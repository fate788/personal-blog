"use strict";

const byId = id => document.getElementById(id);
const workspace = byId("workspace");
const dialog = byId("dialog");
const titles = {
  schedule: "预约日程", records: "预约查询", reschedule: "停诊改约", events: "事件记录"
};
let state;
let selectedSlot = "";
let selectedDay = "";
let department = "";
let pendingDept = "";
let targetId = "";
let eventQuery = "";
let recordQuery = "";
let recordStatus = "";
let selection = new Set();
let submitting = false;
let submitDialog = null;
let restoreFocus = null;
let retryAction = null;
let dialogRevision;
const cjkDate = new Intl.DateTimeFormat("zh-CN", {timeZone:"Asia/Shanghai", month:"2-digit", day:"2-digit"});
const cjkTime = new Intl.DateTimeFormat("zh-CN", {timeZone:"Asia/Shanghai", hour:"2-digit", minute:"2-digit", hour12:false});
const shanghaiDay = new Intl.DateTimeFormat("sv-SE", {timeZone:"Asia/Shanghai", year:"numeric", month:"2-digit", day:"2-digit"});
const fullDay = new Intl.DateTimeFormat("zh-CN", {timeZone:"UTC", month:"long", day:"numeric", weekday:"long"});
const monthYear = new Intl.DateTimeFormat("zh-CN", {timeZone:"UTC", year:"numeric", month:"long"});
const weekDays = ["周一","周二","周三","周四","周五","周六","周日"];

function dayKey(value) { return shanghaiDay.format(new Date(value)); }
function dateValue(key) { return new Date(key+"T00:00:00Z"); }
function shiftDay(key, days) {
  const date = dateValue(key);
  date.setUTCDate(date.getUTCDate()+days);
  return date.toISOString().slice(0,10);
}
function readRequestedRoute() {
  const route=getRoute();
  if(route.view==="records") {
    recordStatus=route.id==="status" && Object.hasOwn(recordLabels,route.detail)?route.detail:"";
    recordQuery=route.query.get("q") || "";
  }
  if(route.view==="events") eventQuery=route.id || route.query.get("q") || "";
  if(route.view==="reschedule" && route.id) {
    const record=state?.records.find(r=>r.id===route.id && r.status==="pending");
    if(record) {
      pendingDept=slotFor(record).department;
      selection=new Set([record.id]);
      targetId="";
    }
  }
  if (route.view!=="schedule") return;
  const slot = state?.slots.find(s=>s.id===route.id);
  if (slot) {
    selectedSlot=slot.id;
    selectedDay=dayKey(slot.start);
    if (department && department!==slot.department) department="";
  } else if(route.day) {
    selectedDay=route.day;
    selectedSlot="";
  }
}

function esc(value) {
  return String(value ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[c]);
}
function moment(value) {
  const instant = new Date(value);
  return cjkDate.format(instant) + " " + cjkTime.format(instant);
}
function slotName(slot) { return slot.department + " · " + slot.label; }
function slotText(slot) { return slotName(slot) + " · " + moment(slot.start) + " · " + slot.id; }
function option(value, label, selected) {
  return '<option value="'+esc(value)+'"'+(value===selected?' selected':'')+'>'+esc(label)+'</option>';
}
function button(action, label, kind="small-button", attrs="") {
  return '<button type="button" class="'+kind+'" data-action="'+action+'" '+attrs+'>'+esc(label)+'</button>';
}
function field(name, label, attributes="") {
  return '<label class="dialog-field">'+label+'<input name="'+name+'" type="text" '+attributes+' required></label>';
}
function getRoute() {
  const [path,search] = location.hash.slice(1).split("?");
  const [view,id,day] = path.split("/");
  const validDay=id==="date" && /^\d{4}-\d{2}-\d{2}$/.test(day || "") && !isNaN(dateValue(day)) && dateValue(day).toISOString().slice(0,10)===day;
  return {view:Object.hasOwn(titles,view)?view:"schedule", id, detail:day, day:validDay?day:"",query:new URLSearchParams(search)};
}
function note(text, failed=false) {
  const item = byId("notice");
  item.textContent = text;
  item.classList.toggle("failed", failed);
  item.hidden = !text;
}
function getSlots() { return state.slots.filter(s => !department || s.department===department); }
function getPending() { return state.records.filter(r => r.status==="pending"); }
function slotFor(record) { return state.slots.find(s => s.id===record.slot_id); }
function currentSlot() { return state.slots.find(s => s.id===selectedSlot); }
function nearestDay(slots, from) {
  const dates = [...new Set(slots.map(s=>dayKey(s.start)))].sort();
  return dates.find(date=>date>=from) || dates.at(-1) || "";
}
function calendar(slots) {
  const monday = shiftDay(selectedDay,-((dateValue(selectedDay).getUTCDay()+6)%7));
  const sunday = shiftDay(monday,6);
  const today = dayKey(state.now);
  const span = monthYear.format(dateValue(monday)) + (monday.slice(0,7)===sunday.slice(0,7)?"":" – "+monthYear.format(dateValue(sunday)));
  const days = weekDays.map((weekday, i)=>{
    const date = shiftDay(monday,i);
    const count = slots.filter(s=>dayKey(s.start)===date).length;
    const status = count ? count+" 班次" : "无排班";
    return '<button type="button" class="calendar-day'+(count?' has-slots':'')+(date===today?' is-today':'')+'" tabindex="'+(date===selectedDay?'0':'-1')+'" data-date="'+date+
      '" aria-pressed="'+(date===selectedDay)+'" aria-label="'+fullDay.format(dateValue(date))+'，'+status+'"'+(date===today?' aria-current="date"':'')+'>'+
      '<span class="day-week">'+weekday+'</span><strong class="day-number">'+Number(date.slice(8))+'</strong>'+
      '<span class="day-status">'+(count?status:"")+'</span></button>';
  });
  return '<section class="calendar-strip" aria-label="周排班日历"><header class="calendar-head"><h2 class="calendar-title">'+span+'</h2>'+
    '<div class="calendar-tools"><button type="button" data-calendar="prev" aria-label="上一周">‹</button><button type="button" data-calendar="today" aria-label="返回演示当天">今天</button><button type="button" data-calendar="next" aria-label="下一周">›</button></div>'+
    '</header><div class="calendar-days">'+days.join("")+'</div></section>';
}
function slotRow(s) {
  const waiting = state.records.filter(r=>r.slot_id===s.id && r.status==="waiting").length;
  const usage = s.status==="suspended" ? "已停诊" : s.status==="closed" ? "已开诊" : s.available ? "余号 "+s.available : "已约满";
  const style = s.status!=="open" ? "closed" : s.available ? "available" : "full";
  return '<li><button type="button" class="slot-button" data-slot="'+s.id+'" aria-pressed="'+(s.id===selectedSlot)+'">'+
    '<time class="slot-time" datetime="'+esc(s.start)+'">'+cjkTime.format(new Date(s.start))+'</time>'+
    '<span class="slot-info"><strong class="slot-name">'+esc(s.department)+'</strong><span class="slot-meta">'+esc(s.label)+' · '+s.id+'</span></span>'+
    '<span class="slot-capacity"><span class="slot-usage '+style+'">'+usage+'</span>'+
    '<small class="slot-queue">'+(waiting?'候补 '+waiting+' 人':'共 '+s.capacity+' 个号源')+'</small></span><span class="chevron" aria-hidden="true">›</span></button></li>';
}
function rosterRow(record) {
  const id=esc(record.id), held=record.status==="held", waiting=record.status==="waiting";
  const flag=held?'<span class="tag held">待确认</span>':waiting?'<span class="tag">第 '+esc(record.position)+' 位</span>':"";
  const detail=held?'预约单 '+id+' · 保留至 '+moment(record.deadline):'预约单 '+id;
  let controls=held?button("confirm","确认保留","small-button primary",'data-record="'+id+'" aria-label="确认保留 '+id+'"'):"";
  if(slotFor(record).status==="open")controls+=button("cancel","取消","text-button",'data-record="'+id+'" aria-label="取消 '+id+'"');
  return '<li class="record"><div class="record-person"><strong class="ticket-id">'+esc(record.person)+'</strong><small class="record-meta">'+esc(detail)+'</small></div>'+
    '<div class="record-side">'+flag+controls+'</div></li>';
}
function roster(s) {
  if(!s) return '<section class="panel roster roster-empty"><header class="panel-head"><h2>班次详情</h2></header><p class="general-empty">选择有排班的日期后，可查看预约名单。</p></section>';
  const rows=state.records.filter(r=>r.slot_id===s.id);
  const booked=rows.filter(r=>r.status==="booked");
  const waiting=rows.filter(r=>r.status==="held").concat(rows.filter(r=>r.status==="waiting").sort((a,b)=>a.position-b.position));
  const sections=[["候补队列",waiting,"暂无候补。"],["已确认预约",booked,"暂无已确认预约。"]];
  const balance=s.status==="open"?(s.available?"余号 "+s.available+" / "+s.capacity:"已约满"):s.status==="suspended"?"已停诊":"已开诊";
  return '<section class="panel roster" aria-label="当前班次名单"><header class="roster-head" id="roster-top" tabindex="-1"><div class="slot-dateline"><span>班次 '+esc(s.id)+'</span><time datetime="'+esc(s.start)+'">'+esc(moment(s.start))+'</time></div>'+
    '<div class="roster-title-row"><h2>'+esc(slotName(s))+'</h2><span class="roster-balance">'+esc(balance)+'</span></div></header>'+
    (s.status==="open"?'<div class="roster-actions">'+button("join",s.available?"登记预约":"登记候补","button primary")+button("suspend","停诊处理","text-button")+'</div>':
      s.status==="suspended"?'<div class="roster-actions"><a class="button" href="#reschedule">查看待改约记录 →</a></div>':'')+
    sections.map(([name,items,empty])=>'<section class="roster-sub"><h3>'+name+' <span class="count">'+items.length+'</span></h3>'+
      (items.length?'<ul class="records">'+items.map(rosterRow).join("")+'</ul>':'<p class="minor-empty">'+empty+'</p>')+'</section>').join("")+'</section>';
}
function queueLinks() {
  const queues = [["waiting","候补排队"],["held","留位待确认"],["pending","停诊待改约"]];
  const links = queues.map(([status, label]) => {
    const count = state.records.filter(record => record.status === status).length;
    return '<a href="#records/status/'+status+'"><span>'+label+'</span><b>'+count+'</b><i aria-hidden="true">›</i></a>';
  });
  return '<section class="panel queue-panel"><header><h2>窗口待办</h2><span>全部日期</span></header>'+
    '<div class="queue-links">'+links.join("")+'</div></section>';
}
function schedule() {
  const deps=[...new Set(state.slots.map(s=>s.department))];
  const slots=getSlots();
  if(!selectedDay) {
    const preferred=slots.find(s=>s.status==="open") || slots[0];
    selectedDay=preferred?dayKey(preferred.start):dayKey(state.now);
  }
  const daySlots=slots.filter(s=>dayKey(s.start)===selectedDay).sort((a,b)=>a.start.localeCompare(b.start));
  if(!daySlots.some(s=>s.id===selectedSlot)) selectedSlot=daySlots[0]?.id || "";
  const jump=nearestDay(slots,selectedDay);
  const listing=daySlots.length ? '<ul class="slots">'+daySlots.map(slotRow).join("")+'</ul>' :
    '<div class="general-empty"><strong>当天没有排班</strong><p>'+esc(department || '所有科室')+'在此日期没有班次。</p>'+
    (jump?'<button type="button" class="button" data-calendar="available">查看 '+Number(jump.slice(5,7))+' 月 '+Number(jump.slice(8))+' 日的排班</button>':'')+'</div>';
  const overview=renderDayOverview(daySlots,selectedDay,calendar(slots));
  return overview+'<div class="board schedule-board"><div class="agenda-column"><section class="panel agenda-panel"><header class="panel-head"><div class="agenda-heading"><h2>出诊时段</h2><span class="agenda-count">'+daySlots.length+' 个班次</span></div>'+
    '<label class="panel-filter"><span class="sr-only">筛选科室</span><select id="department">'+option("","全部科室",department)+deps.map(d=>option(d,d,department)).join("")+'</select></label></header>'+
    listing+'</section>'+queueLinks()+'</div>'+roster(currentSlot())+'</div>';
}
function reschedule() {
  const all=getPending();
  if(!all.length) {
    selection.clear(); targetId="";
    const available=state.slots.filter(slot=>slot.status==="open" && slot.available>0)
      .sort((a,b)=>a.start.localeCompare(b.start)).slice(0,5);
    const openings=available.map(slot=>'<li><a href="#schedule/'+esc(slot.id)+'"><time datetime="'+esc(slot.start)+'">'+esc(moment(slot.start))+'</time>'+
      '<strong>'+esc(slotName(slot))+'</strong><span>余号 '+slot.available+'</span><i aria-hidden="true">›</i></a></li>').join("");
    return '<section class="panel transfer-empty"><div class="transfer-intake"><div class="general-empty"><div class="transfer-message"><strong>暂无待改约预约</strong><p>停诊班次的已确认预约会出现在这里。</p></div><div class="transfer-return"><a class="button" href="#schedule">返回预约日程 →</a></div></div></div>'+
      sceneFigure("transfer")+'</section>'+
      (openings?'<section class="panel receiving-panel"><header class="panel-head"><h2>近期有余号的班次</h2></header><ul>'+openings+'</ul></section>':"");
  }
  const depts=[...new Set(all.map(r=>slotFor(r).department))];
  if(!depts.includes(pendingDept)) pendingDept=depts[0];
  const records=all.filter(r=>slotFor(r).department===pendingDept);
  selection=new Set([...selection].filter(id=>records.some(r=>r.id===id)));
  const targets=state.slots.filter(s=>s.department===pendingDept && s.status==="open" && s.available>=Math.max(selection.size,1));
  if(!targets.some(s=>s.id===targetId)) targetId=targets[0]?.id || "";
  const groupMap=new Map();
  for(const record of records) {
    if(!groupMap.has(record.slot_id)) groupMap.set(record.slot_id,[]);
    groupMap.get(record.slot_id).push(record);
  }
  const groups=[...groupMap.values()].map(group=>{
    const slot=slotFor(group[0]);
    return '<section class="transfer-group"><h3>'+esc(slotText(slot))+'</h3><ul class="records">'+group.map(r=>
      '<li class="record"><label class="check-label"><input type="checkbox" data-pending="'+esc(r.id)+'" '+(selection.has(r.id)?'checked':'')+'><span><strong class="ticket-id">'+esc(r.person)+'</strong>'+
      '<small class="record-meta">预约单 '+esc(r.id)+'</small></span></label>'+button("cancel","取消","text-button",'data-record="'+esc(r.id)+'" aria-label="取消 '+esc(r.id)+'"')+'</li>').join("")+'</ul></section>';
  }).join("");
  const origins=[...new Set(records.filter(r=>selection.has(r.id)).map(r=>r.slot_id))];
  const firstOrigin=state.slots.find(s=>s.id===origins[0]);
  const target=targets.find(s=>s.id===targetId);
  const sourceLabel=origins.length>1?origins.length+" 个班次":firstOrigin?.id || "待选择";
  const sourceTime=origins.length===1?'<small>'+esc(moment(firstOrigin.start))+'</small>':"";
  const summary='<div class="transfer-summary"><div class="transfer-from"><small>原班次</small><strong>'+esc(sourceLabel)+'</strong>'+sourceTime+'</div><span class="transfer-arrow" aria-hidden="true">→</span>'+
    '<div class="transfer-to"><small>接收班次</small><strong>'+esc(target?.id || "暂无")+'</strong>'+(target?'<small>'+esc(moment(target.start))+'</small>':'')+'</div></div>';
  return '<div class="board transfer-board"><section class="panel"><header class="panel-head"><h2>待改约名单</h2><label class="panel-filter"><span class="sr-only">待改约科室</span><select id="pending-dept">'+depts.map(d=>option(d,d,pendingDept)).join("")+'</select></label></header>'+
    '<div class="reschedule-body"><div class="section-tools"><label class="check-label"><input type="checkbox" id="select-all" '+(selection.size===records.length?'checked':'')+'>全选本组</label><span>'+records.length+' 笔待处理</span></div>'+groups+'</div></section>'+
    '<section class="panel transfer-target"><header class="panel-head"><h2>重新分配号源</h2><span class="tag">已选 '+selection.size+' 笔</span></header>'+
    '<div class="target-body">'+summary+'<label for="target-slot">同科目标班次<select id="target-slot" '+(targets.length?'':'disabled')+'>'+
    (targets.length?targets.map(s=>option(s.id,slotText(s)+' · 余号 '+s.available,targetId)).join(""):'<option>暂无余号充足的班次</option>')+
    '</select></label><p class="detail-note">'+(!selection.size?'请勾选需要改约的预约。':target?'提交后此班次剩余 '+(target.available-selection.size)+' 个号源。':'可减少勾选数量，分批改至其他班次。')+'</p>'+
    button("reschedule","办理改约","button primary",selection.size && targetId?"":"disabled")+'</div></section></div>';
}
const eventKinds={booking:"预约成功",join:"候补登记",offer:"候补留位",cancel:"取消记录",confirm:"确认预约",expire:"留位到期",advance:"推进时钟",suspend:"班次停诊",pending:"转待改约",reschedule:"改约完成"};
const recordLabels={booked:"已预约",waiting:"候补中",held:"限时留位",pending:"待改约",cancelled:"已取消",expired:"已过期"};

function matchingRecords() {
  const query=recordQuery.trim().toLowerCase();
  return state.records.filter(record=>{
    if(recordStatus && record.status!==recordStatus) return false;
    const slot=slotFor(record);
    return [record.person,record.id,slot.id,slot.department,slot.label].some(value=>value.toLowerCase().includes(query));
  }).reverse();
}
function recordRows(records) {
  if(!records.length) {
    const filtered=recordQuery || recordStatus;
    return '<div class="general-empty"><strong>'+(filtered?'没有匹配的预约':'暂无预约记录')+'</strong>'+
      (filtered?'<p>尝试其他编号或清除筛选。</p>'+button("clear-records","清除筛选","button"):'')+'</div>';
  }
  const headings='<div class="lookup-columns" aria-hidden="true"><span>就诊编号 / 预约单</span><span>科室 / 出诊时段</span><span>预约状态</span><span>办理记录</span></div>';
  return headings+'<ul class="lookup-list">'+records.map(record=>{
    const slot=slotFor(record);
    const detail=record.status==="waiting"?'第 '+record.position+' 位':record.status==="held"?'保留至 '+moment(record.deadline):'';
    return '<li class="lookup-row" data-record-id="'+esc(record.id)+'"><div class="lookup-ident"><strong>'+esc(record.person)+'</strong><small>预约单 '+esc(record.id)+'</small></div>'+
      '<div class="lookup-slot"><strong>'+esc(slot.department)+' · '+esc(slot.label)+'</strong><small>'+esc(moment(slot.start))+' · '+esc(slot.id)+'</small></div>'+
      '<div class="lookup-status"><span class="lookup-state" data-status="'+record.status+'">'+recordLabels[record.status]+'</span>'+(detail?'<small>'+esc(detail)+'</small>':'')+'</div>'+
      '<div class="lookup-actions">'+button("record-detail","查看详情","small-button",'data-record="'+esc(record.id)+'" aria-label="查看预约 '+esc(record.id)+'"')+'</div></li>';
  }).join("")+'</ul>';
}
function recordsView() {
  const records=matchingRecords();
  return '<section class="panel lookup-panel"><div class="lookup-intake"><div class="lookup-controls"><header class="panel-head"><h2>预约台账</h2><span id="record-count" class="count" role="status">'+records.length+' 笔记录</span></header>'+
    '<div class="lookup-tools"><label class="lookup-search"><span class="sr-only">搜索预约</span><input id="record-search" type="search" placeholder="就诊编号、预约单或班次" value="'+esc(recordQuery)+'"></label>'+
    '<label class="lookup-filter"><span class="sr-only">预约状态</span><select id="record-status">'+option("","全部状态",recordStatus)+
    Object.entries(recordLabels).map(([key,label])=>option(key,label,recordStatus)).join("")+'</select></label></div></div>'+sceneFigure("counter")+'</div>'+
    '<div id="record-results">'+recordRows(records)+'</div></section>';
}
function updateRecordResults() {
  const route=recordStatus?'/status/'+recordStatus:'';
  const search=recordQuery?'?'+new URLSearchParams({q:recordQuery}):'';
  history.replaceState(null,"","#records"+route+search);
  const records=matchingRecords();
  byId("record-count").textContent=records.length+' 笔记录';
  byId("record-results").innerHTML=recordRows(records);
}
function openRecordDetail(record) {
  const slot=slotFor(record);
  const facts=[["就诊编号",record.person],["预约状态",recordLabels[record.status]],["出诊班次",slotName(slot)+" · "+slot.id],["预约时间",moment(slot.start)]];
  if(record.status==="held") facts.push(["保留至",moment(record.deadline)]);
  if(record.status==="waiting") facts.push(["候补顺序","第 "+record.position+" 位"]);
  const events=state.events.filter(event=>event.record_id===record.id);
  const historyList=events.map(event=>'<li><time datetime="'+esc(event.time)+'">'+esc(moment(event.time))+'</time><div><strong>'+esc(eventKinds[event.kind] || "办理记录")+'</strong><p>'+esc(event.text)+'</p></div></li>').join("");
  const destination=record.status==="pending"?'#reschedule/'+record.id:'#schedule/'+slot.id;
  openDialog("预约 "+record.id,
    '<dl class="record-facts">'+facts.map(([key,value])=>'<div><dt>'+key+'</dt><dd>'+esc(value)+'</dd></div>').join("")+'</dl>'+
    '<h3 class="history-heading">办理经过</h3>'+(historyList?'<ol class="record-history">'+historyList+'</ol>':'<p>暂无办理记录。</p>')+
    '<div class="record-links"><a class="button" href="'+esc(destination)+'">'+(record.status==="pending"?'办理改约':'查看班次')+
    '</a><a class="button" href="#events/'+esc(record.id)+'">查看事件记录</a></div>');
}
function eventItems() {
  const q=eventQuery.trim().toLocaleLowerCase();
  const requestedRecord=getRoute().id;
  const days=new Map();
  for(const e of state.events) {
    if(requestedRecord && e.record_id!==requestedRecord)continue;
    if(![e.text,e.slot_id,e.record_id,eventKinds[e.kind],moment(e.time)].join(" ").toLocaleLowerCase().includes(q))continue;
    const key=dayKey(e.time);
    if(!days.has(key))days.set(key,[]);
    days.get(key).push(e);
  }
  if(!days.size)return '<p class="general-empty">'+(q?'没有匹配的记录。':'当前没有操作记录。')+'</p>';
  return [...days.entries()].map(([date,events])=>'<section class="event-group"><h3>'+fullDay.format(dateValue(date))+'</h3><ol class="event-list">'+events.map(e=>
    '<li data-kind="'+esc(e.kind)+'"><time datetime="'+esc(e.time)+'">'+cjkTime.format(new Date(e.time))+'</time><div class="event-copy"><strong class="event-kind">'+esc(eventKinds[e.kind] || '调度操作')+'</strong>'+
    '<p>'+esc(e.text)+'</p><small class="event-key">'+[e.record_id,e.slot_id].filter(Boolean).map(esc).join(" · ")+'</small></div></li>').join("")+'</ol></section>').join("");
}
function eventsView() {
  return '<section class="panel events-panel"><header class="panel-head"><h2>操作时间线</h2><label class="event-filter"><span class="sr-only">查找事件</span><input id="event-filter" type="search" placeholder="搜索编号或事件" value="'+esc(eventQuery)+'"></label></header><div class="event-body" id="event-list">'+eventItems()+'</div></section>';
}

function selectCalendarDay(day, focusSelector) {
  if(!day)return;
  if(selectedDay!==day)selectedSlot="";
  selectedDay=day;
  history.replaceState(null,"","#schedule/date/"+day);
  note("");
  render();
  const focusTarget=workspace.querySelector(focusSelector) || workspace.querySelector('.calendar-day[aria-pressed="true"]');
  focusTarget?.focus({preventScroll:true});
}

function render() {
  const route=getRoute();
  document.querySelectorAll("[data-nav]").forEach(a=>a.dataset.nav===route.view?a.setAttribute("aria-current","page"):a.removeAttribute("aria-current"));
  byId("page-title").textContent=titles[route.view];
  document.title=titles[route.view]+" · 门诊候补与改约工作台";
  if(!state) return;
  byId("clock").textContent=moment(state.now);
  document.querySelectorAll('[data-action="advance"], [data-action="reset"], [data-action="quick-book"]').forEach(b=>b.disabled=submitting);
  const pages={schedule, records:recordsView,events:eventsView,reschedule};
  const content=pages[route.view]();
  workspace.innerHTML=content;
  for (const figure of workspace.querySelectorAll("figure[data-scene]")) {
    const template = byId(figure.dataset.scene+"-scene");
    figure.prepend(template.content.cloneNode(true));
  }
  workspace.setAttribute("aria-busy","false");
  const all=byId("select-all");
  if(all) all.indeterminate=selection.size>0 && !all.checked;
}
async function load() {
  try {
    const response=await fetch("/api/state",{cache:"no-store"});
    if(!response.ok) throw Error();
    state=await response.json();
    readRequestedRoute();
    render();
  } catch {
    workspace.setAttribute("aria-busy","false");
    if(!state) workspace.innerHTML='<p class="initial">无法读取当前工作区。 '+button("retry","重新载入")+'</p>';
    else note("未能刷新工作区，请检查本机服务后重试。",true);
  }
}
function openDialog(title, body, actionTitle="", callback=null) {
  restoreFocus=document.activeElement;
  dialogRevision=state?.revision;
  byId("dialog-title").textContent=title;
  byId("dialog-body").innerHTML=body;
  byId("dialog-error").hidden=true;
  byId("dialog-actions").innerHTML=button("close",callback?"返回":"知道了","button")+(callback?'<button type="submit" class="button primary">'+esc(actionTitle)+'</button>':"");
  submitDialog=callback;
  dialog.showModal();
  (dialog.querySelector("input") || dialog.querySelector("select") || dialog.querySelector('[data-action="close"]')).focus();
}
const personAttributes='placeholder="例如 P005" pattern="P[0-9]{3,5}" maxlength="6" title="大写 P 加 3 至 5 位数字" autocomplete="off"';
function quickBookingFields() {
  const open=state.slots.filter(s=>s.status==="open");
  const depts=[...new Set(open.map(s=>s.department))];
  return '<div class="booking-filters"><label class="dialog-field">科室<select id="quick-dept">'+option("","全部科室","")+depts.map(d=>option(d,d,"")).join("")+'</select></label>'+
    '<label class="dialog-field">出诊日期<select id="quick-day"></select></label></div>'+
    '<label class="quick-free check-label"><input id="quick-free" type="checkbox">仅看有余号的班次</label>'+
    '<label class="dialog-field">选择班次<select id="quick-slot" name="slot" required></select></label>'+
    '<p id="quick-summary" class="booking-summary" aria-live="polite"></p>'+field("person","虚构就诊编号",personAttributes);
}
function updateQuickBooking() {
  const dept=byId("quick-dept").value;
  const date=byId("quick-day");
  const select=byId("quick-slot");
  const open=state.slots.filter(s=>s.status==="open" && (!dept || s.department===dept)).sort((a,b)=>a.start.localeCompare(b.start));
  const days=[...new Set(open.map(s=>dayKey(s.start)))];
  const chosenDay=days.includes(date.value)?date.value:"";
  date.innerHTML=option("","全部日期",chosenDay)+days.map(d=>option(d,fullDay.format(dateValue(d)),chosenDay)).join("");
  const slots=open.filter(s=>(!chosenDay || dayKey(s.start)===chosenDay) && (!byId("quick-free").checked || s.available>0));
  const chosen=slots.find(s=>s.id===select.value) || slots.find(s=>s.available>0) || slots[0];
  select.innerHTML=chosen?slots.map(s=>option(s.id,s.id+' · '+moment(s.start)+' · '+slotName(s)+(s.available?' · 余号 '+s.available:' · 可候补'),chosen.id)).join(""):'<option value="">无可选班次</option>';
  select.disabled=!chosen;
  const submit=dialog.querySelector('button[type="submit"]');
  submit.disabled=!chosen;
  submit.textContent=chosen && !chosen.available?"登记候补":"确认预约";
  const summary=byId("quick-summary");
  summary.dataset.mode=chosen?(chosen.available?"booking":"waiting"):"empty";
  if(!chosen) {
    summary.textContent="当前条件下没有可登记的班次。";
    return;
  }
  const queued=state.records.filter(r=>r.slot_id===chosen.id && r.status==="waiting").length;
  summary.textContent=chosen.available?'剩余 '+chosen.available+' 个号源，提交后即确认预约。':'该班次已约满，当前 '+queued+' 人候补。提交后按登记顺序排队。';
}
function openQuickBooking() {
  if(!state.slots.some(s=>s.status==="open")) {
    openDialog("预约登记",'<p>当前没有开放登记的班次。</p>');
    return;
  }
  openDialog("预约登记",quickBookingFields(),"确认预约",data=>{
    const slot=state.slots.find(s=>s.id===data.get("slot") && s.status==="open");
    if(!slot)return;
    const person=String(data.get("person")).trim();
    const success=updated=>{
      const record=updated.records.filter(r=>r.person===person && r.slot_id===slot.id).at(-1);
      return record?record.person+' · '+record.id+' '+recordLabels[record.status]+'，已定位到班次 '+slot.id+'。':"登记成功，已打开对应班次。";
    };
    mutate({action:"join",slot_id:slot.id,person},success,"schedule/"+slot.id);
  });
  updateQuickBooking();
  byId("quick-dept").focus();
}
function closeDialog() {
  if(!submitting) dialog.close();
}
dialog.addEventListener("close",()=>{
  submitDialog=null;
  if(restoreFocus?.isConnected) restoreFocus.focus({preventScroll:true});
  else {
    const action=restoreFocus?.dataset.action;
    const record=restoreFocus?.dataset.record;
    const selector=action?'[data-action="'+CSS.escape(action)+'"]'+(record?'[data-record="'+CSS.escape(record)+'"]':""):"";
    const target=(selector && workspace.querySelector(selector)) || byId("roster-top") || byId("page-title");
    target.focus({preventScroll:true});
  }
});
dialog.addEventListener("cancel",event=>{if(submitting)event.preventDefault();});
async function mutate(payload, success, nextView) {
  if(submitting)return;
  const key=JSON.stringify(payload)+":"+dialogRevision;
  if(!retryAction || retryAction.key!==key) {
    retryAction={key,id:crypto.randomUUID ? crypto.randomUUID() : [...crypto.getRandomValues(new Uint32Array(4))].map(n=>n.toString(16)).join("-")};
  }
  submitting=true;
  const controls=[...dialog.querySelectorAll("button,input,select")].filter(el=>!el.disabled);
  controls.forEach(el=>el.disabled=true);
  const error=byId("dialog-error");
  error.hidden=true;
  let completed=false;
  try {
    const response=await fetch("/api/action",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({...payload,request_id:retryAction.id,expected_revision:dialogRevision})});
    const updated=await response.json();
    if(!response.ok) {
      retryAction=null;
      if(response.status===409) {
        await load();
        if(dialogRevision!==state?.revision) {
          submitting=false;dialog.close();
          note((updated.error||"记录已发生变化")+"。已刷新工作区，请核对后重新操作。",true);
          return;
        }
      }
      error.textContent=updated.error || "操作未完成，请核对输入后重试。";
      error.hidden=false;
      return;
    }
    state=updated;
    retryAction=null;
    completed=true;
    if(payload.action==="reset") {
      department="";pendingDept="";selectedSlot="";selectedDay="";targetId="";selection.clear();eventQuery="";recordQuery="";recordStatus="";
    }
    if(payload.action==="reschedule")selection.clear();
    if(nextView) {
      const hash="#"+nextView;
      if(nextView.startsWith("schedule/") && location.hash!==hash) history.pushState(null,"",hash);
      else history.replaceState(null,"",hash);
      readRequestedRoute();
      window.scrollTo(0,0);
    }
    render();
    note(typeof success==="function"?success(updated):success);
    if(nextView?.startsWith("schedule/")) restoreFocus=byId("roster-top");
  } catch {
    error.textContent="没有收到服务结果。恢复连接后再次提交，可核对本次操作。";
    error.hidden=false;
  } finally {
    submitting=false;
    controls.forEach(b=>b.disabled=false);
    if(completed)dialog.close();
    document.querySelectorAll('[data-action="advance"], [data-action="reset"], [data-action="quick-book"]').forEach(b=>b.disabled=!state);
  }
}
function actions(action, btn) {
  if(action==="close") {closeDialog();return;}
  if(action==="retry") {load();return;}
  if(action==="guide") {
    openDialog("操作指引",'<ol class="steps"><li><strong>登记与查询</strong>点“快速登记”，按科室或日期选号并输入虚构就诊编号。到“预约查询”用编号找回预约单、查看状态和办理经过。</li><li><strong>释放号源</strong>在初始满员的 S01 班次取消一笔已确认预约，队首候补将获得限时保留。</li><li><strong>处理限时保留</strong>输入对应的虚构就诊编号确认，也可以推进演示时钟，查看保留到期后下一位如何递补。</li><li><strong>办理停诊改约</strong>选择仍有已确认预约的班次停诊，勾选待改约记录，再选择有余号的同科班次。一笔或多笔均可提交。</li></ol>');return;
  }
  if(!state || submitting)return;
  const slot=currentSlot();
  const record=state.records.find(r=>r.id===btn.dataset.record);
  if(action==="quick-book") {
    openQuickBooking();
  } else if(action==="record-detail" && record) {
    openRecordDetail(record);
  } else if(action==="clear-records") {
    recordQuery="";recordStatus="";
    byId("record-search").value="";byId("record-status").value="";
    updateRecordResults();byId("record-search").focus();
  } else if(action==="advance") {
    openDialog("推进演示时钟",'<p>时间向前推进后，系统将处理到期保留及后续递补。当前时间为 '+esc(moment(state.now))+'。</p><label class="dialog-field">推进时长<select name="minutes"><option value="1">1 分钟</option><option value="10" selected>10 分钟</option><option value="30">30 分钟</option><option value="1440">24 小时</option></select></label>',"推进时间",data=>mutate({action,minutes:Number(data.get("minutes"))},"演示时钟已推进，最新号源状态已更新。"));
  } else if(action==="reset") {
    openDialog("重置当前演示",'<p>本工作区将恢复为初始排班，清除本次的预约变更和操作记录。</p>',"确认重置",()=>mutate({action},"已恢复初始排班。","schedule"));
  } else if(action==="join" && slot) {
    const title=slot.available?"登记预约":"登记候补";
    openDialog(title,'<p>'+esc(slotText(slot))+'</p>'+field("person","虚构就诊编号",personAttributes),title,data=>mutate({action,slot_id:slot.id,person:String(data.get("person")).trim()},"已完成登记，请在本班次名单中核对结果。"));
  } else if(action==="confirm" && record) {
    openDialog("确认限时保留",'<p>记录 '+esc(record.id)+' 的保留截止于 '+esc(moment(record.deadline))+'。请核对名单并输入这笔记录对应的就诊编号。</p>'+field("person","确认人的虚构就诊编号",'placeholder="P 加 3 至 5 位数字" pattern="P[0-9]{3,5}" maxlength="6" autocomplete="off"'),"确认预约",data=>mutate({action,record_id:record.id,person:String(data.get("person")).trim()},"已确认保留号源。"));
  } else if(action==="cancel" && record) {
    openDialog("取消这条记录",'<p>'+esc(record.person)+' 的记录 '+esc(record.id)+' 将被取消。已占用或保留的号源会释放给可递补的候补记录。</p>',"确认取消",()=>mutate({action,record_id:record.id},"已取消 "+record.id+"，班次名单已更新。"));
  } else if(action==="suspend" && slot) {
    openDialog("确认班次停诊",'<p>'+esc(slotText(slot))+' 将停止登记。'+slot.booked+' 笔已确认预约转入待改约，该班次的候补和限时保留将取消。</p>',"确认停诊",()=>mutate({action,slot_id:slot.id},"班次已停诊，待改约名单已更新。","reschedule"));
  } else if(action==="reschedule" && selection.size && targetId) {
    const ids=[...selection],target=state.slots.find(s=>s.id===targetId);
    openDialog("确认改约",'<p>将 '+esc(ids.join("、"))+' 共 '+ids.length+' 笔预约改至 '+esc(slotText(target))+'。目标班次当前剩余 '+target.available+' 个号源。</p>',"确认改约",()=>mutate({action,record_ids:ids,slot_id:target.id},"已改约 "+ids.length+" 笔，详情已写入事件记录。"));
  }
}
byId("dialog-form").addEventListener("submit",event=>{
  event.preventDefault();
  if(submitDialog)submitDialog(new FormData(event.target));
});
document.addEventListener("click",event=>{
  const skip=event.target.closest(".skip");
  if(skip){event.preventDefault();byId("main").focus();return;}
  const btn=event.target.closest("[data-action]");
  if(btn){actions(btn.dataset.action,btn);return;}
  const dateButton=event.target.closest("[data-date]");
  if(dateButton && state && !submitting) {
    selectCalendarDay(dateButton.dataset.date,'.calendar-day[aria-pressed="true"]');
    return;
  }
  const calendarButton=event.target.closest("[data-calendar]");
  if(calendarButton && state && !submitting) {
    const operation=calendarButton.dataset.calendar;
    const date=operation==="prev"?shiftDay(selectedDay,-7):operation==="next"?shiftDay(selectedDay,7):
      operation==="today"?dayKey(state.now):nearestDay(getSlots(),selectedDay);
    selectCalendarDay(date,'[data-calendar="'+operation+'"]');
    return;
  }
  const row=event.target.closest("[data-slot]");
  if(row && !submitting) {
    selectedSlot=row.dataset.slot;
    history.replaceState(null,"","#schedule/"+encodeURIComponent(selectedSlot));
    render();
    if(matchMedia("(max-width:740px)").matches)byId("roster-top")?.focus();
    else workspace.querySelector('[data-slot="'+CSS.escape(selectedSlot)+'"]')?.focus({preventScroll:true});
  }
});
document.addEventListener("change",event=>{
  if(!state || submitting)return;
  const el=event.target;
  if(["quick-dept","quick-day","quick-free","quick-slot"].includes(el.id)) {updateQuickBooking();return;}
  if(el.id==="record-status") {recordStatus=el.value;updateRecordResults();return;}
  if(el.id==="department") {department=el.value;history.replaceState(null,"","#schedule/date/"+selectedDay);}
  else if(el.id==="pending-dept") {pendingDept=el.value;selection.clear();}
  else if(el.id==="target-slot") {targetId=el.value;}
  else if(el.id==="select-all") {
    selection=el.checked?new Set(getPending().filter(r=>slotFor(r).department===pendingDept).map(r=>r.id)):new Set();
  } else if(el.dataset.pending) {
    if(el.checked)selection.add(el.dataset.pending);else selection.delete(el.dataset.pending);
  } else return;
  render();
  const replaced=el.id?byId(el.id):workspace.querySelector('[data-pending="'+CSS.escape(el.dataset.pending)+'"]');
  replaced?.focus({preventScroll:true});
});
document.addEventListener("input",event=>{
  if(event.target.id==="record-search") {recordQuery=event.target.value;updateRecordResults();}
  if(event.target.id==="event-filter") {
    eventQuery=event.target.value;
    history.replaceState(null,"","#events"+(eventQuery?'?'+new URLSearchParams({q:eventQuery}):''));
    byId("event-list").innerHTML=eventItems();
  }
});
window.addEventListener("hashchange",()=>{
  if(dialog.open && !submitting) dialog.close();
  readRequestedRoute();
  note("");render();window.scrollTo(0,0);
});
workspace.addEventListener("keydown",event=>{
  if(!event.target.matches("[data-date]") || !state || submitting) return;
  const index=(dateValue(selectedDay).getUTCDay()+6)%7;
  const offsets={ArrowLeft:-1,ArrowRight:1,Home:-index,End:6-index};
  if(!Object.hasOwn(offsets,event.key)) return;
  event.preventDefault();
  selectCalendarDay(shiftDay(selectedDay,offsets[event.key]),'.calendar-day[aria-pressed="true"]');
});
// Reserve the actual footer height even when text wraps or the device's safe area changes.
if ("ResizeObserver" in window) {
  const footer=document.querySelector(".footer");
  const footerObserver=new ResizeObserver(()=>{
    const height=Math.ceil(footer.getBoundingClientRect().height);
    document.documentElement.style.setProperty("--footer-height",height+"px");
  });
  footerObserver.observe(footer,{box:"border-box"});
}
render();
load();

function sceneFigure(scene) {
  return '<figure class="hospital-scene" data-scene="'+scene+'"></figure>';
}

function renderDayOverview(daySlots, date, weekCalendar) {
  const open = daySlots.filter(slot => slot.status === "open");
  const totals = {booked:0, held:0, available:0};
  for (const slot of open) {
    totals.booked += slot.booked;
    totals.held += slot.held;
    totals.available += slot.available;
  }
  const total = totals.booked + totals.held + totals.available;
  const usedPercent = total ? 100 * (totals.booked + totals.held) / total : 0;
  const bookedPercent = total ? 100 * totals.booked / total : 0;
  const groups = [["booked", "已预约"], ["held", "候补留位"], ["available", "可约"]];
  const legend = groups.map(([key, label]) =>
    '<span data-usage="'+key+'" data-count="'+totals[key]+'">'+label+' <b>'+totals[key]+'</b></span>'
  ).join("");
  const available = total ? totals.available : "—";
  const caption = total ? ' / '+total+' 个号源' : daySlots.length ? '暂无开放班次' : '当天无排班';
  return '<section class="day-overview'+(daySlots.length?' capacity-summary':'')+'" aria-label="所选日期号源">'+sceneFigure("lobby")+
    '<div class="overview-data"><div class="overview-date"><time datetime="'+esc(date)+'">'+
    fullDay.format(dateValue(date))+'</time><span>'+esc(department || "全部科室")+'</span></div>'+
    '<div class="overview-totals"><div><h2>当日可约号源</h2><div class="overview-value"><strong>'+available+'</strong><span>'+caption+'</span></div></div>'+
    '<div class="overview-mix"><div class="usage-note">号源占用率 <strong>'+(total?Math.round(usedPercent)+'%':'—')+'</strong></div>'+
    '<div class="capacity-track" aria-hidden="true" style="--booked:'+bookedPercent+'%;--used:'+usedPercent+'%"></div>'+
    '<div class="capacity-legend">'+legend+'</div></div></div></div>'+weekCalendar+'</section>';
}
