import { mkdir, readFile, writeFile } from 'node:fs/promises';
import { dirname, resolve } from 'node:path';

const output = resolve(process.argv[2] || 'dist/index.html');
const read = async path => (await readFile(new URL(path, import.meta.url), 'utf8')).replaceAll('\r\n', '\n');
const moduleUrl = source => `data:text/javascript;base64,${Buffer.from(source).toString('base64')}`;
const [html, css, app, engine, fixtures] = await Promise.all([
  read('./static/index.html'), read('./static/styles.css'), read('./static/app.mjs'),
  read('./engine.mjs'), read('./fixtures.mjs'),
]);

function inlineImport(source, filename, url) {
  return source.replaceAll(`'${filename}'`, `'${url}'`).replaceAll(`"${filename}"`, `"${url}"`);
}

const engineUrl = moduleUrl(engine);
const fixturesUrl = moduleUrl(inlineImport(fixtures, './engine.mjs', engineUrl));
const appSource = inlineImport(inlineImport(app, '../engine.mjs', engineUrl), '../fixtures.mjs', fixturesUrl);
const styleTag = /<link\b[^>]*href=["'](?:\.\/)?styles\.css["'][^>]*>/iu;
const scriptTag = /<script\b[^>]*src=["'](?:\.\/)?app\.mjs["'][^>]*>\s*<\/script>/iu;
const policy = "default-src 'none'; style-src 'unsafe-inline'; script-src data:; img-src data:; connect-src 'none'; base-uri 'none'; form-action 'none'";

if (!styleTag.test(html) || !scriptTag.test(html)) throw new Error('缺少工作台的样式或脚本入口。');
const portable = html.replace('<head>', `<head>\n  <meta http-equiv="Content-Security-Policy" content="${policy}">`)
  .replace(styleTag, () => `<style>\n${css}\n</style>`)
  .replace(scriptTag, () => `<script type="module" src="${moduleUrl(appSource)}"></script>`);

await mkdir(dirname(output), { recursive: true });
await writeFile(output, portable, 'utf8');
console.log(`已生成日志隐私抽检台 ${output}`);
