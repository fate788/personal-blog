const SAMPLE_EMAIL = 'member-204@updates.example';
const SAMPLE_PHONE = '+1 202-555-0142';
const SAMPLE_BEARER = 'Bearer DEMO_ONLY_DO_NOT_USE_9e217416';

function record(minute, service, level, event, extras) {
  return {
    timestamp: `2026-11-28T02:${String(minute).padStart(2, '0')}:00.000Z`,
    level,
    service,
    event,
    trace_id: `${'0'.repeat(30)}${minute.toString(16).padStart(2, '0')}`,
    ...extras,
  };
}

export const SAMPLE_RECORDS = [
  record(1, 'identity-gateway', 'INFO', 'profile.updated', {
    message: '账户偏好已保存。', actor: { email: 'profile-sample@identity.example' }, http: { method: 'PATCH', status: 204 },
  }),
  record(3, 'notification-job', 'WARN', 'email.delivery_retry', {
    message: `由供应商暂存，计划重发给 ${SAMPLE_EMAIL}。`, latency_ms: 830,
  }),
  record(4, 'identity-gateway', 'WARN', 'session.refresh_denied', {
    message: '会话刷新返回拒绝。', headers: { authorization: 'Bearer DEMO_ONLY_DO_NOT_USE_04auth' }, http: { status: 401 },
  }),
  record(6, 'fulfillment-api', 'INFO', 'courier.callback_scheduled', {
    message: `承运商将回拨 ${SAMPLE_PHONE} 确认交付。`, queue: 'delivery-followup',
  }),
  record(9, 'fulfillment-api', 'INFO', 'shipment.assigned', {
    message: '包裹已分给待取班次。', delivery: { contacts: [{ kind: 'recipient', phone: '+1 202-555-0173' }] },
    order_id: 'DEMO-ORD-6089',
  }),
  record(10, 'order-api', 'ERROR', 'invoice.gateway_timeout', {
    message: '开票服务超时，待重试。', http: { method: 'POST', status: 504 },
  }),
  record(12, 'identity-gateway', 'INFO', 'session.revoked', {
    message: '会话已失效。', headers: { cookie: 'demo_session=DEMO_ONLY_DO_NOT_USE_12cookie' }, http: { status: 204 },
  }),
  record(14, 'order-api', 'INFO', 'order.summary_viewed', {
    message: '读取订单摘要。', attributes: { request_id: 'DEMO-REQUEST-0048' }, route: '/orders/:id/summary',
  }),
  record(17, 'notification-job', 'ERROR', 'push.provider_rejected', {
    message: `模拟供应商拒绝授权 ${SAMPLE_BEARER}，已触发重试。`, latency_ms: 320,
  }),
  record(18, 'order-api', 'INFO', 'receipt.requested', {
    message: '收据申请受理。', attributes: { customer: { email: 'receipt-sample@billing.example' } }, status: 'accepted',
  }),
  record(20, 'notification-job', 'INFO', 'push.destination_added', {
    message: '通知端点已标记。', notifications: [{ channel: 'push', access_token: 'DEMO_ONLY_DO_NOT_USE_20push' }],
  }),
  record(22, 'fulfillment-api', 'INFO', 'delivery.completed', {
    message: '包裹送达事件已受理。', http: { status: 202 },
  }),
];

const sensitive = (path, category, literal) => ({ kind: 'sensitive', path, category, literal });
const diagnostic = path => ({ kind: 'protected', path, category: 'diagnostic' });
const trace = (path = '/trace_id') => ({ kind: 'protected', path, category: 'trace' });

// 每行固定标注独立于脱敏规则。正文中的标注仅覆盖敏感片段，保留其余句子。
export const SAMPLE_ANNOTATIONS = [
  [trace(), diagnostic('/http/status'), sensitive('/actor/email', 'email')],
  [trace(), diagnostic('/latency_ms'), sensitive('/message', 'email', SAMPLE_EMAIL)],
  [trace(), diagnostic('/http/status'), sensitive('/headers/authorization', 'credential')],
  [trace(), diagnostic('/queue'), sensitive('/message', 'phone', SAMPLE_PHONE)],
  [trace(), diagnostic('/order_id'), sensitive('/delivery/contacts/0/phone', 'phone')],
  [trace(), diagnostic('/http/status')],
  [trace(), diagnostic('/http/status'), sensitive('/headers/cookie', 'credential')],
  [trace(), trace('/attributes/request_id'), diagnostic('/route')],
  [trace(), diagnostic('/latency_ms'), sensitive('/message', 'credential', SAMPLE_BEARER)],
  [trace(), diagnostic('/status'), sensitive('/attributes/customer/email', 'email')],
  [trace(), diagnostic('/event'), sensitive('/notifications/0/access_token', 'credential')],
  [trace(), diagnostic('/http/status')],
];
