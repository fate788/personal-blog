export const MAX_INPUT_BYTES = 1_048_576;
export const MAX_ROWS = 2_000;
const MAX_DEPTH = 24;

export const BASELINE = Object.freeze({ scanText: false, preserveTrace: false });
export const CANDIDATE = Object.freeze({ scanText: true, preserveTrace: true });

const FIELD_CATEGORIES = new Map([
  ...['email', 'useremail', 'customeremail', 'receiveremail', 'emailaddress'].map(key => [key, 'email']),
  ...['phone', 'mobile', 'phonenumber', 'mobilephone', 'telephone', 'receiverphone'].map(key => [key, 'phone']),
  ...['authorization', 'accesstoken', 'refreshtoken', 'authtoken', 'sessionid', 'cookie', 'setcookie',
    'password', 'apikey', 'clientsecret'].map(key => [key, 'credential']),
]);
const TRACE_FIELDS = new Set(['traceid', 'spanid', 'requestid', 'correlationid']);
const DIAGNOSTIC_FIELDS = new Set([
  'timestamp', 'service', 'level', 'event', 'route', 'status', 'statuscode', 'method', 'latencyms', 'queue', 'orderid',
]);
const CONTAINER_FIELDS = new Set([
  'actor', 'attributes', 'headers', 'http', 'delivery', 'contacts', 'customer', 'notifications', 'message',
]);
const MARKS = Object.freeze({
  email: '[邮箱已遮蔽]', phone: '[电话已遮蔽]', credential: '[凭据已遮蔽]', trace: '[链路标识已遮蔽]',
});

const TEXT_PATTERNS = [
  ['credential', /\bBearer[ \t]+[A-Za-z0-9._~+/=-]{8,}/gi],
  ['email', /(?<![A-Z0-9.!#$%&'*+/=?^_`{|}~-])[A-Z0-9.!#$%&'*+/=?^_`{|}~-]{1,64}@[A-Z0-9](?:[A-Z0-9-]{0,61}[A-Z0-9])?(?:\.[A-Z0-9](?:[A-Z0-9-]{0,61}[A-Z0-9])?){1,10}(?![A-Z0-9-])/gi],
  ['phone', /(?<!\d)(?:\+1[ -])?(?:\([2-9]\d{2}\)|[2-9]\d{2})[ .-][2-9]\d{2}[ .-]\d{4}(?!\d)|(?<!\d)(?:(?:\+?86)[ -]?)?1[3-9]\d{9}(?!\d)/g],
];

function normalizedKey(key) {
  return key.toLowerCase().replace(/[-_.]/g, '');
}

function normalizedPolicy(policy) {
  if (!policy || typeof policy.scanText !== 'boolean' || typeof policy.preserveTrace !== 'boolean') {
    throw new TypeError('规则需要指定正文扫描和链路保留选项。');
  }
  return { scanText: policy.scanText, preserveTrace: policy.preserveTrace };
}

function asPointer(parent, key) {
  return `${parent}/${String(key).replaceAll('~', '~0').replaceAll('/', '~1')}`;
}

function pointerParts(pointer) {
  return pointer.slice(1).split('/').map(key => key.replaceAll('~1', '/').replaceAll('~0', '~'));
}

function atPointer(record, pointer) {
  let value = record;
  for (const key of pointerParts(pointer)) {
    if (value === null || typeof value !== 'object' || !Object.hasOwn(value, key)) return undefined;
    value = value[key];
  }
  return value;
}

function isRecord(value) {
  if (value === null || typeof value !== 'object') return false;
  const prototype = Object.getPrototypeOf(value);
  return prototype === Object.prototype || prototype === null;
}

function validateTree(value, depth = 0) {
  if (depth > MAX_DEPTH) throw new RangeError(`字段嵌套超过 ${MAX_DEPTH} 层。`);
  if (Array.isArray(value) || isRecord(value)) {
    for (const child of Object.values(value)) validateTree(child, depth + 1);
    return;
  }
  if (value !== null && typeof value !== 'string' && typeof value !== 'boolean' && !Number.isFinite(value)) {
    throw new TypeError('字段包含无效的 JSON 值。');
  }
  if (Number.isInteger(value) && !Number.isSafeInteger(value)) {
    throw new RangeError('整数超出安全精度，请把长编号写为字符串。');
  }
}

export function parseJsonl(text) {
  if (typeof text !== 'string') throw new TypeError('请选择 UTF-8 文本。');
  if (new TextEncoder().encode(text).byteLength > MAX_INPUT_BYTES) throw new RangeError('文件超过 1 MiB。');
  const records = [];
  for (const [index, line] of text.replace(/^\uFEFF/, '').split(/\r?\n/).entries()) {
    const content = line.trim();
    if (!content) continue;
    if (records.length >= MAX_ROWS) throw new RangeError(`第 ${index + 1} 行：最多处理 ${MAX_ROWS} 条记录。`);
    let record;
    try {
      record = JSON.parse(content);
    } catch {
      throw new SyntaxError(`第 ${index + 1} 行：无法解析 JSON。`);
    }
    if (!isRecord(record)) throw new TypeError(`第 ${index + 1} 行：每行需要一个 JSON 对象。`);
    try {
      validateTree(record);
    } catch (error) {
      throw new TypeError(`第 ${index + 1} 行：${error.message}`);
    }
    records.push(record);
  }
  if (!records.length) throw new RangeError('文件中未找到日志记录。');
  return records;
}

function hasValue(value) {
  if (typeof value === 'string') return value.trim() !== '' && !Object.values(MARKS).includes(value);
  if (Array.isArray(value)) return value.some(hasValue);
  if (isRecord(value)) return Object.values(value).some(hasValue);
  return value !== null;
}

function textReferences(value, path) {
  return TEXT_PATTERNS.flatMap(([category, pattern]) =>
    [...new Set(Array.from(value.matchAll(pattern), match => match[0]))].map(literal => ({
      kind: 'sensitive', path, category, literal,
    })),
  );
}

function rewriteText(value) {
  for (const [category, pattern] of TEXT_PATTERNS) value = value.replace(pattern, MARKS[category]);
  return value;
}

function isCanonicalTrace(value, key) {
  if (key === 'traceid') return /^(?!0{32}$)[a-f0-9]{32}$/i.test(value);
  return key === 'spanid' && /^(?!0{16}$)[a-f0-9]{16}$/i.test(value);
}

function transform(value, policy, key = '') {
  const normalized = normalizedKey(key);
  const sensitive = FIELD_CATEGORIES.get(normalized);
  if (sensitive && hasValue(value)) return MARKS[sensitive];
  if (!policy.preserveTrace && TRACE_FIELDS.has(normalized) && hasValue(value)) return MARKS.trace;
  if (Array.isArray(value)) return value.map(child => transform(child, policy));
  if (isRecord(value)) {
    return Object.fromEntries(Object.entries(value).map(([name, child]) => [name, transform(child, policy, name)]));
  }
  return typeof value === 'string' && policy.scanText && !isCanonicalTrace(value, normalized) ? rewriteText(value) : value;
}

function estimateReferences(record) {
  const references = [];
  function visit(value, path, key = '') {
    const normalized = normalizedKey(key);
    const category = FIELD_CATEGORIES.get(normalized);
    if (category && hasValue(value)) {
      references.push({ kind: 'sensitive', path, category });
      return;
    }
    if (TRACE_FIELDS.has(normalized) && hasValue(value)) references.push({ kind: 'protected', path, category: 'trace' });
    if (DIAGNOSTIC_FIELDS.has(normalized) && hasValue(value)) references.push({ kind: 'protected', path, category: 'diagnostic' });
    if (typeof value === 'string' && !isCanonicalTrace(value, normalized)) references.push(...textReferences(value, path));
    if (Array.isArray(value)) value.forEach((child, index) => visit(child, asPointer(path, index)));
    if (isRecord(value)) {
      for (const [name, child] of Object.entries(value)) {
        const childPath = asPointer(path, name);
        for (const reference of textReferences(name, childPath)) references.push({ ...reference, location: 'key' });
        visit(child, childPath, name);
      }
    }
  }
  visit(record, '');
  return references;
}

function sameValue(first, second) {
  if (Object.is(first, second)) return true;
  if (first === null || second === null || typeof first !== 'object' || typeof second !== 'object') return false;
  return JSON.stringify(first) === JSON.stringify(second);
}

function evidence(reference, source, redacted, scanText) {
  const { kind, path: sourcePath, category, literal, location } = reference;
  const after = atPointer(redacted, sourcePath);
  const before = atPointer(source, sourcePath);
  const path = pointerParts(sourcePath).reduce((prefix, part) =>
    asPointer(prefix, textReferences(part, '').length ? '[敏感键]' : part), '');
  if (kind === 'protected' && !sameValue(before, after)) {
    return { kind: 'overmask', path, category, reason: '这项排障信息在输出中被改写或遮蔽。' };
  }
  if (location === 'key') {
    return after === undefined ? null : { kind: 'leak', path, category, reason: '敏感内容出现在字段名称中，需要先修正日志结构。' };
  }
  const retained = literal === undefined
    ? after !== undefined && after !== null && !Object.values(MARKS).includes(after)
    : typeof after === 'string' && after.includes(literal);
  if (kind === 'sensitive' && retained) {
    const reason = literal !== undefined && !scanText ? '未启用正文扫描，字符串中的敏感值仍留在输出中。' : '输出中仍能找到此敏感字段或值。';
    return { kind: 'leak', path, category, reason };
  }
  return null;
}

function validateAnnotation(reference, source, index) {
  const { kind, path, category, literal } = reference ?? {};
  const sourceValue = typeof path === 'string' && /^(?:\/(?:[^~/]|~[01])*)+$/.test(path) ? atPointer(source, path) : undefined;
  const supported = kind === 'sensitive' && ['email', 'phone', 'credential'].includes(category)
    || kind === 'protected' && ['trace', 'diagnostic'].includes(category);
  const validLiteral = literal === undefined || kind === 'sensitive' && typeof literal === 'string'
    && literal.length > 0 && typeof sourceValue === 'string' && sourceValue.includes(literal);
  if (!supported || sourceValue === undefined || !hasValue(sourceValue) || !validLiteral) {
    throw new TypeError(`第 ${index + 1} 条记录包含无效标注。`);
  }
}

export function analyze(records, { policy = CANDIDATE, annotations } = {}) {
  const active = normalizedPolicy(policy);
  if (!Array.isArray(records) || !records.length || records.length > MAX_ROWS) {
    throw new RangeError(`需要 1 至 ${MAX_ROWS} 条日志记录。`);
  }
  const labeled = annotations !== undefined;
  if (labeled && (!Array.isArray(annotations) || annotations.length !== records.length || annotations.some(row => !Array.isArray(row)))) {
    throw new TypeError('标注批次与日志记录不匹配。');
  }
  const totals = { rows: records.length, sensitive: 0, protected: 0, leaks: 0, overmasks: 0, changed: 0 };
  const rows = records.map((source, index) => {
    if (!isRecord(source)) throw new TypeError(`第 ${index + 1} 条记录需要一个 JSON 对象。`);
    validateTree(source);
    const redacted = transform(source, active);
    const references = labeled ? annotations[index] : estimateReferences(source);
    const findings = [];
    for (const reference of references) {
      if (labeled) validateAnnotation(reference, source, index);
      if (reference.kind === 'sensitive') totals.sensitive++;
      else totals.protected++;
      const finding = evidence(reference, source, redacted, active.scanText);
      if (!finding) continue;
      findings.push(finding);
      if (finding.kind === 'leak') totals.leaks++;
      else totals.overmasks++;
    }
    if (!sameValue(source, redacted)) totals.changed++;
    return {
      id: `L${String(index + 1).padStart(3, '0')}`,
      service: typeof source.service === 'string' && source.service.trim() ? source.service : '未标注服务',
      source, redacted, findings,
    };
  });
  return { rows, totals, gate: { labeled, allowed: totals.leaks === 0 && totals.overmasks === 0 }, policy: active };
}

function safePath(path, source) {
  let parent = source;
  return pointerParts(path).map(part => {
    const key = normalizedKey(part);
    const known = FIELD_CATEGORIES.has(key) || TRACE_FIELDS.has(key) || DIAGNOSTIC_FIELDS.has(key) || CONTAINER_FIELDS.has(key);
    const safePart = Array.isArray(parent) && /^\d{1,6}$/.test(part) ? part : known ? key : '*';
    parent = parent !== null && typeof parent === 'object' && Object.hasOwn(parent, part) ? parent[part] : undefined;
    return safePart;
  }).reduce(asPointer, '');
}

export function createSummary(result) {
  const { rows, totals, gate, policy } = result;
  const findings = rows.flatMap(({ id, source, findings: entries }) => entries.map(finding => ({
    ...finding, id, path: gate.labeled ? finding.path : safePath(finding.path, source),
  })));
  return { totals: { ...totals }, gate: { ...gate }, policy: { ...policy }, findings };
}

export function exportJsonl(result, { confirmUnlabeled = false } = {}) {
  if (!result.gate.allowed) throw new Error('仍有漏遮或误遮，无法导出处理后的日志。');
  if (!result.gate.labeled && confirmUnlabeled !== true) throw new Error('请先确认已人工检查导入日志的脱敏结果。');
  return result.rows.map(({ redacted }) => JSON.stringify(redacted)).join('\n') + '\n';
}
