import { open, stat, unlink } from 'node:fs/promises';
import { analyze, BASELINE, CANDIDATE, createSummary, exportJsonl, MAX_INPUT_BYTES, parseJsonl } from './engine.mjs';
import { SAMPLE_ANNOTATIONS, SAMPLE_RECORDS } from './fixtures.mjs';

const HELP = `日志隐私抽检台 · 本机命令行

node cli.mjs --demo [选项]
node cli.mjs --input <日志.jsonl> [选项]

  --compare           同时输出基线和所选规则的报告
  --baseline          使用基线规则
  --no-text           关闭消息里的敏感内容识别
  --mask-trace        允许规则遮盖排障追踪字段
  --out <新文件>      通过抽检后写入脱敏 JSONL
  --confirm-reviewed  已人工复核未标注日志，允许申请导出
  --help, -h          查看帮助

标准输出为 JSON 报告。退出码 0 表示检查通过，2 表示抽检阻断或导出待复核，1 表示参数、输入或写入错误。
未标注日志的报告只覆盖规则可检查的范围。`;

const flags = new Set(['--demo', '--compare', '--baseline', '--no-text', '--mask-trace', '--confirm-reviewed']);
const pathArgs = new Set(['--input', '--out']);

class CliError extends Error {}

function parseArgs(argv) {
  const options = new Map();
  for (let index = 0; index < argv.length; index += 1) {
    const name = argv[index];
    if (options.has(name) || (!flags.has(name) && !pathArgs.has(name))) {
      throw new CliError('存在未知或重复的参数。运行 node cli.mjs --help 查看用法。');
    }
    if (flags.has(name)) {
      options.set(name, true);
      continue;
    }
    const value = argv[index + 1];
    if (!value || value.startsWith('--')) throw new CliError('输入和输出选项需要文件路径。');
    options.set(name, value);
    index += 1;
  }
  if (options.has('--demo') === options.has('--input')) {
    throw new CliError('请用 --demo 运行样例，或用 --input 指定一个本地日志文件。');
  }
  return options;
}

async function readInput(path) {
  try {
    const info = await stat(path);
    if (!info.isFile() || info.size > MAX_INPUT_BYTES) {
      throw new CliError(`请提供不超过 ${MAX_INPUT_BYTES} 字节的普通日志文件。`);
    }
    const file = await open(path, 'r');
    try {
      const bytes = Buffer.allocUnsafe(MAX_INPUT_BYTES + 1);
      let length = 0;
      while (length < bytes.length) {
        const { bytesRead } = await file.read(bytes, length, bytes.length - length, null);
        if (!bytesRead) break;
        length += bytesRead;
      }
      if (length > MAX_INPUT_BYTES) throw new CliError(`日志超过 ${MAX_INPUT_BYTES} 字节。`);
      try {
        return new TextDecoder('utf-8', { fatal: true }).decode(bytes.subarray(0, length));
      } catch {
        throw new CliError('日志文件需要使用 UTF-8 编码。');
      }
    } finally {
      await file.close();
    }
  } catch (error) {
    if (error instanceof CliError) throw error;
    throw new CliError('无法读取指定的日志文件。');
  }
}

async function writeNewFile(path, contents) {
  let file;
  try {
    file = await open(path, 'wx', 0o600);
  } catch (error) {
    if (error.code === 'EEXIST') throw new CliError('输出文件已存在，请指定一个新文件。');
    throw new CliError('无法创建输出文件。');
  }
  try {
    try {
      await file.writeFile(contents, 'utf8');
    } finally {
      await file.close();
    }
  } catch {
    await unlink(path).catch(() => {});
    throw new CliError('写入脱敏日志失败。');
  }
}

async function loadRecords(path) {
  const text = await readInput(path);
  try {
    return parseJsonl(text);
  } catch (error) {
    throw new CliError(error.message);
  }
}

async function run(argv) {
  if (argv.length === 1 && ['--help', '-h'].includes(argv[0])) {
    console.log(HELP);
    return 0;
  }
  const options = parseArgs(argv);
  const demo = options.has('--demo');
  const records = demo ? SAMPLE_RECORDS : await loadRecords(options.get('--input'));
  const annotations = demo ? SAMPLE_ANNOTATIONS : undefined;
  const policy = options.has('--baseline') ? BASELINE : {
    scanText: CANDIDATE.scanText && !options.has('--no-text'),
    preserveTrace: CANDIDATE.preserveTrace && !options.has('--mask-trace'),
  };
  const selected = analyze(records, { policy, annotations });
  const summary = createSummary(selected);
  const report = options.has('--compare')
    ? { baseline: createSummary(analyze(records, { policy: BASELINE, annotations })), selected: summary }
    : summary;
  console.log(JSON.stringify(report, null, 2));
  if (!selected.gate.allowed) return 2;

  const output = options.get('--out');
  if (!output) return 0;
  const confirmUnlabeled = options.has('--confirm-reviewed');
  if (!selected.gate.labeled && !confirmUnlabeled) {
    console.error('未标注日志需要人工复核。复核完成后可用 --confirm-reviewed 申请导出。');
    return 2;
  }
  await writeNewFile(output, exportJsonl(selected, { confirmUnlabeled }));
  return 0;
}

try {
  process.exitCode = await run(process.argv.slice(2));
} catch (error) {
  console.error(error instanceof CliError ? error.message : '无法处理日志。请检查文件格式和参数。');
  process.exitCode = 1;
}
