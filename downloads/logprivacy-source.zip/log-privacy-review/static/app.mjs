import {
  BASELINE, CANDIDATE, MAX_INPUT_BYTES, analyze, createSummary, exportJsonl, parseJsonl,
} from '../engine.mjs';
import { SAMPLE_ANNOTATIONS, SAMPLE_RECORDS } from '../fixtures.mjs';

const byId = id => document.getElementById(id);
const PAGE_SIZE = 5;
const CODE_LIMIT = 400;
const LABELS = { leak: '漏遮', overmask: '误遮', fixed: '已修正' };
const CATEGORY = { email: '邮箱', phone: '电话号码', credential: '认证凭据', trace: '链路标识', diagnostic: '排障字段' };
const POLICY_NAMES = { baseline: '基线规则', candidate: '候选规则' };
const state = {
  records: SAMPLE_RECORDS, annotations: SAMPLE_ANNOTATIONS, filename: '服务链路抽检.jsonl',
  view: new URLSearchParams(location.search).get('view') === 'baseline' ? 'baseline' : 'candidate',
  filter: 'all', page: 0, selected: '', activeFinding: 0, fullRecord: false, confirmed: false, reading: 0,
  baseline: null, candidate: null,
};

function element(tag, className, text) {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text !== undefined) node.textContent = text;
  return node;
}

function button(className, text) {
  const node = element('button', className, text);
  node.type = 'button';
  return node;
}

function selectedResult() {
  return state[state.view];
}

function getPolicy() {
  return { scanText: byId('scan-text').checked, preserveTrace: byId('preserve-trace').checked };
}

function notice(text = '', tone = 'success') {
  const node = byId('notice');
  node.dataset.tone = tone;
  node.textContent = text;
  node.hidden = !text;
}

function recalculate() {
  const options = { annotations: state.annotations };
  state.baseline = analyze(state.records, { ...options, policy: BASELINE });
  state.candidate = analyze(state.records, { ...options, policy: getPolicy() });
}

function countLabel(total) {
  return state.candidate.gate.labeled ? `${total} 条日志 · 已人工标注的演示批次` : `${total} 条日志 · 本页文件 · 规则推测`;
}

function renderSummary() {
  byId('batch-name').textContent = state.filename;
  byId('batch-info').textContent = countLabel(state.candidate.totals.rows);
  const cards = ['baseline', 'candidate'].map(type => {
    const { totals } = state[type];
    const card = button('policy-card');
    card.dataset.policy = type;
    card.setAttribute('aria-pressed', String(type === state.view));
    const title = element('span', 'policy-title', POLICY_NAMES[type]);
    const stats = element('span', 'stats');
    for (const [metric, label, tone] of [['leaks', '漏遮', 'leak'], ['overmasks', '误遮', 'overmask']]) {
      const stat = element('span', 'stat');
      const data = element('span', 'stat-data');
      data.append(element('strong', totals[metric] ? tone : 'lift', totals[metric]), document.createTextNode(label));
      stat.append(data);
      stats.append(stat);
    }
    card.append(title, stats);
    return card;
  });
  const hadFocus = document.activeElement?.classList.contains('policy-card');
  byId('policy-totals').replaceChildren(...cards);
  if (hadFocus) cards.find(card => card.dataset.policy === state.view)?.focus();
  document.querySelectorAll('.tabs [data-policy]').forEach(tab => {
    tab.setAttribute('aria-pressed', String(tab.dataset.policy === state.view));
  });
}

function renderGate() {
  const { gate, totals } = state.candidate;
  const area = byId('export-gate');
  const eligible = gate.allowed && (gate.labeled || state.confirmed);
  area.dataset.tone = !gate.allowed ? 'blocked' : eligible ? 'pass' : 'pending';
  byId('gate-title').textContent = !gate.allowed ? '候选暂缓导出' : eligible ? '候选可导出' : '候选待人工复核';
  if (!gate.allowed) {
    byId('gate-reason').textContent = `候选规则还有 ${totals.leaks} 项漏遮、${totals.overmasks} 项误遮。调整规则后可重新检查。`;
  } else if (gate.labeled) {
    byId('gate-reason').textContent = `${totals.sensitive} 项敏感值已处理，${totals.protected} 项排障字段保留。`;
  } else {
    byId('gate-reason').textContent = '导入日志缺少人工标注。逐条核对候选结果后再导出。';
  }
  byId('confirm-control').hidden = gate.labeled;
  byId('confirm-review').checked = state.confirmed;
  byId('confirm-review').disabled = !gate.allowed;
  byId('export-logs').disabled = !eligible;
  byId('export-report').disabled = false;
}

function baselineFindings(row) {
  return state.baseline.rows[Number(row.id.slice(1)) - 1].findings;
}

function resolvedFindings(row) {
  if (state.view === 'baseline') return [];
  return baselineFindings(row).filter(old => !row.findings.some(next =>
    old.kind === next.kind && old.path === next.path && old.category === next.category));
}

function status(row) {
  if (row.findings.some(finding => finding.kind === 'leak')) return { tone: 'leak', name: '仍有漏遮' };
  if (row.findings.length) return { tone: 'overmask', name: '排障字段误遮' };
  if (resolvedFindings(row).length) return { tone: 'lift', name: '风险已修正' };
  return { tone: 'clear', name: '当前未发现问题' };
}

function matchingRows(filter) {
  const { rows } = selectedResult();
  if (filter === 'all') return rows;
  if (filter === 'fixed') return rows.filter(row => resolvedFindings(row).length > 0 && !row.findings.length);
  return rows.filter(row => row.findings.some(finding => finding.kind === filter));
}

function renderFilters() {
  const filters = [['all', '全部记录'], ['leak', '存在漏遮'], ['overmask', '存在误遮'], ['fixed', '已修正']];
  const previouslyFocused = document.activeElement?.dataset.filter;
  const nodes = filters.filter(([key]) => key !== 'fixed' || state.view === 'candidate').map(([key, label]) => {
    const control = button('filter', label);
    control.dataset.filter = key;
    control.setAttribute('aria-pressed', String(state.filter === key));
    control.append(element('span', 'filter-count', matchingRows(key).length));
    return control;
  });
  byId('filters').replaceChildren(...nodes);
  if (previouslyFocused) nodes.find(node => node.dataset.filter === previouslyFocused)?.focus();
}

function preferredRow(rows) {
  return rows.find(row => row.findings.some(finding => finding.kind === 'leak'))
    || rows.find(row => resolvedFindings(row).some(finding => finding.kind === 'leak'))
    || rows[0];
}

function recordTime(row) {
  const stamp = row.source.timestamp;
  if (typeof stamp !== 'string' || !/^\d{4}-\d{2}-\d{2}T.*(?:Z|[+-]\d{2}:\d{2})$/.test(stamp)) return '';
  const instant = Date.parse(stamp);
  return Number.isFinite(instant) ? `${new Date(instant).toISOString().slice(11, 16)} UTC` : '';
}

function rowNode(row) {
  const tr = element('tr', row.id === state.selected ? 'selected' : '');
  tr.dataset.record = row.id;
  const open = button('record-open', row.id);
  open.setAttribute('aria-pressed', String(row.id === state.selected));
  open.setAttribute('aria-controls', 'record-detail');
  const reference = element('td');
  reference.append(open, element('span', 'record-time', recordTime(row)));
  const service = element('td');
  service.append(element('span', 'record-service', row.service));
  if (typeof row.source.event === 'string') service.append(element('span', 'record-event', row.source.event));
  const level = element('td');
  const name = typeof row.source.level === 'string' ? row.source.level.toUpperCase() : '—';
  const levelTag = element('span', 'record-level', name);
  levelTag.dataset.level = name;
  level.append(levelTag);
  const conclusion = element('td');
  const summary = status(row);
  const tag = element('span', 'verdict', summary.name);
  tag.dataset.tone = summary.tone;
  conclusion.append(tag);
  tr.append(reference, service, level, conclusion);
  return tr;
}

function renderRows({ choose = false } = {}) {
  const matches = matchingRows(state.filter);
  if (choose) {
    const row = preferredRow(matches);
    state.selected = row?.id ?? '';
    state.page = row ? Math.floor(matches.indexOf(row) / PAGE_SIZE) : 0;
    state.activeFinding = 0;
    state.fullRecord = false;
  }
  const first = state.page * PAGE_SIZE;
  const items = matches.slice(first, first + PAGE_SIZE);
  if (items.length > 0 && !items.some(row => row.id === state.selected)) {
    state.selected = preferredRow(items).id;
    state.activeFinding = 0;
    state.fullRecord = false;
  }
  const activeRecord = document.activeElement?.closest('[data-record]')?.dataset.record;
  const rows = items.map(rowNode);
  byId('record-list').replaceChildren(...rows);
  if (activeRecord) rows.find(row => row.dataset.record === activeRecord)?.querySelector('button')?.focus();
  byId('empty-records').hidden = items.length > 0;
  byId('pagination').hidden = matches.length <= PAGE_SIZE;
  byId('record-range').textContent = `${first + 1}–${Math.min(first + PAGE_SIZE, matches.length)} / ${matches.length} 条`;
  byId('previous-page').disabled = state.page <= 0;
  byId('next-page').disabled = first + PAGE_SIZE >= matches.length;
  renderDetail(items.find(row => row.id === state.selected));
}

const pointerSegment = segment => String(segment).replaceAll('~', '~0').replaceAll('/', '~1');

function codeModel(value) {
  const lines = [];
  const entries = new Map();
  function walk(value, path = '', key, depth = 0, comma = '') {
    const offset = '  '.repeat(depth);
    const property = key === undefined ? '' : JSON.stringify(key);
    if (value && typeof value === 'object') {
      const array = Array.isArray(value);
      const [open, close] = array ? ['[', ']'] : ['{', '}'];
      const children = Object.entries(value);
      const remainder = children.length ? open : open + close + comma;
      entries.set(path, open + close);
      lines.push({ path, offset, property, content: remainder });
      children.forEach(([child, item], index) => walk(item, `${path}/${pointerSegment(child)}`,
        array ? undefined : child, depth + 1, index === children.length - 1 ? '' : ','));
      if (children.length) lines.push({ offset, content: close + comma });
      return;
    }
    const content = JSON.stringify(value);
    entries.set(path, content);
    lines.push({ path, offset, property, content, type: typeof value === 'string' ? 'json-string' : typeof value === 'number' ? 'json-number' : 'json-literal', comma });
  }
  walk(value);
  return { lines, entries };
}

function changedPaths(before, after) {
  const paths = new Set([...before.entries.keys(), ...after.entries.keys()]);
  return [...paths].filter(path => before.entries.get(path) !== after.entries.get(path) && path !== '');
}

function renderCode(container, model, other, focus) {
  const truncated = !state.fullRecord && model.lines.length > CODE_LIMIT;
  const match = model.lines.findIndex(line => line.path === focus);
  const start = truncated && match >= CODE_LIMIT ? Math.max(0, match - 4) : 0;
  const visible = truncated ? model.lines.slice(start, start + CODE_LIMIT) : model.lines;
  const lines = visible.map((line, index) => {
    const item = element('div', 'code-line');
    if (line.path && model.entries.get(line.path) !== other.entries.get(line.path)) item.classList.add('changed', 'marked');
    if (focus && line.path === focus) item.classList.add('selected');
    const indent = element('span', 'line-number', start + index + 1);
    indent.setAttribute('aria-hidden', 'true');
    const content = element('span', '', line.offset);
    if (line.property) content.append(element('span', 'json-key', line.property), document.createTextNode(': '));
    content.append(element('span', line.type, line.content));
    if (line.comma) content.append(document.createTextNode(line.comma));
    item.append(indent, content);
    return item;
  });
  if (truncated) lines.push(element('div', 'truncation', `该记录共有 ${model.lines.length} 行，此处截取字段附近的内容。`));
  container.replaceChildren(...lines);
  container.scrollTop = 0;
  const selected = container.querySelector('.selected');
  container.scrollTop = selected ? Math.max(0, selected.getBoundingClientRect().top - container.getBoundingClientRect().top - 37) : 0;
}

function renderDetail(row) {
  byId('record-detail').hidden = !row;
  if (!row) return;
  byId('detail-identity').textContent = `${row.id} · ${row.service}`;
  byId('detail-rule').textContent = POLICY_NAMES[state.view];
  const before = codeModel(row.source);
  const after = codeModel(row.redacted);
  const expand = byId('show-full-record');
  expand.hidden = before.lines.length <= CODE_LIMIT && after.lines.length <= CODE_LIMIT;
  expand.setAttribute('aria-pressed', String(state.fullRecord));
  expand.textContent = state.fullRecord ? '收起完整记录' : '显示完整记录';
  const changes = changedPaths(before, after);
  const leakFirst = (left, right) => Number(right.kind === 'leak') - Number(left.kind === 'leak');
  const evidence = [
    ...[...row.findings].sort(leakFirst),
    ...resolvedFindings(row).sort(leakFirst).map(finding => ({ ...finding, kind: 'fixed' })),
  ];
  if (evidence.length === 0) {
    for (const path of changes.slice(0, 10)) evidence.push({ kind: 'changed', path, reason: '这一字段被当前规则修改。' });
  }
  const current = evidence[state.activeFinding] || evidence[0];
  const focusPath = current?.path || '';
  const nodes = evidence.map((finding, index) => {
    const heading = [LABELS[finding.kind], CATEGORY[finding.category]].filter(Boolean).join(' · ') || '已脱敏';
    const chip = button('finding', heading);
    chip.dataset.finding = String(index);
    chip.dataset.tone = finding.kind === 'fixed' || finding.kind === 'changed' ? 'lift' : finding.kind;
    chip.setAttribute('aria-pressed', String(finding === current));
    chip.append(document.createTextNode(' '), element('code', '', finding.path));
    chip.addEventListener('click', () => {
      state.activeFinding = index;
      renderDetail(row);
      byId('finding-list').querySelector(`[data-finding="${index}"]`)?.focus();
    });
    return chip;
  });
  let explanation = current?.reason || '当前规则没有修改这条记录。';
  if (current?.kind === 'fixed') {
    explanation = current.category === 'trace' ? '候选规则已保留链路标识，可用于排障。' : '候选规则已遮蔽基线漏过的敏感值。';
  }
  nodes.push(element('p', 'evidence-note', explanation));
  byId('finding-list').replaceChildren(...nodes);
  renderCode(byId('original-log'), before, after, focusPath);
  renderCode(byId('transformed-log'), after, before, focusPath);
}

function render(choose = false) {
  renderSummary();
  renderGate();
  renderFilters();
  renderRows({ choose });
}

function viewPolicy(event) {
  const tab = event.target.closest('[data-policy]');
  if (!tab || tab.dataset.policy === state.view) return;
  state.view = tab.dataset.policy;
  state.filter = 'all';
  render(true);
}

function setOptions(policy) {
  byId('scan-text').checked = policy.scanText;
  byId('preserve-trace').checked = policy.preserveTrace;
}

function loadDataset(records, annotations, filename) {
  state.records = records;
  state.annotations = annotations;
  state.filename = filename;
  state.confirmed = false;
  state.view = 'candidate';
  state.filter = 'all';
  setOptions(CANDIDATE);
  recalculate();
  render(true);
}

function resetDemo() {
  state.reading += 1;
  loadDataset(SAMPLE_RECORDS, SAMPLE_ANNOTATIONS, '服务链路抽检.jsonl');
  notice('已重新载入演示批次。');
}

async function importFile() {
  const input = byId('file-input');
  const file = input.files[0];
  input.value = '';
  if (!file) return;
  const reading = ++state.reading;
  try {
    if (file.size > MAX_INPUT_BYTES) throw new Error('请选取不超过 1 MiB 的 JSONL 文件。');
    const buffer = await file.arrayBuffer();
    if (reading !== state.reading) return;
    let contents;
    try {
      contents = new TextDecoder('utf-8', { fatal: true }).decode(buffer);
    } catch {
      throw new Error('文件需要使用 UTF-8 编码。');
    }
    const records = parseJsonl(contents);
    loadDataset(records, undefined, file.name);
    notice('日志已在当前页面读取。');
  } catch (error) {
    if (reading === state.reading) notice(error.message || '读取日志时发生错误。', 'warning');
  }
}

function download(contents, type, name) {
  const url = URL.createObjectURL(new Blob([contents], { type }));
  const link = element('a');
  link.href = url;
  link.download = name;
  document.body.append(link);
  link.click();
  link.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1_000);
}

function downloadLogs() {
  try {
    const logs = exportJsonl(state.candidate, { confirmUnlabeled: state.confirmed });
    download(logs, 'application/x-ndjson;charset=utf-8', '脱敏结果.jsonl');
    notice('已生成候选规则处理后的日志。');
  } catch (error) {
    notice(error.message, 'warning');
  }
}

function downloadReport() {
  const report = {
    baseline: createSummary(state.baseline), candidate: createSummary(state.candidate),
    reviewConfirmed: state.confirmed,
  };
  download(`${JSON.stringify(report, null, 2)}\n`, 'application/json;charset=utf-8', '日志脱敏抽检报告.json');
  notice('已生成抽检报告，仅含规则、计数和字段位置。');
}

byId('policy-totals').addEventListener('click', viewPolicy);
document.querySelector('.tabs').addEventListener('click', viewPolicy);
byId('filters').addEventListener('click', event => {
  const control = event.target.closest('[data-filter]');
  if (!control) return;
  state.filter = control.dataset.filter;
  renderFilters();
  renderRows({ choose: true });
});
byId('record-list').addEventListener('click', event => {
  const target = event.target.closest('[data-record]');
  if (!target) return;
  state.selected = target.dataset.record;
  state.activeFinding = 0;
  state.fullRecord = false;
  renderRows();
});
byId('show-full-record').addEventListener('click', () => {
  state.fullRecord = !state.fullRecord;
  renderDetail(selectedResult().rows.find(row => row.id === state.selected));
});
byId('previous-page').addEventListener('click', () => { state.page -= 1; renderRows(); });
byId('next-page').addEventListener('click', () => { state.page += 1; renderRows(); });

function rulesChanged() {
  state.confirmed = false;
  state.view = 'candidate';
  state.filter = 'all';
  state.candidate = analyze(state.records, { annotations: state.annotations, policy: getPolicy() });
  notice();
  render(true);
}

byId('scan-text').addEventListener('change', rulesChanged);
byId('preserve-trace').addEventListener('change', rulesChanged);
byId('confirm-review').addEventListener('change', event => { state.confirmed = event.target.checked; renderGate(); });
byId('reset-demo').addEventListener('click', resetDemo);
byId('import-file').addEventListener('click', () => byId('file-input').click());
byId('file-input').addEventListener('change', importFile);
byId('export-logs').addEventListener('click', downloadLogs);
byId('export-report').addEventListener('click', downloadReport);

setOptions(CANDIDATE);
recalculate();
render(true);
