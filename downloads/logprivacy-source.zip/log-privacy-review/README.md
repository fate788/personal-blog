# 日志隐私抽检台

给维护采集规则的开发和运维人员复核日志脱敏。用同一批 JSONL 复跑两套规则，逐行核对遗漏的敏感字段及受影响的排障字段，再导出脱敏结果和仅含统计的审查报告。

[打开体验](https://fate788.github.io/personal-blog/demos/logprivacy/index.html?v=1.0) · [作品说明](https://fate788.github.io/personal-blog/projects/logprivacy/index.html)

![抽检台实屏](docs/preview.webp)

## 体验流程

1. 打开 12 行合成日志，切换基线与候选规则，查看同一条记录中的原始值、变更后值和判定依据。
2. 在候选规则关闭正文扫描或关闭保留追踪 ID，查看导出状态和受影响的行。
3. 恢复候选规则，下载脱敏 JSONL 和审查报告。导入文件时，每个非空行应是一个 JSON 对象，单批最多 2,000 行及 1 MiB。较长的数字标识请用字符串保存。导入批次依据预设字段和模式抽检，需要人工确认后才能导出日志。

公开体验在当前浏览器内存中处理，刷新会清空导入和复核状态。打包版本通过内容安全策略禁止网络连接。审查报告仅列统计、规则参数、位置和发现类型。

## 在本机复跑

需要 Node.js 22 或更新版本，无额外依赖。

```sh
npm test
npm run build
npm run review
node cli.mjs --demo --baseline
node cli.mjs --input ./events.jsonl --out ./redacted.jsonl --confirm-reviewed
```

构建产物为 `dist/index.html`，可双击离线使用。CLI 退出码 `0` 表示通过，`1` 表示输入或文件错误，`2` 表示抽检阻断或待确认。输出文件须使用新路径。`--compare` 会把基线和所选规则的统计放在同一份报告。`--no-text` 和 `--mask-trace` 可单独关闭对应候选项。

## 抽检口径

合成批次含逐项标注，分别核对敏感值和应保留的诊断字段。导入批次的发现取决于内置字段和文本模式，导出仅表示当前抽检通过。可先从源头控制记录字段，再用本工具回归验证规则。设计参考 [OWASP 日志指南](https://cheatsheetseries.owasp.org/cheatsheets/Logging_Cheat_Sheet.html#data-to-exclude) 与 [OpenTelemetry 敏感数据处理](https://opentelemetry.io/docs/security/handling-sensitive-data/)。
