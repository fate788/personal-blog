import assert from 'node:assert/strict';
import { spawnSync } from 'node:child_process';
import { existsSync } from 'node:fs';
import { mkdtemp, readdir, readFile, rmdir, unlink, writeFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { test } from 'node:test';
import { fileURLToPath } from 'node:url';
import { MAX_INPUT_BYTES } from '../engine.mjs';

const cli = fileURLToPath(new URL('../cli.mjs', import.meta.url));
const originalContact = 'june-upload@review-fixture.example';
const row = {
  timestamp: '2026-11-20T04:00:02.000Z', service: 'test-notifier', level: 'INFO',
  trace_id: 'bf1622c5f0fab0bded98b741b8e8b8bb', email: originalContact,
};
const input = JSON.stringify(row) + '\n';

function invoke(...args) {
  const result = spawnSync(process.execPath, [cli, ...args], { encoding: 'utf8' });
  assert.ifError(result.error);
  assert.ok(!result.signal, result.signal);
  return result;
}

async function runInTemp(t, callback) {
  const folder = await mkdtemp(join(tmpdir(), 'log-review-cli-'));
  t.after(async () => {
    for (const file of await readdir(folder)) await unlink(join(folder, file));
    await rmdir(folder);
  });
  return callback(folder);
}

test('demo comparison emits metadata with an allowed candidate and a blocked baseline', () => {
  const result = invoke('--demo', '--compare');
  assert.equal(result.status, 0, result.stderr);
  const { baseline, selected } = JSON.parse(result.stdout);
  assert.deepEqual(baseline.policy, { scanText: false, preserveTrace: false });
  assert.deepEqual(selected.policy, { scanText: true, preserveTrace: true });
  assert.equal(baseline.gate.allowed, false);
  assert.equal(selected.gate.allowed, true);
  assert.ok(baseline.totals.leaks > 0 && baseline.totals.overmasks > 0);
  assert.equal(selected.totals.leaks + selected.totals.overmasks, 0);
  for (const flag of ['--baseline', '--no-text', '--mask-trace']) {
    const gated = invoke('--demo', flag);
    assert.equal(gated.status, 2, gated.stderr);
    assert.equal(JSON.parse(gated.stdout).gate.allowed, false);
  }
});

test('blocked demo cannot create an output file', async t => runInTemp(t, async folder => {
  const out = join(folder, 'should-not-exist.jsonl');
  const result = invoke('--demo', '--baseline', '--out', out);
  assert.equal(result.status, 2, result.stderr);
  assert.equal(existsSync(out), false);
}));

test('an imported file requires confirmation and exports only transformed data', async t => runInTemp(t, async folder => {
  const source = join(folder, 'test input.jsonl');
  const out = join(folder, 'scrubbed output.jsonl');
  await writeFile(source, input, 'utf8');

  const pending = invoke('--input', source, '--out', out);
  assert.equal(pending.status, 2);
  assert.match(pending.stderr, /人工复核/);
  assert.equal(JSON.parse(pending.stdout).gate.labeled, false);
  assert.equal(existsSync(out), false);

  const ready = invoke('--input', source, '--out', out, '--confirm-reviewed');
  assert.equal(ready.status, 0, ready.stderr);
  const report = JSON.parse(ready.stdout);
  assert.equal(report.gate.labeled, false);
  assert.equal(report.totals.rows, 1);
  assert.ok(!ready.stdout.includes(originalContact));
  assert.ok(!ready.stdout.includes(row.trace_id));
  const output = await readFile(out, 'utf8');
  assert.doesNotMatch(output, /june-upload/);
  assert.equal(JSON.parse(output).trace_id, row.trace_id);
  assert.equal(await readFile(source, 'utf8'), input);
}));

test('CLI preserves existing files and keeps malformed input out of output', async t => runInTemp(t, async folder => {
  const source = join(folder, 'events.jsonl');
  await writeFile(source, input, 'utf8');
  const sameFile = invoke('--input', source, '--out', source, '--confirm-reviewed');
  assert.equal(sameFile.status, 1);
  assert.match(sameFile.stderr, /已存在/);
  assert.equal(await readFile(source, 'utf8'), input);

  const bad = join(folder, 'malformed.jsonl');
  const marker = 'INPUT_ROW_SHOULD_NOT_APPEAR';
  await writeFile(bad, `${input}{"email":"${marker}"`, 'utf8');
  const invalid = invoke('--input', bad, '--out', join(folder, 'should-not-exist.jsonl'), '--confirm-reviewed');
  assert.equal(invalid.status, 1);
  assert.equal(invalid.stdout, '');
  assert.ok(!invalid.stderr.includes(marker));
  assert.match(invalid.stderr, /2/);
  assert.equal(existsSync(join(folder, 'should-not-exist.jsonl')), false);
}));

test('CLI rejects oversized, invalid UTF-8 and unsupported arguments without reading rows', async t => runInTemp(t, async folder => {
  const tooLarge = join(folder, 'too-large.jsonl');
  await writeFile(tooLarge, Buffer.alloc(MAX_INPUT_BYTES + 1, 65));
  const oversized = invoke('--input', tooLarge);
  assert.equal(oversized.status, 1);
  assert.equal(oversized.stdout, '');
  assert.match(oversized.stderr, /字节/);

  const badEncoding = join(folder, 'invalid-utf8.jsonl');
  await writeFile(badEncoding, Buffer.from([0xfe, 0xff]));
  const invalid = invoke('--input', badEncoding);
  assert.equal(invalid.status, 1);
  assert.equal(invalid.stdout, '');
  assert.match(invalid.stderr, /UTF-8/);
  assert.equal(invoke('--demo', '--input', badEncoding).status, 1);
  assert.equal(invoke('--demo', '--unknown').status, 1);
  assert.match(invoke('--help').stdout, /--confirm-reviewed/);
}));
