import assert from 'node:assert/strict';
import { test } from 'node:test';
import { BASELINE, CANDIDATE, MAX_INPUT_BYTES, MAX_ROWS, analyze, createSummary, exportJsonl, parseJsonl } from '../engine.mjs';
import { SAMPLE_ANNOTATIONS, SAMPLE_RECORDS } from '../fixtures.mjs';

const sample = policy => analyze(SAMPLE_RECORDS, { policy, annotations: SAMPLE_ANNOTATIONS });

test('fixed annotations verify both misses and lost trace context in the baseline', () => {
  const result = sample(BASELINE);
  assert.deepEqual(result.totals, { rows: 12, sensitive: 9, protected: 25, leaks: 3, overmasks: 13, changed: 12 });
  assert.deepEqual(result.gate, { allowed: false, labeled: true });
  const findings = createSummary(result).findings;
  assert.deepEqual(findings.filter(item => item.kind === 'leak').map(({ id, path }) => [id, path]), [
    ['L002', '/message'], ['L004', '/message'], ['L009', '/message'],
  ]);
  assert.ok(findings.some(item => item.id === 'L008' && item.path === '/attributes/request_id'));
  assert.throws(() => exportJsonl(result), /无法导出/);
});

test('two rule switches independently control free-text misses and trace overmasking', () => {
  const retainedTrace = sample({ scanText: false, preserveTrace: true }).totals;
  assert.equal(retainedTrace.leaks, 3);
  assert.equal(retainedTrace.overmasks, 0);
  const inspectedText = sample({ scanText: true, preserveTrace: false }).totals;
  assert.equal(inspectedText.leaks, 0);
  assert.equal(inspectedText.overmasks, 13);
});

test('candidate exports only transformed rows in original order with context preserved', () => {
  const original = structuredClone(SAMPLE_RECORDS);
  const result = sample(CANDIDATE);
  assert.deepEqual(result.totals, { rows: 12, sensitive: 9, protected: 25, leaks: 0, overmasks: 0, changed: 9 });
  assert.deepEqual(result.gate, { allowed: true, labeled: true });
  const exported = exportJsonl(result);
  const rows = parseJsonl(exported);
  assert.deepEqual(rows.map(({ trace_id, event }) => [trace_id, event]), original.map(({ trace_id, event }) => [trace_id, event]));
  assert.deepEqual(SAMPLE_RECORDS, original);
  assert.equal(rows[1].message, '由供应商暂存，计划重发给 [邮箱已遮蔽]。');
  assert.equal(rows[3].message, '承运商将回拨 [电话已遮蔽] 确认交付。');
  assert.equal(rows[4].delivery.contacts[0].phone, '[电话已遮蔽]');
  assert.equal(rows[5].http.status, 504);
  assert.equal(rows[7].attributes.request_id, 'DEMO-REQUEST-0048');
  assert.doesNotMatch(exported, /@.*\.example|202-555-|DEMO_ONLY_DO_NOT_USE/);
});

test('unlabeled imports require explicit review and summaries avoid arbitrary key names and values', () => {
  const records = parseJsonl('\uFEFF\r\n{"attributes":{"sample-private-object":{"502851":[{"message":"联系 a@b.example。"}]}}}\n');
  const baseline = analyze(records, { policy: BASELINE });
  assert.equal(baseline.totals.leaks, 1);
  assert.equal(baseline.rows[0].findings[0].path, '/attributes/sample-private-object/502851/0/message');
  assert.equal(createSummary(baseline).findings[0].path, '/attributes/*/*/0/message');
  assert.doesNotMatch(JSON.stringify(createSummary(baseline)), /a@b|sample-private-object|502851/);
  assert.throws(() => exportJsonl(baseline, { confirmUnlabeled: true }), /无法导出/);

  const candidate = analyze(records);
  assert.deepEqual(candidate.gate, { allowed: true, labeled: false });
  assert.throws(() => exportJsonl(candidate), /人工检查/);
  assert.doesNotMatch(exportJsonl(candidate, { confirmUnlabeled: true }), /a@b/);
});

test('canonical trace IDs stay readable and supported private values in keys block export', () => {
  const trace = 'a'.repeat(10) + '13700138000' + 'b'.repeat(11);
  const safe = analyze([{ trace_id: trace }]);
  assert.equal(safe.rows[0].redacted.trace_id, trace);
  assert.equal(safe.totals.sensitive, 0);

  const input = parseJsonl('{"attributes":{"test@reserved.example":"invalid attribute name"},"trace_id":"alias@reserved.example"}');
  const result = analyze(input);
  assert.equal(result.totals.sensitive, 2);
  assert.equal(result.totals.leaks, 1);
  assert.equal(result.totals.overmasks, 1);
  assert.ok(result.rows[0].findings.some(({ kind, path }) => kind === 'leak' && path === '/attributes/[敏感键]'));
  assert.doesNotMatch(JSON.stringify(createSummary(result)), /reserved\.example/);
  assert.throws(() => exportJsonl(result, { confirmUnlabeled: true }), /无法导出/);
});

test('parser rejects malformed or oversized data without echoing source and protects numeric identifiers', () => {
  assert.throws(() => parseJsonl('\n{"password":"demo-sensitive-value"'), error => {
    assert.equal(error.message, '第 2 行：无法解析 JSON。');
    return true;
  });
  assert.throws(() => parseJsonl('\n[1,2]'), /第 2 行.*JSON 对象/);
  assert.throws(() => parseJsonl('\n{"order_id":9007199254740993}'), /第 2 行.*安全精度/);
  assert.throws(() => parseJsonl('{"value":1e999}'), /无效的 JSON 值/);
  assert.throws(() => parseJsonl('\n\n'), /未找到日志记录/);
  assert.throws(() => parseJsonl('界'.repeat(1 + Math.floor(MAX_INPUT_BYTES / 3))), /1 MiB/);
  assert.throws(() => parseJsonl('{}\n'.repeat(MAX_ROWS + 1)), /最多处理 2000/);
  assert.throws(() => parseJsonl('{"field":' + '['.repeat(25) + '0' + ']'.repeat(25) + '}'), /字段嵌套/);
  assert.equal(parseJsonl('{"order_id":"9007199254740993"}')[0].order_id, '9007199254740993');
});

test('large plain strings do not cause repeated address-range scans', () => {
  const message = 'x'.repeat(MAX_INPUT_BYTES - 32);
  const result = analyze(parseJsonl(JSON.stringify({ message })));
  assert.equal(result.rows[0].redacted.message, message);
  assert.equal(result.totals.changed, 0);
});

test('prototype-named fields remain ordinary JSON properties', () => {
  const records = parseJsonl('{"__proto__":{"tokenState":"example"},"constructor":{"email":"a@b.example"}}');
  const result = analyze(records);
  const output = result.rows[0].redacted;
  assert.equal(Object.getPrototypeOf(output), Object.prototype);
  assert.equal(output.__proto__.tokenState, 'example');
  assert.equal(output.constructor.email, '[邮箱已遮蔽]');
  assert.equal({}.tokenState, undefined);
});

test('mismatched or invalid annotations cannot make a row look eligible', () => {
  const records = [{ message: 'fixture contact a@b.example' }];
  assert.throws(() => analyze(records, { annotations: [] }), /标注批次/);
  assert.throws(() => analyze(records, { annotations: [[{ kind: 'sensitive', category: 'email', path: '/missing' }]] }), /无效标注/);
  assert.throws(() => analyze(records, { annotations: [[{ kind: 'sensitive', category: 'email', path: '/message', literal: 'unrelated' }]] }), /无效标注/);
});
