// A literal title/brand/SKU baseline and a lexical candidate with explicit expansion.
export const synonymRules = [
  ["显示器挂灯", "屏幕挂灯"],
  ["理线器", "收线夹", "理线夹", "走线夹"],
  ["排插", "插线板", "电源排插"],
  ["鼠标垫", "桌垫", "桌面保护垫"],
  ["增高架", "抬高架", "升高架"],
  ["笔记本支架", "电脑支架"],
  ["免打孔", "不用打孔", "无需打孔"],
  ["台灯", "桌面灯"],
  ["低蓝光", "护眼"],
  ["静音", "低噪", "静音轴"],
  ["usb-c", "type-c", "usbc", "c口"],
  ["扩展坞", "转接坞", "hub", "分线器"],
];

const expansions = new Map(synonymRules.flatMap(rule =>
  rule.map(term => [term, rule.filter(other => term !== other)])
));
const filler = new Set([
  "有没有", "可以", "适合", "想找", "想要", "需要", "推荐", "一个", "买个", "请问", "能", "的", "用", "和", "给", "要", "找", "下",
]);
const vocabulary = [...new Set([
  ...expansions.keys(), ...filler,
  "机械键盘", "数字键盘", "键盘", "蓝牙", "鼠标", "有线", "无线", "人体工学", "氮化镓", "双口", "三口", "单口", "充电器", "充电头", "充电线",
  "无线充电", "磁吸", "充电", "大桌面", "桌面", "落地灯", "阅读灯", "低亮度", "夜间", "床头", "照明", "宿舍", "暖光", "番茄钟",
  "编织", "快充", "数据线", "收纳", "显示器", "带出门", "轻便", "租房", "理线", "折叠", "低延迟", "夹装", "桌下", "调光", "无级调光",
  "一进两出", "一进一出", "额外按键", "快捷键", "数字区", "键屿", "桌序", "晴间", "伏线", "序光",
])].sort((left, right) => right.length - left.length);

function normalize(text) {
  return typeof text === "string"
    ? text.normalize("NFKC").toLowerCase().replace(/[‐‑−–—]/gu, "-")
      .replace(/[^\p{L}\p{N}.\-\s]+/gu, " ").trim().replace(/\s+/gu, " ")
    : "";
}

function tokenize(query) {
  const terms = new Set();
  for (const part of query.split(" ")) {
    let cursor = 0;
    let unknown = "";
    while (cursor < part.length) {
      const known = vocabulary.find(word => part.startsWith(word, cursor));
      const latin = known ? null : /^[a-z0-9]+(?:[.\-][a-z0-9]+)*/u.exec(part.slice(cursor))?.[0];
      const word = known || latin;
      if (!word) {
        unknown += part[cursor];
        cursor++;
        continue;
      }
      if (unknown) terms.add(unknown);
      if (!filler.has(word)) terms.add(word);
      unknown = "";
      cursor += word.length;
    }
    if (unknown) terms.add(unknown);
  }
  return [...terms];
}

function hasTerm(text, term) {
  if (!/^[a-z0-9][a-z0-9.\-]*$/u.test(term)) return text.includes(term);
  // A numeric spec or model is a whole token: 5W does not match 15W, and K7 does not match K75.
  const marker = term.replace(/[.*+?^${}()|[\]\\]/gu, "\\$&");
  return new RegExp(`(?:^|[^a-z0-9])${marker}(?:$|[^a-z0-9])`, "u").test(text);
}

function fieldsFor(product) {
  const name = normalize(product.name);
  const brand = normalize(product.brand);
  const sku = normalize(product.sku);
  return {
    name, brand, sku,
    words: [[name, 8], [brand, 6], [sku, 9],
      ...product.attributes.map(text => [normalize(text), 5]), [normalize(product.summary), 2]],
    aliases: product.aliases.map(normalize).filter(Boolean),
  };
}

function fieldMatch(words, term) {
  let best = 0;
  for (const [text, weight] of words) {
    if (weight > best && hasTerm(text, term)) best = weight;
  }
  return best;
}

function literal(fields, query) {
  if (fields.sku === query) return {score: 100, matched: [query], expanded: []};
  const score = fields.name === query ? 24 : hasTerm(fields.name, query) ? 16 :
    fields.brand === query ? 13 : hasTerm(fields.brand, query) ? 9 : hasTerm(fields.sku, query) ? 8 : 0;
  return score ? {score, matched: [query], expanded: []} : null;
}

function oneTerm(product, fields, term, expandAliases) {
  const direct = fieldMatch(fields.words, term);
  if (direct) return {weight: direct, term};
  if (!expandAliases) return null;
  if (fields.aliases.some(alias => hasTerm(alias, term))) {
    return {weight: 4, term, via: product.name, source: "catalog"};
  }
  let best = null;
  for (const candidate of expansions.get(term) || []) {
    const weight = fieldMatch(fields.words, candidate) * 0.65;
    if (weight > (best?.weight ?? 0)) best = {weight, term, via: candidate, source: "synonym"};
  }
  return best;
}

function candidate(product, fields, query, terms, expandAliases) {
  // Do not extract digits from a natural-language query and mistake them for a SKU.
  if (/^[a-z0-9-]+$/u.test(query) && fields.sku.replaceAll("-", "") === query.replaceAll("-", "")) {
    return {score: 100, matched: [query], expanded: []};
  }
  const exact = literal(fields, query);
  const matches = terms.map(term => oneTerm(product, fields, term, expandAliases)).filter(Boolean);
  const enoughTerms = terms.length > 0 && matches.length >= Math.ceil(terms.length * 0.60);
  const exactAlias = expandAliases && fields.aliases.includes(query);
  if (!exact && !enoughTerms && !exactAlias) return null;
  const score = matches.reduce((sum, match) => sum + match.weight, exact?.score ?? 0) +
    (terms.length ? (matches.length / terms.length) * 10 : 0) + (exactAlias ? 3 : 0);
  const matched = matches.filter(match => !match.source).map(match => match.term);
  const expanded = matches.filter(match => match.source).map(({term, via, source}) => ({term, via, source}));
  if (exact && !matched.length) matched.push(query);
  if (exactAlias && !expanded.length && !matched.length) expanded.push({term: query, via: product.name, source: "catalog"});
  return {score, matched, expanded};
}

function byRelevance(left, right) {
  return right.score - left.score || Number(right.product.inStock) - Number(left.product.inStock) ||
    left.product.sku.localeCompare(right.product.sku, "en") || left.id.localeCompare(right.id, "en");
}

export function search(products, query, options = {}) {
  const strategy = options.strategy === "baseline" ? "baseline" : "candidate";
  const prepared = normalize(query);
  const useCandidate = strategy === "candidate";
  const terms = useCandidate ? tokenize(prepared) : [];
  const max = options.priceMax === "" || options.priceMax == null ? Infinity : Number(options.priceMax);
  const limit = Number.isSafeInteger(options.limit) && options.limit >= 0 ? options.limit : 24;
  const matches = [];

  for (const product of products) {
    if ((options.category && options.category !== product.category) ||
      (options.inStock === true && !product.inStock) || product.price > max) continue;
    if (!prepared) {
      matches.push({id: product.id, product, score: 0, matched: [], expanded: []});
      continue;
    }
    const fields = fieldsFor(product);
    const result = useCandidate
      ? candidate(product, fields, prepared, terms, options.expandAliases !== false)
      : literal(fields, prepared);
    if (result) matches.push({id: product.id, product, ...result});
  }
  const direction = options.sort === "price-asc" ? 1 : options.sort === "price-desc" ? -1 : 0;
  matches.sort((left, right) => direction * (left.product.price - right.product.price) || byRelevance(left, right));
  return {query: typeof query === "string" ? query.trim() : "", strategy, total: matches.length,
    hits: matches.slice(0, limit).map((hit, index) => ({...hit, rank: index + 1}))};
}

function discountedGains(grades) {
  return grades.reduce((total, grade, index) => total + (2 ** grade - 1) / Math.log2(index + 2), 0);
}

function scoreRanking(ranking, relevant, ideal) {
  const hits = ranking.hits.map(hit => ({...hit, grade: Object.hasOwn(relevant, hit.id) ? relevant[hit.id] : 0}));
  const firstRelevant = hits.findIndex(hit => hit.grade > 0);
  const falsePositives = hits.filter(hit => hit.grade === 0).length;
  return {hits, total: ranking.total, ndcg: ideal ? discountedGains(hits.map(hit => hit.grade)) / ideal : null,
    reciprocalRank: ideal ? (firstRelevant < 0 ? 0 : 1 / (firstRelevant + 1)) : null,
    falsePositives, relevantShare: hits.length ? (hits.length - falsePositives) / hits.length : null};
}

function aggregate(cases, strategy) {
  const summaries = cases.map(result => result[strategy]);
  const judged = summaries.filter(result => result.ndcg != null);
  const mean = field => judged.length ? judged.reduce((sum, result) => sum + result[field], 0) / judged.length : null;
  return {ndcg: mean("ndcg"), mrr: mean("reciprocalRank"), zeroResults: summaries.filter(result => result.total === 0).length,
    unexpectedResults: summaries.filter(result => result.ndcg == null && result.total > 0).length};
}

export function evaluate(products, benchmark, options = {}) {
  const k = Number.isSafeInteger(options.k) && options.k > 0 ? options.k : 5;
  const cases = benchmark.map(item => {
    const ideal = discountedGains(Object.values(item.relevant).sort((left, right) => right - left).slice(0, k));
    const baseline = scoreRanking(search(products, item.query, {strategy: "baseline", limit: k}), item.relevant, ideal);
    const candidate = scoreRanking(search(products, item.query, {
      strategy: "candidate", limit: k, expandAliases: options.expandAliases,
    }), item.relevant, ideal);
    const deltaNdcg = ideal ? candidate.ndcg - baseline.ndcg : null;
    const outcome = !ideal ? "unjudged" : Math.abs(deltaNdcg) <= 1e-10 ? "unchanged" : deltaNdcg > 0 ? "improved" : "declined";
    // Even if the first relevant result stays first, newly retrieved distractors can reduce result precision.
    const moreUnrelated = candidate.falsePositives > baseline.falsePositives;
    const baseIds = baseline.hits.map(hit => hit.id);
    const nextIds = candidate.hits.map(hit => hit.id);
    return {...item, baseline, candidate, deltaNdcg, outcome, moreUnrelated,
      added: nextIds.filter(id => !baseIds.includes(id)), dropped: baseIds.filter(id => !nextIds.includes(id))};
  });
  const count = outcome => cases.filter(item => item.outcome === outcome).length;
  return {k, totals: {queries: cases.length, judged: cases.length - count("unjudged"),
    baseline: aggregate(cases, "baseline"), candidate: aggregate(cases, "candidate"),
    improved: count("improved"), declined: count("declined"), unchanged: count("unchanged"),
    moreUnrelated: cases.filter(item => item.moreUnrelated).length}, cases};
}
