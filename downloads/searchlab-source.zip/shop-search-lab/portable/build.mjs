import { cp, mkdir, readFile, writeFile } from "node:fs/promises";
import { dirname, resolve } from "node:path";

const output = resolve(process.argv[2] || "dist/index.html");
const read = (path) => readFile(new URL(path, import.meta.url), "utf8");
const moduleUrl = (code) => "data:text/javascript;base64," + Buffer.from(code.replaceAll("\r\n", "\n")).toString("base64");
const [catalog, engine, merchandising, bag, bagView, suggestions, app, stylesheet, html] = await Promise.all([
  read("../catalog.mjs"), read("../engine.mjs"), read("../static/merchandising.mjs"),
  read("../static/shopping-bag.mjs"), read("../static/bag-view.mjs"), read("../static/search-suggestions.mjs"),
  read("../static/app.mjs"), read("../static/styles.css"), read("../static/index.html")
]);

function inlineImport(code, pathname, destination) {
  return code.replaceAll(`"${pathname}"`, `"${destination}"`).replaceAll(`'${pathname}'`, `'${destination}'`);
}

const catalogUrl = moduleUrl(catalog);
const engineUrl = moduleUrl(inlineImport(engine, "./catalog.mjs", catalogUrl));
const bagUrl = moduleUrl(bag);
const appModules = [
  ["../catalog.mjs", catalogUrl],
  ["../engine.mjs", engineUrl],
  ["./merchandising.mjs", moduleUrl(merchandising)],
  ["./shopping-bag.mjs", bagUrl],
  ["./bag-view.mjs", moduleUrl(bagView)],
  ["./search-suggestions.mjs", moduleUrl(suggestions)]
];
const appUrl = moduleUrl(appModules.reduce((code, [path, url]) => inlineImport(code, path, url), app));
const styles = /<link\b[^>]*href=["'](?:\.\/)?styles\.css["'][^>]*>/iu;
const script = /<script\b[^>]*src=["'](?:\.\/)?app\.mjs["'][^>]*>\s*<\/script>/iu;
const policy = "default-src 'none'; style-src 'unsafe-inline'; script-src data:; img-src 'self' data:; connect-src 'none'; base-uri 'none'; form-action 'none'";
if (!styles.test(html) || !script.test(html)) throw new Error("缺少前端入口。");
const portable = html.replace("<head>", `<head>\n  <meta http-equiv="Content-Security-Policy" content="${policy}">`)
  .replace(styles, () => `<style>\n${stylesheet}\n</style>`)
  .replace(script, () => `<script type="module" src="${appUrl}"></script>`);

await mkdir(dirname(output), { recursive: true });
await cp(new URL("../static/media/", import.meta.url), resolve(dirname(output), "media"), { recursive: true });
await writeFile(output, portable.replaceAll("\r\n", "\n"), "utf8");
console.log("已生成便携式商品搜索实验台 " + output);
