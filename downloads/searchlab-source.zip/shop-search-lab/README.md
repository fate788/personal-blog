# 商品搜索实验台

桌面办公用品商店配套的搜索实验台。顾客按品名、型号或用途搜商品。运营用固定查询和逐商品相关性分级对照基础检索和候选排序，找出搜不到、排错了以及调整后变差的查询。

[打开顾客端](https://fate788.github.io/personal-blog/demos/searchlab/index.html?v=1.2) · [打开排序评测](https://fate788.github.io/personal-blog/demos/searchlab/index.html?v=1.2#evaluation) · [博客作品页](https://fate788.github.io/personal-blog/projects/searchlab/index.html)

![桌面商店搜索实屏](docs/preview.webp)

## 两分钟体验

1. 在商店输入「屏幕」，从建议里选择「屏幕挂灯」。搜索结果可按类目、价格或库存过滤，三款挂灯的规格可以直接比较。
2. 从商品卡或详情页把现货商品加入购物袋。打开购物袋可增减数量、移除商品和核对合计。演示购物袋保存在当前浏览器。
3. 点击「对照这个搜索词」，立即看同一词在两套检索下的前五件商品。固定样例评测还支持切换同义词扩展和下载 CSV。

## 本地启动

需要 Node.js 20 或以上，无需安装依赖。Windows 可以双击 `start-search.cmd`，也可在目录运行：

```sh
node server.mjs
npm test
npm run build:demo
```

服务地址是 [127.0.0.1:8818](http://127.0.0.1:8818/)。可用 `node server.mjs --port 8819` 更换端口。静态版本生成在 `dist/index.html`，连同相邻的 `media` 目录一起保留即可离线打开。

同一检索和评测逻辑也能通过 Node 服务的只读接口调用：

| 请求 | 用途 |
| --- | --- |
| `GET /api/catalog` | 读取商品和类目 |
| `GET /api/search?q=65W&strategy=candidate&inStock=1` | 用候选方案搜索有现货的商品 |
| `GET /api/search?q=65W&expandAliases=0&limit=3` | 关闭扩展并限制返回数 |
| `GET /api/evaluate?k=5&expandAliases=1` | 核对排序、相关性分级、指标和逐词变化 |

## 评测口径

目录、查询、分级和产品照片用于演练。目录和查询是为作品编写的模拟数据，商品图为生成素材。商品页规格来自样例目录，品类共用图片附有示意标记。样例规模有限，指标仅描述该样例上的离线结果。用户搜索在本机内完成，公开演示无需账号。

nDCG@5 同时考虑前五个结果的位置与相关程度。MRR@5 计算前五位中首个相关结果的倒数排名。没有相关商品标注的查询不计入这两个均值，仍保留在逐词对照和零结果统计里。

固定样例有 56 件商品、23 条查询，19 条有相关性标注。原词基线到候选方案的 nDCG@5 从 0.246 到 0.979，零结果查询从 17 条到 3 条。前五位结果中，5 条查询也多出了未标注为相关的商品。例如「HDMI 分线器」的首位仍然是分线器，同时多召回了一款用途不同的扩展坞。查看评测列表可以逐条复查。

参考了 Elasticsearch 对固定查询集合、相关性分级及排序指标的组织方式，以及 Algolia 的零结果分析和同义词配置工作流。 [Elasticsearch 排序评测](https://www.elastic.co/docs/reference/elasticsearch/rest-apis/search-rank-eval) · [Algolia 零结果优化](https://www.algolia.com/ecommerce-merchandising-playbook/null-results-optimization)

商店列表、输入建议和加购反馈参考了成熟电商的场景与可用性研究。鼠标、键盘、充电器和挂灯分别采用各自的参数顺序。 [Target 商品搜索](https://www.target.com/s?searchTerm=desk+lamp) · [Baymard 搜索建议](https://baymard.com/research-articles/autocomplete-design) · [Baymard 加购反馈](https://baymard.com/ecommerce-design-examples/added-to-cart-confirmation)
