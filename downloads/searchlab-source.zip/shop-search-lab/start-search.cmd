@echo off
cd /d "%~dp0"
node server.mjs
exit /b %errorlevel%
