const money = new Intl.NumberFormat("zh-CN", { maximumFractionDigits: 2 });

function normalize(value) {
  return String(value ?? "").normalize("NFKC").trim().replace(/\s+/gu, " ").toLocaleLowerCase("zh-CN");
}

function optionRow(list, index, { kind, label, detail }) {
  const option = document.createElement("div");
  option.id = `${list.id}-${index}`;
  option.className = "suggestion-option";
  option.dataset.suggestion = String(index);
  option.dataset.kind = kind;
  option.setAttribute("role", "option");
  option.setAttribute("aria-selected", "false");

  const title = document.createElement("span");
  title.className = "suggestion-main";
  title.textContent = label;
  const meta = document.createElement("span");
  meta.className = "suggestion-meta";
  meta.textContent = detail;
  option.append(title, meta);
  return option;
}

export function mountSearchSuggestions({ root, terms, findProducts, onQuery, onProduct, categoryName }) {
  let input;
  let list;
  let draft = "";
  let active = -1;
  let options = [];
  let composing = false;
  const queryTerms = [...new Map(terms.map(term => [normalize(term), term])).entries()].filter(([key]) => key);

  function reset({ restore = false } = {}) {
    if (input) {
      if (restore && active >= 0) input.value = draft;
      input.setAttribute("aria-expanded", "false");
      input.removeAttribute("aria-activedescendant");
    }
    if (list) {
      list.hidden = true;
      list.replaceChildren();
    }
    active = -1;
    options = [];
  }

  function bind(field) {
    if (input === field) return Boolean(list);
    reset();
    input = field;
    list = field.form?.querySelector("#shop-suggestions");
    draft = field.value;
    composing = false;
    return Boolean(list);
  }

  function render() {
    const typed = normalize(draft);
    if (!typed || composing || !list) {
      reset();
      return;
    }
    const matchingTerms = queryTerms.filter(([key]) => key.startsWith(typed)).slice(0, 3);
    const queries = matchingTerms.map(([, label]) => ({ kind: "query", label, detail: "搜索词" }));
    const products = findProducts(draft).slice(0, 3).map(product => ({
      kind: "product",
      id: product.id,
      label: product.name,
      detail: [categoryName(product.category), product.sku, `¥${money.format(product.price)}`].filter(Boolean).join(" · "),
    }));
    options = [...queries, ...products];
    active = -1;
    list.hidden = options.length === 0;
    input.setAttribute("aria-expanded", String(!list.hidden));
    input.removeAttribute("aria-activedescendant");
    list.replaceChildren(...options.map((option, index) => optionRow(list, index, option)));
  }

  function choose(index) {
    const option = options[index];
    if (!option) return;
    const field = input;
    reset({ restore: true });
    if (option.kind === "query") onQuery(option.label);
    else onProduct(option.id, field);
  }

  root.addEventListener("input", event => {
    if (event.target.id !== "shop-query" || !bind(event.target) || event.isComposing || composing) return;
    draft = input.value;
    render();
  });
  root.addEventListener("compositionstart", event => {
    if (event.target.id !== "shop-query" || !bind(event.target)) return;
    composing = true;
    reset();
  });
  root.addEventListener("compositionend", event => {
    if (event.target.id !== "shop-query" || !bind(event.target)) return;
    composing = false;
    draft = input.value;
    render();
  });
  root.addEventListener("keydown", event => {
    if (event.target.id !== "shop-query" || !bind(event.target) || event.isComposing || composing || event.keyCode === 229) return;
    if (event.key === "Escape" && options.length) {
      event.preventDefault();
      event.stopPropagation();
      reset({ restore: true });
    } else if (event.key === "Enter" && active >= 0) {
      event.preventDefault();
      choose(active);
    } else if (event.key === "ArrowDown" || event.key === "ArrowUp") {
      if (!options.length) {
        draft = input.value;
        render();
      }
      if (!options.length) return;
      event.preventDefault();
      const direction = event.key === "ArrowDown" ? 1 : -1;
      active = active < 0 ? (direction === 1 ? 0 : options.length - 1) : (active + direction + options.length) % options.length;
      const selected = list.children[active];
      for (const row of list.children) row.setAttribute("aria-selected", String(row === selected));
      input.setAttribute("aria-activedescendant", selected.id);
      input.value = options[active].kind === "query" ? options[active].label : draft;
      selected.scrollIntoView({ block: "nearest" });
    }
  });
  root.addEventListener("mousedown", event => {
    if (event.target.closest("#shop-suggestions [data-suggestion]")) event.preventDefault();
  });
  root.addEventListener("click", event => {
    const option = event.target.closest("#shop-suggestions [data-suggestion]");
    if (option && list?.contains(option)) choose(Number(option.dataset.suggestion));
  });
  root.addEventListener("focusout", event => {
    if (event.target === input && event.relatedTarget && !input.form?.contains(event.relatedTarget)) reset({ restore: true });
  });
  document.addEventListener("pointerdown", event => {
    if (input && !input.form?.contains(event.target)) reset({ restore: true });
  });
  return { close: () => reset() };
}
