export const shoppingBagStorageKey = "shop-search-lab.bag.v1";
const maxQuantity = 99;
const failures = {
  unknownProduct: "找不到这件商品。",
  invalidQuantity: "请输入 1 到 99 件。",
  quantityLimit: "同一商品最多选 99 件。",
  outOfStock: "这件商品暂时无货。"
};

function defaultStorage() {
  try {
    return globalThis.localStorage;
  } catch {
    return null;
  }
}

function failure(code) {
  return { ok: false, code, message: failures[code] };
}

function success(code, message) {
  return { ok: true, code, message };
}

export function createShoppingBag(products, storage = defaultStorage()) {
  const catalog = new Map();
  const maximumUnitCents = Math.floor(Number.MAX_SAFE_INTEGER / Math.max(products.length, 1) / maxQuantity);
  for (const product of products) {
    if (typeof product?.id !== "string" || !product.id || typeof product.name !== "string" ||
      typeof product.price !== "number") continue;
    const unitCents = Math.round(product.price * 100);
    if (!Number.isSafeInteger(unitCents) || unitCents < 0 || unitCents > maximumUnitCents) continue;
    catalog.set(product.id, { product, unitCents });
  }

  let units = new Map();
  let localOnly = !storage;

  function reload() {
    if (localOnly) return false;
    let raw;
    try {
      raw = storage.getItem(shoppingBagStorageKey);
    } catch {
      localOnly = true;
      return false;
    }
    let saved;
    try {
      saved = JSON.parse(raw ?? "[]");
    } catch {
      saved = [];
    }
    const current = new Map();
    if (Array.isArray(saved)) {
      for (const row of saved) {
        if (!Array.isArray(row) || row.length !== 2) continue;
        const [id, quantity] = row;
        if (Number.isSafeInteger(quantity) && quantity >= 1 && quantity <= maxQuantity &&
          catalog.get(id)?.product.inStock === true) current.set(id, quantity);
      }
    }
    const changed = units.size !== current.size || [...current].some(([id, amount]) => units.get(id) !== amount);
    units = current;
    return changed;
  }
  reload();

  function persist() {
    if (localOnly) return;
    try {
      storage.setItem(shoppingBagStorageKey, JSON.stringify([...units]));
    } catch {
      // Further reloads must not erase edits that could only be saved in memory.
      localOnly = true;
    }
  }

  function quantity(id) {
    return units.get(id) ?? 0;
  }

  function updateQuantity(id, amount) {
    const entry = catalog.get(id);
    if (!entry) return failure("unknownProduct");
    if (entry.product.inStock !== true) return failure("outOfStock");
    if (!Number.isSafeInteger(amount) || amount < 1) return failure("invalidQuantity");
    if (amount > maxQuantity) return failure("quantityLimit");
    const existed = units.has(id);
    units.set(id, amount);
    persist();
    return existed ? success("updated", `已更新为 ${amount} 件。`) : success("added", `已加入购物袋，共 ${amount} 件该商品。`);
  }

  function setQuantity(id, amount) {
    reload();
    return updateQuantity(id, amount);
  }

  function add(id, amount = 1) {
    if (!Number.isSafeInteger(amount) || amount < 1) return failure("invalidQuantity");
    reload();
    const result = updateQuantity(id, quantity(id) + amount);
    return result.ok ? success("added", `已加入购物袋，共 ${quantity(id)} 件该商品。`) : result;
  }

  function decrement(id) {
    reload();
    return updateQuantity(id, quantity(id) - 1);
  }

  function remove(id) {
    if (!catalog.has(id)) return failure("unknownProduct");
    reload();
    if (units.delete(id)) persist();
    return success("removed", "已移除商品。");
  }

  function clear() {
    reload();
    units.clear();
    persist();
    return success("cleared", "已清空购物袋。");
  }

  function list() {
    return [...units].map(([id, quantity]) => {
      const { product, unitCents } = catalog.get(id);
      return { product, quantity, unitCents, lineCents: unitCents * quantity };
    });
  }

  function count() {
    return [...units.values()].reduce((total, amount) => total + amount, 0);
  }

  function subtotalCents() {
    return list().reduce((total, row) => total + row.lineCents, 0);
  }

  return { list, count, subtotalCents, quantity, add, setQuantity, decrement, remove, clear, reload };
}
