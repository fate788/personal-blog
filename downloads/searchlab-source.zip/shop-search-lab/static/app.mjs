import { products, categories, benchmark } from "../catalog.mjs";
import { search, evaluate } from "../engine.mjs";
import { merchandise } from "./merchandising.mjs";
import { createShoppingBag, shoppingBagStorageKey } from "./shopping-bag.mjs";
import { mountShoppingBag } from "./bag-view.mjs";
import { mountSearchSuggestions } from "./search-suggestions.mjs";

const app = document.querySelector("#app");
const dialog = document.querySelector("#product-dialog");
const comparisonDialog = document.querySelector("#comparison-dialog");
const comparisonTray = document.querySelector("#compare-tray");
const shoppingBagDialog = document.querySelector("#bag-dialog");
const bagButton = document.querySelector("#open-bag");
const bagToast = document.querySelector("#bag-toast");
const catalog = new Map(products.map(product => [product.id, product]));
const categoryNames = new Map(categories.map(category => [category.id, category.label]));
const formatMoney = new Intl.NumberFormat("zh-CN", { maximumFractionDigits: 2 });
const sortOptions = { relevance: "相关度", "price-asc": "价格从低到高", "price-desc": "价格从高到低" };
const priceOptions = new Map([[0, "不限价格"], [99, "¥99 以内"], [199, "¥199 以内"], [399, "¥399 以内"]]);
const grades = ["未标注", "部分相关", "相关", "高度相关"];
const outcomes = { all: "全部", improved: "提升", declined: "下降", unchanged: "持平", unjudged: "无标注", "more-unrelated": "多出未标注" };
const preferredQueries = ["屏幕挂灯", "氮化镓", "鼠标垫", "笔记本支架"];
const departments = {
  input: ["键鼠装备", "机械键盘、鼠标和腕托"],
  desk: ["桌面收纳", "桌垫、理线和支架"],
  power: ["充电与连接", "充电器、线材和扩展坞"],
  lighting: ["照明与计时", "挂灯、台灯和计时器"]
};
const featured = ["felt-mat", "k75", "gan65-dual", "basic-desk-lamp"];
const refreshedPictures = new Set(["DS-101", "KB-201", "PW-201", "LT-304"]);
const illustratedSkus = new Set([
  "KB-201", "KB-202", "KB-203", "KB-206", "KB-208", "KB-209", "KB-214",
  "DS-101", "DS-102", "DS-103", "DS-104", "DS-105", "DS-106", "DS-107", "DS-108", "DS-109", "DS-110", "DS-111", "DS-113", "DS-114",
  "PW-201", "PW-202", "PW-203", "PW-211", "PW-212", "LT-301", "LT-302", "LT-303", "LT-304", "LT-305", "LT-306", "LT-307"
]);
const pageSize = 12;
const compareLimit = 3;
const selected = new Set();
const reports = new Map();
const shop = { query: "", category: "", available: false, price: 0, sort: "relevance", shown: pageSize };
const lab = { selected: "", outcome: "all", expandAliases: true, inspect: "" };
let mode = "shop";
let dialogTrigger;
let bagToastTimer;

function escape(value) {
  return String(value ?? "").replace(/[&<>"']/gu, char => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[char]);
}
function cleanQuery(value) {
  return String(value || "").trim().slice(0, 100);
}
function fixed(value) {
  return Number.isFinite(value) ? value.toFixed(3) : "—";
}
function signed(value) {
  return Number.isFinite(value) && Math.abs(value) >= 0.0005 ? `${value > 0 ? "+" : "−"}${Math.abs(value).toFixed(3)}` : "";
}
function price(value) {
  return `<span class="currency">¥</span>${formatMoney.format(value)}`;
}
function photo(product) {
  const specific = illustratedSkus.has(product.sku);
  const file = specific ? product.sku.toLowerCase() : product.photo;
  if (!/^[a-z][a-z0-9-]*$/u.test(file || "")) return `<span class="photo-placeholder" aria-hidden="true">${escape(categoryNames.get(product.category))}</span>`;
  return `<img src="./media/${file}.webp${refreshedPictures.has(product.sku) ? "?v=1.2" : ""}" alt="" width="310" height="310" decoding="async">${specific ? "" : '<small class="image-note">品类示意</small>'}`;
}
function report() {
  if (!reports.has(lab.expandAliases)) reports.set(lab.expandAliases, evaluate(products, benchmark, { k: 5, expandAliases: lab.expandAliases }));
  return reports.get(lab.expandAliases);
}
function sampleCase(cases) {
  return cases.find(entry => entry.query === "屏幕挂灯") || cases.find(entry => entry.outcome === "improved") || cases[0];
}
function visibleCases(cases) {
  if (lab.outcome === "more-unrelated") return cases.filter(entry => entry.moreUnrelated);
  return lab.outcome === "all" ? cases : cases.filter(entry => entry.outcome === lab.outcome);
}
function chooseCase(cases) {
  const visible = visibleCases(cases);
  lab.selected = visible.find(entry => entry.id === lab.selected)?.id ||
    (lab.outcome === "all" ? sampleCase(visible)?.id : visible[0]?.id) || "";
}
function routeLink(view) {
  const params = new URLSearchParams();
  if (view === "shop") {
    if (shop.query) params.set("q", shop.query);
    if (shop.category) params.set("category", shop.category);
    if (shop.available) params.set("stock", "1");
    if (shop.price) params.set("max", shop.price);
    if (shop.sort !== "relevance") params.set("sort", shop.sort);
  } else {
    if (lab.selected && lab.selected !== sampleCase(report().cases)?.id) params.set("q", lab.selected);
    if (lab.outcome !== "all") params.set("outcome", lab.outcome);
    if (!lab.expandAliases) params.set("aliases", "0");
    if (lab.inspect) params.set("inspect", lab.inspect);
  }
  return `#${view}${params.size ? `?${params}` : ""}`;
}
function syncHeader() {
  const isLab = mode === "evaluation";
  document.body.dataset.view = mode;
  document.title = `${isLab ? "搜索排序评测" : "桌面商店"} · 商品搜索实验台`;
  document.querySelector("#identity-title").textContent = isLab ? "商品搜索实验台" : "桌面商店";
  const home = routeLink("shop");
  document.querySelector(".identity").href = home;
  document.querySelector(".footer-name").href = home;
  bagButton.hidden = isLab;
  if (isLab) bagToast.hidden = true;
  document.querySelector("#footer-note").textContent = isLab ? "评测查询与相关性标注为演示样例" : "示例商品、价格与库存 · 商品图片为示意";
  for (const link of document.querySelectorAll(".mode-nav [data-mode]")) {
    link.href = routeLink(link.dataset.mode);
    if (link.dataset.mode === mode) link.setAttribute("aria-current", "page");
    else link.removeAttribute("aria-current");
  }
}
function rememberRoute() {
  history.replaceState(history.state, "", routeLink(mode));
  syncHeader();
}
function readRoute() {
  const [route, query] = location.hash.slice(1).split("?", 2);
  const params = new URLSearchParams(query);
  mode = route === "evaluation" ? "evaluation" : "shop";
  if (mode === "shop") {
    const category = params.get("category");
    const max = Number(params.get("max"));
    const sort = params.get("sort");
    Object.assign(shop, { query: cleanQuery(params.get("q")), category: categoryNames.has(category) ? category : "", shown: pageSize,
      available: params.get("stock") === "1", price: priceOptions.has(max) ? max : 0,
      sort: Object.hasOwn(sortOptions, sort) ? sort : "relevance" });
  } else {
    lab.expandAliases = params.get("aliases") !== "0";
    lab.inspect = cleanQuery(params.get("inspect"));
    const requested = params.get("q");
    lab.outcome = Object.hasOwn(outcomes, params.get("outcome")) ? params.get("outcome") : "all";
    lab.selected = report().cases.find(entry => entry.id === requested || entry.query === requested)?.id || "";
    chooseCase(report().cases);
  }
}
function shopSearchForm() {
  return `<form class="shop-search" id="shop-search" role="search"><label class="visually-hidden" for="shop-query">商品搜索词</label>
    <span class="search-icon" aria-hidden="true"></span><input id="shop-query" name="q" type="search" role="combobox" aria-autocomplete="list" aria-expanded="false" aria-controls="shop-suggestions" maxlength="100" placeholder="搜索商品、品牌或型号" autocomplete="off" value="${escape(shop.query)}">
    <button type="submit">搜索</button><div id="shop-suggestions" class="search-suggestions" role="listbox" aria-label="搜索建议" hidden></div></form>`;
}
function quickQueries() {
  return `<div class="search-samples"><span>试搜</span>${preferredQueries.map(query =>
    `<button type="button" data-quick-query="${escape(query)}">${escape(query)}</button>`).join("")}</div>`;
}
function filterMenu(type, label, options, current) {
  const trigger = type === "price" ? "price-menu" : "sort-menu";
  return `<details class="filter-menu"><summary id="${trigger}">${escape(label)}<span class="chevron" aria-hidden="true"></span></summary>
    <div class="filter-options" role="group" aria-labelledby="${trigger}">${options.map(([value, name]) =>
      `<button type="button" data-${type}="${escape(value)}" aria-pressed="${current === value}">${escape(name)}</button>`).join("")}</div></details>`;
}
function filterControls() {
  const all = [["", "全部商品"], ...categories.map(({id, label}) => [id, label])];
  return `<aside class="shop-filters" aria-label="选购筛选"><div class="filter-heading"><h3>选购筛选</h3></div>
    <div class="category-nav" role="group" aria-label="商品分类">${all.map(([id, label]) =>
    `<button type="button" class="category-tab" data-category="${escape(id)}" aria-pressed="${shop.category === id}">${escape(label)}</button>`).join("")}</div>
    <div class="option-nav" aria-label="价格与库存"><button type="button" class="available-filter" data-available aria-pressed="${shop.available}"><span aria-hidden="true"></span>仅看现货</button>
    ${filterMenu("price", shop.price ? priceOptions.get(shop.price) : "价格区间", [...priceOptions], shop.price)}</div></aside>`;
}
function selectedFilters() {
  const active = [["category", categoryNames.get(shop.category)], ["available", shop.available && "仅看现货"], ["price", shop.price && priceOptions.get(shop.price)]].filter(([, label]) => label);
  if (!active.length) return "";
  return `<div class="active-filters" aria-label="当前筛选">${active.map(([key, label]) =>
    `<button type="button" data-clear-filter="${key}" aria-label="移除筛选 ${escape(label)}">${escape(label)}<span aria-hidden="true">×</span></button>`).join("")}
    ${active.length > 1 ? '<button type="button" class="clear-all" data-reset-shop>清除筛选</button>' : ""}</div>`;
}
function specList(specifications, className, limit) {
  return `<dl class="${className}">${specifications.slice(0, limit).map(({label, value}) =>
    `<div><dt>${escape(label)}</dt><dd>${escape(value)}</dd></div>`).join("")}</dl>`;
}
function compareButton(product) {
  const checked = selected.has(product.id);
  return `<button type="button" class="compare-product" data-compare-item="${escape(product.id)}" aria-label="对比 ${escape(product.name)}" aria-pressed="${checked}">${checked ? "已加入" : "对比"}</button>`;
}
function bagAction(product, className = "") {
  return `<button type="button" class="add-bag ${className}" data-add-bag="${escape(product.id)}"${product.inStock ? "" : " disabled"}>${product.inStock ? "加入购物袋" : "暂时缺货"}</button>`;
}
function productCard(product) {
  const {kind, specifications} = merchandise(product);
  return `<article class="product-card"><div class="photo-frame ${escape(product.category)}">${photo(product)}</div>
    <div class="product-body"><p class="product-meta">${escape(product.brand)} <span aria-hidden="true">·</span> ${escape(kind)}</p>
      <h3><button type="button" class="product-title" data-product="${escape(product.id)}" aria-label="查看${escape(product.name)}">${escape(product.name)}</button></h3>
      <p class="product-usage">${escape(product.summary)}</p>${specList(specifications, "card-specs", 3)}</div>
    <div class="product-actions"><div class="product-offer"><span class="product-price">${price(product.price)}</span><span class="stock-tag${product.inStock ? "" : " sold-out"}">${product.inStock ? "现货" : "暂缺"}</span></div>
      <div class="product-ctas">${compareButton(product)}${bagAction(product)}</div></div></article>`;
}
function productsSection(result) {
  const title = shop.query ? `「${escape(shop.query)}」搜索结果` : shop.category ? escape(categoryNames.get(shop.category)) : "浏览商品";
  const filtered = shop.category || shop.price || shop.available;
  const visible = result.hits.slice(0, shop.shown);
  const sortMenu = filterMenu("sort", sortOptions[shop.sort], Object.entries(sortOptions), shop.sort);
  const replay = shop.query ? `<a class="query-replay" href="#evaluation?${new URLSearchParams({inspect:shop.query})}">对照这个搜索词 ↗</a>` : "";
  return `<section class="catalog" aria-labelledby="results-title"><div class="catalog-layout">${filterControls()}
    <div class="catalog-results"><header class="catalog-header"><div><h2 id="results-title">${title}</h2><span class="result-count" role="status">${result.total} 件商品</span></div><div class="catalog-tools">${replay}${sortMenu}</div></header>
    ${selectedFilters()}${visible.length ? `<div class="product-grid${shop.query ? " is-list" : ""}">${visible.map(({product}) => productCard(product)).join("")}</div>
      ${visible.length < result.hits.length ? `<button type="button" class="show-products" data-more-products>查看更多商品 <span>已显示 ${visible.length} / ${result.total}</span></button>` : ""}` :
      `<div class="empty-search"><span class="search-icon" aria-hidden="true"></span><h3>没有找到符合条件的商品</h3><p>${filtered ? "试试取消分类、价格或现货筛选。" : "试试更短的关键词，或直接输入品名和货号。"}</p><button type="button" data-reset-shop>${filtered ? "清除筛选" : "浏览全部商品"}</button></div>`}</div></div></section>`;
}
function featureProducts(result) {
  const primary = featured.map(id => result.hits.find(hit => hit.id === id)).filter(Boolean);
  return { ...result, hits: [...primary, ...result.hits.filter(hit => !featured.includes(hit.id))] };
}
function departmentShelf() {
  return `<section class="department-shelf" aria-labelledby="departments-title"><div class="department-heading"><h2 id="departments-title">按用途选购</h2></div>
    <div class="department-grid">${Object.entries(departments).map(([id, [label, description]]) => `<button type="button" class="department-tile" data-shop-department="${id}">
      <img src="./media/department-${id}.webp" alt="" width="580" height="425" decoding="async"><span><strong>${label}</strong><small>${description}</small></span><span class="department-arrow" aria-hidden="true">↗</span></button>`).join("")}</div></section>`;
}
function renderShop() {
  const result = search(products, shop.query, { strategy: "candidate", category: shop.category || undefined,
    priceMax: shop.price || undefined, inStock: shop.available || undefined, sort: shop.sort, limit: products.length });
  const compact = !!(shop.query || shop.category);
  const browsingHome = !compact && !shop.price && !shop.available && shop.sort === "relevance";
  app.innerHTML = `<section class="shop-hero${compact ? " compact" : ""}"><div class="shop-hero-copy"><h1>${compact ? "搜索商品" : "给桌面换个样子"}</h1>
    ${compact ? "" : '<p>选一副顺手的键鼠、一盏合适的灯，布置自己的工位。</p>'}${shopSearchForm()}${quickQueries()}</div>
    ${compact ? "" : '<div class="hero-photo"><img src="./media/hero-red.webp" alt="朱红色桌面上摆放浅色机械键盘、鼠标和台灯" width="1536" height="1024" fetchpriority="high"></div>'}</section>${browsingHome ? departmentShelf() : ""}${productsSection(browsingHome ? featureProducts(result) : result)}`;
  renderComparisonTray();
}
function metricTile(label, baseline, candidate, count = false) {
  const direction = Number.isFinite(baseline) && Number.isFinite(candidate) ? candidate - baseline : null;
  const isGain = count ? direction < 0 : direction > 0;
  const delta = count && direction ? `${direction > 0 ? "+" : "−"}${Math.abs(direction)} 条` : signed(direction);
  const value = count ? item => `${item ?? "—"}` : fixed;
  return `<article class="metric-tile"><h2>${label}</h2><div class="metric-value"><strong>${value(candidate)}</strong>
    ${delta ? `<span class="metric-delta ${isGain ? "gain" : "loss"}" aria-label="相对基线 ${escape(delta)}">${escape(delta)}</span>` : ""}</div><p>基线 ${value(baseline)}</p></article>`;
}
function caseQueryList(dataset) {
  const selectedSample = sampleCase(dataset.cases);
  const visible = [...visibleCases(dataset.cases)].sort((left, right) => Number(right === selectedSample) - Number(left === selectedSample));
  return `<section class="query-pane" aria-labelledby="queries-title"><div class="section-heading"><h2 id="queries-title">评测查询</h2><span>${visible.length} / ${dataset.cases.length}</span></div>
    <div class="outcome-filter" role="group" aria-label="按结果筛选">${Object.entries(outcomes).map(([id, name]) =>
      `<button type="button" data-outcome="${id}" aria-pressed="${lab.outcome === id}">${name}</button>`).join("")}</div>
    <div class="case-list" id="case-list">${visible.length ? visible.map(entry =>
      `<button type="button" class="case-choice" data-case="${escape(entry.id)}" aria-pressed="${entry.id === lab.selected}"><span class="case-name"><strong>${escape(entry.query)}</strong><small>${escape(entry.group)}</small></span>
        <span class="outcome ${escape(entry.outcome)}">${outcomes[entry.outcome]}${entry.moreUnrelated ? '<small class="outcome-warning">多出未标注</small>' : signed(entry.deltaNdcg) ? `<small>${signed(entry.deltaNdcg)}</small>` : ""}</span></button>`).join("") : '<p class="empty-queries">当前筛选没有查询。</p>'}</div></section>`;
}
function documentSignals(hit) {
  const expanded = (hit.expanded || []).map(item => `${item.term} → ${item.via}`);
  if (expanded.length) return `<small class="match-trace">${escape([...new Set(expanded)].slice(0, 2).join(" · "))}</small>`;
  return "";
}
function rankedResults(entry, strategy) {
  const isCandidate = strategy === "candidate";
  const result = entry[strategy];
  const diff = new Set(isCandidate ? entry.added : entry.dropped);
  const share = result.relevantShare == null ? "—" : `${Math.round(result.relevantShare * 100)}%`;
  return `<section class="rank-panel ${strategy}" aria-labelledby="rank-${strategy}"><header class="rank-heading"><div><h3 id="rank-${strategy}">${isCandidate ? "候选方案" : "原词基线"}</h3><p>nDCG@5 <span>${fixed(result.ndcg)}</span></p></div><div class="rank-quantity"><span class="rank-share" title="所展示结果中有相关性标注的比例">相关 ${share}</span><span class="rank-size">召回 ${result.total} 件</span></div></header>
    ${result.hits.length ? `<ol class="rank-list">${result.hits.map((hit, index) => {
      const grade = hit.grade || Number(entry.relevant[hit.id] || 0);
      return `<li><span class="rank-number">${index + 1}</span><div class="rank-copy"><strong>${escape(hit.product.name)}</strong><small class="sku">${escape(hit.product.sku)}</small>${documentSignals(hit)}
        <span class="grade grade-${grade}" title="相关性标注 ${grade}">${grades[grade]}</span>${diff.has(hit.id) ? `<span class="rank-change">${isCandidate ? "新进" : "移出"}</span>` : ""}</div></li>`;
    }).join("")}</ol>` : '<p class="rank-empty">没有召回商品</p>'}</section>`;
}
function expectedResults(entry) {
  const relevant = Object.entries(entry.relevant).sort(([,a], [,b]) => b - a);
  if (!relevant.length) return "";
  return `<details class="judgments"><summary>查看人工标注的商品<span class="chevron" aria-hidden="true"></span></summary><ul>${relevant.map(([id, score]) => {
    const product = catalog.get(id);
    return `<li><span>${escape(product?.name || id)}</span><span class="grade grade-${score}">${grades[score]}</span></li>`;
  }).join("")}</ul></details>`;
}
function caseDetail(dataset) {
  const entry = dataset.cases.find(item => item.id === lab.selected);
  if (!entry) return '<section class="comparison empty-comparison"><h2>没有可对照的查询</h2><p>切换筛选条件查看当前评测。</p></section>';
  return `<section class="comparison" aria-labelledby="case-title" id="comparison"><header class="case-header"><div><p>${escape(entry.group)}</p>
    <h2 id="case-title" tabindex="-1">${escape(entry.query)}</h2></div><a class="try-query" href="#shop?${new URLSearchParams({q: entry.query})}">在商店里试搜 <span aria-hidden="true">↗</span></a></header>
    ${entry.note ? `<p class="case-note">${escape(entry.note)}</p>` : ""}${entry.moreUnrelated ? `<p class="case-warning">候选前五位多出 ${entry.candidate.falsePositives - entry.baseline.falsePositives} 件未标注商品。</p>` : ""}<div class="rank-pair">${rankedResults(entry, "baseline")}${rankedResults(entry, "candidate")}</div>${expectedResults(entry)}</section>`;
}
function replaySection() {
  const panels = lab.inspect ? [["baseline", "原词基线"], ["candidate", "候选方案"]].map(([strategy, label]) => {
    const {total, hits} = search(products, lab.inspect, {strategy, limit:5, expandAliases:lab.expandAliases});
    return `<section class="rank-panel ${strategy}"><header class="rank-heading"><h3>${label}</h3><span class="rank-size">${total} 件</span></header>
      ${hits.length ? `<ol class="rank-list">${hits.map(({product, rank, expanded}) => `<li><span class="rank-number">${rank}</span><div class="rank-copy"><strong>${escape(product.name)}</strong><small class="sku">${escape(product.sku)}</small>${documentSignals({expanded})}</div></li>`).join("")}</ol>` : '<p class="rank-empty">没有召回商品</p>'}</section>`;
  }).join("") : "";
  return `<section class="query-inspector" aria-labelledby="inspector-title"><div><h2 id="inspector-title">自定义搜索对照</h2><p>按全目录比较前五位。这些搜索词只用于查看命中，不计入固定评测。</p></div>
    <form id="inspect-query"><label class="visually-hidden" for="inspect-input">要对照的搜索词</label><input id="inspect-input" name="q" type="search" maxlength="100" placeholder="输入任意商品搜索词" value="${escape(lab.inspect)}" required><button type="submit">运行对照</button></form>
    ${panels ? `<div class="rank-pair inspector-results" data-inspector-results>${panels}</div>` : ""}</section>`;
}
function renderLab() {
  const dataset = report();
  const { baseline, candidate, judged, queries, improved, declined, moreUnrelated } = dataset.totals;
  app.innerHTML = `<div class="lab-shell"><header class="lab-header"><div><h1>搜索排序评测</h1><p>用同一批查询对照原词基线和候选方案，核对每个结果的相关性。</p></div>
    <button type="button" class="export" data-export>下载 CSV <span aria-hidden="true">↓</span></button></header>
    <section class="experiment-control" aria-label="候选方案设置"><div><h2>候选同义词扩展</h2><p>关闭后保留字段加权，对照同义词带来的变化。</p></div>
    <button class="experiment-switch" type="button" data-aliases role="switch" aria-checked="${lab.expandAliases}" aria-label="候选同义词扩展"><span aria-hidden="true"></span><b>${lab.expandAliases ? "已开启" : "已关闭"}</b></button></section>
    <div class="metric-grid" aria-label="评测指标">${metricTile("nDCG@5", baseline.ndcg, candidate.ndcg)}${metricTile("MRR@5", baseline.mrr, candidate.mrr)}${metricTile("无结果查询", baseline.zeroResults, candidate.zeroResults, true)}</div>
    <p class="evaluation-context">${queries} 条查询，${judged} 条计入相关性指标 <span>·</span> ${improved} 条提升，${declined} 条下降，${moreUnrelated} 条多出未标注商品</p>
    ${replaySection()}
    <div class="evaluation-grid">${caseQueryList(dataset)}${caseDetail(dataset)}</div>
    <details class="metric-help"><summary>指标口径<span class="chevron" aria-hidden="true"></span></summary><p>nDCG@5 衡量前五位商品的分级相关性和位置。MRR@5 计算前五位中首个有相关性标注商品的倒数排名。无相关商品标注的查询不计入这两项均值，仍检查其是否返回结果。</p></details></div>`;
}
function render() {
  if (mode === "evaluation") renderLab();
  else renderShop();
  if (mode === "evaluation") renderComparisonTray();
  syncHeader();
}
function restoreControl(selector, scrollTop = null) {
  if (scrollTop !== null) document.querySelector("#case-list").scrollTop = scrollTop;
  document.querySelector(selector)?.focus({preventScroll: true});
}
function updateShop(change, control, keepResults = false) {
  const categoryScroll = app.querySelector(".category-nav")?.scrollLeft || 0;
  change();
  if (!keepResults) shop.shown = pageSize;
  rememberRoute();
  renderShop();
  app.querySelector(".category-nav").scrollLeft = categoryScroll;
  if (control) restoreControl(control);
}
function shopQuery(query) {
  updateShop(() => { Object.assign(shop, {query: cleanQuery(query), category: "", available: false, price: 0, sort: "relevance"}); });
  window.scrollTo(0, 0);
  document.querySelector("#shop-query").focus({preventScroll: true});
}
function updateLab(change, control, preserveList = false) {
  const listTop = preserveList ? document.querySelector("#case-list").scrollTop : null;
  change();
  chooseCase(report().cases);
  rememberRoute();
  renderLab();
  restoreControl(control, listTop);
}
function renderComparisonTray() {
  const items = [...selected].map(id => catalog.get(id));
  comparisonTray.hidden = mode !== "shop" || !items.length;
  document.body.classList.toggle("has-compare-tray", !comparisonTray.hidden);
  if (comparisonTray.hidden) {
    comparisonTray.replaceChildren();
    return;
  }
  const ready = items.length >= 2;
  comparisonTray.innerHTML = `<div class="compare-tray-inner"><div class="compare-selection"><b>已选 ${items.length} / ${compareLimit} 件</b><div class="compare-tags">
    ${items.map(product => `<button type="button" data-compare-item="${escape(product.id)}" data-remove-item aria-label="移除 ${escape(product.name)}"><span>${escape(product.name)}</span><span aria-hidden="true">×</span></button>`).join("")}</div><p id="compare-status" role="status"></p></div>
    <button type="button" class="open-comparison" data-open-comparison${ready ? "" : " disabled"}>${ready ? "查看对比" : "再选一件"}</button></div>`;
}
function toggleComparison(id) {
  const product = catalog.get(id);
  if (!product) return;
  const first = catalog.get(selected.values().next().value);
  if (!selected.has(id) && (first && first.photo !== product.photo || selected.size >= compareLimit)) {
    const status = document.querySelector(".product-dialog[open] .sheet-notice") || comparisonTray.querySelector("#compare-status");
    if (status) status.textContent = selected.size >= compareLimit ? "最多对比 3 件，请先移除一件。" : "请选择同类商品，方便核对相同规格。";
    return;
  }
  if (selected.has(id)) selected.delete(id);
  else selected.add(id);
  const sheetNotice = dialog.querySelector(".sheet-notice");
  if (sheetNotice) sheetNotice.textContent = "";
  for (const control of document.querySelectorAll(`[data-compare-item="${CSS.escape(id)}"]:not([data-remove-item])`)) {
    control.setAttribute("aria-pressed", String(selected.has(id)));
    control.textContent = selected.has(id) ? "已加入" : "对比";
  }
  renderComparisonTray();
}
function showComparison() {
  const items = [...selected].map(id => catalog.get(id));
  if (items.length < 2) return;
  const specifications = items.map(product => new Map(merchandise(product).specifications.map(({label, value}) => [label, value])));
  const keys = [...new Set(specifications.flatMap(spec => [...spec.keys()]))];
  const specificationRows = keys.map(key => `<tr><th scope="row">${escape(key)}</th>${specifications.map(spec => `<td>${escape(spec.get(key) || "—")}</td>`).join("")}</tr>`).join("");
  comparisonDialog.innerHTML = `<div class="comparison-sheet"><header class="comparison-heading"><h2 id="comparison-title">商品规格对比</h2><button type="button" class="close-dialog" data-close aria-label="关闭商品对比">×</button></header>
    <table class="comparison-table"><thead><tr><th scope="col">规格</th>${items.map(product => `<th scope="col"><div class="comparison-image">${photo(product)}</div><span>${escape(product.name)}</span><small class="sku">${escape(product.sku)}</small></th>`).join("")}</tr></thead>
    <tbody><tr><th scope="row">价格</th>${items.map(product => `<td>${price(product.price)}</td>`).join("")}</tr>
    <tr><th scope="row">库存</th>${items.map(product => `<td>${product.inStock ? "现货" : "暂缺"}</td>`).join("")}</tr>${specificationRows}</tbody></table></div>`;
  comparisonDialog.showModal();
  comparisonDialog.querySelector("[data-close]").focus();
}
function showProduct(id, trigger) {
  const product = catalog.get(id);
  if (!product) return;
  const {kind, specifications} = merchandise(product);
  dialogTrigger = trigger;
  dialog.innerHTML = `<div class="product-sheet"><button type="button" class="close-dialog" aria-label="关闭商品详情" data-close>×</button>
    <figure class="sheet-visual"><div class="photo-frame ${escape(product.category)}">${photo(product)}</div><figcaption>商品图为示意</figcaption></figure>
    <div class="sheet-copy"><p class="product-meta">${escape(product.brand)} · ${escape(kind)} · <span class="sku">${escape(product.sku)}</span></p>
    <h2 id="product-title">${escape(product.name)}</h2><p class="sheet-summary">${escape(product.summary)}</p>
    <div class="sheet-offer"><div><p class="sheet-price">${price(product.price)}</p><p class="sheet-stock">${product.inStock ? "现货" : "暂时无货"}</p></div><div class="product-ctas">${compareButton(product)}${bagAction(product, "detail-add-bag")}</div></div>
    <p class="sheet-notice" role="status"></p><div class="sheet-bag-result" hidden><p class="sheet-bag-message" role="status"></p><button type="button" data-view-bag>查看购物袋</button></div>
    <section class="sheet-facts" aria-label="商品规格"><h3>商品规格</h3>${specList(specifications, "sheet-specs", specifications.length)}</section></div></div>`;
  dialog.showModal();
  dialog.querySelector("[data-close]").focus();
}
const bag = createShoppingBag(products);
const bagView = mountShoppingBag({dialog:shoppingBagDialog, bag, photo, onChange:syncBagCount});

function syncBagCount() {
  const count = bag.count();
  document.querySelector("#bag-count").textContent = count;
  bagButton.setAttribute("aria-label", `购物袋，${count} 件商品`);
}
function addToBag(id) {
  const result = bag.add(id);
  if (result.ok) syncBagCount();
  const item = catalog.get(id);
  const message = result.ok ? `${item.name}已加入购物袋` : result.message;
  if (dialog.open) {
    const feedback = dialog.querySelector(".sheet-bag-result");
    feedback.hidden = false;
    feedback.querySelector(".sheet-bag-message").textContent = message;
    feedback.querySelector("[data-view-bag]").hidden = !result.ok;
    return;
  }
  clearTimeout(bagToastTimer);
  bagToast.hidden = false;
  document.querySelector("#bag-toast-message").textContent = message;
  bagToast.querySelector("[data-view-bag]").hidden = !result.ok;
  bagToastTimer = setTimeout(() => { bagToast.hidden = true; }, 6000);
}
function openBag() {
  if (dialog.open) dialog.close();
  bagToast.hidden = true;
  bagView.open(bagButton);
}
function csvField(value) {
  let text = String(value ?? "");
  if (typeof value === "string" && /^[=+@\-\t\r]/u.test(text)) text = "'" + text;
  return `"${text.replaceAll('"', '""')}"`;
}
function downloadReport() {
  const { cases, k } = report();
  const rows = [["查询", "分类", "状态", "Top K", "候选同义词", "基线 nDCG", "候选 nDCG", "nDCG 变化", "基线倒数排名", "候选倒数排名", "基线未标注结果数", "候选未标注结果数", "候选多出未标注", "基线结果货号", "候选结果货号", "人工标注商品与分值"]];
  for (const entry of cases) rows.push([entry.query, entry.group, outcomes[entry.outcome], k, lab.expandAliases ? "开启" : "关闭",
    entry.baseline.ndcg, entry.candidate.ndcg, entry.deltaNdcg, entry.baseline.reciprocalRank, entry.candidate.reciprocalRank,
    entry.baseline.falsePositives, entry.candidate.falsePositives, entry.moreUnrelated ? "是" : "否",
    entry.baseline.hits.map(hit => hit.product.sku).join(" | "), entry.candidate.hits.map(hit => hit.product.sku).join(" | "),
    Object.entries(entry.relevant).map(([id, grade]) => `${catalog.get(id)?.sku || id}:${grade}`).join(" | ")]);
  const url = URL.createObjectURL(new Blob(["\uFEFF", rows.map(row => row.map(csvField).join(",")).join("\r\n")], {type: "text/csv;charset=utf-8"}));
  const anchor = document.createElement("a");
  anchor.href = url;
  anchor.download = `商品搜索评测-${lab.expandAliases ? "启用" : "关闭"}同义词.csv`;
  anchor.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}
app.addEventListener("submit", event => {
  if (event.target.id === "shop-search") {
    event.preventDefault();
    shopQuery(new FormData(event.target).get("q"));
  } else if (event.target.id === "inspect-query") {
    event.preventDefault();
    const value = cleanQuery(new FormData(event.target).get("q"));
    if (value) updateLab(() => { lab.inspect = value; }, "#inspect-input");
  }
});
app.addEventListener("click", event => {
  const button = event.target.closest("button");
  if (!button) return;
  const { quickQuery, category, price: priceChoice, sort, product, outcome, case: caseId } = button.dataset;
  if (quickQuery) shopQuery(quickQuery);
  else if (button.dataset.shopDepartment) {
    updateShop(() => { shop.category = button.dataset.shopDepartment; }, '[data-category][aria-pressed="true"]');
    app.querySelector(".catalog").scrollIntoView({block:"start"});
  }
  else if (category !== undefined) updateShop(() => { shop.category = category; }, `[data-category="${CSS.escape(category)}"]`);
  else if (button.hasAttribute("data-available")) updateShop(() => { shop.available = !shop.available; }, "[data-available]");
  else if (priceChoice !== undefined) updateShop(() => { shop.price = Number(priceChoice); }, "#price-menu");
  else if (sort) updateShop(() => { shop.sort = sort; }, "#sort-menu");
  else if (product) showProduct(product, button);
  else if (button.dataset.clearFilter) {
    const key = button.dataset.clearFilter;
    const defaults = {category: "", available: false, price: 0};
    if (Object.hasOwn(defaults, key)) updateShop(() => { shop[key] = defaults[key]; }, "#sort-menu");
  }
  else if (button.hasAttribute("data-more-products")) {
    const previous = shop.shown;
    updateShop(() => { shop.shown += pageSize; }, null, true);
    app.querySelectorAll("[data-product]")[previous]?.focus({preventScroll: true});
  }
  else if (button.hasAttribute("data-reset-shop")) {
    if (shop.category || shop.available || shop.price) updateShop(() => { Object.assign(shop, {category: "", available: false, price: 0}); }, '[data-category=""]');
    else shopQuery("");
  }
  else if (button.hasAttribute("data-aliases")) updateLab(() => { lab.expandAliases = !lab.expandAliases; }, "[data-aliases]");
  else if (outcome) updateLab(() => { lab.outcome = outcome; }, `[data-outcome="${CSS.escape(outcome)}"]`);
  else if (caseId) {
    updateLab(() => { lab.selected = caseId; }, `[data-case="${CSS.escape(caseId)}"]`, true);
    if (matchMedia("(max-width: 760px)").matches) document.querySelector("#case-title")?.focus();
  }
  else if (button.hasAttribute("data-export")) downloadReport();
});
document.addEventListener("click", event => {
  const add = event.target.closest("[data-add-bag]");
  if (add && !add.disabled) addToBag(add.dataset.addBag);
  if (event.target.closest("#open-bag,[data-view-bag]")) openBag();
  const compareControl = event.target.closest("[data-compare-item]");
  if (compareControl) {
    toggleComparison(compareControl.dataset.compareItem);
    if (compareControl.hasAttribute("data-remove-item")) {
      const removedId = compareControl.dataset.compareItem;
      const next = comparisonTray.querySelector("[data-remove-item]") || app.querySelector(`[data-compare-item="${CSS.escape(removedId)}"]`) || document.querySelector("#shop-query");
      next?.focus({preventScroll: true});
    }
  }
  if (event.target.closest("[data-open-comparison]")) showComparison();
  for (const menu of document.querySelectorAll(".filter-menu[open]")) if (!menu.contains(event.target)) menu.open = false;
});
document.addEventListener("keydown", event => {
  if (event.key !== "Escape") return;
  const menu = document.querySelector(".filter-menu[open]");
  if (menu) { menu.open = false; menu.querySelector("summary").focus(); }
});
for (const sheet of [dialog, comparisonDialog]) {
  sheet.addEventListener("click", event => {
    if (event.target === sheet || event.target.closest("[data-close]")) sheet.close();
  });
}
dialog.addEventListener("close", () => dialogTrigger?.focus({preventScroll: true}));
comparisonDialog.addEventListener("close", () => comparisonTray.querySelector("[data-open-comparison]")?.focus({preventScroll: true}));
window.addEventListener("storage", ({key}) => {
  if ((key === shoppingBagStorageKey || key === null) && bag.reload()) {
    syncBagCount();
    if (shoppingBagDialog.open) bagView.refresh();
  }
});
window.addEventListener("hashchange", () => {
  if (dialog.open) dialog.close();
  if (comparisonDialog.open) comparisonDialog.close();
  if (shoppingBagDialog.open) shoppingBagDialog.close();
  readRoute();
  render();
  window.scrollTo(0, 0);
  app.focus({preventScroll: true});
});
document.querySelector(".skip-link").addEventListener("click", event => { event.preventDefault(); app.focus(); });
mountSearchSuggestions({root:app,
  terms:[...preferredQueries, "机械键盘", "显示器挂灯", "收线夹", "静音鼠标", "USB-C", "充电器", "台灯", "无线鼠标"],
  findProducts:query => search(products, query, {limit:3}).hits.map(({product}) => product),
  onQuery:shopQuery, onProduct:showProduct, categoryName:id => categoryNames.get(id)
});
syncBagCount();
readRoute();
render();
