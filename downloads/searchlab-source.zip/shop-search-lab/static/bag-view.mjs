const money = new Intl.NumberFormat("zh-CN", { minimumFractionDigits: 2, maximumFractionDigits: 2 });

function escape(value) {
  return String(value ?? "").replace(/[&<>"']/gu, char => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[char]);
}

function currency(cents) {
  return `¥${money.format(cents / 100)}`;
}

function lineMarkup({ product, quantity, unitCents, lineCents }, photo) {
  const id = escape(product.id);
  const name = escape(product.name);
  return `<li class="bag-line" data-bag-line="${id}"><div class="bag-photo">${photo(product)}</div>
    <div class="bag-item"><p class="bag-name"><strong>${name}</strong></p><p class="bag-meta">${escape(product.sku)} · 单价 ${currency(unitCents)}</p></div>
    <div class="bag-controls"><div class="bag-stepper" aria-label="${name}数量" role="group">
      <button type="button" data-bag-decrease aria-label="减少 ${name} 件数"${quantity <= 1 ? " disabled" : ""}>−</button>
      <output class="bag-qty" aria-label="数量">${quantity}</output>
      <button type="button" data-bag-increase aria-label="增加 ${name} 件数"${quantity >= 99 ? " disabled" : ""}>+</button>
    </div><button type="button" class="bag-remove" data-bag-remove aria-label="移除 ${name}">移除</button></div>
    <p class="bag-line-total" aria-label="小计 ${currency(lineCents)}">${currency(lineCents)}</p></li>`;
}

export function mountShoppingBag({ dialog, bag, photo = () => "", onChange = () => {} }) {
  let trigger;
  dialog.innerHTML = `<section class="bag-sheet"><header class="bag-heading"><div><h2 id="bag-title">购物袋</h2><p data-bag-heading-count></p></div>
    <button type="button" class="close-dialog" data-bag-close aria-label="关闭购物袋">×</button></header>
    <p class="bag-status" role="status" aria-live="polite"></p>
    <div class="bag-overflow" data-bag-list></div><footer class="bag-summary" data-bag-summary></footer></section>`;
  const status = dialog.querySelector(".bag-status");
  const closeButton = dialog.querySelector("[data-bag-close]");
  const contents = dialog.querySelector("[data-bag-list]");

  function refresh() {
    const lines = bag.list();
    dialog.querySelector("[data-bag-heading-count]").textContent = lines.length ? `共 ${bag.count()} 件商品` : "";
    contents.innerHTML = lines.length
      ? `<ul class="bag-list">${lines.map(row => lineMarkup(row, photo)).join("")}</ul>`
      : `<div class="bag-empty"><h3>购物袋还是空的</h3><p>在商品列表或详情页选择「加入购物袋」。</p></div>`;
    dialog.querySelector("[data-bag-summary]").innerHTML = `<p class="bag-disclosure">演示购物袋，商品记录保存在当前浏览器。</p>${lines.length
      ? `<div class="bag-subtotal"><span>商品合计</span><strong>${currency(bag.subtotalCents())}</strong></div>` : ""}
      <div class="bag-footer-actions">${lines.length ? '<button type="button" class="bag-clear" data-bag-clear>清空购物袋</button>' : ""}
      <button type="button" class="bag-continue" data-bag-continue>继续选购</button></div>`;
  }

  dialog.addEventListener("click", event => {
    if (event.target === dialog || event.target.closest("[data-bag-close],[data-bag-continue]")) {
      dialog.close();
      return;
    }
    const control = event.target.closest("[data-bag-increase],[data-bag-decrease],[data-bag-remove],[data-bag-clear]");
    if (!control) return;
    const row = control.closest("[data-bag-line]");
    const id = row?.dataset.bagLine;
    let result;
    if (control.hasAttribute("data-bag-clear")) result = bag.clear();
    else if (control.hasAttribute("data-bag-remove")) result = bag.remove(id);
    else if (control.hasAttribute("data-bag-increase")) result = bag.add(id);
    else result = bag.decrement(id);

    if (result.ok) {
      refresh();
      onChange();
      const updated = [...contents.querySelectorAll("[data-bag-line]")].find(item => item.dataset.bagLine === id);
      const action = control.hasAttribute("data-bag-increase") ? "[data-bag-increase]" : "[data-bag-decrease]";
      const next = updated?.querySelector(`${action}:enabled`) ?? updated?.querySelector(".bag-stepper button:enabled") ??
        contents.querySelector("[data-bag-remove]") ?? dialog.querySelector("[data-bag-continue]");
      next?.focus({preventScroll: true});
    }
    status.textContent = result.message;
  });

  dialog.addEventListener("close", () => {
    trigger?.focus({preventScroll: true});
    trigger = undefined;
  });

  function open(opener) {
    if (!dialog.open) trigger = opener;
    status.textContent = "";
    if (bag.reload()) onChange();
    refresh();
    if (!dialog.open) dialog.showModal();
    closeButton.focus({preventScroll: true});
  }

  return { open, refresh };
}
