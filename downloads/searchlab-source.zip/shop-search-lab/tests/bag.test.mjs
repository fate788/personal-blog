import assert from "node:assert/strict";
import test from "node:test";
import { createShoppingBag } from "../static/shopping-bag.mjs";

const products = [
  { id: "lamp", sku: "LT-01", name: "台灯", inStock: true, price: 18.99 },
  { id: "keyboard", sku: "KB-01", name: "键盘", inStock: true, price: 68.2 },
  { id: "sold-out", sku: "PW-02", name: "充电器", inStock: false, price: 99 }
];

function memoryStore(value = null) {
  return {
    getItem: () => value,
    setItem: (_key, next) => { value = next; }
  };
}

test("shopping bag adds by product ID and calculates integer-cent totals", () => {
  const bag = createShoppingBag(products, null);
  assert.deepEqual(bag.list(), []);
  assert.equal(bag.add("lamp").ok, true);
  assert.equal(bag.add("lamp", 2).ok, true);
  assert.equal(bag.add("keyboard").ok, true);
  assert.equal(bag.count(), 4);
  assert.equal(bag.subtotalCents(), 12517);
  assert.deepEqual(bag.list().map(row => [row.product.id, row.quantity, row.unitCents, row.lineCents]), [
    ["lamp", 3, 1899, 5697], ["keyboard", 1, 6820, 6820]
  ]);
  assert.equal(bag.setQuantity("lamp", 2).code, "updated");
  assert.equal(bag.count(), 3);
  assert.equal(bag.remove("keyboard").code, "removed");
  assert.equal(bag.subtotalCents(), 3798);
});

test("unavailable items and invalid or over-limit quantities do not mutate the bag", () => {
  const bag = createShoppingBag(products, null);
  assert.equal(bag.add("nope").code, "unknownProduct");
  assert.equal(bag.add("sold-out").code, "outOfStock");
  for (const quantity of [0, -1, 0.5, "2", NaN]) {
    assert.equal(bag.add("lamp", quantity).code, "invalidQuantity");
  }
  assert.equal(bag.setQuantity("lamp", 99).ok, true);
  assert.equal(bag.add("lamp").code, "quantityLimit");
  assert.equal(bag.setQuantity("lamp", 100).code, "quantityLimit");
  assert.equal(bag.setQuantity("lamp", 0).code, "invalidQuantity");
  assert.equal(bag.quantity("lamp"), 99);
});

test("restores valid quantities, discards invalid entries, and persists removal and clearing", () => {
  const store = memoryStore(JSON.stringify([["lamp", 2], ["sold-out", 3], ["unknown", 1], null, ["keyboard", -6]]));
  let bag = createShoppingBag(products, store);
  assert.deepEqual(bag.list().map(row => row.product.id), ["lamp"]);
  bag.add("keyboard", 2);
  bag.remove("lamp");
  bag = createShoppingBag(products, store);
  assert.equal(bag.quantity("lamp"), 0);
  assert.equal(bag.quantity("keyboard"), 2);
  bag.clear();
  assert.equal(createShoppingBag(products, store).count(), 0);
});

test("handles inaccessible or corrupt storage and rejects invalid catalog prices", () => {
  const corrupted = createShoppingBag(products, memoryStore("{not JSON"));
  assert.equal(corrupted.count(), 0);
  const blocked = createShoppingBag([...products, { id: "bad-price", name: "异常商品", price: NaN, inStock: true }], {
    getItem() { throw Error("blocked"); },
    setItem() { throw Error("blocked"); }
  });
  assert.equal(blocked.add("bad-price").ok, false);
  assert.equal(blocked.add("keyboard").ok, true);
  assert.equal(blocked.subtotalCents(), 6820);
});

test("a second tab reads the latest saved quantities before applying its changes", () => {
  const store = memoryStore();
  const first = createShoppingBag(products, store);
  const second = createShoppingBag(products, store);
  first.add("lamp", 4);
  second.add("keyboard");
  first.decrement("lamp");
  assert.equal(second.reload(), true);
  assert.equal(second.reload(), false);
  assert.equal(second.quantity("lamp"), 3);
  assert.equal(second.quantity("keyboard"), 1);
  second.clear();
  assert.equal(first.reload(), true);
  assert.equal(first.count(), 0);
});

test("a failed save leaves the current page able to keep and adjust its local items", () => {
  const store = {
    getItem() { return JSON.stringify([["lamp", 2]]); },
    setItem() { throw Error("quota"); }
  };
  const bag = createShoppingBag(products, store);
  assert.equal(bag.add("lamp").ok, true);
  assert.equal(bag.reload(), false);
  assert.equal(bag.quantity("lamp"), 3);
  assert.equal(bag.decrement("lamp").ok, true);
  assert.equal(bag.quantity("lamp"), 2);
});
