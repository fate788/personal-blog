import assert from "node:assert/strict";
import {test} from "node:test";
import {benchmark, categories, products} from "../catalog.mjs";
import {evaluate, search} from "../engine.mjs";

function normalized(values) {
  return values.reduce((sum, value, index) => sum + (2 ** value - 1) / Math.log2(index + 2), 0);
}

test("catalog data and 0–3 judgments refer to real, unique fixture IDs", () => {
  const productIds = new Set(products.map(product => product.id));
  const categoryIds = new Set(categories.map(category => category.id));
  assert.equal(productIds.size, products.length);
  assert.equal(new Set(products.map(product => product.sku)).size, products.length);
  assert.equal(new Set(benchmark.map(item => item.id)).size, benchmark.length);
  for (const product of products) {
    assert.ok(categoryIds.has(product.category));
    assert.ok(Number.isFinite(product.price) && product.price >= 0);
  }
  for (const item of benchmark) {
    for (const [id, grade] of Object.entries(item.relevant)) {
      assert.ok(productIds.has(id), `${item.id} judged unknown product ${id}`);
      assert.ok(Number.isInteger(grade) && grade >= 1 && grade <= 3);
    }
  }
});

test("exact SKU survives phonetic-free normalization; candidate additionally accepts compact SKU", () => {
  const typed = search(products, " ＫＢ‐２０８ ", {strategy: "baseline"});
  assert.deepEqual(typed.hits.map(({id, rank}) => [id, rank]), [["wired-ergo", 1]]);
  assert.equal(search(products, "KB208", {strategy: "baseline"}).total, 0);
  const compact = search(products, "KB208", {expandAliases: false});
  assert.equal(compact.hits[0].id, "wired-ergo");
  assert.equal(compact.hits[0].expanded.length, 0);
});

test("the candidate exposes the concrete synonym and respects the evaluator toggle", () => {
  assert.equal(search(products, "屏幕挂灯", {strategy: "baseline"}).total, 0);
  const enabled = search(products, "屏幕挂灯");
  assert.equal(enabled.total, 3);
  assert.equal(enabled.hits[0].id, "light-bar-pro");
  assert.deepEqual(enabled.hits[0].expanded, [{term: "屏幕挂灯", via: "显示器挂灯", source: "synonym"}]);
  assert.equal(search(products, "屏幕挂灯", {expandAliases: false}).total, 0);
  assert.equal(evaluate(products, benchmark, {expandAliases: false}).cases[0].candidate.total, 0);
  const catalogName = search(products, "整桌鼠标垫").hits[0];
  assert.equal(catalogName.id, "felt-mat");
  assert.ok(catalogName.expanded.some(match => match.source === "catalog"));
});

test("product browsing preserves selected category, stock, price, and deterministic sort with a truthful cap", () => {
  const result = search(products, "", {category: "desk", priceMax: 100, inStock: true, sort: "price-asc", limit: 3});
  assert.ok(result.total > result.hits.length);
  assert.equal(result.hits.length, 3);
  assert.ok(result.hits.every(({product}) => product.category === "desk" && product.inStock && product.price <= 100));
  assert.deepEqual(result.hits.map(({product}) => product.price), [19, 25, 39]);
  assert.equal(search(products, "屏幕挂灯", {inStock: true}).total, 2);
  assert.equal(search(products, "屏幕挂灯", {category: "power"}).total, 0);
});

test("numeric specification tokens use boundaries rather than matching 5W between 1 and 5W", () => {
  const result = search(products, "5W 无线充电");
  assert.deepEqual(result.hits.map(({id}) => id), ["basic-qi5"]);
});

test("evaluator uses discounted gains, Top-K reciprocal rank and separate no-match counts", () => {
  const run = evaluate(products, benchmark);
  const mat = run.cases.find(item => item.id === "mouse-pad");
  const ideal = normalized([3, 3, 2, 1]);
  assert.equal(mat.baseline.ndcg, normalized([3, 3]) / ideal);
  assert.equal(mat.candidate.ndcg, normalized([3, 3, 1, 2]) / ideal);
  assert.equal(mat.baseline.reciprocalRank, 1);
  const printer = run.cases.find(item => item.id === "printer-cable");
  assert.equal(printer.candidate.ndcg, null);
  assert.equal(printer.candidate.reciprocalRank, null);
  assert.equal(printer.baseline.total, 0);
  assert.equal(printer.candidate.total, 8);
  assert.ok(printer.candidate.hits.every(hit => hit.grade === 0));
  assert.equal(run.totals.judged, run.totals.queries - 4);
  assert.equal(run.totals.candidate.unexpectedResults, 1);
});

test("expanded retrieval makes the signal-splitter precision regression visible", () => {
  const row = evaluate(products, benchmark).cases.find(item => item.id === "hdmi-splitter");
  assert.equal(row.outcome, "unchanged");
  assert.ok(row.moreUnrelated);
  assert.equal(row.baseline.relevantShare, 1);
  assert.equal(row.candidate.relevantShare, 0.5);
  assert.deepEqual(row.added, ["hdmi-hub"]);
  assert.equal(row.candidate.hits.find(hit => hit.id === "hdmi-hub").grade, 0);
  const strict = evaluate(products, benchmark, {expandAliases: false}).cases.find(item => item.id === row.id);
  assert.equal(strict.candidate.relevantShare, 1);
  assert.equal(strict.moreUnrelated, false);
});
