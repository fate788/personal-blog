@echo off
setlocal
chcp 65001 >nul
cd /d "%~dp0"
where java >nul 2>&1
if errorlevel 1 (
    echo Java 17 or newer is required.
    pause
    exit /b 1
)
if not exist "release\campus-events.jar" (
    echo release\campus-events.jar was not found.
    pause
    exit /b 1
)
if not defined SERVER_PORT set "SERVER_PORT=8768"
if not defined CAMPUS_SEED_SAMPLE set "CAMPUS_SEED_SAMPLE=true"
set "CAMPUS_SERVER_ADDRESS=127.0.0.1"
echo.
powershell.exe -NoProfile -Command "$base = 'http://127.0.0.1:' + $env:SERVER_PORT; Write-Output ('Participant: ' + $base + '/'); Write-Output ('Organizer workspace: ' + $base + '/organizer.html')"
echo Use Ctrl+C to stop the application.
echo.
java -jar "release\campus-events.jar"
if errorlevel 1 pause
