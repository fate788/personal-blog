package cn.campus.events;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.server.LocalServerPort;
import org.springframework.jdbc.core.JdbcTemplate;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

@SpringBootTest(
    classes = CampusEventsApplication.class,
    webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT,
    properties = {
        "CAMPUS_DB_URL=${CAMPUS_TEST_DB_URL:jdbc:h2:mem:campus_v4_integration;MODE=MySQL;DB_CLOSE_DELAY=-1}",
        "CAMPUS_DB_USER=${CAMPUS_TEST_DB_USER:sa}",
        "CAMPUS_DB_PASSWORD=${CAMPUS_TEST_DB_PASSWORD:}",
        "CAMPUS_CHECK_IN_SECRET=test-only-stable-check-in-secret",
        "CAMPUS_LEGACY_ORGANIZER_PASSWORD=legacy-integration-only-passphrase",
        "CAMPUS_SEED_SAMPLE=false"
    }
)
class CampusEventsIntegrationTest {
    private static final String ORGANIZER_PASSWORD = "organizer-test-passphrase";
    private static final String ACCOUNT_PASSWORD = "account-only-passphrase";
    private final HttpClient client = HttpClient.newBuilder().version(HttpClient.Version.HTTP_1_1)
        .connectTimeout(Duration.ofSeconds(5)).build();

    @Autowired
    private ObjectMapper mapper;

    @Autowired
    private JdbcTemplate database;

    @LocalServerPort
    private int port;

    @Test
    void organizerCanPublishDraftAndKeepRosterPrivate() throws Exception {
        assertThat(send("GET", "/api/organizer/events", null, null).statusCode()).isEqualTo(401);
        String organizer = organizerCookie();
        JsonNode draft = json(send("POST", "/api/organizer/events", eventBody("私有活动", 3), organizer), 201);
        long id = draft.path("id").asLong();
        assertThat(draft.path("status").asText()).isEqualTo("DRAFT");
        assertThat(draft.path("durationMinutes").asInt()).isEqualTo(120);
        assertThat(draft.path("checkInOpensBeforeMinutes").asInt()).isEqualTo(15);
        assertThat(draft.path("checkInClosesAfterMinutes").asInt()).isEqualTo(30);
        assertThat(send("GET", event(id), null, null).statusCode()).isEqualTo(404);
        assertThat(json(send("GET", "/api/events", null, null), 200)).noneMatch(item -> item.path("id").asLong() == id);
        assertThat(json(send("POST", manage(id) + "/publish", null, organizer), 200).path("status").asText())
            .isEqualTo("PUBLISHED");
        assertThat(send("GET", manage(id) + "/registrations", null, null).statusCode()).isEqualTo(401);
        assertThat(send("DELETE", "/api/organizer/session", null, organizer).statusCode()).isEqualTo(204);
        assertThat(send("GET", "/api/organizer/session", null, organizer).statusCode()).isEqualTo(401);
    }

    @Test
    void organizersCanRegisterAndSignInWithTheirOwnUsername() throws Exception {
        String username = organizerUsername();
        HttpResponse<String> registration = send("POST", "/api/organizer/register", organizerBody(username), null);
        String session = cookie(registration, 201);
        JsonNode identity = json(registration, 201);
        assertThat(identity.path("name").asText()).isEqualTo("测试组织者");
        assertThat(identity.path("username").asText()).isEqualTo(username);
        assertThat(identity.has("password")).isFalse();
        assertThat(json(send("GET", "/api/organizer/session", null, session), 200).path("id"))
            .isEqualTo(identity.path("id"));
        assertThat(send("POST", "/api/organizer/register", organizerBody(username.toUpperCase(Locale.ROOT)), null)
            .statusCode()).isEqualTo(409);
        assertThat(send("POST", "/api/organizer/login", Map.of("username", username, "password", "incorrect-password"), null)
            .statusCode()).isEqualTo(401);
        String fromAnotherDevice = cookie(send("POST", "/api/organizer/login",
            Map.of("username", username.toUpperCase(Locale.ROOT), "password", ORGANIZER_PASSWORD), null), 200);
        JsonNode secondSession = json(send("GET", "/api/organizer/session", null, fromAnotherDevice), 200);
        assertThat(secondSession.path("id")).isEqualTo(identity.path("id"));
        assertThat(secondSession.path("tourPending").booleanValue()).isTrue();
        assertThat(send("POST", "/api/organizer/tour/start", null, null).statusCode()).isEqualTo(401);
        assertThat(json(send("POST", "/api/organizer/tour/start", null, session), 200).path("started").booleanValue()).isTrue();
        assertThat(json(send("POST", "/api/organizer/tour/start", null, fromAnotherDevice), 200).path("started").booleanValue()).isFalse();
        assertThat(json(send("GET", "/api/organizer/session", null, fromAnotherDevice), 200).get("tourPending").booleanValue()).isFalse();
        assertThat(send("GET", "/api/account/session", null, fromAnotherDevice).statusCode()).isEqualTo(401);
    }

    @Test
    void privateActivityOperationsAreScopedToTheAccountThatCreatedTheEvent() throws Exception {
        String owner = organizerCookie();
        String other = organizerCookie();
        long id = publish(owner, 2);
        String participant = createAccount(newId());
        long registrationId = signup(id, participant).path("id").asLong();

        assertThat(json(send("GET", "/api/organizer/events", null, other), 200))
            .noneMatch(event -> event.path("id").asLong() == id);
        assertThat(send("GET", manage(id) + "/registrations", null, other).statusCode()).isEqualTo(404);
        assertThat(send("POST", manage(id) + "/publish", null, other).statusCode()).isEqualTo(404);
        assertThat(send("POST", manage(id) + "/check-in-window", null, other).statusCode()).isEqualTo(404);
        assertThat(send("DELETE", manage(id) + "/check-in-window", null, other).statusCode()).isEqualTo(404);
        assertThat(send("POST", manage(id) + "/registrations/" + registrationId + "/check-in", null, other)
            .statusCode()).isEqualTo(404);
        assertThat(send("GET", manage(id) + "/registrations", null, participant).statusCode()).isEqualTo(401);
        assertThat(status(id, participant)).isEqualTo("REGISTERED");
        assertThat(json(send("GET", manage(id) + "/registrations", null, owner), 200)).hasSize(1);
    }

    @Test
    void legacyEventsRemainPublicButRequireAProtectedClaimForManagement() throws Exception {
        String owner = organizerCookie();
        String other = organizerCookie();
        String title = "旧版样例 " + UUID.randomUUID();
        database.update("""
            INSERT INTO campus_event (title, description, starts_at, location, capacity, status)
            VALUES (?, '', ?, '活动室', 10, 'PUBLISHED')
            """, title, LocalDateTime.now(ZoneId.of("Asia/Shanghai")).plusDays(3));
        long id = database.queryForObject("SELECT id FROM campus_event WHERE title = ?", Long.class, title);
        assertThat(send("GET", event(id), null, null).statusCode()).isEqualTo(200);
        assertThat(send("GET", manage(id) + "/registrations", null, owner).statusCode()).isEqualTo(404);
        JsonNode legacy = json(send("GET", "/api/organizer/legacy", null, owner), 200);
        assertThat(legacy.path("enabled").asBoolean()).isTrue();
        assertThat(legacy.path("available").asInt()).isPositive();
        assertThat(send("POST", "/api/organizer/claim-legacy", Map.of("password", "wrong-secret"), owner)
            .statusCode()).isEqualTo(401);
        String legacyPassword = "legacy-integration-only-passphrase";
        assertThat(json(send("POST", "/api/organizer/claim-legacy", Map.of("password", legacyPassword), owner), 200)
            .path("claimed").asInt()).isPositive();
        assertThat(json(send("GET", "/api/organizer/events", null, owner), 200))
            .anyMatch(event -> event.path("id").asLong() == id);
        assertThat(send("GET", manage(id) + "/registrations", null, other).statusCode()).isEqualTo(404);
        assertThat(json(send("POST", "/api/organizer/claim-legacy", Map.of("password", legacyPassword), other), 200)
            .path("claimed").asInt()).isZero();
    }

    @Test
    void accountRegistrationBindsToSignedInIdentityAndWorksOnAnotherDevice() throws Exception {
        String organizer = organizerCookie();
        long id = publish(organizer, 2);
        assertThat(send("POST", event(id) + "/registrations", null, null).statusCode()).isEqualTo(401);
        String identifier = newId();
        String participant = createAccount(identifier);
        assertThat(json(send("GET", "/api/account/session", null, participant), 200).path("tourPending").asBoolean()).isTrue();
        assertThat(send("POST", "/api/account/tour/start", null, organizer).statusCode()).isEqualTo(401);
        assertThat(json(send("POST", "/api/account/tour/start", null, participant), 200).path("started").asBoolean()).isTrue();
        assertThat(send("POST", "/api/account/register", accountBody(identifier), null).statusCode()).isEqualTo(409);
        assertThat(send("POST", "/api/account/login", Map.of("identifier", identifier, "password", "different-pass"), null)
            .statusCode()).isEqualTo(401);
        JsonNode first = json(send("POST", event(id) + "/registrations",
            Map.of("name", "冒名", "identifier", "NOT-MY-ID"), participant), 201);
        assertThat(first.path("name").asText()).isEqualTo("测试参与者");
        assertThat(first.path("status").asText()).isEqualTo("REGISTERED");

        String freshLogin = cookie(send("POST", "/api/account/login", loginBody(identifier), null), 200);
        assertThat(json(send("POST", "/api/account/tour/start", null, freshLogin), 200).path("started").asBoolean()).isFalse();
        assertThat(json(send("GET", "/api/account/session", null, freshLogin), 200).path("identifier").asText())
            .isEqualToIgnoringCase(identifier);
        assertThat(status(id, freshLogin)).isEqualTo("REGISTERED");
        JsonNode mine = json(send("GET", "/api/account/registrations", null, freshLogin), 200);
        assertThat(mine).anyMatch(record -> record.path("event").path("id").asLong() == id);
        String stranger = createAccount(newId());
        assertThat(send("DELETE", event(id) + "/registration", null, stranger).statusCode()).isEqualTo(404);
        assertThat(send("DELETE", event(id) + "/registration", null, freshLogin).statusCode()).isEqualTo(204);
        assertThat(status(id, freshLogin)).isEqualTo("CANCELLED");
        assertCapacity(id, 0, 2);

        assertThat(send("DELETE", "/api/account/session", null, freshLogin).statusCode()).isEqualTo(204);
        assertThat(send("GET", "/api/account/session", null, freshLogin).statusCode()).isEqualTo(401);
    }

    @Test
    void checkInRequiresRegistrationAndTheCurrentEventCode() throws Exception {
        String organizer = organizerCookie();
        long id = publish(organizer, 4);
        long secondEvent = publish(organizer, 4);
        String attendee = createAccount(newId());
        String cancelled = createAccount(newId());
        String stranger = createAccount(newId());
        signup(id, attendee);
        signup(id, cancelled);
        signup(secondEvent, attendee);
        assertThat(send("DELETE", event(id) + "/registration", null, cancelled).statusCode()).isEqualTo(204);
        assertThat(send("POST", manage(id) + "/check-in-window", null, null).statusCode()).isEqualTo(401);

        String firstCode = openWindow(id, organizer);
        String code = openWindow(id, organizer);
        String secondCode = openWindow(secondEvent, organizer);
        assertThat(List.of(firstCode, code, secondCode)).doesNotHaveDuplicates();
        assertThat(scan(id, code, null).statusCode()).isEqualTo(401);
        assertRejectedScan(id, firstCode, attendee);
        assertRejectedScan(id, secondCode, attendee);
        assertRejectedScan(id, code, cancelled);
        assertRejectedScan(id, code, stranger);
        assertThat(status(id, attendee)).isEqualTo("REGISTERED");

        assertThat(json(scan(id, code, attendee), 200).path("status").asText()).isEqualTo("CHECKED_IN");
        assertThat(json(scan(id, code, attendee), 200).path("status").asText()).isEqualTo("CHECKED_IN");
        assertThat(send("DELETE", event(id) + "/registration", null, attendee).statusCode()).isEqualTo(409);
        assertThat(json(send("GET", manage(id) + "/registrations", null, organizer), 200))
            .anyMatch(item -> item.path("status").asText().equals("CHECKED_IN"));

        String next = createAccount(newId());
        signup(id, next);
        assertThat(send("DELETE", manage(id) + "/check-in-window", null, organizer).statusCode()).isEqualTo(204);
        assertRejectedScan(id, code, next);
        assertThat(status(id, next)).isEqualTo("REGISTERED");
    }

    @Test
    void organizerCanCheckInRegisteredAttendeeManually() throws Exception {
        String organizer = organizerCookie();
        long id = publish(organizer, 1);
        String participant = createAccount(newId());
        long registration = signup(id, participant).path("id").asLong();
        String path = manage(id) + "/registrations/" + registration + "/check-in";
        assertThat(send("POST", path, null, participant).statusCode()).isEqualTo(401);
        assertThat(json(send("POST", path, null, organizer), 200).path("status").asText()).isEqualTo("CHECKED_IN");
        assertThat(status(id, participant)).isEqualTo("CHECKED_IN");
        assertCapacity(id, 1, 0);
    }

    @Test
    void eventSchedulesUseCampusTimeAndValidateTheConfiguredMinutes() throws Exception {
        String owner = organizerCookie();
        var body = new HashMap<>(eventBody("跨日活动", 5));
        body.put("startsAt", "2030-12-31T23:50");
        body.put("durationMinutes", 90);
        body.put("checkInOpensBeforeMinutes", 25);
        body.put("checkInClosesAfterMinutes", 45);
        JsonNode draft = json(send("POST", "/api/organizer/events", body, owner), 201);
        assertThat(draft.path("startsAtInstant").asText()).isEqualTo("2030-12-31T15:50:00Z");
        assertThat(draft.path("endsAt").asText()).isEqualTo("2030-12-31T17:20:00Z");
        assertThat(draft.path("checkInOpensAt").asText()).isEqualTo("2030-12-31T15:25:00Z");
        assertThat(draft.path("checkInClosesAt").asText()).isEqualTo("2030-12-31T16:35:00Z");
        EventSchedule schedule = new EventSchedule(90, 25, 45, Instant.parse(draft.path("startsAtInstant").asText()));
        assertThatThrownBy(() -> schedule.requireOpen(schedule.checkInOpensAt().minusNanos(1))).isInstanceOf(ApiException.class);
        schedule.requireOpen(schedule.checkInOpensAt());
        schedule.requireOpen(schedule.checkInClosesAt().minusNanos(1));
        assertThatThrownBy(() -> schedule.requireOpen(schedule.checkInClosesAt())).isInstanceOf(ApiException.class);

        for (var invalid : List.of(Map.entry("durationMinutes", 0), Map.entry("durationMinutes", 1441),
                Map.entry("checkInOpensBeforeMinutes", -1), Map.entry("checkInOpensBeforeMinutes", 1441),
                Map.entry("checkInClosesAfterMinutes", 0), Map.entry("checkInClosesAfterMinutes", 91),
                Map.entry("durationMinutes", 90.5))) {
            var rejected = new HashMap<>(body);
            rejected.put(invalid.getKey(), invalid.getValue());
            assertThat(send("POST", "/api/organizer/events", rejected, owner).statusCode()).isEqualTo(400);
        }
        body.put("durationMinutes", 10);
        body.remove("checkInClosesAfterMinutes");
        JsonNode shortEvent = json(send("POST", "/api/organizer/events", body, owner), 201);
        assertThat(shortEvent.path("checkInClosesAfterMinutes").asInt()).isEqualTo(10);
    }

    @Test
    void scheduleLimitsCodeIssuanceAttendanceAndRegistrationAtTheirRespectiveDeadlines() throws Exception {
        String owner = organizerCookie();
        LocalDateTime now = LocalDateTime.now(EventSchedule.CAMPUS_ZONE).withNano(0);
        var body = new HashMap<>(eventBody("现场签到时段", 8));
        body.put("startsAt", now.minusSeconds(10).toString());
        body.put("durationMinutes", 60);
        body.put("checkInOpensBeforeMinutes", 0);
        body.put("checkInClosesAfterMinutes", 1);
        long id = json(send("POST", "/api/organizer/events", body, owner), 201).path("id").asLong();
        JsonNode published = json(send("POST", manage(id) + "/publish", null, owner), 200);
        String registered = createAccount(newId());
        String cancelled = createAccount(newId());
        long registrationId = signup(id, registered).path("id").asLong();
        signup(id, cancelled);
        assertThat(send("DELETE", event(id) + "/registration", null, cancelled).statusCode()).isEqualTo(204);
        JsonNode window = json(send("POST", manage(id) + "/check-in-window", null, owner), 200);
        assertThat(window.path("expiresAt")).isEqualTo(published.path("checkInClosesAt"));
        String code = window.path("code").asText();
        database.update("UPDATE campus_event SET starts_at = ? WHERE id = ?", now.plusDays(1), id);
        assertThat(json(send("POST", manage(id) + "/check-in-window", null, owner), 409).path("message").asText())
            .contains("未到");
        assertThat(json(scan(id, code, registered), 409).path("message").asText()).contains("未到");
        database.update("UPDATE campus_event SET starts_at = ? WHERE id = ?", now.minusMinutes(2), id);
        assertThat(json(send("POST", manage(id) + "/check-in-window", null, owner), 409).path("message").asText())
            .contains("时段已结束");
        assertThat(json(scan(id, code, registered), 409).path("message").asText()).contains("时段已结束");
        signup(id, createAccount(newId()));
        database.update("UPDATE campus_event SET starts_at = ? WHERE id = ?", now.minusDays(1), id);
        for (String account : List.of(cancelled, createAccount(newId()))) {
            assertThat(json(send("POST", event(id) + "/registrations", null, account), 409).path("message").asText())
                .contains("活动已结束");
        }
        assertThat(status(id, cancelled)).isEqualTo("CANCELLED");
        assertThat(json(send("POST", manage(id) + "/registrations/" + registrationId + "/check-in", null, owner), 200)
            .path("status").asText()).isEqualTo("CHECKED_IN");
    }

    @Test
    void assigningOrChangingAScheduleRevokesCodesButKeepsRegistrationsAndLeases() throws Exception {
        String owner = organizerCookie();
        long ownerId = json(send("GET", "/api/organizer/session", null, owner), 200).path("id").asLong();
        String title = "原有活动 " + UUID.randomUUID();
        database.update("""
            INSERT INTO campus_event (title, description, starts_at, location, capacity, status)
            VALUES (?, '', ?, '多功能厅', 10, 'PUBLISHED')
            """, title, LocalDateTime.now(EventSchedule.CAMPUS_ZONE).withNano(0).minusMinutes(10));
        long id = database.queryForObject("SELECT id FROM campus_event WHERE title = ?", Long.class, title);
        database.update("INSERT INTO event_organizer (event_id, organizer_id) VALUES (?, ?)", id, ownerId);
        assertThat(json(send("GET", event(id), null, null), 200).has("durationMinutes")).isFalse();
        String a = createAccount(newId());
        String b = createAccount(newId());
        signup(id, a);
        signup(id, b);
        String old = openWindow(id, owner);
        json(scan(id, old, a), 200);
        String wrong = String.format(Locale.ROOT, "%06d", (Integer.parseInt(old) + 1) % 1_000_000);
        assertThat(scan(id, wrong, b).statusCode()).isEqualTo(409);
        String path = manage(id) + "/schedule";
        var change = Map.of("durationMinutes", 75, "checkInOpensBeforeMinutes", 10, "checkInClosesAfterMinutes", 25);
        assertThat(send("PATCH", path, change, b).statusCode()).isEqualTo(401);
        assertThat(send("PATCH", path, change, organizerCookie()).statusCode()).isEqualTo(404);
        assertThat(send("PATCH", path, Map.of(), owner).statusCode()).isEqualTo(400);
        String digest = database.queryForObject("SELECT code_digest FROM event_check_in_window WHERE event_id = ?", String.class, id);
        JsonNode revised = json(send("PATCH", path, change, owner), 200);
        assertThat(json(send("GET", event(id), null, null), 200)).isEqualTo(revised);
        assertThat(revised.path("durationMinutes").asInt()).isEqualTo(75);
        assertThat(status(id, a)).isEqualTo("CHECKED_IN");
        assertThat(json(scan(id, old, b), 409).path("message").asText()).contains("关闭");
        assertThat(database.queryForObject("SELECT COUNT(*) FROM event_check_in_attempt WHERE event_id = ?", Integer.class, id)).isZero();
        assertThat(database.queryForObject("SELECT COUNT(*) FROM event_check_in_code_lease WHERE code_digest = ?", Integer.class, digest)).isOne();
        String current = openWindow(id, owner);
        assertThat(current).isNotEqualTo(old);
        json(send("PATCH", path, change, owner), 200);
        assertThat(send("PATCH", path, Map.of("durationMinutes", 5), owner).statusCode()).isEqualTo(400);
        json(scan(id, current, b), 200);
        json(send("PATCH", path, Map.of("durationMinutes", 90), owner), 200);
        assertThat(scan(id, current, b).statusCode()).isEqualTo(409);
        assertCapacity(id, 2, 8);
    }

    @Test
    void expiredCodeDoesNotConfirmAttendance() throws Exception {
        String organizer = organizerCookie();
        long id = publish(organizer, 2);
        String participant = createAccount(newId());
        signup(id, participant);
        String code = openWindow(id, organizer);
        database.update("UPDATE event_check_in_window SET expires_at_ms = ? WHERE event_id = ?",
            Instant.now().minusSeconds(1).toEpochMilli(), id);
        assertThat(scan(id, code, participant).statusCode()).isEqualTo(409);
        assertThat(status(id, participant)).isEqualTo("REGISTERED");
    }

    @Test
    void incorrectNumericAttemptsExpireWithTheCurrentCode() throws Exception {
        String organizer = organizerCookie();
        long id = publish(organizer, 3);
        String participant = createAccount(newId());
        String secondParticipant = createAccount(newId());
        signup(id, participant);
        signup(id, secondParticipant);
        String code = openWindow(id, organizer);
        String wrong = String.format(Locale.ROOT, "%06d", (Integer.parseInt(code) + 1) % 1_000_000);

        assertThat(scan(id, "12A456", participant).statusCode()).isEqualTo(400);
        for (int i = 0; i < 5; i++) assertThat(scan(id, wrong, participant).statusCode()).isEqualTo(409);
        assertThat(scan(id, code, participant).statusCode()).isEqualTo(429);
        assertThat(status(id, participant)).isEqualTo("REGISTERED");
        assertThat(json(scan(id, code, secondParticipant), 200).path("status").asText()).isEqualTo("CHECKED_IN");

        String next = openWindow(id, organizer);
        assertThat(next).isNotEqualTo(code);
        assertThat(json(scan(id, next, participant), 200).path("status").asText()).isEqualTo("CHECKED_IN");
    }

    @Test
    void competingSignedInAccountsCannotOverbook() throws Exception {
        String organizer = organizerCookie();
        long id = publish(organizer, 8);
        List<String> sessions = new ArrayList<>();
        for (int i = 0; i < 24; i++) sessions.add(createAccount(newId()));
        List<Integer> results = compete(id, sessions);
        assertThat(results).containsOnly(201, 409);
        assertThat(results.stream().filter(value -> value == 201).count()).isEqualTo(8);
        assertCapacity(id, 8, 0);
        var unique = new HashSet<String>();
        JsonNode roster = json(send("GET", manage(id) + "/registrations", null, organizer), 200);
        for (JsonNode row : roster) unique.add(row.path("identifier").asText());
        assertThat(unique).hasSize(8);
    }

    @Test
    void competingRequestsFromOneAccountConsumeOneSeat() throws Exception {
        long id = publish(organizerCookie(), 8);
        List<Integer> results = compete(id, java.util.Collections.nCopies(12, createAccount(newId())));
        assertThat(results).containsOnly(201, 409);
        assertThat(results.stream().filter(value -> value == 201).count()).isEqualTo(1);
        assertCapacity(id, 1, 7);
    }

    private List<Integer> compete(long id, List<String> sessions) throws Exception {
        var workers = Executors.newFixedThreadPool(sessions.size());
        var start = new CountDownLatch(1);
        var ready = new CountDownLatch(sessions.size());
        try {
            List<Future<Integer>> results = new ArrayList<>();
            for (String session : sessions) {
                results.add(workers.submit(() -> {
                    ready.countDown();
                    if (!start.await(10, TimeUnit.SECONDS)) throw new IllegalStateException("Concurrent test did not start");
                    return send("POST", event(id) + "/registrations", null, session).statusCode();
                }));
            }
            assertThat(ready.await(10, TimeUnit.SECONDS)).isTrue();
            start.countDown();
            List<Integer> statuses = new ArrayList<>();
            for (Future<Integer> result : results) statuses.add(result.get(20, TimeUnit.SECONDS));
            return statuses;
        } finally {
            start.countDown();
            workers.shutdownNow();
        }
    }

    private void assertCapacity(long id, int confirmed, int remaining) throws Exception {
        JsonNode item = json(send("GET", event(id), null, null), 200);
        assertThat(item.path("confirmed").asInt()).isEqualTo(confirmed);
        assertThat(item.path("remaining").asInt()).isEqualTo(remaining);
        assertThat(item.has("registrations")).isFalse();
    }

    private void assertRejectedScan(long id, String code, String account) throws Exception {
        assertThat(scan(id, code, account).statusCode()).isIn(400, 403, 404, 409, 410);
    }

    private HttpResponse<String> scan(long id, String code, String account) throws Exception {
        return send("POST", event(id) + "/self-check-in", Map.of("code", code), account);
    }

    private String openWindow(long id, String organizer) throws Exception {
        JsonNode window = json(send("POST", manage(id) + "/check-in-window", null, organizer), 200);
        assertThat(window.path("eventId").asLong()).isEqualTo(id);
        assertThat(Instant.parse(window.path("expiresAt").asText())).isAfter(Instant.now());
        assertThat(window.path("code").asText()).matches("[0-9]{6}");
        return window.path("code").asText();
    }

    private String status(long id, String account) throws Exception {
        return json(send("GET", event(id) + "/registration", null, account), 200).path("status").asText();
    }

    private JsonNode signup(long id, String account) throws Exception {
        return json(send("POST", event(id) + "/registrations", null, account), 201);
    }

    private String createAccount(String identifier) throws Exception {
        return cookie(send("POST", "/api/account/register", accountBody(identifier), null), 201);
    }

    private String organizerCookie() throws Exception {
        return cookie(send("POST", "/api/organizer/register", organizerBody(organizerUsername()), null), 201);
    }

    private static String organizerUsername() {
        return "org-" + UUID.randomUUID().toString().substring(0, 14);
    }

    private static Map<String, String> organizerBody(String username) {
        return Map.of("name", "测试组织者", "username", username, "password", ORGANIZER_PASSWORD);
    }

    private long publish(String organizer, int capacity) throws Exception {
        long id = json(send("POST", "/api/organizer/events", eventBody("测试活动", capacity), organizer), 201)
            .path("id").asLong();
        json(send("POST", manage(id) + "/publish", null, organizer), 200);
        return id;
    }

    private Map<String, Object> eventBody(String title, int capacity) {
        return Map.of(
            "title", title, "description", "HTTP integration test fixture",
            "startsAt", LocalDateTime.now(ZoneId.of("Asia/Shanghai")).plusMinutes(2).withNano(0).toString(),
            "location", "活动室", "capacity", capacity
        );
    }

    private Map<String, String> accountBody(String identifier) {
        return Map.of("name", "测试参与者", "identifier", identifier, "password", ACCOUNT_PASSWORD);
    }

    private Map<String, String> loginBody(String identifier) {
        return Map.of("identifier", identifier, "password", ACCOUNT_PASSWORD);
    }

    private static String newId() {
        return "QA-" + UUID.randomUUID().toString().substring(0, 14);
    }

    private static String event(long id) { return "/api/events/" + id; }
    private static String manage(long id) { return "/api/organizer/events/" + id; }

    private String cookie(HttpResponse<String> response, int status) {
        assertThat(response.statusCode()).as("HTTP response %s", response.body()).isEqualTo(status);
        String raw = response.headers().firstValue("Set-Cookie").orElseThrow();
        assertThat(raw.toLowerCase(Locale.ROOT)).contains("httponly", "samesite=strict");
        return raw.split(";", 2)[0];
    }

    private JsonNode json(HttpResponse<String> response, int status) throws Exception {
        assertThat(response.statusCode()).as("HTTP response %s", response.body()).isEqualTo(status);
        return mapper.readTree(response.body());
    }

    private HttpResponse<String> send(String method, String path, Object body, String cookie) throws Exception {
        HttpRequest.Builder request = HttpRequest.newBuilder(URI.create("http://127.0.0.1:" + port + path))
            .timeout(Duration.ofSeconds(25)).header("Accept", "application/json");
        if (cookie != null) request.header("Cookie", cookie);
        if (body == null) {
            request.method(method, HttpRequest.BodyPublishers.noBody());
        } else {
            request.header("Content-Type", "application/json")
                .method(method, HttpRequest.BodyPublishers.ofString(mapper.writeValueAsString(body)));
        }
        return client.send(request.build(), HttpResponse.BodyHandlers.ofString());
    }
}
