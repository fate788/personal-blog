package cn.campus.events;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class CampusEventsApplication {
    public static void main(String[] args) {
        SpringApplication.run(CampusEventsApplication.class, args);
    }

    @Bean
    @ConditionalOnProperty(name = "campus.seed-sample", havingValue = "true")
    ApplicationRunner sampleEvent(CampusEvents events) {
        return args -> events.seedExample();
    }
}
