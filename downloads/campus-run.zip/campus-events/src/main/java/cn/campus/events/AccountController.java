package cn.campus.events;

import jakarta.servlet.http.HttpServletRequest;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseCookie;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.time.Duration;
import java.util.List;

@RestController
@RequestMapping("/api/account")
final class AccountController {
    private static final String COOKIE = ParticipantAccounts.COOKIE;

    private final ParticipantAccounts accounts;
    private final CampusEvents events;

    AccountController(ParticipantAccounts accounts, CampusEvents events) {
        this.accounts = accounts;
        this.events = events;
    }

    @PostMapping("/register")
    ResponseEntity<ParticipantAccounts.Account> register(
            @RequestBody ParticipantAccounts.Register input,
            @CookieValue(value = COOKIE, required = false) String previousToken,
            HttpServletRequest request) {
        ParticipantAccounts.Account account = accounts.create(input);
        return response(account, previousToken, request.isSecure(), HttpStatus.CREATED);
    }

    @PostMapping("/login")
    ResponseEntity<ParticipantAccounts.Account> login(
            @RequestBody ParticipantAccounts.Login input,
            @CookieValue(value = COOKIE, required = false) String previousToken,
            HttpServletRequest request) {
        ParticipantAccounts.Account account = accounts.authenticate(input);
        return response(account, previousToken, request.isSecure(), HttpStatus.OK);
    }

    @GetMapping("/session")
    ParticipantAccounts.Profile session(@CookieValue(value = COOKIE, required = false) String token) {
        return accounts.profile(accounts.require(token));
    }

    @PostMapping("/tour/start")
    TourStart startTour(@CookieValue(value = COOKIE, required = false) String token) {
        return new TourStart(accounts.startTour(accounts.require(token)));
    }

    record TourStart(boolean started) {}

    @DeleteMapping("/session")
    ResponseEntity<Void> logout(@CookieValue(value = COOKIE, required = false) String token,
                                HttpServletRequest request) {
        accounts.end(token);
        return ResponseEntity.noContent().header(HttpHeaders.SET_COOKIE, cookie("", Duration.ZERO, request.isSecure())).build();
    }

    @GetMapping("/registrations")
    List<CampusEvents.MyRegistration> registrations(@CookieValue(value = COOKIE, required = false) String token) {
        return events.myRegistrations(accounts.require(token));
    }

    private ResponseEntity<ParticipantAccounts.Account> response(ParticipantAccounts.Account account,
            String previousToken, boolean secure, HttpStatus status) {
        String value = accounts.begin(account, previousToken);
        return ResponseEntity.status(status)
                .header(HttpHeaders.SET_COOKIE, cookie(value, ParticipantAccounts.SESSION_LIFETIME, secure))
                .body(account);
    }

    private static String cookie(String value, Duration expiry, boolean secure) {
        return ResponseCookie.from(COOKIE, value)
                .path("/api")
                .httpOnly(true)
                .secure(secure)
                .sameSite("Strict")
                .maxAge(expiry)
                .build()
                .toString();
    }
}
