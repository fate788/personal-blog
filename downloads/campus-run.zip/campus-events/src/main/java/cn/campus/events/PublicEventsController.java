package cn.campus.events;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/events")
final class PublicEventsController {
    private static final String COOKIE = ParticipantAccounts.COOKIE;

    private final CampusEvents events;
    private final ParticipantAccounts accounts;

    PublicEventsController(CampusEvents events, ParticipantAccounts accounts) {
        this.events = events;
        this.accounts = accounts;
    }

    @GetMapping
    List<CampusEvents.Event> list() {
        return events.publishedEvents();
    }

    @GetMapping("/{id}")
    CampusEvents.Event event(@PathVariable long id) {
        return events.publishedEvent(id);
    }

    @PostMapping("/{id}/registrations")
    @ResponseStatus(HttpStatus.CREATED)
    CampusEvents.RegistrationView register(@PathVariable long id,
            @CookieValue(value = COOKIE, required = false) String token) {
        return events.register(id, accounts.require(token));
    }

    @GetMapping("/{id}/registration")
    CampusEvents.RegistrationView ownRegistration(@PathVariable long id,
            @CookieValue(value = COOKIE, required = false) String token) {
        return events.ownRegistration(id, accounts.require(token));
    }

    @DeleteMapping("/{id}/registration")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    void cancel(@PathVariable long id, @CookieValue(value = COOKIE, required = false) String token) {
        events.cancel(id, accounts.require(token));
    }

    @PostMapping("/{id}/self-check-in")
    CampusEvents.RegistrationView selfCheckIn(@PathVariable long id,
            @CookieValue(value = COOKIE, required = false) String token, @RequestBody SelfCheckIn input) {
        return events.selfCheckIn(id, accounts.require(token), input.code());
    }

    record SelfCheckIn(String code) {}
}
