package cn.campus.events;

import org.springframework.dao.DuplicateKeyException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.security.MessageDigest;
import java.sql.Statement;
import java.time.Duration;
import java.time.Instant;
import java.util.HexFormat;
import java.util.Objects;
import java.util.concurrent.ConcurrentHashMap;

@Service
class ParticipantAccounts {
    static final String COOKIE = "campus_participant";
    static final Duration SESSION_LIFETIME = Duration.ofHours(12);
    private static final HexFormat HEX = HexFormat.of();

    private final JdbcTemplate database;
    private final AccountPasswords passwords;
    private final byte[] dummySalt = Secrets.randomBytes(16);
    private final ConcurrentHashMap<String, Session> active = new ConcurrentHashMap<>();

    ParticipantAccounts(JdbcTemplate database, AccountPasswords passwords) {
        this.database = database;
        this.passwords = passwords;
    }

    @Transactional
    public Account create(Register input) {
        String name = CampusEvents.required(input.name(), 60, "参与者姓名");
        String identifier = CampusEvents.identifier(input.identifier());
        String password = AccountPasswords.validate(input.password());
        byte[] salt = Secrets.randomBytes(16);
        String digest = HEX.formatHex(passwords.derive(password, salt));
        var key = new GeneratedKeyHolder();
        try {
            database.update(connection -> {
                var insert = connection.prepareStatement("""
                        INSERT INTO participant_account (name, identifier, password_salt, password_digest)
                        VALUES (?, ?, ?, ?)
                        """, Statement.RETURN_GENERATED_KEYS);
                insert.setString(1, name);
                insert.setString(2, identifier);
                insert.setString(3, HEX.formatHex(salt));
                insert.setString(4, digest);
                return insert;
            }, key);
        } catch (DuplicateKeyException error) {
            throw ApiException.conflict("该参与者编号已注册，请直接登录。");
        }
        long id = Objects.requireNonNull(key.getKey()).longValue();
        database.update("INSERT INTO participant_tour_pending (account_id) VALUES (?)", id);
        return new Account(id, name, identifier);
    }

    Account authenticate(Login input) {
        String identifier;
        try {
            identifier = CampusEvents.identifier(input.identifier());
        } catch (ApiException error) {
            throw invalidCredentials();
        }
        if (input.password() == null || input.password().length() > 128) {
            throw invalidCredentials();
        }
        Credentials credentials = database.query("""
                SELECT id, name, identifier, password_salt, password_digest
                FROM participant_account WHERE identifier = ?
                """, (row, index) -> new Credentials(
                new Account(row.getLong("id"), row.getString("name"), row.getString("identifier")),
                HEX.parseHex(row.getString("password_salt")), HEX.parseHex(row.getString("password_digest"))),
                identifier).stream().findFirst().orElse(null);
        byte[] digest = passwords.derive(input.password(), credentials == null ? dummySalt : credentials.salt());
        if (credentials == null || !MessageDigest.isEqual(digest, credentials.digest())) {
            throw invalidCredentials();
        }
        return credentials.account();
    }

    String begin(Account account, String previousToken) {
        end(previousToken);
        Instant now = Instant.now();
        active.entrySet().removeIf(entry -> !entry.getValue().expiry().isAfter(now));
        String token = Secrets.newToken();
        active.put(Secrets.tokenDigest(token), new Session(account, now.plus(SESSION_LIFETIME)));
        return token;
    }

    Account require(String token) {
        String digest = Secrets.tokenDigest(token);
        Session session = digest == null ? null : active.get(digest);
        if (session == null || !session.expiry().isAfter(Instant.now())) {
            throw ApiException.unauthorized("请先登录参与者账号。");
        }
        return session.account();
    }

    void end(String token) {
        String digest = Secrets.tokenDigest(token);
        if (digest != null) {
            active.remove(digest);
        }
    }

    Profile profile(Account account) {
        boolean pending = Boolean.TRUE.equals(database.queryForObject(
            "SELECT COUNT(*) > 0 FROM participant_tour_pending WHERE account_id = ?", Boolean.class, account.id()));
        return new Profile(account.id(), account.name(), account.identifier(), pending);
    }

    boolean startTour(Account account) {
        return database.update("DELETE FROM participant_tour_pending WHERE account_id = ?", account.id()) == 1;
    }

    private static ApiException invalidCredentials() {
        return ApiException.unauthorized("参与者编号或密码不正确。");
    }

    record Register(String name, String identifier, String password) {}
    record Login(String identifier, String password) {}
    record Account(long id, String name, String identifier) {}
    record Profile(long id, String name, String identifier, boolean tourPending) {}
    private record Credentials(Account account, byte[] salt, byte[] digest) {}
    private record Session(Account account, Instant expiry) {}
}
