package cn.campus.events;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.temporal.ChronoUnit;
import java.util.Objects;

record EventSchedule(int durationMinutes, int checkInOpensBeforeMinutes, int checkInClosesAfterMinutes,
                     Instant startsAtInstant) {
    static final ZoneId CAMPUS_ZONE = ZoneId.of("Asia/Shanghai");

    EventSchedule {
        if (durationMinutes < 1 || durationMinutes > 1440) {
            throw ApiException.invalid("活动时长应为 1 至 1440 分钟。");
        }
        if (checkInOpensBeforeMinutes < 0 || checkInOpensBeforeMinutes > 1440) {
            throw ApiException.invalid("签到可在活动开始前 0 至 1440 分钟开放。");
        }
        if (checkInClosesAfterMinutes < 1 || checkInClosesAfterMinutes > durationMinutes) {
            throw ApiException.invalid("签到截止时间须在活动开始至少 1 分钟后，且不能晚于活动结束。");
        }
    }

    record Input(Integer durationMinutes, Integer checkInOpensBeforeMinutes, Integer checkInClosesAfterMinutes) {
        EventSchedule resolve(LocalDateTime startsAt, EventSchedule previous) {
            int duration = Objects.requireNonNullElse(durationMinutes, previous == null ? 120 : previous.durationMinutes);
            int before = Objects.requireNonNullElse(checkInOpensBeforeMinutes,
                    previous == null ? 15 : previous.checkInOpensBeforeMinutes);
            int after = Objects.requireNonNullElse(checkInClosesAfterMinutes,
                    previous == null ? Math.min(30, duration) : previous.checkInClosesAfterMinutes);
            return new EventSchedule(duration, before, after, startsAt.atZone(CAMPUS_ZONE).toInstant());
        }
    }

    @JsonProperty
    public Instant endsAt() {
        return startsAtInstant.plus(durationMinutes, ChronoUnit.MINUTES);
    }

    @JsonProperty
    public Instant checkInOpensAt() {
        return startsAtInstant.minus(checkInOpensBeforeMinutes, ChronoUnit.MINUTES);
    }

    @JsonProperty
    public Instant checkInClosesAt() {
        return startsAtInstant.plus(checkInClosesAfterMinutes, ChronoUnit.MINUTES);
    }

    void requireOpen(Instant now) {
        if (now.isBefore(checkInOpensAt())) {
            throw ApiException.conflict("未到本场活动的签到开放时间。");
        }
        if (!now.isBefore(checkInClosesAt())) {
            throw ApiException.conflict("本场活动的签到时段已结束。");
        }
    }
}
