package cn.campus.events;

import jakarta.servlet.http.HttpServletRequest;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseCookie;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import java.time.Duration;
import java.util.List;

@RestController
@RequestMapping("/api/organizer")
final class OrganizerController {
    private static final String COOKIE = OrganizerAccounts.COOKIE;

    private final CampusEvents events;
    private final OrganizerAccounts accounts;

    OrganizerController(CampusEvents events, OrganizerAccounts accounts) {
        this.events = events;
        this.accounts = accounts;
    }

    @PostMapping("/register")
    ResponseEntity<OrganizerAccounts.Account> register(@RequestBody OrganizerAccounts.Register input,
            @CookieValue(value = COOKIE, required = false) String previousToken, HttpServletRequest request) {
        OrganizerAccounts.Account account = accounts.create(input);
        return started(account, previousToken, request.isSecure(), HttpStatus.CREATED);
    }

    @PostMapping("/login")
    ResponseEntity<OrganizerAccounts.Account> login(@RequestBody OrganizerAccounts.Login input,
            @CookieValue(value = COOKIE, required = false) String previousToken, HttpServletRequest request) {
        OrganizerAccounts.Account account = accounts.authenticate(input, request.getRemoteAddr());
        return started(account, previousToken, request.isSecure(), HttpStatus.OK);
    }

    @GetMapping("/session")
    OrganizerAccounts.WorkspaceSession session(@CookieValue(value = COOKIE, required = false) String token) {
        return accounts.workspaceSession(token);
    }

    @PostMapping("/tour/start")
    TourStart startTour(@CookieValue(value = COOKIE, required = false) String token) {
        return new TourStart(accounts.startTour(organizerId(token)));
    }

    @DeleteMapping("/session")
    ResponseEntity<Void> logout(@CookieValue(value = COOKIE, required = false) String token, HttpServletRequest request) {
        accounts.end(token);
        return ResponseEntity.noContent().header(HttpHeaders.SET_COOKIE, cookie("", Duration.ZERO, request.isSecure())).build();
    }

    @GetMapping("/legacy")
    CampusEvents.LegacyStatus legacy(@CookieValue(value = COOKIE, required = false) String token) {
        accounts.require(token);
        return events.legacyStatus();
    }

    @PostMapping("/claim-legacy")
    CampusEvents.LegacyClaim claimLegacy(@CookieValue(value = COOKIE, required = false) String token,
                                        @RequestBody LegacyPassword input, HttpServletRequest request) {
        long owner = organizerId(token);
        accounts.checkAttemptBudget("legacy:" + request.getRemoteAddr());
        return events.claimLegacy(owner, input.password());
    }

    @GetMapping("/events")
    List<CampusEvents.Event> list(@CookieValue(value = COOKIE, required = false) String token) {
        return events.organizerEvents(organizerId(token));
    }

    @PostMapping("/events")
    @ResponseStatus(HttpStatus.CREATED)
    CampusEvents.Event create(@CookieValue(value = COOKIE, required = false) String token,
                              @RequestBody CampusEvents.NewEvent input) {
        return events.createEvent(organizerId(token), input);
    }

    @PatchMapping("/events/{id}/schedule")
    CampusEvents.Event updateSchedule(@CookieValue(value = COOKIE, required = false) String token,
                                      @PathVariable long id, @RequestBody EventSchedule.Input input) {
        return events.updateSchedule(organizerId(token), id, input);
    }

    @PostMapping("/events/{id}/publish")
    CampusEvents.Event publish(@CookieValue(value = COOKIE, required = false) String token, @PathVariable long id) {
        return events.publishEvent(organizerId(token), id);
    }

    @GetMapping("/events/{id}/registrations")
    List<CampusEvents.RosterEntry> roster(@CookieValue(value = COOKIE, required = false) String token,
                                         @PathVariable long id) {
        return events.roster(organizerId(token), id);
    }

    @PostMapping("/events/{eventId}/registrations/{id}/check-in")
    CampusEvents.RosterEntry checkIn(@CookieValue(value = COOKIE, required = false) String token,
                                     @PathVariable long eventId, @PathVariable long id) {
        return events.checkIn(organizerId(token), eventId, id);
    }

    @PostMapping("/events/{id}/check-in-window")
    CampusEvents.CheckInWindow openCheckIn(@CookieValue(value = COOKIE, required = false) String token,
                                         @PathVariable long id) {
        return events.openCheckIn(organizerId(token), id);
    }

    @DeleteMapping("/events/{id}/check-in-window")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    void closeCheckIn(@CookieValue(value = COOKIE, required = false) String token, @PathVariable long id) {
        events.closeCheckIn(organizerId(token), id);
    }

    private long organizerId(String token) {
        return accounts.require(token).id();
    }

    private ResponseEntity<OrganizerAccounts.Account> started(OrganizerAccounts.Account account,
            String previousToken, boolean secure, HttpStatus status) {
        String token = accounts.begin(account, previousToken);
        return ResponseEntity.status(status)
                .header(HttpHeaders.SET_COOKIE, cookie(token, OrganizerAccounts.SESSION_LIFETIME, secure))
                .body(account);
    }

    private static String cookie(String value, Duration expiry, boolean secure) {
        return ResponseCookie.from(COOKIE, value)
                .path("/api/organizer")
                .httpOnly(true)
                .secure(secure)
                .sameSite("Strict")
                .maxAge(expiry)
                .build().toString();
    }

    record LegacyPassword(String password) {}
    record TourStart(boolean started) {}
}
