package cn.campus.events;

import org.springframework.dao.DuplicateKeyException;
import org.springframework.http.HttpStatus;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.security.MessageDigest;
import java.sql.Statement;
import java.time.Duration;
import java.time.Instant;
import java.util.HashMap;
import java.util.HexFormat;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Pattern;

@Service
class OrganizerAccounts {
    static final String COOKIE = "campus_organizer";
    static final Duration SESSION_LIFETIME = Duration.ofHours(8);
    private static final Pattern USERNAME = Pattern.compile("[A-Za-z0-9][A-Za-z0-9._-]{2,39}");
    private static final HexFormat HEX = HexFormat.of();
    private static final int LOGIN_BUDGET = 24;
    private static final int MAX_SOURCE_ENTRIES = 10_000;
    private static final Duration LOGIN_INTERVAL = Duration.ofMinutes(5);

    private final JdbcTemplate database;
    private final AccountPasswords passwords;
    private final byte[] dummySalt = Secrets.randomBytes(16);
    private final ConcurrentHashMap<String, Session> active = new ConcurrentHashMap<>();
    private final Map<String, LoginWindow> loginWindows = new HashMap<>();
    private Instant nextCleanup = Instant.EPOCH;

    OrganizerAccounts(JdbcTemplate database, AccountPasswords passwords) {
        this.database = database;
        this.passwords = passwords;
    }

    @Transactional
    Account create(Register input) {
        String name = CampusEvents.required(input.name(), 60, "组织者姓名");
        String username = normalize(input.username());
        if (username == null) {
            throw ApiException.invalid("用户名需以字母或数字开头，共 3 至 40 个字符，可含点、下划线和横线。");
        }
        String password = AccountPasswords.validate(input.password());
        byte[] salt = Secrets.randomBytes(16);
        String digest = HEX.formatHex(passwords.derive(password, salt));
        var key = new GeneratedKeyHolder();
        try {
            database.update(connection -> {
                var insert = connection.prepareStatement("""
                        INSERT INTO organizer_account (name, username, password_salt, password_digest)
                        VALUES (?, ?, ?, ?)
                        """, Statement.RETURN_GENERATED_KEYS);
                insert.setString(1, name);
                insert.setString(2, username);
                insert.setString(3, HEX.formatHex(salt));
                insert.setString(4, digest);
                return insert;
            }, key);
        } catch (DuplicateKeyException error) {
            throw ApiException.conflict("该用户名已注册，请登录或选择其他用户名。");
        }
        long id = Objects.requireNonNull(key.getKey()).longValue();
        database.update("INSERT INTO organizer_pending_tour (organizer_id) VALUES (?)", id);
        return new Account(id, name, username);
    }

    WorkspaceSession workspaceSession(String token) {
        Account account = require(token);
        boolean pending = !database.queryForList(
                "SELECT organizer_id FROM organizer_pending_tour WHERE organizer_id = ?", Long.class, account.id()).isEmpty();
        return new WorkspaceSession(account.id(), account.name(), account.username(), pending);
    }

    boolean startTour(long organizerId) {
        return database.update("DELETE FROM organizer_pending_tour WHERE organizer_id = ?", organizerId) == 1;
    }

    Account authenticate(Login input, String source) {
        String username = normalize(input.username());
        if (username == null || input.password() == null || input.password().length() > 128) {
            throw invalidCredentials();
        }
        checkAttemptBudget("login:" + source);
        Credentials saved = database.query("""
                SELECT id, name, username, password_salt, password_digest
                FROM organizer_account WHERE username = ?
                """, (row, index) -> new Credentials(
                new Account(row.getLong("id"), row.getString("name"), row.getString("username")),
                HEX.parseHex(row.getString("password_salt")), HEX.parseHex(row.getString("password_digest"))),
                username).stream().findFirst().orElse(null);
        byte[] digest = passwords.derive(input.password(), saved == null ? dummySalt : saved.salt());
        if (saved == null || !MessageDigest.isEqual(digest, saved.digest())) {
            throw invalidCredentials();
        }
        return saved.account();
    }

    String begin(Account account, String previousToken) {
        end(previousToken);
        Instant now = Instant.now();
        active.entrySet().removeIf(entry -> !entry.getValue().expiry().isAfter(now));
        String token = Secrets.newToken();
        active.put(Secrets.tokenDigest(token), new Session(account, now.plus(SESSION_LIFETIME)));
        return token;
    }

    Account require(String token) {
        String digest = Secrets.tokenDigest(token);
        Session session = digest == null ? null : active.get(digest);
        if (session == null || !session.expiry().isAfter(Instant.now())) {
            throw ApiException.unauthorized("请先登录组织者账号。");
        }
        return session.account();
    }

    void end(String token) {
        String digest = Secrets.tokenDigest(token);
        if (digest != null) {
            active.remove(digest);
        }
    }

    synchronized void checkAttemptBudget(String source) {
        Instant now = Instant.now();
        if (!nextCleanup.isAfter(now)) {
            loginWindows.values().removeIf(window -> !window.expiry().isAfter(now));
            nextCleanup = now.plus(LOGIN_INTERVAL);
        }
        LoginWindow window = loginWindows.get(source);
        if (window == null || !window.expiry().isAfter(now)) {
            if (window == null && loginWindows.size() >= MAX_SOURCE_ENTRIES) {
                throw tooManyAttempts();
            }
            window = new LoginWindow(now.plus(LOGIN_INTERVAL), 0);
        }
        if (window.attempts() >= LOGIN_BUDGET) {
            throw tooManyAttempts();
        }
        loginWindows.put(source, new LoginWindow(window.expiry(), window.attempts() + 1));
    }

    private static String normalize(String input) {
        String cleaned = input == null ? "" : input.strip();
        return USERNAME.matcher(cleaned).matches() ? cleaned.toLowerCase(Locale.ROOT) : null;
    }

    private static ApiException invalidCredentials() {
        return ApiException.unauthorized("用户名或密码不正确。");
    }

    private static ApiException tooManyAttempts() {
        return new ApiException(HttpStatus.TOO_MANY_REQUESTS, "当前网络登录请求较多，请约 5 分钟后重试。");
    }

    record Register(String name, String username, String password) {}
    record Login(String username, String password) {}
    record Account(long id, String name, String username) {}
    record WorkspaceSession(long id, String name, String username, boolean tourPending) {}
    private record Credentials(Account account, byte[] salt, byte[] digest) {}
    private record Session(Account account, Instant expiry) {}
    private record LoginWindow(Instant expiry, int attempts) {}
}
