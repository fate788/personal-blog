package cn.campus.events;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;
import java.security.GeneralSecurityException;
import java.util.Arrays;
import java.util.concurrent.Semaphore;

@Component
final class AccountPasswords {
    private static final int ITERATIONS = 600_000;
    private final Semaphore slots = new Semaphore(4);

    static String validate(String password) {
        if (password == null || password.length() < 8 || password.length() > 128) {
            throw ApiException.invalid("请使用 8 至 128 个字符的密码。");
        }
        return password;
    }

    byte[] derive(String password, byte[] salt) {
        if (!slots.tryAcquire()) {
            throw new ApiException(HttpStatus.TOO_MANY_REQUESTS, "登录或注册请求较多，请稍后再试。");
        }
        char[] characters = password.toCharArray();
        PBEKeySpec specification = new PBEKeySpec(characters, salt, ITERATIONS, 256);
        try {
            return SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(specification).getEncoded();
        } catch (GeneralSecurityException error) {
            throw new IllegalStateException("PBKDF2-HMAC-SHA-256 is unavailable", error);
        } finally {
            specification.clearPassword();
            Arrays.fill(characters, '\0');
            slots.release();
        }
    }
}
