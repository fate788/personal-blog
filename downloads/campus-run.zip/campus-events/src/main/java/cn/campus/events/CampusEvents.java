package cn.campus.events;

import com.fasterxml.jackson.annotation.JsonUnwrapped;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.http.HttpStatus;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Transactional;

import java.security.MessageDigest;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.Instant;
import java.time.LocalDateTime;
import java.util.HexFormat;
import java.util.List;
import java.util.Locale;
import java.util.Objects;
import java.util.Optional;
import java.util.regex.Pattern;

@Service
class CampusEvents {
    private static final int MAX_CAPACITY = 10_000;
    private static final int MAX_FAILED_CHECK_INS = 5;
    private static final Pattern IDENTIFIER = Pattern.compile("[A-Za-z0-9][A-Za-z0-9._-]{0,39}");
    private static final Pattern CHECK_IN_CODE = Pattern.compile("[0-9]{6}");
    private static final String EVENT_COLUMNS = """
            SELECT e.*, s.duration_minutes, s.check_in_opens_before_minutes, s.check_in_closes_after_minutes, (
                SELECT COUNT(*) FROM event_registration r
                WHERE r.event_id = e.id AND r.status <> 'CANCELLED'
            ) AS confirmed
            """;
    private static final String EVENT_SCHEDULE_JOIN = " LEFT JOIN event_schedule s ON s.event_id = e.id ";
    private static final String EVENT_DETAILS = EVENT_COLUMNS + "FROM campus_event e" + EVENT_SCHEDULE_JOIN;
    private static final RowMapper<Event> EVENT_MAPPER = (row, index) -> {
        int capacity = row.getInt("capacity");
        int confirmed = row.getInt("confirmed");
        LocalDateTime startsAt = row.getObject("starts_at", LocalDateTime.class);
        return new Event(row.getLong("id"), row.getString("title"), row.getString("description"),
                startsAt, row.getString("location"), capacity, confirmed, capacity - confirmed,
                EventStatus.valueOf(row.getString("status")), mapSchedule(row, startsAt));
    };
    private static final RowMapper<RosterEntry> ROSTER_MAPPER = (row, index) -> new RosterEntry(
            row.getLong("id"), row.getLong("event_id"), row.getString("name"), row.getString("identifier"),
            RegistrationStatus.valueOf(row.getString("status")));

    private final JdbcTemplate database;
    private final int checkInSeconds;
    private final byte[] checkInSecret;
    private final byte[] legacyPasswordDigest;

    CampusEvents(JdbcTemplate database, @Value("${campus.check-in-seconds}") int checkInSeconds,
                 @Value("${campus.check-in-secret}") String checkInSecret,
                 @Value("${campus.organizer.legacy-password}") String legacyPassword) {
        if (checkInSeconds < 1 || checkInSeconds > 300) {
            throw new IllegalArgumentException("campus.check-in-seconds must be between 1 and 300");
        }
        this.database = database;
        this.checkInSeconds = checkInSeconds;
        this.checkInSecret = checkInSecret.isBlank() ? Secrets.randomBytes(32)
                : Secrets.sha256("campus-check-in:" + checkInSecret);
        this.legacyPasswordDigest = legacyPassword.isBlank() ? null : Secrets.sha256(legacyPassword);
    }

    List<Event> publishedEvents() {
        return database.query(EVENT_DETAILS + "WHERE e.status = 'PUBLISHED' ORDER BY e.starts_at, e.id", EVENT_MAPPER);
    }

    List<Event> organizerEvents(long organizerId) {
        return database.query(EVENT_DETAILS + """
                JOIN event_organizer eo ON eo.event_id = e.id
                WHERE eo.organizer_id = ?
                ORDER BY e.starts_at, e.id
                """, EVENT_MAPPER, organizerId);
    }

    Event publishedEvent(long id) {
        return queryEvent(id).filter(event -> event.status() == EventStatus.PUBLISHED)
                .orElseThrow(CampusEvents::eventMissing);
    }

    @Transactional
    public Event createEvent(long organizerId, NewEvent input) {
        long eventId = insertEvent(input);
        database.update("INSERT INTO event_organizer (event_id, organizer_id) VALUES (?, ?)", eventId, organizerId);
        return organizerEvent(eventId);
    }

    private long insertEvent(NewEvent input) {
        String title = required(input.title(), 120, "活动名称");
        String description = input.description() == null ? "" : input.description().strip();
        if (description.length() > 1000) {
            throw ApiException.invalid("活动说明最多 1000 个字符。");
        }
        if (input.startsAt() == null || input.startsAt().getYear() < 1000 || input.startsAt().getYear() > 9999) {
            throw ApiException.invalid("请填写有效的活动开始时间。");
        }
        String location = required(input.location(), 120, "活动地点");
        if (input.capacity() == null || input.capacity() < 1 || input.capacity() > MAX_CAPACITY) {
            throw ApiException.invalid("活动名额需要在 1 至 10000 之间。");
        }

        EventSchedule schedule = new EventSchedule.Input(input.durationMinutes(), input.checkInOpensBeforeMinutes(),
                input.checkInClosesAfterMinutes()).resolve(input.startsAt(), null);
        var key = new GeneratedKeyHolder();
        database.update(connection -> {
            var insert = connection.prepareStatement("""
                    INSERT INTO campus_event (title, description, starts_at, location, capacity, status)
                    VALUES (?, ?, ?, ?, ?, 'DRAFT')
                    """, Statement.RETURN_GENERATED_KEYS);
            insert.setString(1, title);
            insert.setString(2, description);
            insert.setObject(3, input.startsAt());
            insert.setString(4, location);
            insert.setInt(5, input.capacity());
            return insert;
        }, key);
        long id = Objects.requireNonNull(key.getKey()).longValue();
        insertSchedule(id, schedule);
        return id;
    }

    private void insertSchedule(long eventId, EventSchedule schedule) {
        database.update("""
                INSERT INTO event_schedule (event_id, duration_minutes, check_in_opens_before_minutes, check_in_closes_after_minutes)
                VALUES (?, ?, ?, ?)
                """, eventId, schedule.durationMinutes(), schedule.checkInOpensBeforeMinutes(), schedule.checkInClosesAfterMinutes());
    }

    @Transactional(isolation = Isolation.READ_COMMITTED)
    public Event updateSchedule(long organizerId, long eventId, EventSchedule.Input input) {
        LockedEvent event = lockOrganizerEvent(organizerId, eventId, false);
        if (input.durationMinutes() == null && input.checkInOpensBeforeMinutes() == null && input.checkInClosesAfterMinutes() == null) {
            throw ApiException.invalid("请填写要设置的活动时长或签到时段。");
        }
        EventSchedule previous = readSchedule(eventId, event.startsAt());
        EventSchedule revised = input.resolve(event.startsAt(), previous);
        if (!revised.equals(previous)) {
            if (previous == null) {
                insertSchedule(eventId, revised);
            } else {
                database.update("""
                        UPDATE event_schedule SET duration_minutes = ?, check_in_opens_before_minutes = ?,
                            check_in_closes_after_minutes = ? WHERE event_id = ?
                        """, revised.durationMinutes(), revised.checkInOpensBeforeMinutes(), revised.checkInClosesAfterMinutes(), eventId);
            }
            invalidateCheckInWindow(eventId);
        }
        return organizerEvent(eventId);
    }

    private static EventSchedule mapSchedule(ResultSet row, LocalDateTime startsAt) throws SQLException {
        Integer duration = row.getObject("duration_minutes", Integer.class);
        return duration == null ? null : new EventSchedule(duration, row.getInt("check_in_opens_before_minutes"),
                row.getInt("check_in_closes_after_minutes"), startsAt.atZone(EventSchedule.CAMPUS_ZONE).toInstant());
    }

    private EventSchedule readSchedule(long eventId, LocalDateTime startsAt) {
        return database.query("""
                SELECT duration_minutes, check_in_opens_before_minutes, check_in_closes_after_minutes
                FROM event_schedule WHERE event_id = ?
                """, (row, index) -> mapSchedule(row, startsAt), eventId).stream().findFirst().orElse(null);
    }

    @Transactional(isolation = Isolation.READ_COMMITTED)
    public Event publishEvent(long organizerId, long eventId) {
        lockOrganizerEvent(organizerId, eventId, false);
        return setPublished(eventId);
    }

    private Event setPublished(long eventId) {
        database.update("UPDATE campus_event SET status = 'PUBLISHED' WHERE id = ?", eventId);
        return organizerEvent(eventId);
    }

    @Transactional(isolation = Isolation.READ_COMMITTED)
    public RegistrationView register(long eventId, ParticipantAccounts.Account account) {
        String name = account.name();
        String identifier = account.identifier();

        LockedEvent event = lockEvent(eventId, true);
        Optional<RosterEntry> existing = database.query("""
                SELECT id, event_id, name, identifier, status FROM event_registration
                WHERE event_id = ? AND identifier = ?
                """, ROSTER_MAPPER, eventId, identifier).stream().findFirst();
        if (existing.isPresent()) {
            RosterEntry row = existing.get();
            if (ownedRegistration(eventId, account.id()).isEmpty()) {
                throw ApiException.conflict("该编号已有旧版报名，请联系组织者确认。");
            }
            if (row.status() != RegistrationStatus.CANCELLED) {
                throw ApiException.conflict("你已经报名，无需重复提交。");
            }
        }

        EventSchedule schedule = readSchedule(eventId, event.startsAt());
        if (schedule != null && !Instant.now().isBefore(schedule.endsAt())) {
            throw ApiException.conflict("活动已结束，报名已截止。");
        }

        int confirmed = database.queryForObject("""
                SELECT COUNT(*) FROM event_registration
                WHERE event_id = ? AND status <> 'CANCELLED'
                """, Integer.class, eventId);
        if (confirmed >= event.capacity()) {
            throw ApiException.conflict("活动名额已满。");
        }

        long registrationId;
        if (existing.isPresent()) {
            registrationId = existing.get().id();
            database.update("""
                    UPDATE event_registration
                    SET name = ?, status = 'REGISTERED', registered_at = CURRENT_TIMESTAMP,
                        checked_in_at = NULL, cancelled_at = NULL
                    WHERE id = ?
                    """, name, registrationId);
        } else {
            String digest = Secrets.tokenDigest(Secrets.newToken());
            var key = new GeneratedKeyHolder();
            database.update(connection -> {
                var insert = connection.prepareStatement("""
                        INSERT INTO event_registration (event_id, name, identifier, status, token_digest, registered_at)
                        VALUES (?, ?, ?, 'REGISTERED', ?, CURRENT_TIMESTAMP)
                        """, Statement.RETURN_GENERATED_KEYS);
                insert.setLong(1, eventId);
                insert.setString(2, name);
                insert.setString(3, identifier);
                insert.setString(4, digest);
                return insert;
            }, key);
            registrationId = Objects.requireNonNull(key.getKey()).longValue();
            database.update("""
                    INSERT INTO event_registration_owner (registration_id, account_id) VALUES (?, ?)
                    """, registrationId, account.id());
        }
        return new RegistrationView(registrationId, eventId, name, RegistrationStatus.REGISTERED);
    }

    RegistrationView ownRegistration(long eventId, ParticipantAccounts.Account account) {
        return view(ownedRegistration(eventId, account.id()).orElseThrow(CampusEvents::registrationMissing));
    }

    List<MyRegistration> myRegistrations(ParticipantAccounts.Account account) {
        return database.query(EVENT_COLUMNS + """
                , r.status AS registration_status
                FROM event_registration_owner o
                JOIN event_registration r ON r.id = o.registration_id
                JOIN campus_event e ON e.id = r.event_id
                """ + EVENT_SCHEDULE_JOIN + """
                WHERE o.account_id = ? AND e.status = 'PUBLISHED'
                ORDER BY e.starts_at, e.id
                """, (row, index) -> new MyRegistration(EVENT_MAPPER.mapRow(row, index),
                RegistrationStatus.valueOf(row.getString("registration_status"))), account.id());
    }

    @Transactional(isolation = Isolation.READ_COMMITTED)
    public void cancel(long eventId, ParticipantAccounts.Account account) {
        lockEvent(eventId, true);
        RosterEntry entry = ownedRegistration(eventId, account.id()).orElseThrow(CampusEvents::registrationMissing);
        if (entry.status() == RegistrationStatus.CHECKED_IN) {
            throw ApiException.conflict("已签到的报名请由组织者处理。");
        }
        if (entry.status() == RegistrationStatus.REGISTERED) {
            database.update("""
                    UPDATE event_registration SET status = 'CANCELLED', cancelled_at = CURRENT_TIMESTAMP
                    WHERE id = ?
                    """, entry.id());
        }
    }

    List<RosterEntry> roster(long organizerId, long eventId) {
        requireOrganizerEvent(organizerId, eventId);
        return database.query("""
                SELECT id, event_id, name, identifier, status FROM event_registration
                WHERE event_id = ? ORDER BY registered_at, id
                """, ROSTER_MAPPER, eventId);
    }

    @Transactional(isolation = Isolation.READ_COMMITTED)
    public RosterEntry checkIn(long organizerId, long eventId, long registrationId) {
        lockOrganizerEvent(organizerId, eventId, true);
        RosterEntry entry = database.query("""
                SELECT id, event_id, name, identifier, status FROM event_registration
                WHERE event_id = ? AND id = ?
                """, ROSTER_MAPPER, eventId, registrationId).stream().findFirst()
                .orElseThrow(CampusEvents::registrationMissing);
        return markCheckedIn(entry);
    }

    @Transactional(isolation = Isolation.READ_COMMITTED)
    public CheckInWindow openCheckIn(long organizerId, long eventId) {
        LockedEvent event = lockOrganizerEvent(organizerId, eventId, true);
        Optional<ActiveWindow> previous = checkInWindow(eventId);
        EventSchedule schedule = readSchedule(eventId, event.startsAt());
        Instant now = Instant.now();
        Instant expiry = Instant.ofEpochMilli(now.toEpochMilli()).plusSeconds(checkInSeconds);
        if (schedule != null) {
            schedule.requireOpen(now);
            if (schedule.checkInClosesAt().isBefore(expiry)) expiry = schedule.checkInClosesAt();
        }
        database.update("DELETE FROM event_check_in_code_lease WHERE expires_at_ms <= ?", now.toEpochMilli());
        String code = reserveCheckInCode(previous, expiry);
        String digest = HexFormat.of().formatHex(Secrets.checkInDigest(checkInSecret, code));
        if (previous.isPresent()) {
            database.update("UPDATE event_check_in_window SET code_digest = ?, expires_at_ms = ? WHERE event_id = ?",
                    digest, expiry.toEpochMilli(), eventId);
        } else {
            database.update("""
                    INSERT INTO event_check_in_window (event_id, code_digest, expires_at_ms) VALUES (?, ?, ?)
                    """, eventId, digest, expiry.toEpochMilli());
        }
        database.update("DELETE FROM event_check_in_attempt WHERE event_id = ?", eventId);
        return new CheckInWindow(eventId, code, expiry);
    }

    private String reserveCheckInCode(Optional<ActiveWindow> previous, Instant expiry) {
        for (int attempt = 0; attempt < 20; attempt++) {
            String code = Secrets.newCheckInCode();
            byte[] digest = Secrets.checkInDigest(checkInSecret, code);
            if (previous.isPresent() && MessageDigest.isEqual(previous.get().digest(), digest)) {
                continue;
            }
            try {
                database.update("INSERT INTO event_check_in_code_lease (code_digest, expires_at_ms) VALUES (?, ?)",
                        HexFormat.of().formatHex(digest), expiry.toEpochMilli());
                return code;
            } catch (DuplicateKeyException ignored) {
                // Another event reserved this code for a currently valid window.
            }
        }
        throw new ApiException(HttpStatus.SERVICE_UNAVAILABLE, "暂时无法分配签到码，请重新生成。");
    }

    @Transactional(isolation = Isolation.READ_COMMITTED)
    public void closeCheckIn(long organizerId, long eventId) {
        lockOrganizerEvent(organizerId, eventId, true);
        invalidateCheckInWindow(eventId);
    }

    private void invalidateCheckInWindow(long eventId) {
        database.update("UPDATE event_check_in_window SET expires_at_ms = 0 WHERE event_id = ?", eventId);
        database.update("DELETE FROM event_check_in_attempt WHERE event_id = ?", eventId);
    }

    @Transactional(isolation = Isolation.READ_COMMITTED, noRollbackFor = IncorrectCheckInCode.class)
    public RegistrationView selfCheckIn(long eventId, ParticipantAccounts.Account account, String enteredCode) {
        LockedEvent event = lockEvent(eventId, true);
        RosterEntry entry = ownedRegistration(eventId, account.id()).orElseThrow(
                () -> ApiException.conflict("请先报名参加这场活动。"));
        if (entry.status() == RegistrationStatus.CANCELLED) {
            throw ApiException.conflict("该报名已取消，请重新报名后签到。");
        }

        String code = enteredCode == null || enteredCode.length() > 64 ? "" : enteredCode.strip();
        if (!CHECK_IN_CODE.matcher(code).matches()) {
            throw ApiException.invalid("请输入组织者提供的 6 位数字签到码。");
        }
        EventSchedule schedule = readSchedule(eventId, event.startsAt());
        Instant now = Instant.now();
        if (schedule != null) schedule.requireOpen(now);
        ActiveWindow window = checkInWindow(eventId)
                .filter(current -> !current.expiry().equals(Instant.EPOCH))
                .orElseThrow(() -> ApiException.conflict("组织者尚未开放签到或已关闭签到。"));
        if (!window.expiry().isAfter(now)) {
            throw ApiException.conflict("签到码已过期，请使用现场的新签到码。");
        }
        int failed = database.query("""
                SELECT failed_count FROM event_check_in_attempt WHERE event_id = ? AND account_id = ?
                """, (row, index) -> row.getInt("failed_count"), eventId, account.id())
                .stream().findFirst().orElse(0);
        if (failed >= MAX_FAILED_CHECK_INS) {
            throw new ApiException(HttpStatus.TOO_MANY_REQUESTS, "尝试次数已用完，请联系组织者换码或补录签到。");
        }
        if (!MessageDigest.isEqual(window.digest(), Secrets.checkInDigest(checkInSecret, code))) {
            recordFailedCheckIn(eventId, account.id(), failed);
            int remaining = MAX_FAILED_CHECK_INS - failed - 1;
            String message = remaining == 0 ? "签到码不匹配，尝试次数已用完，请联系组织者换码或补录签到。"
                    : "签到码不匹配，还可尝试 " + remaining + " 次。";
            throw new IncorrectCheckInCode(message);
        }
        return view(markCheckedIn(entry));
    }

    private Optional<ActiveWindow> checkInWindow(long eventId) {
        return database.query("""
                SELECT code_digest, expires_at_ms FROM event_check_in_window WHERE event_id = ?
                """, (row, index) -> new ActiveWindow(HexFormat.of().parseHex(row.getString("code_digest")),
                Instant.ofEpochMilli(row.getLong("expires_at_ms"))), eventId).stream().findFirst();
    }

    private void recordFailedCheckIn(long eventId, long accountId, int failed) {
        if (failed == 0) {
            database.update("""
                    INSERT INTO event_check_in_attempt (event_id, account_id, failed_count) VALUES (?, ?, 1)
                    """, eventId, accountId);
        } else {
            database.update("""
                    UPDATE event_check_in_attempt SET failed_count = ?
                    WHERE event_id = ? AND account_id = ?
                    """, failed + 1, eventId, accountId);
        }
    }

    private RosterEntry markCheckedIn(RosterEntry entry) {
        if (entry.status() == RegistrationStatus.CANCELLED) {
            throw ApiException.conflict("已取消的报名不能签到。");
        }
        if (entry.status() == RegistrationStatus.REGISTERED) {
            database.update("""
                    UPDATE event_registration SET status = 'CHECKED_IN', checked_in_at = CURRENT_TIMESTAMP
                    WHERE id = ?
                    """, entry.id());
        }
        return new RosterEntry(entry.id(), entry.eventId(), entry.name(), entry.identifier(), RegistrationStatus.CHECKED_IN);
    }

    @Transactional(isolation = Isolation.READ_COMMITTED)
    public void seedExample() {
        if (!database.queryForList("SELECT id FROM campus_event LIMIT 1", Long.class).isEmpty()) {
            return;
        }
        LocalDateTime when = LocalDateTime.now(EventSchedule.CAMPUS_ZONE)
                .toLocalDate().plusDays(14).atTime(19, 0);
        long eventId = insertEvent(new NewEvent("校园开发者分享会（样例）",
                "三位同学分享校园开发经验。参与者可提交报名，组织者可核对名单并签到。",
                when, "学生活动中心 · 204", 20, null, null, null));
        setPublished(eventId);
    }

    LegacyStatus legacyStatus() {
        if (legacyPasswordDigest == null) {
            return new LegacyStatus(false, 0);
        }
        Integer available = database.queryForObject("""
                SELECT COUNT(*) FROM campus_event e
                WHERE NOT EXISTS (SELECT 1 FROM event_organizer eo WHERE eo.event_id = e.id)
                """, Integer.class);
        return new LegacyStatus(true, Objects.requireNonNull(available));
    }

    @Transactional(isolation = Isolation.READ_COMMITTED)
    public LegacyClaim claimLegacy(long organizerId, String password) {
        if (legacyPasswordDigest == null) {
            throw ApiException.missing("旧活动迁移未启用。");
        }
        if (password == null || password.length() > 256 ||
                !MessageDigest.isEqual(legacyPasswordDigest, Secrets.sha256(password))) {
            throw ApiException.unauthorized("旧管理口令不正确。");
        }

        // No event is deleted by this application, so the oldest row is a stable migration lock.
        if (database.queryForList("SELECT id FROM campus_event ORDER BY id LIMIT 1 FOR UPDATE", Long.class).isEmpty()) {
            return new LegacyClaim(0);
        }
        List<Long> available = database.queryForList("""
                SELECT e.id FROM campus_event e
                WHERE NOT EXISTS (SELECT 1 FROM event_organizer eo WHERE eo.event_id = e.id)
                ORDER BY e.id
                """, Long.class);
        for (long eventId : available) {
            database.update("INSERT INTO event_organizer (event_id, organizer_id) VALUES (?, ?)", eventId, organizerId);
        }
        return new LegacyClaim(available.size());
    }

    private void requireOrganizerEvent(long organizerId, long eventId) {
        if (database.queryForList("""
                SELECT event_id FROM event_organizer WHERE event_id = ? AND organizer_id = ?
                """, Long.class, eventId, organizerId).isEmpty()) {
            throw eventMissing();
        }
    }

    private LockedEvent lockOrganizerEvent(long organizerId, long eventId, boolean requirePublished) {
        requireOrganizerEvent(organizerId, eventId);
        return lockEvent(eventId, requirePublished);
    }

    private Event organizerEvent(long id) {
        return queryEvent(id).orElseThrow(CampusEvents::eventMissing);
    }

    private Optional<Event> queryEvent(long id) {
        return database.query(EVENT_DETAILS + "WHERE e.id = ?", EVENT_MAPPER, id).stream().findFirst();
    }

    private LockedEvent lockEvent(long eventId, boolean requirePublished) {
        // The event row is the shared lock for every operation that changes this event's capacity usage.
        LockedEvent event = database.query("SELECT starts_at, capacity, status FROM campus_event WHERE id = ? FOR UPDATE",
                        (row, index) -> new LockedEvent(row.getObject("starts_at", LocalDateTime.class), row.getInt("capacity"),
                                EventStatus.valueOf(row.getString("status"))), eventId)
                .stream().findFirst().orElseThrow(CampusEvents::eventMissing);
        if (requirePublished && event.status() != EventStatus.PUBLISHED) {
            throw eventMissing();
        }
        return event;
    }

    private Optional<RosterEntry> ownedRegistration(long eventId, long accountId) {
        return database.query("""
                SELECT r.id, r.event_id, r.name, r.identifier, r.status
                FROM event_registration r
                JOIN event_registration_owner o ON o.registration_id = r.id
                WHERE r.event_id = ? AND o.account_id = ?
                """, ROSTER_MAPPER, eventId, accountId).stream().findFirst();
    }

    private static RegistrationView view(RosterEntry entry) {
        return new RegistrationView(entry.id(), entry.eventId(), entry.name(), entry.status());
    }

    static String identifier(String input) {
        String identifier = input == null ? "" : input.strip();
        if (!IDENTIFIER.matcher(identifier).matches()) {
            throw ApiException.invalid("学号或报名编号需以字母或数字开头，最多 40 个字符，可含点、下划线和横线。");
        }
        return identifier.toUpperCase(Locale.ROOT);
    }

    static String required(String value, int maxLength, String label) {
        String text = value == null ? "" : value.strip();
        if (text.isEmpty() || text.length() > maxLength || text.chars().anyMatch(Character::isISOControl)) {
            throw ApiException.invalid(label + "需填写 1 至 " + maxLength + " 个字符，不能包含换行等控制字符。");
        }
        return text;
    }

    private static ApiException eventMissing() {
        return ApiException.missing("没有找到该活动。");
    }

    private static ApiException registrationMissing() {
        return ApiException.missing("没有找到该报名记录。");
    }

    enum EventStatus { DRAFT, PUBLISHED }
    enum RegistrationStatus { REGISTERED, CHECKED_IN, CANCELLED }

    record NewEvent(String title, String description, LocalDateTime startsAt, String location, Integer capacity,
                    Integer durationMinutes, Integer checkInOpensBeforeMinutes, Integer checkInClosesAfterMinutes) {}
    record Event(long id, String title, String description, LocalDateTime startsAt, String location,
                 int capacity, int confirmed, int remaining, EventStatus status, @JsonUnwrapped EventSchedule schedule) {}
    record RegistrationView(long id, long eventId, String name, RegistrationStatus status) {}
    record RosterEntry(long id, long eventId, String name, String identifier, RegistrationStatus status) {}
    record MyRegistration(Event event, RegistrationStatus status) {}
    record CheckInWindow(long eventId, String code, Instant expiresAt) {}
    record LegacyStatus(boolean enabled, int available) {}
    record LegacyClaim(int claimed) {}
    private record LockedEvent(LocalDateTime startsAt, int capacity, EventStatus status) {}
    private record ActiveWindow(byte[] digest, Instant expiry) {}

    private static final class IncorrectCheckInCode extends ApiException {
        private IncorrectCheckInCode(String message) {
            super(HttpStatus.CONFLICT, message);
        }
    }
}
