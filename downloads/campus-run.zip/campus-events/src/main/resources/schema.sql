CREATE TABLE IF NOT EXISTS campus_event (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(120) NOT NULL,
    description VARCHAR(1000) NOT NULL,
    starts_at DATETIME NOT NULL,
    location VARCHAR(120) NOT NULL,
    capacity INT NOT NULL,
    status VARCHAR(16) NOT NULL,
    CHECK (capacity BETWEEN 1 AND 10000),
    CHECK (status IN ('DRAFT', 'PUBLISHED'))
);

CREATE TABLE IF NOT EXISTS event_schedule (
    event_id BIGINT PRIMARY KEY,
    duration_minutes INT NOT NULL,
    check_in_opens_before_minutes INT NOT NULL,
    check_in_closes_after_minutes INT NOT NULL,
    CONSTRAINT fk_schedule_event FOREIGN KEY (event_id) REFERENCES campus_event (id),
    CHECK (duration_minutes BETWEEN 1 AND 1440),
    CHECK (check_in_opens_before_minutes BETWEEN 0 AND 1440),
    CHECK (check_in_closes_after_minutes BETWEEN 1 AND duration_minutes)
);

CREATE TABLE IF NOT EXISTS event_registration (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    event_id BIGINT NOT NULL,
    name VARCHAR(60) NOT NULL,
    identifier VARCHAR(40) NOT NULL,
    status VARCHAR(16) NOT NULL,
    token_digest CHAR(64) NOT NULL UNIQUE,
    registered_at DATETIME NOT NULL,
    checked_in_at DATETIME,
    cancelled_at DATETIME,
    CONSTRAINT fk_registration_event FOREIGN KEY (event_id) REFERENCES campus_event (id),
    CONSTRAINT uq_registration_event_identifier UNIQUE (event_id, identifier),
    CHECK (status IN ('REGISTERED', 'CHECKED_IN', 'CANCELLED'))
);

CREATE TABLE IF NOT EXISTS participant_account (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(60) NOT NULL,
    identifier VARCHAR(40) NOT NULL UNIQUE,
    password_salt CHAR(32) NOT NULL,
    password_digest CHAR(64) NOT NULL
);

CREATE TABLE IF NOT EXISTS event_registration_owner (
    registration_id BIGINT PRIMARY KEY,
    account_id BIGINT NOT NULL,
    CONSTRAINT fk_owner_registration FOREIGN KEY (registration_id) REFERENCES event_registration (id),
    CONSTRAINT fk_owner_account FOREIGN KEY (account_id) REFERENCES participant_account (id)
);

CREATE TABLE IF NOT EXISTS participant_tour_pending (
    account_id BIGINT PRIMARY KEY,
    CONSTRAINT fk_participant_tour_account FOREIGN KEY (account_id) REFERENCES participant_account (id)
);

CREATE TABLE IF NOT EXISTS event_check_in_window (
    event_id BIGINT PRIMARY KEY,
    code_digest CHAR(64) NOT NULL,
    expires_at_ms BIGINT NOT NULL,
    CONSTRAINT fk_window_event FOREIGN KEY (event_id) REFERENCES campus_event (id)
);

CREATE TABLE IF NOT EXISTS event_check_in_code_lease (
    code_digest CHAR(64) PRIMARY KEY,
    expires_at_ms BIGINT NOT NULL
);

CREATE TABLE IF NOT EXISTS event_check_in_attempt (
    event_id BIGINT NOT NULL,
    account_id BIGINT NOT NULL,
    failed_count INT NOT NULL,
    PRIMARY KEY (event_id, account_id),
    CONSTRAINT fk_attempt_window FOREIGN KEY (event_id) REFERENCES event_check_in_window (event_id),
    CONSTRAINT fk_attempt_account FOREIGN KEY (account_id) REFERENCES participant_account (id),
    CHECK (failed_count BETWEEN 1 AND 5)
);

CREATE TABLE IF NOT EXISTS organizer_account (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(60) NOT NULL,
    username VARCHAR(40) NOT NULL UNIQUE,
    password_salt CHAR(32) NOT NULL,
    password_digest CHAR(64) NOT NULL
);

CREATE TABLE IF NOT EXISTS event_organizer (
    event_id BIGINT PRIMARY KEY,
    organizer_id BIGINT NOT NULL,
    CONSTRAINT fk_organizer_event FOREIGN KEY (event_id) REFERENCES campus_event (id),
    CONSTRAINT fk_organizer_account FOREIGN KEY (organizer_id) REFERENCES organizer_account (id)
);

CREATE TABLE IF NOT EXISTS organizer_pending_tour (
    organizer_id BIGINT PRIMARY KEY,
    CONSTRAINT fk_tour_organizer FOREIGN KEY (organizer_id) REFERENCES organizer_account (id) ON DELETE CASCADE
);
