const OFFLINE_CACHE_PREFIX = 'campus-offline-';
const OFFLINE_CACHE_NAME = OFFLINE_CACHE_PREFIX + '5';
const OFFLINE_PAGE = new URL('offline.html', self.registration.scope);
const API_PATH = new URL('api/', self.registration.scope).pathname;

self.addEventListener('install', event => {
  event.waitUntil((async () => {
    const cache = await caches.open(OFFLINE_CACHE_NAME);
    await cache.add(new Request(OFFLINE_PAGE, { cache: 'reload' }));
    await self.skipWaiting();
  })());
});

self.addEventListener('activate', event => {
  event.waitUntil((async () => {
    const keys = await caches.keys();
    const superseded = keys.filter(key => key.startsWith(OFFLINE_CACHE_PREFIX) && key !== OFFLINE_CACHE_NAME);
    await Promise.all(superseded.map(key => caches.delete(key)));
    await self.clients.claim();
  })());
});

self.addEventListener('fetch', event => {
  const { request } = event;
  const url = new URL(request.url);
  if (request.method !== 'GET' || request.mode !== 'navigate'
      || url.origin !== self.location.origin || url.pathname.startsWith(API_PATH)) return;

  // Every application request stays network-only. Cache only the generic offline notice.
  event.respondWith(fetch(request).catch(async () => {
    const cache = await caches.open(OFFLINE_CACHE_NAME);
    return (await cache.match(OFFLINE_PAGE)) || Response.error();
  }));
});
