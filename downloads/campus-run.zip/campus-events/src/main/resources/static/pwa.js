(() => {
  if (window.isSecureContext && 'serviceWorker' in navigator) {
    navigator.serviceWorker.register('./service-worker.js', { updateViaCache: 'none' }).catch(error => {
      console.warn('Campus service worker could not be registered.', error);
    });
  }

  const installButton = document.querySelector('[data-pwa-install]');
  if (!installButton) return;

  let installPrompt;
  window.addEventListener('beforeinstallprompt', event => {
    event.preventDefault();
    installPrompt = event;
    installButton.hidden = false;
  });

  installButton.addEventListener('click', async () => {
    if (!installPrompt) return;
    const prompt = installPrompt;
    installPrompt = undefined;
    installButton.hidden = true;
    try {
      await prompt.prompt();
    } catch (error) {
      console.warn('Campus install prompt could not be shown.', error);
    }
  });

  window.addEventListener('appinstalled', () => {
    installPrompt = undefined;
    installButton.hidden = true;
  });
})();
