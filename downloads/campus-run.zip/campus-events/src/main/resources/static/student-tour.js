(() => {
  const steps = [
    { nav: 'events', title: '找到活动并报名', text: '从「活动」按名称或地点查找，打开详情后可查看剩余名额并确认报名。' },
    { nav: 'attendance', title: '到场后签到', text: '到场后点「现场签到」，选好已报名的活动，输入现场的六位码。也可以用手机相机扫描现场二维码。' },
    { nav: 'mine', title: '查看报名记录', text: '「我的活动」保存你的报名和签到状态，也可以从这里重新打开指引。' },
  ];
  const panel = document.createElement('section');
  panel.id = 'student-tour';
  panel.className = 'organizer-tour';
  panel.hidden = true;
  panel.setAttribute('role', 'dialog');
  panel.setAttribute('aria-labelledby', 'student-tour-title');
  panel.setAttribute('aria-describedby', 'student-tour-description');
  document.body.append(panel);
  let accountId;
  let index;
  let anchor;
  let returnFocus;
  const starting = new Set();

  function close(restoreFocus = false) {
    anchor?.removeAttribute('data-tour-highlight');
    panel.hidden = true;
    if (restoreFocus && returnFocus?.isConnected) returnFocus.focus({ preventScroll: true });
    anchor = null;
    returnFocus = null;
  }

  function show(stepIndex) {
    index = stepIndex;
    const step = steps[index];
    anchor?.removeAttribute('data-tour-highlight');
    anchor = document.querySelector(`.primary-nav [data-nav="${step.nav}"]`);
    anchor.setAttribute('data-tour-highlight', '');
    anchor.scrollIntoView({ block: 'nearest', inline: 'nearest', behavior: 'instant' });
    panel.innerHTML = `
      <header class="organizer-tour-header"><span>新手指引</span><span>${index + 1} / ${steps.length}</span></header>
      <h2 id="student-tour-title" tabindex="-1">${step.title}</h2><p id="student-tour-description">${step.text}</p>
      <div class="organizer-tour-actions">
        <button type="button" class="button button-secondary" data-tour-action="skip">跳过</button>
        ${index ? '<button type="button" class="button button-secondary" data-tour-action="previous">上一步</button>' : ''}
        <button type="button" class="button button-primary" data-tour-action="next">${index + 1 === steps.length ? '完成指引' : '下一步'}</button>
      </div>`;
    panel.hidden = false;
    positionCampusTour(panel, anchor);
    panel.querySelector('h2').focus({ preventScroll: true });
  }

  async function update(account) {
    const id = account?.id;
    if (accountId !== id) close();
    accountId = id;
    if (!account?.tourPending || starting.has(id) || !panel.hidden) return;
    starting.add(id);
    try {
      const { started } = await api('/account/tour/start', { method: 'POST' });
      if (started && id === accountId && panel.hidden) {
        returnFocus = document.querySelector('#page-title');
        show(0);
      }
    } catch {
      // A later visit can claim the introduction if the service was unavailable.
    } finally {
      starting.delete(id);
    }
  }

  document.addEventListener('click', event => {
    const trigger = event.target.closest('[data-start-student-tour]');
    if (trigger) {
      returnFocus = trigger;
      show(0);
    }
  });
  panel.addEventListener('click', event => {
    const action = event.target.closest('button')?.dataset.tourAction;
    if (action === 'previous') show(index - 1);
    if (action === 'next' && index + 1 < steps.length) show(index + 1);
    else if (action === 'skip' || action === 'next') close(true);
  });
  document.addEventListener('keydown', event => {
    if (!panel.hidden && event.key === 'Escape') {
      event.preventDefault();
      close(panel.contains(document.activeElement));
    }
  });
  window.addEventListener('hashchange', () => close());
  const position = () => positionCampusTour(panel, anchor);
  window.addEventListener('resize', position);
  window.addEventListener('scroll', position, { passive: true });
  window.visualViewport?.addEventListener('resize', position);
  window.visualViewport?.addEventListener('scroll', position, { passive: true });
  window.updateStudentTour = update;
})();
