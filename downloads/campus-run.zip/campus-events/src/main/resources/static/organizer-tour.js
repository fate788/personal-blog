(() => {
  const app = document.querySelector('#app');
  const opener = '[data-start-organizer-tour]';
  const firstVisitHandled = new Set();
  const panel = document.createElement('section');
  panel.id = 'organizer-tour';
  panel.className = 'organizer-tour';
  panel.hidden = true;
  panel.setAttribute('role', 'dialog');
  panel.setAttribute('aria-labelledby', 'organizer-tour-title');
  panel.setAttribute('aria-describedby', 'organizer-tour-description');
  document.body.append(panel);

  let tour;
  let anchor;
  let positionFrame = 0;

  function organizer() {
    return app.querySelector('[data-organizer-username]')?.dataset.organizerUsername;
  }

  function setAnchor(target) {
    if (anchor !== target) anchor?.removeAttribute('data-tour-highlight');
    anchor = target;
    anchor?.setAttribute('data-tour-highlight', '');
  }

  function close({ restoreFocus = true, resume = true } = {}) {
    if (!tour) return;
    const returnHash = resume && tour.returnHash;
    tour.controller?.abort();
    tour = null;
    panel.hidden = true;
    setAnchor(null);
    if (returnHash && location.hash !== returnHash && !hasUnsavedActivity()) location.hash = returnHash;
    else if (restoreFocus) app.querySelector(opener)?.focus({ preventScroll: true });
  }

  function position() {
    window.positionCampusTour(panel, anchor);
  }

  function schedulePosition() {
    if (!tour || panel.hidden || positionFrame) return;
    positionFrame = requestAnimationFrame(() => {
      positionFrame = 0;
      position();
    });
  }

  function show({ title, description, progress, buttons, target, focus = false, scroll = false }) {
    panel.innerHTML = `
      <header class="organizer-tour-header">
        <span>新手指引</span>${progress ? `<span>${progress}</span>` : ''}
      </header>
      <h2 id="organizer-tour-title" tabindex="-1">${title}</h2>
      <p id="organizer-tour-description">${description}</p>
      <div class="organizer-tour-actions">${buttons}</div>
    `;
    setAnchor(target || app.querySelector('#page-title'));
    if (scroll && anchor) anchor.scrollIntoView({ block: 'center', inline: 'nearest', behavior: 'instant' });
    panel.hidden = false;
    position();
    if (focus) panel.querySelector('h2').focus({ preventScroll: true });
  }

  function button(action, label, style = 'secondary') {
    return `<button class="button button-${style}" type="button" data-tour-action="${action}">${label}</button>`;
  }

  async function ownedEventHashes(signal) {
    let events = [];
    try {
      const response = await fetch('/api/organizer/events', {
        credentials: 'same-origin', cache: 'no-store', signal,
      });
      if (response.ok) events = await response.json();
    } catch {
      // Read-only example pages remain available when the list cannot be loaded.
    }
    const hashFor = status => {
      const event = Array.isArray(events) && events.find(event =>
        event.status === status && /^\d+$/.test(event.id),
      );
      return event ? '#organizer/' + event.id : null;
    };
    return {
      draft: hashFor('DRAFT') || '#organizer/guide-draft',
      published: hashFor('PUBLISHED') || '#organizer/guide-published',
    };
  }

  function steps({ draft, published }) {
    return [
      {
        hash: '#organizer', selector: '.workspace-stats',
        title: '活动概况',
        description: '工作台显示活动总数、草稿、已发布活动和有效报名。向下可看到近期活动。',
      },
      {
        hash: '#organizer', selector: '.workspace-nav a[href="#organizer/new"]',
        title: '创建活动',
        description: '从侧栏进入创建页。活动先保存为草稿，核对后再发布。',
      },
      {
        hash: '#organizer/new', selector: '#create-event-form [name="title"]',
        title: '从空白开始',
        description: '填写名称、开始时间、地点和名额。在「时长与签到」设置活动何时结束、同学可以何时签到。',
      },
      {
        hash: '#organizer/new', selector: '[data-creation-mode="template"]',
        title: '按需套用模板',
        description: '默认手动填写。需要参考时，在表单的「活动模板」下拉框选择一个类型，已填的时间和手动修改会保留。',
      },
      {
        hash: '#organizer/new', selector: '#create-event-form button[type="submit"]',
        title: '保存草稿',
        description: '保存后只有组织者能看到草稿。可先核对内容，再决定何时发布。',
      },
      {
        hash: '#organizer/events', selector: '.workspace-search',
        title: '查找和管理活动',
        description: '按活动名称或地点搜索，也能用旁边的状态筛选查找草稿和已发布活动。',
      },
      {
        hash: draft, selector: '[data-action="publish-event"]',
        title: '发布报名',
        description: '在草稿详情核对时间、地点后，点击发布。同学随后就能在同学端报名。',
      },
      {
        hash: published, selector: '[data-action="copy-event-link"]',
        title: '分享报名入口',
        description: '复制报名链接后，可以发给同学。旁边的入口可查看同学实际看到的报名页。',
      },
      {
        hash: published, selector: '[data-action="open-check-in"]',
        title: '开启现场签到',
        description: '活动开始时生成临时二维码和六位签到码。需要时可换码，也可以停止本场签到。',
      },
      {
        hash: published, selector: '[data-action="export-roster"]',
        title: '核对和导出名单',
        description: '可按姓名或报名编号查找，核对到场状态、补录签到，或把名单导出为 CSV。',
      },
      {
        hash: '#organizer/account', selector: '.workspace-profile',
        title: '账号设置',
        description: '这里可以核对组织者姓名和用户名。以后可以从导航里的「新手指引」重新走一遍。',
      },
    ];
  }

  function paintStep() {
    if (!tour || app.getAttribute('aria-busy') === 'true') return;
    const step = tour.steps[tour.index];
    const last = tour.index === tour.steps.length - 1;
    show({
      ...step,
      progress: `${tour.index + 1} / ${tour.steps.length}`,
      buttons: button('skip', '跳过') +
        (tour.index > 0 ? button('previous', '上一步') : '') +
        button('next', last ? '完成指引' : '下一步', 'primary'),
      target: app.querySelector(step.selector),
      focus: true,
      scroll: true,
    });
  }

  function hasUnsavedActivity() {
    const form = app.querySelector('#create-event-form');
    return !!form && [...new FormData(form)].some(([name, value]) => {
      const initial = form.elements.namedItem(name)?.dataset.initialMinutes || '';
      return String(value).trim() !== initial;
    });
  }

  function move(index, discard = false) {
    if (index === tour.steps.length) {
      close();
      return;
    }
    const step = tour.steps[index];
    if (step.hash !== location.hash && !discard && hasUnsavedActivity()) {
      tour.pending = index;
      show({
        title: '当前活动还未保存',
        description: '继续下一页会清除未保存的内容。你也可以退出指引，留在表单继续填写。',
        buttons: button('skip', '继续填写') + button('discard', '离开当前页', 'primary'),
        target: app.querySelector('#create-event-form button[type="submit"]'),
        focus: true,
        scroll: true,
      });
      return;
    }
    tour.index = index;
    tour.stage = 'step';
    tour.hash = step.hash;
    if (location.hash === step.hash) paintStep();
    else {
      panel.hidden = true;
      setAnchor(null);
      location.hash = step.hash;
    }
  }

  async function begin(firstVisit = false) {
    const username = organizer();
    if (!username) return;
    close({ restoreFocus: false, resume: false });
    const active = {
      username, hash: location.hash, stage: 'loading', controller: new AbortController(),
      returnHash: firstVisit && location.hash !== '#organizer' ? location.hash : null,
    };
    tour = active;
    if (firstVisit) {
      firstVisitHandled.add(username);
      const timeout = setTimeout(() => active.controller.abort(), 3000);
      try {
        const response = await fetch('/api/organizer/tour/start', {
          method: 'POST', credentials: 'same-origin', cache: 'no-store', signal: active.controller.signal,
        });
        if (response.status === 401 || (response.ok && !(await response.json()).started)) {
          if (tour === active) close({ restoreFocus: false, resume: false });
          return;
        }
      } catch {
        // The guide remains available for this visit if receipt of the start could not be confirmed.
      } finally {
        clearTimeout(timeout);
      }
      if (tour !== active) return;
    }
    const timeout = setTimeout(() => active.controller.abort(), 3000);
    const events = await ownedEventHashes(active.controller.signal);
    clearTimeout(timeout);
    if (tour !== active) return;
    tour.steps = steps(events);
    move(0);
  }

  function sync() {
    if (app.getAttribute('aria-busy') === 'true') return;
    const username = organizer();
    const target = app.querySelector(opener);
    if (target) {
      target.setAttribute('aria-haspopup', 'dialog');
      target.setAttribute('aria-controls', panel.id);
      target.hidden = false;
    }
    if (tour && (!username || tour.username !== username)) {
      close({ restoreFocus: false, resume: false });
    }
    if (!username || !target) return;
    if (tour?.stage === 'step' && tour.hash === location.hash && (panel.hidden || !anchor?.isConnected)) {
      paintStep();
    }
    const pending = app.querySelector('[data-tour-pending="true"]');
    if (!tour && pending && !firstVisitHandled.has(username)) void begin(true);
  }

  document.addEventListener('click', event => {
    if (event.target.closest(opener)) void begin();
  });
  panel.addEventListener('click', event => {
    const action = event.target.closest('[data-tour-action]')?.dataset.tourAction;
    if (!action || !tour) return;
    if (action === 'skip') close();
    if (action === 'next') move(tour.index + 1);
    if (action === 'previous') move(tour.index - 1);
    if (action === 'discard') move(tour.pending, true);
  });
  document.addEventListener('keydown', event => {
    if (event.key === 'Escape' && !event.defaultPrevented && tour && !panel.hidden && !(event.target instanceof HTMLSelectElement)) {
      event.preventDefault();
      close({ restoreFocus: panel.contains(document.activeElement) });
    }
  });
  window.addEventListener('hashchange', () => {
    if (tour && location.hash !== tour.hash) close({ restoreFocus: false, resume: false });
  });
  window.addEventListener('scroll', schedulePosition, { passive: true });
  window.addEventListener('resize', schedulePosition);
  window.visualViewport?.addEventListener('resize', schedulePosition);
  window.visualViewport?.addEventListener('scroll', schedulePosition, { passive: true });
  new MutationObserver(sync).observe(app, {
    childList: true, attributes: true, attributeFilter: ['aria-busy'],
  });
  sync();
})();
