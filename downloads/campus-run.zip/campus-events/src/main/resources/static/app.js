const app = document.querySelector('#app');
const organizerPortal = document.body.dataset.portal === 'organizer';
const activeWindows = new Map();
const windowStorageKey = 'campus-check-in-windows';
let rosterPoll = 0;
let refreshDirectoryTime;
let viewVersion = 0;
let flash;
let presentedHash;

const html = value => String(value ?? '').replace(/[&<>"']/g, character => ({
  '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;',
})[character]);
const pathId = value => encodeURIComponent(value);
const field = (form, name) => new FormData(form).get(name)?.trim() || '';
const identifierPattern = /^[A-Za-z0-9][A-Za-z0-9._-]{0,39}$/;
const organizerUsernamePattern = /^[A-Za-z0-9][A-Za-z0-9._-]{2,39}$/;
const codePattern = /^\d{6}$/;
const normalizeCode = value => String(value ?? '').normalize('NFKC').replace(/\s/g, '');
const eventLink = id => `#event/${pathId(id)}`;
const authLink = (mode, next) => `#${mode}?next=${encodeURIComponent(next)}`;
const siteLink = hash => new URL('/' + hash, location.origin).href;

if (organizerPortal) {
  try {
    const previous = JSON.parse(sessionStorage.getItem(windowStorageKey) || '[]');
    for (const [id, state] of previous) {
      if (/^\d+$/.test(id) && codePattern.test(state.code) && Date.parse(state.expiresAt) > Date.now()) {
        activeWindows.set(id, state);
      }
    }
  } catch {
    activeWindows.clear();
  }
}

function saveActiveWindows() {
  try {
    const remaining = [...activeWindows].filter(([, state]) => Date.parse(state.expiresAt) > Date.now());
    sessionStorage.setItem(windowStorageKey, JSON.stringify(remaining));
  } catch {
    // The current page can still show the code when storage is unavailable.
  }
}

class RequestError extends Error {
  constructor(message, status) {
    super(message);
    this.status = status;
  }
}

async function api(path, { method = 'GET', body } = {}) {
  const headers = { Accept: 'application/json' };
  if (body) headers['Content-Type'] = 'application/json';
  let response;
  try {
    response = await fetch(`/api${path}`, {
      method,
      headers,
      credentials: 'same-origin',
      cache: 'no-store',
      body: body ? JSON.stringify(body) : undefined,
    });
  } catch {
    throw new RequestError('暂时无法连接报名服务，请稍后重试。', 0);
  }
  if (response.status === 204) return undefined;
  const data = await response.json().catch(() => null);
  if (!response.ok) throw new RequestError(data?.message || '请求未完成，请重试。', response.status);
  return data;
}

async function optional(path, ...statuses) {
  try {
    return await api(path);
  } catch (error) {
    if (statuses.includes(error.status)) return null;
    throw error;
  }
}

function dateParts(value) {
  const match = /^(\d{4})-(\d{2})-(\d{2})[T ](\d{2}):(\d{2})/.exec(value || '');
  if (!match) return { full: value || '时间待定', month: '日期', day: '–' };
  const [, year, month, day, hour, minute] = match;
  return { full: `${year} 年 ${Number(month)} 月 ${Number(day)} 日 · ${hour}:${minute}`, month: `${Number(month)} 月`, day: Number(day) };
}

function pageNotice(message, error = false) {
  if (!message) return '';
  return `<p class="notice ${error ? 'notice-error' : 'notice-success'}" role="${error ? 'alert' : 'status'}">${html(message)}</p>`;
}

function inlineFeedback(belongsTo, message, error = true) {
  const slot = belongsTo.querySelector('[data-feedback]');
  if (slot) slot.innerHTML = pageNotice(message, error);
}

function onSubmit(selector, callback) {
  const form = document.querySelector(selector);
  form?.addEventListener('submit', event => {
    event.preventDefault();
    const button = event.submitter || form.querySelector('button[type="submit"]');
    const feedbackScope = form.closest('[data-feedback-scope]') || form;
    perform(button, feedbackScope, () => callback(form));
  });
}

async function perform(button, container, action) {
  if (button?.matches(':disabled')) return;
  if (button) button.disabled = true;
  try {
    await action();
  } catch (error) {
    inlineFeedback(container, error.message || '操作未完成，请重试。');
  } finally {
    if (button) button.disabled = false;
  }
}

function navigate(hash, message) {
  const target = hash || '#events';
  if (message) flash = { hash: target, message };
  if (location.hash === target || (!location.hash && target === '#events')) render({ focus: true });
  else location.hash = target;
}

function route() {
  const [path, query] = location.hash.slice(1).split('?');
  const [page, id, code] = path.split('/');
  if (page === 'event' && /^\d+$/.test(id || '')) return { page: 'event', id };
  if (page === 'checkin') return /^\d+$/.test(id || '') && codePattern.test(code || '')
    ? { page, id, code } : { page: 'invalid-checkin' };
  if (page === 'organizer') {
    const next = new URLSearchParams(query).get('next') || '#organizer';
    return {
      page,
      id: /^\d+$/.test(id || '') ? id : null,
      section: ['events', 'new', 'account', 'login', 'register', 'guide-draft', 'guide-published'].includes(id) ? id : 'overview',
      next: /^#organizer(?:\/(?:\d+|events|new|account))?$/.test(next) ? next : '#organizer',
    };
  }
  if (page === 'login' || page === 'signup') {
    const next = new URLSearchParams(query).get('next') || '#mine';
    return { page, next: /^#(?:mine|attendance|event\/\d+|checkin\/\d+\/\d{6})$/.test(next) ? next : '#mine' };
  }
  if (page === 'mine' || page === 'attendance') return { page };
  return { page: 'events' };
}

function eventTag(event) {
  if (event.status === 'DRAFT') return '<span class="tag tag-muted">草稿</span>';
  const end = Date.parse(event.endsAt);
  const ended = end <= Date.now();
  const style = ended ? 'muted' : event.remaining <= 0 ? 'orange' : 'green';
  const status = ended ? '活动已结束' : event.remaining <= 0 ? '名额已满' : '报名开放';
  return `<span class="tag tag-${style}"${Number.isFinite(end) ? ` data-registration-tag-end="${end}"` : ''}>${status}</span>`;
}

function rosterTag(status) {
  const [name, variant] = ({
    REGISTERED: ['待签到', 'orange'],
    CHECKED_IN: ['已签到', 'green'],
    CANCELLED: ['已取消', 'muted'],
  })[status] || ['状态待确认', 'muted'];
  return `<span class="tag tag-${variant}">${name}</span>`;
}

function eventStartText(start, now) {
  const seconds = Math.ceil((start - now) / 1000);
  if (seconds <= 0) return '开始时间已到';
  const days = Math.floor(seconds / 86400);
  const hours = Math.floor(seconds / 3600) % 24;
  const minutes = Math.floor(seconds / 60) % 60;
  const secondsLeft = seconds % 60;
  if (days) return `${days} 天 ${hours} 小时 ${minutes} 分`;
  if (hours) return `${hours} 小时 ${minutes} 分 ${secondsLeft} 秒`;
  if (minutes) return `${minutes} 分 ${secondsLeft} 秒`;
  return `${secondsLeft} 秒`;
}

const campusDateTime = new Intl.DateTimeFormat('sv-SE', {
  timeZone: 'Asia/Shanghai', year: 'numeric', month: '2-digit', day: '2-digit',
  hour: '2-digit', minute: '2-digit', hourCycle: 'h23',
});

function eventStartMillis(event) {
  return Date.parse(event.startsAtInstant || event.startsAt);
}

function campusTimeRange(start, end) {
  const from = campusDateTime.format(start);
  const to = campusDateTime.format(end);
  const day = stamp => {
    const [year, month, date] = stamp.slice(0, 10).split('-');
    return `${year}年${Number(month)}月${Number(date)}日`;
  };
  const repeatDate = from.slice(0, 10) !== to.slice(0, 10);
  return `${day(from)} ${from.slice(-5)} – ${repeatDate ? day(to) + ' ' : ''}${to.slice(-5)}`;
}

function activityTime(event) {
  if (!event.endsAt) return dateParts(event.startsAt).full;
  return `${campusTimeRange(eventStartMillis(event), Date.parse(event.endsAt))} · ${event.durationMinutes} 分钟`;
}

function activityClockState(start, end, now) {
  if (now < start) return ['距活动开始', eventStartText(start, now)];
  if (now < end) return ['进行中 · 距结束', eventStartText(end, now)];
  return ['', Number.isFinite(end) ? '活动已结束' : '开始时间已到'];
}

function eventStartClock(event, now = Date.now()) {
  const start = eventStartMillis(event);
  const end = Date.parse(event.endsAt);
  if (!Number.isFinite(start)) return '';
  const [label, value] = activityClockState(start, end, now);
  return `<div class="event-start-clock" data-event-start-countdown="${start}"${Number.isFinite(end) ? ` data-event-end="${end}"` : ''}${!label ? ' data-event-started' : ''}>
    <span class="event-start-label">${label}</span>
    <span class="event-start-value" role="timer" aria-live="off" data-event-start-value>${value}</span>
  </div>`;
}

function checkInPhase(open, close, now) {
  if (now < open) return ['签到未开放', `距开放 ${eventStartText(open, now)}`];
  if (now < close) return ['签到时段开放中', `距截止 ${eventStartText(close, now)}`];
  return ['签到已截止', ''];
}

function checkInSchedule(event) {
  if (!event?.checkInOpensAt || !event.checkInClosesAt) return '';
  const open = Date.parse(event.checkInOpensAt);
  const close = Date.parse(event.checkInClosesAt);
  const [phase, left] = checkInPhase(open, close, Date.now());
  return `<div class="checkin-schedule" data-checkin-schedule data-opens="${open}" data-closes="${close}">
    <div><strong data-checkin-phase>${phase}</strong><span role="timer" aria-live="off" data-checkin-time-left>${left}</span></div>
    <span class="schedule-range">${campusTimeRange(open, close)}<small>北京时间</small></span>
  </div>`;
}

function gateCheckIn(event, controls) {
  if (!event?.checkInOpensAt) return controls;
  const open = Date.parse(event.checkInOpensAt);
  const close = Date.parse(event.checkInClosesAt);
  const now = Date.now();
  return `<fieldset class="checkin-gate" aria-label="现场签到操作" data-checkin-gate data-opens="${open}" data-closes="${close}"${now < open || now >= close ? ' disabled' : ''}>${controls}</fieldset>`;
}

function capacityView(event) {
  return `<div class="capacity"><div><span>已报名 ${html(event.confirmed)} / ${html(event.capacity)} 人</span><strong>剩余 ${html(event.remaining)} 人</strong></div><progress max="${html(event.capacity)}" value="${html(event.confirmed)}" aria-label="名额使用情况"></progress></div>`;
}

function eventCard(event, status, started = false) {
  const date = dateParts(event.startsAt);
  const useDetailLink = status || started || event.remaining <= 0;
  return `<article class="event-card">
    <div class="event-card-top">
      <div class="date-tile" aria-hidden="true"><span>${html(date.month)}</span><strong>${html(date.day)}</strong></div>
      ${status ? rosterTag(status) : started && !event.endsAt ? '<span class="tag tag-muted">开始时间已过</span>' : eventTag(event)}
    </div>
    <h3><a href="#event/${pathId(event.id)}">${html(event.title)}</a></h3>
    <p class="event-card-description">${html(event.description || '查看详情了解这场活动。')}</p>
    <dl class="event-meta">
      <div><dt>时间</dt><dd>${html(date.full)}</dd></div>
      <div><dt>地点</dt><dd>${html(event.location)}</dd></div>
    </dl>
    <div class="event-card-bottom">
      <span class="muted">${started ? `已报名 ${html(event.confirmed)} / ${html(event.capacity)} 人` : `剩余 ${html(event.remaining)} / ${html(event.capacity)} 名额`}</span>
      <a class="text-action" href="#event/${pathId(event.id)}"><span${event.endsAt ? ` data-card-action-end="${Date.parse(event.endsAt)}"` : ''}>${useDetailLink ? '查看详情' : '查看与报名'}</span> <span aria-hidden="true">↗</span></a>
    </div>
  </article>`;
}

function eventDirectoryCards(events, now) {
  const upcoming = events.filter(event => eventStartMillis(event) > now);
  const earlier = events.filter(event => !(eventStartMillis(event) > now)).reverse();
  return [...upcoming, ...earlier].map(event => eventCard(event, undefined, eventStartMillis(event) <= now)).join('');
}

function featuredEvent(events, now) {
  const event = events.find(item => eventStartMillis(item) <= now && now < Date.parse(item.endsAt))
    || events.find(item => eventStartMillis(item) > now);
  if (!event) return '';
  const date = dateParts(event.startsAt);
  return `<a class="featured" href="#event/${pathId(event.id)}">
    <div class="featured-top"><span data-featured-start-label>${now >= eventStartMillis(event) ? '正在进行' : '下一场活动'}</span><span>${event.remaining > 0 ? `剩余 ${html(event.remaining)} 个名额` : '名额已满'} <span aria-hidden="true">↗</span></span></div>
    <div class="featured-body">
      <div class="featured-date" aria-hidden="true"><span>${html(date.month)}</span><strong>${html(date.day)}</strong></div>
      <div><strong>${html(event.title)}</strong><span>${html(date.full)}</span><span>${html(event.location)}</span></div>
    </div>
    ${eventStartClock(event, now)}
  </a>`;
}

function eventsPage(events, account, now) {
  const upcoming = events.filter(event => eventStartMillis(event) > now);
  return `<section class="hero" aria-labelledby="page-title">
    <div>
      <h1 id="page-title" tabindex="-1">校园活动</h1>
      <p>找一场感兴趣的活动，在线报名，到场后完成签到。</p>
      <div class="actions"><a class="button button-primary" href="#published-events">浏览活动 <span aria-hidden="true">↓</span></a>${account ? '' : '<a class="text-action hero-register" href="#signup">注册账号 <span aria-hidden="true">↗</span></a>'}</div>
    </div>
    <div class="hero-side">${featuredEvent(events, now)}</div>
  </section>
  <div class="student-shortcuts" role="group" aria-label="报名和签到快捷入口">
    <a href="#attendance"><span class="student-shortcut-icon" aria-hidden="true"><i class="nav-icon nav-check-in"></i></span><span class="student-shortcut-copy"><strong>现场签到</strong><small>输入 6 位签到码</small></span><span class="student-shortcut-arrow" aria-hidden="true">↗</span></a>
    <a href="#mine"><span class="student-shortcut-icon" aria-hidden="true"><i class="nav-icon nav-mine"></i></span><span class="student-shortcut-copy"><strong>我的活动</strong><small>报名与签到记录</small></span><span class="student-shortcut-arrow" aria-hidden="true">↗</span></a>
  </div>
  <section class="section event-directory" id="published-events" aria-labelledby="published-title" tabindex="-1">
    <div class="section-heading"><h2 id="published-title">活动目录</h2><span data-event-count role="status">${events.length} 场已发布活动</span></div>
    ${events.length ? `<div class="event-directory-tools">
      <div class="event-directory-views" role="group" aria-label="活动时间">
        <button type="button" data-event-view="all" aria-pressed="true">全部 <span>${events.length}</span></button>
        <button type="button" data-event-view="upcoming" aria-pressed="false">即将开始 <span>${upcoming.length}</span></button>
      </div>
      <label class="event-directory-search"><span>搜索活动</span><input type="search" data-event-search placeholder="按名称或地点搜索" maxlength="120" aria-controls="event-list"></label>
    </div>` : ''}
    <div id="event-list" class="event-grid">${events.length ? eventDirectoryCards(events, now) : '<div class="empty"><h3>暂无已发布活动</h3><p>组织者发布后，活动会出现在这里。</p></div>'}</div>
  </section>`;
}

function bindEventDirectory(events, now) {
  const search = document.querySelector('[data-event-search]');
  if (!search) return;
  const views = [...document.querySelectorAll('[data-event-view]')];
  const list = document.querySelector('#event-list');
  const count = document.querySelector('[data-event-count]');
  let view = 'all';
  const update = () => {
    const current = Date.now();
    const words = search.value.trim().toLowerCase().split(/\s+/).filter(Boolean);
    const results = events.filter(event => {
      const matchesTime = view === 'all' || eventStartMillis(event) > current;
      const text = `${event.title} ${event.location}`.toLowerCase();
      return matchesTime && words.every(word => text.includes(word));
    });
    count.textContent = view === 'all' && words.length === 0 ? `${results.length} 场已发布活动` : `找到 ${results.length} 场活动`;
    list.innerHTML = results.length ? eventDirectoryCards(results, current) : `<div class="empty"><h3>${words.length ? '没有匹配的活动' : '暂无即将开始的活动'}</h3><p>试试其他关键词，或查看全部活动。</p><button class="button button-secondary" type="button" data-reset-events>显示全部</button></div>`;
    for (const button of views) button.setAttribute('aria-pressed', String(button.dataset.eventView === view));
  };
  for (const button of views) button.addEventListener('click', () => {
    view = button.dataset.eventView;
    update();
  });
  search.addEventListener('input', update);
  list.addEventListener('click', event => {
    if (!event.target.closest('[data-reset-events]')) return;
    view = 'all';
    search.value = '';
    update();
    search.focus();
  });
  const transitions = events.flatMap(event => [eventStartMillis(event), Date.parse(event.endsAt)])
    .filter(stamp => stamp > now).sort((a, b) => a - b);
  const hero = app.querySelector('.hero-side');
  refreshDirectoryTime = current => {
    if (!transitions.length || current < transitions[0]) return;
    while (transitions.length && current >= transitions[0]) transitions.shift();
    const focused = document.activeElement;
    const focusInHero = hero.contains(focused);
    const previousHref = list.contains(focused) ? focused.getAttribute('href') : null;
    hero.innerHTML = featuredEvent(events, current);
    app.querySelector('[data-event-view="upcoming"] span').textContent = events.filter(event => eventStartMillis(event) > current).length;
    update();
    const nextFocus = focusInHero ? hero.querySelector('.featured') || search :
      previousHref && (Array.from(list.querySelectorAll('a')).find(link => link.getAttribute('href') === previousHref) || search);
    if (nextFocus) nextFocus.focus({ preventScroll: true });
  };
}

function codeInput() {
  return '<label>6 位签到码<input class="checkin-code-input" name="code" type="text" inputmode="numeric" autocomplete="off" autocapitalize="off" spellcheck="false" required maxlength="18" placeholder="输入 6 位数字"></label>';
}

function manualCheckInControls(event) {
  return gateCheckIn(event, `${codeInput()}<button type="submit" class="button button-primary">确认签到</button>`);
}

function registrationCard(event, account, registration, message) {
  const active = registration?.status === 'REGISTERED' || registration?.status === 'CHECKED_IN';
  const end = Date.parse(event.endsAt);
  const ended = end <= Date.now();
  return `<section class="panel registration-panel" aria-labelledby="registration-title" data-feedback-scope>
    <h2 id="registration-title">${active ? '我的报名' : '活动报名'}</h2>
    <div data-feedback>${pageNotice(message)}</div>
    ${checkInSchedule(event)}
    ${active ? `<div class="registration-summary">
      <div><span class="muted">登记姓名</span><strong>${html(registration.name)}</strong></div>
      ${rosterTag(registration.status)}
    </div>
    ${registration.status === 'REGISTERED' ? `<p class="muted">到场后，输入发布端显示的签到码。</p>
      <form id="manual-code-form" class="checkin-code-form">
        ${manualCheckInControls(event)}
      </form>
      <button class="button button-secondary" type="button" data-action="cancel-registration">取消报名</button>
      ` : '<p class="muted">签到记录已同步至发布端名单。</p>'}`
    : `${registration?.status === 'CANCELLED' && !message ? '<p class="muted">上一次报名已取消。</p>' : ''}
    ${Number.isFinite(end) ? `<p class="muted" data-registration-ended="${end}"${ended ? '' : ' hidden'}>活动已结束，报名已截止。</p>` : ''}
    <fieldset class="registration-offers" aria-label="活动报名"${Number.isFinite(end) ? ` data-registration-offers="${end}"${ended ? ' hidden disabled' : ''}` : ''}>
    ${event.remaining > 0 ? account ? `<p class="muted">将使用账号「${html(account.name)}」报名。</p><form id="registration-form">
      <button class="button button-primary" type="submit">确认报名</button></form>`
      : `<p class="muted">登录后报名，并在手机上查看签到状态。</p><div class="actions">
        <a class="button button-primary" href="${html(authLink('login', eventLink(event.id)))}">登录后报名</a>
        <a class="button button-secondary" href="${html(authLink('signup', eventLink(event.id)))}">注册账号</a>
      </div>` : '<p class="muted">当前名额已满。有人取消时，名额会重新开放。</p>'}</fieldset>`}
  </section>`;
}

function eventPage(event, account, registration, message) {
  return `<div class="inner">
    <a class="back-link" href="#events">← 返回活动列表</a>
    <div class="event-layout">
      <article class="panel event-detail">
        <div class="detail-cover"><div>${eventTag(event)}<h1 id="page-title" tabindex="-1">${html(event.title)}</h1></div></div>
        <div class="detail-body">
          <dl class="event-meta detail-meta"><div><dt>活动时间${event.endsAt ? '（北京时间）' : ''}</dt><dd>${html(activityTime(event))}</dd></div><div><dt>活动地点</dt><dd>${html(event.location)}</dd></div></dl>
          ${eventStartClock(event)}
          <h2>活动介绍</h2><p class="event-description">${html(event.description || '暂无补充说明。')}</p>
          ${capacityView(event)}
        </div>
      </article>
      ${registrationCard(event, account, registration, message)}
    </div>
  </div>`;
}

function accountPage(mode, next, message) {
  const registering = mode === 'signup';
  return `<div class="inner auth-layout participant-auth">
    <aside class="auth-art"><span class="auth-ribbon" aria-hidden="true"></span><strong>校园场务</strong><p>报名和签到记录，随身可查。</p></aside>
    <section class="panel login-panel" data-feedback-scope>
      <div class="page-heading"><div><h1 id="page-title" tabindex="-1">${registering ? '创建参与者账号' : '参与者登录'}</h1>
      <p>${registering ? '账号用于报名、签到和跨设备查询。' : '继续报名，或查看自己的活动状态。'}</p></div></div>
      <form id="${registering ? 'account-register' : 'account-login'}-form">
        <div data-feedback>${pageNotice(message)}</div>
        ${registering ? '<label>姓名<input name="name" required autocomplete="name" maxlength="60" placeholder="如 林同学"></label>' : ''}
        <label>学号或报名编号<input name="identifier" required autocomplete="username" autocapitalize="none" spellcheck="false" maxlength="40" placeholder="如 TEST-001"></label>
        <label>密码<input type="password" name="password" required autocomplete="${registering ? 'new-password' : 'current-password'}" ${registering ? 'minlength="8" maxlength="128"' : ''}></label>
        <button type="submit" class="button button-primary">${registering ? '创建账号' : '登录'}</button>
      </form>
      <p class="account-switch">${registering ? '已有账号？' : '还没有账号？'} <a class="text-action" href="${html(authLink(registering ? 'login' : 'signup', next))}">${registering ? '去登录' : '注册账号'}</a></p>
    </section>
  </div>`;
}

function minePage(account, registrations, message) {
  return `<div class="inner"><div class="page-heading"><div><h1 id="page-title" tabindex="-1">我的活动</h1><p>查看报名与签到状态。</p></div></div>
    ${pageNotice(message)}
    ${account ? `<div class="panel account-summary" data-account-actions>
      <div class="account-avatar" aria-hidden="true">${html([...account.name][0])}</div><div><strong>${html(account.name)}</strong><small>${html(account.identifier)}</small>
        <button class="student-guide-trigger text-action" type="button" data-start-student-tour aria-haspopup="dialog" aria-controls="student-tour">新手指引</button></div>
      <button class="button button-secondary" type="button" data-action="account-logout">退出登录</button><div data-feedback></div>
    </div><div class="event-grid">${registrations.length ? registrations.map(entry => eventCard(entry.event, entry.status)).join('') :
      '<div class="empty"><h3>还没有报名</h3><p>报名成功后，活动会出现在这里。</p><a class="button button-primary" href="#events">浏览活动</a></div>'}</div>`
    : `<div class="empty"><h3>登录后查看报名</h3><p>在另一部手机上登录同一账号，可以继续查看报名与签到记录。</p>
      <div class="actions"><a class="button button-primary" href="${html(authLink('login', '#mine'))}">登录</a><a class="button button-secondary" href="${html(authLink('signup', '#mine'))}">注册账号</a></div></div>`}
  </div>`;
}

function attendancePage(account, registrations, message) {
  const awaiting = registrations.filter(registration => registration.status === 'REGISTERED');
  const selected = awaiting.length === 1 ? awaiting[0].event : null;
  return `<div class="inner scan-view attendance-view">
    <section class="panel scan-panel attendance-panel" data-feedback-scope>
      <div class="page-heading"><div><h1 id="page-title" tabindex="-1">现场签到</h1><p>选好已报名的活动，输入现场显示的 6 位数字。</p></div></div>
      <div data-feedback>${pageNotice(message)}</div>
      ${!account ? `<div class="actions">
        <a class="button button-primary" href="${html(authLink('login', '#attendance'))}">登录后签到</a>
        <a class="button button-secondary" href="${html(authLink('signup', '#attendance'))}">注册账号</a></div>`
        : awaiting.length ? `<form id="attendance-code-form" class="checkin-code-form">
          <label>待签到活动<select name="eventId" required>${awaiting.length > 1 ? '<option value="">请选择活动</option>' : ''}
            ${awaiting.map(({ event }) => `<option value="${html(event.id)}">${html(event.title)} · ${html(dateParts(event.startsAt).full)}</option>`).join('')}
          </select></label>
          <div data-attendance-controls>${checkInSchedule(selected)}${manualCheckInControls(selected)}</div>
        </form><p class="muted">也可以用手机相机扫描发布端展示的二维码。</p>`
        : '<p>当前没有待签到的活动。可到「我的活动」查看状态。</p><div class="actions"><a class="button button-primary" href="#mine">查看我的活动</a><a class="button button-secondary" href="#events">浏览活动</a></div>'}
    </section>
  </div>`;
}

function checkInPage(event, account, registration, message) {
  const checked = registration?.status === 'CHECKED_IN';
  return `<div class="inner scan-view"><a class="back-link" href="${eventLink(event.id)}">← 查看活动详情</a>
    <section class="panel scan-panel" data-feedback-scope>
      <div class="scan-mark" aria-hidden="true">${checked ? '✓' : '⌗'}</div>
      <div class="page-heading"><div><h1 id="page-title" tabindex="-1">${checked ? '签到已完成' : '现场签到'}</h1><p>${html(event.title)}</p></div></div>
      <dl class="event-meta"><div><dt>活动时间</dt><dd>${html(activityTime(event))}</dd></div><div><dt>地点</dt><dd>${html(event.location)}</dd></div></dl>
      ${checkInSchedule(event)}
      <div data-feedback>${pageNotice(message)}</div>
      ${!account ? `<p>登录后核对报名，并在此登记到场。</p><div class="actions">
        <a class="button button-primary" href="${html(authLink('login', location.hash))}">登录后签到</a>
        <a class="button button-secondary" href="${html(authLink('signup', location.hash))}">注册账号</a></div>`
        : checked ? `<p>${html(account.name)}，你的到场记录已同步至名单。</p><div class="actions"><a class="button button-secondary" href="#mine">查看我的活动</a></div>`
        : registration?.status === 'REGISTERED' ? `<p>为「${html(account.name)}」登记到场。</p><form id="self-check-in-form">${gateCheckIn(event, '<button type="submit" class="button button-primary">确认现场签到</button>')}</form>`
        : `<p>账号「${html(account.name)}」还没有有效报名。</p><div class="actions"><a class="button button-primary" href="${eventLink(event.id)}">查看报名</a></div>`}
    </section>
  </div>`;
}

function organizerAuthPath(section, next = '#organizer') {
  return `#organizer/${section}${next === '#organizer' ? '' : `?next=${encodeURIComponent(next)}`}`;
}

function organizerBrand() {
  return '<a class="brand workspace-brand" href="#organizer"><span class="brand-icon" aria-hidden="true"></span><span><strong>校园场务</strong><small>活动发布端</small></span></a>';
}

function organizerAuthPage(section, next, message) {
  const registering = section === 'register';
  return `<div class="organizer-auth-shell">
    <aside class="organizer-auth-story">
      ${organizerBrand()}
      <div class="organizer-auth-story-copy">
        <h2>活动发布<br>与现场签到</h2>
        <p>从报名到到场，使用同一份名单。</p>
      </div>
      <a class="portal-switch organizer-auth-note" href="/#events">前往同学端 <span aria-hidden="true">↗</span></a>
    </aside>
    <section class="organizer-auth-panel">
      <div class="organizer-auth-content">
        <h1 id="page-title" tabindex="-1">${registering ? '创建组织者账号' : '组织者登录'}</h1>
        <p>${registering ? '注册后即可创建活动，管理自己的报名名单。' : '登录你的账号，进入活动工作台。'}</p>
        <form id="${registering ? 'organizer-register-form' : 'organizer-login-form'}">
          <div data-feedback>${pageNotice(message)}</div>
          ${registering ? '<label>姓名<input name="name" required maxlength="60" autocomplete="name" placeholder="请输入你的姓名"></label>' : ''}
          <label>用户名<input name="username" required minlength="3" maxlength="40" autocomplete="username" autocapitalize="none" spellcheck="false" placeholder="${registering ? '例如 lin-campus' : '请输入用户名'}">
            ${registering ? '<small>3 至 40 位，以字母或数字开头，可包含点、下划线和连字符。</small>' : ''}
          </label>
          <label>密码<input type="password" name="password" required maxlength="128" autocomplete="${registering ? 'new-password' : 'current-password'}" ${registering ? 'minlength="8"' : ''} placeholder="${registering ? '至少 8 位' : '请输入密码'}"></label>
          <button class="button button-primary" type="submit">${registering ? '创建账号' : '登录工作台'}</button>
        </form>
        <p class="account-switch">${registering ? '已有发布端账号？' : '首次使用发布端？'}
          <a class="text-action" href="${html(organizerAuthPath(registering ? 'login' : 'register', next))}">${registering ? '去登录' : '注册组织者账号'}</a>
        </p>
      </div>
    </section>
  </div>`;
}

const workspaceLinks = [
  { section: 'overview', path: '#organizer', title: '工作台', icon: 'nav-admin' },
  { section: 'events', path: '#organizer/events', title: '我的活动', icon: 'nav-events' },
  { section: 'new', path: '#organizer/new', title: '创建活动', icon: 'nav-create' },
  { section: 'account', path: '#organizer/account', title: '账号设置', icon: 'nav-mine' },
];

const eventTemplates = [
  {
    id: 'talk', label: '讲座分享',
    fields: {
      title: '校园主题分享会', location: '学生活动中心报告厅', capacity: '60',
      description: '围绕本期主题安排嘉宾分享和现场问答。请提前 10 分钟到场签到，入场后将手机调至静音。',
    },
  },
  {
    id: 'club', label: '社团招新',
    fields: {
      title: '社团招新见面会', location: '学生活动中心多功能厅', capacity: '40',
      description: '了解社团的日常活动、成员分工和加入方式，现场安排自由交流与答疑。面向对社团感兴趣的同学，无需提前准备。',
    },
  },
  {
    id: 'volunteer', label: '志愿服务',
    fields: {
      title: '校园志愿服务行动', location: '校图书馆正门集合', capacity: '25',
      description: '签到后由负责人说明服务内容和任务分工，再按小组开展活动。请提前 10 分钟到达集合点，穿便于活动的服装。',
    },
  },
  {
    id: 'workshop', label: '竞赛培训',
    fields: {
      title: '校内竞赛备赛工作坊', location: '教学楼研讨教室', capacity: '30',
      description: '介绍参赛流程和备赛安排，组织小组练习和集中答疑。请自带电脑，可提前整理想讨论的问题。',
    },
  },
  {
    id: 'sports', label: '文体活动',
    fields: {
      title: '校园羽毛球交流活动', location: '校体育馆羽毛球场', capacity: '24',
      description: '签到后按到场人数分组，进行热身和双打交流，欢迎不同水平的同学参加。请自备球拍，穿适合室内运动的鞋。',
    },
  },
];

function workspaceFrame(account, section, output) {
  const current = workspaceLinks.find(item => item.section === section) || workspaceLinks[1];
  const avatar = html([...account.name][0]);
  return `<div class="workspace-shell" data-organizer-username="${html(account.username)}" data-tour-pending="${account.tourPending === true}">
    <aside class="workspace-rail" aria-label="发布端侧边栏">
      ${organizerBrand()}
      <nav class="workspace-nav" aria-label="发布端导航">${workspaceLinks.map(item => `
        <a href="${item.path}"${current.section === item.section ? ' aria-current="page"' : ''}>
          <i class="nav-icon workspace-nav-icon ${item.icon}" aria-hidden="true"></i><span>${item.title}</span>
        </a>`).join('')}</nav>
      <div class="workspace-rail-footer" data-organizer-actions>
        <button class="workspace-guide-trigger" type="button" data-start-organizer-tour hidden>
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linejoin="round" aria-hidden="true"><path d="M12 6C9.2 4.1 5.8 3.8 2.5 4.7v13.4c3.3-.9 6.7-.6 9.5 1.4 2.8-2 6.2-2.3 9.5-1.4V4.7c-3.3-.9-6.7-.6-9.5 1.3Zm0 0v13.5"/></svg>
          新手指引
        </button>
        <div class="workspace-profile-strip">
          <a class="workspace-account" href="#organizer/account" aria-label="${html(account.name)}，账号设置">
            <span class="workspace-avatar" aria-hidden="true">${avatar}</span>
            <span class="workspace-identity"><strong title="${html(account.name)}">${html(account.name)}</strong><small>活动组织者</small></span>
          </a>
          <button class="workspace-logout" type="button" data-action="logout" aria-label="退出登录" title="退出登录">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M9 4H5a1 1 0 0 0-1 1v14a1 1 0 0 0 1 1h4m5-12 4 4-4 4m-5-4h10"/></svg>
          </button>
        </div>
        <div data-feedback></div>
      </div>
    </aside>
    <div class="workspace-main">
      <header class="workspace-topbar"><div class="workspace-breadcrumb"><a href="#organizer">活动发布端</a><span aria-hidden="true">/</span><span aria-current="page">${section === 'detail' ? '活动详情' : current.title}</span></div>
        <div class="workspace-topbar-actions">
          <a class="workspace-student-switch portal-switch" href="/#events">同学端 <span aria-hidden="true">↗</span></a>
        </div>
      </header>
      <div class="workspace-content">${output}</div>
    </div>
  </div>`;
}

function workspacePageHeading(title, description) {
  return `<div class="page-heading workspace-heading">
    <div><h1 id="page-title" tabindex="-1">${html(title)}</h1><p>${html(description)}</p></div>
  </div>`;
}

function workspaceEventRows(events, emptyTitle, emptyDescription) {
  if (!events.length) return `<div class="workspace-empty">
    <h3>${html(emptyTitle)}</h3><p>${html(emptyDescription)}</p>
  </div>`;
  return `<ul class="workspace-event-list">${events.map(event => {
    const date = dateParts(event.startsAt);
    return `<li><a class="workspace-event-row" href="#organizer/${pathId(event.id)}" data-event-status="${html(event.status)}">
      <span class="workspace-event-date" aria-hidden="true"><small>${html(date.month)}</small><strong>${html(date.day)}</strong></span>
      <span class="workspace-event-copy"><strong>${html(event.title)}</strong><small>${html(date.full)} · ${html(event.location)}</small></span>
      <span class="workspace-event-meta">${eventTag(event)}<small>${event.confirmed} / ${event.capacity} 人</small></span>
      <span class="workspace-event-action" aria-hidden="true">↗</span>
    </a></li>`;
  }).join('')}</ul>`;
}

function organizerOverview(events, account, message) {
  const published = events.filter(event => event.status === 'PUBLISHED').length;
  const attendees = events.reduce((count, event) => count + event.confirmed, 0);
  const recent = [...events].sort((a, b) => b.id - a.id).slice(0, 4);
  const now = new Date();
  const next = events.filter(event => event.status === 'PUBLISHED' && eventStartMillis(event) > now.getTime())
    .sort((a, b) => eventStartMillis(a) - eventStartMillis(b))[0];
  const today = new Intl.DateTimeFormat('zh-CN', { year: 'numeric', month: 'long', day: 'numeric', weekday: 'long' }).format(now);
  return `<div class="workspace-page workspace-overview">
    ${pageNotice(message)}
    <section class="workspace-hero">
      <div class="workspace-hero-photo" aria-hidden="true"></div>
      <div class="workspace-hero-copy">
        <time datetime="${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')}">${html(today)}</time>
        <h1 id="page-title" tabindex="-1">${html(account.name)}，你好</h1>
        ${next ? `<a class="workspace-next-event" href="#organizer/${pathId(next.id)}">
          <small>下一场活动</small><strong>${html(next.title)} <span aria-hidden="true">↗</span></strong>
          <span>${html(dateParts(next.startsAt).full)} · ${html(next.location)}</span></a>` : '<p>暂无即将开始的已发布活动。</p>'}
      </div>
    </section>
    <dl class="workspace-stats">
      <div class="workspace-stat"><dt>我的活动</dt><dd>${events.length}</dd></div>
      <div class="workspace-stat"><dt>已发布</dt><dd>${published}</dd></div>
      <div class="workspace-stat"><dt>草稿</dt><dd>${events.length - published}</dd></div>
      <div class="workspace-stat"><dt>有效报名</dt><dd>${attendees}</dd></div>
    </dl>
    <section class="workspace-section workspace-ledger" aria-labelledby="work-recent">
      <div class="section-heading"><h2 id="work-recent">近期创建</h2><a class="text-action" href="#organizer/events">查看全部 <span aria-hidden="true">↗</span></a></div>
      ${workspaceEventRows(recent, '还没有活动记录', '从「创建活动」保存第一份草稿，就能在这里找到它。')}
    </section>
  </div>`;
}

function organizerActivities(events, message) {
  return `<div class="workspace-page" data-workspace-events>
    ${workspacePageHeading('我的活动', '查看草稿、报名和现场签到。')}
    ${pageNotice(message)}
    <section class="workspace-section">
      <div class="workspace-toolbar">
        <div class="workspace-filters" role="group" aria-label="按状态查看活动">
          <button class="button button-secondary" type="button" data-workspace-filter="all" aria-pressed="true">全部</button>
          <button class="button button-secondary" type="button" data-workspace-filter="PUBLISHED" aria-pressed="false">已发布</button>
          <button class="button button-secondary" type="button" data-workspace-filter="DRAFT" aria-pressed="false">草稿</button>
        </div>
        <label class="workspace-search"><span>查找活动</span><input type="search" data-workspace-search placeholder="活动名称或地点"></label>
      </div>
      <div data-workspace-event-results>${workspaceEventRows(events, '还没有活动', '先创建一场活动，保存为草稿。')}</div>
    </section>
  </div>`;
}

function scheduleFieldsHtml(event = {}) {
  const duration = event.durationMinutes ?? 120;
  const opens = event.checkInOpensBeforeMinutes ?? 15;
  const closes = event.checkInClosesAfterMinutes ?? Math.min(30, duration);
  function minutes(name, label, value, min, max) {
    return `<label>${label}<span class="schedule-minute-input">
      <input name="${name}" type="number" inputmode="numeric" required step="1" min="${min}" max="${html(max)}" value="${html(value)}" data-initial-minutes="${html(value)}"${name === 'checkInClosesAfterMinutes' ? ' aria-describedby="schedule-close-feedback"' : ''}>
      <span>分钟</span></span></label>`;
  }
  return `<fieldset class="schedule-fields" data-schedule-start="${html(event.startsAt || '')}" data-custom-close="${event.checkInClosesAfterMinutes != null}">
    <legend>时长与签到</legend>
    <div class="schedule-inputs">
      ${minutes('durationMinutes', '活动时长', duration, 1, 1440)}
      ${minutes('checkInOpensBeforeMinutes', '签到开放 <small>开始前</small>', opens, 0, 1440)}
      ${minutes('checkInClosesAfterMinutes', '签到截止 <small>开始后</small>', closes, 1, duration)}
    </div>
    <p id="schedule-close-feedback" class="schedule-error" role="status"></p>
    <p class="schedule-summary" data-schedule-summary></p>
  </fieldset>`;
}

function organizerCreation(message) {
  return `<div class="workspace-page workspace-creation">
    ${pageNotice(message)}
    <div class="workspace-editor">
    <form class="workspace-form-card workspace-creation-form" id="create-event-form" aria-labelledby="page-title">
      ${workspacePageHeading('活动信息', '保存为草稿，核对后再开放报名。')}
      <div data-feedback></div>
      <div class="workspace-creation-fields">
        <label class="workspace-creation-name">活动名称<input name="title" maxlength="120" required placeholder="输入活动名称"></label>
        <div class="workspace-creation-template">
          <label for="event-template-trigger" id="event-template-label">活动模板 <small>选填</small></label>
          <div class="template-picker">
            <input type="hidden" name="eventTemplate" value="">
            <button type="button" id="event-template-trigger" role="combobox" data-creation-mode="template" aria-labelledby="event-template-label" aria-haspopup="listbox" aria-controls="event-template-options" aria-expanded="false">
              <span data-template-value>手动填写</span><span class="template-chevron" aria-hidden="true"></span>
            </button>
            <ul id="event-template-options" role="listbox" aria-labelledby="event-template-label" hidden>
              <li role="option" id="event-template-manual" aria-selected="true" data-value=""><span>手动填写</span></li>
              ${eventTemplates.map(({ id, label, fields }) => `<li role="option" id="event-template-${html(id)}" aria-selected="false" data-value="${html(id)}" aria-labelledby="event-template-name-${html(id)}" aria-describedby="event-template-size-${html(id)}"><span id="event-template-name-${html(id)}">${html(label)}</span><small id="event-template-size-${html(id)}">${html(fields.capacity)} 人</small></li>`).join('')}
            </ul>
          </div>
        </div>
        <label class="workspace-creation-time">开始时间 <small>北京时间</small><input name="startsAt" type="datetime-local" required></label>
        <label class="workspace-creation-location">活动地点<input name="location" maxlength="120" required placeholder="输入场地或教室"></label>
        <label class="workspace-creation-capacity">报名上限<input name="capacity" type="number" min="1" max="10000" step="1" required placeholder="填写人数"></label>
      </div>
      ${scheduleFieldsHtml()}
      <label>活动说明 <small>选填</small><textarea name="description" rows="4" maxlength="1000" placeholder="介绍内容、参加要求或现场安排"></textarea></label>
      <div class="workspace-creation-footer">
        <p class="workspace-template-feedback" role="status" data-template-status></p>
        <div class="actions"><a class="text-action" href="#organizer/events">返回我的活动</a><button class="button button-primary" type="submit">保存草稿</button></div>
      </div>
    </form>
    <aside class="draft-preview" aria-labelledby="draft-preview-title">
      <div class="draft-preview-heading"><h2 id="draft-preview-title">报名页预览</h2>
        <button type="button" aria-controls="draft-preview-card" aria-expanded="false" data-toggle-preview>展开预览</button>
      </div>
      <div class="draft-preview-card" id="draft-preview-card">
        <div class="draft-preview-cover"><h3 data-preview="title">未命名活动</h3></div>
        <div class="draft-preview-body">
          <dl><div><dt>时间</dt><dd data-preview="startsAt">待填写</dd></div>
            <div><dt>签到</dt><dd data-preview="checkInRange">待填写</dd></div>
            <div><dt>地点</dt><dd data-preview="location">待填写</dd></div>
            <div><dt>名额</dt><dd data-preview="capacity">待填写</dd></div></dl>
          <p class="draft-preview-description" data-preview="description" hidden></p>
        </div>
      </div>
    </aside>
    </div>
  </div>`;
}

function organizerAccount(account, legacy, message) {
  return `<div class="workspace-page">
    ${workspacePageHeading('账号设置', '查看发布端的账号信息。')}
    ${pageNotice(message)}
    <div class="workspace-account-grid">
      <section class="workspace-form-card" aria-labelledby="workspace-profile-title">
        <h2 id="workspace-profile-title">个人资料</h2>
        <dl class="workspace-profile"><div><dt>姓名</dt><dd>${html(account.name)}</dd></div><div><dt>用户名</dt><dd>${html(account.username)}</dd></div></dl>
      </section>
      ${legacy?.enabled ? `<section class="workspace-form-card workspace-legacy" aria-labelledby="workspace-legacy-title">
        <h2 id="workspace-legacy-title">迁入旧版活动</h2>
        <p>${legacy.available > 0 ? `有 ${legacy.available} 场旧版活动可迁入。迁入后由当前账号管理。` : '当前没有可迁入的旧版活动。'}</p>
        ${legacy.available > 0 ? '<form id="organizer-legacy-form"><div data-feedback></div><label>旧版迁移口令<input type="password" name="password" required autocomplete="off"></label><button class="button button-primary" type="submit">确认迁入活动</button></form>' : ''}
      </section>` : ''}
    </div>
  </div>`;
}

function organizerEventPage(event, registrations, message, preview = false) {
  const disabled = preview ? ' disabled' : '';
  const signup = preview
    ? '<button class="button button-secondary" type="button" disabled>查看同学端报名页 ↗</button>'
    : `<a class="button button-secondary" href="/${eventLink(event.id)}">查看同学端报名页 ↗</a>`;
  return `<div class="workspace-page workspace-event-detail">
    <a href="#organizer/events" class="back-link">← 返回我的活动</a>
    ${workspacePageHeading(event.title, `${activityTime(event)} · ${event.location}`)}
    ${preview ? '<p class="workspace-preview-note">新手指引示例 · 此页仅展示操作位置</p>' : ''}
    <div class="management-banner panel" data-event-actions>
      <div>${eventTag(event)}
      <p>${event.status === 'DRAFT' ? '发布后，同学可以在活动列表里报名。' : '同学可以通过活动页查看时间、地点和报名记录。'}</p>
      ${!preview && event.status === 'PUBLISHED' ? eventStartClock(event) : ''}</div>
      <div class="actions">${event.status === 'DRAFT'
        ? `<button class="button button-primary" type="button" data-action="publish-event"${disabled}>发布活动</button>`
        : `${signup}<button class="button button-secondary" type="button" data-action="copy-event-link"${disabled}>复制报名链接</button>`}</div>
      <div data-feedback>${pageNotice(message)}</div>
      <div class="share-fallback" hidden><label>报名链接<input type="url" readonly data-share-url></label></div>
    </div>
    ${preview ? '' : organizerScheduleSettings(event)}
    ${event.status === 'PUBLISHED' ? `<div class="operation-layout">
      ${qrPanel(event, preview)}
      <section class="panel roster-panel" aria-labelledby="roster-title">
        <div class="section-heading"><h2 id="roster-title">报名与到场名单</h2><span data-roster-count>${registrations.length} 条记录</span></div>
        <div data-roster-summary>${rosterSummary(registrations)}</div>
        <div class="roster-filter"><label>查找报名者<input type="search" data-roster-search placeholder="姓名或报名编号"${disabled}></label>
          <div class="actions"><button class="button button-secondary" type="button" data-action="refresh-roster"${disabled}>刷新</button>
          <button class="button button-secondary" type="button" data-action="export-roster"${disabled}>导出 CSV</button></div>
        </div><div data-feedback></div><div data-roster-results>${rosterResults(registrations, '', preview)}</div>
      </section>
    </div>` : ''}
  </div>`;
}

function organizerGuidePreview(section, account) {
  const published = section === 'guide-published';
  const event = {
    id: 0,
    title: '校园交流会（指引示例）',
    location: '学生活动中心',
    status: published ? 'PUBLISHED' : 'DRAFT',
    remaining: 19,
  };
  const roster = published ? [{ id: 0, name: '示例同学', identifier: 'DEMO-01', status: 'REGISTERED' }] : [];
  return workspaceFrame(account, 'detail', organizerEventPage(event, roster, '', true));
}

function qrMarkup(id, state) {
  if (!state) return '<div class="qr-placeholder">尚未生成签到码</div>';
  const url = siteLink(`#checkin/${pathId(id)}/${pathId(state.code)}`);
  let svg = '';
  try {
    svg = window.CampusQr?.toSvg(url) || '';
  } catch {
    // The textual code and link stay usable in case of a QR rendering error.
  }
  return `<div class="checkin-display">
      <div class="qr-state"><span>6 位签到码</span><strong class="checkin-code-value" data-checkin-code>${html(state.code)}</strong>
        <output aria-live="off" data-checkin-countdown></output>
        <button class="button button-secondary" type="button" data-action="copy-check-in-code">复制签到码</button>
      </div>
      <div class="qr-graphic" data-checkin-qr aria-label="手机扫码签到二维码" role="img">${svg || '使用下方活动签到链接'}</div>
    </div>
    <div class="qr-placeholder" data-checkin-expired hidden>签到码已过期，请重新生成</div>
    <a class="text-action" data-checkin-url href="${html(url)}" target="_blank" rel="noopener">打开同学端扫码页 <span aria-hidden="true">↗</span></a>`;
}

function qrPanel(event, preview) {
  const disabled = preview ? ' disabled' : '';
  const windowState = preview ? null : activeWindows.get(String(event.id));
  const loopback = ['localhost', '127.0.0.1', '[::1]'].includes(location.hostname);
  return `<section class="panel qr-panel">
    <h2>现场签到</h2><p>将 6 位签到码展示给同学，也可以用手机扫描二维码。</p>
    ${checkInSchedule(event)}
    <div class="qr-content">${qrMarkup(event.id, windowState)}</div>
    <div class="actions">${gateCheckIn(event, `<button class="button button-primary" type="button" data-action="open-check-in"${disabled}>${windowState ? '换新签到码' : '生成签到码'}</button>`)}
      <button class="button button-secondary" type="button" data-action="close-check-in"${disabled}>停止本场签到</button></div>
    <div data-feedback></div>
    ${loopback && !preview ? '<p class="field-note">当前地址仅本机可达。让手机扫码时，请从手机能访问的地址打开后台。</p>' : ''}
  </section>`;
}

function rosterSummary(registrations) {
  const count = status => registrations.filter(record => record.status === status).length;
  return `<dl class="metrics" aria-label="报名统计"><div><dt>待签到</dt><dd>${count('REGISTERED')}</dd></div>
    <div><dt>已签到</dt><dd>${count('CHECKED_IN')}</dd></div><div><dt>已取消</dt><dd>${count('CANCELLED')}</dd></div></dl>`;
}

function rosterResults(registrations, query = '', preview = false) {
  const needle = query.trim().toLowerCase();
  const disabled = preview ? ' disabled' : '';
  const matches = registrations.filter(record => [record.name, record.identifier].some(value => String(value ?? '').toLowerCase().includes(needle)));
  if (!matches.length) return `<div class="empty empty-small"><p>${needle ? '未找到匹配的报名记录。' : '暂无报名记录。'}</p></div>`;
  return `<div class="table-scroll"><table id="roster-table">
    <thead><tr><th scope="col">姓名</th><th scope="col">报名编号</th><th scope="col">状态</th><th scope="col">操作</th></tr></thead>
    <tbody>${matches.map(record => `<tr>
      <td>${html(record.name)}</td><td>${html(record.identifier)}</td><td>${rosterTag(record.status)}</td>
      <td>${record.status === 'REGISTERED' ? `<button class="button button-small" type="button" data-action="check-in" data-id="${html(record.id)}" aria-label="为 ${html(record.name)} 签到"${disabled}>补录签到</button>` : '<span class="muted">—</span>'}</td>
    </tr>`).join('')}</tbody>
  </table></div>`;
}

async function render({ focus = false } = {}) {
  const current = ++viewVersion;
  refreshDirectoryTime = null;
  clearInterval(rosterPoll);
  if (organizerPortal && !location.hash) history.replaceState(null, '', '#organizer');
  const { page, id, next, code, section } = route();
  if (!organizerPortal && page === 'organizer') {
    location.replace('/organizer.html' + location.hash);
    return;
  }
  if (organizerPortal && page !== 'organizer') {
    location.replace(siteLink(location.hash));
    return;
  }
  const hash = location.hash || '#events';
  const message = flash?.hash === hash ? flash.message : '';
  if (message) flash = undefined;
  const nav = page === 'organizer' ? 'organizer' : ['attendance', 'checkin', 'invalid-checkin'].includes(page)
    ? 'attendance' : ['mine', 'login', 'signup'].includes(page) ? 'mine' : 'events';
  for (const link of document.querySelectorAll('[data-nav]')) {
    if (link.dataset.nav === nav) link.setAttribute('aria-current', 'page');
    else link.removeAttribute('aria-current');
  }
  app.setAttribute('aria-busy', 'true');
  try {
    let output;
    let studentAccount;
    let bind = () => {};
    if (page === 'event' || page === 'checkin') {
      const [event, account] = await Promise.all([api(`/events/${id}`), optional('/account/session', 401)]);
      studentAccount = account;
      const registration = account ? await optional(`/events/${id}/registration`, 401, 404) : null;
      output = page === 'event' ? eventPage(event, account, registration, message) : checkInPage(event, account, registration, message);
      bind = page === 'event' ? () => bindRegistration(id) : () => bindSelfCheckIn(id, code);
    } else if (page === 'signup' || page === 'login') {
      output = accountPage(page, next, message);
      bind = () => bindAccount(page, hash, next);
    } else if (page === 'mine') {
      const account = await optional('/account/session', 401);
      studentAccount = account;
      const registrations = account ? await api('/account/registrations') : [];
      output = minePage(account, registrations, message);
      bind = bindAccountLogout;
    } else if (page === 'attendance') {
      const account = await optional('/account/session', 401);
      studentAccount = account;
      const registrations = account ? await api('/account/registrations') : [];
      output = attendancePage(account, registrations, message);
      bind = () => {
        const select = document.querySelector('#attendance-code-form [name="eventId"]');
        select?.addEventListener('change', () => {
          const entry = registrations.find(({ event }) => String(event.id) === select.value);
          select.form.querySelector('[data-attendance-controls]').innerHTML = checkInSchedule(entry?.event) + manualCheckInControls(entry?.event);
          inlineFeedback(select.closest('[data-feedback-scope]'), '');
        });
        bindManualCheckIn('#attendance-code-form');
      };
    } else if (page === 'invalid-checkin') {
      throw new RequestError('签到地址不完整，请重新扫描现场二维码。', 404);
    } else if (page === 'organizer') {
      const account = await optional('/organizer/session', 401);
      const authPage = section === 'login' || section === 'register';
      if (!account) {
        const returnTo = authPage ? next : hash;
        output = organizerAuthPage(section, returnTo, message);
        bind = () => bindOrganizerAuth(section, hash, returnTo);
      } else if (authPage) {
        navigate(next);
        return;
      } else if (section === 'new') {
        output = workspaceFrame(account, section, organizerCreation(message));
        bind = () => bindCreation(hash);
      } else if (section === 'guide-draft' || section === 'guide-published') {
        output = organizerGuidePreview(section, account);
      } else if (section === 'account') {
        const legacy = await api('/organizer/legacy');
        output = workspaceFrame(account, section, organizerAccount(account, legacy, message));
        bind = bindLegacyClaim;
      } else {
        const events = await api('/organizer/events');
        if (id) {
          const event = events.find(item => String(item.id) === id);
          if (!event) throw new RequestError('未找到这场活动。', 404);
          const records = await api(`/organizer/events/${id}/registrations`);
          output = workspaceFrame(account, 'detail', organizerEventPage(event, records, message));
          bind = () => bindManagement(id, records);
        } else if (section === 'events') {
          output = workspaceFrame(account, section, organizerActivities(events, message));
          bind = () => bindActivityFilters(events);
        } else {
          output = workspaceFrame(account, section, organizerOverview(events, account, message));
        }
      }
    } else {
      const [events, account] = await Promise.all([api('/events'), optional('/account/session', 401)]);
      studentAccount = account;
      const now = Date.now();
      output = eventsPage(events, account, now);
      bind = () => bindEventDirectory(events, now);
    }
    if (current !== viewVersion) return;
    app.innerHTML = output;
    bind();
    bindLogout();
    const directory = location.hash === '#published-events' ? document.querySelector('#published-events') : null;
    if (directory) directory.scrollIntoView({ block: 'start' });
    else if (presentedHash !== hash) window.scrollTo(0, 0);
    presentedHash = hash;
    if (focus) (directory || document.querySelector('#page-title'))?.focus({ preventScroll: true });
    if (!organizerPortal) window.updateStudentTour(studentAccount);
  } catch (error) {
    if (current !== viewVersion) return;
    app.innerHTML = `<section class="inner"><div class="panel failure">
      <h1 id="page-title" tabindex="-1">${error.status === 404 ? '未找到这个页面' : '页面暂时无法载入'}</h1>
      <p role="alert">${html(error.message || '请稍后再试。')}</p>
      <div class="actions"><button type="button" class="button button-primary" data-retry>重新载入</button><a class="button button-secondary" href="${organizerPortal ? '#organizer' : '#events'}">${organizerPortal ? '返回活动管理' : '返回活动列表'}</a></div>
    </div></section>`;
    document.querySelector('[data-retry]')?.addEventListener('click', () => render({ focus: true }));
    if (focus) document.querySelector('#page-title')?.focus();
  } finally {
    if (current === viewVersion) app.setAttribute('aria-busy', 'false');
  }
}

function bindRegistration(id) {
  onSubmit('#registration-form', async () => {
    await api(`/events/${id}/registrations`, { method: 'POST' });
    if (location.hash === eventLink(id)) navigate(eventLink(id), '报名成功，已为你保留名额。');
  });
  bindManualCheckIn('#manual-code-form', id);
  const cancel = document.querySelector('[data-action="cancel-registration"]');
  cancel?.addEventListener('click', () => perform(cancel, cancel.closest('.registration-panel'), async () => {
    await api(`/events/${id}/registration`, { method: 'DELETE' });
    if (location.hash === eventLink(id)) navigate(eventLink(id), '报名已取消，名额已释放。');
  }));
}

function bindManualCheckIn(selector, currentEventId) {
  const hash = location.hash;
  onSubmit(selector, async form => {
    const id = currentEventId || field(form, 'eventId');
    const code = normalizeCode(new FormData(form).get('code'));
    if (!/^\d+$/.test(id)) throw new Error('请选择要签到的活动。');
    if (!codePattern.test(code)) throw new Error('请输入现场展示的 6 位数字签到码。');
    await submitCheckIn(id, code);
    if (location.hash === hash) navigate(eventLink(id), '签到成功，已登记到场。');
  });
}

function submitCheckIn(id, code) {
  return api(`/events/${id}/self-check-in`, { method: 'POST', body: { code } });
}

function bindSelfCheckIn(id, code) {
  const hash = location.hash;
  onSubmit('#self-check-in-form', async () => {
    await submitCheckIn(id, code);
    if (location.hash === hash) navigate(hash, '已登记到场。');
  });
}

function bindAccount(mode, hash, next) {
  const registering = mode === 'signup';
  onSubmit(registering ? '#account-register-form' : '#account-login-form', async form => {
    const identifier = field(form, 'identifier');
    if (!identifierPattern.test(identifier)) throw new Error('报名编号需以字母或数字开头，可使用点、下划线和连字符。');
    const body = { identifier, password: new FormData(form).get('password') };
    if (registering) body.name = field(form, 'name');
    await api(registering ? '/account/register' : '/account/login', { method: 'POST', body });
    if (location.hash === hash) navigate(next, registering ? '账号已创建。' : '登录成功。');
  });
}

function bindAccountLogout() {
  const logout = document.querySelector('[data-action="account-logout"]');
  logout?.addEventListener('click', () => perform(logout, logout.closest('[data-account-actions]'), async () => {
    await api('/account/session', { method: 'DELETE' });
    if (route().page === 'mine') navigate('#mine', '已退出参与者账号。');
  }));
}

function bindOrganizerAuth(section, hash, next) {
  const registering = section === 'register';
  onSubmit(registering ? '#organizer-register-form' : '#organizer-login-form', async form => {
    const username = field(form, 'username');
    if (!organizerUsernamePattern.test(username)) throw new Error('用户名需为 3 至 40 位，以字母或数字开头，可包含点、下划线和连字符。');
    const body = { username, password: new FormData(form).get('password') };
    if (registering) body.name = field(form, 'name');
    await api(registering ? '/organizer/register' : '/organizer/login', { method: 'POST', body });
    activeWindows.clear();
    saveActiveWindows();
    if (location.hash === hash) navigate(next, registering ? '账号已创建。' : undefined);
  });
}

function organizerScheduleSettings(event) {
  const configured = event.durationMinutes != null;
  return `<details class="organizer-schedule-editor">
    <summary><strong>${configured ? '调整活动时段' : '设置活动时段'}</strong>
      <span>${configured ? `活动时长 ${html(event.durationMinutes)} 分钟` : '可设置活动时长和签到时间'}</span></summary>
    <form id="event-schedule-form" data-configured="${configured}">
      ${scheduleFieldsHtml(event)}
      <div data-feedback></div>
      <div class="schedule-editor-actions">
        ${event.status === 'PUBLISHED' ? '<p>调整时段会使当前签到码失效，已签到记录保留。</p>' : ''}
        <button type="submit" class="button button-primary">保存时段</button>
      </div>
    </form>
  </details>`;
}

function bindOrganizerSchedule(id) {
  const form = document.querySelector('#event-schedule-form');
  if (!form) return;
  bindScheduleFields(form);
  const initial = new FormData(form);
  onSubmit('#event-schedule-form', async () => {
    const body = {};
    const fields = ['durationMinutes', 'checkInOpensBeforeMinutes', 'checkInClosesAfterMinutes'];
    for (const key of fields) body[key] = Number(form.elements.namedItem(key).value);
    if (form.dataset.configured === 'true' && fields.every(key => Number(initial.get(key)) === body[key])) {
      inlineFeedback(form, '当前设置已生效。', false);
      return;
    }
    await api(`/organizer/events/${pathId(id)}/schedule`, { method: 'PATCH', body });
    activeWindows.delete(String(id));
    saveActiveWindows();
    if (location.hash === `#organizer/${id}`) navigate(location.hash, '活动时段已保存。');
  });
}

function bindLegacyClaim() {
  const hash = location.hash;
  onSubmit('#organizer-legacy-form', async form => {
    const result = await api('/organizer/claim-legacy', {
      method: 'POST', body: { password: new FormData(form).get('password') },
    });
    if (location.hash === hash) navigate(hash, `已迁入 ${result.claimed} 场旧版活动。`);
  });
}

function bindActivityFilters(events) {
  const workspace = document.querySelector('[data-workspace-events]');
  const filters = [...workspace.querySelectorAll('[data-workspace-filter]')];
  const search = workspace.querySelector('[data-workspace-search]');
  const results = workspace.querySelector('[data-workspace-event-results]');
  let status = 'all';
  const renderResults = () => {
    const term = search.value.trim().toLowerCase();
    const filtered = events.filter(event =>
      (status === 'all' || event.status === status) &&
      (!term || [event.title, event.location].some(text => text.toLowerCase().includes(term))));
    results.innerHTML = filtered.length || !events.length
      ? workspaceEventRows(filtered, '还没有活动', '先创建一场活动，保存为草稿。')
      : '<div class="workspace-empty"><h3>没有匹配的活动</h3><p>可以换个关键词，或查看其他状态。</p></div>';
  };
  for (const button of filters) {
    button.addEventListener('click', () => {
      status = button.dataset.workspaceFilter;
      for (const filter of filters) filter.setAttribute('aria-pressed', String(filter === button));
      renderResults();
    });
  }
  search.addEventListener('input', renderResults);
}

function bindLogout() {
  const logout = document.querySelector('[data-action="logout"]');
  logout?.addEventListener('click', () => perform(logout, logout.closest('[data-organizer-actions]'), async () => {
    await api('/organizer/session', { method: 'DELETE' });
    activeWindows.clear();
    saveActiveWindows();
    if (route().page === 'organizer') navigate('#organizer', '已退出组织者后台。');
  }));
}

function bindTemplatePicker(input) {
  const picker = input.closest('.template-picker');
  const trigger = picker.querySelector('[role="combobox"]');
  const list = picker.querySelector('[role="listbox"]');
  const options = [...list.querySelectorAll('[role="option"]')];
  let active = 0;
  let openListeners;

  function highlight(index) {
    options[active].removeAttribute('data-active');
    active = Math.max(0, Math.min(index, options.length - 1));
    const option = options[active];
    option.setAttribute('data-active', '');
    trigger.setAttribute('aria-activedescendant', option.id);
    if (option.offsetTop < list.scrollTop) list.scrollTop = option.offsetTop;
    const bottom = option.offsetTop + option.offsetHeight;
    if (bottom > list.scrollTop + list.clientHeight) list.scrollTop = bottom - list.clientHeight;
  }

  function position() {
    const rect = trigger.getBoundingClientRect();
    const viewport = window.visualViewport;
    const top = viewport?.offsetTop || 0;
    const left = viewport?.offsetLeft || 0;
    const bottom = top + (viewport?.height || window.innerHeight);
    const right = left + (viewport?.width || document.documentElement.clientWidth);
    if (!trigger.isConnected || rect.bottom <= top || rect.top >= bottom) return close();
    const above = rect.top - top - 12;
    const below = bottom - rect.bottom - 12;
    const upwards = below < list.scrollHeight + 2 && above > below;
    picker.toggleAttribute('data-opens-above', upwards);
    list.style.maxHeight = `${Math.max(0, upwards ? above : below)}px`;
    const aligned = rect.right - list.offsetWidth;
    const bounded = Math.max(left + 6, Math.min(aligned, right - list.offsetWidth - 6));
    list.style.marginInlineEnd = `${aligned - bounded}px`;
  }

  function close() {
    openListeners?.abort();
    openListeners = undefined;
    list.hidden = true;
    trigger.setAttribute('aria-expanded', 'false');
    trigger.removeAttribute('aria-activedescendant');
    options[active].removeAttribute('data-active');
  }

  function open() {
    if (!list.hidden) return;
    trigger.focus({ preventScroll: true });
    list.hidden = false;
    trigger.setAttribute('aria-expanded', 'true');
    position();
    if (list.hidden) return;
    highlight(options.findIndex(option => option.dataset.value === input.value));
    openListeners = new AbortController();
    const { signal } = openListeners;
    document.addEventListener('pointerdown', event => {
      if (!picker.contains(event.target)) close();
    }, { capture: true, signal });
    window.addEventListener('scroll', position, { passive: true, signal });
    window.addEventListener('resize', position, { signal });
    window.visualViewport?.addEventListener('resize', position, { signal });
    window.visualViewport?.addEventListener('scroll', position, { passive: true, signal });
    window.addEventListener('hashchange', close, { signal });
  }

  function choose(option) {
    input.value = option.dataset.value;
    input.dispatchEvent(new Event('change', { bubbles: true }));
    const selected = options.find(item => item.dataset.value === input.value);
    for (const item of options) item.setAttribute('aria-selected', String(item === selected));
    trigger.querySelector('[data-template-value]').textContent = selected.firstElementChild.textContent;
    close();
    trigger.focus({ preventScroll: true });
    input.form.dispatchEvent(new Event('creationpreviewchange'));
  }

  trigger.addEventListener('click', () => list.hidden ? open() : close());
  trigger.addEventListener('blur', close);
  // Keep DOM focus on the combobox while a pointer operates the active descendant.
  list.addEventListener('mousedown', event => {
    if (event.target.closest('[role="option"]')) event.preventDefault();
  });
  list.addEventListener('click', event => {
    const option = event.target.closest('[role="option"]');
    if (option) choose(option);
  });
  trigger.addEventListener('keydown', event => {
    if (event.isComposing) return;
    const { key } = event;
    if (key === 'Escape' && !list.hidden) {
      event.preventDefault();
      event.stopPropagation();
      close();
      return;
    }
    if (key === 'Tab') {
      if (!list.hidden && options[active].dataset.value !== input.value) choose(options[active]);
      else close();
      return;
    }
    if (key === 'Enter' || key === ' ') {
      event.preventDefault();
      if (list.hidden) open();
      else choose(options[active]);
      return;
    }
    if (['ArrowDown', 'ArrowUp', 'Home', 'End'].includes(key)) {
      event.preventDefault();
      open();
      if (key === 'Home') highlight(0);
      else if (key === 'End') highlight(options.length - 1);
      else highlight(active + (key === 'ArrowDown' ? 1 : -1));
    }
  });
}

function bindScheduleFields(form) {
  const group = form.querySelector('.schedule-fields');
  const { durationMinutes: duration, checkInOpensBeforeMinutes: opens, checkInClosesAfterMinutes: closes, startsAt } = form.elements;
  const error = group.querySelector('.schedule-error');
  const summary = group.querySelector('[data-schedule-summary]');
  let manualClose = group.dataset.customClose === 'true';
  const ranges = { activity: '', checkIn: '' };

  // datetime-local represents a campus wall-clock value even when the organizer travels.
  const savedStart = group.dataset.scheduleStart;
  const savedHasOffset = /(?:Z|[+-]\d\d:\d\d)$/i.test(savedStart);
  const savedWallTime = savedHasOffset
    ? Date.parse(savedStart) + 8 * 3600000 : Date.parse(savedStart + 'Z');

  function range(start, end) {
    const first = new Date(start).toISOString().slice(0, 16);
    const last = new Date(end).toISOString().slice(0, 16);
    const endLabel = first.slice(0, 10) === last.slice(0, 10) ? last.slice(11) : dateParts(last).full;
    return `${dateParts(first).full} 至 ${endLabel}`;
  }

  function update(event) {
    if (event && event.target !== startsAt && !group.contains(event.target)) return;
    if (event?.target === closes) manualClose = true;
    const minutes = duration.valueAsNumber;
    const validDuration = duration.validity.valid;
    closes.max = validDuration ? String(minutes) : '1440';
    if (validDuration && !manualClose && event?.target === duration) closes.value = String(Math.min(30, minutes));
    const message = validDuration && closes.valueAsNumber > minutes
      ? `签到截止不能晚于活动结束，请填写 1 至 ${minutes} 分钟。` : '';
    closes.setCustomValidity(message);
    if (message) closes.setAttribute('aria-invalid', 'true');
    else closes.removeAttribute('aria-invalid');
    error.textContent = message;
    const start = startsAt ? startsAt.valueAsNumber : savedWallTime;
    ranges.activity = Number.isFinite(start) && validDuration ? range(start, start + minutes * 60000) : '';
    ranges.checkIn = Number.isFinite(start) && validDuration && opens.validity.valid && closes.validity.valid
      ? range(start - opens.valueAsNumber * 60000, start + closes.valueAsNumber * 60000) : '';
    summary.textContent = [ranges.activity && '活动 ' + ranges.activity, ranges.checkIn && '签到 ' + ranges.checkIn]
      .filter(Boolean).join('\n');
  }
  form.addEventListener('input', update);
  update();
  return ranges;
}

function bindDraftPreview(form, ranges) {
  const preview = form.parentElement.querySelector('.draft-preview');
  const slots = [...preview.querySelectorAll('[data-preview]')];
  const toggle = preview.querySelector('[data-toggle-preview]');
  toggle.addEventListener('click', () => {
    const open = toggle.getAttribute('aria-expanded') !== 'true';
    toggle.setAttribute('aria-expanded', String(open));
    toggle.textContent = open ? '收起预览' : '展开预览';
  });
  function update() {
    for (const slot of slots) {
      const name = slot.dataset.preview;
      const input = form.elements.namedItem(name);
      const value = input?.value.trim() || '';
      let content = value;
      if (name === 'description') {
        slot.hidden = !value;
      } else if (name === 'title') {
        content = value || '未命名活动';
      } else if (name === 'startsAt') {
        content = ranges.activity || (value ? dateParts(value).full : '待填写');
      } else if (name === 'checkInRange') {
        content = ranges.checkIn || '待填写';
      } else if (name === 'capacity') {
        content = value && input.validity.valid ? `${value} 人` : '待填写';
      } else {
        content = value || '待填写';
      }
      if (slot.textContent !== content) slot.textContent = content;
    }
  }
  form.addEventListener('input', update);
  form.addEventListener('creationpreviewchange', update);
  update();
}

function bindCreation(hash) {
  const form = document.querySelector('#create-event-form');
  const ranges = bindScheduleFields(form);
  bindDraftPreview(form, ranges);
  const templateValue = form.elements.namedItem('eventTemplate');
  const templateStatus = form.querySelector('[data-template-status]');
  const templateValues = new Map();
  let appliedTemplate = '';
  form.addEventListener('input', event => templateValues.delete(event.target.name));
  templateValue.addEventListener('change', () => {
    if (!templateValue.value) {
      for (const [name, value] of templateValues) {
        const input = form.elements.namedItem(name);
        if (input.value === value) input.value = '';
      }
      templateValues.clear();
      appliedTemplate = '';
      templateStatus.textContent = '已切回手动填写。';
      return;
    }
    const template = eventTemplates.find(item => item.id === templateValue.value);
    const fields = Object.entries(template.fields);
    let kept = 0;
    for (const [name, value] of fields) {
      const input = form.elements.namedItem(name);
      if (input.value.trim() && input.value !== templateValues.get(name)) {
        kept++;
        continue;
      }
      input.value = value;
      templateValues.set(name, value);
    }
    if (kept === fields.length) {
      templateValue.value = appliedTemplate;
      templateStatus.textContent = '已保留所有手填内容。清空需要替换的字段后可套用模板。';
      return;
    }
    appliedTemplate = template.id;
    templateStatus.textContent = `已套用「${template.label}」${kept ? '，已保留手填内容' : ''}。`;
  });
  bindTemplatePicker(templateValue);
  onSubmit('#create-event-form', async form => {
    const body = {
      title: field(form, 'title'),
      description: field(form, 'description'),
      startsAt: field(form, 'startsAt'),
      durationMinutes: Number(field(form, 'durationMinutes')),
      checkInOpensBeforeMinutes: Number(field(form, 'checkInOpensBeforeMinutes')),
      checkInClosesAfterMinutes: Number(field(form, 'checkInClosesAfterMinutes')),
      location: field(form, 'location'),
      capacity: Number(field(form, 'capacity')),
    };
    const result = await api('/organizer/events', { method: 'POST', body });
    if (location.hash === hash) navigate(`#organizer/${pathId(result.id)}`, '草稿已保存，可以发布活动。');
  });
}

function bindManagement(id, records) {
  bindOrganizerSchedule(id);
  const hash = `#organizer/${id}`;
  const publish = document.querySelector('[data-action="publish-event"]');
  publish?.addEventListener('click', () => perform(publish, publish.closest('[data-event-actions]'), async () => {
    await api(`/organizer/events/${id}/publish`, { method: 'POST' });
    if (location.hash === hash) navigate(hash, '活动已发布，可以分享公开报名页。');
  }));
  const copy = document.querySelector('[data-action="copy-event-link"]');
  copy?.addEventListener('click', () => perform(copy, copy.closest('[data-event-actions]'), async () => {
    const container = copy.closest('[data-event-actions]');
    const url = siteLink(eventLink(id));
    try {
      await navigator.clipboard.writeText(url);
      inlineFeedback(container, '报名链接已复制。', false);
    } catch {
      const fallback = container.querySelector('.share-fallback');
      fallback.hidden = false;
      const input = fallback.querySelector('[data-share-url]');
      input.value = url;
      input.select();
      inlineFeedback(container, '报名链接已选中，可以复制。', false);
    }
  }));
  const qr = document.querySelector('.qr-panel');
  if (qr) bindQr(id, qr);

  const roster = document.querySelector('.roster-panel');
  if (!roster) return;
  const search = roster.querySelector('[data-roster-search]');
  const results = roster.querySelector('[data-roster-results]');
  let registrations = records;
  let refreshing = null;
  const redrawResults = () => results.innerHTML = rosterResults(registrations, search.value);
  const refresh = () => {
    if (refreshing) return refreshing;
    refreshing = api(`/organizer/events/${id}/registrations`).then(updated => {
      if (!roster.isConnected || location.hash !== hash) return;
      if (JSON.stringify(updated) === JSON.stringify(registrations)) return;
      registrations = updated;
      roster.querySelector('[data-roster-count]').textContent = `${registrations.length} 条记录`;
      roster.querySelector('[data-roster-summary]').innerHTML = rosterSummary(registrations);
      redrawResults();
    }).finally(() => refreshing = null);
    return refreshing;
  };
  search.addEventListener('input', redrawResults);
  roster.addEventListener('click', event => {
    const button = event.target.closest('button[data-action]');
    if (!button) return;
    perform(button, roster, async () => {
      if (button.dataset.action === 'export-roster') {
        await refresh();
        if (roster.isConnected) exportRoster(id, registrations);
      } else if (button.dataset.action === 'refresh-roster') {
        await refresh();
        if (roster.isConnected) inlineFeedback(roster, '名单已更新。', false);
      } else if (button.dataset.action === 'check-in') {
        await api(`/organizer/events/${id}/registrations/${pathId(button.dataset.id)}/check-in`, { method: 'POST' });
        await refresh();
        if (roster.isConnected) inlineFeedback(roster, '已补录到场。', false);
      }
    });
  });
  rosterPoll = setInterval(() => {
    if (document.visibilityState === 'visible') refresh().catch(() => {});
  }, 6000);
}

function bindQr(id, qr) {
  const open = qr.querySelector('[data-action="open-check-in"]');
  const close = qr.querySelector('[data-action="close-check-in"]');
  const update = (button, publish) => perform(button, qr, async () => {
    open.disabled = true;
    close.disabled = true;
    try {
      const state = await api(`/organizer/events/${id}/check-in-window`, { method: publish ? 'POST' : 'DELETE' });
      if (publish) activeWindows.set(id, state);
      else activeWindows.delete(id);
      saveActiveWindows();
      if (qr.isConnected) {
        qr.querySelector('.qr-content').innerHTML = qrMarkup(id, state);
        open.textContent = publish ? '换新签到码' : '生成签到码';
        inlineFeedback(qr, publish ? '签到码已生效。' : '本场签到已停止。', false);
        updateCountdown();
      }
    } finally {
      open.disabled = false;
      close.disabled = false;
    }
  });
  open.addEventListener('click', () => update(open, true));
  close.addEventListener('click', () => update(close, false));
  qr.addEventListener('click', event => {
    const copy = event.target.closest('[data-action="copy-check-in-code"]');
    if (!copy) return;
    perform(copy, qr, async () => {
      const state = activeWindows.get(id);
      if (!state || Date.parse(state.expiresAt) <= Date.now()) throw new Error('签到码已过期，请换新。');
      try {
        await navigator.clipboard.writeText(state.code);
        inlineFeedback(qr, '签到码已复制。', false);
      } catch {
        const range = document.createRange();
        range.selectNodeContents(qr.querySelector('[data-checkin-code]'));
        const selection = window.getSelection();
        selection.removeAllRanges();
        selection.addRange(range);
        inlineFeedback(qr, '已选中签到码，可以复制。', false);
      }
    });
  });
  updateCountdown();
}

function updateCountdown() {
  const output = document.querySelector('[data-checkin-countdown]');
  if (!output) return;
  const state = activeWindows.get(route().id);
  const seconds = Math.max(0, Math.ceil((Date.parse(state?.expiresAt) - Date.now()) / 1000));
  if (!seconds) {
    const schedule = output.closest('.qr-panel').querySelector('[data-checkin-schedule]');
    const closed = schedule && Date.now() >= Number(schedule.dataset.closes);
    document.querySelector('[data-checkin-url]').hidden = true;
    document.querySelector('.checkin-display').hidden = true;
    const expired = document.querySelector('[data-checkin-expired]');
    expired.textContent = closed ? '本场签到时段已结束' : '签到码已过期，请在签到时段内换新';
    expired.hidden = false;
  } else {
    output.textContent = `本码剩余 ${Math.floor(seconds / 60)}:${String(seconds % 60).padStart(2, '0')}`;
  }
}

function updateEventStartClocks() {
  const now = Date.now();
  refreshDirectoryTime?.(now);
  for (const clock of app.querySelectorAll('[data-event-start-countdown]:not([data-event-started])')) {
    const start = Number(clock.dataset.eventStartCountdown);
    const end = Number(clock.dataset.eventEnd);
    const [label, text] = activityClockState(start, end, now);
    const caption = clock.querySelector('.event-start-label');
    if (caption.textContent !== label) caption.textContent = label;
    const value = clock.querySelector('[data-event-start-value]');
    if (value.textContent !== text) value.textContent = text;
    if (!label) clock.setAttribute('data-event-started', '');
    if (start <= now) {
      const featuredLabel = clock.closest('.featured')?.querySelector('[data-featured-start-label]');
      const featuredState = now < end ? '正在进行' : '活动提醒';
      if (featuredLabel && featuredLabel.textContent !== featuredState) featuredLabel.textContent = featuredState;
    }
  }
  for (const schedule of app.querySelectorAll('[data-checkin-schedule]')) {
    const [phase, left] = checkInPhase(Number(schedule.dataset.opens), Number(schedule.dataset.closes), now);
    const caption = schedule.querySelector('[data-checkin-phase]');
    const timer = schedule.querySelector('[data-checkin-time-left]');
    if (caption.textContent !== phase) caption.textContent = phase;
    if (timer.textContent !== left) timer.textContent = left;
  }
  for (const group of app.querySelectorAll('[data-checkin-gate]')) {
    const disabled = now < Number(group.dataset.opens) || now >= Number(group.dataset.closes);
    if (group.disabled !== disabled) group.disabled = disabled;
  }
  for (const offers of app.querySelectorAll('[data-registration-offers]:not([hidden])')) {
    if (now >= Number(offers.dataset.registrationOffers)) {
      offers.disabled = true;
      offers.hidden = true;
      offers.parentElement.querySelector('[data-registration-ended]').hidden = false;
    }
  }
  for (const tag of app.querySelectorAll('[data-registration-tag-end]')) {
    if (now >= Number(tag.dataset.registrationTagEnd)) {
      tag.textContent = '活动已结束';
      tag.className = 'tag tag-muted';
      tag.removeAttribute('data-registration-tag-end');
    }
  }
  for (const link of app.querySelectorAll('[data-card-action-end]')) {
    if (now >= Number(link.dataset.cardActionEnd)) {
      link.textContent = '查看详情';
      link.removeAttribute('data-card-action-end');
    }
  }
}

function csvText(value) {
  let cell = String(value ?? '');
  if (/^\s*[=+@-]/.test(cell) || /^[\t\r\n]/.test(cell)) cell = `'${cell}`;
  return `"${cell.replaceAll('"', '""')}"`;
}

function exportRoster(id, records) {
  const labels = { REGISTERED: '待签到', CHECKED_IN: '已签到', CANCELLED: '已取消' };
  const rows = [['姓名', '报名编号', '状态'], ...records.map(record => [record.name, record.identifier, labels[record.status] || record.status])];
  const csv = '\ufeff' + rows.map(row => row.map(csvText).join(',')).join('\r\n');
  const url = URL.createObjectURL(new Blob([csv], { type: 'text/csv;charset=utf-8' }));
  const download = document.createElement('a');
  download.href = url;
  download.download = `校园活动-${id}-报名名单.csv`;
  document.body.append(download);
  download.click();
  download.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

window.addEventListener('hashchange', () => render({ focus: true }));
window.addEventListener('pageshow', event => { if (event.persisted) render(); });
setInterval(() => {
  updateCountdown();
  updateEventStartClocks();
}, 1000);
document.querySelector('.skip-link').addEventListener('click', event => {
  event.preventDefault();
  document.querySelector('#main-section').focus();
});
render();
