function positionCampusTour(panel, anchor) {
  if (panel.hidden || !anchor?.isConnected) return;
  const viewport = window.visualViewport;
  const inset = 12;
  const gap = 12;
  const leftEdge = (viewport?.offsetLeft ?? 0) + inset;
  const topEdge = (viewport?.offsetTop ?? 0) + inset;
  const rightEdge = leftEdge + (viewport?.width ?? document.documentElement.clientWidth) - inset * 2;
  const bottomEdge = topEdge + (viewport?.height ?? document.documentElement.clientHeight) - inset * 2;
  const target = anchor.getBoundingClientRect();
  panel.style.maxWidth = Math.max(0, rightEdge - leftEdge) + 'px';
  panel.style.maxHeight = Math.max(80, bottomEdge - topEdge) + 'px';
  const width = panel.offsetWidth;
  const height = panel.offsetHeight;
  const centerX = target.left + target.width / 2;
  const centerY = target.top + target.height / 2;
  const horizontal = centerX - width / 2;
  const vertical = centerY - height / 2;
  const options = [
    { x: target.right + gap, y: vertical, space: rightEdge - target.right - gap - width },
    { x: target.left - gap - width, y: vertical, space: target.left - gap - leftEdge - width },
    { x: horizontal, y: target.bottom + gap, space: bottomEdge - target.bottom - gap - height },
    { x: horizontal, y: target.top - gap - height, space: target.top - gap - topEdge - height },
  ];
  const placement = options.find(option => option.space >= 0) ||
    (options[2].space > options[3].space ? options[2] : options[3]);
  const left = Math.max(leftEdge, Math.min(placement.x, rightEdge - width));
  const top = Math.max(topEdge, Math.min(placement.y, bottomEdge - height));
  panel.style.left = left + 'px';
  panel.style.top = top + 'px';
}
