# 手机扫码试点部署

这一部署使用独立的 HTTPS 域名、Caddy 和一台校园场务服务。使用部署地址登录组织者后台，再生成签到码。手机相机识别后会打开同一个域名。

## 启动

1. 准备能从参与者手机网络访问的域名，将 DNS 指向运行 Docker 的服务器，并开放入站 80 和 443。
2. 在 `deploy` 目录把 `.env.example` 复制为 `.env`，设置域名，填入稳定的随机签到签名密钥。对照项目根目录确认 `CAMPUS_JAR_PATH` 指向打包后的 JAR。
3. 在 `deploy` 目录运行 `docker compose up -d --build`。用 `docker compose logs caddy campus-events` 查看状态。
4. 用部署域名打开 `/organizer.html` 并注册组织者账号。先用一个试用活动走通发布、报名、扫码和后台核对。请同时用部署域名生成二维码，方便参与者跨设备打开。

浏览器的安装方式随平台不同。在 Android Chrome 中可从浏览器菜单安装，在 iPhone Safari 中可从分享菜单添加到主屏幕。安装和 Service Worker 需要手机访问到受信任的 HTTPS 地址，桌面本机开发可以使用 localhost。 [安装要求](https://developer.mozilla.org/zh-CN/docs/Web/Progressive_web_apps/Guides/Making_PWAs_installable)

应用数据写入 `campus_data` 卷，证书写入 `caddy_data` 卷。备份应用数据时先停止应用容器，保留部署域名和卷。恢复时使用相同应用版本验证活动、报名及签到状态。
