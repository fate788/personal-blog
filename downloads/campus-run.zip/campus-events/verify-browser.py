import contextlib
import io
import json
import os
import re
import secrets
import subprocess
import time
from datetime import datetime, timedelta, timezone
from pathlib import Path
from tempfile import mkdtemp
from urllib.request import urlopen

import cv2
import numpy as np
from PIL import Image
from playwright.sync_api import expect, sync_playwright


PROJECT = Path(__file__).resolve().parent
PORT = 8770
BASE = f"http://127.0.0.1:{PORT}"
EDGE = r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe"
RUNTIME = PROJECT / "runtime"
RUNTIME.mkdir(exist_ok=True)
INSTANCE = Path(mkdtemp(dir=RUNTIME, prefix="browser-v12-"))
LEGACY_PASSWORD = secrets.token_urlsafe(18)
ORGANIZER_PASSWORD = secrets.token_urlsafe(16)
ORGANIZER_USERNAME = "review-publisher"
PARTICIPANT_PASSWORD = secrets.token_urlsafe(14)
ENV = os.environ | {
    "CAMPUS_DB_URL": "jdbc:h2:file:./data/campus-events;MODE=MySQL;DB_CLOSE_ON_EXIT=FALSE;WRITE_DELAY=0",
    "CAMPUS_DB_USER": "sa",
    "CAMPUS_DB_PASSWORD": "",
    "CAMPUS_CHECK_IN_SECRET": secrets.token_urlsafe(32),
    "CAMPUS_LEGACY_ORGANIZER_PASSWORD": LEGACY_PASSWORD,
    "CAMPUS_SEED_SAMPLE": "true",
    "CAMPUS_SERVER_ADDRESS": "127.0.0.1",
    "SERVER_PORT": str(PORT),
}
JAR = PROJECT / "target" / "campus-events-0.12.0.jar"


@contextlib.contextmanager
def server(stage):
    with (INSTANCE / f"{stage}.log").open("wb") as log:
        process = subprocess.Popen(
            ["java", "-jar", str(JAR)], cwd=INSTANCE, env=ENV,
            stdout=log, stderr=subprocess.STDOUT, creationflags=subprocess.CREATE_NO_WINDOW,
        )
        try:
            for _ in range(120):
                if process.poll() is not None:
                    raise RuntimeError(f"Server stopped. Check {log.name}.")
                try:
                    with urlopen(f"{BASE}/api/events", timeout=0.5) as response:
                        assert response.status == 200
                    break
                except OSError:
                    time.sleep(0.25)
            else:
                raise RuntimeError(f"Server did not start. Check {log.name}.")
            yield
        finally:
            if process.poll() is None:
                process.terminate()
                process.wait(timeout=15)


def organizer_login(page):
    page.goto(f"{BASE}/organizer.html")
    form = page.locator("#organizer-login-form")
    form.locator('[name="username"]').fill(ORGANIZER_USERNAME)
    form.locator('[name="password"]').fill(ORGANIZER_PASSWORD)
    form.locator('[type="submit"]').click()
    expect(page.locator(".workspace-nav")).to_be_visible()


def organizer_register(page, username, name):
    page.goto(f"{BASE}/organizer.html#organizer/register")
    form = page.locator("#organizer-register-form")
    form.locator('[name="name"]').fill(name)
    form.locator('[name="username"]').fill(username)
    form.locator('[name="password"]').fill(ORGANIZER_PASSWORD)
    confirmation = form.locator('[name="confirmPassword"]')
    if confirmation.count():
        confirmation.fill(ORGANIZER_PASSWORD)
    form.locator('[type="submit"]').click()
    expect(page.locator(".workspace-nav")).to_be_visible()
    expect(page.locator(".workspace-identity")).to_contain_text(name)


def participant_login(page, identifier):
    form = page.locator("#account-login-form")
    form.locator('[name="identifier"]').fill(identifier)
    form.locator('[name="password"]').fill(PARTICIPANT_PASSWORD)
    form.locator('[type="submit"]').click()


def create_participant(page, event_id, name, identifier):
    page.goto(f"{BASE}/#event/{event_id}")
    page.locator(".registration-panel").get_by_role("link", name="注册账号").click()
    signup = page.locator("#account-register-form")
    signup.locator('[name="name"]').fill(name)
    signup.locator('[name="identifier"]').fill(identifier)
    signup.locator('[name="password"]').fill(PARTICIPANT_PASSWORD)
    signup.locator('[type="submit"]').click()
    expect(page).to_have_url(f"{BASE}/#event/{event_id}")
    expect(page.locator(".registration-panel")).to_contain_text(name)
    tour = page.locator("#student-tour")
    expect(tour.get_by_role("heading", name="找到活动并报名")).to_be_visible()
    for title in ("到场后签到", "查看报名记录"):
        tour.get_by_role("button", name="下一步").click()
        expect(tour.get_by_role("heading", name=title)).to_be_visible()
    tour.get_by_role("button", name="完成指引").click()
    expect(page).to_have_url(f"{BASE}/#event/{event_id}")
    page.locator("#registration-form [type='submit']").click()
    expect(page.locator('[data-action="cancel-registration"]')).to_be_visible()


def checkin_status(page, event_id):
    return page.request.get(f"{BASE}/api/events/{event_id}/registration").json()["status"]


def assert_checkin_boundaries(page, action, event):
    page.evaluate("window.realNow = Date.now")
    for stamp, offset, enabled in (
        (event["checkInOpensAt"], -1, False),
        (event["checkInOpensAt"], 0, True),
        (event["checkInClosesAt"], -1, True),
        (event["checkInClosesAt"], 0, False),
    ):
        page.evaluate("([stamp,offset]) => { Date.now = () => Date.parse(stamp) + offset }", [stamp, offset])
        if enabled:
            expect(action).to_be_enabled()
        else:
            expect(action).to_be_disabled()
    page.evaluate("Date.now = window.realNow")
    expect(action).to_be_enabled()


def decoded_qr(page):
    qr = page.locator("[data-checkin-qr]")
    expect(qr).to_be_visible()
    pixels = qr.screenshot(path=INSTANCE / "checkin-qr.png")
    matrix = cv2.imdecode(np.frombuffer(pixels, np.uint8), cv2.IMREAD_GRAYSCALE)
    detector = cv2.QRCodeDetector()
    for size in (None, 440, 660):
        scaled = matrix if size is None else cv2.resize(matrix, (size, size), interpolation=cv2.INTER_NEAREST)
        url, _, _ = detector.detectAndDecode(scaled)
        if url:
            return url
    raise AssertionError("Could not decode the displayed QR code")


with sync_playwright() as playwright:
    browser = playwright.chromium.launch(executable_path=EDGE, headless=True)
    desktop = browser.new_page(viewport={"width": 1450, "height": 960}, reduced_motion="reduce")
    organizer = browser.new_page(viewport={"width": 1450, "height": 960}, accept_downloads=True, reduced_motion="reduce")
    phone = browser.new_page(viewport={"width": 390, "height": 844}, is_mobile=True, has_touch=True, reduced_motion="reduce")
    errors = []
    for page in (desktop, organizer, phone):
        page.on("pageerror", lambda error: errors.append(str(error)))

    with server("initial"):
        desktop.goto(f"{BASE}/")
        expect(desktop.locator("main")).to_contain_text("校园开发者分享会")
        expect(desktop.locator("html")).to_have_css("background-color", "rgb(247, 242, 234)")
        expect(desktop.locator('meta[name="theme-color"]')).to_have_attribute("content", "#4a1d29")
        expect(desktop.locator(".hero-side")).to_have_css("background-image", re.compile("campus-gallery.webp"))
        expect(desktop.locator(".featured [data-event-start-countdown]")).to_contain_text("距活动开始")
        directory_search = desktop.locator("[data-event-search]")
        directory_search.fill("204")
        expect(desktop.locator("#event-list")).to_contain_text("校园开发者分享会")
        directory_search.fill("无匹配项")
        expect(desktop.locator("#event-list")).to_contain_text("没有匹配的活动")
        desktop.locator("[data-reset-events]").click()
        expect(directory_search).to_have_value("")
        upcoming = desktop.locator('[data-event-view="upcoming"]')
        upcoming.click()
        expect(upcoming).to_have_attribute("aria-pressed", "true")
        desktop.locator('[data-event-view="all"]').click()
        assert desktop.evaluate("""async () => (await document.fonts.load('600 36px "Campus Serif UI"', '校园活动'))
            .some(face => face.status === 'loaded')""")
        for image_name in ("campus-gallery", "event-venue"):
            asset = desktop.request.get(f"{BASE}/images/{image_name}.webp")
            assert asset.ok
            with Image.open(io.BytesIO(asset.body())) as photo:
                assert photo.format == "WEBP" and photo.width >= 1200
        desktop.screenshot(path=INSTANCE / "home-desktop.png", full_page=True)
        manifest = desktop.locator('link[rel="manifest"]').get_attribute("href")
        response = desktop.request.get(f"{BASE}/{manifest.lstrip('/')}")
        assert response.ok
        settings = response.json()
        assert settings["display"] == "standalone"
        assert settings["theme_color"] == "#4a1d29"
        assert settings["background_color"] == "#f7f2ea"
        for dimension in (192, 512):
            icon = next(image for image in settings["icons"] if image["sizes"] == f"{dimension}x{dimension}")
            pixels = desktop.request.get(f"{BASE}/{icon['src'].lstrip('/')}").body()
            assert Image.open(io.BytesIO(pixels)).size == (dimension, dimension)
        desktop.wait_for_function("navigator.serviceWorker.getRegistration().then(item => item?.active?.state === 'activated')")

        assert desktop.locator('header nav a[href*="organizer"]').count() == 0
        organizer.goto(f"{BASE}/organizer.html")
        expect(organizer.locator('meta[name="theme-color"]')).to_have_attribute("content", "#4a1d29")
        expect(organizer.locator("#organizer-login-form")).to_be_visible()
        expect(organizer.locator(".organizer-auth-story")).to_have_css("background-image", re.compile("event-venue.webp"))
        expect(organizer.get_by_role("link", name="注册组织者账号")).to_be_visible()
        organizer.screenshot(path=INSTANCE / "organizer-login.png", full_page=True)
        organizer_register(organizer, ORGANIZER_USERNAME, "场务负责人")
        assert organizer.url.startswith(f"{BASE}/organizer.html")
        expect(organizer.locator("#create-event-form")).to_have_count(0)
        expect(organizer.locator(".workspace-nav a")).to_have_count(4)
        expect(organizer.locator(".workspace-hero-photo")).to_have_css("background-image", re.compile("event-venue.webp"))
        expect(organizer.locator('a[href="#organizer/new"]')).to_have_count(1)
        tour = organizer.locator("#organizer-tour")
        tour_trigger = organizer.locator("[data-start-organizer-tour]")
        expect(tour_trigger).to_be_visible()
        expect(tour).to_be_visible()
        expect(tour.get_by_role("heading", name="活动概况")).to_be_visible()
        expect(organizer.locator(".workspace-rail-footer [data-start-organizer-tour]")).to_be_visible()
        organizer.screenshot(path=INSTANCE / "onboarding-desktop.png")
        for title, route in (
            ("活动概况", "#organizer"),
            ("创建活动", "#organizer"),
            ("从空白开始", "#organizer/new"),
            ("按需套用模板", "#organizer/new"),
            ("保存草稿", "#organizer/new"),
            ("查找和管理活动", "#organizer/events"),
            ("发布报名", "#organizer/guide-draft"),
            ("分享报名入口", "#organizer/guide-published"),
            ("开启现场签到", "#organizer/guide-published"),
            ("核对和导出名单", "#organizer/guide-published"),
            ("账号设置", "#organizer/account"),
        ):
            expect(tour.get_by_role("heading", name=title)).to_be_visible()
            expect(organizer).to_have_url(BASE + "/organizer.html" + route)
            expect(organizer.locator("[data-tour-highlight]")).to_have_count(1)
            if title == "按需套用模板":
                tour.locator('[data-tour-action="previous"]').click()
                expect(tour.get_by_role("heading", name="从空白开始")).to_be_visible()
                tour.locator('[data-tour-action="next"]').click()
                expect(tour.get_by_role("heading", name=title)).to_be_visible()
                trigger = organizer.locator('#create-event-form [role="combobox"][data-tour-highlight]')
                expect(trigger).to_contain_text("手动填写")
                trigger.click()
                trigger.press("Escape")
                expect(trigger).to_have_attribute("aria-expanded", "false")
                expect(tour).to_be_visible()
            if title == "发布报名":
                expect(organizer.locator('[data-action="publish-event"]')).to_be_disabled()
            if title == "开启现场签到":
                expect(organizer.locator('[data-action="open-check-in"]')).to_be_disabled()
                organizer.set_viewport_size({"width": 320, "height": 844})
                organizer.wait_for_function("""() => {
                    const bounds = document.querySelector('#organizer-tour').getBoundingClientRect();
                    return bounds.left >= 0 && bounds.right <= window.innerWidth + 1;
                }""")
                organizer.screenshot(path=INSTANCE / "tour-mobile.png", full_page=True)
                organizer.set_viewport_size({"width": 1450, "height": 960})
            tour.locator('[data-tour-action="next"]').click()
        expect(tour).to_be_hidden()
        assert organizer.request.get(f"{BASE}/api/organizer/events").json() == []
        organizer.goto(f"{BASE}/organizer.html#organizer")
        organizer.reload()
        expect(organizer.locator(".workspace-stats")).to_be_visible()
        expect(tour).to_be_hidden()
        tour_trigger.click()
        expect(tour).to_be_visible()
        tour.locator('[data-tour-action="skip"]').click()
        expect(tour).to_be_hidden()
        organizer.screenshot(path=INSTANCE / "workspace-empty.png", full_page=True)
        organizer.locator('.workspace-nav a[href="#organizer/account"]').click()
        claim = organizer.locator("#organizer-legacy-form")
        claim.locator('[name="password"]').fill(LEGACY_PASSWORD)
        claim.locator('[type="submit"]').click()
        expect(claim).to_have_count(0)
        organizer.locator('.workspace-nav a[href="#organizer/events"]').click()
        expect(organizer.locator("[data-workspace-event-results]")).to_contain_text("校园开发者分享会")
        organizer.locator('.workspace-nav a[href="#organizer/new"]').click()
        create = organizer.locator("#create-event-form")
        save = create.get_by_role("button", name="保存草稿")
        template_select = create.get_by_role("combobox", name=re.compile("活动模板"))
        stored_template = create.locator('[name="eventTemplate"]')
        options = create.get_by_role("listbox")
        def choose_template(value):
            template_select.click()
            options.locator(f'[role="option"][data-value="{value}"]').click()
        title_input = create.locator('[name="title"]')
        expect(organizer.get_by_role("form", name="活动信息")).to_be_visible()
        expect(stored_template).to_have_value("")
        expect(template_select).to_have_attribute("aria-expanded", "false")
        template_select.click()
        expect(options.get_by_role("option")).to_have_count(6)
        expect(options.get_by_role("option", selected=True)).to_contain_text("手动填写")
        title_input.click()
        expect(options).to_be_hidden()
        expect(organizer.locator("#app dialog")).to_have_count(0)
        for field_name in ("title", "startsAt", "capacity", "location", "description"):
            expect(create.locator(f'[name="{field_name}"]')).to_have_value("")
        for width, height in ((1450, 960), (679, 740), (390, 844), (320, 600)):
            organizer.set_viewport_size({"width": width, "height": height})
            form_bounds = create.bounding_box()
            template_bounds = template_select.bounding_box()
            assert form_bounds["x"] <= template_bounds["x"]
            assert template_bounds["x"] + template_bounds["width"] <= form_bounds["x"] + form_bounds["width"]
            assert organizer.evaluate("document.documentElement.scrollWidth <= window.innerWidth")
            template_select.click()
            bounds = options.bounding_box()
            assert bounds["x"] >= 0 and bounds["x"] + bounds["width"] <= width + 1
            assert bounds["y"] >= 0 and bounds["y"] + bounds["height"] <= height + 1
            organizer.screenshot(path=INSTANCE / f"organizer-create-{width}.png")
            template_select.press("Escape")
            expect(template_select).to_be_focused()
            preview_card = organizer.locator("#draft-preview-card")
            if width < 1120:
                expect(preview_card).to_be_hidden()
                organizer.locator("[data-toggle-preview]").click()
                expect(preview_card).to_be_visible()
                organizer.locator("[data-toggle-preview]").click()
                expect(preview_card).to_be_hidden()
            else:
                expect(preview_card).to_be_visible()
        organizer.set_viewport_size({"width": 1450, "height": 960})
        template_select.focus()
        template_select.press("ArrowDown")
        template_select.press("Enter")
        expect(stored_template).to_have_value("talk")
        expect(title_input).to_have_value("校园主题分享会")
        expect(organizer.locator('[data-preview="title"]')).to_have_text("校园主题分享会")
        expect(create.locator('[name="startsAt"]')).to_have_value("")
        save.click()
        assert not create.locator('[name="startsAt"]').evaluate("input => input.validity.valid")
        assert organizer.url.endswith("#organizer/new")
        assert len(organizer.request.get(f"{BASE}/api/organizer/events").json()) == 1

        campus_zone = timezone(timedelta(hours=8))
        event_start = (datetime.now(campus_zone) + timedelta(minutes=6)).replace(second=0, microsecond=0)
        stops = event_start.strftime("%Y-%m-%dT%H:%M")
        duration = create.locator('[name="durationMinutes"]')
        opens = create.locator('[name="checkInOpensBeforeMinutes"]')
        closes = create.locator('[name="checkInClosesAfterMinutes"]')
        expect(duration).to_have_value("120")
        expect(opens).to_have_value("15")
        expect(closes).to_have_value("30")
        duration.fill("12")
        expect(closes).to_have_value("12")
        closes.fill("13")
        assert not closes.evaluate("el => el.validity.valid")
        expect(create.locator(".schedule-error")).to_contain_text("不能晚于活动结束")
        duration.fill("90")
        closes.fill("20")
        opens.fill("15")
        create.locator('[name="startsAt"]').fill("2026-12-11T23:50")
        expect(organizer.locator('[data-preview="startsAt"]')).to_contain_text("01:20")
        expect(organizer.locator('[data-preview="checkInRange"]')).to_contain_text("00:10")
        create.locator('[name="startsAt"]').fill("2026-12-11T14:00")
        expect(organizer.locator('[data-preview="checkInRange"]')).to_contain_text("13:45")
        create.get_by_role("heading", name="活动信息").click()
        organizer.screenshot(path=INSTANCE / "schedule-create-desktop.png", full_page=True)
        create.locator('[name="startsAt"]').fill(stops)
        expect(organizer.locator('[data-preview="startsAt"]')).to_contain_text(stops[-5:])
        template_select.click()
        organizer.screenshot(path=INSTANCE / "template-preview-desktop.png")
        template_select.press("Escape")
        title_input.fill("活动测试标题")
        choose_template("")
        expect(title_input).to_have_value("活动测试标题")
        expect(create.locator('[name="startsAt"]')).to_have_value(stops)
        expect(create.locator('[name="location"]')).to_have_value("")
        expect(create.locator('[name="capacity"]')).to_have_value("")
        title_input.fill("")
        for template_id, title, location, capacity in (
            ("club", "社团招新见面会", "学生活动中心多功能厅", "40"),
            ("volunteer", "校园志愿服务行动", "校图书馆正门集合", "25"),
            ("sports", "校园羽毛球交流活动", "校体育馆羽毛球场", "24"),
        ):
            choose_template(template_id)
            expect(title_input).to_have_value(title)
            expect(create.locator('[name="location"]')).to_have_value(location)
            expect(create.locator('[name="capacity"]')).to_have_value(capacity)
            expect(create.locator('[name="description"]')).to_have_value(re.compile(r".+"))
            expect(create.locator('[name="startsAt"]')).to_have_value(stops)

        title_input.fill("移动签到验证场")
        create.locator('[name="capacity"]').fill("4")
        create.locator('[name="location"]').fill("实验楼 101")
        expect(organizer.locator('[data-preview="location"]')).to_have_text("实验楼 101")
        choose_template("workshop")
        expect(create.locator("[data-template-status]")).to_contain_text("已保留手填内容")
        expect(title_input).to_have_value("移动签到验证场")
        expect(create.locator('[name="capacity"]')).to_have_value("4")
        expect(create.locator('[name="location"]')).to_have_value("实验楼 101")
        expect(create.locator('[name="startsAt"]')).to_have_value(stops)
        expect(create.locator('[name="description"]')).to_have_value(re.compile("集中答疑"))
        create.locator('[name="description"]').fill("保留集中答疑并补充签到说明。")
        choose_template("club")
        expect(stored_template).to_have_value("workshop")
        expect(create.locator("[data-template-status]")).to_contain_text("已保留所有手填内容")
        expect(title_input).to_have_value("移动签到验证场")
        expect(create.locator('[name="description"]')).to_have_value("保留集中答疑并补充签到说明。")
        organizer.screenshot(path=INSTANCE / "organizer-create.png", full_page=True)
        save.click()
        publish = organizer.locator('[data-action="publish-event"]')
        expect(publish).to_be_visible()
        event_id = organizer.url.rsplit("/", 1)[-1]
        draft = next(event for event in organizer.request.get(f"{BASE}/api/organizer/events").json()
                     if str(event["id"]) == event_id)
        assert draft["status"] == "DRAFT"
        assert draft["startsAt"].startswith(stops)
        assert (draft["durationMinutes"], draft["checkInOpensBeforeMinutes"], draft["checkInClosesAfterMinutes"]) == (90, 15, 20)
        assert draft["location"] == "实验楼 101" and draft["capacity"] == 4
        assert "集中答疑" in draft["description"]
        assert desktop.request.get(f"{BASE}/api/events/{event_id}").status == 404
        publish.click()
        expect(organizer.locator('[data-action="open-check-in"]')).to_be_visible()
        expect(organizer.locator("[data-event-start-countdown]")).to_contain_text("距活动开始")

        clock_page = browser.new_page(viewport={"width": 320, "height": 740}, reduced_motion="reduce", timezone_id="America/Los_Angeles")
        clock_page.goto(f"{BASE}/#event/{event_id}")
        clock_container = clock_page.locator("[data-event-start-countdown]")
        expected_start = int(event_start.timestamp() * 1000)
        assert expected_start == clock_page.evaluate("date => Date.parse(date)", draft["startsAtInstant"])
        expect(clock_container).to_have_attribute("data-event-start-countdown", str(expected_start))
        clock = clock_container.locator("[data-event-start-value]")
        phase = clock_page.locator("[data-checkin-phase]").first
        clock_page.evaluate("start => { window.reviewClock = start - 15*60000 - 1; Date.now = () => window.reviewClock; }", expected_start)
        expect(phase).to_have_text("签到未开放")
        clock_page.evaluate("window.reviewClock += 1")
        expect(phase).to_have_text("签到时段开放中")
        clock_page.evaluate("start => { window.reviewClock = start - 9000; Date.now = () => window.reviewClock; }", expected_start)
        expect(clock).to_have_text("9 秒")
        clock_page.evaluate("window.reviewClock += 2000")
        expect(clock).to_have_text("7 秒")
        assert clock_page.evaluate("document.documentElement.scrollWidth <= window.innerWidth")
        clock_page.screenshot(path=INSTANCE / "event-start-countdown-mobile.png")
        clock_page.evaluate("window.reviewClock += 8000")
        expect(clock_container).to_contain_text("距结束")
        clock_page.evaluate("start => window.reviewClock = start + 20 * 60000", expected_start)
        expect(phase).to_have_text("签到已截止")
        expect(clock_container).to_contain_text("距结束")
        clock_page.evaluate("start => window.reviewClock = start + 90 * 60000", expected_start)
        expect(clock).to_have_text("活动已结束")
        clock_page.context.close()

        outsider = browser.new_page(viewport={"width": 390, "height": 844})
        organizer_register(outsider, "isolated-publisher", "第二位负责人")
        assert outsider.evaluate("document.documentElement.scrollWidth <= window.innerWidth")
        outsider.goto(f"{BASE}/organizer.html#organizer/{event_id}")
        expect(outsider.locator("main")).to_contain_text(re.compile("找不到|未找到"))
        assert outsider.request.get(f"{BASE}/api/organizer/events/{event_id}/registrations").status == 404
        outsider.context.close()

        create_participant(desktop, event_id, "输入码同学", "TEST-MANUAL-01")
        expect(desktop.locator("#manual-code-form")).to_be_visible()
        assert_checkin_boundaries(desktop, desktop.locator('#manual-code-form [type="submit"]'), draft)
        create_participant(phone, event_id, "移动联调同学", "TEST-MOBILE-01")
        phone.goto(f"{BASE}/#mine")
        phone.get_by_role("button", name="新手指引").click()
        expect(phone.locator("#student-tour")).to_be_visible()
        phone.locator("#student-tour").get_by_role("button", name="跳过").click()
        phone.locator('[data-action="account-logout"]').click()
        expect(phone.locator('[data-action="account-logout"]')).to_be_hidden()

        assert_checkin_boundaries(organizer, organizer.locator('[data-action="open-check-in"]'), draft)
        organizer.locator('[data-action="open-check-in"]').click()
        sign_in_url = decoded_qr(organizer)
        original_code = sign_in_url.rsplit("/", 1)[-1]
        schedule_editor = organizer.locator(".organizer-schedule-editor")
        schedule_editor.locator("summary").click()
        schedule_editor.locator('[name="checkInOpensBeforeMinutes"]').fill("25")
        schedule_editor.get_by_role("button", name="保存时段").click()
        expect(organizer.locator("[data-event-actions]")).to_contain_text("活动时段已保存")
        expect(organizer.locator('[data-checkin-qr]')).to_be_hidden()
        revoked = desktop.request.post(f"{BASE}/api/events/{event_id}/self-check-in", data={"code": original_code})
        assert revoked.status == 409
        organizer.locator('[data-action="open-check-in"]').click()
        sign_in_url = decoded_qr(organizer)
        assert sign_in_url.startswith(f"{BASE}/#checkin/{event_id}/"), sign_in_url
        code = sign_in_url.rsplit("/", 1)[-1]
        assert re.fullmatch(r"\d{6}", code), code
        assert original_code != code
        expect(organizer.locator("[data-checkin-code]")).to_contain_text(re.compile(r"\D*".join(code)))
        open_link = organizer.locator("[data-checkin-url]").evaluate(
            "element => element.value || element.href || element.textContent.trim()"
        )
        assert sign_in_url == open_link
        expect(organizer.locator('[data-action="copy-check-in-code"]')).to_be_visible()
        organizer.screenshot(path=INSTANCE / "organizer-desktop.png", full_page=True)
        organizer.set_viewport_size({"width": 320, "height": 860})
        assert organizer.evaluate("document.documentElement.scrollWidth <= window.innerWidth")
        organizer.set_viewport_size({"width": 1450, "height": 960})

        desktop.set_viewport_size({"width": 390, "height": 844})
        desktop.goto(f"{BASE}/#attendance")
        manual = desktop.locator("#attendance-code-form")
        manual.locator('[name="eventId"]').select_option(event_id)
        manual.locator('[name="code"]').fill(f"{(int(code) + 1) % 1_000_000:06d}")
        manual.locator('[type="submit"]').click()
        expect(desktop.locator("main [role='alert']")).to_contain_text("签到码")
        assert checkin_status(desktop, event_id) == "REGISTERED"
        manual.locator('[name="code"]').fill(code)
        assert checkin_status(desktop, event_id) == "REGISTERED"
        desktop.screenshot(path=INSTANCE / "manual-entry-mobile.png", full_page=True)
        manual.locator('[type="submit"]').click()
        expect(desktop.locator("main")).to_contain_text(re.compile("签到已完成|已登记到场|签到成功"))
        assert checkin_status(desktop, event_id) == "CHECKED_IN"
        assert desktop.evaluate("document.documentElement.scrollWidth <= window.innerWidth")

        phone.goto(sign_in_url)
        phone.get_by_role("link", name="登录后签到").click()
        participant_login(phone, "TEST-MOBILE-01")
        expect(phone.locator("#self-check-in-form")).to_be_visible()
        assert phone.url == sign_in_url
        assert phone.evaluate("document.documentElement.scrollWidth <= window.innerWidth")
        phone.screenshot(path=INSTANCE / "checkin-phone.png", full_page=True)
        phone.locator("#self-check-in-form [type='submit']").click()
        phone.wait_for_function(
            f"fetch('/api/events/{event_id}/registration').then(r => r.json()).then(x => x.status === 'CHECKED_IN')"
        )
        expect(phone.locator("main")).to_contain_text(re.compile("签到已完成|已登记到场"))
        phone.screenshot(path=INSTANCE / "success-phone.png", full_page=True)
        organizer.locator('[data-action="refresh-roster"]').click()
        row = organizer.locator("#roster-table tbody tr", has_text="移动联调同学")
        expect(row).to_contain_text("已签到")
        expect(organizer.locator("#roster-table tbody tr", has_text="输入码同学")).to_contain_text("已签到")
        export = organizer.locator('[data-action="export-roster"]')
        with organizer.expect_download() as download:
            export.click()
        csv = download.value.path().read_text(encoding="utf-8-sig")
        assert "移动联调同学" in csv and "输入码同学" in csv and csv.count("已签到") >= 2
        organizer.locator('[data-action="close-check-in"]').click()
        expect(organizer.locator('[data-checkin-qr]')).to_be_hidden()
        expect(organizer.locator(".qr-panel")).to_contain_text("本场签到已停止")

    with server("restart"):
        organizer_login(organizer)
        expect(organizer.locator(".workspace-identity")).to_contain_text("场务负责人")
        expect(organizer.locator("#organizer-tour")).to_be_hidden()
        fresh = browser.new_page()
        organizer_login(fresh)
        assert fresh.request.get(f"{BASE}/api/organizer/session").json()["tourPending"] is False
        expect(fresh.locator("#organizer-tour")).to_be_hidden()
        fresh.context.close()
        organizer.screenshot(path=INSTANCE / "workspace-desktop.png", full_page=True)
        phone.goto(f"{BASE}/#login")
        participant_login(phone, "TEST-MOBILE-01")
        expect(phone).to_have_url(f"{BASE}/#mine")
        expect(phone.locator("main")).to_contain_text("移动签到验证场")
        expect(phone.locator("main")).to_contain_text("已签到")
        restored = phone.request.get(f"{BASE}/api/events/{event_id}").json()
        assert (restored["durationMinutes"], restored["checkInOpensBeforeMinutes"], restored["checkInClosesAfterMinutes"]) == (90, 25, 20)
        assert phone.request.get(f"{BASE}/api/account/session").json()["tourPending"] is False
        expect(phone.locator("#student-tour")).to_be_hidden()
        assert phone.evaluate("document.documentElement.scrollWidth <= window.innerWidth")
        legacy = browser.new_page()
        legacy.goto(f"{BASE}/#organizer/{event_id}")
        expect(legacy).to_have_url(f"{BASE}/organizer.html#organizer/{event_id}")

    browser.close()
    assert not errors, errors

print(f"Passed event duration, check-in boundaries, schedule updates, code invalidation, both sign-in methods, restart persistence, and portal and PWA regressions. Screenshots: {INSTANCE}")
