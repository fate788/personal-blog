@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>&1
if errorlevel 1 goto usepython
py -3 server.py
goto finished
:usepython
python server.py
:finished
if errorlevel 1 pause
