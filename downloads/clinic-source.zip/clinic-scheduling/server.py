"""Run the local scheduling desk using Python's standard library."""
import argparse
from http.cookies import SimpleCookie, CookieError
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
from pathlib import Path
import sqlite3
from urllib.parse import urlsplit

import engine


ROOT = Path(__file__).resolve().parent
COOKIE = "clinic_demo_sid"
STATIC = {"/": ("index.html","text/html; charset=utf-8"),
          "/index.html": ("index.html","text/html; charset=utf-8"),
          "/app.js": ("app.js","text/javascript; charset=utf-8"),
          "/style.css": ("style.css","text/css; charset=utf-8")}


class Handler(BaseHTTPRequestHandler):
    def respond(self, status, content, mime, cookie=None):
        self.send_response(status)
        self.send_header("Content-Type", mime)
        self.send_header("Content-Length",str(len(content)))
        self.send_header("X-Content-Type-Options","nosniff")
        self.send_header("Cache-Control","no-store")
        self.send_header("Referrer-Policy","no-referrer")
        if cookie:
            self.send_header("Set-Cookie",f"{COOKIE}={cookie}; Path=/api; HttpOnly; SameSite=Strict; Max-Age=2592000")
        self.end_headers()
        self.wfile.write(content)

    def json_response(self, status, payload, cookie=None):
        self.respond(status,json.dumps(payload,ensure_ascii=False).encode("utf-8"),
                     "application/json; charset=utf-8",cookie)

    def session(self):
        cookie = SimpleCookie()
        try:
            cookie.load(self.headers.get("Cookie",""))
        except CookieError:
            return None
        sid = cookie.get(COOKIE)
        return sid.value if sid else None

    def validate_origin(self):
        port = self.server.server_port
        allowed = {f"127.0.0.1:{port}", f"localhost:{port}"}
        if port==80:
            allowed.update(("127.0.0.1","localhost"))
        host = self.headers.get("Host","").lower()
        if host not in allowed:
            raise engine.Problem("请通过本机地址打开工作台。",403)
        if self.headers.get("Origin") not in (None, "http://"+host):
            raise engine.Problem("当前来源无法访问此工作区。",403)
        if self.headers.get("Sec-Fetch-Site")=="cross-site":
            raise engine.Problem("请直接打开工作台。",403)

    def state(self):
        sid = self.session()
        if sid:
            try:
                return self.json_response(200,engine.get_state(self.server.database,sid))
            except engine.Problem as error:
                if error.status!=401:
                    raise
        sid, state = engine.open_session(self.server.database)
        self.json_response(200,state,sid)

    def read_action(self):
        sid = self.session()
        if not sid:
            raise engine.Problem("请先打开工作台以初始化工作区。",401)
        if self.headers.get_content_type()!="application/json":
            raise engine.Problem("请以 JSON 提交操作。",415)
        try:
            size = int(self.headers.get("Content-Length","-1"))
        except ValueError:
            size = -1
        if not 0<size<=16384:
            raise engine.Problem("请求体为空或过大。",413)
        try:
            data = json.loads(self.rfile.read(size).decode("utf-8"))
        except (UnicodeError, ValueError, RecursionError):
            raise engine.Problem("JSON 格式错误。",400)
        self.json_response(200,engine.apply(self.server.database,sid,data))

    def dispatch(self, method):
        try:
            route = urlsplit(self.path).path
            if route.startswith("/api/"):
                self.validate_origin()
            if method=="GET" and route=="/api/state":
                self.state()
            elif method=="POST" and route=="/api/action":
                self.read_action()
            elif method=="GET" and route in STATIC:
                filename, mime = STATIC[route]
                self.respond(200,(ROOT/"static"/filename).read_bytes(),mime)
            else:
                raise engine.Problem("未找到此接口或页面。",404)
        except engine.Problem as error:
            self.json_response(error.status,{"error":str(error)})
        except sqlite3.OperationalError:
            self.json_response(503,{"error":"数据库暂时不可用，请稍后重试。"})

    def do_GET(self):
        self.dispatch("GET")

    def do_POST(self):
        self.dispatch("POST")


def make_server(port, database):
    engine.initialize(database)
    httpd = ThreadingHTTPServer(("127.0.0.1",port), Handler)
    httpd.database = database
    return httpd


if __name__=="__main__":
    parser = argparse.ArgumentParser(description="门诊候补与改约工作台")
    parser.add_argument("--port",type=int,default=8796)
    parser.add_argument("--db",type=Path,default=ROOT/"data"/"clinic.sqlite3")
    args = parser.parse_args()
    with make_server(args.port,args.db) as server:
        print(f"http://127.0.0.1:{server.server_port}/",flush=True)
        try:
            server.serve_forever()
        except KeyboardInterrupt:
            pass
