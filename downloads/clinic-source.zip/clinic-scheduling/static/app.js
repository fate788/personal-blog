"use strict";

const byId = id => document.getElementById(id);
const workspace = byId("workspace");
const dialog = byId("dialog");
const titles = {
  schedule: ["排班与候补", "查看各班次的号源和候补顺序，在空位释放后处理限时确认。"],
  reschedule: ["停诊改约", "从受影响的预约中选取记录，分配到仍有余位的同科班次。"],
  events: ["事件记录", "按发生顺序追溯预约、号源保留和改约结果。"]
};
let state;
let selectedSlot = "";
let department = "";
let pendingDept = "";
let targetId = "";
let eventQuery = "";
let selection = new Set();
let submitting = false;
let submitDialog = null;
let restoreFocus = null;
let retryAction = null;
let dialogRevision;
const cjkDate = new Intl.DateTimeFormat("zh-CN", {timeZone:"Asia/Shanghai", month:"2-digit", day:"2-digit"});
const cjkTime = new Intl.DateTimeFormat("zh-CN", {timeZone:"Asia/Shanghai", hour:"2-digit", minute:"2-digit", hour12:false});

function esc(value) {
  return String(value ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[c]);
}
function moment(value) {
  const instant = new Date(value);
  return cjkDate.format(instant) + " " + cjkTime.format(instant);
}
function slotName(slot) { return slot.department + " · " + slot.label; }
function slotText(slot) { return slotName(slot) + " · " + moment(slot.start) + " · " + slot.id; }
function option(value, label, selected) {
  return '<option value="'+esc(value)+'"'+(value===selected?' selected':'')+'>'+esc(label)+'</option>';
}
function button(action, label, kind="small-button", attrs="") {
  return '<button type="button" class="'+kind+'" data-action="'+action+'" '+attrs+'>'+esc(label)+'</button>';
}
function field(name, label, attributes="") {
  return '<label class="dialog-field">'+label+'<input name="'+name+'" type="text" '+attributes+' required></label>';
}
function getRoute() {
  const [view,id] = location.hash.slice(1).split("/");
  return {view:Object.hasOwn(titles,view)?view:"schedule", id};
}
function note(text, failed=false) {
  const item = byId("notice");
  item.textContent = text;
  item.classList.toggle("failed", failed);
  item.hidden = !text;
}
function getSlots() { return state.slots.filter(s => !department || s.department===department); }
function getPending() { return state.records.filter(r => r.status==="pending"); }
function slotFor(record) { return state.slots.find(s => s.id===record.slot_id); }
function currentSlot() { return state.slots.find(s => s.id===selectedSlot); }
function metrics() {
  const list = [
    ["可预约号源",state.slots.filter(s=>s.status==="open").reduce((sum,s)=>sum+s.available,0),"席"],
    ["候补排队",state.records.filter(r=>r.status==="waiting").length,"人"],
    ["限时保留",state.records.filter(r=>r.status==="held").length,"席"],
    ["待改约",getPending().length,"笔"]
  ];
  return '<dl class="metrics">'+list.map(([label,value,unit])=>'<div class="metric"><dt>'+label+'</dt><dd>'+value+'<span>'+unit+'</span></dd></div>').join("")+'</dl>';
}
function slotRow(s) {
  const waiting = state.records.filter(r=>r.slot_id===s.id && r.status==="waiting").length;
  const usage = s.status==="suspended" ? "已停诊" : s.status==="closed" ? "已开诊" : s.available ? "余 "+s.available+" / "+s.capacity : "已满 / "+s.capacity;
  const percent = s.capacity ? Math.min(100,100*(s.booked+s.held)/s.capacity) : 0;
  return '<li><button type="button" class="slot-button" data-slot="'+esc(s.id)+'" aria-pressed="'+(s.id===selectedSlot)+'">'+
    '<span><strong class="slot-name">'+esc(s.department)+' <small class="slot-code">'+esc(s.id)+'</small></strong><span class="slot-meta">'+esc(moment(s.start))+' · '+esc(s.label)+'</span></span>'+
    '<span class="slot-usage">'+esc(usage)+'<i aria-hidden="true"><b style="width:'+percent+'%"></b></i></span>'+
    '<span class="slot-queue">'+waiting+'</span><span class="chevron" aria-hidden="true">›</span></button></li>';
}
function rosterRow(record) {
  const id=esc(record.id), held=record.status==="held", waiting=record.status==="waiting";
  let flag=held?'<span class="tag held">待确认</span>':waiting?'<span class="tag">第 '+esc(record.position)+' 位</span>':"";
  const detail=held?"保留至 "+moment(record.deadline):waiting?"候补登记":"已确认预约";
  let controls=held?button("confirm","确认保留","small-button primary",'data-record="'+id+'" aria-label="确认保留 '+id+'"'):"";
  if(slotFor(record).status==="open")controls+=button("cancel","取消","text-button",'data-record="'+id+'" aria-label="取消 '+id+'"');
  return '<li class="record"><div><strong class="ticket-id">'+esc(record.person)+' · '+id+'</strong><small class="record-meta">'+esc(detail)+'</small></div><div class="record-side">'+flag+controls+'</div></li>';
}
function roster(s) {
  if(!s) return '<section class="panel general-empty">请选择要查看的班次。</section>';
  const rows=state.records.filter(r=>r.slot_id===s.id);
  const booked=rows.filter(r=>r.status==="booked");
  const waiting=rows.filter(r=>r.status==="held").concat(rows.filter(r=>r.status==="waiting").sort((a,b)=>a.position-b.position));
  const sections=[["已确认预约",booked,"暂无已确认预约。"],["候补与限时保留",waiting,"当前班次没有候补记录。"]];
  const balance=s.status==="open"?"余 "+s.available+" / "+s.capacity+" 席":s.status==="suspended"?"已停诊":"已开诊";
  return '<section class="panel" aria-label="当前班次名单"><header class="roster-head" id="roster-top" tabindex="-1"><div class="slot-dateline"><span>当前班次 '+esc(s.id)+'</span><span>'+esc(moment(s.start))+'</span></div>'+
    '<div class="roster-title-row"><h2>'+esc(slotName(s))+'</h2><span class="roster-balance">'+esc(balance)+'</span></div></header>'+
    (s.status==="open"?'<div class="roster-actions">'+button("join",s.available?"登记预约":"登记候补","button primary")+button("suspend","停诊处理","text-button")+'</div>':
      s.status==="suspended"?'<div class="roster-actions"><a class="button" href="#reschedule">查看待改约记录 →</a></div>':'')+
    sections.map(([name,items,empty])=>'<div class="roster-sub"><h3>'+name+' <span class="count">'+items.length+'</span></h3>'+
      (items.length?'<ul class="records">'+items.map(rosterRow).join("")+'</ul>':'<p class="minor-empty">'+empty+'</p>')+'</div>').join("")+'</section>';
}
function schedule() {
  const deps=[...new Set(state.slots.map(s=>s.department))];
  if(department && !deps.includes(department)) department="";
  const slots=getSlots();
  if(!slots.some(s=>s.id===selectedSlot)) selectedSlot=slots[0]?.id || "";
  return '<div class="board"><section class="panel"><header class="panel-head"><h2>门诊排班</h2><label class="panel-filter"><span class="sr-only">筛选科室</span><select id="department">'+option("","全部科室",department)+deps.map(d=>option(d,d,department)).join("")+'</select></label></header>'+
    '<div class="slot-columns" aria-hidden="true"><span>科室 / 时段</span><span>号源</span><span>候补</span><span></span></div><ul class="slots">'+slots.map(slotRow).join("")+'</ul></section>'+roster(currentSlot())+'</div>';
}
function reschedule() {
  const all=getPending();
  if(!all.length) {
    selection.clear(); targetId="";
    return '<section class="panel"><header class="panel-head"><h2>待改约名单</h2></header><div class="general-empty"><strong>当前没有待改约预约</strong><p>班次停诊后，原有的已确认预约会在这里等候重新分配。</p><a class="button" href="#schedule">查看门诊排班 →</a></div></section>';
  }
  const depts=[...new Set(all.map(r=>slotFor(r).department))];
  if(!depts.includes(pendingDept)) pendingDept=depts[0];
  const records=all.filter(r=>slotFor(r).department===pendingDept);
  selection=new Set([...selection].filter(id=>records.some(r=>r.id===id)));
  const targets=state.slots.filter(s=>s.department===pendingDept && s.status==="open" && s.available>=Math.max(selection.size,1));
  if(!targets.some(s=>s.id===targetId)) targetId=targets[0]?.id || "";
  const list=records.map(r=>'<li class="record"><label class="check-label"><input type="checkbox" data-pending="'+esc(r.id)+'" '+(selection.has(r.id)?"checked":"")+'><span><strong class="ticket-id">'+esc(r.person)+' · '+esc(r.id)+'</strong><small class="record-meta">原班次 '+esc(slotText(slotFor(r)))+'</small></span></label>'+button("cancel","取消","text-button",'data-record="'+esc(r.id)+'" aria-label="取消 '+esc(r.id)+'"')+'</li>').join("");
  return '<div class="board"><section class="panel"><header class="panel-head"><h2>待改约名单</h2><label class="panel-filter"><span class="sr-only">待改约科室</span><select id="pending-dept">'+depts.map(d=>option(d,d,pendingDept)).join("")+'</select></label></header>'+
    '<div class="reschedule-body"><div class="section-tools"><label class="check-label"><input type="checkbox" id="select-all" '+(selection.size===records.length?"checked":"")+'>全选本组</label><span>'+records.length+' 笔待处理</span></div><ul class="records">'+list+'</ul></div></section>'+
    '<section class="panel"><header class="panel-head"><h2>重新分配号源</h2><span class="tag">已选 '+selection.size+' 笔</span></header>'+
    '<div class="target-body"><label for="target-slot">同科目标班次<select id="target-slot" '+(targets.length?"":"disabled")+'>'+
    (targets.length?targets.map(s=>option(s.id,slotText(s)+' · 余 '+s.available+' 席',targetId)).join(""):'<option>暂无足够余位的班次</option>')+
    '</select></label><p class="detail-note">'+(!targets.length&&selection.size>1?"可以减少勾选数量，分批安排到不同班次。":"所选预约会一并提交，人数须在目标余位以内。")+'</p>'+
    button("reschedule","办理改约","button primary",selection.size && targetId?"":"disabled")+'</div></section></div>';
}
function eventItems() {
  const q=eventQuery.trim().toLocaleLowerCase();
  const events=state.events.filter(e=>[e.text,e.slot_id,e.record_id,moment(e.time)].join(" ").toLocaleLowerCase().includes(q));
  return events.length?'<ol class="event-list">'+events.map(e=>'<li><time datetime="'+esc(e.time)+'">'+esc(moment(e.time))+'</time><p>'+esc(e.text)+'</p><small class="event-key">'+[e.record_id,e.slot_id].filter(Boolean).map(esc).join(" · ")+'</small></li>').join("")+'</ol>':'<p class="general-empty">'+(q?'没有匹配的记录。':'完成一次号源操作后，可在这里查看记录。')+'</p>';
}
function eventsView() {
  return '<section class="panel"><header class="panel-head"><h2>操作时间线</h2><label class="event-filter"><span class="sr-only">查找事件</span><input id="event-filter" type="search" placeholder="查记录 / 班次编号" value="'+esc(eventQuery)+'"></label></header><div class="event-body" id="event-list">'+eventItems()+'</div></section>';
}

function render() {
  const route=getRoute();
  document.querySelectorAll("[data-nav]").forEach(a=>a.dataset.nav===route.view?a.setAttribute("aria-current","page"):a.removeAttribute("aria-current"));
  byId("page-title").textContent=titles[route.view][0];
  byId("page-description").textContent=titles[route.view][1];
  document.title=titles[route.view][0]+" · 门诊候补与改约工作台";
  if(!state) return;
  byId("clock").textContent=moment(state.now);
  document.querySelectorAll('[data-action="advance"], [data-action="reset"]').forEach(b=>b.disabled=submitting);
  const content=route.view==="schedule"?schedule():route.view==="events"?eventsView():reschedule();
  workspace.innerHTML=metrics()+content;
  workspace.setAttribute("aria-busy","false");
  const all=byId("select-all");
  if(all) all.indeterminate=selection.size>0 && !all.checked;
}
async function load() {
  try {
    const response=await fetch("/api/state",{cache:"no-store"});
    if(!response.ok) throw Error();
    state=await response.json();
    const requested=getRoute().id;
    if(requested && state.slots.some(s=>s.id===requested)) selectedSlot=requested;
    render();
  } catch {
    workspace.setAttribute("aria-busy","false");
    if(!state) workspace.innerHTML='<p class="initial">无法读取当前工作区。 '+button("retry","重新载入")+'</p>';
    else note("未能刷新工作区，请检查本机服务后重试。",true);
  }
}
function openDialog(title, body, actionTitle="", callback=null) {
  restoreFocus=document.activeElement;
  dialogRevision=state?.revision;
  byId("dialog-title").textContent=title;
  byId("dialog-body").innerHTML=body;
  byId("dialog-error").hidden=true;
  byId("dialog-actions").innerHTML=button("close",callback?"返回":"知道了","button")+(callback?'<button type="submit" class="button primary">'+esc(actionTitle)+'</button>':"");
  submitDialog=callback;
  dialog.showModal();
  (dialog.querySelector("input") || dialog.querySelector("select") || dialog.querySelector('[data-action="close"]')).focus();
}
function closeDialog() {
  if(!submitting) dialog.close();
}
dialog.addEventListener("close",()=>{
  submitDialog=null;
  if(restoreFocus?.isConnected) restoreFocus.focus({preventScroll:true});
  else {
    const action=restoreFocus?.dataset.action;
    const record=restoreFocus?.dataset.record;
    const selector=action?'[data-action="'+CSS.escape(action)+'"]'+(record?'[data-record="'+CSS.escape(record)+'"]':""):"";
    const target=(selector && workspace.querySelector(selector)) || byId("roster-top") || byId("page-title");
    target.focus({preventScroll:true});
  }
});
dialog.addEventListener("cancel",event=>{if(submitting)event.preventDefault();});
async function mutate(payload, success, nextView) {
  if(submitting)return;
  const key=JSON.stringify(payload)+":"+dialogRevision;
  if(!retryAction || retryAction.key!==key) {
    retryAction={key,id:crypto.randomUUID ? crypto.randomUUID() : [...crypto.getRandomValues(new Uint32Array(4))].map(n=>n.toString(16)).join("-")};
  }
  submitting=true;
  const controls=[...dialog.querySelectorAll("button")];
  controls.forEach(b=>b.disabled=true);
  const error=byId("dialog-error");
  error.hidden=true;
  let completed=false;
  try {
    const response=await fetch("/api/action",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({...payload,request_id:retryAction.id,expected_revision:dialogRevision})});
    const updated=await response.json();
    if(!response.ok) {
      retryAction=null;
      if(response.status===409) {
        await load();
        if(dialogRevision!==state?.revision) {
          submitting=false;dialog.close();
          note((updated.error||"记录已发生变化")+"。已刷新工作区，请核对后重新操作。",true);
          return;
        }
      }
      error.textContent=updated.error || "操作未完成，请核对输入后重试。";
      error.hidden=false;
      return;
    }
    state=updated;
    retryAction=null;
    completed=true;
    if(payload.action==="reset") {
      department="";pendingDept="";selectedSlot="";targetId="";selection.clear();eventQuery="";
    }
    if(payload.action==="reschedule")selection.clear();
    if(nextView) {history.replaceState(null,"","#"+nextView);window.scrollTo(0,0);}
    render();note(success);
  } catch {
    error.textContent="没有收到服务结果。恢复连接后再次提交，可核对本次操作。";
    error.hidden=false;
  } finally {
    submitting=false;
    controls.forEach(b=>b.disabled=false);
    if(completed)dialog.close();
    document.querySelectorAll('[data-action="advance"], [data-action="reset"]').forEach(b=>b.disabled=!state);
  }
}
function actions(action, btn) {
  if(action==="close") {closeDialog();return;}
  if(action==="retry") {load();return;}
  if(action==="guide") {
    openDialog("操作指引",'<ol class="steps"><li><strong>释放号源</strong>在初始满员的 S01 班次取消一笔已确认预约，队首候补将获得限时保留。</li><li><strong>处理限时保留</strong>输入对应的虚构就诊编号确认，也可以推进演示时钟，查看保留到期后下一位如何递补。</li><li><strong>办理停诊改约</strong>选择仍有已确认预约的班次停诊，勾选待改约记录，再选择有余位的同科班次。一笔或多笔均可提交。</li></ol>');return;
  }
  if(!state || submitting)return;
  const slot=currentSlot();
  const record=state.records.find(r=>r.id===btn.dataset.record);
  if(action==="advance") {
    openDialog("推进演示时钟",'<p>时间向前推进后，系统将处理到期保留及后续递补。当前时间为 '+esc(moment(state.now))+'。</p><label class="dialog-field">推进时长<select name="minutes"><option value="1">1 分钟</option><option value="10" selected>10 分钟</option><option value="30">30 分钟</option><option value="1440">24 小时</option></select></label>',"推进时间",data=>mutate({action,minutes:Number(data.get("minutes"))},"演示时钟已推进，最新号源状态已更新。"));
  } else if(action==="reset") {
    openDialog("重置当前演示",'<p>本工作区将恢复为初始排班，清除本次的预约变更和操作记录。</p>',"确认重置",()=>mutate({action},"已恢复初始排班。","schedule"));
  } else if(action==="join" && slot) {
    const title=slot.available?"登记预约":"登记候补";
    openDialog(title,'<p>'+esc(slotText(slot))+'</p>'+field("person","虚构就诊编号",'placeholder="例如 P005" pattern="P[0-9]{3,5}" maxlength="6" title="大写 P 加 3 至 5 位数字" autocomplete="off"'),title,data=>mutate({action,slot_id:slot.id,person:String(data.get("person")).trim()},"已完成登记，请在本班次名单中核对结果。"));
  } else if(action==="confirm" && record) {
    openDialog("确认限时保留",'<p>记录 '+esc(record.id)+' 的保留截止于 '+esc(moment(record.deadline))+'。请核对名单并输入这笔记录对应的就诊编号。</p>'+field("person","确认人的虚构就诊编号",'placeholder="P 加 3 至 5 位数字" pattern="P[0-9]{3,5}" maxlength="6" autocomplete="off"'),"确认预约",data=>mutate({action,record_id:record.id,person:String(data.get("person")).trim()},"已确认保留号源。"));
  } else if(action==="cancel" && record) {
    openDialog("取消这条记录",'<p>'+esc(record.person)+' 的记录 '+esc(record.id)+' 将被取消。已占用或保留的号源会释放给可递补的候补记录。</p>',"确认取消",()=>mutate({action,record_id:record.id},"已取消 "+record.id+"，班次名单已更新。"));
  } else if(action==="suspend" && slot) {
    openDialog("确认班次停诊",'<p>'+esc(slotText(slot))+' 将停止登记。'+slot.booked+' 笔已确认预约转入待改约，该班次的候补和限时保留将取消。</p>',"确认停诊",()=>mutate({action,slot_id:slot.id},"班次已停诊，待改约名单已更新。","reschedule"));
  } else if(action==="reschedule" && selection.size && targetId) {
    const ids=[...selection],target=state.slots.find(s=>s.id===targetId);
    openDialog("确认改约",'<p>将 '+esc(ids.join("、"))+' 共 '+ids.length+' 笔预约改至 '+esc(slotText(target))+'。目标班次当前有 '+target.available+' 席余量。</p>',"确认改约",()=>mutate({action,record_ids:ids,slot_id:target.id},"已改约 "+ids.length+" 笔，详情已写入事件记录。"));
  }
}
byId("dialog-form").addEventListener("submit",event=>{
  event.preventDefault();
  if(submitDialog)submitDialog(new FormData(event.target));
});
document.addEventListener("click",event=>{
  const skip=event.target.closest(".skip");
  if(skip){event.preventDefault();byId("main").focus();return;}
  const btn=event.target.closest("[data-action]");
  if(btn){actions(btn.dataset.action,btn);return;}
  const row=event.target.closest("[data-slot]");
  if(row && !submitting) {
    selectedSlot=row.dataset.slot;
    history.replaceState(null,"","#schedule/"+encodeURIComponent(selectedSlot));
    render();
    if(matchMedia("(max-width:720px)").matches)byId("roster-top")?.focus();
    else workspace.querySelector('[data-slot="'+CSS.escape(selectedSlot)+'"]')?.focus({preventScroll:true});
  }
});
document.addEventListener("change",event=>{
  if(!state || submitting)return;
  const el=event.target;
  if(el.id==="department") {department=el.value;history.replaceState(null,"","#schedule");}
  else if(el.id==="pending-dept") {pendingDept=el.value;selection.clear();}
  else if(el.id==="target-slot") {targetId=el.value;return;}
  else if(el.id==="select-all") {
    selection=el.checked?new Set(getPending().filter(r=>slotFor(r).department===pendingDept).map(r=>r.id)):new Set();
  } else if(el.dataset.pending) {
    if(el.checked)selection.add(el.dataset.pending);else selection.delete(el.dataset.pending);
  } else return;
  render();
  const replaced=el.id?byId(el.id):workspace.querySelector('[data-pending="'+CSS.escape(el.dataset.pending)+'"]');
  replaced?.focus({preventScroll:true});
});
document.addEventListener("input",event=>{
  if(event.target.id==="event-filter") {eventQuery=event.target.value;byId("event-list").innerHTML=eventItems();}
});
window.addEventListener("hashchange",()=>{
  const route=getRoute();if(route.id) {department="";selectedSlot=route.id;}
  note("");render();window.scrollTo(0,0);
});
render();
load();
