"""Transactional scheduling for isolated, synthetic outpatient desks."""
from contextlib import closing
from datetime import datetime, timedelta, timezone
from pathlib import Path
import hashlib
import json
import re
import secrets
import sqlite3


ZONE = timezone(timedelta(hours=8))
START = int(datetime(2026, 12, 7, 8, 40, tzinfo=ZONE).timestamp())
HOLD_SECONDS = 600
ACTIVE = ("booked", "waiting", "held", "pending")
PERSON = re.compile(r"P[0-9]{3,5}\Z")
RECORD = re.compile(r"R[0-9]{3,9}\Z")
REQUEST_ID = re.compile(r"[a-zA-Z0-9._:-]{8,100}\Z")
SCHEMA = """
CREATE TABLE IF NOT EXISTS desks (
    key TEXT PRIMARY KEY, now INTEGER NOT NULL, revision INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS slots (
    desk TEXT NOT NULL REFERENCES desks(key), id TEXT NOT NULL, department TEXT NOT NULL,
    label TEXT NOT NULL, start INTEGER NOT NULL, capacity INTEGER NOT NULL CHECK(capacity>0),
    suspended INTEGER NOT NULL DEFAULT 0, PRIMARY KEY(desk,id)
);
CREATE TABLE IF NOT EXISTS records (
    desk TEXT NOT NULL, seq INTEGER NOT NULL, slot TEXT NOT NULL, person TEXT NOT NULL,
    status TEXT NOT NULL CHECK(status IN ('booked','waiting','held','pending','cancelled','expired')),
    deadline INTEGER, PRIMARY KEY(desk,seq), FOREIGN KEY(desk,slot) REFERENCES slots(desk,id),
    CHECK ((status='held') = (deadline IS NOT NULL))
);
CREATE UNIQUE INDEX IF NOT EXISTS one_active ON records(desk,slot,person)
  WHERE status IN ('booked','held','waiting','pending');
CREATE INDEX IF NOT EXISTS queue_order ON records(desk,slot,status,seq);
CREATE TABLE IF NOT EXISTS events (
    desk TEXT NOT NULL REFERENCES desks(key), seq INTEGER NOT NULL, time INTEGER NOT NULL,
    kind TEXT NOT NULL, text TEXT NOT NULL, record INTEGER, slot TEXT, PRIMARY KEY(desk,seq)
);
CREATE TABLE IF NOT EXISTS requests (
    desk TEXT NOT NULL REFERENCES desks(key), key TEXT NOT NULL, digest TEXT NOT NULL,
    PRIMARY KEY(desk,key)
);
"""


class Problem(Exception):
    def __init__(self, message, status=409):
        super().__init__(message)
        self.status = status


def iso(timestamp):
    return datetime.fromtimestamp(timestamp, ZONE).isoformat()


def rid(seq):
    return f"R{seq:03d}"


def connect(database):
    db = sqlite3.connect(database, isolation_level=None, timeout=12)
    db.row_factory = sqlite3.Row
    db.execute("PRAGMA foreign_keys=ON")
    return db


def initialize(database):
    Path(database).parent.mkdir(parents=True, exist_ok=True)
    with closing(connect(database)) as db:
        db.execute("PRAGMA journal_mode=WAL")
        db.executescript(SCHEMA)


class Desk:
    """All reads and writes in a request share a transaction and a workspace key."""
    def __init__(self, db, key):
        self.db = db
        self.key = key
        row = self.sql("SELECT now,revision FROM desks WHERE key=?").fetchone()
        if row is None:
            raise Problem("演示工作区不存在，请刷新页面。", 401)
        self.now = row["now"]
        self.revision = row["revision"]

    def sql(self, query, *args):
        return self.db.execute(query, (self.key, *args))

    def slot(self, value):
        if not isinstance(value, str):
            raise Problem("请选择有效号源。", 400)
        slot = self.sql("SELECT * FROM slots WHERE desk=? AND id=?", value).fetchone()
        if slot is None:
            raise Problem("找不到这个号源。", 404)
        return slot

    def record(self, value):
        if not isinstance(value, str) or not RECORD.fullmatch(value):
            raise Problem("请选择有效预约编号。", 400)
        row = self.sql("SELECT * FROM records WHERE desk=? AND seq=?", int(value[1:])).fetchone()
        if row is None:
            raise Problem("找不到这条预约。", 404)
        return row

    def event(self, kind, text, slot=None, record=None):
        n = self.sql("SELECT COALESCE(MAX(seq),0)+1 FROM events WHERE desk=?").fetchone()[0]
        self.sql("INSERT INTO events VALUES(?,?,?,?,?,?,?)", n, self.now, kind, text, record, slot)

    def free(self, slot):
        used = self.sql("SELECT count(*) FROM records WHERE desk=? AND slot=? "
                        "AND status IN ('booked','held')", slot["id"]).fetchone()[0]
        return slot["capacity"] - used

    def change(self, seq, status, deadline=None):
        self.sql("UPDATE records SET status=?2,deadline=?3 WHERE desk=?1 AND seq=?4",
                 status, deadline, seq)

    def check_time_conflict(self, person, slot, exclude=0):
        conflict = self.sql(
            "SELECT r.seq FROM records r JOIN slots s ON s.desk=r.desk AND s.id=r.slot "
            "WHERE r.desk=? AND r.person=? AND s.start=? AND r.seq!=? "
            "AND (r.status IN ('booked','held','waiting') OR (r.status='pending' AND r.slot=?))",
            person, slot["start"], exclude, slot["id"]).fetchone()
        if conflict:
            raise Problem("该编号在这个时段已有预约或候补记录。")


def seed(d):
    # The clock is deliberately virtual. Samples retain the same meaning whenever opened.
    for identifier, department, label, day, hour, capacity in [
        ("S01","综合门诊","一诊室",8,9,2), ("S02","综合门诊","二诊室",8,10,2),
        ("S03","综合门诊","一诊室",9,9,1), ("S04","健康咨询","三诊室",8,11,2),
    ]:
        start = int(datetime(2026, 12, day, hour, tzinfo=ZONE).timestamp())
        d.sql("INSERT INTO slots(desk,id,department,label,start,capacity) VALUES(?,?,?,?,?,?)",
              identifier, department, label, start, capacity)
    for seq, status in enumerate(("booked","booked","waiting","waiting"), 1):
        person = f"P{seq:03d}"
        d.sql("INSERT INTO records VALUES(?,?,?,?,?,NULL)", seq, "S01", person, status)
        action = "已预约" if status == "booked" else "已进入候补队列"
        d.event("booking" if status=="booked" else "join", f"{person} {action}。", "S01", seq)


def open_session(database):
    key = secrets.token_urlsafe(32)
    with closing(connect(database)) as db, db:
        db.execute("BEGIN IMMEDIATE")
        db.execute("INSERT INTO desks(key,now) VALUES(?,?)", (key, START))
        desk = Desk(db, key)
        seed(desk)
        return key, snapshot(desk)


def snapshot(d):
    slots = []
    for slot in d.sql("SELECT * FROM slots WHERE desk=? ORDER BY start,id"):
        counts = {r[0]:r[1] for r in d.sql(
            "SELECT status,count(*) FROM records WHERE desk=? AND slot=? GROUP BY status",slot["id"])}
        booked, held = counts.get("booked",0), counts.get("held",0)
        status = "suspended" if slot["suspended"] else "closed" if slot["start"]<=d.now else "open"
        slots.append(dict(id=slot["id"],department=slot["department"],label=slot["label"],
                          start=iso(slot["start"]),capacity=slot["capacity"],status=status,booked=booked,
                          held=held,available=slot["capacity"]-booked-held if status=="open" else 0))
    records = []
    positions = {}
    for row in d.sql("SELECT * FROM records WHERE desk=? ORDER BY seq"):
        position = None
        if row["status"] == "waiting":
            position = positions.get(row["slot"],0)+1
            positions[row["slot"]] = position
        records.append(dict(id=rid(row["seq"]),person=row["person"],slot_id=row["slot"],status=row["status"],
                            deadline=iso(row["deadline"]) if row["deadline"] is not None else None,
                            position=position))
    events = [dict(id=r["seq"],time=iso(r["time"]),kind=r["kind"],text=r["text"],
                   record_id=rid(r["record"]) if r["record"] else None,slot_id=r["slot"])
              for r in d.sql("SELECT * FROM events WHERE desk=? ORDER BY seq DESC")]
    return dict(now=iso(d.now),revision=d.revision,hold_minutes=HOLD_SECONDS//60,
                slots=slots,records=records,events=events)


def get_state(database, key):
    with closing(connect(database)) as db, db:
        db.execute("BEGIN")
        return snapshot(Desk(db,key))


def open_slot(slot, now):
    if slot["suspended"] or slot["start"]<=now:
        raise Problem("这个号源已停诊或已开始，无法接收预约。")


def offer_waiters(d, slot):
    if slot["suspended"] or slot["start"]<=d.now:
        return
    free = d.free(slot)
    rows = d.sql("SELECT seq,person FROM records WHERE desk=? AND slot=? AND status='waiting' "
                 "ORDER BY seq LIMIT ?",slot["id"],free).fetchall()
    deadline = min(slot["start"], d.now + HOLD_SECONDS)
    for row in rows:
        d.change(row["seq"], "held", deadline)
        d.event("offer",f"{row['person']} 按候补顺序获得留位，截止 {iso(deadline)[11:16]}。",
                slot["id"],row["seq"])


def person_id(value):
    if not isinstance(value,str) or not PERSON.fullmatch(value):
        raise Problem("请输入 P 加 3 至 5 位数字的虚构编号，例如 P005。",400)
    return value


def join(d, data):
    slot = d.slot(data.get("slot_id"))
    open_slot(slot,d.now)
    person = person_id(data.get("person"))
    d.check_time_conflict(person,slot)
    seq = d.sql("SELECT COALESCE(MAX(seq),0)+1 FROM records WHERE desk=?").fetchone()[0]
    status = "booked" if d.free(slot)>0 else "waiting"
    d.sql("INSERT INTO records VALUES(?,?,?,?,?,NULL)",seq,slot["id"],person,status)
    action = "已预约可用名额" if status == "booked" else "已按登记顺序候补"
    d.event("booking" if status=="booked" else "join",f"{person} {action}。",slot["id"],seq)


def cancel(d,data):
    row = d.record(data.get("record_id"))
    slot = d.slot(row["slot"])
    if row["status"] not in ACTIVE or (slot["start"]<=d.now and row["status"]!="pending"):
        raise Problem("当前状态无法取消。")
    d.change(row["seq"],"cancelled")
    d.event("cancel",f"{row['person']} 的记录已取消。",row["slot"],row["seq"])
    offer_waiters(d,slot)


def confirm(d,data):
    row = d.record(data.get("record_id"))
    if person_id(data.get("person")) != row["person"]:
        raise Problem("虚构编号与该留位记录不匹配。",403)
    if row["status"]!="held" or row["deadline"]<=d.now:
        raise Problem("只有截止前的有效留位可以确认。")
    d.change(row["seq"],"booked")
    d.event("confirm",f"{row['person']} 已确认候补名额。",row["slot"],row["seq"])


def advance_clock(d, data):
    minutes = data.get("minutes")
    if type(minutes) is not int or not 1<=minutes<=1440:
        raise Problem("每次可推进 1 至 1440 个整分钟。",400)
    target = d.now + minutes * 60
    # Process deadlines chronologically. A large jump can expire several successive offers.
    while True:
        next_time = d.sql(
            "SELECT MIN(at) FROM (SELECT deadline AS at FROM records WHERE desk=?1 AND status='held' "
            "UNION ALL SELECT s.start FROM records r JOIN slots s ON s.desk=r.desk AND s.id=r.slot "
            "WHERE r.desk=?1 AND r.status='waiting')").fetchone()[0]
        if next_time is None or next_time > target:
            break
        d.now = next_time
        expired = d.sql("SELECT seq,slot,person FROM records WHERE desk=? AND deadline=? ORDER BY seq",
                        next_time).fetchall()
        for row in expired:
            d.change(row["seq"],"expired")
            d.event("expire",f"{row['person']} 的留位已到期。",row["slot"],row["seq"])
        closed = d.sql("SELECT r.seq,r.person,r.slot FROM records r JOIN slots s ON s.desk=r.desk AND s.id=r.slot "
                       "WHERE r.desk=? AND r.status='waiting' AND s.start=? ORDER BY r.seq",next_time).fetchall()
        for row in closed:
            d.change(row["seq"],"expired")
            d.event("expire",f"{row['person']} 的候补在时段开始时结束。",row["slot"],row["seq"])
        for identifier in sorted({r["slot"] for r in expired}):
            offer_waiters(d,d.slot(identifier))
    d.now = target
    d.sql("UPDATE desks SET now=?2 WHERE key=?1",target)
    d.event("advance",f"演示时间已推进 {minutes} 分钟。")


def suspend(d,data):
    slot = d.slot(data.get("slot_id"))
    open_slot(slot,d.now)
    d.sql("UPDATE slots SET suspended=1 WHERE desk=? AND id=?",slot["id"])
    d.event("suspend",f"{slot['id']} 已停诊。",slot["id"])
    rows = d.sql("SELECT seq,person,status FROM records WHERE desk=? AND slot=? "
                 "AND status IN ('booked','held','waiting') ORDER BY seq",slot["id"]).fetchall()
    for row in rows:
        booked = row["status"]=="booked"
        d.change(row["seq"],"pending" if booked else "cancelled")
        text = "原预约已转为待改约" if booked else "未确认的候补已因停诊撤销"
        d.event("pending" if booked else "cancel",f"{row['person']} {text}。",slot["id"],row["seq"])


def reschedule(d,data):
    target = d.slot(data.get("slot_id"))
    open_slot(target,d.now)
    ids = data.get("record_ids")
    if not isinstance(ids,list) or not 1<=len(ids)<=100 or not all(isinstance(i,str) for i in ids):
        raise Problem("请至少选择一条待改约记录，每批不超过 100 条。",400)
    rows = [d.record(i) for i in ids]
    if len({r["seq"] for r in rows})!=len(rows):
        raise Problem("同一条预约在批次中只能选择一次。",400)
    if d.free(target)<len(rows):
        raise Problem("目标号源余量不足，整批预约均保留原状。")
    for row in rows:
        origin = d.slot(row["slot"])
        if row["status"]!="pending" or origin["department"]!=target["department"]:
            raise Problem("只能将待改约记录转入同科室的开放号源。")
        d.check_time_conflict(row["person"],target,row["seq"])
        d.sql("UPDATE records SET slot=?2,status='booked',deadline=NULL WHERE desk=?1 AND seq=?3",
              target["id"],row["seq"])
        d.event("reschedule",f"{row['person']} 已从 {origin['id']} 改约至 {target['id']}。",
                target["id"],row["seq"])


def reset(d, data):
    for table in ("events","records","slots"):
        d.sql("DELETE FROM "+table+" WHERE desk=?")
    d.now = START
    d.sql("UPDATE desks SET now=?2 WHERE key=?1", START)
    seed(d)


ACTIONS = {"join":join,"cancel":cancel,"confirm":confirm,"advance":advance_clock,
           "suspend":suspend,"reschedule":reschedule,"reset":reset}


def apply(database, key, data):
    if not isinstance(data,dict) or not isinstance(data.get("action"),str) or data["action"] not in ACTIONS:
        raise Problem("未识别的操作。",400)
    request_id = data.get("request_id")
    if request_id is not None and (not isinstance(request_id,str) or not REQUEST_ID.fullmatch(request_id)):
        raise Problem("请求标识格式错误。",400)
    digest = hashlib.sha256(json.dumps(data,sort_keys=True,separators=(",",":")).encode()).hexdigest()
    with closing(connect(database)) as db, db:
        db.execute("BEGIN IMMEDIATE")
        d = Desk(db,key)
        if request_id:
            prior = d.sql("SELECT digest FROM requests WHERE desk=? AND key=?",request_id).fetchone()
            if prior:
                if prior["digest"]!=digest:
                    raise Problem("同一请求标识不能用于不同操作。")
                return snapshot(d)
        if "expected_revision" in data:
            version = data["expected_revision"]
            if type(version) is not int or version!=d.revision:
                raise Problem("这个工作区已变更，请刷新后重试。")
        ACTIONS[data["action"]](d,data)
        d.revision += 1
        d.sql("UPDATE desks SET revision=?2 WHERE key=?1",d.revision)
        if request_id:
            d.sql("INSERT INTO requests VALUES(?,?,?)",request_id,digest)
        return snapshot(d)
