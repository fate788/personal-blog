# 门诊候补与改约工作台 v0.5 源码包

原始发布归档为 `门诊候补与改约工作台-v0.5.zip`。压缩包保留其中 9 份文本文件的原始路径与字节，本文件为导出说明。

在项目根目录运行 `python server.py` 启动本机服务，默认端口 8796。导诊大厅、预约窗口和诊区走廊三张 AI 生成的场景图内嵌于 `static/index.html`。中文字体内嵌于 `static/style.css`，许可和 README 实屏图随源码分发。运行 `python -m unittest discover -v` 验证预约调度规则。
