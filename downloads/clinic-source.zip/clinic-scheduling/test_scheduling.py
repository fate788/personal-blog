from concurrent.futures import ThreadPoolExecutor
from contextlib import closing
from http.cookiejar import CookieJar
import json
from pathlib import Path
from tempfile import TemporaryDirectory
from threading import Barrier, Thread
import unittest
from urllib.error import HTTPError
from urllib.request import HTTPCookieProcessor, Request, build_opener

import engine
from server import make_server


def item(state, section, identifier):
    return next(row for row in state[section] if row["id"]==identifier)


class SchedulingTest(unittest.TestCase):
    def setUp(self):
        folder = TemporaryDirectory()
        self.addCleanup(folder.cleanup)
        self.database = Path(folder.name)/"clinic.sqlite3"
        engine.initialize(self.database)
        self.key, self.initial = engine.open_session(self.database)

    def act(self, action, **data):
        return engine.apply(self.database,self.key,{"action":action,**data})

    def current(self):
        return engine.get_state(self.database,self.key)

    def test_fifo_confirmation_and_wrong_person(self):
        state = self.act("cancel",record_id="R001")
        self.assertEqual(item(state,"slots","S01")["held"],1)
        self.assertEqual(item(state,"records","R003")["deadline"],"2026-12-07T08:50:00+08:00")
        self.assertEqual(item(state,"records","R004")["position"],1)
        with self.assertRaises(engine.Problem) as error:
            self.act("confirm",record_id="R003",person="P004")
        self.assertEqual(error.exception.status,403)
        self.assertEqual(state,self.current())
        self.act("advance",minutes=9)
        state = self.act("confirm",record_id="R003",person="P003")
        self.assertEqual(item(state,"records","R003")["status"],"booked")
        self.assertEqual(item(state,"slots","S01")["booked"],2)

    def test_deadline_passes_exactly_to_next(self):
        self.act("cancel",record_id="R001")
        state = self.act("advance",minutes=10)
        self.assertEqual(item(state,"records","R003")["status"],"expired")
        self.assertEqual(item(state,"records","R004")["deadline"],"2026-12-07T09:00:00+08:00")
        with self.assertRaises(engine.Problem):
            self.act("confirm",record_id="R003",person="P003")

    def test_long_jump_processes_intermediate_deadlines(self):
        self.act("cancel",record_id="R001")
        state = self.act("advance",minutes=35)
        self.assertEqual(item(state,"records","R003")["status"],"expired")
        self.assertEqual(item(state,"records","R004")["status"],"expired")
        self.assertEqual([e["time"][11:16] for e in state["events"] if e["kind"]=="expire"],["09:00","08:50"])
        self.assertEqual(item(state,"slots","S01")["available"],1)

    def test_slot_start_caps_hold_and_closes_queue_across_date(self):
        self.act("advance",minutes=1440)
        self.act("advance",minutes=15)
        state = self.act("cancel",record_id="R001")
        self.assertEqual(item(state,"records","R003")["deadline"],"2026-12-08T09:00:00+08:00")
        state = self.act("advance",minutes=180)
        self.assertEqual(item(state,"slots","S01")["status"],"closed")
        self.assertTrue(all(item(state,"records",r)["status"]=="expired" for r in ("R003","R004")))
        self.assertTrue(all(e["time"][11:16]=="09:00" for e in state["events"] if e["kind"]=="expire"))
        with self.assertRaises(engine.Problem):
            self.act("join",slot_id="S01",person="P999")

    def test_cancel_held_reoffers_immediately_and_allows_reentry(self):
        self.act("cancel",record_id="R001")
        self.act("cancel",record_id="R003")
        state = self.act("join",slot_id="S01",person="P003")
        self.assertEqual(item(state,"records","R004")["status"],"held")
        self.assertEqual(item(state,"records","R005")["position"],1)
        with self.assertRaises(engine.Problem):
            self.act("join",slot_id="S01",person="P003")

    def test_suspension_cancels_unconfirmed_and_preserves_confirmed(self):
        self.act("join",slot_id="S01",person="P005")
        self.act("cancel",record_id="R001")
        state=self.act("suspend",slot_id="S01")
        self.assertEqual(item(state,"records","R002")["status"],"pending")
        self.assertEqual(item(state,"records","R003")["status"],"cancelled")
        self.assertEqual(item(state,"records","R004")["status"],"cancelled")
        self.assertEqual(item(state,"slots","S01")["available"],0)
        with self.assertRaises(engine.Problem):
            self.act("join",person="P888",slot_id="S01")

    def test_batch_reschedule_keeps_record_ids_and_events(self):
        self.act("suspend",slot_id="S01")
        state = self.act("reschedule",record_ids=["R001","R002"],slot_id="S02")
        self.assertEqual(item(state,"slots","S02")["booked"],2)
        self.assertTrue(all(item(state,"records",r)["slot_id"]=="S02" for r in ("R001","R002")))
        self.assertEqual(sum(e["kind"]=="reschedule" for e in state["events"]),2)
        with self.assertRaises(engine.Problem):
            self.act("reschedule",record_ids=["R001"],slot_id="S03")
        self.assertEqual(state,self.current())

    def test_batch_refuses_insufficient_capacity_and_wrong_department(self):
        before = self.act("suspend",slot_id="S01")
        for target, rows in [("S03",["R001","R002"]),("S04",["R001"]),("S02",["R001","R001"])]:
            with self.subTest(target=target), self.assertRaises(engine.Problem):
                self.act("reschedule",record_ids=rows,slot_id=target)
            self.assertEqual(before,self.current())
        state = self.act("reschedule",record_ids=["R001"],slot_id="S03")
        self.assertEqual(item(state,"records","R002")["status"],"pending")

    def test_batch_rolls_back_earlier_row_on_late_conflict(self):
        self.act("suspend",slot_id="S01")
        # A separate, simultaneous source in the same department already seats the second person.
        with closing(engine.connect(self.database)) as db, db:
            db.execute("INSERT INTO slots SELECT desk,'S05',department,'四诊室',start,1,0 FROM slots "
                       "WHERE desk=? AND id='S02'",(self.key,))
        before = self.act("join",slot_id="S05",person="P002")
        with self.assertRaisesRegex(engine.Problem,"已有预约"):
            self.act("reschedule",record_ids=["R001","R002"],slot_id="S02")
        self.assertEqual(before,self.current())

    def test_duplicate_request_precedes_stale_revision_check(self):
        args = dict(minutes=10,request_id="advance-request-1",expected_revision=0)
        state = self.act("advance",**args)
        self.assertEqual(state,self.act("advance",**args))
        with self.assertRaises(engine.Problem):
            self.act("advance",minutes=11,request_id=args["request_id"])
        with self.assertRaises(engine.Problem):
            self.act("advance",minutes=10,expected_revision=0)
        self.assertEqual(state,self.current())

    def test_concurrent_join_for_one_seat(self):
        count = 12
        barrier = Barrier(count)
        def submit(n):
            barrier.wait(timeout=15)
            return self.act("join",slot_id="S03",person=f"P{100+n}")
        with ThreadPoolExecutor(max_workers=count) as pool:
            list(pool.map(submit,range(count)))
        state = self.current()
        rows = [row for row in state["records"] if row["slot_id"]=="S03"]
        self.assertEqual([r["status"] for r in rows],["booked"]+["waiting"]*(count-1))
        self.assertEqual([r["position"] for r in rows[1:]],list(range(1,count)))
        self.assertEqual(item(state,"slots","S03")["available"],0)

    def test_restart_isolation_and_reset(self):
        other, untouched = engine.open_session(self.database)
        before = self.act("cancel",record_id="R001")
        engine.initialize(self.database)
        self.assertEqual(before,self.current())
        self.assertEqual(untouched,engine.get_state(self.database,other))
        state = self.act("reset")
        self.assertEqual(state["revision"],2)
        self.assertEqual(state["records"],self.initial["records"])
        self.assertEqual(state["events"],self.initial["events"])


class HttpTest(unittest.TestCase):
    def setUp(self):
        folder = TemporaryDirectory()
        self.addCleanup(folder.cleanup)
        app = make_server(0,Path(folder.name)/"test.sqlite3")
        self.addCleanup(app.server_close)
        worker = Thread(target=app.serve_forever,daemon=True)
        worker.start()
        self.addCleanup(worker.join)
        self.addCleanup(app.shutdown)
        self.base = "http://127.0.0.1:"+str(app.server_port)
        self.client = build_opener(HTTPCookieProcessor(CookieJar()))

    def request(self, path="/api/state", payload=None, client=None, **headers):
        data = None if payload is None else json.dumps(payload).encode()
        req = Request(self.base+path,data=data,headers={"Content-Type":"application/json",**headers})
        with (client or self.client).open(req,timeout=5) as response:
            return json.load(response),response.headers

    def test_two_clients_have_separate_desks(self):
        initial,headers=self.request()
        self.assertIn("HttpOnly",headers["Set-Cookie"])
        self.assertIn("SameSite=Strict",headers["Set-Cookie"])
        other=build_opener(HTTPCookieProcessor(CookieJar()))
        other_initial,_=self.request(client=other)
        self.assertEqual(initial,other_initial)
        state,_=self.request("/api/action",{"action":"cancel","record_id":"R001"})
        self.assertEqual(item(state,"records","R003")["status"],"held")
        self.assertEqual(self.request(client=other)[0],initial)

    def test_write_requires_workspace_json_and_same_origin(self):
        with self.assertRaises(HTTPError) as error:
            self.request("/api/action",{"action":"reset"})
        self.assertEqual(error.exception.code,401)
        self.request()
        for headers, code in [({"Origin":"https://example.invalid"},403),({"Content-Type":"text/plain"},415)]:
            with self.assertRaises(HTTPError) as error:
                self.request("/api/action",{"action":"reset"},**headers)
            self.assertEqual(error.exception.code,code)
        self.assertEqual(self.request()[0]["revision"],0)

    def test_invalid_body_and_identifiers_return_visible_errors(self):
        self.request()
        for body in [None,{},{"action":[]},{"action":"join","slot_id":[],"person":"P005"},
                     {"action":"advance","minutes":True},{"action":"confirm","record_id":[],"person":7},
                     {"action":"join","slot_id":"S01","person":"张三"}]:
            with self.subTest(body=body):
                req=Request(self.base+"/api/action",data=json.dumps(body).encode(),headers={"Content-Type":"application/json"})
                with self.assertRaises(HTTPError) as error:
                    self.client.open(req,timeout=5)
                self.assertEqual(error.exception.code,400)
                self.assertTrue(json.load(error.exception)["error"])


if __name__=="__main__":
    unittest.main()
