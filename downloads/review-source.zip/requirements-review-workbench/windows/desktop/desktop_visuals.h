#pragma once
#include <objidl.h>
#include <gdiplus.h>
#include <dwmapi.h>
#include <cmath>

#pragma comment(lib, "gdiplus.lib")
#pragma comment(lib, "dwmapi.lib")

namespace desktop_visuals {
constexpr COLORREF Paper = RGB(248, 246, 239), Ink = RGB(28, 53, 42),
    Muted = RGB(75, 86, 75);
constexpr int EmblemCenterLift = 17;

inline bool highContrast() {
    HIGHCONTRASTW mode{sizeof(mode)};
    return SystemParametersInfoW(SPI_GETHIGHCONTRAST, sizeof(mode), &mode, 0) && (mode.dwFlags & HCF_HIGHCONTRASTON);
}

inline void styleCaption(HWND hwnd, bool accessible) {
    COLORREF surface = accessible ? GetSysColor(COLOR_ACTIVECAPTION) : Paper;
    COLORREF text = accessible ? GetSysColor(COLOR_CAPTIONTEXT) : Ink;
    // Earlier Windows versions can keep their native caption and ignore these Windows 11 attributes.
    DwmSetWindowAttribute(hwnd, 35, &surface, sizeof(surface));
    DwmSetWindowAttribute(hwnd, 36, &text, sizeof(text));
}

inline void rounded(Gdiplus::GraphicsPath& path, float x, float y, float w, float h, float r) {
    float d = std::min(r*2, std::min(w,h));
    path.AddArc(x,y,d,d,180,90); path.AddArc(x+w-d,y,d,d,270,90);
    path.AddArc(x+w-d,y+h-d,d,d,0,90); path.AddArc(x,y+h-d,d,d,90,90); path.CloseFigure();
}
inline void surface(Gdiplus::Graphics& g, float x, float y, float w, float h, float radius,
                    Gdiplus::Color fill, Gdiplus::Color border) {
    Gdiplus::GraphicsPath shape; rounded(shape,x,y,w,h,radius);
    Gdiplus::SolidBrush background(fill); g.FillPath(&background,&shape);
    if (border.GetA()) { Gdiplus::Pen pen(border); g.DrawPath(&pen,&shape); }
}
inline void canvas(HDC dc, const RECT& bounds, UINT dpi, bool pending, bool motion, bool accessible) {
    using namespace Gdiplus;
    const auto paper = accessible ? GetSysColor(COLOR_WINDOW) : Paper;
    SetDCBrushColor(dc,paper); FillRect(dc,&bounds,static_cast<HBRUSH>(GetStockObject(DC_BRUSH)));
    if (!pending) return;
    const float scale = dpi / 96.f;
    const float centerX = (bounds.right - bounds.left)*.5f;
    const float centerY = (bounds.bottom - bounds.top)*.5f - EmblemCenterLift*scale;
    Graphics ring(dc); ring.SetSmoothingMode(SmoothingModeAntiAlias);
    ring.SetPageUnit(UnitPixel);
    ring.TranslateTransform(centerX-32*scale,centerY-32*scale);
    ring.ScaleTransform(scale,scale);
    RectF circle(7,7,50,50);
    auto color = [](COLORREF value) { return Color(255,GetRValue(value),GetGValue(value),GetBValue(value)); };
    Pen track(color(accessible ? GetSysColor(COLOR_GRAYTEXT) : RGB(220,222,211)),1.2f);
    ring.DrawEllipse(&track,circle);
    Pen lead(color(accessible ? GetSysColor(COLOR_WINDOWTEXT) : RGB(40,88,66)),2.8f);
    lead.SetStartCap(LineCapRound); lead.SetEndCap(LineCapRound);
    float angle = -70.f, sweep = 112.f;
    if (motion) {
        static const ULONGLONG began = GetTickCount64();
        const auto time = GetTickCount64()-began;
        const float phase = float(time%1650)/1650.f;
        const bool growing = phase < .5f;
        const float half = phase*2.f - (growing ? 0.f : 1.f);
        const float advance = 194.f * (.5f - .5f*std::cos(3.14159265f*half));
        // On expansion only the leading tip advances; on contraction the tail catches up.
        // Carry the tail's angular displacement into the next cycle so neither tip jumps backward.
        const float carried = float(((time/1650)%180)*194%360);
        angle = -90.f + float(time%2500)*(360.f/2500.f) + carried + (growing ? 0.f : advance);
        sweep = growing ? 36.f+advance : 230.f-advance;
    }
    ring.DrawArc(&lead,circle,angle,sweep);
    Pen corners(color(accessible ? GetSysColor(COLOR_WINDOWTEXT) : RGB(49,84,67)),1.45f);
    corners.SetStartCap(LineCapRound); corners.SetEndCap(LineCapRound); corners.SetLineJoin(LineJoinRound);
    for (int quadrant = 0; quadrant < 4; ++quadrant) {
        auto state = ring.Save();
        ring.TranslateTransform(32,32); ring.RotateTransform(float(quadrant*90)); ring.TranslateTransform(-32,-32);
        GraphicsPath corner;
        corner.AddLine(24.f,28.f,24.f,25.f); corner.AddArc(24.f,24.f,2.f,2.f,180,90);
        corner.AddLine(25.f,24.f,28.f,24.f); ring.DrawPath(&corners,&corner);
        ring.Restore(state);
    }
    Pen scan(color(accessible ? GetSysColor(COLOR_WINDOWTEXT) : RGB(165,137,88)),1.4f);
    scan.SetStartCap(LineCapRound); scan.SetEndCap(LineCapRound);
    ring.DrawLine(&scan,26.f,32.f,38.f,32.f);
}

// CapturePreview renders on demand even on a fresh GPU-backed WebView. Discard the in-memory preview after testing
// for visible content. It never leaves the process or touches the file system.
inline bool hasPaint(IStream* preview) {
    using namespace Gdiplus;
    LARGE_INTEGER start{};
    if (FAILED(preview->Seek(start,STREAM_SEEK_SET,nullptr))) return false;
    Bitmap frame(preview,FALSE);
    if (frame.GetLastStatus() != Ok || !frame.GetWidth() || !frame.GetHeight()) return false;
    Bitmap reduced(32,24,PixelFormat32bppARGB);
    {
        Graphics sample(&reduced);
        sample.SetInterpolationMode(InterpolationModeHighQualityBilinear);
        if (sample.DrawImage(&frame,Rect(0,0,32,24)) != Ok) return false;
    }
    int darkest = 255, lightest = 0;
    for (int row = 0; row < 24; ++row) {
        for (int col = 0; col < 32; ++col) {
            Color pixel;
            if (reduced.GetPixel(col,row,&pixel) != Ok || pixel.GetA() < 225) continue;
            int level = (pixel.GetR()*3 + pixel.GetG()*6 + pixel.GetB()) / 10;
            darkest = std::min(darkest,level); lightest = std::max(lightest,level);
            if (lightest-darkest > 14) return true;
        }
    }
    return false;
}
inline void button(const DRAWITEMSTRUCT& item, bool primary, HFONT font, UINT dpi, bool hc) {
    using namespace Gdiplus;
    int w = item.rcItem.right, h = item.rcItem.bottom;
    const COLORREF cardColor = hc ? GetSysColor(COLOR_WINDOW) : Paper;
    SetDCBrushColor(item.hDC,cardColor); FillRect(item.hDC,&item.rcItem,static_cast<HBRUSH>(GetStockObject(DC_BRUSH)));
    bool pressed = (item.itemState & ODS_SELECTED) != 0;
    POINT pos{}; GetCursorPos(&pos); ScreenToClient(item.hwndItem,&pos);
    bool hot = PtInRect(&item.rcItem,pos);
    if (!hc) {
        Graphics g(item.hDC); g.SetSmoothingMode(SmoothingModeAntiAlias);
        const float unit=dpi/96.f;
        Color fill = primary ? (pressed ? Color(255,21,50,38) : hot ? Color(255,48,85,63) : Color(255,35,65,49)) :
            hot ? Color(255,238,236,224) : Color(255,250,248,240);
        surface(g,2*unit,2*unit,w-4*unit,h-4*unit,7*unit,fill,primary ? fill : Color(255,202,200,183));
    } else {
        DrawFrameControl(item.hDC,const_cast<RECT*>(&item.rcItem),DFC_BUTTON,DFCS_BUTTONPUSH | (pressed ? DFCS_PUSHED : 0));
    }
    wchar_t label[128]{}; GetWindowTextW(item.hwndItem,label,ARRAYSIZE(label));
    auto old = SelectObject(item.hDC,font);
    SetTextColor(item.hDC,hc ? GetSysColor(COLOR_BTNTEXT) : primary ? RGB(255,253,243) : Ink);
    SetBkMode(item.hDC,TRANSPARENT); RECT textRect = item.rcItem;
    DrawTextW(item.hDC,label,-1,&textRect,DT_CENTER|DT_VCENTER|DT_SINGLELINE|DT_NOPREFIX);
    SelectObject(item.hDC,old);
    if ((item.itemState & ODS_FOCUS) && !(item.itemState & ODS_NOFOCUSRECT)) {
        RECT focus = item.rcItem; InflateRect(&focus,-1,-1); DrawFocusRect(item.hDC,&focus);
    }
}
}
