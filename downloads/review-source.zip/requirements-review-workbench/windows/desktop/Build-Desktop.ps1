param([string]$OutputDirectory = (Join-Path $PSScriptRoot 'build'))
$ErrorActionPreference = 'Stop'
$buildDirectory = [IO.Path]::GetFullPath($OutputDirectory)
$null = New-Item -ItemType Directory -Force -Path $buildDirectory

$packageVersion = '1.0.3650.58'
$trustedHash = '911a472128c82ac8baa0c486c23342cc9dd6e7dc50d754e676726642ca065c60'
$nupkg = Join-Path $buildDirectory 'webview2.nupkg'
if (!(Test-Path -LiteralPath $nupkg)) {
    $url = "https://api.nuget.org/v3-flatcontainer/microsoft.web.webview2/$packageVersion/microsoft.web.webview2.$packageVersion.nupkg"
    Invoke-WebRequest -Uri $url -OutFile $nupkg -UseBasicParsing
}
if ((Get-FileHash -LiteralPath $nupkg -Algorithm SHA256).Hash -ne $trustedHash) { throw 'WebView2 SDK checksum mismatch.' }
$sdk = Join-Path $buildDirectory 'sdk'
Add-Type -AssemblyName System.IO.Compression.FileSystem
$archive = [IO.Compression.ZipFile]::OpenRead($nupkg)
try {
    foreach ($entry in @('build/native/include/WebView2.h','build/native/x64/WebView2LoaderStatic.lib','LICENSE.txt','NOTICE.txt')) {
        $dest = Join-Path $sdk $entry
        $null = New-Item -ItemType Directory -Force -Path ([IO.Path]::GetDirectoryName($dest))
        [IO.Compression.ZipFileExtensions]::ExtractToFile($archive.GetEntry($entry), $dest, $true)
    }
} finally { $archive.Dispose() }

$vswhere = Join-Path ${env:ProgramFiles(x86)} 'Microsoft Visual Studio/Installer/vswhere.exe'
$install = & $vswhere -latest -products '*' -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 -property installationPath
if (!$install) { throw 'Install Visual Studio Build Tools 2022 with Desktop development with C++ and a Windows SDK.' }
$devCmd = Join-Path $install 'VC/Auxiliary/Build/vcvars64.bat'
$environment = & $env:ComSpec /d /c ('call "' + $devCmd + '" >nul && set')
if ($LASTEXITCODE) { throw 'Cannot load the x64 MSVC environment.' }
foreach ($line in $environment) {
    $pair = $line -split '=',2
    if ($pair.Length -eq 2 -and $pair[0]) { [Environment]::SetEnvironmentVariable($pair[0],$pair[1],'Process') }
}
$resource = Join-Path $buildDirectory 'workbench.res'
& rc.exe /nologo /c65001 /i $PSScriptRoot /i $sdk /fo $resource (Join-Path $PSScriptRoot 'workbench.rc')
if ($LASTEXITCODE) { throw 'Compiling the application resources failed.' }
$target = Join-Path $buildDirectory 'ReqReviewClient.exe'
$obj = Join-Path $buildDirectory 'client.obj'
& cl.exe /nologo /O2 /MT /EHsc /utf-8 /std:c++17 /DUNICODE /D_UNICODE /D_WIN32_WINNT=0x0A00 /W4 /guard:cf /I (Join-Path $sdk 'build/native/include') /Fo"$obj" (Join-Path $PSScriptRoot 'client.cpp') /link /SUBSYSTEM:WINDOWS /DYNAMICBASE /NXCOMPAT /GUARD:CF /MANIFEST:NO /OUT:"$target" $resource (Join-Path $sdk 'build/native/x64/WebView2LoaderStatic.lib') user32.lib gdi32.lib comctl32.lib shell32.lib ole32.lib oleaut32.lib shlwapi.lib advapi32.lib version.lib winhttp.lib
if ($LASTEXITCODE) { throw 'Building the desktop client failed.' }
Get-Item -LiteralPath $target
