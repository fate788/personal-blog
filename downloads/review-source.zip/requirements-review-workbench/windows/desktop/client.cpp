#define NOMINMAX
#define WIN32_LEAN_AND_MEAN
#include <winsock2.h>
#include <windows.h>
#include <commctrl.h>
#include <shellapi.h>
#include <shlobj.h>
#include <winhttp.h>
#include <wrl.h>
#include <WebView2.h>
#include <algorithm>
#include <cwctype>
#include <filesystem>
#include <fstream>
#include <string>
#include <thread>
#include "client_link.h"
#include "desktop_visuals.h"

using Microsoft::WRL::Callback;
using Microsoft::WRL::ComPtr;
namespace fs = std::filesystem;
using std::wstring;

static const wchar_t* Product = L"需求审查工作台";
static const wchar_t* RuntimePage = L"https://developer.microsoft.com/microsoft-edge/webview2/#download";
enum { Home = 101, Reload, Downloads, Notices, Quit, Connect, InstallRuntime = 108, Cover = 112 };
constexpr UINT VerifiedHostMessage = WM_APP + 1;
constexpr UINT MenuMessage = WM_APP + 2;
constexpr UINT_PTR ProgressTimer = 1, PaintReadyTimer = 2;
constexpr UINT DesktopSystemMenu = 0x1d00;
static const wchar_t* OfflineHint = L"暂时连不上工作台。请确认主机和共享服务已开启，再点击重新连接。如果管理员更新了分享，请获取新版客户端。";
static const wchar_t* IdentityHint = L"当前服务的身份与分享这份客户端的主机不符。请联系管理员确认服务，或重新获取客户端。";

static wstring trim(wstring value) {
    auto a = value.find_first_not_of(L" \r\n\t"), b = value.find_last_not_of(L" \r\n\t");
    return a == wstring::npos ? L"" : value.substr(a, b - a + 1);
}

// The application uses root-relative API paths. Persist the origin, never credentials, paths or query values.
static wstring origin(const wstring& url, bool formValue = false) {
    if (url.empty() || url.size() > 4096 || url.find_first_of(L"\\\r\n\t ") != wstring::npos) return {};
    URL_COMPONENTS parts = {};
    parts.dwStructSize = sizeof(parts);
    parts.dwSchemeLength = parts.dwHostNameLength = parts.dwUserNameLength = parts.dwPasswordLength =
        parts.dwUrlPathLength = parts.dwExtraInfoLength = static_cast<DWORD>(-1);
    if (!WinHttpCrackUrl(url.c_str(), static_cast<DWORD>(url.size()), 0, &parts) ||
        (parts.nScheme != INTERNET_SCHEME_HTTP && parts.nScheme != INTERNET_SCHEME_HTTPS) ||
        !parts.dwHostNameLength || parts.dwUserNameLength || parts.dwPasswordLength || !parts.nPort) return {};
    wstring path(parts.lpszUrlPath ? parts.lpszUrlPath : L"", parts.dwUrlPathLength);
    wstring extra(parts.lpszExtraInfo ? parts.lpszExtraInfo : L"", parts.dwExtraInfoLength);
    // Also accept a copied workbench bookmark, including its hash route.
    if (formValue && (path != L"" && path != L"/" || !extra.empty() && extra[0] != L'#')) return {};
    wstring host(parts.lpszHostName, parts.dwHostNameLength);
    std::transform(host.begin(), host.end(), host.begin(), towlower);
    if (host.find(L':') != wstring::npos && host.front() != L'[') host = L"[" + host + L"]";
    bool tls = parts.nScheme == INTERNET_SCHEME_HTTPS;
    return wstring(tls ? L"https://" : L"http://") + host +
        (parts.nPort == (tls ? 443 : 80) ? L"" : L":" + std::to_wstring(parts.nPort)) + L"/";
}

static bool loopback(const wstring& endpoint) {
    return endpoint.find(L"http://127.0.0.1:") == 0 || endpoint == L"http://127.0.0.1/" ||
        endpoint.find(L"http://localhost:") == 0 || endpoint == L"http://localhost/" ||
        endpoint.find(L"http://[::1]:") == 0 || endpoint == L"http://[::1]/";
}

// Evidence links open only after a user gesture, in the system browser with its own cookie store.
static bool publicReference(const wstring& url) {
    auto root = origin(url);
    if (root.rfind(L"https://", 0) != 0 || root.find(L'[', 8) != wstring::npos || url.size() > 4096 ||
        url.find(L'\\') != wstring::npos || url.find(L'\0') != wstring::npos) return false;
    auto last = root.find_first_of(L":/", 8);
    auto name = root.substr(8, last-8);
    auto dot = name.rfind(L'.');
    if (dot == wstring::npos || !client_link::validDomain(name)) return false;
    const auto suffix = name.substr(dot+1);
    if (suffix.size() < 2 || suffix.find_first_not_of(L"abcdefghijklmnopqrstuvwxyz") != wstring::npos) return false;
    for (const auto* reserved : {L"local", L"localhost", L"internal", L"arpa", L"test", L"invalid", L"example", L"onion"})
        if (suffix == reserved) return false;
    return true;
}

static wstring readAddress(const fs::path& dir) {
    std::error_code e;
    const auto file = dir / L"server.txt";
    auto size = fs::file_size(file, e);
    if (e || !size || size > 8192 || size % sizeof(wchar_t)) return {};
    std::ifstream in(file, std::ios::binary);
    wstring value(static_cast<size_t>(size / sizeof(wchar_t)), L'\0');
    if (!in.read(reinterpret_cast<char*>(value.data()), static_cast<std::streamsize>(size))) return {};
    return origin(value, true);
}

static bool saveAddress(const fs::path& dir, const wstring& value) {
    const auto tmp = dir / (L"server-" + std::to_wstring(GetCurrentProcessId()) + L".tmp");
    {
        std::ofstream out(tmp, std::ios::binary | std::ios::trunc);
        out.write(reinterpret_cast<const char*>(value.data()), value.size() * sizeof(wchar_t));
        out.close();
        if (!out) { DeleteFileW(tmp.c_str()); return false; }
    }
    if (MoveFileExW(tmp.c_str(), (dir / L"server.txt").c_str(), MOVEFILE_REPLACE_EXISTING | MOVEFILE_WRITE_THROUGH)) return true;
    DeleteFileW(tmp.c_str());
    return false;
}

static void viewNotices(HWND owner) {
    PWSTR folder = nullptr;
    if (FAILED(SHGetKnownFolderPath(FOLDERID_LocalAppData, KF_FLAG_CREATE, nullptr, &folder))) return;
    auto path = fs::path(folder) / L"RequirementReviewStudio" / L"DesktopNotices.txt";
    CoTaskMemFree(folder);
    std::error_code e;
    fs::create_directories(path.parent_path(), e);
    std::ofstream out(path, std::ios::binary | std::ios::trunc);
    if (out) {
        for (int id : {201, 202}) {
            HRSRC res = FindResourceW(nullptr, MAKEINTRESOURCEW(id), RT_RCDATA);
            if (res) out.write(static_cast<const char*>(LockResource(LoadResource(nullptr, res))), SizeofResource(nullptr, res));
            out << "\r\n";
        }
        out.close();
        if (out) ShellExecuteW(owner, L"open", path.c_str(), nullptr, nullptr, SW_SHOWNORMAL);
    }
}

class Workbench {
    HWND win{}, webHost{}, cover{}, title{}, message{}, connect{}, runtime{};
    HFONT normalFont{}, titleFont{}, statusFont{};
    HBRUSH bg = CreateSolidBrush(desktop_visuals::Paper);
    bool highContrast = false, animate = true, probing = false, pendingPaint = false;
    ULONGLONG readyDeadline{};
    bool local, damaged, panel = true, pending = false, initializing = false, needsRuntime = false;
    bool verifying = false, waitingForNavigation = false, identifiedNavigation = false;
    fs::path data;
    wstring requested, pinned, destination;
    ComPtr<ICoreWebView2Environment> environment;
    ComPtr<ICoreWebView2Controller> controller;
    ComPtr<ICoreWebView2> web;
    struct DelayedRequest { ComPtr<ICoreWebView2WebResourceRequestedEventArgs> args; ComPtr<ICoreWebView2Deferral> deferral; };
    std::vector<DelayedRequest> delayedRequests;
    bool bound() const { return !pinned.empty(); }
    int scale(int n) const { return MulDiv(n, GetDpiForWindow(win), 96); }

    static LRESULT CALLBACK procedure(HWND w, UINT msg, WPARAM wp, LPARAM lp) {
        auto* app = reinterpret_cast<Workbench*>(GetWindowLongPtrW(w, GWLP_USERDATA));
        if (msg == WM_NCDESTROY) {
            SetWindowLongPtrW(w, GWLP_USERDATA, 0);
            return DefWindowProcW(w, msg, wp, lp);
        }
        if (msg == WM_NCCREATE) {
            app = static_cast<Workbench*>(reinterpret_cast<CREATESTRUCT*>(lp)->lpCreateParams);
            app->win = w;
            SetWindowLongPtrW(w, GWLP_USERDATA, reinterpret_cast<LONG_PTR>(app));
        }
        return app ? app->onMessage(msg, wp, lp) : DefWindowProcW(w, msg, wp, lp);
    }

    HWND control(const wchar_t* type, const wchar_t* text, DWORD style, int id = 0) {
        return CreateWindowExW(0, type, text, WS_CHILD | WS_VISIBLE | style,
            0, 0, 0, 0, win, reinterpret_cast<HMENU>(static_cast<INT_PTR>(id)), GetModuleHandleW(nullptr), nullptr);
    }
    void fonts() {
        auto font = [this](int px, int weight) {
            return CreateFontW(-scale(px), 0, 0, 0, weight, FALSE, FALSE, FALSE, DEFAULT_CHARSET, OUT_DEFAULT_PRECIS,
                CLIP_DEFAULT_PRECIS, CLEARTYPE_QUALITY, DEFAULT_PITCH, L"Microsoft YaHei UI");
        };
        HFONT oldNormal = normalFont, oldTitle = titleFont, oldStatus = statusFont;
        normalFont = font(15, FW_NORMAL); titleFont = font(24, FW_SEMIBOLD); statusFont = font(14, FW_NORMAL);
        for (HWND w : {connect, runtime}) SendMessageW(w, WM_SETFONT, (WPARAM)normalFont, TRUE);
        SendMessageW(message, WM_SETFONT, (WPARAM)(pending ? statusFont : normalFont), TRUE);
        SendMessageW(title, WM_SETFONT, (WPARAM)titleFont, TRUE);
        if (oldNormal) DeleteObject(oldNormal);
        if (oldTitle) DeleteObject(oldTitle);
        if (oldStatus) DeleteObject(oldStatus);
    }
    void layout() {
        RECT r{}; GetClientRect(win,&r);
        if (!cover || !message) return;
        SetWindowPos(webHost,HWND_BOTTOM,0,0,r.right,r.bottom,SWP_NOACTIVATE);
        if (controller) controller->put_Bounds(r);
        SetWindowPos(cover,nullptr,0,0,r.right,r.bottom,SWP_NOZORDER|SWP_NOACTIVATE);
        int width = std::max(1,std::min(scale(396),int(r.right)-scale(56)));
        int x = (r.right-width)/2, mid = r.bottom/2;
        if (pending) {
            MoveWindow(message,x,mid+scale(32+12-desktop_visuals::EmblemCenterLift),width,scale(25),TRUE);
        } else {
            wchar_t text[512]{}; GetWindowTextW(message,text,ARRAYSIZE(text));
            HDC dc = GetDC(win); auto old = SelectObject(dc,normalFont); RECT measured{0,0,width,0};
            DrawTextW(dc,text,-1,&measured,DT_CALCRECT|DT_WORDBREAK|DT_EDITCONTROL|DT_CENTER|DT_NOPREFIX);
            SelectObject(dc,old); ReleaseDC(win,dc);
            int body = std::max(scale(24),int(measured.bottom+scale(4)));
            int y = std::max(scale(14),mid-(scale(122)+body)/2);
            MoveWindow(title,x,y,width,scale(39),TRUE);
            MoveWindow(message,x,y+scale(50),width,body,TRUE);
            int buttonY = y+scale(72)+body;
            int pair = needsRuntime ? scale(115+10+153) : scale(115);
            int first = (int(r.right)-pair)/2;
            MoveWindow(connect,first,buttonY,scale(115),scale(43),TRUE);
            MoveWindow(runtime,first+scale(125),buttonY,scale(153),scale(43),TRUE);
        }
        InvalidateRect(cover,nullptr,FALSE);
    }
    void showForm(bool show) {
        panel = show;
        SendMessageW(message,WM_SETFONT,(WPARAM)(pending ? statusFont : normalFont),FALSE);
        EnableWindow(webHost,!show);
        if (show) {
            SetWindowPos(cover,HWND_TOP,0,0,0,0,SWP_NOSIZE|SWP_NOMOVE|SWP_NOACTIVATE|SWP_SHOWWINDOW);
            for (HWND w : {message,title,connect,runtime})
                SetWindowPos(w,HWND_TOP,0,0,0,0,SWP_NOSIZE|SWP_NOMOVE|SWP_NOACTIVATE);
            if (!pending && controller) controller->put_IsVisible(FALSE);
        }
        ShowWindow(title,show && !pending ? SW_SHOW : SW_HIDE);
        ShowWindow(message,show ? SW_SHOW : SW_HIDE);
        ShowWindow(connect,show && !pending ? SW_SHOW : SW_HIDE);
        ShowWindow(runtime,show && needsRuntime ? SW_SHOW : SW_HIDE);
        EnableWindow(connect,!pending);
        SetWindowTextW(connect,requested.empty() ? L"关闭" : L"重新连接");
        if (show && pending && animate) SetTimer(win,ProgressTimer,16,nullptr);
        else KillTimer(win,ProgressTimer);
        if (show) {
            layout();
            if (!pending) SetFocus(connect);
        } else {
            ShowWindow(cover,SW_HIDE);
            if (controller) controller->MoveFocus(COREWEBVIEW2_MOVE_FOCUS_REASON_PROGRAMMATIC);
        }
    }
    void setStatus(const wchar_t* text) {
        SetWindowTextW(message,text);
        NotifyWinEvent(EVENT_OBJECT_NAMECHANGE,message,OBJID_CLIENT,CHILDID_SELF);
        NotifyWinEvent(EVENT_OBJECT_LIVEREGIONCHANGED,message,OBJID_CLIENT,CHILDID_SELF);
    }
    void failed(const wchar_t* detail, bool install = false) {
        pending = false; needsRuntime = install;
        pendingPaint = false; KillTimer(win,PaintReadyTimer);
        SetWindowTextW(title, install ? L"需要桌面组件" : detail == IdentityHint ? L"主机身份有变" : L"暂时无法连接");
        SetWindowTextW(message, detail); showForm(true);
        NotifyWinEvent(EVENT_SYSTEM_ALERT,win,OBJID_CLIENT,CHILDID_SELF);
    }
    void openTarget() {
        identifiedNavigation = bound();
        controller->put_IsVisible(TRUE);
        if (FAILED(web->Navigate(destination.c_str()))) { identifiedNavigation = false; failed(OfflineHint); }
    }
    void beginVerification() {
        if (verifying) return;
        verifying = true;
        try {
            std::thread([window = win, root = requested, key = pinned] {
                auto result = HostVerification::Unavailable;
                try { result = VerifyHostedServer(root, key); } catch (...) {}
                PostMessageW(window, VerifiedHostMessage, static_cast<WPARAM>(result), 0);
            }).detach();
        } catch (...) {
            PostMessageW(win, VerifiedHostMessage, static_cast<WPARAM>(HostVerification::Unavailable), 0);
        }
    }
    void deny(ICoreWebView2WebResourceRequestedEventArgs* args) {
        ComPtr<ICoreWebView2WebResourceResponse> blocked;
        if (environment && SUCCEEDED(environment->CreateWebResourceResponse(nullptr, 403, L"Forbidden",
                L"Cache-Control: no-store", &blocked))) args->put_Response(blocked.Get());
    }
    void verificationFinished(HostVerification result) {
        verifying = false;
        const bool ok = result == HostVerification::Verified;
        bool navigate = waitingForNavigation;
        waitingForNavigation = false;
        for (auto& request : delayedRequests) {
            if (!ok) deny(request.args.Get());
            request.deferral->Complete();
        }
        delayedRequests.clear();
        if (!ok) { failed(result == HostVerification::Mismatch ? IdentityHint : OfflineHint); return; }
        if (navigate) connectVerified();
    }
    bool protectRequests() {
        EventRegistrationToken token{};
        if (FAILED(web->AddWebResourceRequestedFilter(L"*", COREWEBVIEW2_WEB_RESOURCE_CONTEXT_ALL))) return false;
        return SUCCEEDED(web->add_WebResourceRequested(Callback<ICoreWebView2WebResourceRequestedEventHandler>([this](ICoreWebView2*, ICoreWebView2WebResourceRequestedEventArgs* args) -> HRESULT {
            ComPtr<ICoreWebView2WebResourceRequest> request;
            if (FAILED(args->get_Request(&request)) || !request) { deny(args); return S_OK; }
            LPWSTR raw{}; request->get_Uri(&raw); wstring url = raw ? raw : L""; CoTaskMemFree(raw);
            if (url.rfind(L"data:", 0) == 0 || (url.rfind(L"blob:", 0) == 0 && origin(url.substr(5)) == requested)) return S_OK;
            if (origin(url) != requested) { deny(args); return S_OK; }
            raw = nullptr; request->get_Method(&raw); wstring method = raw ? raw : L""; CoTaskMemFree(raw);
            // Recheck before sending credentials, changing data, or reading a signed-in user's API data.
            const bool api = url.rfind(requested + L"api/", 0) == 0;
            if (api || (method != L"GET" && method != L"HEAD" && method != L"OPTIONS")) {
                DelayedRequest deferred{args, {}};
                if (FAILED(args->GetDeferral(&deferred.deferral))) { deny(args); return S_OK; }
                delayedRequests.push_back(std::move(deferred));
                beginVerification();
            }
            return S_OK;
        }).Get(), &token));
    }
    void connected() {
        pending = false;
        pendingPaint = false; KillTimer(win,PaintReadyTimer);
        if (!bound() && !local && !saveAddress(data, requested))
            MessageBoxW(win, L"本次已连接，但无法保存本机连接记录。", Product, MB_ICONINFORMATION);
        showForm(false);
    }
    void waitForContent() {
        if (probing || !pending || !pendingPaint || !web) return;
        if (GetTickCount64() >= readyDeadline) { failed(L"工作台页面未能加载完成。请重新连接，或联系管理员检查共享服务。"); return; }
        probing = true;
        // A mounted Vue root can still be waiting for the session. Reveal only its usable login or workspace.
        HRESULT hr = web->ExecuteScript(L"document.querySelector('#account-entry-form,#workspace-navigation') ? 2 : document.getElementById('app') ? 1 : 0",
            Callback<ICoreWebView2ExecuteScriptCompletedHandler>([this](HRESULT evaluated, LPCWSTR result)->HRESULT {
                if (!win || !pending || !pendingPaint || waitingForNavigation) { probing = false; return S_OK; }
                if (FAILED(evaluated) || !result || !wcscmp(result,L"0")) { probing = false; failed(OfflineHint); }
                else if (!wcscmp(result,L"2")) {
                    ComPtr<IStream> preview;
                    if (FAILED(CreateStreamOnHGlobal(nullptr,TRUE,&preview))) { probing = false; return S_OK; }
                    HRESULT hr = web->CapturePreview(COREWEBVIEW2_CAPTURE_PREVIEW_IMAGE_FORMAT_JPEG,preview.Get(),
                        Callback<ICoreWebView2CapturePreviewCompletedHandler>([this,preview](HRESULT captured)->HRESULT {
                            probing = false;
                            if (win && pending && pendingPaint && !waitingForNavigation && SUCCEEDED(captured) &&
                                    desktop_visuals::hasPaint(preview.Get())) connected();
                            return S_OK;
                        }).Get());
                    if (FAILED(hr)) probing = false;
                } else probing = false;
                return S_OK;
            }).Get());
        if (FAILED(hr)) { probing = false; failed(OfflineHint); }
    }
    static int shortcut(UINT key) {
        const bool alt = GetKeyState(VK_MENU) < 0, ctrl = GetKeyState(VK_CONTROL) < 0, shift = GetKeyState(VK_SHIFT) < 0;
        if (key == VK_F10 && !alt && !ctrl && !shift) return MenuMessage;
        if (key == VK_F5 && !alt && !ctrl && !shift) return Reload;
        if (key == VK_HOME && alt && !ctrl && !shift) return Home;
        if (key == 'J' && ctrl && !alt && !shift) return Downloads;
        return 0;
    }
    void postShortcut(int action) {
        if (action == MenuMessage) PostMessageW(win,MenuMessage,0,0);
        else PostMessageW(win,WM_COMMAND,action,0);
    }
    void wire() {
        EventRegistrationToken token{};
        controller->add_AcceleratorKeyPressed(Callback<ICoreWebView2AcceleratorKeyPressedEventHandler>(
            [this](ICoreWebView2Controller*, ICoreWebView2AcceleratorKeyPressedEventArgs* a)->HRESULT {
                COREWEBVIEW2_KEY_EVENT_KIND kind{}; UINT key{};
                a->get_KeyEventKind(&kind); a->get_VirtualKey(&key);
                if (kind == COREWEBVIEW2_KEY_EVENT_KIND_KEY_DOWN || kind == COREWEBVIEW2_KEY_EVENT_KIND_SYSTEM_KEY_DOWN) {
                    int action = shortcut(key);
                    if (action) { a->put_Handled(TRUE); postShortcut(action); }
                }
                return S_OK;
            }).Get(),&token);
        ComPtr<ICoreWebView2Settings> settings;
        if (SUCCEEDED(web->get_Settings(&settings))) {
            settings->put_AreDevToolsEnabled(FALSE);
            settings->put_AreDefaultContextMenusEnabled(!bound());
            settings->put_IsWebMessageEnabled(FALSE);
        }
        web->add_NavigationStarting(Callback<ICoreWebView2NavigationStartingEventHandler>([this](ICoreWebView2*, ICoreWebView2NavigationStartingEventArgs* a) -> HRESULT {
            LPWSTR raw{}; a->get_Uri(&raw); wstring url = raw ? raw : L""; CoTaskMemFree(raw);
            const auto host = origin(url);
            bool ownBlob = url.rfind(L"blob:", 0) == 0 && origin(url.substr(5)) == requested;
            if (host != requested && !ownBlob) {
                a->put_Cancel(TRUE);
                BOOL user = FALSE, redirect = FALSE; a->get_IsUserInitiated(&user); a->get_IsRedirected(&redirect);
                if (user && !redirect && !host.empty() && (!bound() || publicReference(url)))
                    ShellExecuteW(win, L"open", url.c_str(), nullptr, nullptr, SW_SHOWNORMAL);
                if (redirect) failed(L"工作台返回了其他站点的跳转。请联系管理员检查共享服务，再重新连接。");
            } else if (bound() && !ownBlob) {
                if (identifiedNavigation && url == destination) identifiedNavigation = false;
                else {
                    a->put_Cancel(TRUE);
                    // Redirects are not required by the workbench, which uses client-side hash routes.
                    BOOL redirected = FALSE; a->get_IsRedirected(&redirected);
                    if (redirected) failed(L"工作台出现了意外跳转。请联系管理员检查共享服务，再重新连接。");
                    else if (!pending) connectTo(url);
                }
            }
            return S_OK;
        }).Get(), &token);
        web->add_NewWindowRequested(Callback<ICoreWebView2NewWindowRequestedEventHandler>([this](ICoreWebView2*, ICoreWebView2NewWindowRequestedEventArgs* a) -> HRESULT {
            a->put_Handled(TRUE);
            BOOL user = FALSE; a->get_IsUserInitiated(&user);
            LPWSTR raw{}; a->get_Uri(&raw); wstring url = raw ? raw : L""; CoTaskMemFree(raw);
            if (user && !origin(url).empty()) {
                if (origin(url) == requested) web->Navigate(url.c_str());
                else if (!bound() || publicReference(url)) ShellExecuteW(win, L"open", url.c_str(), nullptr, nullptr, SW_SHOWNORMAL);
            }
            return S_OK;
        }).Get(), &token);
        web->add_NavigationCompleted(Callback<ICoreWebView2NavigationCompletedEventHandler>([this](ICoreWebView2*, ICoreWebView2NavigationCompletedEventArgs* a) -> HRESULT {
            BOOL ok = FALSE; a->get_IsSuccess(&ok);
            int http = 0;
            ComPtr<ICoreWebView2NavigationCompletedEventArgs2> details;
            if (SUCCEEDED(a->QueryInterface(IID_PPV_ARGS(&details)))) details->get_HttpStatusCode(&http);
            COREWEBVIEW2_WEB_ERROR_STATUS error = COREWEBVIEW2_WEB_ERROR_STATUS_UNKNOWN;
            if (!ok) a->get_WebErrorStatus(&error);
            if (error == COREWEBVIEW2_WEB_ERROR_STATUS_OPERATION_CANCELED) return S_OK;
            if (!ok || http >= 400) {
                if (!panel || pending) failed(local ? L"本机服务尚未响应，请稍后重新连接，或关闭后重新启动独立版。"
                    : OfflineHint);
                return S_OK;
            }
            if (pending) {
                pendingPaint = true; readyDeadline = GetTickCount64() + 30000;
                SetTimer(win,PaintReadyTimer,110,nullptr); waitForContent();
            }
            return S_OK;
        }).Get(), &token);
        web->add_ProcessFailed(Callback<ICoreWebView2ProcessFailedEventHandler>([this](ICoreWebView2*, ICoreWebView2ProcessFailedEventArgs* a) -> HRESULT {
            COREWEBVIEW2_PROCESS_FAILED_KIND kind{}; a->get_ProcessFailedKind(&kind);
            if (kind == COREWEBVIEW2_PROCESS_FAILED_KIND_BROWSER_PROCESS_EXITED) {
                if (controller) controller->Close();
                web.Reset(); controller.Reset();
                failed(L"桌面组件已关闭，点击重新连接即可恢复。");
            } else if (kind == COREWEBVIEW2_PROCESS_FAILED_KIND_RENDER_PROCESS_EXITED) {
                failed(L"页面已停止响应，请重新连接工作台。");
            }
            return S_OK;
        }).Get(), &token);
    }
    void connectTo(const wstring& target = {}) {
        if (pending || initializing || requested.empty()) return;
        destination = target.empty() ? requested : target;
        pending = true; needsRuntime = false;
        pendingPaint = false;
        setStatus(bound() ? L"正在连接工作台…" : L"正在打开工作台…"); showForm(true);
        if (bound()) { waitingForNavigation = true; beginVerification(); }
        else connectVerified();
    }
    void connectVerified() {
        setStatus(L"正在打开工作台…");
        if (web) { openTarget(); return; }
        initializing = true;
        auto status = CreateCoreWebView2EnvironmentWithOptions(nullptr, (data / L"WebView").c_str(), nullptr,
            Callback<ICoreWebView2CreateCoreWebView2EnvironmentCompletedHandler>([this](HRESULT hr, ICoreWebView2Environment* env) -> HRESULT {
                if (!win) return S_OK;
                if (FAILED(hr) || !env) {
                    initializing = false;
                    failed(L"无法启动 Microsoft Edge WebView2。请确认运行时已安装，且当前用户的数据目录可写。", true); return S_OK;
                }
                environment = env;
                HRESULT next = env->CreateCoreWebView2Controller(webHost, Callback<ICoreWebView2CreateCoreWebView2ControllerCompletedHandler>(
                    [this](HRESULT result, ICoreWebView2Controller* ctl) -> HRESULT {
                        initializing = false;
                        if (!win) return S_OK;
                        if (FAILED(result) || !ctl || FAILED(ctl->get_CoreWebView2(&web))) { failed(L"无法创建工作台窗口，请重新连接。"); return S_OK; }
                        controller = ctl; controller->put_IsVisible(FALSE); layout(); wire();
                        ComPtr<ICoreWebView2Controller2> colors;
                        if (SUCCEEDED(controller.As(&colors))) {
                            COLORREF paper = highContrast ? GetSysColor(COLOR_WINDOW) : desktop_visuals::Paper;
                            colors->put_DefaultBackgroundColor({255,GetRValue(paper),GetGValue(paper),GetBValue(paper)});
                        }
                        if (bound() && !protectRequests()) {
                            controller->Close(); web.Reset(); controller.Reset();
                            failed(L"无法启用桌面连接保护。请修复 Microsoft Edge WebView2 运行时后重新连接。", true);
                            return S_OK;
                        }
                        if (pending) openTarget();
                        return S_OK;
                    }).Get());
                if (FAILED(next)) { initializing = false; failed(L"无法创建工作台窗口，请重新连接。"); }
                return S_OK;
            }).Get());
        if (FAILED(status)) { initializing = false; failed(L"无法启动 Microsoft Edge WebView2，安装或修复运行时后可以重新连接。", true); }
    }
    void command(int id) {
        switch (id) {
            case Connect:
                if (requested.empty()) DestroyWindow(win); else connectTo();
                break;
            case Home: connectTo(); break;
            case Reload:
                if (web && !panel) {
                    if (bound()) {
                        LPWSTR raw{}; web->get_Source(&raw); wstring url = raw ? raw : L""; CoTaskMemFree(raw);
                        connectTo(origin(url) == requested ? url : requested);
                    } else web->Reload();
                } else connectTo();
                break;
            case Downloads: {
                ComPtr<ICoreWebView2_9> view;
                if (!panel && web && SUCCEEDED(web.As(&view))) view->OpenDefaultDownloadDialog();
                break;
            }
            case InstallRuntime: ShellExecuteW(win, L"open", RuntimePage, nullptr, nullptr, SW_SHOWNORMAL); break;
            case Notices: viewNotices(win); break;
            case Quit: DestroyWindow(win); break;
        }
    }
    void fillActions(HMENU menu, bool system) {
        auto add = [&](UINT id, const wchar_t* label) {
            AppendMenuW(menu,MF_STRING | ((!web || panel) && id == Downloads ? MF_GRAYED : 0),
                system ? DesktopSystemMenu + ((id-Home)<<4) : id,label); };
        if (!requested.empty()) {
            add(Home,L"工作台首页(&H)\tAlt+Home"); add(Reload,L"重新加载(&R)\tF5");
            add(Downloads,L"下载记录(&D)\tCtrl+J"); AppendMenuW(menu,MF_SEPARATOR,0,nullptr);
        }
        add(Notices,L"第三方组件许可(&L)");
        if (!system) { AppendMenuW(menu,MF_SEPARATOR,0,nullptr); add(Quit,L"关闭工作台(&X)\tAlt+F4"); }
    }
    void showActions() {
        auto actions = CreatePopupMenu(); if (!actions) return;
        fillActions(actions,false);
        POINT p{scale(8),0}; ClientToScreen(win,&p);
        int selected = TrackPopupMenuEx(actions,TPM_RETURNCMD|TPM_NONOTIFY|TPM_LEFTALIGN|TPM_TOPALIGN,
            p.x,p.y,win,nullptr);
        DestroyMenu(actions);
        if (selected) command(selected);
    }
    void theme() {
        highContrast = desktop_visuals::highContrast(); BOOL useMotion = TRUE;
        SystemParametersInfoW(SPI_GETCLIENTAREAANIMATION,0,&useMotion,0); animate = useMotion != FALSE;
        desktop_visuals::styleCaption(win,highContrast);
    }
    static LRESULT CALLBACK buttonEvents(HWND control,UINT msg,WPARAM wp,LPARAM lp,UINT_PTR,DWORD_PTR) {
        if (msg == WM_MOUSEMOVE) {
            TRACKMOUSEEVENT track{sizeof(track),TME_LEAVE,control,HOVER_DEFAULT}; TrackMouseEvent(&track);
        }
        if (msg == WM_MOUSEMOVE || msg == WM_MOUSELEAVE) InvalidateRect(control,nullptr,FALSE);
        return DefSubclassProc(control,msg,wp,lp);
    }
    LRESULT onMessage(UINT msg, WPARAM wp, LPARAM lp) {
        switch (msg) {
        case WM_CREATE: {
            theme();
            auto system = GetSystemMenu(win,FALSE);
            if (system) { AppendMenuW(system,MF_SEPARATOR,0,nullptr); fillActions(system,true); }
            webHost = control(L"STATIC",L"",WS_CLIPSIBLINGS|WS_CLIPCHILDREN);
            cover = control(L"STATIC",L"",SS_OWNERDRAW|WS_CLIPSIBLINGS,Cover);
            title = control(L"STATIC",damaged ? L"需要新的分享文件" : L"获取团队工作台",SS_CENTER|SS_NOPREFIX|WS_CLIPSIBLINGS);
            message = control(L"STATIC", damaged ? L"分享文件的连接信息无效，请向管理员重新获取客户端。" : requested.empty() ?
                L"请向管理员获取为团队生成的桌面客户端。收到分享文件后，双击即可打开工作台。" : L"正在打开工作台…", SS_CENTER|SS_NOPREFIX|SS_EDITCONTROL|WS_CLIPSIBLINGS);
            connect = control(L"BUTTON",L"重新连接",WS_TABSTOP|BS_OWNERDRAW,Connect);
            runtime = control(L"BUTTON",L"获取桌面运行时",WS_TABSTOP|BS_OWNERDRAW,InstallRuntime);
            for (HWND button : {connect,runtime}) SetWindowSubclass(button,buttonEvents,1,0);
            fonts(); layout();
            if (requested.empty()) showForm(true); else connectTo();
            return 0;
        }
        case MenuMessage: showActions(); return 0;
        case WM_INITMENUPOPUP:
            if ((HMENU)wp == GetSystemMenu(win,FALSE)) {
                EnableMenuItem((HMENU)wp, DesktopSystemMenu+((Downloads-Home)<<4), MF_BYCOMMAND | (web && !panel ? MF_ENABLED : MF_GRAYED));
            }
            break;
        case WM_SYSCOMMAND: {
            UINT sys = static_cast<UINT>(wp) & 0xfff0;
            if (sys >= DesktopSystemMenu && sys <= DesktopSystemMenu+((Notices-Home)<<4)) {
                command(Home + ((sys-DesktopSystemMenu)>>4)); return 0;
            }
            break;
        }
        case VerifiedHostMessage:
            verificationFinished(static_cast<HostVerification>(wp)); return 0;
        case WM_COMMAND: if (HIWORD(wp) <= 1) command(LOWORD(wp)); return 0;
        case WM_GETMINMAXINFO: {
            auto limits = reinterpret_cast<MINMAXINFO*>(lp); limits->ptMinTrackSize = {scale(410), scale(430)}; return 0;
        }
        case WM_CTLCOLORSTATIC: {
            HDC dc = reinterpret_cast<HDC>(wp); auto control = (HWND)lp;
            SetBkMode(dc,TRANSPARENT);
            SetTextColor(dc,highContrast ? GetSysColor(COLOR_WINDOWTEXT) : control == title ? desktop_visuals::Ink : desktop_visuals::Muted);
            return (LRESULT)(highContrast ? GetSysColorBrush(COLOR_WINDOW) : bg);
        }
        case WM_DRAWITEM:
            if (wp == Cover) {
                auto item = reinterpret_cast<DRAWITEMSTRUCT*>(lp);
                RECT clip{}; if (GetClipBox(item->hDC,&clip) == NULLREGION) return TRUE;
                int w=clip.right-clip.left, h=clip.bottom-clip.top;
                if (w <= 0 || h <= 0) return TRUE;
                auto mem=CreateCompatibleDC(item->hDC); auto bmp=CreateCompatibleBitmap(item->hDC,w,h);
                auto prev=SelectObject(mem,bmp);
                SetViewportOrgEx(mem,-clip.left,-clip.top,nullptr);
                desktop_visuals::canvas(mem,item->rcItem,GetDpiForWindow(win),pending,animate,highContrast);
                BitBlt(item->hDC,clip.left,clip.top,w,h,mem,clip.left,clip.top,SRCCOPY);
                SelectObject(mem,prev); DeleteObject(bmp); DeleteDC(mem);
                return TRUE;
            }
            if (wp == Connect || wp == InstallRuntime) {
                desktop_visuals::button(*reinterpret_cast<DRAWITEMSTRUCT*>(lp),wp == Connect,normalFont,GetDpiForWindow(win),highContrast);
                return TRUE;
            }
            break;
        case WM_ERASEBKGND: return 1;
        case WM_TIMER:
            if (wp == PaintReadyTimer) waitForContent();
            else if (wp == ProgressTimer && panel && pending) {
                RECT r{}; GetClientRect(cover,&r); int x = r.right/2, y = r.bottom/2;
                y -= scale(desktop_visuals::EmblemCenterLift);
                RECT ring{x-scale(29),y-scale(29),x+scale(29),y+scale(29)};
                InvalidateRect(cover,&ring,FALSE);
            }
            return 0;
        case WM_SETTINGCHANGE: theme(); if (panel) showForm(true); break;
        case WM_DPICHANGED: {
            RECT r = *reinterpret_cast<RECT*>(lp);
            SetWindowPos(win,nullptr,r.left,r.top,r.right-r.left,r.bottom-r.top,SWP_NOZORDER|SWP_NOACTIVATE);
            fonts(); layout(); return 0;
        }
        case WM_SIZE: layout(); return 0;
        case WM_MOVE: if (controller) controller->NotifyParentWindowPositionChanged(); break;
        case WM_SETFOCUS: if (!panel && controller) controller->MoveFocus(COREWEBVIEW2_MOVE_FOCUS_REASON_PROGRAMMATIC); break;
        case WM_DESTROY:
            win = nullptr;
            for (auto& request : delayedRequests) { deny(request.args.Get()); request.deferral->Complete(); }
            delayedRequests.clear();
            if (controller) controller->Close();
            web.Reset(); controller.Reset(); PostQuitMessage(0); return 0;
        }
        return DefWindowProcW(win, msg, wp, lp);
    }
public:
    Workbench(bool standalone, fs::path folder, wstring endpoint, const client_link::Link& link) :
        local(standalone), damaged(link.kind == client_link::Kind::Damaged), data(std::move(folder)),
        requested(std::move(endpoint)), pinned(link.publicKey) {}
    ~Workbench() { DeleteObject(normalFont); DeleteObject(titleFont); DeleteObject(statusFont); DeleteObject(bg); }
    int run(HINSTANCE instance, int show) {
        WNDCLASSW cls{}; cls.lpfnWndProc = procedure; cls.hInstance = instance; cls.lpszClassName = L"ReqReviewStudioClient";
        cls.hCursor = LoadCursorW(nullptr, IDC_ARROW); cls.hIcon = LoadIconW(instance, MAKEINTRESOURCEW(101));
        if (!RegisterClassW(&cls)) return 1;
        DWORD dpi = GetDpiForSystem();
        RECT area{}; SystemParametersInfoW(SPI_GETWORKAREA, 0, &area, 0);
        int wide = std::min(MulDiv(1240, dpi, 96), int(area.right-area.left));
        int high = std::min(MulDiv(850, dpi, 96), int(area.bottom-area.top));
        if (!CreateWindowExW(0, cls.lpszClassName, Product, WS_OVERLAPPEDWINDOW | WS_CLIPCHILDREN,
                area.left+(area.right-area.left-wide)/2, area.top+(area.bottom-area.top-high)/2,
                wide, high, nullptr,nullptr,instance,this)) return 1;
        ShowWindow(win,show); UpdateWindow(win);
        MSG msg{};
        while (GetMessageW(&msg,nullptr,0,0) > 0) {
            if (panel && msg.message == WM_KEYDOWN && msg.wParam == VK_RETURN &&
                GetFocus() == connect) { command(Connect); continue; }
            if (msg.message == WM_KEYDOWN || msg.message == WM_SYSKEYDOWN) {
                int action = shortcut(static_cast<UINT>(msg.wParam));
                if (action) { postShortcut(action); continue; }
                if (panel && msg.wParam == VK_RETURN && GetFocus() == runtime) { command(InstallRuntime); continue; }
            }
            if (panel && IsDialogMessageW(win,&msg)) continue;
            TranslateMessage(&msg); DispatchMessageW(&msg);
        }
        return static_cast<int>(msg.wParam);
    }
};

int WINAPI wWinMain(HINSTANCE instance, HINSTANCE, PWSTR, int show) {
    const auto link = client_link::fromExecutable();
    const bool plain = link.kind == client_link::Kind::Template;
    int argc{}; auto args = CommandLineToArgvW(GetCommandLineW(), &argc);
    bool local = false, invalid = !args; wstring endpoint = link.endpoint; fs::path data;
    for (int i = 1; !invalid && i < argc; ++i) {
        wstring flag(args[i]);
        if (++i >= argc) { invalid = true; break; }
        if (flag == L"--local-session" || flag == L"--server") {
            if (!plain) continue;
            local = flag == L"--local-session"; endpoint = origin(trim(args[i]), true);
            invalid = endpoint.empty() || (local && !loopback(endpoint));
        } else if (flag == L"--profile-dir") {
            data = args[i]; invalid = !data.is_absolute();
        } else invalid = true;
    }
    if (args) LocalFree(args);
    if (invalid) { MessageBoxW(nullptr,L"启动参数无效。请直接双击管理员提供的客户端。",Product,MB_ICONWARNING); return 2; }
    if (data.empty()) {
        PWSTR folder{};
        if (FAILED(SHGetKnownFolderPath(FOLDERID_LocalAppData, KF_FLAG_CREATE, nullptr, &folder))) return 1;
        data = fs::path(folder) / L"RequirementReviewStudio" / (local ? L"LocalDesktop" : L"SharedDesktop");
        CoTaskMemFree(folder);
        if (link.kind == client_link::Kind::Bound) {
            // Windows paths are case-insensitive. Use a hex-encoded fingerprint to isolate each host's browser profile.
            std::array<BYTE,65> point{}; std::array<BYTE,32> hash{}; DWORD size = DWORD(hash.size());
            if (!desktop_identity::decode(link.publicKey, point) || !CryptHashCertificate2(BCRYPT_SHA256_ALGORITHM, 0,
                    nullptr, point.data(), DWORD(point.size()), hash.data(), &size) || size != hash.size()) return 1;
            const wchar_t digits[] = L"0123456789abcdef";
            wstring directory;
            for (auto byte : hash) { directory += digits[byte >> 4]; directory += digits[byte & 15]; }
            data /= fs::path(L"Hosts") / directory;
        }
    }
    std::error_code ec; fs::create_directories(data,ec);
    if (ec) { MessageBoxW(nullptr,L"无法创建本机用户目录，无法保存桌面会话。",Product,MB_ICONERROR); return 1; }
    if (plain && !local && endpoint.empty()) endpoint = readAddress(data);
    if (FAILED(CoInitializeEx(nullptr,COINIT_APARTMENTTHREADED))) return 1;
    INITCOMMONCONTROLSEX controls{sizeof(controls), ICC_STANDARD_CLASSES};
    InitCommonControlsEx(&controls);
    Gdiplus::GdiplusStartupInput gdiplusInput; ULONG_PTR graphics{};
    if (Gdiplus::GdiplusStartup(&graphics,&gdiplusInput,nullptr) != Gdiplus::Ok) { CoUninitialize(); return 1; }
    int result;
    { Workbench app(local, data, endpoint, link); result = app.run(instance,show); }
    Gdiplus::GdiplusShutdown(graphics);
    CoUninitialize();
    return result;
}
