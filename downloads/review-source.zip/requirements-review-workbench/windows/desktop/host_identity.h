#pragma once
#include <windows.h>
#include <bcrypt.h>
#include <wincrypt.h>
#include <winhttp.h>
#include <algorithm>
#include <array>
#include <string>

#pragma comment(lib, "bcrypt.lib")
#pragma comment(lib, "crypt32.lib")
#pragma comment(lib, "winhttp.lib")

enum class HostVerification { Verified, Unavailable, Mismatch };

namespace desktop_identity {
struct HttpHandle {
    HINTERNET handle;
    ~HttpHandle() { if (handle) WinHttpCloseHandle(handle); }
};
struct Algorithm {
    BCRYPT_ALG_HANDLE handle{};
    ~Algorithm() { if (handle) BCryptCloseAlgorithmProvider(handle, 0); }
};
struct Key {
    BCRYPT_KEY_HANDLE handle{};
    ~Key() { if (handle) BCryptDestroyKey(handle); }
};

template <size_t N>
bool decode(const std::wstring& base64, std::array<BYTE, N>& bytes) {
    if (base64.size() != 4 * ((N + 2) / 3)) return false;
    DWORD length = static_cast<DWORD>(bytes.size());
    return CryptStringToBinaryW(base64.c_str(), static_cast<DWORD>(base64.size()), CRYPT_STRING_BASE64 | CRYPT_STRING_STRICT,
            bytes.data(), &length, nullptr, nullptr) && length == N;
}

inline bool validSignature(const std::wstring& pinned, const std::wstring& encodedSignature, const std::string& nonce) {
    std::array<BYTE, 65> point{};
    std::array<BYTE, 64> signature{};
    if (!decode(pinned, point) || point.front() != 4 || !decode(encodedSignature, signature)) return false;
    Algorithm ecdsa, sha;
    if (!BCRYPT_SUCCESS(BCryptOpenAlgorithmProvider(&ecdsa.handle, BCRYPT_ECDSA_P256_ALGORITHM, nullptr, 0)) ||
        !BCRYPT_SUCCESS(BCryptOpenAlgorithmProvider(&sha.handle, BCRYPT_SHA256_ALGORITHM, nullptr, 0))) return false;
    struct { BCRYPT_ECCKEY_BLOB prefix; BYTE xy[64]; } blob = {{BCRYPT_ECDSA_PUBLIC_P256_MAGIC, 32}, {}};
    std::copy(point.begin() + 1, point.end(), blob.xy);
    Key key;
    if (!BCRYPT_SUCCESS(BCryptImportKeyPair(ecdsa.handle, nullptr, BCRYPT_ECCPUBLIC_BLOB, &key.handle,
            reinterpret_cast<PUCHAR>(&blob), sizeof(blob), 0))) return false;
    std::string message = "REQAUDIT-DESKTOP-V2\n" + nonce;
    std::array<BYTE, 32> digest{};
    if (!BCRYPT_SUCCESS(BCryptHash(sha.handle, nullptr, 0, reinterpret_cast<PUCHAR>(message.data()),
            static_cast<ULONG>(message.size()), digest.data(), static_cast<ULONG>(digest.size())))) return false;
    return BCRYPT_SUCCESS(BCryptVerifySignature(key.handle, nullptr, digest.data(), static_cast<ULONG>(digest.size()),
            signature.data(), static_cast<ULONG>(signature.size()), 0));
}
}

inline HostVerification VerifyHostedServer(const std::wstring& canonicalRootUrl, const std::wstring& pinnedPublicKeyBase64) {
    using namespace desktop_identity;
    URL_COMPONENTS parts{};
    parts.dwStructSize = sizeof(parts);
    parts.dwHostNameLength = static_cast<DWORD>(-1);
    if (!WinHttpCrackUrl(canonicalRootUrl.c_str(), 0, 0, &parts) || !parts.dwHostNameLength ||
        (parts.nScheme != INTERNET_SCHEME_HTTP && parts.nScheme != INTERNET_SCHEME_HTTPS)) return HostVerification::Mismatch;
    const bool tls = parts.nScheme == INTERNET_SCHEME_HTTPS;
    std::wstring host(parts.lpszHostName, parts.dwHostNameLength);
    if (host.size() > 2 && host.front() == L'[' && host.back() == L']') host = host.substr(1, host.size() - 2);
    std::array<BYTE, 32> random{};
    if (!BCRYPT_SUCCESS(BCryptGenRandom(nullptr, random.data(), static_cast<ULONG>(random.size()), BCRYPT_USE_SYSTEM_PREFERRED_RNG)))
        return HostVerification::Unavailable;
    constexpr char hex[] = "0123456789abcdef";
    std::string nonce;
    for (BYTE b : random) { nonce.push_back(hex[b >> 4]); nonce.push_back(hex[b & 15]); }
    const auto path = L"/api/desktop/identity?challenge=" + std::wstring(nonce.begin(), nonce.end());
    HttpHandle session{WinHttpOpen(L"ReqAuditDesktop/3.9.17", tls ? WINHTTP_ACCESS_TYPE_AUTOMATIC_PROXY : WINHTTP_ACCESS_TYPE_NO_PROXY,
            WINHTTP_NO_PROXY_NAME, WINHTTP_NO_PROXY_BYPASS, 0)};
    if (!session.handle || !WinHttpSetTimeouts(session.handle, 4000, 4000, 5000, 5000)) return HostVerification::Unavailable;
    HttpHandle connection{WinHttpConnect(session.handle, host.c_str(), parts.nPort, 0)};
    if (!connection.handle) return HostVerification::Unavailable;
    HttpHandle request{WinHttpOpenRequest(connection.handle, L"GET", path.c_str(), nullptr, WINHTTP_NO_REFERER,
            WINHTTP_DEFAULT_ACCEPT_TYPES, WINHTTP_FLAG_REFRESH | (tls ? WINHTTP_FLAG_SECURE : 0))};
    DWORD disable = WINHTTP_DISABLE_COOKIES | WINHTTP_DISABLE_REDIRECTS | WINHTTP_DISABLE_AUTHENTICATION;
    if (!request.handle || !WinHttpSetOption(request.handle, WINHTTP_OPTION_DISABLE_FEATURE, &disable, sizeof(disable)) ||
        !WinHttpSendRequest(request.handle, WINHTTP_NO_ADDITIONAL_HEADERS, 0, WINHTTP_NO_REQUEST_DATA, 0, 0, 0) ||
        !WinHttpReceiveResponse(request.handle, nullptr)) return HostVerification::Unavailable;
    DWORD status = 0, size = sizeof(status);
    if (!WinHttpQueryHeaders(request.handle, WINHTTP_QUERY_STATUS_CODE | WINHTTP_QUERY_FLAG_NUMBER,
            WINHTTP_HEADER_NAME_BY_INDEX, &status, &size, WINHTTP_NO_HEADER_INDEX)) return HostVerification::Unavailable;
    if (status != 200) return status >= 500 ? HostVerification::Unavailable : HostVerification::Mismatch;
    wchar_t proof[92]{};
    size = sizeof(proof);
    if (!WinHttpQueryHeaders(request.handle, WINHTTP_QUERY_CUSTOM, L"X-Review-Desktop-Proof", proof, &size, WINHTTP_NO_HEADER_INDEX) ||
        !validSignature(pinnedPublicKeyBase64, proof, nonce)) return HostVerification::Mismatch;
    return HostVerification::Verified;
}
