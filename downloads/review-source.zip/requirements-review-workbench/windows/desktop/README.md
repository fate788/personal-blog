# Windows 桌面客户端

本目录提供使用 Microsoft Edge WebView2 的 Windows x64 客户端源码。安装 Visual Studio C++ 桌面开发工具、Windows SDK 和 WebView2 Runtime 后，在 PowerShell 中运行 `.\Build-Desktop.ps1`。构建脚本会下载指定版本的 WebView2 SDK 并核对散列，生成 `build/ReqReviewClient.exe`。

先启动本机工作台，再在同一设备上运行 `.\build\ReqReviewClient.exe --local-session http://127.0.0.1:8080/`。桌面窗口支持登录、文档编辑和导出。F10 打开桌面操作，Alt+Home 返回首页，Ctrl+J 查看下载。
