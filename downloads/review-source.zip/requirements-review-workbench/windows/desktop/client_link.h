#pragma once
#include <ws2tcpip.h>
#include "host_identity.h"
#include <filesystem>
#include <fstream>
#include <cstring>
#include <string>
#include <vector>

#pragma comment(lib, "ws2_32.lib")

namespace client_link {
enum class Kind { Template, Bound, Damaged };
struct Link {
    Kind kind = Kind::Damaged;
    std::wstring endpoint, publicKey;
};

inline bool asciiAlnum(wchar_t ch) {
    return (ch >= L'0' && ch <= L'9') || (ch >= L'a' && ch <= L'z') || (ch >= L'A' && ch <= L'Z');
}

inline bool validDomain(const std::wstring& value) {
    if (value.empty() || value.size() > 253) return false;
    for (size_t start = 0; start < value.size();) {
        auto dot = value.find(L'.', start);
        size_t end = dot == std::wstring::npos ? value.size() : dot;
        if (end == start || end-start > 63 || !asciiAlnum(value[start]) || !asciiAlnum(value[end-1])) return false;
        for (size_t i = start; i < end; ++i) if (!asciiAlnum(value[i]) && value[i] != L'-') return false;
        if (dot == std::wstring::npos) return true;
        start = dot + 1;
    }
    return false;
}

// The stamp contains ASCII only. This also rejects malformed UTF-8 and URL characters with browser-specific interpretations.
inline std::wstring validatedOrigin(std::wstring url) {
    if (url.size() > 2048 || url.find_first_of(L"\\@%?#") != std::wstring::npos) return {};
    for (auto ch : url) if (ch < 0x21 || ch > 0x7e) return {};
    std::transform(url.begin(), url.end(), url.begin(), [](wchar_t ch){ return ch >= L'A' && ch <= L'Z' ? wchar_t(ch + 32) : ch; });
    const bool tls = url.rfind(L"https://", 0) == 0;
    if (!tls && url.rfind(L"http://", 0) != 0) return {};
    auto authority = url.substr(tls ? 8 : 7);
    if (!authority.empty() && authority.back() == L'/') authority.pop_back();
    if (authority.empty() || authority.find(L'/') != std::wstring::npos) return {};

    std::wstring host;
    size_t portStart;
    bool isPrivate = false;
    if (authority.front() == L'[') {
        auto bracket = authority.find(L']');
        if (bracket == std::wstring::npos) return {};
        IN6_ADDR ip{}; wchar_t rendered[INET6_ADDRSTRLEN]{};
        if (InetPtonW(AF_INET6, authority.substr(1, bracket-1).c_str(), &ip) != 1 ||
            !InetNtopW(AF_INET6, &ip, rendered, ARRAYSIZE(rendered))) return {};
        isPrivate = IN6_IS_ADDR_LOOPBACK(&ip) || IN6_IS_ADDR_LINKLOCAL(&ip) || (ip.u.Byte[0] & 0xfe) == 0xfc;
        host = L"[" + std::wstring(rendered) + L"]";
        portStart = bracket + 1;
    } else {
        auto colon = authority.find(L':');
        host = authority.substr(0, colon);
        portStart = colon == std::wstring::npos ? authority.size() : colon;
        if (!validDomain(host)) return {};
        IN_ADDR ip{};
        if (InetPtonW(AF_INET, host.c_str(), &ip) == 1) {
            wchar_t rendered[INET_ADDRSTRLEN]{};
            if (!InetNtopW(AF_INET, &ip, rendered, ARRAYSIZE(rendered)) || host != rendered) return {};
            const auto& b = ip.S_un.S_un_b;
            isPrivate = b.s_b1 == 127 || b.s_b1 == 10 || (b.s_b1 == 172 && b.s_b2 >= 16 && b.s_b2 <= 31) ||
                (b.s_b1 == 192 && b.s_b2 == 168) || (b.s_b1 == 169 && b.s_b2 == 254);
        } else {
            // Browsers accept non-canonical numeric IPv4 spellings, including octal and hexadecimal.
            const auto last = host.substr(host.rfind(L'.') == std::wstring::npos ? 0 : host.rfind(L'.') + 1);
            if (last.find_first_not_of(L"0123456789") == std::wstring::npos || last.rfind(L"0x", 0) == 0) return {};
            isPrivate = host == L"localhost";
        }
    }
    if (!tls && !isPrivate) return {};
    unsigned port = tls ? 443u : 80u;
    if (portStart != authority.size()) {
        if (authority[portStart] != L':' || authority.size() - portStart < 2 || authority.size() - portStart > 6) return {};
        port = 0;
        for (size_t i = portStart + 1; i < authority.size(); ++i) {
            if (authority[i] < L'0' || authority[i] > L'9') return {};
            port = port * 10 + (authority[i]-L'0');
        }
        if (!port || port > 65535) return {};
    }
    return std::wstring(tls ? L"https://" : L"http://") + host +
        (port == (tls ? 443u : 80u) ? L"" : L":" + std::to_wstring(port)) + L"/";
}

inline bool validKey(const std::wstring& value) {
    if (value.size() != 88 || value.back() != L'=') return false;
    for (size_t i = 0; i < value.size()-1; ++i)
        if (!asciiAlnum(value[i]) && value[i] != L'/' && value[i] != L'+') return false;
    std::array<BYTE, 65> point{};
    if (!desktop_identity::decode(value, point) || point.front() != 4) return false;
    wchar_t canonical[90]{}; DWORD length = ARRAYSIZE(canonical);
    if (!CryptBinaryToStringW(point.data(), DWORD(point.size()), CRYPT_STRING_BASE64 | CRYPT_STRING_NOCRLF,
            canonical, &length) || value != canonical) return false;
    desktop_identity::Algorithm alg; desktop_identity::Key key;
    struct { BCRYPT_ECCKEY_BLOB header; BYTE xy[64]; } blob = {{BCRYPT_ECDSA_PUBLIC_P256_MAGIC, 32}, {}};
    std::copy(point.begin()+1, point.end(), blob.xy);
    return BCRYPT_SUCCESS(BCryptOpenAlgorithmProvider(&alg.handle, BCRYPT_ECDSA_P256_ALGORITHM, nullptr, 0)) &&
        BCRYPT_SUCCESS(BCryptImportKeyPair(alg.handle, nullptr, BCRYPT_ECCPUBLIC_BLOB, &key.handle,
            reinterpret_cast<PUCHAR>(&blob), sizeof(blob), 0));
}

// A template is exactly its linked PE image. Unexpected bytes (including a truncated stamp) are damaged.
inline std::streamoff linkedSize(std::ifstream& file) {
    auto read = [&](std::streamoff offset, void* bytes, size_t count){
        file.seekg(offset); return bool(file.read(static_cast<char*>(bytes), count)); };
    IMAGE_DOS_HEADER dos{}; IMAGE_NT_HEADERS64 nt{};
    if (!read(0, &dos, sizeof(dos)) || dos.e_magic != IMAGE_DOS_SIGNATURE || dos.e_lfanew < 0 ||
        !read(dos.e_lfanew, &nt, sizeof(nt)) || nt.Signature != IMAGE_NT_SIGNATURE ||
        nt.OptionalHeader.Magic != IMAGE_NT_OPTIONAL_HDR64_MAGIC || nt.FileHeader.NumberOfSections > 96 ||
        !nt.FileHeader.NumberOfSections) return -1;
    auto table = std::streamoff(dos.e_lfanew) + FIELD_OFFSET(IMAGE_NT_HEADERS64, OptionalHeader) + nt.FileHeader.SizeOfOptionalHeader;
    std::streamoff end = nt.OptionalHeader.SizeOfHeaders;
    for (int i = 0; i < nt.FileHeader.NumberOfSections; ++i) {
        IMAGE_SECTION_HEADER section{};
        if (!read(table + i*sizeof(section), &section, sizeof(section))) return -1;
        end = std::max(end, std::streamoff(section.PointerToRawData) + section.SizeOfRawData);
    }
    return end;
}

inline Link fromExecutable() {
    wchar_t path[32768]{};
    auto n = GetModuleFileNameW(nullptr, path, ARRAYSIZE(path));
    if (!n || n >= ARRAYSIZE(path)) return {};
    std::ifstream file(std::filesystem::path(path), std::ios::binary | std::ios::ate);
    if (!file) return {};
    auto bytes = std::streamoff(file.tellg()), image = linkedSize(file);
    if (image < 0 || bytes < image) return {};
    if (bytes == image) return {Kind::Template, {}, {}};
    constexpr char magic[] = "REQAUDIT-LINK-V2";
    constexpr size_t marker = sizeof(magic)-1;
    static_assert(marker == 16);
    if (bytes - image <= 20 || bytes - image > 20 + 2048 + 1 + 88) return {};
    file.seekg(bytes - 20);
    std::uint32_t count{}; char footer[marker]{};
    if (!file.read(reinterpret_cast<char*>(&count), sizeof(count)) || !file.read(footer, marker) ||
        std::memcmp(footer, magic, marker) || count != bytes-image-20) return {};
    file.seekg(image);
    std::string payload(count, '\0');
    if (!file.read(payload.data(), count)) return {};
    for (unsigned char ch : payload) if (ch > 0x7e || (ch < 0x21 && ch != '\n')) return {};
    auto newline = payload.find('\n');
    if (newline == std::string::npos) return {};
    std::wstring wide(payload.begin(), payload.end());
    auto endpoint = validatedOrigin(wide.substr(0, newline)), key = wide.substr(newline+1);
    if (endpoint.empty() || !validKey(key)) return {};
    return {Kind::Bound, endpoint, key};
}
}
