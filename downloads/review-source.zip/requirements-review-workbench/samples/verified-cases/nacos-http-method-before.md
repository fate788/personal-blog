### 3.25. 更新配置元数据

#### 接口描述

通过该接口，可以更新配置的元数据信息：仅能更新`描述`和`标签`。

#### 请求方式

`PUT`

#### 鉴权状态

需要具有对应`命名空间写入`权限的用户身份。

#### 请求URL

`/nacos/v3/admin/cs/config/metadata`

#### 请求参数

| **参数名**       | **参数类型** | **是否必填** | **默认值**  | **描述** |
|---------------|----------|----------|----------|--------|
| `dataId`      | `String` | **是**    | 无        | 配置ID   |
| `groupName`   | `String` | **是**    | 无        | 分组名称   |
| `namespaceId` | `String` | 否        | `public` | 命名空间   |
| `desc`        | `string` | 否        | null     | 配置的新描述 |
| `configTags`  | `string` | 否        | null     | 配置的新标签 |

#### 返回数据

返回体遵循[Nacos open API 统一返回体格式](#01-统一返回体格式)，下表只阐述`data`字段中的返回参数。

| 参数名    | 参数类型      | 描述   |
|--------|-----------|------|
| `data` | `Boolean` | 操作结果 |

#### 示例

* 请求示例

```shell
curl -X POST '127.0.0.1:8848/v3/admin/cs/config/metadata' \
-d 'namespaceId=public' \
-d 'groupName=DEFAULT_GROUP' \
-d 'dataId=test' \
-d 'desc=testDesc' \
-d 'configTags=customTag'
```
