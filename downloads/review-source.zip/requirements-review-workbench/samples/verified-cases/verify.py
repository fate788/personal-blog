"""Verify these public excerpts and their six targeted upstream corrections.

python verify.py --refetch
The optional network step downloads the twelve pinned source files for byte comparison.
This script reads examples as text. It does not run upstream shell commands or SQL.
"""
import argparse
from collections import Counter
from concurrent.futures import ThreadPoolExecutor
from hashlib import sha256
import json
from pathlib import Path
import re
from urllib.parse import urlsplit
from urllib.request import Request, urlopen


ROOT = Path(__file__).resolve().parent


def verify_version(version, refetch):
    text = (ROOT / version["file"]).read_bytes()
    assert sha256(text).hexdigest() == version["sha256"]
    first, last = version["startLine"], version["endLine"]
    assert len(text.splitlines()) == last - first + 1
    assert all(first <= line <= last for line in version["focusLines"])
    if refetch:
        url = version["rawUrl"]
        parts = urlsplit(url)
        assert parts.scheme == "https" and parts.hostname == "raw.githubusercontent.com"
        assert re.fullmatch("[0-9a-f]{40}", version["commit"]) and version["commit"] in parts.path.split("/")
        with urlopen(Request(url, headers={"User-Agent": "RequirementReviewCaseVerifier"}), timeout=25) as response:
            source = response.read()
        assert sha256(source).hexdigest() == version["sourceSha256"]
        assert b"".join(source.splitlines(keepends=True)[first - 1:last]) == text
    return text.decode("utf-8")


def target_matches(case_id, text):
    if case_id == "nacos-http-method":
        declared = re.search(r"请求方式\s+`([A-Z]+)`", text).group(1)
        actual = re.search(r"curl -X ([A-Z]+)", text).group(1)
        return actual == declared
    if case_id == "apisix-json-body":
        body = re.search(r"-d '(.+?)'\s*```", text, re.S).group(1)
        try:
            obj = json.loads(body)
        except json.JSONDecodeError as error:
            assert '"index": "gateway",' in body and body[error.pos] == "}"
            return False
        return obj["plugins"]["elasticsearch-logger"]["field"]["index"] == "gateway"
    if case_id == "doris-bigint-example":
        query = re.search(r"SELECT (json_extract_\w+)\(", text).group(1)
        output = re.search(r"\| (json_extract_\w+)\(", text).group(1)
        return query == output
    if case_id == "doris-array-count":
        args = re.search(r"select array_enumerate_uniq\((\[[^;]+, \[[^;]+)\);", text).group(1)
        arrays = [json.loads(arg) for arg in re.findall(r"\[[\d, ]+\]", args)]
        assert len(arrays) == 3 and all(len(a) == 5 for a in arrays)
        counts, calculated = Counter(), []
        for position in zip(*arrays):
            counts[position] += 1
            calculated.append(counts[position])
        stated = json.loads(re.findall(r"\| (\[[\d, ]+\])", text)[-1])
        return stated == calculated
    # For these two cases the upstream's own edit establishes the reference.
    # Matching the edit does not establish how the software runs.
    if case_id == "tidb-listen-address":
        examples = re.findall(r'"([^"]+:20160)"', text)
        assert len(examples) == 3
        return all(re.fullmatch(r"(?:\d{1,3}\.){3}\d{1,3}:20160", x) for x in examples)
    if case_id == "echarts-offset":
        assert "向上移动" in text
        return re.search(r"\[0, '(-?50%)'\]", text).group(1) == "-50%"
    raise ValueError("Unknown case " + case_id)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--refetch", action="store_true")
    args = parser.parse_args()
    cases = json.loads((ROOT / "manifest.json").read_text("utf-8"))["cases"]

    def verify(case):
        result = {key: target_matches(case["id"], verify_version(case[key], args.refetch))
                  for key in ("before", "after")}
        assert result == {"before": False, "after": True}, case["id"]
        return {"caseId": case["id"], "evidenceBasis": case["evidenceBasis"],
                "originalMatchesCorrection": False, "revisedMatchesCorrection": True}

    with ThreadPoolExecutor(max_workers=5) as pool:
        checked = list(pool.map(verify, cases))
    print(json.dumps({"upstreamBytesVerified": args.refetch, "cases": checked}, indent=2))


if __name__ == "__main__":
    main()
