import { readFile, readdir, writeFile } from 'node:fs/promises'
import { extname } from 'node:path'

const folder = new URL('./dist/', import.meta.url)
let html = await readFile(new URL('index.html', folder), 'utf8')
const script = html.match(/<script type="module"[^>]*src="\/([^"]+)"[^>]*><\/script>/)
const style = html.match(/<link rel="stylesheet"[^>]*href="\/([^"]+)"[^>]*>/)
if (!script || !style) throw new Error('The Vite HTML is missing a script or stylesheet.')
const [js, css] = await Promise.all([
  readFile(new URL(script[1], folder), 'utf8'),
  readFile(new URL(style[1], folder), 'utf8'),
])
html = html.replace(script[0], () => '<script type="module">\n' + js.replace(/<\/script/gi, '<\\/script') + '\n</script>')
html = html.replace(style[0], () => '<style>\n' + css + '\n</style>')

// A file:// preview has no server to resolve Vite's absolute image URLs.
const imageTypes = { '.webp': 'image/webp', '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.svg': 'image/svg+xml', '.avif': 'image/avif', '.gif': 'image/gif' }
const images = await readdir(new URL('assets/', folder), { withFileTypes: true })
for (const image of images) {
  const mime = imageTypes[extname(image.name).toLowerCase()]
  const url = '/assets/' + image.name
  if (!image.isFile() || !mime || !html.includes(url)) continue
  const bytes = await readFile(new URL('assets/' + image.name, folder))
  html = html.replaceAll(url, () => `data:${mime};base64,${bytes.toString('base64')}`)
}
await writeFile(new URL('preview.html', folder), html)
