<script setup>
import { computed, nextTick, ref, watch } from 'vue'
import { Check, CircleAlert, Link2, Search } from 'lucide-vue-next'
import WorkspaceSelect from './WorkspaceSelect.vue'
import { api, offline } from './api.js'
import { relatedWarningLabel, sourceGutterNumber, sourceLocation } from './workflow.js'

const props = defineProps({ documentId: String, version: Object, initialLine: Number, initialColumn: Number })
const emit = defineEmits(['select-line'])
const body = ref(null)
const selected = ref(null)
const selectedColumn = ref(null)
const query = ref('')
const checked = ref(null)
const checkError = ref(false)
const checkAttempt = ref(0)
const rows = computed(() => (props.version?.text || '').split('\n').map((text, index) => ({ text, line: index + 1 })))
const headings = computed(() => new Set((props.version?.sections || []).map(section => section.line)))
const chapterOptions = computed(() => (props.version?.sections || []).map(section => ({
  value: section.line, label: section.title,
})))
const matchLines = computed(() => {
  const word = query.value.trim().toLowerCase()
  return word ? rows.value.filter(row => row.text.toLowerCase().includes(word)) : []
})
const format = computed(() => (props.version?.source?.format || '文本').toUpperCase())
function cells(row) {
  const anchors = props.version.source?.anchors?.[row.line]?.cells
  if (!anchors?.length) return []
  return anchors.map(cell => ({ column: cell.column, text: row.text.slice(cell.start, cell.end) }))
}

watch(() => props.version?.id, () => { query.value = ''; selected.value = null; selectedColumn.value = null; if (body.value) body.value.scrollTop = 0 })
watch(() => [props.version?.id, props.initialLine, props.initialColumn], ([versionId, line, column]) => {
  if (versionId && line) go(line, column)
}, { immediate: true, flush: 'post' })
watch(() => [props.documentId, props.version?.id, checkAttempt.value], async ([documentId, versionId], _previous, onCleanup) => {
  if (offline || !documentId || !versionId) return
  let current = true
  onCleanup(() => { current = false })
  checked.value = null
  checkError.value = false
  try {
    const warnings = await api('/api/documents/' + encodeURIComponent(documentId) + '/versions/' + encodeURIComponent(versionId) + '/checks')
    if (current) checked.value = warnings
  } catch {
    if (current) checkError.value = true
  }
}, { immediate: true })

function go(line, column = null) {
  if (!line) return
  selected.value = Number(line)
  selectedColumn.value = Number.isInteger(column) ? column : null
  nextTick(() => {
    const anchor = body.value?.querySelector('[data-doc-line="' + Number(line) + '"]')
    if (!anchor) return
    body.value.scrollTop = Math.max(0, anchor.offsetTop - 45)
    anchor.focus({ preventScroll: true })
    if (matchMedia('(max-width: 720px)').matches) body.value.scrollIntoView({ block: 'nearest' })
  })
  emit('select-line', Number(line), selectedColumn.value)
}
function focusLine(line) {
  body.value?.scrollIntoView({ block: 'nearest' })
  go(line)
}
defineExpose({ focusLine })
</script>

<template>
  <div class="doc-reader">
    <div class="doc-source-info">
      <span class="file-type">{{ format }}</span>
      <div><strong>{{ version.source?.fileName || '当前版本' }}</strong><small>{{ version.items.length }} 个解析条目 · {{ version.sections.length }} 个章节<template v-if="version.source?.pageCount"> · {{ version.source.pageCount }} 页原件</template></small></div>
    </div>
    <details v-if="version.source?.warnings?.length" class="source-warnings">
      <summary><CircleAlert :size="16" /> {{ version.source.warnings.length }} 项导入提示</summary>
      <ul><li v-for="warning in version.source.warnings" :key="warning">{{ warning }}</li></ul>
    </details>
    <div v-if="!offline" class="document-checks" aria-label="原件检查">
      <details v-if="checked?.length" open>
        <summary><CircleAlert :size="16" /> 原件检查 · {{ checked.length }} 条提示</summary>
        <ul>
          <li v-for="(warning, index) in checked" :key="warning.type + ':' + warning.line + ':' + index">
            <button v-if="warning.line > 0" class="document-check-link" @click="go(warning.line)"><span>{{ warning.detail }}</span><span><Link2 :size="13" /> {{ warning.relatedLine ? '调用示例 · ' : '' }}{{ sourceLocation(version, warning.line) }}</span></button>
            <span v-else>{{ warning.detail }}</span>
            <button v-if="warning.relatedLine" class="text-button document-related-link" @click="go(warning.relatedLine)"><Link2 :size="13" /> {{ relatedWarningLabel(warning) }} · {{ sourceLocation(version, warning.relatedLine) }}</button>
          </li>
        </ul>
      </details>
      <div v-else class="document-check-status" role="status">
        <Check v-if="checked" :size="15" /><span>{{ checked ? '原件检查完成，本次规则未发现提示' : checkError ? '原件检查暂不可用' : '正在检查原件…' }}</span>
        <button v-if="checkError" class="text-button" @click="checkAttempt++">重试</button>
      </div>
    </div>
    <div class="doc-reader-toolbar">
      <label class="search"><Search :size="16" /><input v-model="query" type="search" aria-label="搜索文档正文" placeholder="搜索条款或原文" @keydown.enter.prevent="go(matchLines[0]?.line)"></label>
      <WorkspaceSelect v-if="chapterOptions.length" :options="chapterOptions" label="定位到章节" placeholder="定位到章节" @update:model-value="go($event)" />
    </div>
    <div v-if="query.trim()" class="doc-matches">
      <small>{{ matchLines.length }} 处匹配</small>
      <button v-for="entry in matchLines.slice(0, 8)" :key="entry.line" class="text-button" @click="go(entry.line)"><Link2 :size="14" /> {{ sourceLocation(version, entry.line) }}</button>
    </div>
    <div ref="body" class="paper standalone-paper" tabindex="0" aria-label="文档正文">
      <div v-for="row in rows" :key="row.line" :data-doc-line="row.line" :title="sourceLocation(version, row.line)" tabindex="-1" class="source-line" :class="{ 'source-heading': headings.has(row.line), 'source-focused': row.line === selected }">
        <span>{{ sourceGutterNumber(version, row.line) }}</span><div v-if="version.source?.anchors?.[row.line]?.cells?.length" class="source-cells"><span v-for="cell in cells(row)" :key="cell.column" :data-source-column="cell.column" :class="{ 'source-cell-focused': row.line === selected && cell.column === selectedColumn }" :title="'原件第 ' + cell.column + ' 列'">{{ cell.text || '　' }}</span></div><div v-else>{{ row.text || ' ' }}</div>
      </div>
    </div>
  </div>
</template>

<style scoped>
.document-related-link { margin: 0 12px 6px; min-height: 28px; }
</style>
