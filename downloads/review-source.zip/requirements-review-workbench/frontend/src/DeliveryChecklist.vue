<script setup>
import { computed, reactive, ref, watch } from 'vue'
import { ClipboardCheck, Download } from 'lucide-vue-next'
import { api, offline } from './api.js'

const props = defineProps({
  documentId: { type: String, required: true },
  versionId: { type: String, required: true },
  documentTitle: { type: String, required: true },
  versionNumber: { type: Number, required: true },
  reviewId: String,
  executionRevision: String,
  steps: { type: Array, default: () => [] },
})

const evidenceStates = {
  READY: '已有系统证据',
  ATTENTION: '系统有待处理事项',
  UNKNOWN: '系统证据待核对',
  MANUAL: '由人工核对',
}
const stamp = new Intl.DateTimeFormat('zh-CN', {
  timeZone: 'Asia/Shanghai', dateStyle: 'short', timeStyle: 'medium',
})
const checks = ref({})
const pending = reactive(new Set())
const loaded = ref(false)
const writable = ref(false)
const loadError = ref('')
const saveError = ref('')
const lookupReview = computed(() => props.reviewId || '')
const base = computed(() => '/api/documents/' + encodeURIComponent(props.documentId) + '/versions/' +
  encodeURIComponent(props.versionId) + '/delivery-checklist')
const scope = computed(() => base.value + '?reviewId=' + encodeURIComponent(lookupReview.value))
let request = 0

const rows = computed(() => {
  const version = {
    key: 'VERSION_REVISION',
    title: '版本与修订',
    detail: props.versionNumber > 1
      ? '核对本版改动和复查记录是否对应计划交付的版本。'
      : '核对所选原版是否与计划交付的范围一致。',
    state: 'MANUAL',
  }
  return [version, ...props.steps].map(step => ({
    ...step,
    evidence: JSON.stringify([step.state, step.detail, step.key === 'EXECUTIONS' ? props.executionRevision || '' : '']),
  }))
})
const checked = row => checks.value[row.key]?.evidenceSignature === row.evidence
const needsRecheck = row => !!checks.value[row.key] && !checked(row)
const totalChecked = computed(() => rows.value.filter(checked).length)
const systemLabel = row => evidenceStates[row.state] || evidenceStates.UNKNOWN

async function load() {
  const fetchId = ++request
  loaded.value = false
  writable.value = false
  loadError.value = ''
  saveError.value = ''
  checks.value = {}
  pending.clear()
  if (offline) return

  try {
    const snapshot = await api(scope.value)
    if (fetchId !== request) return
    if (snapshot.documentId !== props.documentId || snapshot.versionId !== props.versionId ||
      snapshot.reviewId !== lookupReview.value) throw new Error('交付版本已变化，请重新加载清单。')
    checks.value = Object.fromEntries(snapshot.entries.map(entry => [entry.itemKey, entry]))
    writable.value = snapshot.canCheck
    loaded.value = true
  } catch (error) {
    if (fetchId === request) loadError.value = error.message || '暂时无法读取人工核对清单。'
  }
}

watch(scope, load, { immediate: true })

async function changeCheck(row, event) {
  const nextValue = event.currentTarget.checked
  event.currentTarget.checked = checked(row)
  if (!loaded.value || !writable.value || pending.has(row.key)) return

  const saveId = request
  pending.add(row.key)
  saveError.value = ''
  try {
    const updated = await api(base.value, {
      method: 'PUT',
      body: { reviewId: lookupReview.value, itemKey: row.key, evidenceSignature: row.evidence, checked: nextValue },
    })
    if (saveId !== request) return
    if (updated.checked) checks.value[row.key] = updated
    else delete checks.value[row.key]
  } catch (error) {
    if (saveId === request) saveError.value = '未保存「' + row.title + '」。' + (error.message || '请重试。')
  } finally {
    if (saveId === request) pending.delete(row.key)
  }
}

function plain(value) {
  return String(value || '').replace(/[\r\n]+/g, ' ').replaceAll('&', '&amp;').replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;').replace(/[\\`*_\[\]]/g, '\\$&')
}

function exportChecklist() {
  if (!loaded.value || pending.size) return
  const lines = [
    '# 交付核对清单', '', '- 文档　' + plain(props.documentTitle), '- 版本　V' + props.versionNumber,
    '- 导出时间　' + stamp.format(new Date()) + '（北京时间）',
    '- 对照审查任务　' + (lookupReview.value ? plain(lookupReview.value) : '未选用审查任务'),
    '- 人工核对　' + totalChecked.value + ' / ' + rows.value.length, '',
    '人工勾选仅记录核对动作。交付判断以项目验收决定和实际测试记录为准。', '',
  ]
  for (const row of rows.value) {
    const done = checked(row)
    lines.push(
      '- [' + (done ? 'x' : ' ') + '] ' + plain(row.title) + ' · ' + (done ? '已核对' : '待核对'),
      '  - 系统信息　' + systemLabel(row) + '。' + plain(row.detail),
    )
    if (done) lines.push('  - 保存时间　' + stamp.format(new Date(checks.value[row.key].checkedAt)))
    if (needsRecheck(row)) lines.push('  - 系统证据已变化，请重新核对。')
  }

  const blob = new Blob([lines.join('\n') + '\n'], { type: 'text/markdown;charset=utf-8' })
  const url = URL.createObjectURL(blob)
  const anchor = window.document.createElement('a')
  const title = props.documentTitle.replace(/[<>:"/\\|?*\u0000-\u001F]/g, '_').slice(0, 80)
  anchor.href = url
  anchor.download = title + '-V' + props.versionNumber + '-交付核对清单.md'
  anchor.click()
  window.setTimeout(() => URL.revokeObjectURL(url), 1500)
}
</script>

<template>
  <section v-if="!offline" class="panel delivery-checklist" aria-labelledby="personal-delivery-checklist-heading">
    <header class="panel-heading checklist-heading">
      <div>
        <div class="delivery-panel-title">
          <ClipboardCheck :size="19" aria-hidden="true" />
          <h2 id="personal-delivery-checklist-heading" tabindex="-1">人工核对清单</h2>
        </div>
        <p>勾选后保存到当前账号。请结合系统证据判断交付条件。</p>
      </div>
      <button type="button" class="button secondary small" :disabled="!loaded || !!pending.size" @click="exportChecklist">
        <Download :size="16" aria-hidden="true" /> 下载清单
      </button>
    </header>
    <div v-if="loadError" class="checklist-message" role="alert">
      <span>{{ loadError }}</span><button type="button" class="text-button" @click="load">重新加载</button>
    </div>
    <p v-else-if="!loaded" class="checklist-message" role="status">正在加载人工核对清单…</p>
    <template v-else>
      <p class="checklist-summary" role="status">
        V{{ versionNumber }} · {{ totalChecked }} / {{ rows.length }} 项已核对
        <span v-if="!writable"> · 当前角色可查看和下载</span>
      </p>
      <ul class="checklist-items">
        <li v-for="row in rows" :key="row.key">
          <label class="checklist-item">
            <input type="checkbox" :checked="checked(row)" :disabled="!writable || pending.has(row.key)"
              @change="changeCheck(row, $event)" />
            <span class="checklist-item-copy">
              <strong>{{ row.title }}</strong>
              <small>{{ systemLabel(row) }} · {{ row.detail }}</small>
            </span>
            <span class="checklist-item-state" :class="{ checked: checked(row) }" aria-hidden="true">
              {{ pending.has(row.key) ? '保存中…' : needsRecheck(row) ? '证据已变化' : checked(row) ? '已核对' : '待核对' }}
            </span>
          </label>
          <span v-if="needsRecheck(row)" class="sr-only">原证据已变化，请重新核对。</span>
        </li>
      </ul>
      <p v-if="saveError" class="checklist-message" role="alert">{{ saveError }}</p>
    </template>
  </section>
</template>

<style scoped>
.checklist-heading { align-items: flex-start; gap: 12px; }
.checklist-heading p, .checklist-summary { margin: 4px 0 0; color: var(--muted); font-size: 13px; }
.checklist-summary { margin: 0; padding: 0 18px 8px; font-variant-numeric: tabular-nums; }
.checklist-items { margin: 0; padding: 0 18px 12px; list-style: none; }
.checklist-items li { border-top: 1px solid var(--line); }
.checklist-item { min-height: 52px; display: grid; grid-template-columns: auto minmax(0, 1fr) auto; align-items: start; gap: 10px; padding: 9px 0; }
.checklist-item input { margin: 2px 0 0; width: 18px; height: 18px; accent-color: var(--primary); }
.checklist-item-copy { display: grid; gap: 3px; min-width: 0; }
.checklist-item-copy strong { font-size: 14px; }
.checklist-item-copy small { line-height: 1.5; font-size: 12px; color: var(--muted); overflow-wrap: anywhere; }
.checklist-item-state { padding-top: 3px; color: var(--muted); font-size: 12px; }
.checklist-item-state.checked { color: #22654b; }
.checklist-message { display: flex; flex-wrap: wrap; align-items: center; gap: 10px; padding: 10px 18px 16px; margin: 0; font-size: 13px; }
.checklist-message[role="alert"] { color: #982e3a; }
@media (max-width: 460px) {
  .checklist-heading { flex-wrap: wrap; }
  .checklist-item { grid-template-columns: auto minmax(0, 1fr); }
  .checklist-item-state { grid-column: 2; padding: 0; }
}
</style>
