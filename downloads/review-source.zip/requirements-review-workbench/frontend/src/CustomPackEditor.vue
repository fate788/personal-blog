<script setup>
import { computed, nextTick, ref } from 'vue'
import { ChevronDown, Plus, Trash2 } from 'lucide-vue-next'
import { api } from './api.js'

const props = defineProps({ pack: { type: Object, required: true }, projectId: { type: String, required: true } })
const emit = defineEmits(['saved', 'cancel'])
const editing = Boolean(props.pack.basePackId)
const revision = ref(props.pack.revision)
const name = ref(editing ? props.pack.name : props.pack.name + ' · 项目版')
const description = ref(props.pack.description || '')
const rules = ref(props.pack.rules.map(rule => ({ ...rule })))
const expanded = ref('')
const working = ref(false)
const stale = ref(false)
const error = ref('')
const valid = computed(() => name.value.trim() && rules.value.length > 0 && rules.value.every(rule => rule.name.trim() && rule.question.trim()))

async function addRule() {
  const value = new Uint32Array(2)
  crypto.getRandomValues(value)
  const id = 'C-' + [...value].map(part => part.toString(16).padStart(8, '0')).join('')
  rules.value.push({ id, name: '', question: '', applies: '', criterion: '', example: '' })
  expanded.value = id
  await nextTick()
  document.getElementById('pack-rule-name-' + id)?.focus()
}

async function save() {
  if (working.value || stale.value || !valid.value) return
  working.value = true
  error.value = ''
  try {
    const endpoint = '/api/projects/' + encodeURIComponent(props.projectId) + '/packs'
    const pack = await api(editing ? endpoint + '/' + encodeURIComponent(props.pack.id) : endpoint, {
      method: editing ? 'PUT' : 'POST',
      body: { basePackId: props.pack.basePackId || props.pack.id, name: name.value.trim(), description: description.value.trim(),
        rules: rules.value.map(rule => ({ ...rule, name: rule.name.trim(), question: rule.question.trim() })),
        ...(editing ? { revision: revision.value } : {}) },
    })
    emit('saved', pack, props.projectId)
  } catch (problem) {
    stale.value = editing && problem.status === 409
    error.value = problem.message || '保存失败，请重试。'
  } finally { working.value = false }
}

async function reload() {
  if (working.value) return
  working.value = true
  try {
    const workspace = await api('/api/workspace?projectId=' + encodeURIComponent(props.projectId))
    const latest = workspace.packs.find(pack => pack.id === props.pack.id)
    if (!latest) throw new Error('这个包已从项目中移除，请返回审查包目录。')
    name.value = latest.name
    description.value = latest.description || ''
    revision.value = latest.revision
    rules.value = latest.rules.map(rule => ({ ...rule }))
    expanded.value = ''
    stale.value = false
    error.value = ''
  } catch (problem) { error.value = problem.message }
  finally { working.value = false }
}
</script>

<template>
  <form class="panel pack-editor" data-pack-editor @submit.prevent="save">
    <header><h2>{{ editing ? '编辑项目审查包' : '自定义审查包' }}</h2>
      <p>{{ editing ? '保存后生成新版本，已完成的报告保留原审查规则。' : '从「' + pack.name + '」开始，选择、改写或添加这个项目需要的检查项。' }}</p>
    </header>
    <fieldset :disabled="working">
      <label for="custom-pack-name">审查包名称</label>
      <input id="custom-pack-name" v-model="name" required maxlength="100">
      <label for="custom-pack-description">适用场景</label>
      <textarea id="custom-pack-description" v-model="description" rows="2" maxlength="600" placeholder="说明团队应在什么情况下选择这个包。"></textarea>
      <div class="editor-section-title"><h3>检查项</h3><span>{{ rules.length }} / 24</span></div>
      <ul class="editor-rules">
        <li v-for="(rule, index) in rules" :key="rule.id" :data-pack-rule="rule.id">
          <div class="rule-heading">
            <button type="button" class="rule-open" :aria-expanded="expanded === rule.id" :aria-controls="'edit-rule-' + rule.id"
              @click="expanded = expanded === rule.id ? '' : rule.id">
              <span>{{ rule.name || '新检查项' }}</span><ChevronDown :size="16" />
            </button>
            <button type="button" class="icon-button" data-rule-remove :aria-label="'移除' + (rule.name || '新检查项')"
              @click="rules.splice(index, 1)"><Trash2 :size="16" /></button>
          </div>
          <div v-show="expanded === rule.id" :id="'edit-rule-' + rule.id" class="rule-inputs">
            <label>检查项名称<input :id="'pack-rule-name-' + rule.id" data-rule-name v-model="rule.name" maxlength="100"></label>
            <label>要检查的问题<textarea data-rule-question v-model="rule.question" rows="2" maxlength="600" placeholder="例如：退款失败后，用户能从哪里查看处理进度？"></textarea></label>
            <label>适用条件<input v-model="rule.applies" maxlength="600" placeholder="在哪些情形下检查这条要求"></label>
            <label>判断标准<textarea v-model="rule.criterion" rows="2" maxlength="600" placeholder="根据哪类原文证据可以指出问题"></textarea></label>
            <label>问题示例<input v-model="rule.example" maxlength="600" placeholder="选填"></label>
          </div>
        </li>
      </ul>
      <button type="button" class="button secondary small add-rule" data-rule-add :disabled="rules.length >= 24" @click="addRule"><Plus :size="15" /> 添加检查项</button>
    </fieldset>
    <p v-if="!rules.length" role="status">至少添加一个检查项，才能保存这个包。</p>
    <p v-else-if="rules.some(rule => !rule.name.trim() || !rule.question.trim())" role="status">请补全检查项名称和要检查的问题。</p>
    <div v-if="error" role="alert" class="editor-error">{{ error }}
      <button v-if="stale" type="button" class="text-button" :disabled="working" @click="reload">放弃草稿并加载最新版</button>
    </div>
    <footer>
      <button class="button secondary small" type="button" :disabled="working" @click="emit('cancel')">取消</button>
      <button class="button primary small" data-pack-save :disabled="!valid || working || stale">{{ working ? '正在处理…' : editing ? '保存新版本' : '保存到项目' }}</button>
    </footer>
  </form>
</template>

<style scoped>
.pack-editor { padding: clamp(17px, 2.5vw, 29px); min-width: 0; }
header h2 { font-family: var(--display-font); font-size: clamp(23px, 3vw, 31px); }
header p, .pack-editor > p { color: var(--muted); margin: 6px 0 14px; font-size: 13px; line-height: 1.65; }
fieldset { min-width: 0; padding: 0; margin: 0; border: 0; display: grid; gap: 7px; }
fieldset > label, .rule-inputs label { font-size: 13px; font-weight: 620; color: var(--primary); }
fieldset > label:not(:first-child) { margin-top: 5px; }
input, textarea { width: 100%; font-weight: 400; }
.editor-section-title, .rule-heading, footer { display: flex; align-items: center; justify-content: space-between; gap: 10px; }
.editor-section-title { margin-top: 12px; }
.editor-section-title h3 { font-size: 15px; }
.editor-section-title span { color: var(--muted); font-size: 12px; }
.editor-rules { display: grid; gap: 5px; list-style: none; margin: 0; padding: 0; }
.editor-rules li { border: 1px solid var(--line); border-radius: 7px; overflow: hidden; }
.rule-heading { padding: 0 5px 0 0; gap: 0; background: #f8f5ed; }
.rule-open { color: var(--text); padding: 10px; text-align: left; display: flex; justify-content: space-between; align-items: center; gap: 8px; min-height: 40px; flex: 1; border: 0; background: none; }
.rule-open svg { flex: none; }
.rule-open[aria-expanded=true] svg { transform: rotate(180deg); }
.rule-inputs { display: grid; gap: 8px; padding: 12px; }
.rule-inputs label { display: grid; gap: 4px; }
.add-rule { justify-self: start; margin: 4px 0; }
.editor-error { margin-top: 10px; color: #883b35; font-size: 13px; }
footer { justify-content: flex-end; margin-top: 14px; border-top: 1px solid var(--line); padding-top: 12px; }
</style>
