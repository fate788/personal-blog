<script setup>
defineProps({ steps: Array, labels: Array, available: Array, visited: Array, current: Number, busy: Boolean })
defineEmits(['select'])
</script>

<template>
  <ol class="journey-steps" aria-label="工作阶段">
    <li v-for="(step, index) in steps" :key="step.action">
      <button type="button" class="journey-step" :data-coach="'stage-' + index"
        :data-state="index === current ? 'current' : visited?.[index] ? 'ready' : 'waiting'"
        :aria-current="index === current ? 'step' : undefined" :disabled="busy || (available && !available[index])"
        @click="$emit('select', step.action)">
        <span class="journey-step-icon"><component :is="step.icon" :size="19" :stroke-width="1.8" /></span>
        <span class="journey-step-copy"><strong>{{ step.title }}</strong><small>{{ labels[index] }}</small></span>
      </button>
    </li>
  </ol>
</template>
