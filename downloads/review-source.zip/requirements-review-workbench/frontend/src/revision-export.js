import { reviewProblems, sameRequestMethod } from './review-findings.js'

export function matchingRepair(problem, patches, warnings) {
  if (!problem) return null
  return patches.find(patch => {
    if (patch.findingIds?.includes(problem.id)) return true
    if (problem.warning) {
      return patch.line === problem.warning.line && patch.ruleTypes.includes(problem.warning.type)
    }
    return warnings.some(warning => warning.line === patch.line && patch.ruleTypes.includes(warning.type)
      && (warning.matchingFindingId === problem.id || sameRequestMethod({ warning }, problem)))
  })
}

export function revisedBody(run, version, edits) {
  if (run.versionId !== version.id || !edits.length) throw new Error('请先确认要应用的改动。')
  const live = new Map(reviewProblems(run, version).map(problem => [problem.id, problem]))
  const lines = version.text.split(/\r?\n/)
  const byLine = new Map()
  for (const edit of edits) {
    const current = live.get(edit.problemId)
    if (!current?.evidence.some(source => source.line === edit.line)) {
      throw new Error('有问题已被排除或证据发生变化。请重新核对后导出。')
    }
    if (byLine.has(edit.line) || lines[edit.line - 1] !== edit.expected) {
      throw new Error('有改动指向同一行或与原文不一致。请重新确认这一行。')
    }
    if (!edit.replacement.trim() || edit.replacement === edit.expected) throw new Error('请填写与原文不同的修订文字。')
    byLine.set(edit.line, edit.replacement)
  }
  return lines.map((text, index) => byLine.get(index + 1) ?? text).join('\n')
}
