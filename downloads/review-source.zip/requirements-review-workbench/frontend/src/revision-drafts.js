import { onBeforeUnmount, onMounted, ref } from 'vue'

const prefix = 'req-review:revision-draft:'
export function draftKey(userId, projectId, docId, versionId) {
  if (![userId, projectId, docId, versionId].every(Boolean)) return ''
  return prefix + [userId, projectId, docId, versionId].map(encodeURIComponent).join(':')
}

export function useRevisionDrafts() {
  const memory = new Map()
  const pending = new Map()
  const changed = ref(0)
  const memoryOnly = ref(false)
  let timer

  function read(key) {
    if (!key) return null
    if (!memory.has(key)) {
      try { memory.set(key, sessionStorage.getItem(key)) }
      catch { memoryOnly.value = true; memory.set(key, null) }
    }
    return memory.get(key)
  }

  function flush() {
    clearTimeout(timer)
    for (const [key, text] of pending) {
      try {
        if (text === null) sessionStorage.removeItem(key)
        else sessionStorage.setItem(key, text)
        pending.delete(key)
      } catch {
        // A failed write must never offer an older checkpoint as the latest text.
        try { sessionStorage.removeItem(key) } catch {}
      }
    }
    memoryOnly.value = pending.size > 0
  }
  function write(key, text) {
    if (!key || read(key) === text) return
    const wasPresent = memory.get(key) !== null
    memory.set(key, text)
    if (wasPresent !== (text !== null)) changed.value++
    pending.set(key, text)
    clearTimeout(timer)
    if (text === null) flush()
    else timer = setTimeout(flush, 250)
  }
  function clearForUser(userId) {
    if (!userId) return
    const userPrefix = prefix + encodeURIComponent(userId) + ':'
    const keys = new Set(memory.keys())
    try {
      for (let i = 0; i < sessionStorage.length; i++) keys.add(sessionStorage.key(i))
    } catch {}
    for (const key of keys) {
      if (!key?.startsWith(userPrefix)) continue
      memory.delete(key)
      pending.delete(key)
      try { sessionStorage.removeItem(key) } catch {}
    }
    changed.value++
  }
  onMounted(() => window.addEventListener('pagehide', flush))
  onBeforeUnmount(() => { window.removeEventListener('pagehide', flush); flush() })
  return { read, write, clearForUser, changed, memoryOnly }
}
