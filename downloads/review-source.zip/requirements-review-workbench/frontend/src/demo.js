import { transitions } from './workflow.js'

const storageKey = 'requirement-review-prototype-v3'
const sampleTime = '2026-11-25T09:32:00+08:00'
const sampleProjectTitle = '企业 IT 服务台与变更管理'
const sampleProjectDescription = '虚构企业信息化案例，覆盖员工报障、工单流转、SLA、变更审批、权限隔离与审计留证。'
const demoUser = {id: 'demo-user', username: 'reviewer', displayName: '演示审查员', role: 'ADMIN'}
const defaultPack = {
  id: 'requirements-basic',
  name: '基础需求质量审查包',
  description: '检查需求是否清晰、完整、一致且可验证。需要业务背景才能判定时，记录材料不足。',
  version: '1.0',
  rules: [
    {
      id: 'RV-01',
      name: '表达明确性',
      question: '角色、对象、条件和动作是否有明确指向？',
      applies: '包含权限、指代、条件或业务术语的条目。',
      criterion: '从同章及术语中查找定义。仍存在多种合理解释时，引用产生歧义的原文。',
      example: '「管理员可以查看相关记录」中的「相关」需要说明权限边界。',
    },
    {
      id: 'RV-02',
      name: '异常处理完整性',
      question: '涉及状态变化的操作在失败后应如何处理记录和资源？',
      applies: '生成记录、更新数据或占用资源的功能。',
      criterion: '核对异常分支、事务边界和资源恢复要求。缺少必要的关联材料时标记信息不足。',
      example: '报名失败应说明记录是否保留，以及已经占用的名额如何处理。',
    },
    {
      id: 'RV-03',
      name: '跨条款一致性',
      question: '适用对象、条件和范围相同的条款是否给出冲突约束？',
      applies: '关联条目对同一实体、状态或操作施加规则时。',
      criterion: '联合检查关联条款并核对适用条件。发现冲突时分别给出两处原文。',
      example: '同一活动同时要求一条有效报名记录，也允许多条有效记录。',
    },
    {
      id: 'RV-04',
      name: '验收可验证性',
      question: '是否有可观察、可度量且能用于验收的条件？',
      applies: '通知时效、性能指标、容量或其他质量属性。',
      criterion: '核对指标、阈值、负载条件和测量边界。先由业务方确认具体目标值。',
      example: '「快速响应」需要定义分位耗时、负载和测量范围。',
    },
    {
      id: 'RV-05',
      name: '访问与审批边界',
      question: '访问权限是否兼顾租户边界、最小授权和独立审批？',
      applies: '工单可见性、跨组织分派、紧急变更或敏感信息读取。',
      criterion: '对照角色职责和例外流程，核对作用范围、授权依据、审批责任和审计记录。',
      example: '紧急变更可缩短审批时限，审批人仍与发起人分离。',
    },
    {
      id: 'RV-06',
      name: '数据与追踪完整性',
      question: '状态、数据关系、审计及留存要求能否追溯？',
      applies: '历史记录、审计事件、需求引用、外部接口及数据删除。',
      criterion: '核对可用引用与数据责任，区分在线访问和归档，保留重试和人工补偿的可追溯记录。',
      example: '工单同步失败时记录关联 ID、幂等键及重试结果。',
    },
  ],
}

const packs = [
  defaultPack,
  {
    id: 'requirements-consistency',
    name: '业务一致性专项',
    description: '侧重跨模块冲突、访问与审批边界、状态及数据约束。',
    version: '1.0',
    rules: defaultPack.rules.filter(rule => ['RV-03', 'RV-05', 'RV-06'].includes(rule.id)),
  },
  {
    id: 'requirements-acceptance',
    name: '可验收性专项',
    description: '核对描述清晰度、失败恢复和可测量的质量指标。',
    version: '1.0',
    rules: defaultPack.rules.filter(rule => ['RV-01', 'RV-02', 'RV-04'].includes(rule.id)),
  },
]

export const enterpriseText = `# 企业 IT 服务台与变更管理 · 软件需求规格说明书
文档编号 SRS-ITSM-001 ｜ 版本 V1.0 ｜ 状态：提交需求评审
本文为虚构的企业数字化建设案例，部门、系统和数据为自建样例。

## 1. 项目目标与边界
员工通过统一入口提交报障，服务台分派并跟踪，值班人员处理重大事件，系统记录受控变更与审计过程。本期范围含员工门户、服务台、值班与变更控制台。自动执行生产变更和计费结算留在后续阶段。
本案例的单个组织空间具有独立工单与审计记录。P1 表示关键服务不可用。首次响应指服务台或值班工程师首次向报障人发送人工处理说明。

## 2. 角色和职责
报障人查阅本人提交工单和面向报障人的回复。服务台负责受理与分派。值班工程师处理当班事件。变更负责人拟定方案，由变更审批员或值班经理负责审批。组织管理员授权，审计员按授权范围查阅记录。
FR-001：员工通过企业统一身份登录，首次登录后依据身份声明绑定员工编号与组织空间。未成功绑定的会话不得创建工单。
FR-002：报障人可查阅本人提交的工单与公开回复，内部处理备注仅对所属组织中获授权的服务台和处理人可见。
FR-003：值班工程师只能访问当前组织空间内已分派给本人或本值班组的工单。审计员仅通过授权的审计视图查阅。
FR-004：统一身份系统传入岗位组，服务台按外部岗位组清单映射审批员与值班经理权限。外部岗位组清单由身份管理团队另行交付。

## 3. 报障与工单处理
FR-005：员工提交报障时填写服务、影响描述和联系渠道。同一组织及员工在 10 分钟内重复使用相同请求标识时，返回原工单编号。
FR-006：服务台可按服务目录、地点和班次选定队列。队列无人可受理时应采取适当措施并将工单交给相关人员。
FR-007：工单状态按「新建→处理中→已解决→已关闭」流转。报障人可在解决后 48 小时内确认解决或重开，超时自动关闭并记录系统操作人。
FR-008：处理人添加时间线备注时，必须显式选择公开或内部可见性。后续变更可见性须记录操作人和原因。
FR-009：分派工单时更新责任组和处理人，并通过消息服务通知接收人。消息服务失败时系统提示分派失败。
FR-010：收到重开操作后保留原解决记录，工单转回处理中，将重开原因写入时间线，并通知最后一个有效责任组。
FR-011：工单查询结果按更新时间倒序排列，相同时间使用工单编号降序作为次排序键。查询接口仅返回本页授权范围内的结果。

## 4. 重大事件与 SLA
FR-012：重大事件由值班经理标记为 P1，升级后必须关联受影响服务。首次响应未完成时，P1 工单处于「等待用户」状态也继续计算首次响应 SLA。
FR-013：当首次响应 SLA 达到阈值的 80% 时向责任组值班人员发出预警，同一工单同一响应周期只发一次，保留通知事件编号。
FR-014：看板需尽快展示最新的 P1 工单状态，便于值班经理跟踪当前处置进度。
NFR-001：P1 首次响应 SLA 为 15 分钟，从工单首次保存起算，进入「等待用户」状态时暂停。恢复时累加已消耗时间。
NFR-002：在 250 个并发工单查询用户下，最近 30 天记录查询的服务端 P95 耗时不超过 800 毫秒，5 分钟观测窗口内统计。
NFR-003：员工提交报障后系统应快速响应并显示编号。

## 5. 变更与审批
FR-015：对生产服务的常规变更应填写影响范围、实施窗口和回滚方案，创建待审批记录并关联服务资产。
FR-016：常规和紧急变更必须有独立审批记录。发起人、执行人与审批人分离，审批员不得审批本人发起的生产变更。
FR-017：紧急变更由值班经理在收到请求后 10 分钟内作出批准或拒绝决定。值班高峰允许值班经理直接批准本人发起的紧急变更。
FR-018：已批准变更执行前须核验审批记录仍有效；实施窗口以外禁止启动，界面提示重新提交方案。
FR-019：变更回滚时保存触发原因、回滚执行人、回滚结果和时间戳。回滚不覆盖已保存的实施记录。
FR-020：工单可关联生产变更，只有处理负责人可操作关联。关联权限与角色规则见 FR-099。
FR-021：当工单升级为 P1 时，为缩短协调时间，值班工程师可以打开其他组织空间中的 P1 工单附件，无需额外授权。

## 6. 数据、审计和集成
DR-001：工单编号在组织空间内唯一，关联记录同时持有组织标识和工单编号。新增工单与请求标识在一次事务中提交。
DR-002：审批事件应记录组织、变更编号、审批人、决定、时间和理由。生产变更审批审计记录仅保留 30 天，期满后永久删除。
DR-003：附件对象、工单与当前读取会话必须属于同一组织空间。所有下载均校验工单读取权限和附件授权。
DR-004：服务台改变工单状态、分派对象或备注可见性时记录旧值、新值和操作来源。审计事件以追加方式保存。
NFR-004：生产变更审批审计记录在线保留不少于 180 天，在此期间审核人可通过工单或变更编号检索。
NFR-005：系统发现存储失败时应返回可追踪错误编号并写入运维日志。错误消息不得包含访问令牌或完整工单附件路径。
NFR-006：附件的恶意内容检测在上传后运行。判定为待检查或不通过的附件在所有用户视图中均禁止下载。

## 7. 验收资料
验收取数使用虚构组织、员工和工单。角色组映射由身份管理团队补交。项目组准备 P1 升级、等待回复、通知失败、跨组织读取拒绝和紧急变更分离审批的验收场景。`

export const enterpriseTextV2 = enterpriseText
  .replace('版本 V1.0 ｜ 状态：提交需求评审', '版本 V2.0 ｜ 状态：修订后复查')
  .replace('报障后系统应快速响应并显示编号。', '报障后，从提交请求到服务端返回编号的 P95 耗时，在 120 个并发提交下不超过 1.2 秒。')
  .replace('关联权限与角色规则见 FR-099。', '关联权限按 FR-003 与 DR-001 核对；发起关联前校验两条记录的组织标识。')
  .replace('生产变更审批审计记录仅保留 30 天，期满后永久删除。', '生产变更审批审计记录在线保留不少于 180 天。')

const sampleText = `软件需求规格说明书 V1.0（节选）

1.2 系统范围
本系统面向在校学生和活动管理员，提供活动发布、在线报名、报名信息维护及通知功能。

2.1 用户角色
学生可查询活动、提交报名及查看报名结果；活动管理员负责维护本人所管理活动的报名信息。

3.2 活动报名
FR-021：学生完成身份认证后，可在报名截止时间前提交报名申请。系统应校验活动剩余名额，并为符合条件的学生生成有效报名记录。
FR-022：同一学生对同一活动只能保留一条有效报名记录。重复提交时，系统应返回原报名结果，不重复占用名额。
FR-023：报名提交失败时，系统应向学生显示失败提示。

3.3 报名信息维护
FR-031：活动管理员可以修改报名信息，保存成功后，系统应及时通知相关学生。

4.1 性能要求
NFR-011：在 500 名学生同时在线的条件下，系统应快速响应报名提交请求。

5.1 数据约束
DR-006：同一学生对同一活动允许同时存在多条有效报名记录。`

const exampleText = `1. 系统范围
系统支持在校师生预约图书馆自习座位。

2. 座位预约
FR-101：认证用户可预约当天剩余的自习座位。每名用户同一时段最多预约一个座位。
FR-102：预约提交失败时，系统应回滚预占的座位，并显示失败原因。

3. 性能要求
NFR-101：在 100 个并发预约请求下，从请求到达服务端至写入响应，95% 的请求耗时不超过 800 毫秒。`

const entryPattern = /^\s*([A-Z][A-Z0-9]{0,9}[-_]\d+)\b[：:、.\s]*/i
const headingPattern = /^(?:#{1,6}\s+(.+)|(?:第[一二三四五六七八九十百\d]+[章节篇]|\d+(?:\.\d+)+[.、]?|\d+[.、])\s*(.+))$/
let state

function uid() {
  return globalThis.crypto?.randomUUID?.() ??
    `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 12)}`
}

function makeVersion(text, number = 1, id = uid(), createdAt = new Date().toISOString()) {
  const letters = typeof text === 'string' ? text.replace(/^\uFEFF/, '').replace(/\r\n?/g, '\n') : ''
  if (!letters.trim()) throw new Error('请输入需求文档内容。')
  if (letters.length > 200000) throw new Error('文档超过 20 万字符，请拆分后导入。')
  const sections = []
  const items = []
  let section = '正文'
  for (const [index, line] of letters.split('\n').entries()) {
    const content = line.trim()
    const label = line.match(entryPattern)
    if (label) {
      items.push({id: `${id}-L${index + 1}`, code: label[1].toUpperCase(), text: line, line: index + 1, section})
      continue
    }
    if (headingPattern.test(content)) {
      section = content.replace(/^#{1,6}\s+/, '')
      const level = content.match(/^(#{1,6})\s+/)?.[1].length ?? 1
      sections.push({id: `${id}-S${index + 1}`, title: section, line: index + 1, level})
    }
  }
  if (!sections.length) sections.push({id: `${id}-S1`, title: '正文', line: 1, level: 1})
  if (!items.length) {
    letters.split('\n').forEach((line, index) => {
      if (line.trim() && !headingPattern.test(line.trim())) {
        items.push({
          id: `${id}-L${index + 1}`,
          code: `L-${String(index + 1).padStart(3, '0')}`,
          text: line,
          line: index + 1,
          section: sections.findLast(candidate => candidate.line <= index + 1)?.title ?? '正文',
        })
      }
    })
  }
  return {id, number, text: letters, createdAt, sections, items}
}

function makeDocument(title, text, id = uid(), versionId = uid(), createdAt = new Date().toISOString()) {
  const name = typeof title === 'string' ? title.trim() : ''
  if (!name) throw new Error('请输入文档名称。')
  if (name.length > 160) throw new Error('文档名称最多支持 160 个字符。')
  return {id, title: name, createdAt, updatedAt: createdAt, versions: [makeVersion(text, 1, versionId, createdAt)]}
}

function evidence(item, quote) {
  if (!item) return null
  const start = item.text.indexOf(quote)
  if (start < 0 || item.text.indexOf(quote, start + 1) >= 0) return null
  return {itemId: item.id, code: item.code, quote, line: item.line, start, end: start + quote.length}
}

const enterpriseFindings = [
  {
    rule: 'RV-03', severity: 'HIGH', title: 'P1 等待用户期间的 SLA 计时相互矛盾',
    reason: '两个条款均适用于处于等待用户状态且尚未完成首次响应的 P1 工单。继续计时与暂停计时会导致同一工单是否违约出现不同结论。',
    suggestion: '由服务运营负责人选定口径，同步修改事件处理、SLA 公式、预警及报表。增加等待期间跨越 15 分钟的验收场景。',
    refs: [['FR-012', '也继续计算首次响应 SLA'], ['NFR-001', '进入「等待用户」状态时暂停']],
  },
  {
    rule: 'RV-05', severity: 'HIGH', title: '紧急变更可绕过独立审批',
    reason: 'FR-016 的职责分离同时适用于常规和紧急变更，FR-017 却允许值班经理在未定义的高峰条件下自批紧急变更。',
    suggestion: '明确替代审批人及最短授权路径。记录缺少可用审批人的处理方式，并对全部紧急决定保存独立审批记录。',
    refs: [['FR-016', '审批员不得审批本人发起的生产变更'], ['FR-017', '允许值班经理直接批准本人发起的紧急变更']],
  },
  {
    rule: 'RV-05', severity: 'HIGH', title: '跨组织附件权限要求缺少授权边界',
    reason: '紧急工单条款允许值班工程师读取其他组织空间附件，角色范围和附件约束则要求组织一致。P1 等级自身无法确定可读取哪些对象。',
    suggestion: '由数据负责人明确跨组织协作是否允许。若需要，定义显式授权对象、有效期和审计记录，并同步更新角色和附件规则。',
    refs: [
      ['FR-021', '可以打开其他组织空间中的 P1 工单附件，无需额外授权'],
      ['FR-003', '只能访问当前组织空间内已分派给本人或本值班组的工单'],
      ['DR-003', '附件对象、工单与当前读取会话必须属于同一组织空间'],
    ],
  },
  {
    rule: 'RV-06', severity: 'HIGH', title: '生产变更审批记录的留存要求冲突',
    reason: '同一类审批审计记录在 DR-002 中第 30 天后删除，NFR-004 要求在线可查至少 180 天，现有条款没有区分适用对象。',
    suggestion: '由合规负责人确认在线和归档年限、手工检索权限及到期清理条件，统一保留要求和验收方法。',
    refs: [['DR-002', '生产变更审批审计记录仅保留 30 天，期满后永久删除'], ['NFR-004', '生产变更审批审计记录在线保留不少于 180 天']],
  },
  {
    rule: 'RV-02', severity: 'MEDIUM', title: '分派通知失败后工单和审计状态不明确',
    reason: '分派包含责任组更新和异步通知，失败路径只有提示。当前条款无法确定责任组变更是否提交、重试是否重复发通知或该记录是否应进入审计。',
    suggestion: '规定分派状态和通知投递状态的边界，补充失败时的原子性或补偿、幂等重试及审计事件关联方式。',
    refs: [
      ['FR-009', '消息服务失败时系统提示分派失败'],
      ['FR-009', '更新责任组和处理人，并通过消息服务通知接收人'],
      ['DR-004', '分派对象或备注可见性时记录旧值、新值和操作来源'],
    ],
  },
  {
    rule: 'RV-01', severity: 'MEDIUM', title: '队列无人值守时的分派边界不清楚',
    reason: '条款既未说明替代人员是值班经理、后备队列还是共享服务团队，也没有给出升级条件与责任记录。',
    suggestion: '补充无可用处理人时的队列优先顺序、等待上限、升级对象和观察结果，具体运行条件由服务台确认。',
    refs: [['FR-006', '应采取适当措施并将工单交给相关人员']],
  },
  {
    rule: 'RV-04', severity: 'MEDIUM', title: '重大事件看板缺少数据新鲜度验收条件',
    reason: '“尽快”无法定义处置变更何时在看板可见；不同刷新方式或断线恢复下会有不同体验。',
    suggestion: '给出从状态提交到看板可见的时延上限、统计口径、断线标识和恢复要求。',
    refs: [['FR-014', '看板需尽快展示最新的 P1 工单状态']],
  },
  {
    rule: 'RV-04', severity: 'MEDIUM', title: '报障提交的响应性能缺少测量口径',
    reason: 'NFR-003 无法测量“快速响应”。NFR-002 已定义查询性能，但服务端查询与报障提交为不同操作。',
    suggestion: '分别定义提交负载、计时起止、统计分位和阈值，并补充队列拥堵或服务降级时的验收场景。',
    refs: [['NFR-003', '系统应快速响应并显示编号'], ['NFR-002', '记录查询的服务端 P95 耗时不超过 800 毫秒']],
  },
  {
    rule: 'RV-06', severity: 'MEDIUM', title: '工单和生产变更的关联引用无法核对',
    reason: 'FR-020 将操作权限指向文档中不存在的 FR-099。实际的角色边界、数据标识与审批权限需要分别明确。',
    suggestion: '核实并更新引用，补充关联双方的组织校验和变更状态约束。',
    refs: [['FR-020', '关联权限与角色规则见 FR-099'], ['DR-001', '关联记录同时持有组织标识和工单编号']],
  },
  {
    rule: 'RV-05', severity: 'LOW', status: 'INSUFFICIENT', title: '外部岗位组权限映射尚未交付',
    reason: '条款明确映射表由外部团队交付。样例可见范围尚无组值、有效期和变动同步口径，无法判断映射是否匹配角色职责。',
    suggestion: '向身份管理团队索引当前版本的岗位组映射、异常回退策略和交付编号，再复查审批权限覆盖。',
    refs: [['FR-004', '外部岗位组清单由身份管理团队另行交付']],
  },
  {
    rule: 'RV-02', severity: 'LOW', status: 'NOT_APPLICABLE', title: '查询排序不涉及写入回滚',
    reason: 'FR-011 只描述授权查询及确定的排序方式。状态变更回滚项不适用于本条查询。',
    suggestion: '',
    refs: [['FR-011', '查询接口仅返回本页授权范围内的结果']],
  },
]

function runReview(document, version, pack, {id = uid(), createdAt = new Date().toISOString(), itemIds} = {}) {
  const startTime = performance.now()
  const findings = []
  const selection = new Set(itemIds ?? [])
  const available = new Set(version.items.map(item => item.id))
  if ([...selection].some(itemId => !available.has(itemId))) {
    throw new Error('所选审查条目不属于当前文档版本，请重新选择。')
  }
  const targets = selection.size ? version.items.filter(item => selection.has(item.id)) : version.items
  const checked = targets.slice(0, 40)
  const checkedSet = new Set(checked.map(item => item.id))
  const find = code => version.items.find(item => item.code === code)
  const add = (ruleId, severity, title, reason, suggestion, references, status = 'ISSUE') => {
    const rule = pack.rules.find(candidate => candidate.id === ruleId)
    if (!rule || references.some(reference => reference === null)) return
    const primary = references.find(anchor => checkedSet.has(anchor.itemId))
    if (!primary) return
    findings.push({
      id: `${id}-F${findings.length + 1}`, ruleId, title, category: rule.name, severity, status,
      itemId: primary.itemId,
      reason, suggestion, evidence: references, decision: 'PENDING', note: '', decidedAt: null,
    })
  }
  const enterprise = version.text.includes('SRS-ITSM-001')
  if (enterprise) {
    for (const fixture of enterpriseFindings) {
      add(fixture.rule, fixture.severity, fixture.title, fixture.reason, fixture.suggestion,
        fixture.refs.map(([code, quote]) => evidence(find(code), quote)), fixture.status)
    }
  }
  const knownFindings = new Set(findings.flatMap(finding => finding.evidence.map(anchor => anchor.itemId)))
  add(
    'RV-03', 'HIGH', '同一活动的有效报名记录数量互相冲突',
    '两处条款适用于同一学生与同一活动。功能条款限定一条有效记录，数据约束允许多条有效记录，开发和验收会得到不同结论。',
    '请业务方确认应采用的记录数量约束，再统一 FR-022 与 DR-006。若允许保留历史记录，明确其有效状态。',
    [
      evidence(find('FR-022'), '同一学生对同一活动只能保留一条有效报名记录'),
      evidence(find('DR-006'), '同一学生对同一活动允许同时存在多条有效报名记录'),
    ],
  )
  const failure = find('FR-023')
  if (failure?.text.replace(entryPattern, '').trim().replace(/[。.!！]$/, '') ===
      '报名提交失败时，系统应向学生显示失败提示') {
    add(
      'RV-02', 'MEDIUM', '报名失败后的状态处理要求不足',
      'FR-021 涉及生成报名记录和校验名额，FR-023 仅说明失败提示。当前检查范围内，记录状态与已占用名额如何处理仍待确认。',
      '补充报名提交失败时的数据与名额处理要求，覆盖部分写入、重复提交和可重试错误。',
      [
        evidence(failure, '系统应向学生显示失败提示'),
        evidence(find('FR-021'), '系统应校验活动剩余名额'),
      ],
    )
  }
  for (const item of checked) {
    if (knownFindings.has(item.id)) continue
    if (/\d+\s*(?:ms\b|毫秒|秒|分钟|小时|天)/i.test(item.text)) continue
    const vague = item.text.match(/及时通知|快速响应|尽快处理|尽快展示|迅速完成/)
    if (!vague) continue
    const appliesToPerformance = vague[0] === '快速响应'
    add(
      'RV-04', 'MEDIUM', appliesToPerformance ? '响应时延缺少可验收指标' : '时效要求缺少明确阈值',
      `条目使用「${vague[0]}」描述时效。当前条目未给出可测量的阈值和时间边界。`,
      appliesToPerformance
        ? '明确负载、计时起止点和百分位时延阈值，并由相关方确认目标数值。'
        : '由业务方确认时限，补充计时起点和完成判定，明确失败处理方式。',
      [evidence(item, vague[0])],
    )
  }
  const pending = checked.find(item => item.text.includes('待确认'))
  if (pending) {
    add(
      'RV-01', 'LOW', '需补充业务口径',
      '文档中存在显式待确认标记，当前信息不足以判断涉及的业务规则。',
      '确认业务目标、适用角色或约束后，再修订文档并复查。',
      [evidence(pending, '待确认')], 'INSUFFICIENT',
    )
  }
  const ruleWarnings = []
  const seen = new Set()
  const codes = new Set(version.items.map(item => item.code))
  for (const item of version.items) {
    if (seen.has(item.code)) ruleWarnings.push({type: 'DUPLICATE_CODE', detail: `需求编号 ${item.code} 重复。`, line: item.line})
    seen.add(item.code)
    const body = item.text.replace(entryPattern, '')
    const missing = [...new Set(body.match(/\b[A-Z][A-Z0-9]{0,9}[-_]\d+\b/g) ?? [])].filter(code => !codes.has(code))
    for (const code of missing) ruleWarnings.push({type: 'UNKNOWN_REFERENCE', detail: `${item.code} 引用的 ${code} 未在当前版本定义。`, line: item.line})
  }
  const checkedIds = checked.map(item => item.id)
  const omitted = targets.slice(checked.length).map(item => item.id)
  const details = []
  for (let start = 0; start < checked.length; start += 4) {
    const primary = checked.slice(start, start + 4)
    const primaryIds = primary.map(item => item.id)
    const relatedIds = findings
      .filter(finding => finding.evidence.some(anchor => primaryIds.includes(anchor.itemId)))
      .flatMap(finding => finding.evidence.map(anchor => anchor.itemId))
      .filter(itemId => !primaryIds.includes(itemId))
    details.push({
      number: details.length + 1, primaryItemIds: primaryIds, contextItemIds: [...new Set(relatedIds)],
      completed: true, coveredChecks: primary.length * pack.rules.length,
    })
  }
  const diagnostics = [{type: 'DEMO', detail: enterprise
    ? '本地演示回放自建评审样例。原文修订后会重新匹配已知证据，实际语义复查需使用模型。'
    : '本地演示提供样例判定与有限词语检查。未命中的条目仍需在模型模式或人工评审中核对。'}]
  if (omitted.length) diagnostics.push({type: 'SCOPE_LIMIT', detail: `达到本地演示上限，${omitted.length} 个条目未覆盖。`})
  return {
    id, documentId: document.id, versionId: version.id, packId: pack.id, createdAt, mode: 'DEMO',
    status: omitted.length ? 'PARTIAL' : 'COMPLETED', packVersion: pack.version, model: '本地样例回放',
    targetItemIds: targets.map(item => item.id),
    scope: {
      items: targets.length, checks: targets.length * pack.rules.length, batches: details.length,
      coveredItemIds: checkedIds, omittedItemIds: omitted, coveredChecks: checkedIds.length * pack.rules.length, details,
    },
    elapsedMs: Math.round(performance.now() - startTime),
    usage: {calls: 0, inputTokens: 0, outputTokens: 0},
    findings,
    diagnostics,
    ruleWarnings,
  }
}

function makeProject(name, description, id = uid(), createdAt = new Date().toISOString()) {
  const label = typeof name === 'string' ? name.trim() : ''
  const details = typeof description === 'string' ? description.trim() : ''
  if (!label || label.length > 120) throw new Error('请输入 1 至 120 个字符的项目名称。')
  if (details.length > 2000) throw new Error('项目说明最多支持 2000 个字符。')
  return {id, name: label, description: details, createdAt, updatedAt: createdAt}
}

function seedEnterprise(workspace) {
  const existing = workspace.projects.find(project => project.id === 'enterprise-itsm')
  if (existing) return existing
  const project = makeProject(sampleProjectTitle, sampleProjectDescription, 'enterprise-itsm', sampleTime)
  const document = makeDocument('企业 IT 服务台与变更管理 SRS', enterpriseText, 'itsm-srs', 'itsm-v1', sampleTime)
  document.projectId = project.id
  const revisedAt = '2026-11-26T14:20:00+08:00'
  document.versions.unshift(makeVersion(enterpriseTextV2, 2, 'itsm-v2', revisedAt))
  document.updatedAt = revisedAt
  project.updatedAt = revisedAt
  const initial = runReview(document, document.versions[1], defaultPack, {id: 'itsm-review-1', createdAt: '2026-11-25T09:35:00+08:00'})
  const followup = runReview(document, document.versions[0], defaultPack, {id: 'itsm-review-2', createdAt: '2026-11-26T14:24:00+08:00'})
  const decidedAt = '2026-11-25T10:12:00+08:00'
  const reviewed = initial.findings.filter(finding => finding.ruleId === 'RV-06'
    || finding.evidence[0]?.code === 'NFR-003')
  const logs = reviewed.map(finding => {
    const note = '与编写人核对并纳入 V2 修订范围，复查时验证对应条款。'
    finding.decision = 'CONFIRMED'
    finding.note = note
    finding.decidedAt = decidedAt
    return {findingId: finding.id, priorDecision: 'PENDING', newDecision: 'CONFIRMED', note, createdAt: decidedAt}
  })
  workspace.decisions[initial.id] = logs
  const fixedPerformance = reviewed.find(finding => finding.evidence[0]?.code === 'NFR-003')
  if (fixedPerformance) {
    workspace.issues ??= {}
    const completion = '2026-11-26T15:00:00+08:00'
    const note = '对照 V2 性能条款，确认已补齐峰值负载、P95 时延和验收口径。'
    workspace.issues[initial.id] = [{
      findingId: fixedPerformance.id, status: 'VERIFIED', assigneeId: 'demo-author', assigneeName: '需求作者',
      dueDate: '2026-11-27', resolutionVersionId: 'itsm-v2', note, updatedAt: completion, updatedBy: demoUser.id,
      history: [{fromStatus: 'FIXED', toStatus: 'VERIFIED', assigneeId: 'demo-author', assigneeName: '需求作者',
        dueDate: '2026-11-27', resolutionVersionId: 'itsm-v2', note, actorId: demoUser.id,
        actorName: demoUser.displayName, createdAt: completion}],
    }]
  }
  workspace.projects.unshift(project)
  workspace.documents.unshift(document)
  workspace.runs.unshift(followup, initial)
  return project
}

function loadState() {
  if (state) return state
  try {
    const stored = globalThis.localStorage?.getItem(storageKey)
    if (stored) {
      state = JSON.parse(stored)
      state.users ??= [demoUser]
      if (state.user?.id === demoUser.id) state.user = demoUser
      return state
    }
  } catch {
    // Some browsers disable file-origin storage. The current tab can still keep review data in memory.
  }
  const campusProject = makeProject('校园活动报名系统', '开题 PPT 样例，用于检查报名记录约束、失败恢复和验收阈值。', 'campus-project', sampleTime)
  const campus = makeDocument('校园活动报名系统需求规格说明书', sampleText, 'campus', 'campus-v1', sampleTime)
  campus.projectId = campusProject.id
  const libraryProject = makeProject('图书馆座位预约', '正常条款对照样例，包含可验证的容量和性能要求。', 'library-project', sampleTime)
  const library = makeDocument('图书馆座位预约需求规格说明书', exampleText, 'library', 'library-v1', sampleTime)
  library.projectId = libraryProject.id
  const run = runReview(campus, campus.versions[0], defaultPack, {id: 'campus-review-1', createdAt: '2026-11-25T09:35:00+08:00'})
  state = {
    mode: 'DEMO', documents: [campus, library], packs, runs: [run],
    projects: [campusProject, libraryProject], user: demoUser, users: [demoUser], decisions: {},
  }
  seedEnterprise(state)
  return state
}

function saveState() {
  try {
    globalThis.localStorage?.setItem(storageKey, JSON.stringify(state))
  } catch {
    // The current tab remains usable when storage is unavailable or full.
  }
}

const utf8 = new TextDecoder()
const MAX_IMPORT = 10 * 1024 * 1024
const wordNamespace = 'http://schemas.openxmlformats.org/wordprocessingml/2006/main'

async function wordXml(buffer) {
  const data = new Uint8Array(buffer)
  const view = new DataView(buffer)
  let position = data.length - 22
  const limit = Math.max(0, data.length - 65557)
  while (position >= limit && (
    view.getUint32(position, true) !== 0x06054b50 ||
    position + 22 + view.getUint16(position + 20, true) !== data.length
  )) position--
  if (position < limit) throw new Error('无法读取 DOCX 压缩目录，请检查文件是否可正常打开。')
  const count = view.getUint16(position + 10, true)
  position = view.getUint32(position + 16, true)
  for (let index = 0; index < count; index++) {
    if (position + 46 > data.length || view.getUint32(position, true) !== 0x02014b50) break
    const method = view.getUint16(position + 10, true)
    const packedSize = view.getUint32(position + 20, true)
    const xmlSize = view.getUint32(position + 24, true)
    const nameLength = view.getUint16(position + 28, true)
    const extraLength = view.getUint16(position + 30, true)
    const commentLength = view.getUint16(position + 32, true)
    const localOffset = view.getUint32(position + 42, true)
    const name = utf8.decode(data.subarray(position + 46, position + 46 + nameLength))
    position += 46 + nameLength + extraLength + commentLength
    if (name !== 'word/document.xml') continue
    if (xmlSize > MAX_IMPORT) throw new Error('DOCX 正文过大，请拆分后导入。')
    if (localOffset + 30 > data.length || view.getUint32(localOffset, true) !== 0x04034b50) break
    const start = localOffset + 30 + view.getUint16(localOffset + 26, true) + view.getUint16(localOffset + 28, true)
    if (start + packedSize > data.length) break
    const payload = data.subarray(start, start + packedSize)
    if (method === 0) return utf8.decode(payload)
    if (method !== 8 || typeof DecompressionStream !== 'function') break
    const reader = new Blob([payload]).stream().pipeThrough(new DecompressionStream('deflate-raw')).getReader()
    const parts = []
    let total = 0
    for (;;) {
      const {value, done} = await reader.read()
      if (done) break
      total += value.length
      if (total > MAX_IMPORT || total > xmlSize) {
        await reader.cancel()
        throw new Error('DOCX 正文数据异常或过大，请用 Word 另存后重试。')
      }
      parts.push(value)
    }
    if (total !== xmlSize) break
    return new Blob(parts).text()
  }
  throw new Error('无法提取 DOCX 正文。请用较新版本的浏览器打开原型，或使用 UTF-8 TXT 导入。')
}

function plainParagraph(paragraph) {
  return Array.from(paragraph.getElementsByTagNameNS(wordNamespace, '*'))
    .map(node => {
      if (node.parentNode?.localName !== 'r') return ''
      if (node.localName === 't') return node.textContent
      if (node.localName === 'br' || node.localName === 'cr') return '\n'
      if (node.localName === 'tab') return '\t'
      return ''
    }).join('')
}

function revisionCodeFences(body) {
  const opening = new Map(), closing = new Map()
  let active = null
  for (const p of body.children) {
    if (p.localName !== 'p') { active = null; continue }
    const style = p.getElementsByTagNameNS(wordNamespace, 'pStyle')[0]?.getAttributeNS(wordNamespace, 'val')
    if (style === 'CodeBlock') {
      for (const mark of p.getElementsByTagNameNS(wordNamespace, 'bookmarkStart')) {
        const match = /^ReqCode(Open)?_[0-9]+_([A-Za-z0-9_]{1,32})$/.exec(mark.getAttributeNS(wordNamespace, 'name'))
        if (!match) continue
        active = { start: p, id: mark.getAttributeNS(wordNamespace, 'id'), language: match[2], closed: !match[1], ticks: 2, tildes: 2 }
        break
      }
    }
    if (!active) continue
    for (const line of plainParagraph(p).split('\n')) {
      const prefix = line.trimStart().match(/^(`+|~+)/)?.[0] || ''
      if (prefix.startsWith('`')) active.ticks = Math.max(active.ticks, prefix.length)
      else active.tildes = Math.max(active.tildes, prefix.length)
    }
    if (Array.from(p.getElementsByTagNameNS(wordNamespace, 'bookmarkEnd')).some(end => end.getAttributeNS(wordNamespace, 'id') === active.id)) {
      const marker = active.ticks <= active.tildes ? '`'.repeat(active.ticks + 1) : '~'.repeat(active.tildes + 1)
      opening.set(active.start, marker + active.language)
      if (active.closed) closing.set(p, marker)
      active = null
    }
  }
  return { opening, closing }
}

function headingLevel(paragraph) {
  const style = paragraph.getElementsByTagNameNS(wordNamespace, 'pStyle')[0]?.getAttributeNS(wordNamespace, 'val')
  const level = paragraph.getElementsByTagNameNS(wordNamespace, 'outlineLvl')[0]?.getAttributeNS(wordNamespace, 'val')
  if (level !== null && level !== undefined && /^[0-5]$/.test(level)) return Number(level) + 1
  return Number(style?.match(/^(?:heading|标题)\s*([1-6])$/i)?.[1] ?? 0)
}

async function readFile(file) {
  if (!file || typeof file.arrayBuffer !== 'function') throw new Error('请选择需要导入的文件。')
  if (file.size > MAX_IMPORT) throw new Error('文件超过 10 MB，请拆分后导入。')
  if (/\.(txt|md|rst)$/i.test(file.name)) return utf8.decode(await file.arrayBuffer())
  if (!/\.docx$/i.test(file.name)) throw new Error('请选择 UTF-8 TXT 或基础 DOCX 文件。')
  const xml = new DOMParser().parseFromString(await wordXml(await file.arrayBuffer()), 'application/xml')
  const body = xml.getElementsByTagNameNS(wordNamespace, 'body')[0]
  if (!body) throw new Error('未找到 DOCX 正文。')
  const lines = []
  const fences = revisionCodeFences(body)
  for (const element of body.children) {
    if (element.localName === 'p') {
      const level = headingLevel(element)
      const line = plainParagraph(element)
      if (fences.opening.has(element)) lines.push(fences.opening.get(element))
      lines.push(level && line.trim() ? `${'#'.repeat(level)} ${line}` : line)
      if (fences.closing.has(element)) lines.push(fences.closing.get(element))
    }
    if (element.localName === 'tbl') {
      for (const row of Array.from(element.children).filter(child => child.localName === 'tr')) {
        const cells = Array.from(row.children).filter(child => child.localName === 'tc')
        lines.push(cells.map(cell =>
          Array.from(cell.children).filter(child => child.localName === 'p').map(plainParagraph).join('\n'),
        ).join(' │ '))
      }
    }
  }
  return lines.join('\n')
}

function parseBody(body) {
  return typeof body === 'string' ? JSON.parse(body) : body ?? {}
}

function makeDraft({goal, roles, features, constraints, scope, acceptance, nfr, integrations, mode}) {
  if (mode === 'MODEL') throw new Error('完整项目连接模型后可使用 AI 草稿。')
  const objective = typeof goal === 'string' ? goal.trim() : ''
  if (!objective) throw new Error('请输入业务目标。')
  const entries = value => (typeof value === 'string' ? value : '').split(/[\r\n；;]+/).map(line => line.trim()).filter(Boolean)
  const numbered = (values, prefix, placeholder) =>
    (values.length ? values : [placeholder]).map((entry, index) =>
      entryPattern.test(entry) ? entry : `${prefix}-${String(index + 1).padStart(3, '0')}：${entry}`,
    ).join('\n')
  const title = `${objective.replace(/\s+/g, ' ').slice(0, 24)} · 需求草稿`
  const text = [
    '# 软件需求规格说明书 · 草稿', '编写状态：业务负责人待复核', '',
    '## 1. 业务目标与建设范围', objective,
    entries(scope).join('\n') || '[待确认] 本期功能边界、交付范围及依赖项目。', '',
    '## 2. 用户角色与权限', entries(roles).join('\n') || '[待确认] 用户角色与职责范围。', '',
    '## 3. 功能需求', numbered(entries(features), 'FR', '[待确认] 主要功能及触发条件。'), '',
    '## 4. 业务与数据约束', numbered(entries(constraints), 'BR', '[待确认] 适用条件、角色权限及数据状态。'), '',
    '## 5. 数据与外部接口',
    numbered(entries(integrations), 'DR', '[待确认] 数据归属、字段、接口对接、调用失败处理。'), '',
    '## 6. 质量属性与运行约束',
    numbered(entries(nfr), 'NFR', '[待确认] 运行条件、性能度量、失败恢复和权限审计。'), '',
    '## 7. 验收场景与追踪',
    numbered(entries(acceptance), 'AC', '[待确认] 按编号补充适用角色、前置条件、输入和可观察结果。'), '',
    '## 8. 待确认事项',
    '[待确认] 由项目负责人补全角色、接口、异常分支、验收指标及优先级。',
  ].join('\n')
  return {title, text, mode: 'DEMO'}
}

function required(entity, message) {
  if (!entity) throw new Error(message)
  return entity
}

function addMember(workspace, {username, displayName, password}) {
  const account = typeof username === 'string' ? username.trim().toLowerCase() : ''
  const name = typeof displayName === 'string' ? displayName.trim() : ''
  if (!/^[a-z0-9][a-z0-9._-]{2,39}$/.test(account)) {
    throw new Error('账号名须为 3 至 40 个字母、数字、点、下划线或连字符，并以字母或数字开头。')
  }
  if (name.length > 100) throw new Error('显示名称最多支持 100 个字符。')
  if (typeof password !== 'string' || password.length < 12 || password.length > 128 || !password.trim()) {
    throw new Error('请输入 12 至 128 字符的演示密码。密码仅用于输入校验。')
  }
  if (workspace.users.some(user => user.username === account)) throw new Error('此账号名已被使用。')
  const user = {id: uid(), username: account, displayName: name || account, role: 'MEMBER'}
  workspace.users.push(user)
  return user
}

export async function demo(path, {method = 'GET', body} = {}) {
  const {pathname: route, searchParams} = new URL(path, 'http://localhost')
  const workspace = loadState()
  const session = () => ({initialized: true, user: workspace.user, setupTokenRequired: false})
  if (method === 'GET' && route === '/api/session') return structuredClone(session())
  if (method === 'POST' && ['/api/session/setup', '/api/session/login', '/api/session/logout'].includes(route)) {
    workspace.user = route.endsWith('/logout') ? null : demoUser
    saveState()
    return structuredClone(session())
  }
  if (!workspace.user) throw new Error('请先进入交互演示。')
  if (route === '/api/users') {
    if (workspace.user.role !== 'ADMIN') throw new Error('只有管理员可查看演示账号。')
    if (method === 'GET') return structuredClone(workspace.users)
    if (method === 'POST') {
      const user = addMember(workspace, parseBody(body))
      saveState()
      return structuredClone(user)
    }
  }
  const projectFor = projectId => required(
    projectId ? workspace.projects.find(project => project.id === projectId) : workspace.projects[0],
    '未找到项目。',
  )
  if (method === 'GET' && route === '/api/projects') return workspace.projects.map(project => ({ ...project, role: 'OWNER' }))
  if (method === 'GET' && route === '/api/workspace') {
    const project = projectFor(searchParams.get('projectId'))
    const documents = workspace.documents.filter(document => document.projectId === project.id)
    const documentIds = new Set(documents.map(document => document.id))
    const runs = workspace.runs.filter(run => documentIds.has(run.documentId))
    return structuredClone({mode: 'DEMO', projects: workspace.projects.map(row => ({ ...row, role: 'OWNER' })), project: { ...project, role: 'OWNER' }, documents, packs: workspace.packs, runs})
  }
  const inboxRoute = route.match(/^\/api\/projects\/([^/]+)\/issues$/)
  if (method === 'GET' && inboxRoute) {
    const project = projectFor(inboxRoute[1])
    const documents = new Map(workspace.documents.filter(doc => doc.projectId === project.id).map(doc => [doc.id, doc]))
    return workspace.runs.filter(run => documents.has(run.documentId)).flatMap(run => {
      const doc = documents.get(run.documentId)
      return (workspace.issues?.[run.id] || []).map(issue => ({
        ...issue, runId: run.id, title: run.findings.find(item => item.id === issue.findingId)?.title,
        documentTitle: doc.title, versionNumber: doc.versions.find(version => version.id === run.versionId)?.number,
      }))
    })
  }
  const memberRoute = route.match(/^\/api\/projects\/([^/]+)\/members(?:\/([^/]+))?$/)
  if (memberRoute) {
    const project = projectFor(memberRoute[1])
    workspace.members ??= {}
    const demoMembers = [
      { id: 'demo-author', username: 'writer', displayName: '需求作者', role: 'MEMBER' },
      { id: 'demo-reviewer', username: 'qa', displayName: '质量复核人', role: 'MEMBER' },
    ]
    for (const user of demoMembers) {
      if (!workspace.users.some(member => member.id === user.id)) workspace.users.push(user)
    }
    const member = (user, role) => ({userId: user.id, username: user.username, displayName: user.displayName, role})
    const rows = workspace.members[project.id] ??= [
      member(demoUser, 'OWNER'),
      ...(project.id === 'enterprise-itsm' ? [member(demoMembers[0], 'EDITOR'), member(demoMembers[1], 'REVIEWER')] : []),
    ]
    if (method === 'POST' || method === 'PUT') {
      const input = parseBody(body)
      const username = input.username.trim().toLowerCase()
      const role = method === 'POST' ? 'VIEWER' : input.role
      if (!['EDITOR', 'REVIEWER', 'VIEWER'].includes(role)) throw new Error('请选择有效的项目角色。')
      const user = required(workspace.users.find(person => person.username === username), '账户不存在。请先进入账户管理创建。')
      if (user.id === demoUser.id) throw new Error('负责人角色由创建项目时确认。')
      const pos = rows.findIndex(person => person.userId === user.id)
      if (pos < 0) rows.push(member(user, role))
      else if (method === 'PUT') rows[pos] = member(user, role)
    } else if (method === 'DELETE') {
      const pos = rows.findIndex(person => person.userId === memberRoute[2] && person.role !== 'OWNER')
      if (pos < 0) throw new Error('找不到可移除的成员。')
      rows.splice(pos, 1)
    }
    saveState()
    return structuredClone(rows)
  }
  const issueRoute = route.match(/^\/api\/reviews\/([^/]+)\/issues(?:\/([^/]+))?$/)
  if (issueRoute) {
    const run = required(workspace.runs.find(item => item.id === issueRoute[1]), '未找到审查记录。')
    workspace.issues ??= {}
    const rows = workspace.issues[run.id] ??= []
    if (method === 'GET') return structuredClone(rows)
    const finding = required(run.findings.find(item => item.id === issueRoute[2] && item.status === 'ISSUE'), '未找到可跟进的问题。')
    const incoming = parseBody(body)
    const previous = rows.find(item => item.findingId === finding.id)
    const priorStatus = previous?.status || 'OPEN'
    if (!incoming.status || ![priorStatus, ...(transitions[priorStatus] || [])].includes(incoming.status)) throw new Error('当前状态不允许该操作。')
    if (['IN_PROGRESS', 'FIXED', 'VERIFIED'].includes(incoming.status) && finding.decision !== 'CONFIRMED') throw new Error('请先确认疑点。')
    const resolutionVersionId = incoming.status === 'OPEN' && priorStatus !== 'OPEN' ? null
      : 'resolutionVersionId' in incoming ? incoming.resolutionVersionId : previous?.resolutionVersionId || null
    const document = workspace.documents.find(doc => doc.id === run.documentId)
    const reviewVersion = document?.versions.find(version => version.id === run.versionId)
    if (['FIXED', 'VERIFIED'].includes(incoming.status) && !document?.versions.some(version => version.id === resolutionVersionId && version.number > reviewVersion.number)) throw new Error('请选择此文档较新的修订版本。')
    const note = String(incoming.note || '').trim()
    if (['VERIFIED', 'DISMISSED'].includes(incoming.status) && !note) throw new Error('请填写核验依据或关闭原因。')
    const assigneeId = 'assigneeId' in incoming ? incoming.assigneeId : previous?.assigneeId || null
    const assigneeName = workspace.users.find(user => user.id === assigneeId)?.displayName || null
    const dueDate = 'dueDate' in incoming ? incoming.dueDate : previous?.dueDate || null
    const updatedAt = new Date().toISOString()
    const entry = {fromStatus: priorStatus, toStatus: incoming.status, assigneeId, assigneeName, dueDate, resolutionVersionId, note, actorId: demoUser.id, actorName: demoUser.displayName, createdAt: updatedAt}
    const updated = {findingId: finding.id, status: incoming.status, assigneeId, assigneeName, dueDate, resolutionVersionId, note, updatedAt, updatedBy: demoUser.id, history: [...(previous?.history || []), entry]}
    if (previous) rows[rows.indexOf(previous)] = updated
    else rows.push(updated)
    saveState()
    return structuredClone(updated)
  }
  if (method === 'GET' && route === '/api/health') return {status: 'UP', mode: 'DEMO'}
  if (method === 'GET' && route === '/api/model') {
    return {mode: 'DEMO', configured: false, model: '本地样例回放', provider: '交互演示', credentialConfigured: false,
      profiles: [{id: 'PRIMARY', label: '主模型', configured: false}, {id: 'BACKUP', label: '备选模型', configured: false}]}
  }
  if (method === 'POST' && route === '/api/model/test') {
    return {success: false, message: '交互演示使用本地评审样例。真实模型连通性可在完整项目中检测。', elapsedMs: 0}
  }
  if (method === 'POST' && route === '/api/drafts') return makeDraft(parseBody(body))
  let result
  if (method === 'POST' && route === '/api/projects/sample') {
    result = seedEnterprise(workspace)
  } else if (method === 'POST' && route === '/api/projects') {
    const {name, description} = parseBody(body)
    result = makeProject(name, description)
    workspace.projects.unshift(result)
  } else if (method === 'PATCH' && /^\/api\/projects\/[^/]+$/.test(route)) {
    const current = projectFor(route.split('/')[3])
    const {name, description} = parseBody(body)
    result = makeProject(name ?? current.name, description ?? current.description, current.id, current.createdAt)
    result.updatedAt = new Date().toISOString()
    workspace.projects.splice(workspace.projects.indexOf(current), 1, result)
  } else if (method === 'POST' && route === '/api/documents') {
    const {title, text, projectId} = parseBody(body)
    result = makeDocument(title, text)
    result.projectId = projectFor(projectId).id
    workspace.documents.unshift(result)
  } else if (method === 'POST' && route === '/api/documents/import') {
    const file = body?.get?.('file')
    const text = await readFile(file)
    const title = body.get('title') || file.name.replace(/\.(docx|txt|md|rst)$/i, '')
    result = makeDocument(title, text)
    result.projectId = projectFor(body.get('projectId')).id
    workspace.documents.unshift(result)
  } else if (method === 'POST' && /^\/api\/documents\/[^/]+\/versions$/.test(route)) {
    const document = required(workspace.documents.find(item => item.id === route.split('/')[3]), '未找到文档。')
    const revision = parseBody(body)
    if (revision.expectedLatestVersionId && revision.expectedLatestVersionId !== document.versions[0].id) {
      throw Object.assign(new Error('已有更新的文档版本，请先核对最新版，再决定如何保存修订。'), {status: 409})
    }
    const version = makeVersion(revision.text, document.versions[0].number + 1)
    document.versions.unshift(version)
    document.updatedAt = version.createdAt
    result = document
  } else if (method === 'POST' && route === '/api/reviews') {
    const {documentId, versionId, packId, itemIds, mode} = parseBody(body)
    if (mode === 'MODEL') throw new Error('完整项目连接模型后可提交 AI 审查。')
    const document = required(workspace.documents.find(item => item.id === documentId), '未找到文档。')
    const version = required(document.versions.find(item => item.id === versionId), '未找到对应版本。')
    const pack = required(workspace.packs.find(item => item.id === packId), '未找到审查包。')
    result = runReview(document, version, pack, {itemIds})
    workspace.runs.unshift(result)
  } else if (method === 'PATCH' && /^\/api\/reviews\/[^/]+\/findings\/[^/]+$/.test(route)) {
    const [, , , runId, , findingId] = route.split('/')
    const run = required(workspace.runs.find(item => item.id === runId), '未找到审查记录。')
    const finding = required(run.findings.find(item => item.id === findingId), '未找到疑点。')
    const {decision, note} = parseBody(body)
    if (!['PENDING', 'CONFIRMED', 'REJECTED'].includes(decision)) throw new Error('无法识别复核决定。')
    const priorDecision = finding.decision
    const createdAt = new Date().toISOString()
    finding.decision = decision
    finding.note = typeof note === 'string' ? note.trim() : ''
    finding.decidedAt = decision === 'PENDING' ? null : createdAt
    const decisions = workspace.decisions[runId] ??= []
    decisions.push({findingId, priorDecision, newDecision: decision, note: finding.note, createdAt})
    result = run
  } else if (method === 'GET' && /^\/api\/reviews\/[^/]+$/.test(route)) {
    return structuredClone(required(workspace.runs.find(item => item.id === route.split('/')[3]), '未找到审查记录。'))
  } else if (method === 'GET' && /^\/api\/reviews\/[^/]+\/report$/.test(route)) {
    const run = required(workspace.runs.find(item => item.id === route.split('/')[3]), '未找到审查记录。')
    const document = required(workspace.documents.find(item => item.id === run.documentId), '未找到原始文档。')
    const version = required(document.versions.find(item => item.id === run.versionId), '未找到审查版本。')
    const pack = required(workspace.packs.find(item => item.id === run.packId), '未找到审查包。')
    return structuredClone({
      documentTitle: document.title, versionNumber: version.number, packName: pack.name, run,
      decisions: workspace.decisions[run.id] ?? [],
      issues: workspace.issues?.[run.id] ?? [],
    })
  } else {
    throw new Error('本地演示不支持这个操作。')
  }
  saveState()
  return structuredClone(result)
}
