<script setup>
import { computed, ref, watch } from 'vue'
import { CalendarDays, ClipboardCheck, History, UserRound } from 'lucide-vue-next'
import WorkspaceSelect from './WorkspaceSelect.vue'
import { issueStates, transitions } from './workflow.js'

const props = defineProps({
  finding: Object, issue: Object, role: String, members: Array, currentUser: String, busy: Boolean,
  versions: Array, reviewVersion: Number,
})
const emit = defineEmits(['save'])
const form = ref({})
const current = computed(() => props.issue?.status || 'OPEN')
const manage = computed(() => ['OWNER', 'REVIEWER'].includes(props.role))
const canUpdate = computed(() => manage.value || (props.role === 'EDITOR' && props.issue?.assigneeId === props.currentUser))
const laterVersions = computed(() => (props.versions || []).filter(version => version.number > props.reviewVersion))
const allowed = computed(() => [current.value, ...(transitions[current.value] || [])].filter(status =>
  (manage.value || ['OPEN', 'IN_PROGRESS', 'FIXED'].includes(status)) &&
  (props.finding.decision === 'CONFIRMED' || !['IN_PROGRESS', 'FIXED', 'VERIFIED'].includes(status)) &&
  (laterVersions.value.length || !['FIXED', 'VERIFIED'].includes(status))))
const statusOptions = computed(() => allowed.value.map(state => ({ value: state, label: issueStates[state] })))
const assigneeOptions = computed(() => [
  { value: '', label: '未分派' },
  ...(props.members || []).filter(member => member.role !== 'VIEWER').map(member => ({
    value: member.userId, label: member.displayName || member.username,
  })),
])
const revisionOptions = computed(() => [
  { value: '', label: '选择修订版' },
  ...laterVersions.value.map(version => ({ value: version.id, label: 'V' + version.number })),
])
const readTime = value => value ? new Date(value).toLocaleString('zh-CN', { hour12: false }) : ''
const statusStyle = value => value === 'VERIFIED' || value === 'DISMISSED' ? 'success' : value === 'FIXED' ? 'info' : 'amber'
const needsVerificationNote = computed(() => ['VERIFIED', 'DISMISSED'].includes(form.value.status))
const needsRevision = computed(() => ['FIXED', 'VERIFIED'].includes(form.value.status) && !form.value.resolutionVersionId)

watch(() => [props.finding.id, props.issue?.updatedAt], () => {
  form.value = {
    status: current.value,
    assigneeId: props.issue?.assigneeId || '',
    dueDate: props.issue?.dueDate || '',
    resolutionVersionId: props.issue?.resolutionVersionId || '',
    note: '',
  }
}, { immediate: true })

function save() {
  const payload = { status: form.value.status, note: form.value.note.trim() }
  if (manage.value) {
    payload.assigneeId = form.value.assigneeId || null
    payload.dueDate = form.value.dueDate || null
  }
  if (form.value.resolutionVersionId !== (props.issue?.resolutionVersionId || '')) {
    payload.resolutionVersionId = form.value.resolutionVersionId || null
  }
  emit('save', props.finding.id, payload)
}
</script>

<template>
  <section class="issue-workflow">
    <div class="issue-header"><div><ClipboardCheck :size="17" /><strong>问题跟进</strong></div><span class="pill" :class="issue ? statusStyle(current) : 'neutral'">{{ issue ? issueStates[current] : '未分派' }}</span></div>
    <div v-if="issue" class="issue-meta"><span><UserRound :size="14" />{{ issue.assigneeName || '未分派' }}</span><span><CalendarDays :size="14" />{{ issue.dueDate || '未设截止日' }}</span><span v-if="issue.resolutionVersionId">修订版 V{{ versions?.find(version => version.id === issue.resolutionVersionId)?.number || '—' }}</span></div>
    <form v-if="canUpdate && (issue || finding.decision === 'CONFIRMED')" class="issue-form" @submit.prevent="save">
      <div class="form-pair">
        <label>处理状态<WorkspaceSelect v-model="form.status" :options="statusOptions" label="处理状态" /></label>
        <label v-if="manage">处理人<WorkspaceSelect v-model="form.assigneeId" :options="assigneeOptions" label="处理人" /></label>
        <label v-if="manage">截止日期<input v-model="form.dueDate" type="date"></label>
        <label v-if="laterVersions.length && ['FIXED', 'VERIFIED'].includes(form.status)">
          修订版本<WorkspaceSelect v-model="form.resolutionVersionId" :options="revisionOptions" label="修订版本" :disabled="current === 'VERIFIED' && form.status === 'VERIFIED'" />
        </label>
      </div>
      <label>处理说明<textarea v-model="form.note" aria-label="问题处理说明" rows="2" maxlength="2000" :placeholder="needsVerificationNote ? '记录核验依据或关闭原因' : '说明处理计划、改动和复查依据'"></textarea></label>
      <button class="button secondary small" :disabled="busy || needsRevision || (needsVerificationNote && !form.note.trim())">{{ issue ? '保存跟进' : '建立跟进' }}</button>
    </form>
    <p v-else-if="!issue" class="issue-help">{{ finding.decision === 'REJECTED' ? '已驳回，跟进结束。' : '确认问题后，负责人或复核人可分派处理。' }}</p>
    <details v-if="issue?.history?.length" class="issue-history">
      <summary><History :size="15" /> 处理记录</summary>
      <ul><li v-for="(entry, index) in issue.history" :key="entry.id || index"><strong>{{ issueStates[entry.toStatus] || '更新' }} · {{ entry.actorName || '团队成员' }}</strong><small>{{ readTime(entry.createdAt) }}</small><p v-if="entry.note">{{ entry.note }}</p></li></ul>
    </details>
  </section>
</template>
