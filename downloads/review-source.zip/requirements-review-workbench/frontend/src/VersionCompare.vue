<script setup>
import { computed, ref, watch } from 'vue'
import { GitCompareArrows } from 'lucide-vue-next'
import WorkspaceSelect from './WorkspaceSelect.vue'
import { plainFinding } from './problem-language.js'
import { sourceLocation } from './workflow.js'
import { changedPassages } from './version-source-diff.js'
const props = defineProps({ previous: Object, olderVersions: Array, current: Object, previousRun: Object, currentRun: Object })
const emit = defineEmits(['finding', 'select-version'])
const enabled = ref(false)
const display = ref('')
const page = ref(1)
const pageSize = 10
const versionOptions = computed(() => (props.olderVersions || [props.previous]).filter(Boolean)
  .map(version => ({ value: version.id, label: 'V' + version.number })))
watch(() => props.current?.id, () => { enabled.value = false })
watch(() => [props.previous?.id, props.current?.id], () => { display.value = ''; page.value = 1 })

function index(version) {
  const groups = new Map()
  for (const item of version.items || []) {
    if (/^[PL]-\d+$/i.test(item.code)) continue
    const group = groups.get(item.code) || []
    group.push(item.text)
    groups.set(item.code, group)
  }
  return groups
}

function changedText(old, next) {
  const before = Array.from(old)
  const after = Array.from(next)
  const shorter = Math.min(before.length, after.length)
  let first = 0
  while (first < shorter && before[first] === after[first]) first++
  let last = 0
  while (last < shorter - first && before[before.length - 1 - last] === after[after.length - 1 - last]) last++
  return {
    prefix: before.slice(0, first).join(''),
    old: before.slice(first, before.length - last).join(''),
    next: after.slice(first, after.length - last).join(''),
    suffix: last ? before.slice(-last).join('') : '',
  }
}
const changes = computed(() => {
  if (!props.previous || !props.current) return []
  const before = index(props.previous)
  const after = index(props.current)
  return [...new Set([...before.keys(), ...after.keys()])].map(code => {
    const old = before.get(code)
    const next = after.get(code)
    if ((old?.length || 0) > 1 || (next?.length || 0) > 1) return { code, old, next, change: '编号重复' }
    if (old?.[0] === next?.[0]) return null
    const change = !old ? '新增' : !next ? '删除' : '修改'
    return { code, old, next, change, parts: change === '修改' ? changedText(old[0], next[0]) : null }
  }).filter(Boolean)
})
const hasNumbered = computed(() => [props.previous, props.current].some(version =>
  version?.items?.some(item => item.code && !/^[PL]-\d+$/i.test(item.code))))
const textView = computed(() => display.value ? display.value === 'source' : !hasNumbered.value || !changes.value.length)
const passages = computed(() => enabled.value && textView.value
  ? changedPassages(props.previous?.text, props.current?.text) : [])
const pageCount = computed(() => Math.ceil(passages.value.length / pageSize))
const visiblePassages = computed(() => passages.value.slice((page.value - 1) * pageSize, page.value * pageSize)
  .map(row => ({ ...row, parts: row.old.length === 1 && row.next.length === 1
    ? changedText(row.old[0], row.next[0]) : null })))
const actualModels = run => [...new Set((run.modelTrace || []).map(entry => entry.actualModel).filter(Boolean))].sort().join('|')
const compatible = computed(() => props.previousRun && props.currentRun &&
  props.previousRun.packVersion === props.currentRun.packVersion &&
  props.previousRun.model === props.currentRun.model &&
  props.previousRun.modelConfigRevision === props.currentRun.modelConfigRevision &&
  actualModels(props.previousRun) === actualModels(props.currentRun))
const evidenceCodes = finding => [...new Set(finding.evidence.map(e => e.code))].sort()
function matchKey(finding, oldCounts, newCounts) {
  const codes = evidenceCodes(finding)
  if (!codes.length || !codes.every(code => code && !/^[PL]-\d+$/i.test(code)
      && oldCounts.get(code)?.length === 1 && newCounts.get(code)?.length === 1)) return null
  return JSON.stringify([finding.ruleId, codes])
}
const problemChanges = computed(() => {
  if (!compatible.value) return []
  const before = props.previousRun.findings.filter(finding => finding.status === 'ISSUE' && finding.decision !== 'REJECTED')
  const after = props.currentRun.findings.filter(finding => finding.status === 'ISSUE' && finding.decision !== 'REJECTED')
  const byCode = version => {
    const result = new Map()
    for (const item of version.items || []) {
      if (!result.has(item.code)) result.set(item.code, [])
      result.get(item.code).push(item.id)
    }
    return result
  }
  const previousCodes = byCode(props.previous)
  const codes = byCode(props.current)
  const key = finding => matchKey(finding, previousCodes, codes)
  function groups(findings) {
    const result = new Map()
    for (const finding of findings) {
      const id = key(finding)
      if (!id) continue
      if (!result.has(id)) result.set(id, [])
      result.get(id).push(finding)
    }
    return result
  }
  const oldGroups = groups(before), newGroups = groups(after)
  const paired = new Set()
  const covered = new Set(props.currentRun.scope?.coveredItemIds || [])
  const priorCovered = new Set(props.previousRun.scope?.coveredItemIds || [])
  return [
    ...before.map(finding => {
      const id = key(finding)
      const candidates = newGroups.get(id) || []
      const again = oldGroups.get(id)?.length === 1 && candidates.length === 1 && candidates[0]
      if (again) paired.add(again.id)
      const comparable = id && !candidates.length && evidenceCodes(finding).every(code => covered.has(codes.get(code)[0]))
      return { finding: again || finding, run: again ? props.currentRun : props.previousRun,
        state: again ? '本轮仍发现' : comparable ? '本轮未检出 · 待核对' : '原版发现 · 待对照' }
    }),
    ...after.filter(finding => !paired.has(finding.id)).map(finding => {
      const id = key(finding)
      const comparable = id && !oldGroups.has(id) && evidenceCodes(finding).every(code => priorCovered.has(previousCodes.get(code)[0]))
      return { finding, run: props.currentRun, state: comparable ? '本轮新发现' : '本版发现 · 待对照' }
    }),
  ]
})
</script>

<template>
  <section v-if="previous && current" class="panel related-reports">
    <div class="panel-heading">
      <div class="panel-title"><GitCompareArrows :size="18" /><h2>版本对照</h2></div>
      <button class="text-button" @click="enabled = !enabled">{{ enabled ? '收起对照' : '查看 V' + previous.number + ' → V' + current.number }}</button>
    </div>
    <template v-if="enabled">
      <div class="version-compare-toolbar">
        <label>对照版本
          <WorkspaceSelect :model-value="previous.id" :options="versionOptions" label="选择对照版本" @update:model-value="emit('select-version', $event)" />
        </label>
        <div v-if="hasNumbered" class="view-buttons" role="group" aria-label="对照方式">
          <button type="button" :aria-pressed="textView" @click="display = 'source'">原文</button>
          <button type="button" :aria-pressed="!textView" @click="display = 'numbered'">编号条款</button>
        </div>
        <div v-if="!textView" class="version-compare-counts">
          <span v-for="[name, tone] in [['新增','success'],['删除','amber'],['修改','info']]" :key="name" class="pill" :class="tone">{{ name }} {{ changes.filter(row => row.change === name).length }}</span>
        </div>
      </div>
      <template v-if="textView">
        <p v-if="passages.length" class="compare-caption">两版原文有 {{ passages.length }} 处变动</p>
        <div v-for="row in visiblePassages" :key="row.oldLine + '/' + row.nextLine" class="source-passage" data-compare-passage>
          <section v-for="side in ['old','next']" :key="side" :class="side === 'old' ? 'previous-text' : 'current-text'">
            <header><strong>V{{ side === 'old' ? previous.number : current.number }}</strong>
              <small v-if="row[side].length">{{ sourceLocation(side === 'old' ? previous : current, side === 'old' ? row.oldLine : row.nextLine) }}</small></header>
            <p v-if="!row[side].length" class="missing">{{ side === 'old' ? '此处原先没有内容' : '此处内容已删除' }}</p>
            <pre v-else-if="row.parts">{{ row.parts.prefix }}<mark v-if="row.parts[side]" :class="side === 'old' ? 'version-compare-mark-removed' : 'version-compare-mark-added'">{{ row.parts[side] }}</mark>{{ row.parts.suffix }}</pre>
            <pre v-else>{{ row[side].slice(0, 6).join('\n') || '（空行）' }}</pre>
            <details v-if="row[side].length > 6"><summary>展开其余 {{ row[side].length - 6 }} 行</summary><pre>{{ row[side].slice(6).join('\n') }}</pre></details>
          </section>
        </div>
        <div v-if="!passages.length" class="empty compact"><p>两版原文内容相同。</p></div>
        <div v-if="pageCount > 1" class="passage-paging"><button class="text-button" :disabled="page === 1" @click="page--">上一页</button><span>{{ page }} / {{ pageCount }}</span><button class="text-button" :disabled="page >= pageCount" @click="page++">下一页</button></div>
      </template>
      <template v-else><p class="compare-caption">按需求编号对照条款。</p>
      <div v-if="changes.length" class="table-scroll"><table class="compare-table">
        <thead><tr><th>条款</th><th>V{{ previous.number }} 原文</th><th>V{{ current.number }} 原文</th><th>状态</th></tr></thead>
        <tbody>
          <tr v-for="row in changes" :key="row.code">
            <td><strong>{{ row.code }}</strong></td>
            <td><template v-if="row.parts">{{ row.parts.prefix }}<mark v-if="row.parts.old" class="version-compare-mark-removed">{{ row.parts.old }}</mark>{{ row.parts.suffix }}</template><template v-else>{{ row.old?.join('\n') || '—' }}</template></td>
            <td><template v-if="row.parts">{{ row.parts.prefix }}<mark v-if="row.parts.next" class="version-compare-mark-added">{{ row.parts.next }}</mark>{{ row.parts.suffix }}</template><template v-else>{{ row.next?.join('\n') || '—' }}</template></td>
            <td><span class="pill" :class="row.change === '新增' ? 'success' : row.change === '修改' ? 'info' : 'amber'">{{ row.change }}</span></td>
          </tr>
        </tbody>
      </table></div>
      <div v-else class="empty compact"><p>两个版本的编号条款内容相同。</p></div>
      </template>
      <div v-if="previousRun && !compatible" class="compare-caption">两次任务使用的模型或规则版本有变化。可分别打开报告核对各自结果。</div>
      <div v-if="compatible && problemChanges.length" class="problem-compare">
        <h3>复查发现对照</h3>
        <p class="compare-caption">按审核项和原文条款编号，对照两轮语义审查中的问题。</p>
        <div class="table-scroll"><table><thead><tr><th>问题</th><th>证据条款</th><th>本轮对照</th></tr></thead><tbody>
          <tr v-for="(row, index) in problemChanges" :key="row.finding.id + index"><td><button class="text-button compare-link" @click="emit('finding', row.run.id, row.finding.id)">{{ plainFinding(row.finding).title }}</button></td><td>{{ evidenceCodes(row.finding).join('、') }}</td><td><span class="pill" :class="row.state === '本轮仍发现' ? 'amber' : 'info'">{{ row.state }}</span></td></tr>
        </tbody></table></div>
      </div>
    </template>
  </section>
</template>

<style scoped>
.view-buttons,.passage-paging { display:flex; align-items:center; gap:5px; }
.view-buttons button { border:1px solid var(--line); border-radius:5px; background:transparent; color:var(--muted); font:inherit; font-size:12px; padding:5px 10px; cursor:pointer; }
.view-buttons button[aria-pressed=true] { color:var(--primary); background:#edf2e9; border-color:#b6c7bc; }
.source-passage { display:grid; grid-template-columns:minmax(0,1fr) minmax(0,1fr); gap:10px; margin:0 18px 11px; }
.source-passage section { border:1px solid var(--line); border-radius:7px; padding:10px 12px; min-width:0; }
.source-passage header { display:flex; align-items:baseline; gap:8px; margin-bottom:5px; color:var(--primary); }
.source-passage small,.source-passage .missing,.source-passage summary { color:var(--muted); font-size:12px; }
.source-passage pre { margin:0; white-space:pre-wrap; overflow-wrap:anywhere; font:13px/1.65 var(--mono,monospace); color:var(--text); }
.source-passage summary { cursor:pointer; }
.passage-paging { justify-content:center; margin:12px 0; font-size:12px; color:var(--muted); }
@media(max-width:600px) { .source-passage { grid-template-columns:1fr; gap:4px; margin:0 12px 12px; } }
</style>
