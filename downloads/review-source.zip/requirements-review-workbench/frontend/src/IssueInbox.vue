<script setup>
import { computed, ref } from 'vue'
import { ArrowRight, CalendarClock, ChevronRight, ClipboardList, ListChecks, RefreshCw, Search, UserRound } from 'lucide-vue-next'
import { issueStates } from './workflow.js'
import './issue-inbox.css'

const props = defineProps({ records: Array, userId: String, error: String, loading: Boolean })
const emit = defineEmits(['open', 'reload', 'reviews'])
const filter = ref('active')
const query = ref('')
const mine = ref(false)
const labels = [
  ['active', '待处理'], ['FIXED', '待复查'], ['VERIFIED', '已核验'], ['all', '全部'],
]
const unresolved = item => ['OPEN', 'IN_PROGRESS'].includes(item.status)
const count = key => (props.records || []).filter(item => key === 'all' || (key === 'active' ? unresolved(item) : item.status === key)).length
const rows = computed(() => (props.records || []).filter(item => {
  const value = query.value.trim().toLowerCase()
  return (!mine.value || item.assigneeId === props.userId) &&
    (filter.value === 'all' || (filter.value === 'active' ? unresolved(item) : item.status === filter.value)) &&
    (!value || [item.title, item.documentTitle, item.assigneeName].some(field => field?.toLowerCase().includes(value)))
}).sort((a, b) => (a.dueDate || '9999').localeCompare(b.dueDate || '9999')))
const today = new Intl.DateTimeFormat('sv-SE', { timeZone: 'Asia/Shanghai' }).format(new Date())

function resetFilters() {
  filter.value = 'all'
  query.value = ''
  mine.value = false
}
</script>

<template>
  <div class="issue-inbox-page">
    <section class="issue-ledger" aria-labelledby="issue-ledger-title">
      <div class="page-heading issue-ledger-heading">
        <div><h1 id="issue-ledger-title">问题工作台</h1><p>跟踪已登记问题的处理人、修订版本与复查结论。</p></div>
        <button type="button" class="button secondary issue-reload" :disabled="loading" @click="emit('reload')"><RefreshCw :size="15" />刷新清单</button>
      </div>
      <div class="issue-tiles" role="group" aria-label="按处理状态筛选">
        <button v-for="[key, label] in labels" :key="key" type="button" class="issue-tile" :class="{ active: filter === key }" :aria-pressed="filter === key" @click="filter = key">
          <span>{{ label }}</span><strong>{{ count(key) }}</strong>
        </button>
      </div>
    </section>
    <section class="panel inbox-panel" aria-labelledby="issue-list-title">
      <div class="panel-heading inbox-toolbar">
        <div class="panel-title"><ClipboardList :size="18" /><h2 id="issue-list-title">项目跟进清单</h2></div>
        <div class="actions inbox-controls">
          <label class="checkbox-inline"><input v-model="mine" type="checkbox">只看分给我</label>
          <label class="search"><Search :size="15" /><input v-model="query" aria-label="搜索跟进问题" type="search" placeholder="问题、文档或处理人"></label>
        </div>
      </div>
      <div v-if="error" class="form-error" role="alert">{{ error }}</div>
      <div v-if="loading && !rows.length" class="empty issue-inbox-empty" role="status"><ListChecks :size="27" /><p>正在读取项目跟进记录。</p></div>
      <div v-else-if="rows.length" class="table-scroll issue-table-scroll">
        <table class="issue-table" aria-label="项目问题明细" role="table">
          <thead role="rowgroup"><tr role="row"><th scope="col" role="columnheader">问题</th><th scope="col" role="columnheader">文档版本</th><th scope="col" role="columnheader">处理人</th><th scope="col" role="columnheader">截止日期</th><th scope="col" role="columnheader">状态</th><th scope="col" role="columnheader" aria-label="操作"></th></tr></thead>
          <tbody role="rowgroup">
            <tr v-for="item in rows" :key="item.findingId" role="row">
              <td class="issue-title-cell" role="cell"><button class="text-button compare-link" @click="emit('open', item.runId, item.findingId)">{{ item.title }}</button></td>
              <td class="issue-version-cell" role="cell"><span class="issue-cell-label" aria-hidden="true">文档版本</span>{{ item.documentTitle }} · V{{ item.versionNumber }}</td>
              <td class="issue-assignee-cell" role="cell"><span class="issue-cell-label" aria-hidden="true">处理人</span><span class="cell-with-icon"><UserRound :size="14" />{{ item.assigneeName || '未分派' }}</span></td>
              <td class="issue-due-cell" role="cell">
                <span class="issue-cell-label" aria-hidden="true">截止日期</span>
                <span class="cell-with-icon" :class="{ overdue: item.dueDate && item.dueDate < today && unresolved(item) }"><CalendarClock v-if="item.dueDate" :size="14" />{{ item.dueDate || '—' }}</span>
              </td>
              <td class="issue-status-cell" role="cell"><span class="pill" :class="item.status === 'VERIFIED' ? 'success' : 'info'">{{ issueStates[item.status] }}</span></td>
              <td class="issue-open-cell" role="cell"><button class="icon-button" :aria-label="'打开 ' + item.title" @click="emit('open', item.runId, item.findingId)"><ChevronRight :size="16" /></button></td>
            </tr>
          </tbody>
        </table>
      </div>
      <div v-else-if="!error" class="empty issue-inbox-empty">
        <span class="issue-empty-mark"><ListChecks :size="24" /></span>
        <template v-if="records?.length">
          <h2>当前筛选暂无问题</h2><p>可切换状态，或清除搜索和分派条件。</p>
          <button class="button secondary" @click="resetFilters">清除筛选条件</button>
        </template>
        <template v-else>
          <h2>还没有跟进记录</h2><p>在审查详情中确认问题并建立跟进，记录会出现在这里。</p>
          <button class="button secondary" @click="emit('reviews')">查看审查任务 <ArrowRight :size="15" /></button>
        </template>
      </div>
    </section>
  </div>
</template>
