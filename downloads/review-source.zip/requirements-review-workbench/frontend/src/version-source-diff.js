// Align identical lines that occur once in each version. Repeated boilerplate can stay inside a
// changed passage. This keeps time and memory bounded for documents with thousands of lines.
function uniquePositions(lines) {
  const positions = new Map()
  lines.forEach((text, index) => positions.set(text, positions.has(text) ? -1 : index))
  return positions
}

function orderedAnchors(before, after) {
  const oldPositions = uniquePositions(before)
  const newPositions = uniquePositions(after)
  const pairs = []
  const tails = []
  for (const [text, oldIndex] of oldPositions) {
    const nextIndex = newPositions.get(text)
    if (!text.trim() || oldIndex < 0 || nextIndex == null || nextIndex < 0) continue
    let low = 0, high = tails.length
    while (low < high) {
      const middle = Math.floor((low + high) / 2)
      if (pairs[tails[middle]].nextIndex < nextIndex) low = middle + 1
      else high = middle
    }
    pairs.push({ oldIndex, nextIndex, previous: low > 0 ? tails[low - 1] : -1 })
    tails[low] = pairs.length - 1
  }
  const anchors = []
  for (let cursor = tails.at(-1); cursor != null && cursor >= 0; cursor = pairs[cursor].previous) {
    anchors.push(pairs[cursor])
  }
  return anchors.reverse()
}

export function changedPassages(oldText, newText) {
  const split = text => text ? text.split(/\r\n?|\n/) : []
  const before = split(oldText), after = split(newText)
  const anchors = orderedAnchors(before, after)
  anchors.push({ oldIndex: before.length, nextIndex: after.length })
  let oldStart = 0, newStart = 0
  const changes = []
  for (const { oldIndex, nextIndex } of anchors) {
    let oldEnd = oldIndex, newEnd = nextIndex
    while (oldStart < oldEnd && newStart < newEnd && before[oldStart] === after[newStart]) {
      oldStart++
      newStart++
    }
    while (oldStart < oldEnd && newStart < newEnd && before[oldEnd - 1] === after[newEnd - 1]) {
      oldEnd--
      newEnd--
    }
    if (oldEnd > oldStart || newEnd > newStart) {
      changes.push({
        old: before.slice(oldStart, oldEnd), oldLine: oldStart + 1,
        next: after.slice(newStart, newEnd), nextLine: newStart + 1,
        change: oldEnd === oldStart ? '新增' : newEnd === newStart ? '删除' : '修改',
      })
    }
    oldStart = oldIndex + 1
    newStart = nextIndex + 1
  }
  return changes
}
