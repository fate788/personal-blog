<script setup>
import { computed, onBeforeUnmount, ref, watch } from 'vue'
import { ArrowDownToLine, Check, X } from 'lucide-vue-next'
import WorkspaceSelect from './WorkspaceSelect.vue'
import { api, offline } from './api.js'
import { reviewProblems } from './review-findings.js'
import { matchingRepair, revisedBody } from './revision-export.js'
import { sourceLocation } from './workflow.js'
import { downloadWord } from './word.js'

const props = defineProps({ run: Object, version: Object, document: Object, patches: Array, issues: Array, loading: Boolean })
const picked = ref('')
const pickedLine = ref(0)
const typed = ref(new Map())
const confirmed = ref(new Map())
const existing = ref('')
const excluded = ref(new Set())
const downloading = ref(false)
const message = ref('')
const error = ref('')
let active = true
onBeforeUnmount(() => { active = false })
const problems = computed(() => reviewProblems(props.run, props.version).filter(row => !excluded.value.has(row.id)))
const problemOptions = computed(() => problems.value.map(row => ({ value: row.id, label: row.title })))
const problem = computed(() => problems.value.find(row => row.id === picked.value) || problems.value[0])
const lines = computed(() => props.version.text.split(/\r?\n/))
const patch = computed(() => matchingRepair(problem.value, props.patches || [], props.run.ruleWarnings || []))
const evidenceLines = computed(() => [...new Set((problem.value?.evidence || []).map(source => source.line))])
const line = computed(() => evidenceLines.value.includes(pickedLine.value) ? pickedLine.value
  : evidenceLines.value.includes(patch.value?.line) ? patch.value.line : evidenceLines.value[0])
const lineOptions = computed(() => evidenceLines.value.map(value => ({
  value, label: sourceLocation(props.version, value), detail: lines.value[value - 1],
})))
const original = computed(() => lines.value[line.value - 1] || '')
const key = computed(() => problem.value?.id + ':' + line.value)
const known = computed(() => patch.value?.line === line.value && patch.value.expected === original.value ? patch.value : null)
const entry = computed(() => confirmed.value.get(line.value))
const overlap = computed(() => entry.value && entry.value.problemId !== problem.value?.id)
const replacement = computed({
  get: () => typed.value.get(key.value) ?? (overlap.value ? original.value : entry.value?.replacement) ?? known.value?.replacement ?? original.value,
  set(value) { typed.value.set(key.value, value); message.value = ''; error.value = '' },
})
const edits = computed(() => [...confirmed.value.values()].sort((a, b) => a.line - b.line))
const unconfirmedInput = computed(() => typed.value.has(key.value) && replacement.value !== original.value
  && (entry.value?.problemId !== problem.value?.id || replacement.value !== entry.value?.replacement))
const canConfirm = computed(() => !overlap.value && replacement.value.trim() && replacement.value !== original.value
  && entry.value?.replacement !== replacement.value)
const savedVersions = computed(() => props.document.versions.filter(row => row.number > props.version.number))
const associated = computed(() => new Set((props.issues || []).map(issue => issue.resolutionVersionId).filter(Boolean)))
const versionOptions = computed(() => savedVersions.value.map(row => ({
  value: row.id, label: 'V' + row.number + (associated.value.has(row.id) ? ' · 问题跟进已关联' : ''),
})))
const saved = computed(() => savedVersions.value.find(row => row.id === existing.value))

watch(() => props.run, () => {
  const available = new Set(problems.value.map(row => row.id))
  for (const [number, edit] of confirmed.value) if (!available.has(edit.problemId)) confirmed.value.delete(number)
})
function chooseProblem(value) {
  picked.value = value
  pickedLine.value = 0
}
function confirm() {
  if (!canConfirm.value || downloading.value) return
  confirmed.value.set(line.value, { line: line.value, expected: original.value, replacement: replacement.value,
    problemId: problem.value.id, title: problem.value.title })
  typed.value.delete(key.value)
  error.value = ''
  message.value = ''
}
function remove(edit) {
  confirmed.value.delete(edit.line)
  typed.value.delete(edit.problemId + ':' + edit.line)
  message.value = ''
  error.value = ''
}
function saveFile(version, text, suffix, edits = []) {
  downloadWord('V' + version.number + suffix + ' · ' + props.document.title, text, {
    sourceBody: true, documentTitle: props.document.title, version, edits,
    versionLabel: suffix ? '基于 V' + version.number + ' · 修订稿' : 'V' + version.number,
  })
}
async function exportConfirmed() {
  if (!edits.value.length || downloading.value || unconfirmedInput.value) return
  const selected = edits.value.slice()
  const runId = props.run.id
  downloading.value = true
  message.value = ''
  error.value = ''
  try {
    const live = offline ? props.run : await api('/api/reviews/' + encodeURIComponent(runId))
    if (!active || props.run.id !== runId) return
    if (live.id !== runId || live.versionId !== props.version.id || live.documentId !== props.document.id) throw new Error('审查版本已变化，请重新打开这份报告。')
    const available = new Set(reviewProblems(live, props.version).map(item => item.id))
    const stale = selected.filter(edit => !available.has(edit.problemId))
    if (stale.length) {
      stale.forEach(edit => { remove(edit); excluded.value.add(edit.problemId) })
      throw new Error('复核结果已更新，已移除失效的改动。请核对其余内容后再导出。')
    }
    const text = revisedBody(live, props.version, selected)
    saveFile(props.version, text, ' 修订稿', selected)
    message.value = '已开始下载修订稿，已应用 ' + selected.length + ' 处改动。'
  } catch (failure) { if (active) error.value = failure.message || '下载失败，可以重新尝试。' }
  finally { if (active) downloading.value = false }
}
</script>

<template>
  <section class="confirmed-export" aria-label="修订稿下载">
    <template v-if="problems.length">
      <h3 id="confirmed-export-title">导出修订后的文档</h3>
      <p>逐处确认后下载完整正文。修订稿基于 V{{ version.number }}，项目中的版本会保留。</p>
      <p v-if="['DOCX','PDF'].includes(version.source?.format?.toUpperCase())">Word 按导入后可见的正文重新排版。</p>
      <p v-if="loading" role="status">正在核对可直接采用的替换文字…</p>
      <div class="edit-fields">
        <label v-if="problemOptions.length > 1">问题<WorkspaceSelect :model-value="problem?.id" :options="problemOptions" label="选择要修订的问题" :disabled="downloading" @update:model-value="chooseProblem" /></label>
        <strong v-else class="edit-title">{{ problem?.title }}</strong>
        <label v-if="lineOptions.length > 1">修改位置<WorkspaceSelect :model-value="line" :options="lineOptions" label="选择修改位置" :disabled="downloading" @update:model-value="pickedLine = $event" /></label>
        <small v-else-if="line">{{ sourceLocation(version, line) }}</small>
      </div>
      <template v-if="line">
        <p v-if="problem.action" class="edit-suggestion">修改建议 · {{ problem.action }}</p>
        <div class="edit-pair"><div><strong>原文</strong><pre>{{ original }}</pre></div>
          <label>{{ known ? '建议替换为（可编辑）' : '修订后的文字' }}<textarea v-model="replacement" rows="3" aria-label="修订后的文字" :disabled="downloading || !!overlap" spellcheck="false"></textarea></label>
        </div>
        <p v-if="overlap" role="status">这行已有一处已确认的改动。如需调整，请先在下方移除，再确认替换文字。</p>
        <div class="confirm-controls"><button type="button" class="button secondary small" :disabled="!canConfirm || downloading" @click="confirm"><Check :size="15" />确认这处修改</button>
          <span v-if="unconfirmedInput" role="status">这段输入尚未确认</span></div>
      </template>
      <ul v-if="edits.length" class="confirmed-list" aria-label="本次导出的改动">
        <li v-for="edit in edits" :key="edit.line"><details><summary>{{ sourceLocation(version, edit.line) }} · {{ edit.title }}</summary><p>原文</p><pre>{{ edit.expected }}</pre><p>修订后</p><pre>{{ edit.replacement }}</pre></details>
          <button type="button" class="text-button" :disabled="downloading" :aria-label="'移除' + sourceLocation(version, edit.line) + '的改动'" @click="remove(edit)"><X :size="14" />移除</button></li>
      </ul>
      <div class="download-action"><span>已确认 {{ edits.length }} 处改动</span><button type="button" class="button primary small" data-download-revision :disabled="!edits.length || downloading || unconfirmedInput" @click="exportConfirmed"><ArrowDownToLine :size="16" />{{ downloading ? '正在核对…' : '下载修订稿 Word' }}</button></div>
    </template>
    <p v-if="error" class="export-error" role="alert">{{ error }}</p><p v-if="message" role="status">{{ message }}</p>
    <details v-if="savedVersions.length" class="other-versions" :open="!problems.length"><summary>下载项目中的后续版本</summary>
      <p>当前审查基于 V{{ version.number }}。选择已保存的版本，可以直接下载该版本的完整正文。</p>
      <div class="saved-actions"><WorkspaceSelect v-model="existing" :options="versionOptions" label="选择已保存的版本" placeholder="选择版本" /><button type="button" class="button secondary small" :disabled="!saved" @click="saveFile(saved, saved.text, '')"><ArrowDownToLine :size="16" />下载所选版本 Word</button></div>
    </details>
  </section>
</template>

<style scoped>
.confirmed-export { min-width: 0; }
.confirmed-export h3 { font-size: 15px; }
.confirmed-export p, .confirmed-export small, .download-action > span, .confirm-controls > span { color: var(--muted); font-size: 13px; line-height: 1.6; }
.confirmed-export p { margin: 6px 0; }
.edit-fields, .saved-actions { display: flex; align-items: end; flex-wrap: wrap; gap: 10px 16px; margin: 12px 0; }
.edit-fields label { min-width: 0; flex: 1 1 220px; }
.edit-title { align-self: center; font-size: 14px; }
.edit-pair { display: grid; grid-template-columns: repeat(2, minmax(0,1fr)); gap: 12px; margin: 10px 0; }
.edit-pair > * { min-width: 0; border: 1px solid var(--line); border-radius: 8px; padding: 10px; }
.edit-pair strong, .edit-pair label, .edit-fields label { font-size: 13px; }
.edit-pair pre, .confirmed-list pre { margin: 6px 0 0; white-space: pre-wrap; overflow-wrap: anywhere; font: inherit; line-height: 1.6; }
.edit-pair textarea { display: block; width: 100%; min-height: 64px; margin-top: 6px; padding: 7px; resize: vertical; font: inherit; line-height: 1.6; }
.confirm-controls, .download-action, .confirmed-list li { display: flex; align-items: center; flex-wrap: wrap; gap: 8px 12px; }
.download-action, .confirmed-list li { justify-content: space-between; }
.download-action, .other-versions { margin-top: 14px; }
.confirmed-list { list-style: none; padding: 0; margin: 12px 0; }
.confirmed-list li { padding: 8px 0; border-bottom: 1px solid var(--line); }
.confirmed-list details { flex: 1 1 180px; min-width: 0; font-size: 13px; }
.confirmed-export summary { cursor: pointer; }
.other-versions { border-top: 1px solid var(--line); padding-top: 12px; font-size: 13px; }
.other-versions summary { color: var(--primary); }
.confirmed-export .export-error { color: #9c3929; }
@media (max-width: 660px) { .edit-pair { grid-template-columns: minmax(0,1fr); } }
</style>
