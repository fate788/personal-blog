<script setup>
import { computed, ref } from 'vue'
import { Activity, ArrowDownToLine, BarChart3, Bot, FileCheck2 } from 'lucide-vue-next'
import WorkspaceSelect from './WorkspaceSelect.vue'
import { terminal } from './workflow.js'
const props = defineProps({ runs: Array, projectName: String })
const period = ref('30')
const periodOptions = [{ value: '30', label: '最近 30 天' }, { value: 'all', label: '全部时间' }]
const sevDate = new Intl.DateTimeFormat('zh-CN', { timeZone: 'Asia/Shanghai', year: 'numeric', month: '2-digit', day: '2-digit' })
const data = computed(() => (props.runs || []).filter(r => terminal(r) &&
  (period.value === 'all' || Date.parse(r.createdAt) >= Date.now() - Number(period.value) * 86400000)))
const models = computed(() => data.value.filter(r => r.mode === 'MODEL'))
const usage = (run, key) => run.usage?.[key] ?? null
const tally = key => models.value.reduce((total, run) => total + (usage(run, key) || 0), 0)
const metrics = computed(() => [
  { name: '审查任务', value: data.value.length, icon: FileCheck2, tone: 'blue' },
  { name: '模型调用', value: tally('calls'), icon: Bot, tone: 'teal' },
  { name: '已记录输入 token', value: tally('inputTokens').toLocaleString('zh-CN'), icon: Activity, tone: 'blue' },
  { name: '已记录输出 token', value: tally('outputTokens').toLocaleString('zh-CN'), icon: BarChart3, tone: 'gold' },
])
function exportCsv() {
  const cell = v => {
    const text = String(v ?? '')
    return '"' + (/^[=+\-@\t\r]/.test(text) ? "'" : '') + text.replace(/"/g, '""') + '"'
  }
  const lines = [['时间', '执行方式', '模型配置', '模型', '状态', '调用次数', '输入 token', '输出 token', '缓存输入 token', '推理 token', '用量完整'],
    ...data.value.map(run => [run.createdAt, run.mode, run.profile, run.model, run.status, usage(run, 'calls'),
      usage(run, 'inputTokens'), usage(run, 'outputTokens'), usage(run, 'cachedInputTokens'), usage(run, 'reasoningTokens'), usage(run, 'complete')])]
  const url = URL.createObjectURL(new Blob(['\uFEFF', lines.map(row => row.map(cell).join(',')).join('\r\n')], { type: 'text/csv;charset=utf-8' }))
  const link = document.createElement('a')
  link.href = url
  link.download = '项目审查用量.csv'
  link.click()
  setTimeout(() => URL.revokeObjectURL(url), 3000)
}
</script>

<template>
  <div class="page-heading"><div><h1>项目用量</h1><p>{{ projectName }} · 审查任务和模型返回的计量记录。</p></div><div class="actions"><WorkspaceSelect v-model="period" :options="periodOptions" label="用量时间范围" style="--select-width: 9rem" /><button class="button secondary" :disabled="!data.length" @click="exportCsv"><ArrowDownToLine :size="16" /> 导出用量</button></div></div>
  <div class="metrics"><div v-for="metric in metrics" :key="metric.name" class="metric"><span class="metric-icon" :class="metric.tone"><component :is="metric.icon" :size="20" /></span><span class="metric-copy"><strong>{{ metric.value }}</strong><small>{{ metric.name }}</small></span></div></div>
  <section class="panel"><div class="panel-heading"><div class="panel-title"><BarChart3 :size="19" /><h2>任务用量明细</h2></div></div>
    <div v-if="data.length" class="table-scroll"><table><thead><tr><th>日期</th><th>模型或模式</th><th>调用次数</th><th>输入 token</th><th>输出 token</th><th>执行状态</th></tr></thead><tbody>
      <tr v-for="run in data" :key="run.id"><td>{{ sevDate.format(new Date(run.createdAt)) }}</td><td>{{ run.mode === 'MODEL' ? run.model : '演示审查' }}</td><td>{{ usage(run, 'calls') ?? '—' }}</td><td>{{ usage(run, 'inputTokens') ?? '—' }}</td><td>{{ usage(run, 'outputTokens') ?? '—' }}</td><td>{{ ({COMPLETED:'已完成',PARTIAL:'部分完成',FAILED:'失败'})[run.status] || run.status }}</td></tr>
    </tbody></table></div>
    <div v-else class="empty"><Activity :size="29" /><p>此时间范围内还没有完成的任务。</p></div>
  </section>
  <p class="usage-footnote">用量按审查任务统计。供应商未返回的数据以「—」显示，费用以供应商账单为准。</p>
</template>
