<script setup>
import { computed, onBeforeUnmount, ref, watch } from 'vue'
import { ArrowUpRight, Check, ChevronLeft, ChevronRight, CircleAlert, ClipboardList, Download, FileText, History, RotateCcw, Search, Upload } from 'lucide-vue-next'
import WorkspaceSelect from './WorkspaceSelect.vue'
import { api } from './api.js'
import { sourceLocation } from './workflow.js'

const props = defineProps({ documentId: String, version: Object, canImport: Boolean, requirements: Array })
const emit = defineEmits(['source', 'update'])

const CASE = 'CASE'
const SUMMARY = 'REQUIREMENT_SUMMARY'
const scopeOptions = [
  { value: CASE, label: '逐用例执行结果' },
  { value: SUMMARY, label: '需求级结果汇总' },
]
const categories = [
  { key: CASE, label: '用例结果', hint: '逐条显示同一需求和用例在该版本的有效执行记录。' },
  { key: SUMMARY, label: '需求级汇总', hint: '保留报告对整条需求给出的状态及关联用例。用例的单独结果在「用例结果」中查看。' },
]
const states = {
  PASS: { label: '通过', tone: 'passed' },
  FAIL: { label: '失败', tone: 'failed' },
  SKIPPED: { label: '跳过', tone: 'skipped' },
  NOT_RUN: { label: '未执行', tone: 'not-run' },
}
const statuses = Object.keys(states)
const reviewPriority = { FAIL: 0, SKIPPED: 1, NOT_RUN: 2, PASS: 3 }
const identifiers = new Intl.Collator('zh-CN', { numeric: true, sensitivity: 'base' })
const headers = 'requirement_id,case_id,status,executed_at,evidence,case_ids'
const pageSize = 20
const stamp = new Intl.DateTimeFormat('zh-CN', {
  year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', hourCycle: 'h23',
  timeZone: 'Asia/Shanghai',
})

const snapshot = ref(null)
const loading = ref(false)
const loadError = ref('')
const scope = ref(CASE)
const statusFilter = ref('')
const query = ref('')
const page = ref(1)
const showForm = ref(false)
const importing = ref(false)
const file = ref(null)
const importScope = ref(CASE)
const source = ref('')
const observedAt = ref('')
const note = ref('')
const importError = ref('')
const batchEvidence = ref({})
let readSequence = 0
let writeSequence = 0
let viewSequence = 0

const endpoint = computed(() => props.documentId && props.version?.id
  ? '/api/documents/' + encodeURIComponent(props.documentId) + '/versions/' + encodeURIComponent(props.version.id) + '/executions'
  : '')
const rows = computed(() => snapshot.value?.rows || [])
const batches = computed(() => snapshot.value?.batches || [])
const batchIndex = computed(() => new Map(batches.value.map(batch => [batch.id, batch])))
const tabs = computed(() => categories.map(category => ({
  ...category, total: rows.value.filter(row => row.scope === category.key).length,
})))
const activeTab = computed(() => tabs.value.find(category => category.key === scope.value))
const activeRows = computed(() => rows.value.filter(row => row.scope === scope.value))
const activeCounts = computed(() => scope.value === SUMMARY ? snapshot.value?.summaryCounts : snapshot.value?.counts)
const matchedRows = computed(() => {
  const keyword = query.value.trim().toLowerCase()
  return activeRows.value.filter(row => (!statusFilter.value || row.status === statusFilter.value) &&
    (!keyword || [row.requirementId, row.caseId, relatedCases(row), row.evidence, sourceName(row)]
      .some(value => String(value ?? '').toLowerCase().includes(keyword))))
    .sort((left, right) => reviewPriority[left.status] - reviewPriority[right.status]
      || identifiers.compare(left.requirementId, right.requirementId)
      || identifiers.compare(left.caseId || '', right.caseId || ''))
})
const pageCount = computed(() => Math.max(1, Math.ceil(matchedRows.value.length / pageSize)))
const pageRows = computed(() => matchedRows.value.slice((page.value - 1) * pageSize, page.value * pageSize))
const sourceItems = computed(() => {
  const items = new Map()
  for (const item of props.requirements || props.version?.items || []) {
    const code = identifier(item.code)
    if (code) items.set(code, items.has(code) ? null : item)
  }
  return items
})

watch(endpoint, () => {
  ++viewSequence
  ++readSequence
  ++writeSequence
  snapshot.value = null
  loading.value = false
  loadError.value = ''
  importing.value = false
  showForm.value = false
  file.value = null
  source.value = ''
  observedAt.value = ''
  note.value = ''
  importError.value = ''
  batchEvidence.value = {}
  scope.value = CASE
  importScope.value = CASE
  statusFilter.value = ''
  query.value = ''
  emit('update', null)
  if (endpoint.value) refresh({ chooseScope: true })
}, { immediate: true })
watch([scope, statusFilter, query, snapshot], () => { page.value = 1 })
onBeforeUnmount(() => {
  ++viewSequence
  ++readSequence
  ++writeSequence
})

function applySnapshot(result, chooseScope) {
  if (result.documentId !== props.documentId || result.versionId !== props.version?.id) {
    throw new Error('版本已变化，请刷新后重试。')
  }
  snapshot.value = result
  if (chooseScope && !rows.value.some(row => row.scope === CASE) && rows.value.some(row => row.scope === SUMMARY)) {
    scope.value = SUMMARY
  }
  emit('update', result)
}

async function refresh({ chooseScope = false } = {}) {
  if (!endpoint.value || importing.value) return
  const sequence = ++readSequence
  const path = endpoint.value
  loading.value = true
  loadError.value = ''
  try {
    const result = await api(path)
    if (sequence === readSequence && path === endpoint.value) applySnapshot(result, chooseScope)
  } catch (error) {
    if (sequence === readSequence) loadError.value = error.message || '暂未获取执行记录。'
  } finally {
    if (sequence === readSequence) loading.value = false
  }
}

function toggleForm() {
  showForm.value = !showForm.value
  if (!showForm.value) {
    file.value = null
    importError.value = ''
    return
  }
  importScope.value = scope.value
  note.value = ''
}

function selectFile(event) {
  file.value = event.target.files?.[0] || null
  importError.value = ''
}

async function importReport() {
  if (!props.canImport || !file.value || !endpoint.value || importing.value) return
  const sequence = ++writeSequence
  const path = endpoint.value
  const selectedScope = importScope.value
  const body = new FormData()
  body.set('file', file.value)
  body.set('scope', selectedScope)
  if (source.value.trim()) body.set('source', source.value.trim())
  if (observedAt.value.trim()) body.set('observedAt', observedAt.value.trim())
  importing.value = true
  importError.value = ''
  loadError.value = ''
  note.value = ''
  ++readSequence
  loading.value = false
  try {
    const result = await api(path, { method: 'POST', body })
    if (sequence !== writeSequence || path !== endpoint.value) return
    applySnapshot(result, false)
    chooseTab(selectedScope)
    showForm.value = false
    file.value = null
    source.value = ''
    observedAt.value = ''
    note.value = '执行记录已导入 V' + props.version.number + '。'
  } catch (error) {
    if (sequence === writeSequence) importError.value = error.message || '导入暂未完成，请核对报告。'
  } finally {
    if (sequence === writeSequence) importing.value = false
  }
}

function chooseTab(key) {
  scope.value = key
  statusFilter.value = ''
  query.value = ''
  page.value = 1
}

function identifier(value) {
  return String(value ?? '').trim().toUpperCase()
}

function locatedSource(row) {
  const item = sourceItems.value.get(identifier(row.requirementId))
  return item && Number.isInteger(item.line) && item.line > 0 ? item : null
}

function jump(row) {
  const item = locatedSource(row)
  if (item) emit('source', item.line)
}

function relatedCases(row) {
  if (Array.isArray(row.relatedCaseIds)) return row.relatedCaseIds.join('、')
  return String(row.relatedCaseIds ?? '')
}

function sourceName(row) {
  const batch = batchIndex.value.get(row.batchId)
  return batch?.source || batch?.fileName || ''
}

function presentDate(value) {
  if (!value) return ''
  const date = new Date(value)
  return Number.isFinite(date.getTime()) ? stamp.format(date) : ''
}

function safeLink(value) {
  if (typeof value !== 'string' || !/^https?:\/\/[^\s]+$/i.test(value)) return ''
  try {
    const url = new URL(value)
    return !url.username && !url.password ? url.href : ''
  } catch {
    return ''
  }
}

function evidenceParts(value) {
  const url = safeLink(value)
  if (url) return { url, note: '' }
  const withCitation = /^(.*?)\s+[—–]\s+(https?:\/\/[^\s]+)$/is.exec(value || '')
  const cited = withCitation ? safeLink(withCitation[2]) : ''
  return { url: cited, note: cited ? withCitation[1] : value }
}

async function loadBatch(batchId, event) {
  if (event && !event.target.open) return
  const previous = batchEvidence.value[batchId]
  if (!endpoint.value || previous?.loading || previous?.rows) return
  const path = endpoint.value
  const sequence = viewSequence
  batchEvidence.value[batchId] = { loading: true }
  try {
    const detail = await api(path + '/batches/' + encodeURIComponent(batchId))
    if (sequence !== viewSequence || path !== endpoint.value) return
    if (detail.batch.id !== batchId) throw new Error('报告批次已变化，请重新加载。')
    batchEvidence.value[batchId] = { rows: detail.rows, visible: pageSize }
  } catch (error) {
    if (sequence === viewSequence && path === endpoint.value) {
      batchEvidence.value[batchId] = { error: error.message || '暂未获取本批记录。' }
    }
  }
}

function downloadTemplate() {
  const encoded = new Blob(['\uFEFF', headers + '\r\n'], { type: 'text/csv;charset=utf-8' })
  const url = URL.createObjectURL(encoded)
  const link = document.createElement('a')
  link.download = '执行记录导入模板.csv'
  link.href = url
  link.click()
  window.setTimeout(() => URL.revokeObjectURL(url), 1500)
}
</script>

<template>
  <section v-if="endpoint" class="panel execution-evidence" :aria-busy="loading || importing" aria-labelledby="execution-evidence-heading">
    <header class="panel-heading execution-header">
      <div>
        <div class="execution-title"><ClipboardList :size="19" aria-hidden="true" /><h2 id="execution-evidence-heading">测试执行记录</h2></div>
        <p>查看导入到 V{{ version.number }} 的执行结果与报告来源。</p>
      </div>
      <div class="execution-actions">
        <button type="button" class="icon-button execution-refresh" aria-label="刷新执行记录" title="刷新执行记录"
          :disabled="loading || importing" @click="refresh()"><RotateCcw :size="16" aria-hidden="true" /></button>
        <button v-if="canImport" type="button" class="button primary small" :aria-expanded="showForm" aria-controls="execution-import-form"
          :disabled="importing" @click="toggleForm"><Upload :size="16" aria-hidden="true" />{{ showForm ? '收起导入' : '导入 CSV' }}</button>
      </div>
    </header>

    <form v-if="showForm && canImport" id="execution-import-form" class="execution-form" @submit.prevent="importReport">
      <div class="execution-fields">
        <label>记录类型
          <WorkspaceSelect v-model="importScope" :options="scopeOptions" label="记录类型" :disabled="importing" />
        </label>
        <label>CSV 文件
          <input type="file" accept=".csv,text/csv" :disabled="importing" required @change="selectFile">
        </label>
        <label><span>来源说明 <small>选填</small></span>
          <input v-model="source" maxlength="500" placeholder="报告网址或名称" :disabled="importing">
        </label>
        <label><span>报告时间 <small>选填</small></span>
          <input v-model="observedAt" maxlength="40" placeholder="RFC 3339，含时区" :disabled="importing">
        </label>
      </div>
      <details class="execution-format">
        <summary>CSV 字段说明</summary>
        <p><code>requirement_id</code> 对应需求编号。<code>status</code> 取 PASS、FAIL、SKIPPED 或 NOT_RUN。</p>
        <p>逐用例执行记录填写 <code>case_id</code>。需求级汇总将该列留空，可在 <code>case_ids</code> 列保留报告列出的用例编号。</p>
        <p>可同时提供 <code>executed_at</code> 执行时间和 <code>evidence</code> 原始证据。</p>
      </details>
      <div class="execution-form-actions">
        <button type="button" class="text-button" @click="downloadTemplate"><Download :size="15" aria-hidden="true" />下载空白模板</button>
        <button type="submit" class="button primary small" :disabled="!file || importing">{{ importing ? '正在导入…' : '导入到 V' + version.number }}</button>
      </div>
      <p v-if="importError" class="execution-alert" role="alert"><CircleAlert :size="16" aria-hidden="true" />{{ importError }}</p>
    </form>
    <p v-if="note" class="execution-success" role="status"><Check :size="16" aria-hidden="true" />{{ note }}</p>
    <p v-if="loadError" class="execution-alert execution-load-state" role="alert">
      <CircleAlert :size="17" aria-hidden="true" />{{ loadError }}<button type="button" class="text-button" @click="refresh()">重试</button>
    </p>
    <p v-else-if="loading && !snapshot" class="execution-load-state" role="status">正在读取执行记录…</p>

    <template v-if="snapshot">
      <div class="execution-scope">
        <div class="execution-tabs" role="group" aria-label="执行记录类型">
          <button v-for="tab in tabs" :key="tab.key" type="button" :aria-pressed="scope === tab.key" @click="chooseTab(tab.key)">
            {{ tab.label }} <span>{{ tab.total }}</span>
          </button>
        </div>
        <p>{{ activeTab?.hint }}</p>
      </div>

      <template v-if="activeRows.length">
        <div class="execution-stats" role="group" aria-label="按执行状态筛选">
          <button v-for="status in statuses" :key="status" type="button" :class="states[status].tone"
            :aria-pressed="statusFilter === status" @click="statusFilter = statusFilter === status ? '' : status">
            <span>{{ states[status].label }}</span><strong>{{ activeCounts?.[status] ?? 0 }}</strong>
          </button>
        </div>
        <div class="execution-list-controls">
          <label class="execution-search"><Search :size="16" aria-hidden="true" />
            <input v-model="query" type="search" placeholder="搜索需求、用例或报告来源" aria-label="搜索执行记录">
          </label>
          <button v-if="statusFilter || query" type="button" class="text-button" @click="statusFilter = ''; query = ''">清除筛选</button>
          <span>{{ matchedRows.length }} 条记录</span>
        </div>
        <ul v-if="pageRows.length" class="execution-list">
          <li v-for="row in pageRows" :key="JSON.stringify([row.scope, row.requirementId, row.caseId])" class="execution-row">
            <div class="execution-requirement">
              <div>
                <button v-if="locatedSource(row)" type="button" class="text-button execution-source-link" @click="jump(row)"
                  :title="sourceLocation(version, locatedSource(row).line)">
                  {{ row.requirementId }}<ArrowUpRight :size="13" aria-hidden="true" />
                </button>
                <strong v-else>{{ row.requirementId }}</strong>
                <span class="execution-status" :class="states[row.status]?.tone">{{ states[row.status]?.label || row.status }}</span>
              </div>
              <p v-if="row.caseId" class="execution-case">{{ row.caseId }}</p>
              <p v-else-if="relatedCases(row)" class="execution-case">关联用例 {{ relatedCases(row) }}</p>
            </div>
            <div class="execution-origin">
              <p v-if="sourceName(row)">
                <a v-if="safeLink(sourceName(row))" :href="safeLink(sourceName(row))" target="_blank" rel="noopener noreferrer">
                  {{ batchIndex.get(row.batchId)?.fileName || '打开原报告' }}<ArrowUpRight :size="13" aria-hidden="true" />
                </a>
                <span v-else>{{ sourceName(row) }}</span>
              </p>
              <small>{{ presentDate(row.executedAt) || '未提供执行时间' }}</small>
            </div>
            <p v-if="row.evidence" class="execution-proof">
              <template v-for="proof in [evidenceParts(row.evidence)]">
                <span v-if="proof.note">{{ proof.note }}</span>
                <a v-if="proof.url" :href="proof.url" target="_blank" rel="noopener noreferrer">
                  查看原文证据<ArrowUpRight :size="13" aria-hidden="true" />
                </a>
              </template>
            </p>
          </li>
        </ul>
        <p v-else class="execution-load-state" role="status">当前筛选下没有执行记录。</p>
        <nav v-if="pageCount > 1" class="execution-pagination" aria-label="执行记录分页">
          <span>{{ (page - 1) * pageSize + 1 }}–{{ Math.min(page * pageSize, matchedRows.length) }} / {{ matchedRows.length }}</span>
          <button type="button" class="icon-button" aria-label="上一页" :disabled="page <= 1" @click="page--"><ChevronLeft :size="17" aria-hidden="true" /></button>
          <button type="button" class="icon-button" aria-label="下一页" :disabled="page >= pageCount" @click="page++"><ChevronRight :size="17" aria-hidden="true" /></button>
        </nav>
      </template>
      <div v-else class="execution-empty">
        <FileText :size="20" aria-hidden="true" />
        <div><strong>当前版本暂无{{ activeTab?.label }}</strong>
          <p>实际执行状态未知。导入对应报告后即可查看。</p></div>
      </div>

      <details v-if="batches.length" class="execution-history">
        <summary><History :size="16" aria-hidden="true" /> 导入历史 <span>{{ batches.length }} 批</span></summary>
        <ul>
          <li v-for="batch in batches" :key="batch.id">
            <strong>{{ batch.fileName }}</strong>
            <p>{{ categories.find(item => item.key === batch.scope)?.label || batch.scope }} · {{ batch.rowCount }} 条记录</p>
            <p v-if="batch.source">
              <a v-if="safeLink(batch.source)" :href="safeLink(batch.source)" target="_blank" rel="noopener noreferrer">查看报告来源<ArrowUpRight :size="13" aria-hidden="true" /></a>
              <span v-else>{{ batch.source }}</span>
            </p>
            <p v-if="batch.observedAt">报告时间 {{ presentDate(batch.observedAt) }}</p>
            <p v-if="batch.importedAt">导入于 {{ presentDate(batch.importedAt) }}<template v-if="batch.importedBy"> · {{ batch.importedBy }}</template></p>
            <details class="execution-original-rows" @toggle="loadBatch(batch.id, $event)">
              <summary>查看本批原始结果</summary>
              <p v-if="batchEvidence[batch.id]?.loading" role="status">正在读取本批记录…</p>
              <p v-else-if="batchEvidence[batch.id]?.error" role="alert">
                {{ batchEvidence[batch.id].error }}<button class="text-button" type="button" @click="loadBatch(batch.id)">重试</button>
              </p>
              <template v-else-if="batchEvidence[batch.id]?.rows">
                <ul>
                  <li v-for="row in batchEvidence[batch.id].rows.slice(0, batchEvidence[batch.id].visible)" :key="JSON.stringify([row.requirementId, row.caseId])">
                    <span class="execution-status" :class="states[row.status]?.tone">{{ states[row.status]?.label || row.status }}</span>
                    <strong>{{ row.requirementId }}</strong>
                    <span v-if="row.caseId || relatedCases(row)">{{ row.caseId || relatedCases(row) }}</span>
                    <small v-if="row.executedAt">{{ presentDate(row.executedAt) }}</small>
                    <p v-if="row.evidence" class="execution-original-proof">
                      <template v-for="proof in [evidenceParts(row.evidence)]">
                        <span v-if="proof.note">{{ proof.note }}</span>
                        <a v-if="proof.url" :href="proof.url" target="_blank" rel="noopener noreferrer">
                          查看原文证据<ArrowUpRight :size="13" aria-hidden="true" />
                        </a>
                      </template>
                    </p>
                  </li>
                </ul>
                <button v-if="batchEvidence[batch.id].visible < batchEvidence[batch.id].rows.length"
                  class="text-button" type="button" @click="batchEvidence[batch.id].visible += pageSize">加载更多</button>
              </template>
            </details>
            <details v-if="batch.sha256"><summary>文件指纹 SHA-256</summary><code>{{ batch.sha256 }}</code></details>
          </li>
        </ul>
      </details>
    </template>
  </section>
</template>

<style scoped>
.execution-evidence { min-width: 0; }
.execution-header { align-items: flex-start; gap: 12px; }
.execution-title, .execution-actions { display: flex; align-items: center; gap: 8px; }
.execution-title { color: var(--text); }
.execution-title > svg { color: var(--primary); flex: none; }
.execution-title h2 { margin: 0; font-size: 16px; line-height: 1.45; }
.execution-header p, .execution-scope p { margin: 5px 0 0; font-size: 12px; color: var(--muted); line-height: 1.6; }
.execution-refresh { height: 34px; width: 34px; border: 1px solid var(--line); }
.execution-form { display: grid; gap: 11px; padding: 14px 18px; border-bottom: 1px solid var(--line); background: #fbfcfe; }
.execution-fields { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 11px; }
.execution-fields label { display: grid; min-width: 0; gap: 6px; font-size: 12px; color: var(--muted); font-weight: 650; }
.execution-fields small { display: inline; font-size: 11px; font-weight: 500; }
.execution-fields :is(input, .workspace-select) { width: 100%; min-width: 0; min-height: 38px; font-size: 13px; color: var(--text); }
.execution-fields input[type="file"] { padding: 7px; border-radius: 7px; border: 1px solid var(--line); background: white; }
.execution-format { font-size: 12px; color: var(--muted); line-height: 1.6; }
.execution-format summary { width: fit-content; color: var(--primary); cursor: pointer; }
.execution-format p { margin: 5px 0 0; }
.execution-format code { overflow-wrap: anywhere; }
.execution-form-actions, .execution-pagination { display: flex; flex-wrap: wrap; justify-content: space-between; align-items: center; gap: 8px; }
.execution-alert, .execution-success, .execution-load-state { display: flex; align-items: flex-start; flex-wrap: wrap; gap: 8px; font-size: 13px; line-height: 1.6; margin: 0; overflow-wrap: anywhere; }
.execution-alert { color: #922f41; }
.execution-success, .execution-load-state { padding: 12px 18px; }
.execution-success { color: #256548; background: #f0f8f3; }
.execution-load-state { color: var(--muted); }
.execution-load-state.execution-alert { color: #922f41; }
.execution-scope { padding: 12px 18px; border-bottom: 1px solid var(--line); }
.execution-tabs { display: flex; flex-wrap: wrap; gap: 5px; }
.execution-tabs button { min-height: 33px; border: 1px solid transparent; border-radius: 6px; padding: 5px 9px; font-size: 13px; font-weight: 650; color: var(--muted); background: transparent; }
.execution-tabs button[aria-pressed="true"] { color: var(--primary); background: var(--soft); border-color: var(--line); }
.execution-tabs button:hover { background: #f1f5fa; }
.execution-tabs span { margin-inline-start: 4px; font-variant-numeric: tabular-nums; }
.execution-stats { display: grid; grid-template-columns: repeat(4, minmax(0, 1fr)); gap: 7px; padding: 11px 18px; border-bottom: 1px solid var(--line); }
.execution-stats button { display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; min-height: 43px; min-width: 0; gap: 5px; padding: 6px 9px; border: 1px solid var(--line); border-radius: 6px; font-size: 12px; }
.execution-stats button[aria-pressed="true"] { border-color: currentColor; box-shadow: 0 0 0 1px currentColor inset; }
.execution-stats strong { font-size: 16px; font-variant-numeric: tabular-nums; }
.passed { background: #e8f3ec; color: #2c6049; }
.failed { background: #fbecef; color: #8c2d3b; }
.skipped { background: #fbf0dc; color: #80501a; }
.not-run { background: #ecf1f7; color: #4c5f79; }
.execution-list-controls { display: flex; align-items: center; flex-wrap: wrap; gap: 9px; padding: 10px 18px; border-bottom: 1px solid var(--line); }
.execution-list-controls > span { margin-inline-start: auto; font-size: 12px; color: var(--muted); }
.execution-search { display: inline-flex; align-items: center; gap: 6px; flex: 1 1 240px; max-width: 330px; min-width: 0; padding: 0 7px; color: var(--muted); border: 1px solid var(--line); border-radius: 6px; }
.execution-search input { min-width: 0; width: 100%; border: 0; background: transparent; font-size: 12px; padding: 7px 0; }
.execution-search svg { flex: none; }
.execution-list, .execution-history ul { list-style: none; padding: 0; margin: 0; }
.execution-row { min-width: 0; display: grid; grid-template-columns: minmax(0, 1fr) minmax(0, .8fr); align-items: start; gap: 7px 17px; padding: 12px 18px; }
.execution-row + .execution-row { border-top: 1px solid var(--line); }
.execution-requirement > div { display: flex; align-items: center; flex-wrap: wrap; gap: 4px 8px; min-width: 0; }
.execution-requirement strong, .execution-requirement button { font-size: 13px; overflow-wrap: anywhere; }
.execution-source-link { justify-content: flex-start; flex-wrap: wrap; white-space: normal; text-align: start; gap: 4px; max-width: 100%; }
.execution-status { display: inline-flex; padding: 3px 7px; border-radius: 5px; font-size: 11px; font-weight: 650; }
.execution-case, .execution-origin p, .execution-origin small, .execution-proof, .execution-history p { margin: 2px 0 0; color: var(--muted); font-size: 12px; line-height: 1.55; overflow-wrap: anywhere; }
.execution-proof { grid-column: 1 / -1; color: var(--text); }
.execution-proof, .execution-original-proof { display: flex; align-items: baseline; flex-wrap: wrap; gap: 4px 9px; }
.execution-original-proof { flex-basis: 100%; }
.execution-evidence a { display: inline-flex; align-items: center; gap: 3px; color: var(--primary); text-decoration: none; }
.execution-evidence a:hover { text-decoration: underline; }
.execution-evidence a > svg { flex: none; }
.execution-empty { display: flex; align-items: flex-start; gap: 10px; padding: 19px 18px; }
.execution-empty > svg { flex: none; color: var(--primary); }
.execution-empty strong { font-size: 13px; color: var(--text); }
.execution-empty p { margin: 5px 0 0; color: var(--muted); font-size: 12px; line-height: 1.6; }
.execution-pagination { justify-content: flex-end; gap: 5px; padding: 8px 14px; border-top: 1px solid var(--line); }
.execution-pagination span { color: var(--muted); font-size: 12px; margin-inline-end: 5px; font-variant-numeric: tabular-nums; }
.execution-pagination button { min-height: 33px; width: 33px; }
.execution-history { padding: 11px 18px; border-top: 1px solid var(--line); }
.execution-history > summary { cursor: pointer; width: fit-content; max-width: 100%; color: var(--primary); font-size: 13px; font-weight: 650; }
.execution-history > summary svg { vertical-align: middle; }
.execution-history > summary span { color: var(--muted); font-size: 12px; margin-inline-start: 3px; }
.execution-history li { padding: 10px 0; min-width: 0; overflow-wrap: anywhere; font-size: 13px; }
.execution-history li + li { border-top: 1px solid var(--line); }
.execution-history li details { margin-top: 4px; color: var(--muted); font-size: 11px; }
.execution-history li details summary { cursor: pointer; width: fit-content; }
.execution-original-rows ul { margin: 7px 0; padding-inline: 10px; border-inline-start: 2px solid var(--line); }
.execution-original-rows li { display: flex; flex-wrap: wrap; align-items: center; gap: 6px 8px; padding: 6px 0; font-size: 12px; }
.execution-original-rows li small { color: var(--muted); }

@media (max-width: 650px) {
  .execution-header { flex-wrap: wrap; }
  .execution-form, .execution-scope, .execution-list-controls, .execution-row, .execution-empty, .execution-history, .execution-success, .execution-load-state { padding-inline: 12px; }
  .execution-fields, .execution-row { grid-template-columns: minmax(0, 1fr); }
  .execution-stats { grid-template-columns: repeat(2, minmax(0, 1fr)); padding-inline: 12px; }
  .execution-list-controls > span { margin-inline-start: 0; }
}
</style>
