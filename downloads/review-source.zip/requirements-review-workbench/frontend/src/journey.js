import { isLocalRuleReview } from './workflow.js'
import { reviewProblems } from './review-findings.js'

export const openIssue = issue => ['OPEN', 'IN_PROGRESS', 'FIXED'].includes(issue.status)

export function reviewJourney(document, runs, issues) {
  const version = document?.versions[0]
  const matching = version ? runs.filter(run => run.versionId === version.id && run.documentId === document.id) : []
  const latest = matching[0]
  const running = ['RUNNING', 'QUEUED'].includes(latest?.status)
  const result = matching.find(run => run.mode === 'MODEL' && ['COMPLETED', 'PARTIAL'].includes(run.status))
    || matching.find(run => ['COMPLETED', 'PARTIAL'].includes(run.status))
  const problems = reviewProblems(result, version)
  const pending = problems.find(problem => problem.finding?.decision === 'PENDING')?.finding
  const ruleNotices = problems.filter(problem => problem.kind === 'rule').length
  const runIds = new Set(runs.filter(run => run.documentId === document?.id).map(run => run.id))
  const issue = issues.find(item => runIds.has(item.runId) && openIssue(item))
  const incomplete = result?.mode === 'MODEL' && (result.status === 'PARTIAL' || result.scope?.omittedItemIds?.length)
  let next = { step: 4, title: '检查交付资料', text: '核对验收依据和执行记录，再导出对应版本的报告。', action: 'delivery' }

  if (!version) next = { step: 0, title: '准备第一份需求文档', text: '导入原件，或从业务说明起草。', action: 'document' }
  else if (running) next = { step: 1, title: '查看审查进度', text: '当前版本的任务正在运行，完成后就会保存结果。', action: 'review' }
  else if (!result && version.number > 1) next = { step: 3, title: `复查修订版 V${version.number}`, text: '这一版还没有完成的审查。可以沿用上一版的规则。', action: 'review' }
  else if (!result) next = { step: 1, title: latest?.status === 'FAILED' ? '重试审查' : '发起审查', text: latest?.status === 'FAILED' ? '先查看失败原因，再重试当前版本。' : '选择审查包和范围，核对原文后提交。', action: 'review' }
  else if (pending) next = { step: 2, title: '复核找到的问题', text: '对照原文，记录确认或驳回的依据。', action: 'evidence' }
  else if (issue) next = { step: 3, title: issue.status === 'FIXED' ? '核验已提交的修订' : '处理已登记的问题', text: '从问题记录进入原文和跟进状态。', action: 'issue' }
  else if (ruleNotices) next = { step: 2, title: '核对规则发现的问题', text: `规则检查发现了 ${ruleNotices} 条问题。打开结果可直接定位原文。`, action: 'evidence' }
  else if (incomplete) next = { step: 1, title: '核对审查覆盖范围', text: '当前结果还有待核验的范围。查看诊断后可继续审查。', action: 'evidence' }

  return {
    version, latest, result, pending, issue, next,
    availability: [true, !!version, !!result, !!version, !!version],
    visited: [!!version, !!result, !!result && !pending && !ruleNotices && !incomplete, version?.number > 1 && !!result && !issue && !ruleNotices, false],
    labels: [version ? `V${version.number} 已保存` : '等待原件', running ? '任务进行中' : result ? (isLocalRuleReview(result) ? '本地检查完成' : '已有审查结果') : latest ? '等待重试' : '尚无审查',
      pending ? '有问题待复核' : ruleNotices ? `${ruleNotices} 条问题待查看` : result ? '可核对结果' : '审查后可看',
      issue?.status === 'FIXED' ? '等待核验' : issue ? '跟进问题中' : version?.number > 1 ? (result ? '已生成复查结果' : '新版本待复查') : '按需修订', '核对清单与报告'],
  }
}
