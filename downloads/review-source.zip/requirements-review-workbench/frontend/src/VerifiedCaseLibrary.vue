<script setup>
import { computed, ref, watch } from 'vue'
import { ArrowRight, ArrowUpRight, BookOpen, ChevronRight, ClipboardCheck, FileText, GitCompareArrows } from 'lucide-vue-next'
import { api } from './api.js'
import { reviewProblems } from './review-findings.js'

const props = defineProps({
  projectId: { type: String, required: true }, documents: { type: Array, required: true },
  runs: { type: Array, required: true }, canWrite: Boolean, canAudit: Boolean, importCase: { type: Function, required: true },
  runStatus: { type: Function, required: true },
})
const emit = defineEmits(['source', 'audit', 'task', 'report', 'delivery', 'back'])
const cards = ref([])
const selected = ref('')
const loading = ref(false)
const importing = ref('')
const error = ref('')
const importError = ref('')
const importStatus = ref('')
const reload = ref(0)
const selectedCard = computed(() => cards.value.find(row => row.sample.id === selected.value))
const sample = computed(() => selectedCard.value?.sample)
const imported = computed(() => selectedCard.value?.imported)
const remaining = computed(() => cards.value.filter(row => !row.imported).length)
const document = computed(() => props.documents.find(row => row.id === imported.value?.documentId))
const originalReview = computed(() => props.runs.find(run =>
  run.versionId === imported.value?.beforeVersionId && ['COMPLETED', 'PARTIAL'].includes(run.status)))
const showingReference = ref(false)
const reference = ref(null)
const referenceError = ref('')
const referenceAttempt = ref(0)
watch(selected, () => { showingReference.value = false })
watch(() => [props.projectId, selected.value, originalReview.value?.id, showingReference.value, referenceAttempt.value],
  async ([projectId, caseId, runId, visible], _, cleanup) => {
    let current = true
    cleanup(() => { current = false })
    reference.value = null
    referenceError.value = ''
    if (!visible || !runId) return
    try {
      const result = await api('/api/projects/' + encodeURIComponent(projectId) + '/cases/' +
        encodeURIComponent(caseId) + '/reference?runId=' + encodeURIComponent(runId))
      if (current) reference.value = result
    } catch (failure) { if (current) referenceError.value = failure.message }
  })
const stages = computed(() => [
  { side: 'before', label: '原版', id: imported.value?.beforeVersionId },
  { side: 'after', label: '修订版', id: imported.value?.afterVersionId },
].map(stage => {
  const version = document.value?.versions.find(row => row.id === stage.id)
  const run = stage.id && props.runs.find(row => row.versionId === stage.id)
  const source = sample.value?.[stage.side]
  const lines = reference.value?.[stage.side]?.focusLines || []
  const focused = Object.entries(version?.source?.anchors || {}).filter(([, pos]) =>
    lines.some(line => pos.startLine <= line && pos.endLine >= line))
  const versionLines = (version?.text || '').split('\n')
  const count = run && version ? reviewProblems(run, version).length : 0
  const status = run && props.runStatus(run)
  return { ...stage, source, run, count, status,
    excerpt: focused.map(([index, pos]) => ({ line: pos.startLine, text: versionLines[Number(index) - 1] })),
    pending: ['RUNNING', 'QUEUED'].includes(run?.status), report: ['COMPLETED', 'PARTIAL', 'FAILED'].includes(run?.status) }
}))
const storageKey = () => 'req-review-case:' + props.projectId

watch(() => [props.projectId, reload.value], async ([projectId], _, cleanup) => {
  let current = true
  cleanup(() => { current = false })
  error.value = ''
  loading.value = true
  try {
    const rows = await api('/api/projects/' + encodeURIComponent(projectId) + '/cases')
    if (!current) return
    cards.value = rows
    let saved = selected.value
    try { saved = sessionStorage.getItem(storageKey()) || saved } catch {}
    selected.value = rows.find(row => row.sample.id === saved)?.sample.id || rows[0]?.sample.id || ''
  } catch (failure) { if (current) error.value = failure.message }
  finally { if (current) loading.value = false }
}, { immediate: true })

function choose(id) {
  selected.value = id
  importError.value = ''
  importStatus.value = ''
  try { sessionStorage.setItem(storageKey(), id) } catch {}
}
async function addToProject() {
  const row = selectedCard.value
  if (importing.value || !row) return
  importing.value = row.sample.id
  importError.value = ''
  try {
    row.imported = await props.importCase(props.projectId, row.sample.id)
    importStatus.value = '已加入两个版本，可选择原版开始审查。'
  }
  catch (failure) { importError.value = failure.message }
  finally { importing.value = '' }
}
async function importRemaining() {
  if (importing.value || !remaining.value) return
  importing.value = 'all'
  importError.value = ''
  try {
    cards.value = await props.importCase(props.projectId)
    importStatus.value = cards.value.length + ' 份公开文档均已加入当前项目，可分别选择版本开始审查。'
  }
  catch (failure) { importError.value = failure.message }
  finally { importing.value = '' }
}
function openSource(stage) {
  emit('source', imported.value.documentId, stage.id)
}
</script>

<template>
  <div class="verified-cases">
    <header class="page-heading"><div><button type="button" class="text-button back-link" @click="emit('back')">‹ 返回需求文档</button><h1>公开文档库</h1><p>将公开文档的两个历史版本加入当前项目，再选择审查包检查原文。</p></div>
      <button v-if="canWrite && remaining" type="button" class="button secondary" data-case-import-all :disabled="!!importing" @click="importRemaining">{{ importing === 'all' ? '正在导入…' : (remaining === cards.length ? '导入全部 ' : '导入剩余 ') + remaining + ' 份' }}</button>
    </header>
    <p v-if="importStatus" class="case-import-status" role="status">{{ importStatus }}</p>
    <section v-if="error" class="panel empty" role="alert"><p>{{ error }}</p><button class="button secondary small" @click="reload++">重试</button></section>
    <section v-else-if="loading" class="panel empty" role="status"><p>正在读取案例…</p></section>
    <div v-else-if="sample" class="case-layout">
      <nav class="panel cases-nav" aria-label="选择公开案例">
        <h2><BookOpen :size="17" /> 可导入的文档 <span>{{ cards.length }}</span></h2>
        <button v-for="{ sample: entry } in cards" :key="entry.id" type="button" :data-case-id="entry.id"
          class="case-choice" :aria-pressed="selected === entry.id" :disabled="!!importing" @click="choose(entry.id)">
          <span><small>{{ entry.project }}</small><strong>{{ entry.title }}</strong></span><ChevronRight :size="15" />
        </button>
      </nav>
      <article :key="sample.id" class="panel case-detail" :data-case-detail="sample.id">
        <header class="case-heading"><div class="case-byline">{{ sample.project }}<span aria-hidden="true">·</span>{{ sample.kind }}</div>
          <h2>{{ sample.title }}</h2><p>{{ sample.summary }}</p>
        </header>
        <section v-if="!imported" class="case-import">
          <div><h3>把两个版本加入当前项目</h3><p>将同一份公开文档的修订前后片段分别保存为 V1 和 V2，之后可以查看原文、运行审查并导出报告。</p></div>
          <button v-if="canWrite" type="button" class="button primary small" data-case-import :disabled="!!importing" @click="addToProject">
            {{ importing ? '正在导入…' : '导入两版原文' }}<ArrowRight :size="16" /></button>
          <p v-else>请项目所有者或编辑成员先导入两个版本。</p>
        </section>
        <p v-if="importError" class="case-error" role="alert">{{ importError }}</p>
        <section v-if="imported" class="case-workflow" aria-label="案例审查步骤">
          <div class="case-stage" v-for="(stage, index) in stages" :key="stage.side" :data-case-side="stage.side">
            <div class="stage-icon"><component :is="index ? GitCompareArrows : FileText" :size="19" /></div>
            <div class="stage-body"><h3>{{ index ? '复查上游修订版' : '审查原版文档' }} <small>V{{ index + 1 }}</small></h3>
              <p v-if="stage.run">{{ stage.status }}<template v-if="stage.run.mode === 'MODEL'"> · {{ stage.run.executionStrategy === 'COMBINED' ? '联合审查' : '模型审查' }}</template><template v-if="stage.report && stage.run.status !== 'FAILED'"> · {{ stage.count }} 条问题记录</template><template v-else-if="stage.run.executionStrategy === 'COMBINED' && stage.count"> · 已保留 {{ stage.count }} 条问题记录</template></p>
              <p v-else>{{ index ? '尚未审查。可以使用同一审查包比较这两个版本。' : '尚未审查。请选择审查包和范围，再开始检查。' }}</p>
              <div class="stage-actions">
                <button v-if="!stage.run && canAudit" class="button primary small" type="button" :data-case-audit="stage.side" @click="emit('audit', imported.documentId, stage.id)">{{ index ? '复查修订版' : '审查原版' }}<ArrowRight :size="14" /></button>
                <button v-if="stage.run" class="button secondary small" type="button" :data-case-task="stage.side" @click="emit('task', stage.run.id)">{{ stage.pending ? '查看进度' : '查看任务与证据' }}</button>
                <button v-if="stage.report" class="text-button" type="button" :data-case-report="stage.side" @click="emit('report', stage.run.id)">打开报告</button>
                <button class="text-button" type="button" :data-case-source="stage.side" @click="openSource(stage)">查看原文</button>
                <button v-if="stage.report && canAudit" class="text-button" type="button" @click="emit('audit', imported.documentId, stage.id)">重新审查</button>
              </div>
            </div>
          </div>
          <div v-if="stages[1].report" class="case-delivery"><ClipboardCheck :size="17" />
            <button class="text-button" type="button" data-case-delivery @click="emit('delivery', imported.documentId, imported.afterVersionId, stages[1].run.id)">核对修订版交付清单 <ArrowRight :size="14" /></button></div>
        </section>
        <details v-if="originalReview" class="case-proof" @toggle="showingReference = $event.target.open"><summary><span>核对上游修订依据</span><ChevronRight :size="16" /></summary>
          <p v-if="referenceError" role="alert">{{ referenceError }} <button type="button" class="text-button" @click="referenceAttempt++">重新加载</button></p>
          <p v-else-if="!reference" role="status">正在读取上游修订记录…</p>
          <template v-else>
          <dl><dt>上游记录的问题</dt><dd>{{ reference.expectedIssue }}</dd><dt>上游如何修改</dt><dd>{{ reference.expectedFix }}</dd>
            <template v-if="reference.scopeNote || reference.reviewHint"><dt>核对范围</dt><dd>{{ reference.scopeNote || reference.reviewHint }}</dd></template></dl>
          <div v-if="imported" class="case-clips"><section v-for="stage in stages" :key="stage.side">
            <h4>{{ stage.label }}关键原文</h4>
            <div v-for="entry in stage.excerpt" :key="entry.line"><small>第 {{ entry.line }} 行</small><code>{{ entry.text }}</code></div>
            <button v-if="!stage.excerpt.length" class="text-button" type="button" @click="openSource(stage)">打开该版原文</button>
          </section></div>
          <a :href="reference.fixUrl" target="_blank" rel="noopener noreferrer">查看上游修订记录 <ArrowUpRight :size="13" /></a>
          <a v-if="reference.corroborationUrl && reference.corroborationUrl !== reference.fixUrl" :href="reference.corroborationUrl"
            target="_blank" rel="noopener noreferrer">对照项目依据 <ArrowUpRight :size="13" /></a>
          <div v-for="ref in reference.supportingReferences || []" :key="ref.beforeUrl" class="case-ref">
            <strong>{{ ref.title }}</strong><p>{{ ref.scope }}</p>
            <a :href="ref.beforeUrl" target="_blank" rel="noopener noreferrer">原版约定 <ArrowUpRight :size="13" /></a>
            <a :href="ref.afterUrl" target="_blank" rel="noopener noreferrer">修订版约定 <ArrowUpRight :size="13" /></a>
          </div>
          </template>
        </details>
        <footer class="case-sources"><strong>公开原文</strong>
          <a v-for="stage in stages" :key="stage.side" :href="stage.source.url" target="_blank" rel="noopener noreferrer">{{ stage.label }} · {{ stage.source.startLine }}–{{ stage.source.endLine }} 行 <ArrowUpRight :size="12" /></a>
        </footer>
      </article>
    </div>
  </div>
</template>

<style scoped>
.case-layout { display:grid; grid-template-columns:minmax(205px,.78fr) minmax(0,2fr); align-items:start; gap:18px; }
.cases-nav { padding:18px 12px 12px; }
.cases-nav h2,.case-byline,.case-sources,.case-delivery,.stage-actions,.case-proof summary,.case-proof a { display:flex; align-items:center; gap:8px; }
.cases-nav h2 { margin:0 8px 12px; font-size:16px; }
.cases-nav h2 span { margin-left:auto; font-size:12px; color:var(--muted); }
.case-choice { display:flex; align-items:center; justify-content:space-between; text-align:left; width:100%; gap:4px; padding:11px; border:1px solid transparent; background:none; color:var(--text); border-radius:8px; }
.case-choice + .case-choice { margin-top:2px; }
.case-choice[aria-pressed=true] { background:#eaf0e8; border-color:#c4d4c7; color:var(--primary); }
.case-choice span { display:grid; gap:3px; min-width:0; }
.case-choice strong { font-size:14px; line-height:1.5; overflow-wrap:anywhere; }
.case-choice small,.case-byline,.case-sources strong { color:var(--muted); font-size:12px; }
.case-choice svg,.stage-icon svg,.case-sources svg { flex-shrink:0; }
.case-detail { padding:clamp(16px,2.5vw,32px); min-width:0; }
.case-byline { font-weight:600; }
.case-heading h2 { font-family:var(--display-font); font-size:clamp(23px,3vw,32px); margin:6px 0; overflow-wrap:anywhere; }
.case-heading p,.case-import p,.stage-body p,.case-proof dd { font-size:14px; line-height:1.65; color:var(--muted); overflow-wrap:anywhere; }
.case-heading p,.case-import p,.stage-body p { margin:4px 0; }
.case-import { border:1px solid var(--line); background:#f5f4ea; border-radius:10px; padding:17px; margin:20px 0; }
.case-import h3,.stage-body h3 { font-size:16px; margin:0; }
.case-import button { margin-top:10px; }
.case-workflow { margin:19px 0; }
.case-stage { display:flex; gap:12px; padding:16px 0; border-top:1px solid var(--line); }
.stage-icon { background:#eef1e9; color:var(--primary); border-radius:8px; padding:9px; height:fit-content; display:grid; }
.stage-body { min-width:0; }
.stage-body h3 small { margin-left:3px; color:var(--muted); font-size:12px; font-weight:500; }
.stage-actions,.case-sources { flex-wrap:wrap; }
.stage-actions { margin-top:8px; gap:7px 13px; }
.case-delivery { border-top:1px solid var(--line); padding-top:12px; color:var(--primary); }
.case-proof { border-top:1px solid var(--line); padding:13px 0; }
.case-proof summary { cursor:pointer; list-style:none; justify-content:space-between; font-weight:650; font-size:14px; }
.case-proof[open] summary svg { transform:rotate(90deg); }
.case-proof dl { margin:14px 0; }
.case-proof dt { color:var(--primary); font-size:12px; font-weight:650; }
.case-proof dd { margin:2px 0 9px; }
.case-proof a,.case-sources a { color:var(--primary); font-size:12px; text-decoration:underline; text-underline-offset:3px; }
.case-proof a { width:fit-content; margin-top:6px; }
.case-ref { margin-top:12px; color:var(--muted); font-size:12px; }
.case-ref p { margin:3px 0; }
.case-ref a { display:inline-flex; margin-right:12px; }
.case-clips { display:grid; grid-template-columns:repeat(2,minmax(0,1fr)); gap:8px; margin:10px 0; }
.case-clips section { background:#f5f4ec; padding:10px; border-radius:6px; }
.case-clips h4 { margin:0 0 6px; font-size:12px; }
.case-clips small { display:block; margin-top:5px; color:var(--muted); font-size:11px; }
.case-clips code { white-space:pre-wrap; overflow-wrap:anywhere; font-size:12px; }
.case-sources { gap:6px 13px; border-top:1px solid var(--line); padding-top:13px; }
.case-sources a { display:inline-flex; align-items:center; gap:2px; }
.case-error { color:#893f36; }
.case-import-status { color:var(--primary); margin:0 0 14px; }
@media(max-width:800px) { .case-layout { grid-template-columns:1fr; } .cases-nav { display:grid; grid-template-columns:repeat(2,minmax(0,1fr)); } .cases-nav h2 { grid-column:1/-1; } .case-choice + .case-choice { margin:0; } }
@media(max-width:470px) { .case-layout { gap:10px; } .case-choice { padding:8px; } .case-choice small { font-size:11px; } .case-choice svg { display:none; } .stage-icon { padding:6px; } .case-stage { gap:8px; } }
@media(max-width:520px) { .case-clips { grid-template-columns:1fr; } }
</style>
