import { createApp } from 'vue'
import App from './App.vue'
import './style.css'
import './platform.css'
import './delivery.css'
import './workspace.css'
import './reports.css'

createApp(App).mount('#app')
