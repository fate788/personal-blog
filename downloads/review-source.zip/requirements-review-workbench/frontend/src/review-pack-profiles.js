const profiles = {
  general: {
    audience: '准备评审或交付需求的产品、开发、测试和项目负责人',
    goal: '一次核对需求能否讲清楚、做出来、测得过，以及出错后能否恢复。',
    materials: '需求规格书，含业务流程、相关接口、数据约定和验收条件。可按章节或整个版本运行。',
    example: '接口说明写着用 PUT 更新配置，紧接着的调用示例却用 POST。照抄示例的人可能调用失败。',
    result: '并列标出冲突的两处原文，说明调用者会遇到什么问题，以及需要统一哪两处。',
    boundary: '覆盖常见文档错误。实际响应时间、服务可用性和线上权限效果需要测试记录验证。',
  },
  'information-security': {
    audience: '安全评审、架构、开发及测试人员',
    goal: '检查谁能访问哪些数据、账户停用后权限何时失效，以及敏感操作能否追溯。',
    materials: '需求文档中的角色权限、会话、日志、导出与审计约定。可补充适用的权限矩阵。',
    example: '规范要求停用员工账户后立即停止访问项目，另一条却允许用旧会话继续下载客户资料。',
    result: '指出停用后的访问路径和两处不一致的要求，建议统一会话失效时间并补一条验收用例。',
    boundary: '核对需求中的安全设计。线上系统的实际控制效果需结合授权测试或运行记录。',
    requiresModel: true,
    reference: { label: 'OWASP 应用安全验证标准', url: 'https://asvs.owasp.org/' },
  },
  baseline: {
    audience: '首次评审的产品、开发和测试人员',
    goal: '查一遍需求有没有说清楚，前后是否打架，开发和测试能否执行。',
    materials: '需求规格书。权限表、异常说明和验收条件可整理在同一份文档中。',
    example: '一处规定每个学生只能保留一条有效报名，另一处却允许同一学生保留多条。',
    result: '标出两处要求和共同适用的场景，提示先统一报名规则再写验收用例。',
    boundary: '覆盖常见需求质量问题。公司政策和法规要求可用对应的专题包核对。',
  },
  'business-fit': {
    audience: '产品负责人、业务方和公司治理人员',
    goal: '把准备做的功能和公司在意的目标、做事原则或禁止事项逐条对照。',
    materials: '需求文档，以及与本次评审直接相关的业务目标、优先级或公司原则。建议用编号，并写出明确的要求。',
    example: '公司原则写明费用需在付款前展示，需求却规定付款后才显示附加费用。',
    result: '分别引用需求和公司原则，提示把费用展示放到确认付款之前。',
    boundary: '以你提供的公司目标和规则为准，具体取舍由相关负责人确认。',
    requiresModel: true,
    context: {
      label: '公司目标与原则',
      hint: '填入能直接核对的目标或原则，可按 G-01、P-01 分行。',
      placeholder: 'P-01 所有附加费用必须在用户确认付款前展示。',
      required: true,
    },
    reference: { label: 'NASA 系统设计流程中的利益相关者期望', url: 'https://www.nasa.gov/reference/4-0-system-design-processes/' },
  },
  'legal-risk': {
    audience: '产品、隐私、合规和法务协作人员',
    goal: '检查个人信息收集、告知、保存和删除的设计，找出需要合规复核的具体风险。',
    materials: '需求文档。可补充业务地区、服务对象、信息处理场景等背景。',
    example: '关闭账户后，需求仍规定把用户的手机号无限期保留，方便将来营销。',
    result: '指出保留目的和期限可能需要核对，附对应原文和法规核对依据。',
    boundary: '以中国大陆个人信息保护规则为参考做风险初筛。适用性和最终法律意见由合规或法务人员确认。',
    requiresModel: true,
    context: {
      label: '业务范围补充（选填）',
      hint: '例如业务地区、用户类型、涉及的个人信息及使用场景。请填写业务规则，避免粘贴真实个人信息。',
      placeholder: '例如：中国大陆，向个人用户提供账户服务，手机号用于登录和找回账户。',
      required: false,
    },
    reference: { label: '《中华人民共和国个人信息保护法》', url: 'https://www.cac.gov.cn/2021-08/20/c_1631050028355286.htm' },
  },
  'user-journey': {
    audience: '用户体验、产品、客服和测试人员',
    goal: '顺着用户完成一件事的过程，找出会卡住的步骤和看不懂的结果。',
    materials: '需求文档。最好包含角色、主要流程、失败后的操作、反馈和验收条件。',
    example: '重置密码的链接失效后，页面只提示“失败”，用户找不到重新发送的入口。',
    result: '定位卡住的步骤，建议给出可执行的下一步，并补上测试应观察到的结果。',
    boundary: '检查写在需求里的流程和反馈。界面可用性可结合实际页面和用户测试继续验证。',
    requiresModel: true,
  },
  consistency: {
    audience: '业务分析师、项目负责人和评审人员',
    goal: '核对同一个角色、对象和条件下的要求是否一致。',
    materials: '涉及同一操作的条款、角色说明、术语定义和引用的需求。',
    example: '一处允许项目成员直接归档需求，另一处规定只有项目所有者可以做同一操作。',
    result: '列出两条要求及适用条件，指出需要统一的角色权限。',
    boundary: '以文档中的角色和权限定义为准。',
  },
  acceptance: {
    audience: '测试、验收负责人和项目经理',
    goal: '检查团队能不能按同一组条件复现结果、判定通过。',
    materials: '需求的性能目标、可观察结果、异常处理和运行条件。',
    example: '需求只写“500 人同时提交时快速响应”，没有说明多快算通过。',
    result: '标出不能直接验收的表述，说明要补充计时起点、测量口径和通过条件。',
    boundary: '检查验收条件是否可执行。运行测试、测量实际性能是后续工作。',
  },
  integration: {
    audience: '接口开发、数据和系统集成人员',
    goal: '核对系统之间怎么交换数据，调用失败后该怎么处理。',
    materials: '接口契约、权限、数据字段、超时、重试及失败后的状态约定。',
    example: '通知接口超时后可以重试，但需求没有约定如何识别同一次发送，可能重复通知用户。',
    result: '定位会产生重复操作的失败路径，指出要明确重试条件和去重依据。',
    boundary: '检查提交的接口和数据契约。外部服务的实际行为需用联调或测试记录验证。',
  },
  launch: {
    audience: '运维、交付和服务负责人',
    goal: '检查上线后出错能否发现、谁来处置、怎样确认服务恢复。',
    materials: '上线要求、依赖服务、关键告警、恢复步骤和相应验收条件。',
    example: '需求规定故障自动恢复，却没写故障持续多久要通知谁，也没说明怎样判断恢复成功。',
    result: '指出告警和恢复验收的具体缺口，给出需要补齐的条件与责任。',
    boundary: '检查文档中的运行保障。用演练、监控和运行记录验证实际保障能力。',
  },
}

export function reviewPackProfile(pack) {
  if (pack?.basePackId) {
    const base = profiles[pack.basePackId] || {}
    const example = pack.rules?.find(rule => rule.example)?.example
    return {
      ...base, requiresModel: true,
      goal: pack.description || '按这个项目包保存的检查项审查需求。',
      example: example || '', result: '展示命中检查项的问题、原文位置和修改建议。',
      boundary: [base.boundary, '本包按已保存的检查项运行。'].filter(Boolean).join(''),
    }
  }
  return profiles[pack?.id] || { goal: pack?.description }
}
