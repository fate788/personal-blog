<script setup>
import { computed, ref, useId, watch } from 'vue'
import { Check, ChevronDown } from 'lucide-vue-next'

const props = defineProps({
  modelValue: [String, Number, Boolean],
  options: { type: Array, default: () => [] },
  label: { type: String, required: true },
  placeholder: { type: String, default: '请选择' },
  disabled: Boolean,
})
const emit = defineEmits(['update:modelValue'])
const trigger = ref(null)
const menu = ref(null)
const expanded = ref(false)
const activeIndex = ref(-1)
const listId = useId() + '-choices'
const optionId = index => `${listId}-${index}`
const selected = computed(() => props.options.find(option => option.value === props.modelValue))
const enabled = computed(() => props.options.flatMap((option, index) => option.disabled ? [] : [index]))
const unavailable = computed(() => props.disabled || !enabled.value.length)

let typed = ''
let typedAt = 0

function open() {
  if (unavailable.value) return
  const index = props.options.indexOf(selected.value)
  activeIndex.value = enabled.value.includes(index) ? index : enabled.value[0]
  expanded.value = true
}

function close() {
  expanded.value = false
  typed = ''
  typedAt = 0
}

function toggle() {
  if (expanded.value) close()
  else {
    trigger.value?.focus({ preventScroll: true })
    open()
  }
}

function choose(index, restoreFocus = false) {
  const option = props.options[index]
  if (!option || option.disabled) return
  close()
  if (restoreFocus) trigger.value?.focus({ preventScroll: true })
  if (option.value !== props.modelValue) emit('update:modelValue', option.value)
}

function positionMenu(event) {
  const list = menu.value
  if (!list || !trigger.value || event?.target === list) return
  const rect = trigger.value.getBoundingClientRect()
  const view = window.visualViewport
  const topEdge = view?.offsetTop ?? 0
  const leftEdge = view?.offsetLeft ?? 0
  const viewportWidth = view?.width ?? document.documentElement.clientWidth
  const viewportHeight = view?.height ?? window.innerHeight
  const gutter = 10
  const gap = 7
  if (rect.bottom <= topEdge || rect.top >= topEdge + viewportHeight) {
    close()
    return
  }

  const width = Math.min(Math.max(rect.width, 248), viewportWidth - 2 * gutter)
  list.style.width = `${width}px`
  list.style.left = `${Math.max(leftEdge + gutter, Math.min(rect.left, leftEdge + viewportWidth - width - gutter))}px`
  const below = topEdge + viewportHeight - rect.bottom - gap - gutter
  const above = rect.top - topEdge - gap - gutter
  const desired = Math.min(320, list.scrollHeight + 2)
  const upwards = below < desired && above > below
  list.dataset.placement = upwards ? 'above' : 'below'
  list.style.maxHeight = `${Math.max(0, Math.min(desired, upwards ? above : below))}px`
  list.style.top = `${upwards ? rect.top - gap - list.getBoundingClientRect().height : rect.bottom + gap}px`
  list.style.visibility = 'visible'
}

function revealActive() {
  const list = menu.value
  const option = list?.children[activeIndex.value]
  if (!option) return
  const visible = list.getBoundingClientRect()
  const rect = option.getBoundingClientRect()
  if (rect.top < visible.top + 5) list.scrollTop += rect.top - visible.top - 5
  else if (rect.bottom > visible.bottom - 5) list.scrollTop += rect.bottom - visible.bottom + 5
}

function move(amount) {
  const index = enabled.value.indexOf(activeIndex.value)
  activeIndex.value = enabled.value[Math.max(0, Math.min(index + amount, enabled.value.length - 1))]
}

function matchTyped(key) {
  const now = Date.now()
  const character = key.toLocaleLowerCase()
  typed = (now - typedAt < 650 ? typed : '') + character
  typedAt = now
  const repeating = [...typed].every(entry => entry === character)
  const prefix = repeating ? character : typed
  const index = enabled.value.indexOf(activeIndex.value) + (repeating ? 1 : 0)
  const candidates = enabled.value.slice(index).concat(enabled.value.slice(0, index))
  const match = candidates.find(entry => props.options[entry].label.toLocaleLowerCase().startsWith(prefix))
  if (match != null) activeIndex.value = match
}

function handleKey(event) {
  if (unavailable.value || event.isComposing) return
  const { key, altKey, ctrlKey, metaKey } = event
  const wasOpen = expanded.value
  if (key === 'Tab') {
    if (wasOpen) choose(activeIndex.value)
    return
  }
  if (key === 'Escape') {
    if (wasOpen) {
      event.preventDefault()
      event.stopPropagation()
      close()
    }
    return
  }
  if (ctrlKey || metaKey || (altKey && !['ArrowUp', 'ArrowDown'].includes(key))) return
  switch (key) {
    case 'Enter':
    case ' ':
      event.preventDefault()
      if (wasOpen) choose(activeIndex.value)
      else open()
      break
    case 'ArrowUp':
    case 'ArrowDown':
      event.preventDefault()
      if (!wasOpen) open()
      else if (altKey && key === 'ArrowUp') choose(activeIndex.value)
      else if (!altKey) move(key === 'ArrowUp' ? -1 : 1)
      break
    case 'Home':
    case 'End':
      event.preventDefault()
      if (!wasOpen) open()
      activeIndex.value = key === 'Home' ? enabled.value[0] : enabled.value.at(-1)
      break
    case 'PageUp':
    case 'PageDown':
      if (wasOpen) {
        event.preventDefault()
        move(key === 'PageUp' ? -10 : 10)
      }
      break
    default:
      if (key.length === 1 && !altKey) {
        event.preventDefault()
        if (!wasOpen) open()
        matchTyped(key)
      }
  }
}

function closeOutside(event) {
  if (!trigger.value?.contains(event.target) && !menu.value?.contains(event.target)) close()
}

watch(expanded, (visible, _, onCleanup) => {
  if (!visible || !menu.value) return
  menu.value.showPopover?.()
  positionMenu()
  revealActive()

  const listeners = new AbortController()
  const { signal } = listeners
  document.addEventListener('pointerdown', closeOutside, { capture: true, signal })
  window.addEventListener('scroll', positionMenu, { capture: true, passive: true, signal })
  window.addEventListener('resize', positionMenu, { passive: true, signal })
  window.visualViewport?.addEventListener('resize', positionMenu, { passive: true, signal })
  window.visualViewport?.addEventListener('scroll', positionMenu, { passive: true, signal })
  onCleanup(() => listeners.abort())
}, { flush: 'post' })

watch(activeIndex, revealActive, { flush: 'post' })
watch([enabled, unavailable], () => {
  if (!expanded.value) return
  if (unavailable.value) close()
  else {
    if (!enabled.value.includes(activeIndex.value)) activeIndex.value = enabled.value[0]
    positionMenu()
  }
}, { flush: 'post' })
</script>

<template>
  <span class="workspace-select">
    <button ref="trigger" type="button" class="workspace-select-trigger" role="combobox" aria-haspopup="listbox"
      :aria-label="label" :aria-expanded="expanded" :aria-controls="expanded ? listId : undefined"
      :aria-activedescendant="expanded && activeIndex >= 0 ? optionId(activeIndex) : undefined" :disabled="unavailable"
      :title="selected?.label" @click="toggle" @keydown="handleKey" @blur="close">
      <span class="workspace-select-copy" :class="{ 'workspace-select-placeholder': !selected }">
        <span class="workspace-select-value">{{ selected?.label || placeholder }}</span>
        <small v-if="selected?.detail" class="workspace-select-detail">{{ selected.detail }}</small>
      </span>
      <ChevronDown class="workspace-select-chevron" :size="15" aria-hidden="true" />
    </button>
    <span v-if="expanded" :id="listId" ref="menu" class="workspace-select-menu" popover="manual" role="listbox" :aria-label="label" @click.stop>
      <span v-for="(option, index) in options" :id="optionId(index)" :key="option.value" class="workspace-select-option" role="option"
        :aria-selected="option.value === modelValue" :aria-disabled="option.disabled || undefined"
        :class="{ 'is-active': activeIndex === index }"
        @mousedown.prevent @pointermove="event => { if (event.pointerType === 'mouse' && !option.disabled) activeIndex = index }"
        @click.stop.prevent="choose(index, true)">
        <span class="workspace-select-copy">
          <span class="workspace-select-option-label">{{ option.label }}</span>
          <small v-if="option.detail" class="workspace-select-detail">{{ option.detail }}</small>
        </span>
        <Check v-if="option.value === modelValue" class="workspace-select-check" :size="15" aria-hidden="true" />
      </span>
    </span>
  </span>
</template>

<style scoped>
.workspace-select { display: inline-block; width: var(--select-width, 100%); min-width: 0; max-width: 100%; vertical-align: middle; }
.workspace-select-trigger {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 9px;
  width: 100%;
  min-width: 0;
  min-height: 37px;
  padding: 7px 10px;
  border: 1px solid #ded9ca;
  border-radius: 8px;
  background: var(--panel, #fffdf7);
  color: var(--text, #202822);
  box-shadow: inset 0 1px #fffaf0;
  font-size: 13px;
  font-weight: 500;
  line-height: 1.4;
  text-align: left;
}
.workspace-select-trigger:hover:not(:disabled), .workspace-select-trigger[aria-expanded="true"] {
  border-color: #b39b70;
  background: #fbf7ec;
}
.workspace-select-trigger:focus-visible { outline: 2px solid #987845; outline-offset: 2px; }
.workspace-select-trigger[aria-expanded="true"] .workspace-select-chevron { transform: rotate(180deg); }
.workspace-select-copy { display: grid; min-width: 0; flex: 1; gap: 2px; }
.workspace-select-value, .workspace-select-trigger .workspace-select-detail { overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.workspace-select-chevron { color: #725e3e; flex: none; }
.workspace-select-placeholder, .workspace-select-detail { color: #606557; }
.workspace-select-detail { font-size: 11px; font-weight: 500; line-height: 1.45; }
.workspace-select-menu {
  position: fixed;
  z-index: 50;
  inset: auto;
  max-height: 320px;
  overflow: auto;
  visibility: hidden;
  overscroll-behavior: contain;
  margin: 0;
  padding: 5px;
  border: 1px solid #c8b68d;
  border-radius: 10px;
  background: #fffdf6;
  color: #202822;
  box-shadow: 0 10px 26px #15271d2b, 0 2px 5px #45351a14, inset 0 0 0 2px #f7f0e1;
  scrollbar-width: thin;
  scrollbar-color: #b1a080 transparent;
}
.workspace-select-option {
  display: flex;
  align-items: flex-start;
  gap: 8px;
  min-height: 35px;
  padding: 8px 9px;
  border-radius: 6px;
  font-size: 13px;
  font-weight: 520;
  line-height: 1.45;
  cursor: pointer;
}
.workspace-select-option > .workspace-select-copy { overflow-wrap: anywhere; }
.workspace-select-option[aria-selected="true"] { color: #254638; background: #eaf0e7; }
.workspace-select-option.is-active { background: #f1e8d5; box-shadow: inset 2px 0 #9b7943; }
.workspace-select-option.is-active[aria-selected="true"] { background: #e5ecdf; }
.workspace-select-option[aria-disabled="true"] { color: #77776d; cursor: default; }
.workspace-select-check { flex: none; margin-top: 2px; color: #355747; }

@media (pointer: coarse) {
  .workspace-select-trigger, .workspace-select-option { min-height: 44px; }
}
</style>
