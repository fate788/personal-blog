<script setup>
import { computed } from 'vue'
import { Bot, CheckCircle2, CircleAlert, KeyRound, Plug, ShieldCheck } from 'lucide-vue-next'
const props = defineProps({ model: Object, results: Object, testing: String, error: String, offline: Boolean, canTest: Boolean })
const emit = defineEmits(['test', 'reload'])
const profiles = computed(() => props.model?.profiles?.length ? props.model.profiles : [
  { id: 'PRIMARY', label: '主模型', configured: Boolean(props.model?.configured), provider: props.model?.provider, model: props.model?.model, credentialConfigured: props.model?.credentialConfigured },
  { id: 'BACKUP', label: '备选模型', configured: false },
])
</script>

<template>
  <div class="page-heading"><div><h1>模型服务状态</h1><p>查看工作台的模型连接状态。生成需求文档和语义审查会自动使用默认服务。</p></div><button class="button secondary" @click="emit('reload')">刷新服务状态</button></div>
  <div v-if="error" class="panel form-error" role="alert">{{ error }}</div>
  <section v-if="offline" class="model-disclosure"><ShieldCheck :size="19" /><div><strong>当前为交互演示</strong><p>真实调用由完整项目包中的 Spring Boot 服务执行。连接测试仅发送固定探针。</p></div></section>
  <div class="model-profiles">
    <section v-for="profile in profiles" :key="profile.id" class="panel model-card">
      <div class="panel-heading"><div class="panel-title"><span class="metric-icon blue"><Bot :size="22" /></span><div><h2>{{ profile.label || (profile.id === 'PRIMARY' ? '主模型' : '备选模型') }}</h2><p>{{ profile.id === 'PRIMARY' ? '日常生成与审查' : '主模型未配置时作为默认服务' }}</p></div></div><span class="pill" :class="profile.configured ? 'success' : 'neutral'">{{ profile.configured ? '已配置' : '未配置' }}</span></div>
      <div class="settings-body">
        <dl class="connection-list"><dt>服务端点</dt><dd>{{ profile.provider || '—' }}</dd><dt>模型标识</dt><dd>{{ profile.model || '—' }}</dd><dt>凭据状态</dt><dd>{{ profile.credentialConfigured ? '服务端已设置' : '未设置' }}</dd><template v-if="profile.format"><dt>返回格式</dt><dd>{{ profile.format }}</dd></template><template v-if="profile.thinking && profile.configured"><dt>思考模式</dt><dd>{{ ({ OFF: '关闭', ON: '开启', AUTO: '随服务商设置' })[profile.thinking] || profile.thinking }}</dd></template></dl>
        <button v-if="canTest" class="button secondary" :disabled="!!testing || !model || !profile.configured" @click="emit('test', profile.id)"><Plug :size="17" />{{ testing === profile.id ? '正在测试…' : '测试连接' }}</button>
        <p v-if="results?.[profile.id]" class="connection-result" :class="results[profile.id].success ? 'good' : 'warning'" role="status"><CheckCircle2 v-if="results[profile.id].success" :size="17" /><CircleAlert v-else :size="17" /><span>{{ results[profile.id].message }}<template v-if="results[profile.id].elapsedMs"> · {{ results[profile.id].elapsedMs }} ms</template></span></p>
      </div>
    </section>
  </div>
  <details class="panel model-setup"><summary><KeyRound :size="18" /> 服务端维护说明</summary><div class="settings-body">
    <p>模型服务的地址、名称与密钥由服务端通过环境变量配置。连接测试只发送固定探针，审查提交前会显示原文发送范围。</p>
    <div class="model-env"><div><strong>主模型</strong><code>REVIEW_MODEL_PRIMARY_ENDPOINT</code><code>REVIEW_MODEL_PRIMARY_NAME</code><code>REVIEW_MODEL_PRIMARY_API_KEY</code></div><div><strong>备选模型</strong><code>REVIEW_MODEL_BACKUP_ENDPOINT</code><code>REVIEW_MODEL_BACKUP_NAME</code><code>REVIEW_MODEL_BACKUP_API_KEY</code></div></div>
    <p>DeepSeek 官方接口做常规结构化审查时，可设置 <code>REVIEW_MODEL_PRIMARY_THINKING=OFF</code>。模型参数由服务端配置，报告保留模型来源。</p>
  </div></details>
</template>
