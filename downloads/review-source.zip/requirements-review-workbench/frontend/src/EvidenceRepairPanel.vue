<script setup>
import { computed, ref, watch } from 'vue'
import { ArrowDownToLine, ChevronDown, CircleAlert, UploadCloud, Wrench } from 'lucide-vue-next'
import { api, offline } from './api.js'
import { downloadWord } from './word.js'
import { combinedScopeLabel, includesLocalResults, isCombinedReview, problemSourceLabel, reviewResult, reviewTemplateId } from './review-findings.js'
import { isLocalRuleReview, sourceLocation } from './workflow.js'
import ConfirmedRevisionExport from './ConfirmedRevisionExport.vue'

const props = defineProps({ run: Object, document: Object, version: Object, issues: Array, canEdit: Boolean, busy: Boolean })
const emit = defineEmits(['applied', 'upload'])
const expanded = ref(false)
const plan = ref(null)
const chosen = ref([])
const loading = ref(false)
const saving = ref(false)
const loadError = ref('')
const saveError = ref('')
const refresh = ref(0)

const repairUrl = computed(() => includesLocalResults(props.run)
  && (['COMPLETED', 'PARTIAL'].includes(props.run?.status) || (isCombinedReview(props.run) && props.run.status === 'FAILED'))
  && '/api/reviews/' + encodeURIComponent(props.run.id) + '/repairs')
const patches = computed(() => plan.value?.patches || [])
const locked = computed(() => !!props.busy || saving.value)
const canApply = computed(() => props.canEdit && plan.value?.latest === true && !locked.value && chosen.value.length > 0)
const originalLines = computed(() => (props.version?.text || '').split(/\r?\n/))

watch([expanded, repairUrl, () => props.version?.id, () => props.canEdit, () => props.document?.versions?.[0]?.id, refresh], async ([open, url, versionId, canEdit], _previous, onCleanup) => {
  let current = true
  onCleanup(() => { current = false })
  plan.value = null
  chosen.value = []
  loadError.value = ''
  loading.value = false
  if (!open || !url || !versionId || offline || !canEdit) return
  loading.value = true
  try {
    const candidate = await api(url)
    if (current && candidate.versionId === versionId) plan.value = candidate
    else if (current) loadError.value = '当前候选与正在查看的文档版本不一致，请重新读取。'
  } catch (error) {
    if (current) loadError.value = error.message || '无法读取可用修正。'
  } finally {
    if (current) loading.value = false
  }
})

watch(repairUrl, () => { saveError.value = '' })

async function applySelected() {
  if (!canApply.value) return
  const url = repairUrl.value
  saving.value = true
  saveError.value = ''
  try {
    const document = await api(url, { method: 'POST', body: { patchIds: [...chosen.value] } })
    if (url === repairUrl.value) {
      chosen.value = []
      emit('applied', document)
    }
  } catch (error) {
    if (url === repairUrl.value) {
      saveError.value = error.message || '未保存修订版，请重试。'
      if (error.status === 409) refresh.value++
    }
  } finally {
    saving.value = false
  }
}

function originalEvidence(line, quote, label = '') {
  if (!Number.isInteger(line) || line < 1) return []
  const text = quote ?? originalLines.value[line - 1]?.trim()
  return ['- ' + (label ? label + ' · ' : '') + sourceLocation(props.version, line) + (text ? ' · ' + text : '')]
}

function exportMaterials() {
  const { document, version, run } = props
  if (!version || !run) return
  const { listed: problems, inconclusive, message } = reviewResult(run, version)
  const interrupted = run.status === 'FAILED' || (run.status === 'PARTIAL' && !isLocalRuleReview(run))
  const contents = [
    '- 审查基线：V' + version.number + (version.source?.fileName ? ' · ' + version.source.fileName : ''),
    ...(run.createdAt ? ['- 审查时间：' + run.createdAt] : []),
    ...(isLocalRuleReview(run) ? ['- 模型语义审查：未执行'] : []),
    ...(isCombinedReview(run) ? ['- 检查范围：' + combinedScopeLabel(run)] : []),
    ...(reviewTemplateId(run) === 'legal-risk' ? ['- 法规范围：中国大陆个人信息保护初筛，需由法务复核。'] : []),
    ...(interrupted ? ['- 本次审查未完整执行，以下为目前找到的问题。'] : []),
    '',
    inconclusive ? '## 审查结果（尚无结论）' : '## 找到的问题（' + problems.length + ' 条）',
    ...(message ? [message] : []), '',
    ...problems.flatMap(problem => [
      '### ' + problem.title,
      '- 发现方式：' + problemSourceLabel(problem),
      ...(problem.finding ? ['- 处理状态：' + (problem.finding.decision === 'CONFIRMED' ? '已确认，待核对修订' : '待人工复核')] : []),
      ...(problem.impact ? ['- 为什么影响使用：' + problem.impact] : []),
      ...problem.evidence.flatMap(evidence => originalEvidence(evidence.line, evidence.quote, evidence.label || '原文')),
      ...(problem.basisEvidence || []).map(source => '- ' + source.code + ' · ' + source.quote),
      ...(problem.action ? ['- 怎么改：' + problem.action] : []),
      '',
    ]),
    ...patches.value.flatMap(patch => [
      '### 可预览的规则修正 · ' + patch.title,
      '- ' + sourceLocation(version, patch.line),
      '- 原文：' + patch.expected,
      '- 建议改为：' + patch.replacement,
      '',
    ]),
    '## 复查清单', '',
    ...problems.map(problem => '□ 对照原文核对修订：' + problem.title),
    '□ 将修订稿保存为独立版本，保留本次审查基线。',
    '□ 对修订版本重新运行相关检查并核对证据。',
    ...(run.mode === 'MODEL' && run.scope?.omittedItemIds?.length ? ['□ 复核本次任务尚未覆盖的条款。'] : []),
    ...(isLocalRuleReview(run) ? ['□ 如需核验业务语义，发起联合审查或安排人工复核。'] : []),
    '',
    '## 审查基线原文', '',
    version.text || '',
  ]
  const title = document?.title || '需求文档'
  downloadWord('V' + version.number + ' 修订材料 · ' + title, contents.join('\n'))
}
</script>

<template>
  <details id="evidence-repair-panel" class="panel evidence-repair-panel" @toggle="expanded = $event.currentTarget.open">
    <summary class="repair-summary">
      <span class="repair-summary-icon"><Wrench :size="18" aria-hidden="true" /></span>
      <span><strong>修订与导出</strong><small>确认具体改动后下载整份文档，也可以带走证据自行修订。</small></span>
      <ChevronDown class="repair-chevron" :size="17" aria-hidden="true" />
    </summary>
    <div class="repair-body">
      <ConfirmedRevisionExport :run="run" :version="version" :document="document" :patches="patches" :issues="issues" :loading="loading" />
      <details v-if="canEdit && !offline && repairUrl && (plan?.latest && patches.length || loadError)" class="repair-section save-rules" :aria-busy="loading || saving">
        <summary>将规则修正保存为项目新版本</summary>
        <h3 id="rule-repair-title">可应用的规则修正</h3>
        <p v-if="loading" role="status">正在核对当前文档版本…</p>
        <div v-else-if="loadError" class="repair-notice" role="alert"><CircleAlert :size="16" aria-hidden="true" /><span>{{ loadError }}</span><button type="button" class="text-button" :disabled="locked" @click="refresh++">重试</button></div>
        <p v-else-if="plan?.latest === false" class="repair-notice">这份结果来自历史版本。可下载材料，也可以检查最新版后再应用修正。</p>
        <p v-else-if="plan && !patches.length">本次检查没有可直接应用的修正。仍可下载原文和证据，逐项核对后修改。</p>
        <template v-else-if="patches.length">
          <p>勾选需要采用的修正。系统会将修改保存为新版本，供你继续复查。</p>
          <ul class="repair-list">
            <li v-for="patch in patches" :key="patch.id">
              <label class="repair-option">
                <input v-model="chosen" type="checkbox" :value="patch.id" :disabled="locked">
                <span><strong>{{ patch.title }}</strong><small>{{ sourceLocation(version, patch.line) }}</small></span>
              </label>
              <details class="repair-preview">
                <summary>查看原文与拟修订内容</summary>
                <dl>
                  <div><dt>原文</dt><dd><code>{{ patch.expected }}</code></dd></div>
                  <div><dt>拟修订</dt><dd><code>{{ patch.replacement }}</code></dd></div>
                </dl>
              </details>
            </li>
          </ul>
          <div class="repair-actions">
            <span role="status">已选择 {{ chosen.length }} 项</span>
            <button type="button" class="button primary small" :disabled="!canApply" @click="applySelected">{{ saving ? '正在保存…' : '应用修正并保存为新版本' }}</button>
          </div>
        </template>
        <div v-if="saveError" class="repair-notice" role="alert"><CircleAlert :size="16" aria-hidden="true" /><span>{{ saveError }}</span></div>
      </details>
      <section class="repair-section repair-export" aria-labelledby="repair-export-title">
        <div><h3 id="repair-export-title">导出后自行修改</h3><p>Word 包含原文、证据和待复查清单。修改后将原文部分另存为修订稿。</p></div>
        <div class="repair-export-actions">
          <button type="button" class="button secondary small" :disabled="!version || locked" @click="exportMaterials"><ArrowDownToLine :size="16" aria-hidden="true" /> 下载修订材料 Word</button>
          <button v-if="canEdit && !offline && version" type="button" class="button secondary small" :disabled="locked" @click="emit('upload')"><UploadCloud :size="16" aria-hidden="true" /> 上传修订稿</button>
        </div>
      </section>
    </div>
  </details>
</template>

<style scoped>
.evidence-repair-panel {
  margin-bottom: 16px;
}

.repair-summary {
  display: grid;
  grid-template-columns: auto minmax(0, 1fr) auto;
  align-items: center;
  gap: 11px;
  padding: 13px 16px;
  cursor: pointer;
  list-style: none;
}

.repair-summary::-webkit-details-marker {
  display: none;
}

.repair-summary-icon {
  display: grid;
  place-items: center;
  width: 34px;
  height: 34px;
  border-radius: 8px;
  background: var(--soft);
  color: var(--primary);
}

.repair-summary strong,
.repair-summary small,
.repair-option small {
  display: block;
}

.repair-summary small,
.repair-option small {
  margin-top: 3px;
  color: var(--muted);
  font-size: 12px;
  line-height: 1.5;
}

.repair-chevron {
  color: var(--muted);
}

.evidence-repair-panel[open] .repair-chevron {
  transform: rotate(180deg);
}

.repair-body {
  display: grid;
  gap: 16px;
  padding: 16px;
  border-top: 1px solid var(--line);
}

.repair-section {
  min-width: 0;
}

.repair-section h3 {
  font-size: 14px;
}
.save-rules summary { cursor: pointer; color: var(--primary); font-size: 13px; }
.save-rules h3 { margin-top: 12px; }

.repair-section p {
  margin-top: 6px;
  color: var(--muted);
  font-size: 13px;
  line-height: 1.6;
}

.repair-list {
  display: grid;
  gap: 8px;
  list-style: none;
  padding: 0;
  margin: 12px 0;
}

.repair-list li {
  min-width: 0;
  padding: 10px 11px;
  border: 1px solid var(--line);
  border-radius: 10px;
  background: #fafcf9;
}

.repair-option {
  display: flex;
  align-items: flex-start;
  gap: 8px;
  width: fit-content;
  max-width: 100%;
  line-height: 1.55;
}

.repair-option input {
  flex: none;
  margin: 3px 0 0;
  accent-color: var(--primary);
}

.repair-preview {
  margin: 8px 0 0 21px;
}

.repair-preview summary {
  width: fit-content;
  color: var(--primary);
  font-size: 12px;
  font-weight: 650;
  cursor: pointer;
}

.repair-preview dl {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 8px;
  margin: 8px 0 0;
}

.repair-preview dl > div {
  min-width: 0;
  padding: 8px;
  border: 1px solid var(--line);
  border-radius: 7px;
  background: white;
}

.repair-preview dt,
.repair-actions > span {
  color: var(--muted);
  font-size: 12px;
}

.repair-preview dd {
  margin: 4px 0 0;
  line-height: 1.5;
}

.repair-preview code {
  white-space: pre-wrap;
  overflow-wrap: anywhere;
}

.repair-actions,
.repair-export,
.repair-notice {
  display: flex;
  align-items: center;
  flex-wrap: wrap;
  gap: 8px 12px;
}

.repair-actions,
.repair-export {
  justify-content: space-between;
}

.repair-export-actions {
  display: flex;
  flex-wrap: wrap;
  gap: 7px;
}

.repair-section + .repair-section {
  padding-top: 15px;
  border-top: 1px solid var(--line);
}

.repair-section .repair-notice {
  margin-top: 8px;
  color: #734c14;
  font-size: 12px;
  line-height: 1.55;
}

.repair-notice svg {
  flex: none;
}

@media (max-width: 560px) {
  .repair-summary,
  .repair-body {
    padding: 11px 12px;
  }

  .repair-preview dl {
    grid-template-columns: minmax(0, 1fr);
  }
}
</style>
