<script setup>
import { computed, ref } from 'vue'
import { ArrowUpRight, ChevronDown, ClipboardCheck, FileText, ShieldCheck, UserRound, UserRoundPlus, UsersRound } from 'lucide-vue-next'
import WorkspaceSelect from './WorkspaceSelect.vue'
import { projectIdentity } from './workflow.js'

const props = defineProps({ project: Object, members: Array, busy: Boolean, error: String })
const emit = defineEmits(['invite', 'save', 'remove', 'reload', 'navigate'])
const username = ref('')
const permissionsFor = ref('')
const selectedPermission = ref('')
const confirming = ref('')
const owner = computed(() => props.project?.role === 'OWNER')
const orderedMembers = computed(() => [
  ...props.members.filter(member => member.role === 'OWNER'),
  ...props.members.filter(member => member.role !== 'OWNER'),
])
const access = {
  OWNER: '管理项目、成员和评审流程',
  VIEWER: '查看需求文档、审查结果和报告',
  EDITOR: '查看项目、编辑需求和发起审查',
  REVIEWER: '查看项目、发起审查和复核结论',
}
const permissionOptions = [
  { value: 'VIEWER', label: '查看文档、结果和报告' },
  { value: 'EDITOR', label: '同时允许编辑需求和发起审查' },
  { value: 'REVIEWER', label: '同时允许复核结论和发起审查' },
]

function invite() {
  const account = username.value.trim()
  if (account) emit('invite', account, () => { username.value = '' })
}

function togglePermissions(member) {
  permissionsFor.value = permissionsFor.value === member.userId ? '' : member.userId
  selectedPermission.value = member.role
  confirming.value = ''
}
</script>

<template>
  <div class="page-heading">
    <div><h1>项目成员</h1><p>{{ project?.name }} · 与成员一起查看项目资料和审查进展。</p></div>
    <button type="button" class="button secondary" :disabled="busy" @click="emit('reload')">刷新成员</button>
  </div>
  <div class="settings-layout team-layout">
    <section class="panel">
      <div class="panel-heading"><div class="panel-title"><UsersRound :size="19" /><h2>访问此项目的人员</h2></div><span class="pill info">{{ members.length }} 人</span></div>
      <div v-if="error" class="form-error" role="alert">{{ error }}</div>
      <div v-else-if="!members.length" class="empty"><UsersRound :size="27" /><p>正在读取项目成员</p></div>
      <div v-if="orderedMembers.length" class="team-members">
        <article v-for="member in orderedMembers" :key="member.userId" class="team-member">
          <span class="team-avatar" :class="{ 'team-owner-avatar': member.role === 'OWNER' }">
            <ShieldCheck v-if="member.role === 'OWNER'" :size="18" /><UserRound v-else :size="18" />
          </span>
          <div class="team-name">
            <div><strong>{{ member.displayName || member.username }}</strong><span class="pill" :class="member.role === 'OWNER' ? 'success' : 'neutral'">{{ projectIdentity(member.role) }}</span></div>
            <small v-if="member.displayName && member.displayName !== member.username">@{{ member.username }}</small>
            <p>{{ access[member.role] }}</p>
          </div>
          <button v-if="owner && member.role !== 'OWNER'" type="button" class="text-button member-permission-button" :disabled="busy" :aria-label="'管理 ' + member.username + ' 的访问权限'" :aria-expanded="permissionsFor === member.userId" @click="togglePermissions(member)">
            访问权限 <ChevronDown :size="14" />
          </button>
          <div v-if="permissionsFor === member.userId" class="member-access-settings">
            <form class="member-access-form" @submit.prevent="emit('save', { username: member.username, role: selectedPermission })">
              <label>允许操作<WorkspaceSelect v-model="selectedPermission" :options="permissionOptions" label="允许操作" :disabled="busy" /></label>
              <button type="submit" class="button secondary small" :disabled="busy || selectedPermission === member.role">保存权限</button>
            </form>
            <button v-if="confirming !== member.userId" type="button" class="text-button remove-member-button" :disabled="busy" @click="confirming = member.userId">取消项目访问</button>
            <div v-else class="member-confirm"><span>取消 {{ member.displayName || member.username }} 的项目访问？</span><button type="button" class="button secondary small" @click="confirming = ''">保留</button><button type="button" class="button primary small" :disabled="busy" @click="emit('remove', member.userId)">确认取消</button></div>
          </div>
        </article>
      </div>
    </section>
    <div class="team-aside">
      <form v-if="owner" class="panel team-share" @submit.prevent="invite">
        <div class="panel-heading"><div class="panel-title"><UserRoundPlus :size="19" /><h2>共享项目给同事</h2></div></div>
        <div class="form-body">
          <label>对方的平台用户名<input v-model="username" maxlength="40" autocomplete="off" required placeholder="请输入对方注册时的用户名"></label>
          <p class="form-hint">添加后，对方可从「我的项目」打开此项目，查看文档、审查结果和报告。访问范围限于当前项目。</p>
          <button type="submit" class="button primary" :disabled="busy || !username.trim()"><UserRoundPlus :size="17" /> 添加成员</button>
        </div>
      </form>
      <section v-else class="panel team-shared-content">
        <div class="panel-heading"><div class="panel-title"><FileText :size="19" /><h2>项目资料</h2></div></div>
        <div class="settings-body">
          <button type="button" class="button secondary" @click="emit('navigate', 'documents')"><FileText :size="16" /> 查看需求文档 <ArrowUpRight :size="15" /></button>
          <button type="button" class="button secondary" @click="emit('navigate', 'reviews')"><ClipboardCheck :size="16" /> 查看审查结果 <ArrowUpRight :size="15" /></button>
        </div>
      </section>
    </div>
  </div>
</template>
