const historicalExplanations = {
  '负载因子取值范围与格式不明确': {
    quote: '负载因子，必须是一个数字',
    title: '调整连接分布时，哪些数字可以填？',
    reason: '原文只说用一个数字。调用者看不出这个参数（loaderFactor）能不能填小数或负数，也不知道上下限，开发和测试可能会按不同的标准校验。',
    suggestion: '在这个参数的说明里写清上下限、能否取小数或负数，再给一个有效示例。',
  },
  'groupName与namespaceId互斥条件的判定方式不明确': {
    quote: '分组名称，与命名空间ID 两者必须有其一',
    title: '分组和命名空间都填时，配额会改到哪里？',
    reason: '原文要求至少填分组或命名空间中的一个。调用者看不出两项同时填写时，接口会拒绝请求、只改一处，还是两处都改。',
    suggestion: '写清只填一项、两项都填或都不填时分别怎么处理，并说明空字符串算不算填写。',
  },
}

export function plainFinding(finding) {
  const { title, reason, suggestion } = finding
  const explanation = historicalExplanations[title]
  if (finding.status === 'ISSUE' && explanation?.quote
      && finding.evidence?.some(entry => entry.quote?.includes(explanation.quote))) {
    return { title: explanation.title, reason: explanation.reason, suggestion: explanation.suggestion }
  }
  return { title, reason, suggestion }
}
