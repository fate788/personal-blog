<script setup>
import { computed, nextTick, onBeforeUnmount, onMounted, ref, watch } from 'vue'
import {
  Activity, ArrowDownToLine, ArrowRight, ArrowUpRight, BarChart3, BookOpen, Check, ChevronDown, ChevronRight, CircleAlert, ClipboardCheck,
  FileCheck2, FileDown, FileText, Files, FolderKanban, GitCompareArrows, History, LayoutGrid, ListChecks, LogOut,
  Menu, Plug, Plus, ScanLine, Search, Settings2, ShieldCheck, Sparkles, UploadCloud, UsersRound, X,
} from 'lucide-vue-next'
import { api, offline } from './api.js'
import LoginScreen from './LoginScreen.vue'
import DraftStudio from './DraftStudio.vue'
import DocumentPreview from './DocumentPreview.vue'
import IssueInbox from './IssueInbox.vue'
import ModelSettings from './ModelSettings.vue'
import ReviewDesk from './ReviewDesk.vue'
import ReviewPackPicker from './ReviewPackPicker.vue'
import VerifiedCaseLibrary from './VerifiedCaseLibrary.vue'
import ProjectTeam from './ProjectTeam.vue'
import ProjectUsage from './ProjectUsage.vue'
import ProjectRuleStudio from './ProjectRuleStudio.vue'
import ReleaseReadiness from './ReleaseReadiness.vue'
import SourceCheckCompare from './SourceCheckCompare.vue'
import StartingGuide from './StartingGuide.vue'
import VersionCompare from './VersionCompare.vue'
import WorkspaceSelect from './WorkspaceSelect.vue'
import WorkflowSteps from './WorkflowSteps.vue'
import { reviewJourney } from './journey.js'
import { plainFinding } from './problem-language.js'
import { combinedScopeLabel, problemSourceLabel, reviewProblems, reviewResult, reviewTemplateId } from './review-findings.js'
import { reviewPackProfile } from './review-pack-profiles.js'
import { draftKey, useRevisionDrafts } from './revision-drafts.js'
import { downloadWord } from './word.js'
import { isLocalRuleReview, issueStates, projectIdentity, reviewInterruption, sourceLocation } from './workflow.js'

const nav = [
  { key: 'home', label: '项目概览', icon: LayoutGrid },
  { key: 'drafts', label: '新建需求', icon: Sparkles },
  { key: 'documents', label: '需求文档', icon: Files },
  { key: 'cases', label: '公开文档库', icon: BookOpen },
  { key: 'reviews', label: '审查与复核', icon: ClipboardCheck },
  { key: 'issues', label: '问题工作台', icon: ListChecks },
  { key: 'reports', label: '报告与复查', icon: FileCheck2 },
  { key: 'delivery', label: '交付准备', icon: ShieldCheck },
  { key: 'team', label: '项目成员', icon: UsersRound },
  { key: 'usage', label: '项目用量', icon: BarChart3 },
]
const settings = [
  { key: 'packs', label: '审查包与规则', icon: ListChecks },
  { key: 'model', label: '服务状态', icon: Plug },
  { key: 'accounts', label: '账户管理', icon: UsersRound },
]
const navigationGroups = [
  { title: '需求与审核', keys: ['documents', 'reviews', 'issues'] },
  { title: '交付与留档', keys: ['delivery', 'reports'] },
]
const workflowSteps = [
  { title: '准备文档', icon: Files, action: 'document' },
  { title: '运行审查', icon: ScanLine, action: 'review' },
  { title: '复核证据', icon: ClipboardCheck, action: 'evidence' },
  { title: '修订与复查', icon: GitCompareArrows, action: 'versions' },
  { title: '检查交付', icon: ShieldCheck, action: 'delivery' },
]
const workflowDescriptions = ['生成需求文档或导入原文', '选择范围和审查包', '逐项核对原文依据', '修改文档并复查', '核对清单和报告']
const browserRoutes = new Set(['projects', ...nav.map(item => item.key), ...settings.map(item => item.key)])
const routeFromAddress = () => {
  const name = location.hash.slice(2).split('?')[0]
  return location.hash.startsWith('#/') && browserRoutes.has(name) ? name : 'projects'
}
const route = ref(offline ? 'home' : routeFromAddress())
const emptyWorkspace = () => ({ mode: 'DEMO', documents: [], packs: [], runs: [], projects: [], project: null })
const state = ref(emptyWorkspace())
const session = ref(null)
const sessionLoaded = ref(false)
watch(sessionLoaded, ready => {
  if (ready) document.getElementById('workbench-bootstrap')?.remove()
}, { flush: 'post' })
const loginBusy = ref(false)
const loginError = ref('')
const showLoginPreview = ref(offline && new URLSearchParams(location.search).get('view') === 'login')
const projectId = ref('')
const projectForm = ref({ name: '', description: '' })
const projectReturn = ref('home')
const requestedStage = ref('')
const projectMenu = ref(false)
const modelInfo = ref(null)
const modelResults = ref({})
const modelError = ref('')
const modelLoading = ref(false)
const modelTesting = ref('')
const reviewProbe = ref({ id: '', pending: false, success: false, message: '' })
const accounts = ref([])
const members = ref([])
const memberError = ref('')
const issues = ref([])
const reportIssues = ref([])
const projectIssues = ref([])
const issuesLoading = ref(false)
const issuesError = ref('')
const accountForm = ref({ username: '', displayName: '', password: '' })
const loaded = ref(false)
const loadError = ref('')
const busy = ref(false)
const mobileNav = ref(false)
const mobileMenuButton = ref(null)
const mobileMenuClose = ref(null)
const mobileBreakpoint = window.matchMedia('(max-width: 880px)')
const guideOpen = ref(false)
const guideStep = ref(0)
const guideSeen = new Set()
const journeyDocumentId = ref('')
const activeFlow = ref(null)
const followReview = ref(false)
const toast = ref('')
const toastError = ref(false)
let toastTimer
let pollTimer
let fetchId = 0
let membersRequest = 0

const modal = ref('')
const modalError = ref('')
const importTab = ref('file')
const importForJourney = ref(false)
const fileInput = ref(null)
const chosenFile = ref(null)
const chosenFileDigest = ref('')
const importForm = ref({ title: '', text: '' })
const reviewForm = ref({ documentId: '', versionId: '', packId: '', mode: '' })
const forceFreshReview = ref(false)
const repeatOptions = [
  { value: false, label: '优先使用已有结果', detail: '条件相同时，沿用已完成的审查和人工复核记录。' },
  { value: true, label: '重新独立审查', detail: '保留原任务，另开一轮检查。模型审查会再次调用 API。' },
]
const reviewPackChoice = ref(null)
const reviewPackNotice = ref('')
const reviewBasisByPack = ref({})
const reviewSection = ref('')
const reviewResumeIds = ref([])
const query = ref('')
const taskFilter = ref('')
const chosenDoc = ref('')
const chosenVersion = ref('')
const compareSources = ref(false)
const documentReader = ref(null)
const sourceFocusLine = ref(null)
const sourceFocusColumn = ref(null)
const chosenRun = ref('')
const showRunRevision = ref(false)
const chosenPack = ref('')
const ruleTab = ref('general')
const chosenReport = ref('')
const compareWith = ref('')
const deliveryTarget = ref({ documentId: '', versionId: '' })
const editText = ref('')
const editing = ref(false)
const revisionDrafts = useRevisionDrafts()
const acknowledgedHead = ref('')
const discardDraftId = ref('')
const newDraftForm = () => ({ goal: '', roles: '', features: '', constraints: '', scope: '', acceptance: '', nfr: '', integrations: '' })
const draftForm = ref(newDraftForm())
const draft = ref(null)
const draftError = ref('')
const draftGenerating = ref(false)
const selectedFinding = ref('')

const labels = { QUEUED: '排队中', RUNNING: '审查中', COMPLETED: '已完成', PARTIAL: '部分完成', FAILED: '失败', PENDING: '待复核', CONFIRMED: '已确认', REJECTED: '已驳回' }
const taskStatusOptions = [
  { value: '', label: '全部状态' },
  ...['QUEUED', 'RUNNING', 'COMPLETED', 'PARTIAL', 'FAILED'].map(value => ({ value, label: value === 'FAILED' ? '失败或受阻' : labels[value] })),
]
const reviewModeOptions = [
  { value: 'MODEL', label: '联合审查（本地规则 + AI）', detail: '规则检查原文，AI 按审查包核对条款，共用一份报告。' },
  { value: 'DEMO', label: '仅本地规则检查', detail: '检查编号、引用和接口示例等问题，无需调用模型。' },
]
const inProgress = item => ['QUEUED', 'RUNNING'].includes(item?.status)
const statusTone = status => ({ COMPLETED: 'success', FAILED: 'danger', RUNNING: 'info', QUEUED: 'info', PARTIAL: 'amber' }[status] || 'neutral')
const localRunLabels = { QUEUED: '本地检查排队中', RUNNING: '本地检查执行中', COMPLETED: '本地检查已完成', PARTIAL: '本地检查已完成', FAILED: '本地检查失败' }
const runStatus = run => (run.status === 'FAILED' && reviewInterruption(run)?.label)
  || (isLocalRuleReview(run) ? localRunLabels[run.status] : labels[run.status]) || run.status
const displayRunStatus = run => isLocalRuleReview(run) && run.status === 'PARTIAL' ? 'COMPLETED' : run.status
const runTone = run => run.status === 'FAILED' && reviewInterruption(run) ? 'amber' : statusTone(displayRunStatus(run))
const runMode = run => run.executionStrategy === 'COMBINED' ? '联合审查（本地规则 + AI）'
  : isLocalRuleReview(run) ? '本地规则检查' : run.mode === 'MODEL' ? '模型审查' : '样例演示'
const dateFormat = new Intl.DateTimeFormat('zh-CN', { timeZone: 'Asia/Shanghai', year: 'numeric', month: '2-digit', day: '2-digit' })
const stampFormat = new Intl.DateTimeFormat('zh-CN', { timeZone: 'Asia/Shanghai', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', hour12: false })
const displayDate = value => value && !Number.isNaN(Date.parse(value)) ? dateFormat.format(new Date(value)) : '—'
const displayStamp = value => value && !Number.isNaN(Date.parse(value)) ? stampFormat.format(new Date(value)) : '—'
const documents = computed(() => [...state.value.documents].sort((a, b) => Date.parse(b.updatedAt) - Date.parse(a.updatedAt)))
const runs = computed(() => [...state.value.runs].sort((a, b) => Date.parse(b.createdAt) - Date.parse(a.createdAt)))
const projectIssueRows = computed(() => {
  const byRun = new Map(runs.value.map(run => [run.id, run]))
  return projectIssues.value.map(item => {
    const finding = byRun.get(item.runId)?.findings.find(row => row.id === item.findingId)
    return finding ? { ...item, title: plainFinding(finding).title } : item
  })
})
const projects = computed(() => state.value.projects || [])
const project = computed(() => state.value.project || projects.value.find(item => item.id === projectId.value))
const projectRole = computed(() => project.value?.role || 'OWNER')
const canWrite = computed(() => ['OWNER', 'EDITOR'].includes(projectRole.value))
const canAudit = computed(() => projectRole.value !== 'VIEWER')
const canDecide = computed(() => ['OWNER', 'REVIEWER'].includes(projectRole.value))
const projectNav = computed(() => nav.filter(item => (item.key !== 'drafts' || canWrite.value) &&
  (!['delivery', 'cases'].includes(item.key) || !offline)))
const navGroupItems = group => group.keys.map(key => projectNav.value.find(item => item.key === key)).filter(Boolean)
const navActive = key => route.value === key || (['drafts', 'cases'].includes(route.value) && key === 'documents')
const modelReady = computed(() => state.value.mode === 'MODEL')
const modelDestination = computed(() => {
  const { configured, model, provider } = modelInfo.value || {}
  return configured && model && provider ? model + '（' + provider + '）' : ''
})
const accountName = computed(() => session.value?.user?.displayName || session.value?.user?.username || '用户')
const hasAdmin = computed(() => session.value?.user?.role === 'ADMIN')
const readyRuns = computed(() => runs.value.filter(run => !inProgress(run)))
const lookupDoc = id => state.value.documents.find(d => d.id === id)
const lookupPack = id => state.value.packs.find(p => p.id === id)
const savedPackForRun = item => item?.packSnapshot || lookupPack(item?.packId)
function savedPackLabel(item) {
  const pack = savedPackForRun(item)
  const version = item?.packVersion || item?.packSnapshot?.version
  return pack ? pack.name + (version ? ' · V' + version : '') : ''
}
const lookupVersion = (docId, versionId) => lookupDoc(docId)?.versions.find(v => v.id === versionId)
const documentOptions = computed(() => documents.value.map(item => ({ value: item.id, label: item.title })))
const journeyOptions = computed(() => documents.value.map(item => ({
  value: item.id, label: item.title, detail: item.versions.length ? 'V' + item.versions[0].number : '',
})))
const reportOptions = computed(() => [
  { value: '', label: '最近任务' },
  ...readyRuns.value.map(item => ({
    value: item.id,
    label: lookupDoc(item.documentId)?.title || '需求文档',
    detail: [`V${lookupVersion(item.documentId, item.versionId)?.number ?? '—'}`, runMode(item),
      savedPackLabel(item), displayStamp(item.createdAt)].filter(Boolean).join(' · '),
  })),
])
const doc = computed(() => lookupDoc(chosenDoc.value))
const version = computed(() => lookupVersion(chosenDoc.value, chosenVersion.value))
const run = computed(() => state.value.runs.find(r => r.id === chosenRun.value))
const plannedRunBatches = computed(() => {
  const scope = run.value?.scope
  return Math.min(scope?.plannedBatches ?? scope?.batches ?? 0, scope?.batchLimit ?? scope?.batches ?? 0)
})
const currentReviewProbe = computed(() => reviewProbe.value.id === run.value?.id ? reviewProbe.value : null)
const report = computed(() => readyRuns.value.find(r => r.id === chosenReport.value) || readyRuns.value[0])
const reportInterruption = computed(() => reviewInterruption(report.value))
const incompleteReport = run => run?.status === 'FAILED' || (run?.status === 'PARTIAL' && !isLocalRuleReview(run))
const reportVersion = computed(() => report.value && lookupVersion(report.value.documentId, report.value.versionId))
const reportHasLaterVersion = computed(() => (lookupDoc(report.value?.documentId)?.versions || [])
  .some(item => item.number > reportVersion.value?.number))
const reportResult = computed(() => reviewResult(report.value, reportVersion.value))
const reportProblems = computed(() => reportResult.value.listed)
function reportCountLabel(run) {
  const result = reviewResult(run, lookupVersion(run.documentId, run.versionId))
  return result.inconclusive ? '尚无结论' : result.listed.length + ' 个'
}
const reportProblemTitle = findingId => reportProblems.value.find(problem => problem.finding?.id === findingId)?.title
const basisEvidenceLabel = item => reviewTemplateId(item) === 'legal-risk' ? '法规核对依据' : '公司审查依据'
const reportedIssues = computed(() => reportIssues.value.filter(item => reportProblemTitle(item.findingId)))
const olderVersions = computed(() => (lookupDoc(report.value?.documentId)?.versions || [])
  .filter(item => item.number < (reportVersion.value?.number ?? 0)))
const comparisonVersion = computed(() => olderVersions.value.find(item => item.id === compareWith.value) || olderVersions.value[0])
watch(() => reportVersion.value?.id, () => { compareWith.value = '' })
const comparisonRun = computed(() => {
  if (!comparisonVersion.value) return null
  const current = report.value
  const previous = readyRuns.value.filter(candidate => candidate.documentId === current.documentId &&
    candidate.versionId === comparisonVersion.value.id && candidate.packId === current.packId &&
    (!savedPackForRun(current)?.basePackId || candidate.packVersion === current.packVersion) &&
    candidate.mode === current.mode && candidate.status !== 'FAILED' &&
    (candidate.reviewBasis || '') === (current.reviewBasis || ''))
  return previous.find(candidate => candidate.packVersion === current.packVersion &&
    candidate.model === current.model && candidate.modelConfigRevision === current.modelConfigRevision) || previous[0]
})
const relatedReports = computed(() => runs.value.filter(r =>
  !inProgress(r) && r.id !== report.value?.id && r.documentId === report.value?.documentId &&
  r.packId === report.value?.packId && r.mode === report.value?.mode && isLocalRuleReview(r) === isLocalRuleReview(report.value)))
const targetDoc = computed(() => lookupDoc(reviewForm.value.documentId))
const targetVersion = computed(() => lookupVersion(reviewForm.value.documentId, reviewForm.value.versionId))
const targetSections = computed(() => [...new Set((targetVersion.value?.items || []).map(item => item.section || '正文'))])
const targetVersionOptions = computed(() => (targetDoc.value?.versions || []).map(item => ({
  value: item.id, label: 'V' + item.number, detail: displayStamp(item.createdAt),
})))
const reviewScopeOptions = computed(() => [
  { value: '', label: '整个版本' },
  ...targetSections.value.map(section => ({ value: section, label: section })),
])
const formPacks = computed(() => {
  const choice = reviewPackChoice.value
  const available = state.value.packs
  if (!choice) return available
  return available.some(item => item.id === choice.id)
    ? available.map(item => item.id === choice.id ? choice : item)
    : [choice, ...available]
})
const latestReviewPack = computed(() => lookupPack(reviewForm.value.packId))
const reviewProfile = computed(() => reviewPackProfile(reviewPackChoice.value))
const reviewBasis = computed({
  get: () => reviewBasisByPack.value[reviewForm.value.packId] || '',
  set: value => { reviewBasisByPack.value[reviewForm.value.packId] = value },
})
const reviewUsesRules = computed(() => !offline && !reviewProfile.value.requiresModel && reviewForm.value.mode === 'DEMO')
const targetItems = computed(() => {
  const items = targetVersion.value?.items || []
  if (reviewUsesRules.value) return items
  return items.filter(item => reviewResumeIds.value.length ? reviewResumeIds.value.includes(item.id)
    : !reviewSection.value || (item.section || '正文') === reviewSection.value)
})
const hasPreviousReview = computed(() => !offline && reviewForm.value.mode === 'MODEL' && runs.value.some(item =>
  item.versionId === reviewForm.value.versionId && item.packId === reviewForm.value.packId && item.mode === reviewForm.value.mode))
watch(() => [reviewForm.value.versionId, reviewForm.value.packId, reviewForm.value.mode], () => { forceFreshReview.value = false })
const canSubmitReview = computed(() => {
  const form = reviewForm.value
  if (busy.value || !form.versionId || !form.packId || !targetItems.value.length) return false
  if (reviewProfile.value.requiresModel && form.mode !== 'MODEL') return false
  if (form.mode === 'MODEL' && !modelDestination.value) return false
  return !reviewProfile.value.context?.required || reviewBasis.value.trim().length >= 10
})
watch(() => reviewForm.value.versionId, () => { reviewSection.value = ''; reviewResumeIds.value = [] }, { flush: 'sync' })
const searchDocs = computed(() => documents.value.filter(d => d.title.toLowerCase().includes(query.value.trim().toLowerCase())))
const searchRuns = computed(() => runs.value.filter(r => (!taskFilter.value || displayRunStatus(r) === taskFilter.value) &&
  (lookupDoc(r.documentId)?.title || '').toLowerCase().includes(query.value.trim().toLowerCase())))
const runProblemCounts = computed(() => new Map(searchRuns.value.map(run => [
  run.id, reviewProblems(run, lookupVersion(run.documentId, run.versionId)).length,
])))
const currentRuns = computed(() => {
  const seen = new Set()
  return readyRuns.value.filter(r => {
    if (r.status === 'FAILED' || lookupDoc(r.documentId)?.versions[0]?.id !== r.versionId) return false
    const signature = JSON.stringify([r.versionId, r.mode, r.packId, r.packVersion, r.reviewBasis || '', [...(r.targetItemIds || [])].sort()])
    if (seen.has(signature)) return false
    seen.add(signature)
    return true
  })
})
const outstanding = computed(() => currentRuns.value.flatMap(run =>
  reviewProblems(run, lookupVersion(run.documentId, run.versionId))
    .filter(problem => problem.finding?.decision === 'PENDING').map(problem => ({ run, problem })))
  .sort((a, b) => ({ HIGH: 0, MEDIUM: 1, LOW: 2 }[a.problem.finding.severity] ?? 3)
    - ({ HIGH: 0, MEDIUM: 1, LOW: 2 }[b.problem.finding.severity] ?? 3)))
const sourceAlerts = computed(() => {
  const latest = new Map()
  for (const run of currentRuns.value) {
    if (!latest.has(run.documentId)) latest.set(run.documentId, run)
  }
  return [...latest.values()].flatMap(run => {
    const count = reviewProblems(run, lookupVersion(run.documentId, run.versionId)).filter(problem => problem.kind === 'rule').length
    return count ? [{ run, count }] : []
  })
})
const journeyDocument = computed(() => lookupDoc(journeyDocumentId.value) || documents.value[0])
const journey = computed(() => reviewJourney(journeyDocument.value, runs.value, projectIssues.value))
const versionRun = computed(() => runs.value.find(item => item.versionId === version.value?.id))
const currentNav = computed(() => [...nav, ...settings].find(n => n.key === route.value)?.label || '工作台首页')
const projectEntries = {
  cases: '选择项目后，可以导入公开案例，对照修订前后的审查结果。',
  documents: '创建项目后，可以导入原件并查看版本历史。',
  drafts: '创建项目后，可以从业务说明整理第一份需求。',
  reviews: '选择或创建项目后，可以对文档版本发起审查并查看结果。',
  issues: '项目里的已确认问题、修订进度和核验记录会显示在这里。',
  delivery: '这里按文档版本核对审查、验收追溯和测试执行。',
  reports: '完成审查后，可以在这里查看和导出项目报告。',
  team: '打开项目后，可查看成员或与同事共享项目。',
  usage: '创建项目后，可以查看审查任务和模型用量。',
}
const projectEntry = computed(() => !project.value && projectEntries[route.value])
const missingProjectTitle = computed(() => guideOpen.value && guideStep.value === 2 && route.value === 'reviews' ? '复核证据' : currentNav.value)
const documentFlow = computed(() => doc.value && doc.value.id === activeFlow.value?.documentId &&
  [0, 3].includes(activeFlow.value.stage) ? activeFlow.value : null)
const runFlow = computed(() => run.value && run.value.id === activeFlow.value?.runId &&
  [1, 2].includes(activeFlow.value.stage) ? activeFlow.value : null)
const reviewedFlowVersion = computed(() => {
  const previous = runs.value.find(item => item.id === documentFlow.value?.runId)
  return previous && lookupVersion(previous.documentId, previous.versionId)
})
const canRecheckFlow = computed(() => documentFlow.value?.stage === 3 && version.value?.number > (reviewedFlowVersion.value?.number ?? Infinity))

watch(() => project.value?.id, id => {
  draftForm.value = { ...newDraftForm(), goal: project.value?.description || '' }
  draft.value = null
  draftError.value = ''
  journeyDocumentId.value = ''
  activeFlow.value = null
  projectIssues.value = []
  issuesError.value = ''
  if (id && ['home', 'issues'].includes(route.value)) loadProjectIssues()
})

watch([loaded, () => session.value?.user?.id, route, modal], async ([ready, userId, page, dialog]) => {
  if (!ready || !userId || !['home', 'projects'].includes(page) || dialog || guideSeen.has(userId)) return
  guideSeen.add(userId)
  const marker = 'req-review-guide-v2:' + userId
  let seenLocally = false
  try { seenLocally = !!localStorage.getItem(marker) } catch {}
  let due = offline
  if (!offline) {
    try { due = (await api('/api/session/onboarding', { method: 'POST' })).show } catch { return }
  }
  if (!due || seenLocally || guideOpen.value || userId !== session.value?.user?.id || modal.value || !['home', 'projects'].includes(route.value)) return
  try { localStorage.setItem(marker, 'seen') } catch {}
  openGuide()
})

function handleMobileMenuKey(event) {
  if (!mobileNav.value) return
  if (event.key === 'Escape') {
    event.preventDefault()
    event.stopPropagation()
    mobileNav.value = false
    return
  }
  if (event.key !== 'Tab') return
  const buttons = [...event.currentTarget.querySelectorAll('button:not(:disabled), summary')].filter(element => {
    const closed = element.closest('details:not([open])')
    return element.getClientRects().length && (!closed || closed.querySelector('summary') === element)
  })
  const first = buttons[0], last = buttons[buttons.length - 1]
  if (event.shiftKey && event.target === first || !event.shiftKey && event.target === last) {
    event.preventDefault()
    const focusTarget = event.shiftKey ? last : first
    focusTarget?.focus()
  }
}
function resetMobileMenu(event) {
  if (!event.matches) mobileNav.value = false
}
watch(mobileNav, open => {
  if (!open) projectMenu.value = false
  if (!mobileBreakpoint.matches || modal.value || guideOpen.value) return
  const focusTarget = open ? mobileMenuClose.value : mobileMenuButton.value
  focusTarget?.focus({ preventScroll: true })
}, { flush: 'post' })

function openGuide() {
  mobileNav.value = false
  guideStep.value = 0
  guideOpen.value = true
}

function closeGuide() {
  const userId = session.value?.user?.id
  if (userId) try { localStorage.setItem('req-review-guide-v2:' + userId, 'seen') } catch {}
  guideOpen.value = false
}

const guideAnchor = name => `[data-coach="${name}"]`
const guidePages = ['documents', 'reviews', 'reviews', 'documents', 'delivery']
const guideSubject = computed(() => {
  const viewedRun = route.value === 'reviews' ? run.value : null
  const viewedDoc = route.value === 'documents' ? doc.value : null
  const formDocument = modal.value === 'review' ? lookupDoc(reviewForm.value.documentId) : null
  const targetId = route.value === 'delivery' ? deliveryTarget.value.documentId : activeFlow.value?.documentId
  const versionId = route.value === 'delivery' ? deliveryTarget.value.versionId : activeFlow.value?.versionId
  const selected = formDocument || viewedDoc || lookupDoc(viewedRun?.documentId || targetId) || journeyDocument.value
  const viewed = formDocument ? lookupVersion(formDocument.id, reviewForm.value.versionId)
    : viewedDoc ? version.value : lookupVersion(selected?.id, viewedRun?.versionId || versionId)
  const chosen = viewed || selected?.versions[0]
  const audited = readyRuns.value.find(item => item.documentId === selected?.id && item.versionId === chosen?.id && item.status !== 'FAILED')
  return { selected, chosen, audited }
})

function nextGuideStep(step) {
  if (busy.value) { notify('当前操作正在保存，稍后可继续引导。'); return }
  if (!Number.isInteger(step) || step < 0 || step >= workflowSteps.length) return
  const { selected, chosen, audited } = guideSubject.value
  if (modal.value) closeModal()
  guideStep.value = step
  const page = step === 4 && offline ? 'reports' : guidePages[step]

  if (step === 1 && selected && chosen && canAudit.value) {
    go('reviews')
    openVersionReview(selected.id, chosen.id)
    followReview.value = activeFlow.value?.documentId === selected.id
  } else if (step === 2 && audited) {
    openRun(audited.id)
    if (runFlow.value) moveFlow(2)
  } else if (step === 3 && selected) {
    if (runFlow.value) flowToRevision(!reviewProblems(run.value, lookupVersion(run.value.documentId, run.value.versionId)).length)
    else {
      openDoc(selected.id)
      compareSources.value = !offline && selected.versions.length > 1
    }
  } else if (step === 4 && selected && chosen) openDelivery(selected.id, chosen.id)
  else go(page)
}

function locateCoachControl(name, activate = false) {
  const target = document.querySelector(guideAnchor(name))
  if (!target) return
  target.scrollIntoView({ block: 'nearest' })
  if (activate && !target.disabled) target.click()
  else target.focus({ preventScroll: true })
}

const guideHint = computed(() => {
  const tip = (anchor, heading, description, label, perform) => ({ target: guideAnchor(anchor), heading, description, label, perform })
  const stage = guideStep.value
  const { selected, chosen, audited } = guideSubject.value
  if (modal.value === 'project-new') return tip('project-name', '给项目取个名字', '输入名称，再点击创建项目。', '填写项目名称', () => locateCoachControl('project-name'))
  if (modal.value === 'choose-flow-project' || modal.value === 'choose-flow-document') {
    const choosingProject = modal.value === 'choose-flow-project'
    if (!choosingProject && requestedStage.value === 'document' && canWrite.value) {
      return tip('flow-choices', '选择文档来源', '可以用业务目标生成草稿，也可以导入文件或选择项目已有文档。', '查看选项', () => locateCoachControl('flow-choices'))
    }
    return tip('flow-choices', choosingProject ? '选择工作项目' : '选择需求文档', '点击列表中你要继续处理的一项。', '查看选项', () => locateCoachControl('flow-choices'))
  }
  if (modal.value === 'import' || modal.value === 'import-version') {
    return tip(importTab.value === 'file' ? 'choose-file' : 'paste-source', '准备原件', '选择文件或贴入正文，再点击保存。',
      importTab.value === 'file' ? '选择文件' : '填写正文', () => importTab.value === 'file' ? fileInput.value?.click() : locateCoachControl('paste-source'))
  }
  if (modal.value === 'review') {
    return tip('submit-review', '核对版本并开始审查', '确认文档、版本和执行方式后，点击页面上的提交按钮。', '定位提交按钮', () => locateCoachControl('submit-review'))
  }
  if (!project.value) {
    if (route.value === 'projects') return tip('begin-flow', '从第一步开始', '在首页开始流程，选择自己的项目和文档。', '开始准备', () => beginWorkspaceStage('document'))
    const title = projectEntry.value ? missingProjectTitle.value : projects.value.length ? '选择工作项目' : '创建你的第一个项目'
    const text = projectEntry.value ? '创建或打开项目后，便能使用这里的功能。' : '项目保存你的原件、审查任务和修订版本。'
    return tip('create-project', title, text, '创建项目', () => openProjectForm(false, projectEntry.value ? route.value : 'home'))
  }
  if (route.value === 'home' && stage === 0) {
    return tip('begin-flow', '从第一步开始', '选择从业务说明生成草稿、导入原件，或打开已有文档。', '开始准备', startFirstStep)
  }
  if (route.value === 'documents' && stage === 3) {
    const anchor = documentFlow.value?.stage === 3 ? 'revision-next' : doc.value ? 'version-tools' : 'documents-import'
    return tip(anchor, '修订与复查', '可以上传修订稿，再复查新版本。', '打开版本操作', () => {
      if (documentFlow.value?.stage === 3) locateCoachControl('revision-next', true)
      else if (selected && canWrite.value) openRevisionUpload(selected.id)
      else if (selected) openDoc(selected.id)
      else if (canWrite.value) openImport()
    })
  }
  if (route.value === 'documents' && documentFlow.value?.stage === 0) {
    return tip('prepare-next', '进入第二步', '原件核对后，直接进入运行审查。', '前往审查', () => nextGuideStep(1))
  }
  if (route.value === 'documents' && stage === 0 && !doc.value && canWrite.value) {
    return tip('documents-import', '准备需求文档', '可以先导入一份原件。', '导入原件', openImport)
  }
  if (route.value === 'reviews' && run.value && !inProgress(run.value) && run.value.status !== 'FAILED') {
    const hasEvidence = stage === 2 && run.value.ruleWarnings?.some(entry => entry.line > 0)
    return hasEvidence
      ? tip('rule-evidence', '从证据返回原文', '点击行号，工作台会定位文档原句。', '查看原文', () => locateCoachControl('rule-evidence', true))
      : tip('review-next', '继续当前审查', '根据结果复核、修订或核对交付条件。', '继续操作', () => locateCoachControl('review-next', true))
  }
  if (route.value === 'reviews' && !run.value && stage <= 2) {
    const label = audited ? '打开审查结果' : selected && canAudit.value ? '发起审查' : '前往需求文档'
    return tip(audited ? 'review-result' : 'reviews-start', stage === 2 ? '复核证据' : '运行审查',
      audited ? '打开该版本的审查结果。' : '运行一次审查后，会在这里保存可复核的证据。', label,
      () => audited ? openRun(audited.id) : selected && canAudit.value ? nextGuideStep(1) : go('documents'))
  }
  if (route.value === 'delivery' && stage === 4 && audited) {
    return tip('delivery-report', '查看同版本报告', '核对验收和执行记录后，打开该版本的报告。', '查看报告', () => locateCoachControl('delivery-report', true))
  }
  const item = stage === 4 && offline ? 'reports' : guidePages[stage]
  return { ...tip('nav-' + item, workflowSteps[stage].title, '进入对应的页面。', '前往这一步', () => nextGuideStep(stage)),
    target: `${guideAnchor('nav-' + item)}, ${guideAnchor('mobile-menu')}` }
})

function guideAction() {
  if (busy.value) { notify('当前操作正在保存，稍后可继续引导。'); return }
  guideHint.value.perform()
}

function writeAddress(page, details = {}, replace = false) {
  if (offline) return
  const params = new URLSearchParams()
  for (const [key, value] of Object.entries(details)) {
    if (value !== null && value !== undefined && value !== '') params.set(key, String(value))
  }
  if ((params.size || ['home', 'cases', 'drafts'].includes(page)) && projectId.value) params.set('project', projectId.value)
  const hash = '#/' + page + (params.size ? '?' + params : '')
  if (location.hash !== hash) {
    history[replace ? 'replaceState' : 'pushState'](null, '', location.pathname + location.search + hash)
  }
}
function go(page, updateAddress = true, details = {}) {
  if ((!hasAdmin.value && ['accounts', 'model'].includes(page)) || (!canWrite.value && page === 'drafts') || (offline && ['delivery', 'cases'].includes(page))) page = 'home'
  if (!offline && page === 'home' && !project.value) page = 'projects'
  if (updateAddress) writeAddress(page, details)
  route.value = page
  query.value = ''
  taskFilter.value = ''
  mobileNav.value = false
  projectMenu.value = false
  if (page === 'documents') {
    chosenDoc.value = details.doc || ''
    chosenVersion.value = details.version || ''
    editing.value = false
    compareSources.value = false
    sourceFocusLine.value = details.line || null
    sourceFocusColumn.value = details.column || null
  }
  if (page === 'delivery') deliveryTarget.value = { documentId: details.doc || '', versionId: details.version || '', runId: details.run || '' }
  if (page === 'reviews') {
    chosenRun.value = details.run || ''
    selectedFinding.value = details.finding || ''
    showRunRevision.value = details.panel === 'revision'
  }
  if (page === 'reports') chosenReport.value = details.run || ''
  if (page === 'model' || (page === 'drafts' && modelReady.value && !modelDestination.value)) loadModel()
  if (page === 'team') loadMembers()
  if (page === 'projects' && loaded.value && (projectId.value || updateAddress)) refreshProjectDirectory()
  if (page === 'home' || page === 'issues') loadProjectIssues()
  if (page === 'reports') loadReportIssues()
  if (page === 'accounts') loadAccounts()
  window.scrollTo({ top: 0 })
}
let restoringAddress = ''
async function onAddressChanged() {
  if (offline || !session.value?.user || !loaded.value || restoringAddress === location.href) return
  const address = location.href
  restoringAddress = address
  const page = routeFromAddress()
  const query = location.hash.split('?')[1] || ''
  const params = new URLSearchParams(query)
  const requestedProject = params.get('project')
  const details = {}
  try {
    if (requestedProject && requestedProject !== projectId.value) {
      if (!await refresh(requestedProject, () => location.href === address)) return
      resetProjectForms()
    }
    const runId = params.get('run')
    const docId = params.get('doc')
    const versionId = params.get('version')
    if (runId && (page === 'reports' || page === 'reviews')) {
      const target = runs.value.find(item => item.id === runId)
      if (!target || (page === 'reports' && inProgress(target))) throw new Error('当前项目无法打开这份审查记录。')
      details.run = target.id
      if (page === 'reviews' && !inProgress(target) && params.get('panel') === 'revision') details.panel = 'revision'
      if (page === 'reviews' && params.get('finding')) {
        const version = lookupVersion(target.documentId, target.versionId)
        const exists = reviewProblems(target, version, { includeRejected: true }).some(p => p.id === params.get('finding'))
        if (exists) details.finding = params.get('finding')
        else notify('这条问题已无法定位，已打开原审查任务。')
      }
    } else if ((docId || versionId) && (page === 'documents' || page === 'delivery')) {
      const version = lookupVersion(docId, versionId)
      if (!version) throw new Error('当前项目无法打开这个文档版本。')
      details.doc = docId
      details.version = versionId
      if (page === 'delivery' && runId) {
        const target = readyRuns.value.find(r => r.id === runId && r.versionId === versionId && r.documentId === docId)
        if (!target) throw new Error('这份交付记录与文档版本不一致。')
        details.run = target.id
      }
      const line = Number(params.get('line'))
      const column = Number(params.get('column'))
      if (page === 'documents' && Number.isSafeInteger(line) && line > 0 && line <= version.text.split('\n').length) {
        details.line = line
        if (Number.isSafeInteger(column) && column > 0) details.column = column
      }
    }
    go(page, false, details)
    if (route.value !== page) writeAddress(route.value, {}, true)
  } catch (error) {
    if (location.href !== address) return
    if (error.status && ![403, 404].includes(error.status)) { notify(error.message, true); return }
    const fallback = page === 'reports' ? 'reviews' : ['reviews', 'documents'].includes(page) ? page : 'home'
    writeAddress(fallback, {}, true)
    go(fallback, false)
    notify(error.status ? '这个项目当前无法访问。' : error.message, true)
  } finally {
    if (restoringAddress === address) restoringAddress = ''
  }
}
function openDoc(id, startEditing = false) {
  const target = lookupDoc(id)
  if (!target) return
  go('documents', true, { doc: id, version: target.versions[0]?.id })
  if (startEditing) startEdit()
}
function openDocumentSource(documentId, versionId, line, column = null) {
  if (!lookupVersion(documentId, versionId)) return
  go('documents', true, { doc: documentId, version: versionId, line, column })
}
async function focusComparedSource(versionId, line) {
  openDocumentSource(chosenDoc.value, versionId, line)
  await nextTick()
  documentReader.value?.focusLine(line)
}
function rememberDocumentLine(line, column) {
  if (route.value === 'documents' && chosenDoc.value && chosenVersion.value) {
    writeAddress('documents', { doc: chosenDoc.value, version: chosenVersion.value, line, column }, true)
  }
}
function openDelivery(documentId, versionId, runId = '') {
  if (offline) { go('reports'); return }
  go('delivery', true, { doc: documentId, version: versionId, run: runId })
}
function openRun(id, findingId = '') {
  go('reviews', true, { run: id, finding: findingId })
}

function openVersionReview(documentId, versionId) {
  if (!canAudit.value) { go('reviews'); return }
  const previous = lookupDoc(documentId)?.versions.find(item => item.number === lookupVersion(documentId, versionId)?.number - 1)
  const prior = previous && readyRuns.value.find(item => item.versionId === previous.id && item.status !== 'FAILED')
  openReview(documentId, versionId, prior && (prior.mode !== 'MODEL' || modelReady.value) ? prior : null)
}

function openImportLibrary() {
  const details = importForJourney.value ? { flow: 'prepare' } : {}
  closeModal()
  go('cases', true, details)
}

function selectCaseForJourney(documentId, versionId) {
  if (new URLSearchParams(location.hash.split('?')[1]).get('flow') !== 'prepare' || !lookupVersion(documentId, versionId)) return false
  moveFlow(0, { documentId, versionId, baselineId: versionId, runId: '', optionalRevision: false })
  return true
}

function openCaseSource(documentId, versionId) {
  selectCaseForJourney(documentId, versionId)
  openDocumentSource(documentId, versionId)
}

function openCaseReview(documentId, versionId) {
  if (selectCaseForJourney(documentId, versionId)) {
    openDocumentSource(documentId, versionId)
    startFlowReview()
  } else openVersionReview(documentId, versionId)
}

function openCaseRun(id) {
  const task = runs.value.find(item => item.id === id)
  if (task && selectCaseForJourney(task.documentId, task.versionId)) moveFlow(1, { runId: id })
  openRun(id)
}

async function importVerifiedCase(expectedProjectId, caseId) {
  const path = '/api/projects/' + encodeURIComponent(expectedProjectId) + '/cases'
  const result = await api(path + (caseId ? '/' + encodeURIComponent(caseId) : '') + '/import', { method: 'POST' })
  if (expectedProjectId === projectId.value) await refresh(expectedProjectId)
  return result
}

function openRevisionUpload(documentId) {
  if (!lookupDoc(documentId)) return
  openDoc(documentId, offline && canWrite.value)
  if (!offline && canWrite.value) prepareImport('import-version')
}

function useRepairVersion(saved) {
  const reviewed = run.value
  const revised = saved?.versions?.[0]
  if (!reviewed || saved?.id !== reviewed.documentId || !revised) return
  action(async () => {
    await refresh()
    openDoc(saved.id)
    selectVersion(revised.id)
    compareSources.value = true
    moveFlow(3, { documentId: saved.id, versionId: revised.id, baselineId: reviewed.versionId,
      runId: reviewed.id, optionalRevision: false })
    notify(`修正已保存为 V${revised.number}，接下来可以复查。`)
  })
}

function moveFlow(stage, changes = {}) {
  activeFlow.value = { ...activeFlow.value, ...changes, stage }
  if (guideOpen.value) guideStep.value = stage
}

function startFirstStep() {
  if (canWrite.value) {
    requestedStage.value = 'document'
    modalError.value = ''
    modal.value = 'choose-flow-document'
  } else if (journeyDocument.value) prepareExistingDocument(journeyDocument.value.id)
  else go('documents')
}

function prepareExistingDocument(id) {
  const versionId = lookupDoc(id)?.versions[0]?.id
  if (!versionId) return
  journeyDocumentId.value = id
  moveFlow(0, { documentId: id, versionId, baselineId: versionId, runId: '', optionalRevision: false })
  openDoc(id)
}

function openDraftStudio() {
  if (!canWrite.value || busy.value) return
  closeModal()
  go('drafts')
}

function startFlowReview() {
  if (!canAudit.value || !doc.value || !version.value) return
  openVersionReview(doc.value.id, version.value.id)
  if (modal.value === 'review') {
    followReview.value = true
    if (guideOpen.value) guideStep.value = 1
  }
}

function flowToRevision(optionalRevision = false) {
  const reviewed = run.value
  if (!runFlow.value || !reviewed) return
  openDoc(reviewed.documentId)
  const nextVersion = optionalRevision ? reviewed.versionId : chosenVersion.value
  selectVersion(nextVersion)
  moveFlow(3, { versionId: nextVersion, optionalRevision })
}

function flowToDelivery() {
  const { documentId, versionId, runId } = activeFlow.value || {}
  if (!documentId || !versionId) return
  moveFlow(4)
  const reviewed = readyRuns.value.find(item => item.id === runId && item.documentId === documentId && item.versionId === versionId)
  openDelivery(documentId, versionId, reviewed?.id)
}

function continueFlowReview(remaining = false) {
  if (!run.value) return
  openReview(run.value.documentId, run.value.versionId, run.value, remaining)
  if (modal.value === 'review') followReview.value = !!runFlow.value
}

function beginWorkspaceStage(action) {
  if (busy.value) return
  if (!projects.value.length) { openProjectForm(false, 'home', action); return }
  requestedStage.value = action
  modalError.value = ''
  modal.value = 'choose-flow-project'
}

function startProjectStage(stage) {
  if (documents.value.length > 1) {
    requestedStage.value = stage
    modal.value = 'choose-flow-document'
  } else enterWorkspaceStage(stage)
}

function chooseFlowDocument(id) {
  const stage = requestedStage.value
  requestedStage.value = ''
  modal.value = ''
  if (id) {
    if (stage === 'document') prepareExistingDocument(id)
    else {
      journeyDocumentId.value = id
      enterWorkspaceStage(stage)
    }
  } else {
    moveFlow(0, { documentId: '', versionId: '', baselineId: '', runId: '', optionalRevision: false })
    openImport(true)
  }
}

function enterWorkspaceStage(action) {
  const selected = journeyDocument.value
  const { version, result, latest, pending, issue } = journey.value
  if (!version || action === 'document') {
    startFirstStep()
    if (!version && action !== 'document') notify(canWrite.value ? '请先生成或导入一份需求文档。' : '这个项目还没有可以查看的文档。')
    return
  }
  const scope = { documentId: selected.id, versionId: version.id, baselineId: version.id, runId: result?.id || '', optionalRevision: false }
  if (action === 'issue' && issue) {
    openRun(issue.runId, issue.findingId)
  } else if (action === 'delivery') {
    moveFlow(4, scope)
    openDelivery(selected.id, version.id, result?.id)
  } else if (action === 'versions') {
    const previous = result || readyRuns.value.find(r => r.documentId === selected.id && r.status !== 'FAILED' &&
      lookupVersion(r.documentId, r.versionId)?.number < version.number)
    openDoc(selected.id)
    compareSources.value = !offline && selected.versions.length > 1
    if (previous) moveFlow(3, { ...scope, runId: previous.id, baselineId: previous.versionId,
      optionalRevision: !!result && !reviewProblems(result, version).length })
    else {
      moveFlow(0, scope)
      if (canAudit.value) startFlowReview()
    }
  } else {
    const latestNeedsAttention = latest && (inProgress(latest) || latest.status === 'FAILED')
    const usable = action === 'evidence' && result ? result : latestNeedsAttention ? latest : result
    if (usable) {
      const evidence = action === 'evidence' && usable === result
      moveFlow(evidence ? 2 : 1, { ...scope, runId: usable.id })
      openRun(usable.id, evidence ? pending?.id : '')
    } else if (canAudit.value) {
      moveFlow(0, scope)
      openDoc(selected.id)
      startFlowReview()
      if (action === 'evidence') notify('这一版还没有审查结果，请先运行审查。')
    } else { go('reviews'); notify('这一版还没有可查看的审查结果。') }
  }
}

const journeyButton = computed(() => {
  const { next, latest, result, pending, issue, version } = journey.value
  if (next.action === 'document') return canWrite.value ? '准备文档' : '查看文档'
  if (next.action === 'review') return result || latest ? '打开审查任务' : canAudit.value ? (version?.number > 1 ? '复查此版本' : '发起审查') : '查看审查记录'
  if (next.action === 'evidence') return pending ? '进入人工复核' : '打开检查结果'
  if (next.action === 'issue') return issue?.status === 'FIXED' ? '打开修订记录' : '打开问题详情'
  return offline ? '查看报告' : '打开交付清单'
})
watch(() => run.value?.id, async id => {
  issues.value = []
  if (!id) return
  try {
    const rows = await api('/api/reviews/' + id + '/issues')
    if (run.value?.id === id) issues.value = rows
  } catch (error) { if (run.value?.id === id) notify(error.message, true) }
  await loadMembers()
})
watch(() => report.value?.id, async id => {
  reportIssues.value = []
  projectIssues.value = []
  if (!id || route.value !== 'reports') return
  try {
    const rows = await api('/api/reviews/' + id + '/issues')
    if (report.value?.id === id) reportIssues.value = rows
  } catch (error) { if (report.value?.id === id) notify(error.message, true) }
})
function openReport(id) {
  go('reports', true, { run: id })
}
async function loadReportIssues() {
  const id = report.value?.id
  if (!id) return
  try {
    const rows = await api('/api/reviews/' + id + '/issues')
    if (report.value?.id === id) reportIssues.value = rows
  } catch (error) { if (report.value?.id === id) notify(error.message, true) }
}
function revisionKey(id) {
  return draftKey(session.value?.user?.id, projectId.value, doc.value?.id, id)
}
const recoverableVersions = computed(() => {
  revisionDrafts.changed.value
  return canWrite.value ? (doc.value?.versions || []).filter(v => revisionDrafts.read(revisionKey(v.id)) !== null) : []
})
function startEdit() {
  if (!version.value || !canWrite.value) return
  acknowledgedHead.value = ''
  discardDraftId.value = ''
  editText.value = revisionDrafts.read(revisionKey(version.value.id)) ?? version.value.text
  compareSources.value = false
  editing.value = true
}
function updateRevision(text) {
  editText.value = text
  if (editing.value && version.value) revisionDrafts.write(revisionKey(version.value.id), text === version.value.text ? null : text)
}
function resumeRevision(id) {
  selectVersion(id)
  startEdit()
}
function discardRevision(id) {
  revisionDrafts.write(revisionKey(id), null)
  discardDraftId.value = ''
  if (version.value?.id === id) { editText.value = ''; editing.value = false }
}
function selectVersion(id) {
  chosenVersion.value = id
  sourceFocusLine.value = null
  sourceFocusColumn.value = null
  editing.value = false
  if (route.value === 'documents' && chosenDoc.value) writeAddress('documents', { doc: chosenDoc.value, version: id })
}
function notify(message, error = false) {
  toast.value = message
  toastError.value = error
  clearTimeout(toastTimer)
  toastTimer = setTimeout(() => { toast.value = '' }, 5500)
}
async function refresh(requestedProject = projectId.value, accept = () => true) {
  const request = ++fetchId
  const workspace = await api('/api/workspace' + (requestedProject ? '?projectId=' + encodeURIComponent(requestedProject) : offline ? '' : '?directory=true'))
  if (request !== fetchId || !accept()) return false
  state.value = workspace
  projectId.value = workspace.project?.id || requestedProject || ''
  if (projectId.value && session.value?.user) {
    try { localStorage.setItem('req-review-current:' + session.value.user.id, projectId.value) } catch {}
  }
  return true
}
async function refreshProjectDirectory() {
  try {
    await refresh(offline ? projectId.value : '', () => route.value === 'projects')
  } catch (error) {
    if (route.value === 'projects') notify(error.message, true)
  }
}
async function load() {
  loadError.value = ''
  try {
    await refresh()
    loaded.value = true
    loadModel()
  } catch (error) {
    if (error.status === 401) await loadSession()
    else loadError.value = error.message
  }
}
async function loadSession() {
  loginError.value = ''
  try {
    session.value = await api('/api/session')
    sessionLoaded.value = true
    if (session.value.user && !showLoginPreview.value) {
      await openWorkspace()
      await onAddressChanged()
    }
  } catch (error) {
    sessionLoaded.value = true
    loginError.value = error.message
  }
}
async function openWorkspace() {
  loadError.value = ''
  try {
    projectId.value = (offline || routeFromAddress() !== 'projects') && localStorage.getItem('req-review-current:' + session.value.user.id) || ''
  } catch { projectId.value = '' }
  const entry = new URL(location.href)
  const legacyCaseLink = !offline && routeFromAddress() === 'cases' && entry.searchParams.has('project')
  const linked = new URLSearchParams(entry.hash.split('?')[1]).get('project') || (legacyCaseLink && entry.searchParams.get('project'))
  if (legacyCaseLink) {
    entry.searchParams.delete('project')
    if (linked) entry.hash = '/cases?' + new URLSearchParams({ project: linked })
    history.replaceState(history.state, '', entry.pathname + entry.search + entry.hash)
  }
  if (!offline && linked && linked.length <= 64 && linked !== projectId.value) {
    try {
      await refresh(linked)
      loaded.value = true
      loadModel()
      return
    } catch (error) {
      if (![403, 404].includes(error.status)) { loadError.value = error.message; return }
    }
  }
  if (projectId.value) {
    // A previously selected project can disappear after database restoration.
    try { await refresh(); loaded.value = true; loadModel(); return } catch (error) {
      if (![403, 404].includes(error.status)) { loadError.value = error.message; return }
      projectId.value = ''
    }
  }
  await load()
}
async function authenticate(setup, form) {
  await enterAccount(setup ? 'setup' : 'login', form)
}
async function enterAccount(method, form) {
  if (loginBusy.value) return
  loginBusy.value = true
  loginError.value = ''
  try {
    session.value = await api('/api/session/' + method, { method: 'POST', body: form })
    showLoginPreview.value = false
    projectId.value = ''
    await openWorkspace()
    if (offline) go('home')
    else await onAddressChanged()
  } catch (error) {
    loginError.value = error.message
  } finally {
    loginBusy.value = false
  }
}
async function signOut() {
  action(async () => {
    const previousUser = session.value?.user?.id
    session.value = await api('/api/session/logout', { method: 'POST' })
    revisionDrafts.clearForUser(previousUser)
    editText.value = ''
    guideOpen.value = false
    state.value = emptyWorkspace()
    projectId.value = ''
    loaded.value = false
    resetProjectForms()
    go('home')
  })
}
function resetProjectForms() {
  chosenReport.value = ''
  chosenDoc.value = ''
  editing.value = false
  members.value = []
  issues.value = []
  reportIssues.value = []
}
function switchProject(id, page = 'home', stage = '') {
  action(async () => {
    if (id !== projectId.value) {
      await refresh(id)
      resetProjectForms()
    }
    if (modal.value === 'choose-flow-project') modal.value = ''
    requestedStage.value = ''
    go(page)
    if (stage) startProjectStage(stage)
  })
}
function openProjectForm(edit = false, returnPage = 'home', stage = '') {
  requestedStage.value = stage
  projectForm.value = edit && project.value ? { name: project.value.name, description: project.value.description || '' } : { name: '', description: '' }
  projectReturn.value = returnPage
  modalError.value = ''
  modal.value = edit ? 'project-edit' : 'project-new'
}
function storeProject() {
  action(async () => {
    const stage = requestedStage.value
    const edit = modal.value === 'project-edit'
    const saved = await api('/api/projects' + (edit ? '/' + project.value.id : ''), {
      method: edit ? 'PATCH' : 'POST', body: projectForm.value,
    })
    await refresh(saved.id)
    if (!edit) resetProjectForms()
    modal.value = ''
    requestedStage.value = ''
    go(projectReturn.value)
    if (stage) startProjectStage(stage)
    else notify(edit ? '项目资料已更新' : '项目已创建')
  })
}
async function loadModel() {
  if (modelLoading.value) return
  modelLoading.value = true
  modelError.value = ''
  try {
    modelInfo.value = await api('/api/model')
  } catch (error) {
    modelInfo.value = null
    modelError.value = error.message
  } finally {
    modelLoading.value = false
  }
}
async function testModel(profile) {
  modelError.value = ''
  modelTesting.value = profile
  try {
    modelResults.value = { ...modelResults.value, [profile]: await api('/api/model/test', { method: 'POST', body: { profile } }) }
  } catch (error) {
    modelError.value = error.message
  } finally {
    modelTesting.value = ''
  }
}
async function checkReviewService() {
  const current = run.value
  if (!current || !hasAdmin.value || reviewProbe.value.pending) return
  reviewProbe.value = { id: current.id, pending: true, success: false, message: '' }
  try {
    const result = await api('/api/model/test', { method: 'POST', body: { profile: current.profile || 'PRIMARY' } })
    const reason = reviewInterruption({ mode: 'MODEL', status: 'FAILED', modelTrace: result.modelTrace })
    const available = reviewInterruption(current)?.billing
      ? '连通性探针已响应。完整审查仍取决于可用额度，请先核对账户额度。'
      : '服务已响应，可以重新提交模型审查。'
    reviewProbe.value = { id: current.id, pending: false, success: result.success,
      message: result.success ? available : reason?.detail || '服务尚未恢复，请稍后再检查。' }
  } catch {
    reviewProbe.value = { id: current.id, pending: false, success: false, message: '暂时无法检查模型服务状态，请稍后重试。' }
  }
}
async function loadMembers() {
  const id = projectId.value
  if (!id) return
  const request = ++membersRequest
  memberError.value = ''
  try {
    const rows = await api('/api/projects/' + id + '/members')
    if (id === projectId.value && request === membersRequest) members.value = rows
  } catch (error) {
    if (id === projectId.value && request === membersRequest) memberError.value = error.message
  }
}
function updateProjectMembers(method, body, message, memberId = '', onSuccess) {
  const id = projectId.value
  const path = '/api/projects/' + id + '/members' + (memberId ? '/' + memberId : '')
  action(async () => {
    const rows = await api(path, { method, body })
    if (id !== projectId.value) return
    membersRequest += 1
    members.value = rows
    memberError.value = ''
    onSuccess?.()
    notify(message)
  })
}
function inviteMember(username, onSuccess) {
  updateProjectMembers('POST', { username }, '项目已共享，对方可从「我的项目」打开', '', onSuccess)
}
function saveMember(payload) {
  updateProjectMembers('PUT', payload, '已保存成员权限')
}
function removeMember(id) {
  updateProjectMembers('DELETE', undefined, '已取消该成员的项目访问', id)
}
function saveIssue(findingId, payload) {
  action(async () => {
    const id = run.value.id
    await api('/api/reviews/' + id + '/issues/' + findingId, { method: 'PATCH', body: payload })
    const rows = await api('/api/reviews/' + id + '/issues')
    if (run.value?.id === id) issues.value = rows
    notify('问题跟进已保存')
  })
}
async function loadProjectIssues() {
  const id = projectId.value
  if (!id) return
  issuesLoading.value = true
  issuesError.value = ''
  try {
    const rows = await api('/api/projects/' + id + '/issues')
    if (id === projectId.value) projectIssues.value = rows
  } catch (error) {
    if (id === projectId.value) issuesError.value = error.message
  } finally {
    if (id === projectId.value) issuesLoading.value = false
  }
}
async function loadAccounts() {
  try {
    accounts.value = await api('/api/users')
  } catch (error) {
    notify(error.message, true)
  }
}
function saveAccount() {
  action(async () => {
    await api('/api/users', { method: 'POST', body: accountForm.value })
    accountForm.value = { username: '', displayName: '', password: '' }
    await loadAccounts()
    notify('账户已创建')
  })
}
onMounted(() => {
  mobileBreakpoint.addEventListener('change', resetMobileMenu)
  window.addEventListener('popstate', onAddressChanged)
  window.addEventListener('hashchange', onAddressChanged)
  loadSession()
  pollTimer = setInterval(async () => {
    if (!busy.value && !restoringAddress && session.value?.user && loaded.value && runs.value.some(inProgress)) {
      try { await refresh() } catch (error) { if (error.status === 401) await loadSession() }
    }
  }, 2200)
})
onBeforeUnmount(() => {
  mobileBreakpoint.removeEventListener('change', resetMobileMenu)
  clearInterval(pollTimer)
  clearTimeout(toastTimer)
  window.removeEventListener('popstate', onAddressChanged)
  window.removeEventListener('hashchange', onAddressChanged)
})
async function action(callback) {
  if (busy.value) return
  busy.value = true
  modalError.value = ''
  try {
    await callback()
  } catch (error) {
    if (error.status === 401) {
      modal.value = ''
      await loadSession()
      loginError.value = '登录已过期，请重新登录。'
    } else if (modal.value) modalError.value = error.message
    else notify(error.message, true)
  } finally {
    busy.value = false
  }
}
function openImport(forJourney = false) {
  if (!project.value) { openProjectForm(); return }
  if (!canWrite.value) return
  prepareImport('import', forJourney === true)
}
function prepareImport(kind, forJourney = false) {
  importForJourney.value = forJourney
  importTab.value = 'file'
  importForm.value = { title: '', text: '' }
  chosenFile.value = null
  modalError.value = ''
  modal.value = kind
}
function openReview(documentId, versionId, priorRun = null, remaining = false) {
  if (!project.value) { openProjectForm(); return }
  if (!canAudit.value) return
  followReview.value = false
  forceFreshReview.value = false
  const selected = lookupDoc(documentId) || documents.value[0]
  const selectedVersionId = versionId || selected?.versions[0]?.id || ''
  const sameVersion = priorRun?.versionId === selectedVersionId
  const priorPack = savedPackForRun(priorRun)
  const currentTemplate = priorPack && !priorPack.basePackId ? lookupPack(priorPack.id) : null
  reviewPackNotice.value = ''
  reviewPackChoice.value = priorPack || state.value.packs[0] || null
  if (priorPack?.basePackId && !lookupPack(priorPack.id)) {
    reviewPackNotice.value = '上次使用的项目审查包已归档，请选择此次使用的审查包。'
    reviewPackChoice.value = null
  } else if (currentTemplate && currentTemplate.version !== priorPack.version) {
    reviewPackChoice.value = currentTemplate
    reviewPackNotice.value = '本次使用已更新的「' + currentTemplate.name + '」V' + currentTemplate.version + '。上次报告使用 V' + priorPack.version + '。'
  } else if (priorPack && !priorPack.rules?.length) {
    reviewPackNotice.value = '上次审查的旧版规则未留存，请选择此次使用的审查包。'
    reviewPackChoice.value = null
  }
  reviewForm.value = {
    documentId: selected?.id || '',
    versionId: selectedVersionId,
    packId: reviewPackChoice.value?.id || '',
    packVersion: reviewPackChoice.value?.version,
    mode: modelReady.value && !(sameVersion && priorRun.mode === 'DEMO') ? 'MODEL' : 'DEMO',
  }
  reviewBasisByPack.value = priorRun?.reviewBasis ? { [priorRun.packId]: priorRun.reviewBasis } : {}
  reviewSection.value = ''
  const pending = priorRun?.versionId === reviewForm.value.versionId ? (remaining ? priorRun.scope?.omittedItemIds : priorRun.targetItemIds) : null
  const version = lookupVersion(reviewForm.value.documentId, reviewForm.value.versionId)
  reviewResumeIds.value = pending?.length && pending.length !== version?.items?.length ? pending : []
  modalError.value = ''
  modal.value = 'review'
  if (modelReady.value && !modelDestination.value) loadModel()
}
function selectReviewPack(id) {
  const choice = lookupPack(id) || formPacks.value.find(item => item.id === id)
  if (!choice) return
  reviewPackNotice.value = ''
  reviewPackChoice.value = choice
  reviewForm.value.packId = id
  reviewForm.value.packVersion = choice.version
  if (reviewProfile.value.requiresModel && modelReady.value) reviewForm.value.mode = 'MODEL'
}
function startPackReview(id) {
  openReview()
  if (modal.value === 'review') selectReviewPack(id)
}
function saveProjectPack(pack, sourceProjectId) {
  if (project.value?.id !== sourceProjectId) return
  const index = state.value.packs.findIndex(item => item.id === pack.id)
  if (index === -1) state.value.packs.push(pack)
  else state.value.packs.splice(index, 1, pack)
  chosenPack.value = pack.id
  notify('项目审查包已保存至 V' + pack.version)
}
function changeTarget(id) {
  reviewForm.value.documentId = id
  reviewForm.value.versionId = lookupDoc(id)?.versions[0]?.id || ''
}
function closeModal() {
  if (!busy.value) modal.value = ''
}
watch(modal, value => {
  if (value) {
    mobileNav.value = false
    requestAnimationFrame(() => document.querySelector('.dialog h2')?.focus())
  }
})
function pick(file) {
  if (!file) return
  chosenFileDigest.value = ''
  const allowed = offline ? /\.(txt|docx|md|rst)$/i : /\.(txt|docx|md|markdown|rst|pdf)$/i
  if (!allowed.test(file.name) || file.size > 8 * 1024 * 1024) {
    chosenFile.value = null
    modalError.value = file.size > 8 * 1024 * 1024 ? '原件大小需在 8 MB 内。'
      : offline ? '请选择 DOCX、TXT、Markdown 或 RST。PDF 由 Spring Boot 服务解析。' : '请选择 DOCX、带文本的 PDF、TXT、Markdown 或 RST。'
    return
  }
  chosenFile.value = file
  modalError.value = ''
  if (modal.value === 'import' && globalThis.crypto?.subtle) {
    file.arrayBuffer().then(bytes => crypto.subtle.digest('SHA-256', bytes)).then(digest => {
      if (chosenFile.value === file) chosenFileDigest.value = Array.from(new Uint8Array(digest),
        byte => byte.toString(16).padStart(2, '0')).join('')
    }).catch(() => {})
  }
}
const comparableSource = text => (text || '').replace(/\r\n?/g, '\n').replace(/\n+$/, '')
const previousImport = computed(() => {
  if (offline || modal.value !== 'import') return null
  const fileMode = importTab.value === 'file'
  const text = fileMode ? '' : comparableSource(importForm.value.text)
  if (fileMode ? !chosenFile.value || !chosenFileDigest.value : !text.trim()) return null
  for (const document of documents.value) {
    const version = document.versions.find(item => fileMode
      ? item.source?.fileSha256 === chosenFileDigest.value : comparableSource(item.text) === text)
    if (version) return { document, version }
  }
  return null
})
function openPreviousImport() {
  if (!previousImport.value || busy.value) return
  const { document, version } = previousImport.value
  closeModal()
  openDocumentSource(document.id, version.id)
  if (activeFlow.value?.stage === 0) moveFlow(0, { documentId: document.id, versionId: version.id, baselineId: version.id })
}
function importDoc() {
  action(async () => {
    const parentId = modal.value === 'import-version' ? doc.value.id : null
    let saved
    if (importTab.value === 'file') {
      const data = new FormData()
      data.append('file', chosenFile.value)
      if (!parentId) data.append('projectId', projectId.value)
      const path = parentId ? '/api/documents/' + parentId + '/versions/import' : '/api/documents/import'
      saved = await api(path, { method: 'POST', body: data })
    } else {
      saved = await api('/api/documents', { method: 'POST', body: { ...importForm.value, projectId: projectId.value } })
    }
    await refresh()
    modal.value = ''
    openDoc(saved.id)
    if (activeFlow.value && ((parentId && documentFlow.value?.stage === 3) || (!parentId && activeFlow.value.stage === 0 && !activeFlow.value.documentId))) {
      moveFlow(parentId ? 3 : 0, { documentId: saved.id, versionId: chosenVersion.value,
        baselineId: activeFlow.value.baselineId || chosenVersion.value, optionalRevision: false })
    }
    if (parentId) compareSources.value = true
    notify(parentId ? '已导入修订版并打开检查对照' : '文档已导入')
  })
}
function saveVersion() {
  action(async () => {
    const id = doc.value.id
    const ownerProject = projectId.value
    const base = version.value.id
    const expectedHead = doc.value.versions[0].id
    const key = revisionKey(base)
    if (base !== expectedHead && acknowledgedHead.value !== expectedHead) return
    let saved
    try {
      saved = await api('/api/documents/' + id + '/versions', {
        method: 'POST', body: { text: editText.value, expectedLatestVersionId: expectedHead },
      })
    } catch (error) {
      if (error.status === 409 && projectId.value === ownerProject) {
        acknowledgedHead.value = ''
        await refresh(ownerProject)
      }
      throw error
    }
    revisionDrafts.write(key, null)
    if (projectId.value !== ownerProject) return
    state.value.documents = [saved, ...state.value.documents.filter(item => item.id !== id)]
    if (route.value !== 'documents' || doc.value?.id !== id || version.value?.id !== base) return
    openDoc(id)
    if (documentFlow.value?.stage === 3) moveFlow(3, { versionId: chosenVersion.value, optionalRevision: false })
    notify('已保存为新版本')
  })
}
function runReview() {
  if (!canSubmitReview.value) return
  action(async () => {
    const reviewed = await api('/api/reviews', { method: 'POST', body: { ...reviewForm.value, async: !offline,
      ...(!offline ? { executionStrategy: reviewForm.value.mode === 'MODEL' ? 'COMBINED' : 'LOCAL_ONLY' } : {}),
      ...(hasPreviousReview.value && forceFreshReview.value ? { forceFresh: true } : {}),
      ...(reviewProfile.value.context && reviewBasis.value.trim() ? { reviewBasis: reviewBasis.value.trim() } : {}),
      itemIds: !reviewUsesRules.value && (reviewSection.value || reviewResumeIds.value.length) ? targetItems.value.map(item => item.id) : [] } })
    await refresh()
    modal.value = ''
    if (followReview.value) {
      const same = activeFlow.value?.documentId === reviewed.documentId
      moveFlow(1, { documentId: reviewed.documentId, versionId: reviewed.versionId, runId: reviewed.id,
        baselineId: (same && activeFlow.value.stage !== 0 && activeFlow.value.baselineId) || reviewed.versionId, optionalRevision: false })
    }
    openRun(reviewed.id)
    const message = reviewed.submissionDisposition === 'REUSED' ? '已打开相同条件下的完整结果，保留了原有复核记录。'
      : reviewed.submissionDisposition === 'IN_PROGRESS' ? '相同条件的审查正在执行，已打开该任务。'
      : reviewed.status === 'FAILED' ? reviewInterruption(reviewed)?.label || '任务未完成，请查看任务诊断'
      : inProgress(reviewed) ? (isLocalRuleReview(reviewed) ? '已提交本地规则检查' : '已提交后台审查')
      : (isLocalRuleReview(reviewed) ? '本地规则检查已完成' : '已生成审查结果')
    notify(message, reviewed.status === 'FAILED')
  })
}
function settle(findingId, decision, note) {
  action(async () => {
    await api('/api/reviews/' + run.value.id + '/findings/' + findingId, { method: 'PATCH', body: { decision, note } })
    await refresh()
    notify(decision === 'CONFIRMED' ? '已确认问题' : '已驳回疑点')
  })
}
function generateDraft() {
  if (!project.value || !canWrite.value || !draftForm.value.goal.trim() || (modelReady.value && !modelDestination.value)) return
  const sourceProject = projectId.value
  const author = session.value?.user?.id
  action(async () => {
    draftGenerating.value = true
    draftError.value = ''
    try {
      const result = await api('/api/drafts', { method: 'POST', body: { ...draftForm.value, mode: modelReady.value ? 'MODEL' : 'DEMO' } })
      if (sourceProject !== projectId.value || author !== session.value?.user?.id) return
      draft.value = result
      notify('草稿已生成，可以核对并编辑。')
    } catch (error) {
      if (error.status === 401) throw error
      if (sourceProject === projectId.value && author === session.value?.user?.id) draftError.value = error.message
    } finally { draftGenerating.value = false }
  })
}
function saveDraft(startReview = false) {
  if (!project.value || !canWrite.value || !draft.value?.text.trim() || !draft.value?.title.trim()) return
  const sourceProject = projectId.value
  const author = session.value?.user?.id
  action(async () => {
    const saved = await api('/api/documents', { method: 'POST', body: { title: draft.value.title, text: draft.value.text, projectId: sourceProject } })
    if (sourceProject !== projectId.value || author !== session.value?.user?.id) return
    state.value = { ...state.value, documents: [saved, ...state.value.documents.filter(item => item.id !== saved.id)] }
    draft.value = null
    draftForm.value = { ...newDraftForm(), goal: project.value?.description || '' }
    draftError.value = ''
    prepareExistingDocument(saved.id)
    notify('已将需求文档保存为 V1。')
    if (startReview) startFlowReview()
  })
}
function download(content, name) {
  const url = URL.createObjectURL(new Blob(['\uFEFF', content], { type: 'text/markdown;charset=utf-8' }))
  const link = document.createElement('a')
  link.href = url
  link.download = name
  link.click()
  setTimeout(() => URL.revokeObjectURL(url), 5000)
}
function exportReport(format = 'md') {
  action(async () => {
    const data = await api('/api/reviews/' + report.value.id + '/report')
    const r = data.run
    const v = lookupVersion(r.documentId, r.versionId)
    const { listed: problems, excluded, inconclusive, message, sourceSummary } = reviewResult(r, v)
    const problemTitles = new Map((r.findings || []).map(finding => [finding.id, plainFinding(finding).title]))
    const titleFor = id => problemTitles.get(id) || '历史记录（' + id + '）'
    const decisions = data.decisions || []
    const currentIssues = data.issues || await api('/api/reviews/' + r.id + '/issues')
    const interruption = reviewInterruption(r)
    const output = [
      '# ' + data.documentTitle + ' · 审查报告', '',
      '- 文档版本：V' + data.versionNumber,
      ...(data.packName || savedPackLabel(r) ? ['- 审查包：' + (savedPackLabel(r) || data.packName)] : []),
      ...(reviewTemplateId(r) === 'legal-risk' ? ['- AI 依据中国大陆《个人信息保护法》进行风险初筛。法规适用性和最终法律意见由合规或法务人员确认。'] : []),
      '- 检查方式：' + runMode(r),
      ...(combinedScopeLabel(r) ? ['- 检查范围：' + combinedScopeLabel(r)] : []),
      ...(v?.source?.fileName ? ['- 原件：' + v.source.fileName] : []),
      '- 任务状态：' + runStatus(r),
      '- 审查时间：' + displayStamp(r.createdAt),
      ...(interruption ? ['- 本次检查未完成：' + interruption.detail] : []),
      ...(incompleteReport(r) && !interruption ? ['- 本次检查未完成。以下仅列出已有原文依据的问题。'] : []),
      ...(inconclusive ? [] : ['- 报告所列问题：' + problems.length + ' 个']),
      ...(sourceSummary ? ['- 问题来源：' + sourceSummary] : []),
      ...(message ? ['- 结果说明：' + message] : []), '',
      ...(problems.length ? ['## 问题明细', '', ...problems.flatMap(problem => [
        '### ' + problem.title, '',
        '- 发现方式：' + problemSourceLabel(problem),
        ...(problem.impact ? ['- 会有什么影响：' + problem.impact] : []),
        ...(problem.action ? ['- 建议怎么改：' + problem.action] : []),
        ...problem.evidence.map(e => '- ' + (e.label || '原文') + '（' + sourceLocation(v, e.line) + '）' + (e.quote ? '：' + e.quote : '')),
        ...(problem.basisEvidence || []).map(e => '- ' + basisEvidenceLabel(r) + (e.code ? '（' + e.code + '）' : '') + '：' + e.quote),
        ...(problem.finding ? ['- 人工复核：' + (labels[problem.finding.decision] || '待复核')] : []),
        ...(problem.finding?.note ? ['- 复核备注：' + problem.finding.note] : []), '',
      ])] : []),
      ...(excluded.length ? [
        '## 人工排除的疑点（' + excluded.length + ' 条）', '',
        ...excluded.flatMap(problem => ['### ' + problem.title,
          '- 发现方式：' + problemSourceLabel(problem),
          ...problem.evidence.map(e => '- ' + sourceLocation(v, e.line) + '：' + e.quote),
          '- 排除原因：' + (problem.finding.note || '未填写'),
          ...(problem.finding.decidedAt ? ['- 复核时间：' + problem.finding.decidedAt] : []), '']),
      ] : []),
      ...(decisions.length ? [
        '## 复核历史', '', ...decisions.map(d => '- ' + d.createdAt + ' · ' +
          titleFor(d.findingId) + ' · ' +
          labels[d.priorDecision] + ' → ' + labels[d.newDecision] + (d.note ? ' · ' + d.note : '')), '',
      ] : []),
      ...(currentIssues.length ? [
        '## 问题跟进', '',
        ...currentIssues.flatMap(item => [
          '### ' + titleFor(item.findingId),
          '- 状态：' + issueStates[item.status],
          '- 负责人：' + (item.assigneeName || '未分派'),
          '- 截止日期：' + (item.dueDate || '未设置'),
          ...(item.resolutionVersionId ? ['- 修订版本：V' + (lookupVersion(r.documentId, item.resolutionVersionId)?.number || '—')] : []),
          ...(item.history || []).map(entry => '- ' + entry.createdAt + ' · ' + (entry.actorName || '团队成员') + ' · ' +
            (issueStates[entry.toStatus] || '') + (entry.note ? ' · ' + entry.note : '')), '',
        ]),
      ] : []),
    ]
    const filename = data.documentTitle.replace(/[<>:"/\\|?*]/g, '_') + '-V' + data.versionNumber + '-审查报告'
    if (format === 'word') downloadWord(filename, output.slice(2).join('\n'))
    else download(output.join('\n'), filename + '.md')
    notify('报告已导出')
  })
}
</script>

<template>
  <LoginScreen v-if="sessionLoaded && (!session?.user || showLoginPreview)" :session="session" :offline="offline" :busy="loginBusy" :error="loginError" @authenticate="authenticate" @register="enterAccount('register', $event)" @demo="authenticate(false, { username: 'demo', password: '' })" />
  <div v-else-if="sessionLoaded" class="shell" @keydown.esc="closeModal">
    <div v-if="mobileNav" class="mobile-scrim" aria-hidden="true" @click="mobileNav = false"></div>
    <aside id="workspace-navigation" class="sidebar" :class="{ 'mobile-open': mobileNav }" :inert="!!modal"
      :role="mobileNav ? 'dialog' : undefined" :aria-modal="mobileNav ? 'true' : undefined" aria-label="工作区导航" @keydown="handleMobileMenuKey">
      <button ref="mobileMenuClose" class="icon-button mobile-menu-close" type="button" aria-label="关闭菜单" @click="mobileNav = false"><X :size="21" /></button>
      <button class="brand" @click="go(offline ? 'home' : 'projects')">
        <span class="brand-mark"><ScanLine :size="23" :stroke-width="2.2" /></span>
        <span><strong>需求审查</strong><small>软件需求工作空间</small></span>
      </button>
      <div class="project-switch">
        <button class="project-switch-button" :aria-expanded="projectMenu" @click="projectMenu = !projectMenu"><span class="project-icon"><FolderKanban :size="17" /></span><span class="project-switch-name"><small>当前项目</small><strong>{{ project?.name || '选择项目' }}</strong></span><ChevronDown :size="15" /></button>
        <div v-if="projectMenu" class="project-options">
          <button v-for="item in projects" :key="item.id" :disabled="busy" @click="switchProject(item.id)"><strong>{{ item.name }}</strong><Check v-if="item.id === projectId" :size="14" /></button>
          <button @click="go('projects')"><FolderKanban :size="15" /> 我的项目</button>
          <button @click="projectMenu = false; openProjectForm()"><Plus :size="15" /> 创建项目</button>
        </div>
      </div>
      <nav aria-label="主导航">
        <button class="overview-link" :class="{ active: ['home','projects'].includes(route) }" :aria-current="['home','projects'].includes(route) ? 'page' : undefined" @click="go(project ? 'home' : 'projects')"><LayoutGrid :size="18" /><span>{{ project ? '项目概览' : '工作台首页' }}</span><ChevronRight v-if="['home','projects'].includes(route)" :size="14" class="nav-arrow" /></button>
        <div v-for="group in navigationGroups" :key="group.title" class="nav-group" role="group" :aria-label="group.title">
          <div class="nav-section-title">{{ group.title }}</div>
            <button v-for="item in navGroupItems(group)" :key="item.key" :data-coach="'nav-' + item.key" :class="{ active: navActive(item.key) }" :aria-current="navActive(item.key) ? 'page' : undefined" @click="go(item.key)">
            <component :is="item.icon" :size="18" :stroke-width="1.8" /><span>{{ item.label }}</span><ChevronRight v-if="navActive(item.key)" :size="14" class="nav-arrow" />
          </button>
        </div>
        <details class="nav-disclosure" :open="['team', 'usage'].includes(route)">
          <summary><UsersRound :size="17" /><span>项目管理</span><ChevronDown :size="14" /></summary>
          <div class="nav-disclosure-items">
            <button v-for="item in projectNav.filter(item => ['team', 'usage'].includes(item.key))" :key="item.key" :class="{ active: route === item.key }" :aria-current="route === item.key ? 'page' : undefined" @click="go(item.key)"><component :is="item.icon" :size="17" /><span>{{ item.label }}</span></button>
          </div>
        </details>
      </nav>
      <details class="nav-disclosure" :open="settings.some(item => item.key === route)">
        <summary><Settings2 :size="17" /><span>工作区设置</span><ChevronDown :size="14" /></summary>
        <nav class="nav-disclosure-items" aria-label="工作空间设置">
          <button v-for="item in settings.filter(item => item.key === 'packs' || hasAdmin)" :key="item.key" :class="{ active: route === item.key }" :aria-current="route === item.key ? 'page' : undefined" @click="go(item.key)">
            <component :is="item.icon" :size="17" /><span>{{ item.label }}</span>
          </button>
        </nav>
      </details>
      <button class="nav-help" @click="openGuide"><BookOpen :size="17" /> 新手引导</button>
      <div class="sidebar-bottom">
        <div class="workspace-icon">{{ accountName.slice(0, 2) }}</div>
        <div class="account-id"><strong>{{ accountName }}</strong><small>{{ hasAdmin ? '管理员' : '项目用户' }}</small></div>
        <button class="icon-button sign-out" aria-label="退出登录" title="退出登录" :disabled="busy" @click="signOut"><LogOut :size="17" /></button>
      </div>
    </aside>

    <div class="main-shell" :inert="!!modal || mobileNav">
      <header class="topbar">
        <div class="breadcrumb"><button ref="mobileMenuButton" class="icon-button mobile-menu" aria-label="打开菜单" aria-controls="workspace-navigation" :aria-expanded="mobileNav" data-coach="mobile-menu" @click="mobileNav = true"><Menu :size="21" /></button><button class="text-button" @click="go('projects')">项目</button><ChevronRight :size="14" /><strong>{{ currentNav }}</strong></div>
        <div v-if="loaded" class="topbar-tools"><span v-if="project" class="workspace-role">{{ projectIdentity(projectRole) }}</span><span class="mode-badge" :class="{ 'model-mode': modelReady }"><i></i>{{ modelReady ? 'AI 审查已启用' : offline ? '演示模式' : '本地规则检查' }}</span></div>
      </header>

      <main class="content">
        <div v-if="!loaded" class="panel empty">
          <Activity :size="32" /><h2>{{ loadError ? '暂时无法加载工作空间' : '正在加载工作空间' }}</h2>
          <p v-if="loadError">{{ loadError }}</p><button v-if="loadError" class="button primary" @click="loadSession">重试</button>
        </div>
        <template v-else-if="route === 'projects' || (!project && route === 'home')">
          <div class="page-heading"><div><h1>需求审查工作台</h1><p>从第一份原文开始，或选择一个阶段继续工作。</p></div></div>
          <section class="panel journey-panel workspace-flow" aria-labelledby="workspace-flow-title">
            <header class="journey-heading"><h2 id="workspace-flow-title">需求审查流程</h2></header>
            <WorkflowSteps :steps="workflowSteps" :labels="workflowDescriptions" :busy="busy" @select="beginWorkspaceStage" />
            <div class="journey-next">
              <div class="journey-next-copy"><h3>准备需求文档</h3><p>{{ projects.length ? '选择项目后，可以从业务说明生成需求文档、导入原件，或继续已有文档。' : '创建项目后，可以从业务说明生成需求文档，也可以导入原件。' }}</p></div>
              <button type="button" class="button primary journey-next-action" data-coach="begin-flow" data-home-start :disabled="busy" @click="beginWorkspaceStage('document')">从第一步开始 <ArrowRight :size="16" /></button>
            </div>
          </section>
          <div class="journey-heading directory-heading"><h2>我的项目</h2><button class="button secondary small" data-coach="create-project" :disabled="busy" @click="openProjectForm()"><Plus :size="16" /> 创建项目</button></div>
          <p v-if="!projects.length" class="directory-empty">你创建或受邀加入的项目会显示在这里。</p>
          <div v-else class="project-cards">
            <button v-for="item in projects" :key="item.id" class="panel project-card" :disabled="busy" @click="switchProject(item.id)"><span class="metric-icon blue"><FolderKanban :size="20" /></span><strong>{{ item.name }}</strong><p>{{ item.description || '查看需求文档与审查记录' }}</p><div><span>{{ item.role === 'OWNER' ? '我创建的' : '受邀加入' }} · {{ displayDate(item.updatedAt) }}</span><ArrowUpRight :size="17" /></div></button>
          </div>
        </template>
        <template v-else-if="projectEntry">
          <div class="page-heading"><div><h1>{{ missingProjectTitle }}</h1><p>{{ projectEntry }}</p></div></div>
          <section class="panel empty project-empty section-entry">
            <span class="metric-icon blue"><FolderKanban :size="22" /></span>
            <h2>先创建或打开一个项目</h2>
            <p>完成后会回到「{{ missingProjectTitle }}」。</p>
            <div class="actions">
              <button class="button primary" data-coach="create-project" :disabled="busy" @click="openProjectForm(false, route)"><Plus :size="17" /> 创建项目</button>
              <WorkspaceSelect v-if="projects.length" :options="projects.map(p => ({ value: p.id, label: p.name }))" placeholder="打开已有项目" label="打开已有项目" :disabled="busy" @update:model-value="switchProject($event, route)" />
            </div>
          </section>
        </template>
        <template v-else-if="route === 'home'">
          <section class="overview-lead" aria-labelledby="overview-title">
            <div class="overview-lead-copy">
              <h1 id="overview-title">{{ project?.name }}</h1>
              <p v-if="project?.description">{{ project.description }}</p>
              <div v-if="canWrite" class="actions overview-actions">
                <button class="button overview-primary" @click="openImport"><UploadCloud :size="16" /> 导入需求</button>
                <button class="button overview-secondary" data-project-generate @click="openDraftStudio"><Sparkles :size="16" /> 一键生成需求文档</button>
                <button v-if="projectRole === 'OWNER'" class="button overview-secondary" @click="openProjectForm(true)"><Settings2 :size="15" /> 编辑项目</button>
              </div>
            </div>
            <dl class="overview-totals">
              <div><dt>需求文档</dt><dd>{{ documents.length }}</dd></div>
              <div><dt>审查任务</dt><dd>{{ runs.length }}</dd></div>
              <div><dt>待复核问题</dt><dd>{{ outstanding.length }}</dd></div>
            </dl>
          </section>

          <section class="panel journey-panel" aria-labelledby="journey-title">
            <header class="journey-heading">
              <h2 id="journey-title">需求审查流程</h2>
              <div class="journey-heading-tools">
                <div v-if="documents.length" class="journey-target">
                  <span>当前文档</span>
                  <WorkspaceSelect :model-value="journeyDocument?.id" :options="journeyOptions" label="选择流程文档" @update:model-value="journeyDocumentId = $event" />
                </div>
                <button v-if="documents.length" class="button secondary small" data-coach="begin-flow" @click="startFirstStep">从第一步开始 <ArrowRight :size="15" /></button>
              </div>
            </header>
            <WorkflowSteps :steps="workflowSteps" :labels="journey.labels" :available="journey.availability" :visited="journey.visited" :current="journey.next.step" :busy="busy" @select="enterWorkspaceStage" />
            <div class="journey-next" aria-live="polite">
              <div class="journey-next-copy"><small>下一步</small><h3>{{ journey.next.title }}</h3><p>{{ journey.next.text }}</p></div>
              <button class="button primary journey-next-action" :data-coach="documents.length ? null : 'begin-flow'" @click="enterWorkspaceStage(journey.next.action)">{{ journeyButton }} <ArrowRight :size="16" /></button>
            </div>
          </section>

          <div class="dashboard-grid workspace-dashboard">
            <section class="panel dashboard-flow">
              <div class="panel-heading"><div class="panel-title"><ListChecks :size="19" /><h2>待复核</h2></div><button class="text-button" @click="go('issues')">问题工作台 <ArrowRight :size="15" /></button></div>
              <div v-if="!outstanding.length && !sourceAlerts.length" class="empty compact"><Check :size="26" /><p>当前没有待复核事项。</p></div>
              <div v-else class="flow-list">
                <button v-for="{ run, problem } in outstanding.slice(0, 5)" :key="problem.id" @click="openRun(run.id, problem.id)"><span class="flow-icon" :class="'risk-' + problem.finding.severity.toLowerCase()"><CircleAlert :size="16" /></span><span><strong>{{ problem.title }}</strong><small>{{ lookupDoc(run.documentId)?.title }} · V{{ lookupVersion(run.documentId, run.versionId)?.number }}</small></span><ChevronRight :size="14" /></button>
                <button v-for="{ run, count } in sourceAlerts.slice(0, 3)" :key="run.id" @click="openRun(run.id)"><span class="flow-icon risk-medium"><ScanLine :size="16" /></span><span><strong>{{ lookupDoc(run.documentId)?.title }}</strong><small>V{{ lookupVersion(run.documentId, run.versionId)?.number }} · 规则发现 {{ count }} 个问题</small></span><ChevronRight :size="14" /></button>
              </div>
            </section>
            <section class="panel recent-panel">
              <div class="panel-heading"><div class="panel-title"><History :size="19" /><h2>最近审查</h2></div><button class="text-button" @click="go('reviews')">全部任务 <ArrowRight :size="15" /></button></div>
              <div v-if="!runs.length" class="empty compact"><ClipboardCheck :size="27" /><p>导入文档后即可发起审查。</p><button v-if="documents.length && canAudit" class="button secondary small" @click="openReview()">发起审查</button></div>
              <div v-else class="recent-rows">
                <button v-for="r in runs.slice(0, 5)" :key="r.id" class="recent-row" @click="openRun(r.id)">
                  <span class="record-icon"><FileText :size="18" /></span>
                  <span class="record-name"><strong>{{ lookupDoc(r.documentId)?.title || '需求文档' }}</strong><small>V{{ lookupVersion(r.documentId, r.versionId)?.number ?? '—' }} · {{ runMode(r) }}<template v-if="!isLocalRuleReview(r) && savedPackForRun(r)"> · {{ savedPackLabel(r) }}</template></small></span>
                  <span class="recent-date">{{ displayStamp(r.createdAt) }}</span>
                  <span class="pill" :class="runTone(r)">{{ runStatus(r) }}</span>
                  <ChevronRight :size="15" class="row-chevron" />
                </button>
              </div>
            </section>

          </div>
        </template>

        <template v-else-if="route === 'documents' && doc && version">
          <div class="page-heading"><div>
            <button class="text-button back-link" @click="go('documents')">‹ 返回文档库</button><h1>{{ doc.title }}</h1>
            <p>{{ version.items.length }} 个解析条目 · {{ version.sections.length }} 个章节 · {{ displayDate(version.createdAt) }}</p>
          </div><div class="actions"><button class="button secondary" @click="downloadWord(doc.title + ' · V' + version.number, version.text)"><FileDown :size="17" /> 下载 Word</button><button v-if="canWrite && !editing" class="button secondary" @click="startEdit">编辑新版本</button></div></div>
          <section v-if="!editing && recoverableVersions.length" class="panel revision-recovery" aria-label="本标签页中的修订草稿">
            <div v-for="base in recoverableVersions" :key="base.id" class="revision-recovery-row">
              <span>基于 V{{ base.number }} 的修订草稿</span>
              <div v-if="discardDraftId === base.id" class="actions">
                <span>丢弃后无法恢复。</span>
                <button class="button secondary small" @click="discardDraftId = ''">保留草稿</button>
                <button class="button secondary small" @click="discardRevision(base.id)">确认丢弃</button>
              </div>
              <div v-else class="actions">
                <button class="text-button" @click="discardDraftId = base.id">丢弃草稿</button>
                <button class="button secondary small" data-resume-revision @click="resumeRevision(base.id)">继续编辑</button>
              </div>
            </div>
          </section>
          <section v-if="!editing && documentFlow" class="flow-next" aria-label="当前流程与下一步">
            <div>
              <small>第 {{ documentFlow.stage + 1 }} 步 / 共 5 步</small>
              <h2>{{ documentFlow.stage === 0 ? '准备文档' : '修订与复查' }}</h2>
              <p v-if="documentFlow.stage === 0">核对 V{{ version.number }} 的原文与章节，然后进入审查。</p>
              <p v-else-if="canRecheckFlow">V{{ version.number }} 已保存。运行复查后，核对问题是否还存在。</p>
              <p v-else-if="documentFlow.optionalRevision">本轮结果允许按需修订。可先查看本版的交付条件。</p>
              <p v-else>根据原文证据修订，再保存为一个新版本。</p>
            </div>
            <div class="actions">
              <button v-if="documentFlow.stage === 0 && canAudit" class="button primary small" data-coach="prepare-next" @click="startFlowReview">下一步：运行审查 <ArrowRight :size="16" /></button>
              <button v-else-if="documentFlow.stage === 3 && canRecheckFlow && canAudit" class="button primary small" data-coach="revision-next" @click="startFlowReview">复查修订版 <ArrowRight :size="16" /></button>
              <template v-else-if="documentFlow.stage === 3">
                <button v-if="canWrite && !offline" class="button small" :class="documentFlow.optionalRevision ? 'secondary' : 'primary'" data-coach="revision-next" @click="prepareImport('import-version')"><UploadCloud :size="16" /> 上传修订版</button>
                <button v-else-if="canWrite" class="button secondary small" data-coach="revision-next" @click="startEdit">编辑新版本</button>
                <button class="button small" :class="documentFlow.optionalRevision ? 'primary' : 'secondary'" :data-coach="canWrite && !documentFlow.optionalRevision ? null : 'revision-next'" @click="flowToDelivery">{{ documentFlow.optionalRevision ? '下一步：检查交付' : '查看交付条件' }} <ArrowRight :size="16" /></button>
              </template>
              <button v-else class="button secondary small" data-coach="prepare-next" @click="go('reviews')">查看审查记录</button>
            </div>
          </section>
          <section v-else-if="!editing" class="flow-next" aria-label="下一步">
            <div><small>下一步</small><h2>{{ versionRun ? '核对当前版本的审查任务' : version.number > 1 ? '复查已保存的修订版' : '对当前版本发起审查' }}</h2><p>{{ versionRun ? `V${version.number} · ${runStatus(versionRun)}` : version.number > 1 ? '可沿用上一版的规则，再到结果页定位证据。' : '提交前可确认执行方式和版本。' }}</p></div>
            <div class="actions">
              <button v-if="versionRun && canAudit && !inProgress(versionRun)" class="button secondary small" @click="openVersionReview(doc.id, version.id)">重新审查</button>
              <button v-if="versionRun" class="button primary small" @click="openRun(versionRun.id)">打开审查任务 <ArrowRight :size="16" /></button>
              <button v-else-if="canAudit" class="button primary small" @click="openVersionReview(doc.id, version.id)"><ScanLine :size="17" /> {{ version.number > 1 ? '复查此版本' : '审查此版本' }}</button>
            </div>
          </section>
          <div class="document-grid">
            <section class="panel version-panel">
              <div class="panel-heading"><div class="panel-title"><History :size="18" /><h2>版本历史</h2></div></div>
              <button v-for="v in doc.versions" :key="v.id" class="version-row" :class="{ active: v.id === version.id }" @click="selectVersion(v.id)"><strong>V{{ v.number }}{{ doc.versions[0].id === v.id ? ' · 最新版' : '' }}</strong><small>{{ displayStamp(v.createdAt) }}</small></button>
              <div v-if="!offline && (canWrite || doc.versions.length > 1)" class="version-tools" data-coach="version-tools">
                <button v-if="canWrite" class="button secondary small" @click="prepareImport('import-version')"><UploadCloud :size="16" /> 上传修订版</button>
                <button v-if="doc.versions.length > 1" class="button secondary small" :aria-expanded="compareSources" aria-controls="source-check-comparison" @click="editing = false; compareSources = !compareSources"><GitCompareArrows :size="16" /> {{ compareSources ? '收起检查对照' : '对照最近两版' }}</button>
              </div>
              <div v-if="!offline" class="version-delivery"><button class="text-button" @click="openDelivery(doc.id, version.id)">查看该版本交付准备 <ArrowUpRight :size="14" /></button></div>
            </section>
            <section class="panel document-panel">
              <div class="panel-heading"><div class="panel-title"><FileText :size="18" /><h2>{{ editing ? '编辑新版本' : '文档原文' }}</h2></div><span class="pill neutral">V{{ version.number }}</span></div>
              <SourceCheckCompare v-if="!offline && !editing && compareSources && doc.versions.length > 1" :document-id="doc.id" :before="doc.versions[1]" :after="doc.versions[0]" @source="focusComparedSource" />
              <div v-if="editing" class="editor">
                <div v-if="version.id !== doc.versions[0].id" class="revision-base" data-older-base>
                  <strong>正在编辑 V{{ version.number }}，最新版本为 V{{ doc.versions[0].number }}。</strong>
                  <p>从这份旧稿保存会创建新版本，期间其他版本的修改需要手动合并。</p>
                  <button class="text-button" :disabled="busy" @click="selectVersion(doc.versions[0].id)">查看最新版原文</button>
                  <label><input type="checkbox" :checked="acknowledgedHead === doc.versions[0].id" :disabled="busy"
                    @change="acknowledgedHead = $event.target.checked ? doc.versions[0].id : ''">我仍要基于 V{{ version.number }} 保存</label>
                </div>
                <textarea :value="editText" :disabled="busy" rows="17" aria-label="编辑文档原文" @input="updateRevision($event.target.value)"></textarea>
                <p v-if="editText !== version.text" class="revision-draft-note">{{ revisionDrafts.memoryOnly.value ? '浏览器暂时无法暂存草稿，刷新前请保存为新版本。' : '草稿暂存在本标签页，退出账号时清除。' }}</p>
                <div class="actions"><button class="button secondary" :disabled="busy" @click="editing = false">{{ editText !== version.text ? '留存草稿并返回' : '取消' }}</button>
                  <button class="button primary" :disabled="busy || !editText.trim() || editText === version.text || (version.id !== doc.versions[0].id && acknowledgedHead !== doc.versions[0].id)" @click="saveVersion">保存为新版本</button></div>
              </div>
              <DocumentPreview v-else ref="documentReader" :document-id="doc.id" :version="version" :initial-line="sourceFocusLine" :initial-column="sourceFocusColumn" @select-line="rememberDocumentLine" />
            </section>
          </div>
        </template>

        <template v-else-if="route === 'documents'">
          <div class="page-heading"><div><h1>需求文档</h1><p>查看原文和历史版本，选择要审查的版本。</p></div><div class="actions"><button v-if="!canWrite && !offline" class="button secondary" @click="go('cases')"><BookOpen :size="17" /> 公开文档库</button><template v-if="canWrite"><button class="button primary" data-coach="documents-import" @click="openImport"><UploadCloud :size="18" /> 导入文档</button><button class="button secondary" data-library-generate @click="openDraftStudio"><Sparkles :size="18" /> 一键生成需求文档</button></template></div></div>
          <section class="panel">
            <div class="panel-heading list-toolbar"><label class="search"><Search :size="16" /><input v-model="query" type="search" placeholder="搜索文档名称" aria-label="搜索文档名称"></label><span class="count-label">{{ searchDocs.length }} 份文档</span></div>
            <div class="table-scroll"><table v-if="searchDocs.length">
              <thead><tr><th>文档名称</th><th>最新版本</th><th>需求条目</th><th>更新时间</th><th>操作</th></tr></thead>
              <tbody><tr v-for="d in searchDocs" :key="d.id"><td><button class="table-name" @click="openDoc(d.id)"><span class="record-icon"><FileText :size="17" /></span><span><strong>{{ d.title }}</strong><small v-if="d.versions[0]?.source?.format">{{ d.versions[0].source.format.toUpperCase() }}</small></span></button></td><td><span class="pill neutral">V{{ d.versions[0]?.number }}</span></td><td>{{ d.versions[0]?.items.length }}</td><td>{{ displayDate(d.updatedAt) }}</td><td><button v-if="canAudit" class="text-button" @click="openReview(d.id)">发起审查 <ArrowUpRight :size="14" /></button><button v-else class="text-button" @click="openDoc(d.id)">查看文档 <ArrowUpRight :size="14" /></button></td></tr></tbody>
            </table></div>
            <div v-if="!searchDocs.length" class="empty"><Files :size="30" /><p>{{ query ? '未找到匹配的文档' : '文档库为空，请先导入需求文档。' }}</p></div>
          </section>
        </template>

        <template v-else-if="route === 'reviews' && run && inProgress(run)">
          <div class="page-heading"><div><button class="text-button back-link" @click="go('reviews')">‹ 返回审查任务</button><h1>{{ lookupDoc(run.documentId)?.title || '审查任务' }}</h1><p>V{{ lookupVersion(run.documentId, run.versionId)?.number }} · {{ runMode(run) }}<template v-if="!isLocalRuleReview(run) && savedPackForRun(run)"> · {{ savedPackLabel(run) }}</template></p></div></div>
          <div class="panel empty queue-state">
            <span class="metric-icon blue"><Activity :size="24" /></span><h2>{{ runStatus(run) }}</h2>
            <div v-if="!isLocalRuleReview(run) && plannedRunBatches" class="queue-progress"><progress :value="run.scope.details?.length || 0" :max="plannedRunBatches" aria-label="审查批次进度"></progress><span>{{ run.scope.details?.length || 0 }} / {{ plannedRunBatches }} 批已执行</span><small v-if="run.scope.plannedBatches > plannedRunBatches">本次共计划 {{ run.scope.plannedBatches }} 批，预算内执行 {{ plannedRunBatches }} 批。</small></div>
            <p>任务在后台执行。你可以离开此页面，稍后从审查列表查看结果。</p><button class="button secondary" @click="go('reviews')">返回任务列表</button>
          </div>
        </template>
        <ReviewDesk v-else-if="route === 'reviews' && run" :run="run" :document="lookupDoc(run.documentId)" :version="lookupVersion(run.documentId, run.versionId)" :pack="savedPackForRun(run)" :initial-finding="selectedFinding" :open-revision="showRunRevision" :busy="busy"
          :flow-stage="runFlow?.stage" :rechecked="!!runFlow && runFlow.baselineId !== run.versionId"
          :role="projectRole" :members="members" :issues="issues" :current-user="session.user.id" :can-edit="canWrite" :can-audit="canAudit" :can-decide="canDecide" :model-ready="modelReady" :offline="offline"
          :can-probe="hasAdmin" :service-probe="currentReviewProbe" @check-service="checkReviewService"
          @back="go('reviews')" @decision="settle" @issue="saveIssue" @report="openReport" @retry="continueFlowReview()" @continue="continueFlowReview(true)"
          @locate="writeAddress('reviews', { run: run.id, finding: $event }, true)"
          @start-model="openReview(run.documentId, run.versionId)"
          @advance-evidence="moveFlow(2)" @flow-revision="flowToRevision($event)"
          @repairs-applied="useRepairVersion" @repairs-opened="guideOpen && (guideStep = 3)"
          @upload-revision="openRevisionUpload(run.documentId)" @view-revision="openDocumentSource(run.documentId, $event)" @delivery="runFlow ? flowToDelivery() : openDelivery(run.documentId, run.versionId, run.id)" />

        <template v-else-if="route === 'reviews'">
          <div class="page-heading"><div><h1>{{ guideOpen && guideStep === 2 ? '复核证据' : '审查与复核' }}</h1><p>按文档版本追踪执行状态、审查范围和人工结论。</p></div>
            <button v-if="canAudit && documents.length" class="button primary" data-coach="reviews-start" @click="openReview()"><Plus :size="18" /> 发起审查</button>
            <button v-else-if="!documents.length" class="button secondary" data-coach="reviews-start" @click="go('documents')">前往需求文档 <ArrowRight :size="16" /></button>
          </div>
          <section class="panel">
            <div class="panel-heading list-toolbar">
              <label class="search"><Search :size="16" /><input v-model="query" type="search" placeholder="搜索文档名称" aria-label="搜索审查任务"></label>
              <WorkspaceSelect v-model="taskFilter" class="review-task-filter" :options="taskStatusOptions" label="筛选任务状态" />
            </div>
            <div class="table-scroll"><table v-if="searchRuns.length">
              <thead><tr><th>审查文档</th><th>状态</th><th>结果摘要</th><th>创建时间</th><th>操作</th></tr></thead>
              <tbody><tr v-for="r in searchRuns" :key="r.id">
                <td><button class="table-name" :data-coach="guideOpen && r.id === guideSubject.audited?.id ? 'review-result' : null" @click="openRun(r.id)"><span class="record-icon"><ClipboardCheck :size="17" /></span><span><strong>{{ lookupDoc(r.documentId)?.title }}</strong><small>V{{ lookupVersion(r.documentId, r.versionId)?.number }} · {{ runMode(r) }}<template v-if="!isLocalRuleReview(r) && savedPackForRun(r)"> · {{ savedPackLabel(r) }}</template></small></span></button></td>
                <td><span class="pill" :class="runTone(r)">{{ runStatus(r) }}</span></td>
                <td>{{ inProgress(r) ? '审查中' : (runProblemCounts.get(r.id) || 0) + ' 个问题' }}</td>
                <td>{{ displayStamp(r.createdAt) }}</td><td><button class="text-button" @click="openRun(r.id)">打开任务 <ArrowUpRight :size="14" /></button></td>
              </tr></tbody>
            </table></div>
            <div v-if="!searchRuns.length" class="empty"><ClipboardCheck :size="30" /><p>当前条件下没有审查任务。</p></div>
          </section>
        </template>

        <VerifiedCaseLibrary v-else-if="route === 'cases' && project && !offline" :key="project.id"
          :project-id="project.id" :documents="documents" :runs="runs" :can-write="canWrite" :can-audit="canAudit"
          :import-case="importVerifiedCase" :run-status="runStatus" @source="openCaseSource" @audit="openCaseReview" @task="openCaseRun" @back="go('documents')"
          @report="openReport" @delivery="openDelivery" />

        <template v-else-if="route === 'packs'">
          <div class="page-heading"><div><h1>审查包与规则</h1><p>日常评审选常规综合审查。有专项要求时，可选对应模板，或使用团队保存的项目审查包。</p></div></div>
          <div v-if="project && !offline" class="tabs rule-tabs" aria-label="规则类型">
            <button :class="{ active: ruleTab === 'general' }" :aria-pressed="ruleTab === 'general'" @click="ruleTab = 'general'">审查包</button>
            <button :class="{ active: ruleTab === 'project' }" :aria-pressed="ruleTab === 'project'" @click="ruleTab = 'project'">原文检查规则</button>
          </div>
          <ProjectRuleStudio v-if="project && !offline && ruleTab === 'project'" :key="project.id" :project="project" :documents="documents" :can-decide="canDecide" @source="openDocumentSource" />
          <ReviewPackPicker v-else :key="project?.id" v-model="chosenPack" :packs="state.packs" catalog
            :project-id="project?.id" :manage="!offline && project?.role === 'OWNER'" :allow-start="canAudit"
            @start="startPackReview" @saved="saveProjectPack" />
        </template>

        <DraftStudio v-else-if="route === 'drafts' && canWrite" :form="draftForm" :draft="draft" :busy="busy" :generating="draftGenerating" :error="draftError" :model-ready="modelReady" :model-destination="modelDestination" :model-loading="modelLoading"
          @generate="generateDraft" @model-retry="loadModel" @save="saveDraft" @export="downloadWord(draft.title, draft.text)" />

        <ModelSettings v-else-if="route === 'model' && hasAdmin" :model="modelInfo" :results="modelResults" :testing="modelTesting" :error="modelError" :offline="offline" :can-test="hasAdmin" @test="testModel" @reload="loadModel" />

        <ProjectTeam v-else-if="route === 'team'" :key="projectId" :project="project" :members="members" :busy="busy" :error="memberError" @invite="inviteMember" @save="saveMember" @remove="removeMember" @reload="loadMembers" @navigate="go" />

        <ProjectUsage v-else-if="route === 'usage'" :runs="runs" :project-name="project?.name" />

        <IssueInbox v-else-if="route === 'issues'" :records="projectIssueRows" :user-id="session.user.id" :error="issuesError" :loading="issuesLoading" @open="openRun" @reload="loadProjectIssues" @reviews="go('reviews')" />

        <template v-else-if="route === 'accounts' && hasAdmin">
          <div class="page-heading"><div><h1>账户管理</h1><p>为使用者建立账户。每个账户的项目和资料独立保存。</p></div></div>
          <div class="settings-layout">
            <section class="panel"><div class="panel-heading"><div class="panel-title"><UsersRound :size="18" /><h2>账户列表</h2></div></div>
              <div class="table-scroll"><table><thead><tr><th>显示名称</th><th>用户名</th><th>角色</th></tr></thead><tbody><tr v-for="account in accounts" :key="account.id"><td>{{ account.displayName || account.username }}</td><td>{{ account.username }}</td><td><span class="pill" :class="account.role === 'ADMIN' ? 'info' : 'neutral'">{{ account.role === 'ADMIN' ? '管理员' : '项目用户' }}</span></td></tr></tbody></table></div>
            </section>
            <form class="panel" @submit.prevent="saveAccount"><div class="panel-heading"><div class="panel-title"><Plus :size="18" /><h2>添加账户</h2></div></div>
              <div class="form-body"><label>显示名称<input v-model.trim="accountForm.displayName" maxlength="60" autocomplete="off"></label><label>用户名<input v-model.trim="accountForm.username" minlength="3" maxlength="40" required autocomplete="off"></label><label>密码<input v-model="accountForm.password" type="password" minlength="12" maxlength="128" placeholder="至少 12 个字符" required autocomplete="new-password"></label><button class="button primary" :disabled="busy">创建账户</button></div>
            </form>
          </div>
        </template>

        <ReleaseReadiness v-else-if="route === 'delivery'" :documents="documents" :packs="state.packs"
          :initial-document-id="deliveryTarget.documentId" :initial-version-id="deliveryTarget.versionId" :initial-run-id="deliveryTarget.runId"
          @selection="openDelivery"
          :guided="activeFlow?.stage === 4 && activeFlow.versionId === deliveryTarget.versionId"
          :can-audit="canAudit" @source="openDocumentSource" @review="openRun" @start-review="openVersionReview" @issues="go('issues')" @report="openReport" />

        <div v-else-if="route === 'reports'" class="report-page">
          <div class="page-heading report-heading">
            <div><h1>报告与复查</h1><p>按文档版本查看审查结果、原文证据和修订对照。</p></div>
            <div v-if="report" class="actions report-export">
              <button class="button secondary" :disabled="busy" @click="exportReport('md')">下载 Markdown</button>
              <button class="button secondary" :disabled="busy" @click="exportReport('word')"><ArrowDownToLine :size="17" /> 下载 Word 报告</button>
              <button v-if="!offline && (reportProblems.length || reportHasLaterVersion)" class="button primary" data-report-revision :disabled="busy" @click="go('reviews', true, { run: report.id, panel: 'revision' })"><FileDown :size="17" /> 确认并导出修订稿</button>
            </div>
          </div>
          <template v-if="report">
            <section class="panel report-overview" aria-labelledby="report-document-title">
              <div class="report-picker">
                <div class="report-picker-field">
                  <span>审查任务</span>
                  <WorkspaceSelect :model-value="chosenReport" :options="reportOptions" label="选择报告来源" @update:model-value="openReport" />
                </div>
                <div class="report-shortcuts">
                  <button class="text-button" @click="openDocumentSource(report.documentId, report.versionId)">查看版本原文 <ArrowUpRight :size="14" /></button>
                  <button v-if="!offline" class="text-button" @click="openDelivery(report.documentId, report.versionId, report.id)">交付准备 <ArrowUpRight :size="14" /></button>
                  <button class="text-button" @click="openRun(report.id)">进入任务 <ArrowUpRight :size="14" /></button>
                </div>
              </div>
              <div class="report-summary">
                <div class="report-cover">
                  <div>
                    <h2 id="report-document-title">{{ lookupDoc(report.documentId)?.title }}</h2>
                    <p class="report-meta">V{{ reportVersion?.number }} · {{ runMode(report) }}<template v-if="!isLocalRuleReview(report) && savedPackForRun(report)"> · {{ savedPackLabel(report) }}</template> · <time :datetime="report.createdAt">{{ displayStamp(report.createdAt) }}</time></p>
                    <p v-if="combinedScopeLabel(report)" class="report-meta">{{ combinedScopeLabel(report) }}</p>
                  </div>
                  <span class="pill report-status" :class="runTone(report)">{{ runStatus(report) }}</span>
                </div>
                <div class="report-counts">
                  <div><span>报告所列问题</span><strong v-if="reportResult.inconclusive">尚无结论</strong><strong v-else data-problem-count>{{ reportProblems.length }} <small>个</small></strong></div>
                  <p v-if="reportResult.sourceSummary" class="report-source-total" data-problem-sources>{{ reportResult.sourceSummary }}</p>
                </div>
              </div>
            </section>
            <details v-if="report.packSnapshot?.basePackId" class="panel report-pack-snapshot">
              <summary>查看本次使用的 {{ report.packSnapshot.rules.length }} 个检查项 · V{{ report.packVersion }}</summary>
              <dl><template v-for="rule in report.packSnapshot.rules" :key="rule.id">
                <dt>{{ rule.name }}</dt><dd>{{ rule.question }}</dd>
              </template></dl>
            </details>
            <section v-if="reviewTemplateId(report) === 'legal-risk'" class="panel report-legal-scope" aria-label="法律风险初筛范围">
              <ShieldCheck :size="18" aria-hidden="true" />
              <p>AI 依据中国大陆《个人信息保护法》进行风险初筛。法规适用性和最终法律意见由合规或法务人员确认。</p>
            </section>
            <section v-if="incompleteReport(report)" class="panel report-interruption" aria-label="审查进度说明">
              <CircleAlert :size="18" aria-hidden="true" />
              <div><h2>{{ reportInterruption?.title || '本次检查未完成' }}</h2><p>{{ reportInterruption?.detail || '以下仅列出已有原文依据的问题。' }}</p></div>
              <button class="text-button" @click="openRun(report.id)">打开审查任务 <ArrowUpRight :size="14" /></button>
            </section>
            <section class="panel report-section" aria-labelledby="report-findings-heading">
              <div class="panel-heading"><div class="panel-title"><ClipboardCheck :size="18" /><h2 id="report-findings-heading">问题明细</h2></div></div>
              <div v-if="reportResult.message" class="empty compact report-empty"><p>{{ reportResult.message }}</p></div>
              <ul v-if="reportProblems.length" class="report-problems">
                <li v-for="problem in reportProblems" :key="problem.id" class="report-problem" :data-problem-source="problem.source">
                  <div class="report-problem-explanation">
                    <h3 class="report-problem-title">
                      <button class="text-button compare-link report-finding-link" @click="openRun(report.id, problem.id)">{{ problem.title }}</button>
                    </h3>
                    <dl class="report-problem-guidance">
                      <div><dt>发现方式</dt><dd>{{ problemSourceLabel(problem) }}</dd></div>
                      <div v-if="problem.impact" class="report-impact"><dt>会有什么影响</dt><dd>{{ problem.impact }}</dd></div>
                      <div v-if="problem.action" class="report-action"><dt>建议怎么改</dt><dd>{{ problem.action }}</dd></div>
                      <div v-if="problem.finding?.note"><dt>复核备注</dt><dd>{{ problem.finding.note }}</dd></div>
                    </dl>
                    <span v-if="problem.finding" class="pill" :class="problem.finding.decision === 'CONFIRMED' ? 'success' : 'amber'">{{ labels[problem.finding.decision] || '待复核' }}</span>
                  </div>
                  <div v-if="problem.evidence.length || problem.basisEvidence?.length" class="report-quote-list" aria-label="问题证据">
                    <div v-for="(evidence, index) in problem.evidence" :key="index" class="report-quote">
                      <button v-if="evidence.line > 0" class="text-button compare-link" @click="openDocumentSource(report.documentId, report.versionId, evidence.line)">{{ evidence.label || '原文' }} · {{ sourceLocation(reportVersion, evidence.line) }} <ArrowUpRight :size="14" /></button>
                      <p v-if="evidence.quote">{{ evidence.quote }}</p>
                    </div>
                    <div v-for="(basis, index) in problem.basisEvidence || []" :key="'basis-' + index" class="report-quote" data-report-basis-evidence>
                      <strong>{{ basisEvidenceLabel(report) }}<template v-if="basis.code"> · {{ basis.code }}</template></strong>
                      <p>{{ basis.quote }}</p>
                    </div>
                  </div>
                </li>
              </ul>
              <details v-if="reportResult.excluded.length" :key="report.id" class="report-excluded">
                <summary>查看人工排除的 {{ reportResult.excluded.length }} 条疑点</summary>
                <ul class="report-problems">
                  <li v-for="problem in reportResult.excluded" :key="problem.id" class="report-problem" :data-problem-source="problem.source">
                    <div>
                      <h3 class="report-problem-title"><button class="text-button compare-link report-finding-link" @click="openRun(report.id, problem.id)">{{ problem.title }}</button></h3>
                      <dl class="report-problem-guidance"><div><dt>发现方式</dt><dd>{{ problemSourceLabel(problem) }}</dd></div><div><dt>排除原因</dt><dd>{{ problem.finding.note || '未填写' }}</dd></div></dl>
                    </div>
                    <div class="report-quote-list">
                      <div v-for="(evidence, index) in problem.evidence" :key="index" class="report-quote">
                        <button class="text-button compare-link" @click="openDocumentSource(report.documentId, report.versionId, evidence.line)">{{ sourceLocation(reportVersion, evidence.line) }} <ArrowUpRight :size="14" /></button>
                        <p>{{ evidence.quote }}</p>
                      </div>
                    </div>
                  </li>
                </ul>
              </details>
            </section>
            <section v-if="reportedIssues.length" class="panel report-section" aria-labelledby="report-issues-heading">
              <div class="panel-heading"><div class="panel-title"><ClipboardCheck :size="18" /><h2 id="report-issues-heading">问题跟进状态</h2></div></div>
              <div class="table-scroll" tabindex="0" aria-label="问题跟进状态明细">
                <table>
                  <thead><tr><th scope="col">已登记问题</th><th scope="col">处理人</th><th scope="col">截止日期</th><th scope="col">状态</th></tr></thead>
                  <tbody><tr v-for="item in reportedIssues" :key="item.findingId"><td><button class="text-button compare-link" @click="openRun(report.id, item.findingId)">{{ reportProblemTitle(item.findingId) }}</button></td><td>{{ item.assigneeName || '未分派' }}</td><td>{{ item.dueDate || '—' }}</td><td><span class="pill info">{{ issueStates[item.status] }}</span></td></tr></tbody>
                </table>
              </div>
            </section>
            <VersionCompare :previous="comparisonVersion" :older-versions="olderVersions" :current="reportVersion" :previous-run="isLocalRuleReview(report) ? null : comparisonRun" :current-run="isLocalRuleReview(report) ? null : report" @select-version="compareWith = $event" @finding="openRun" />
            <section v-if="relatedReports.length" class="panel report-section" aria-labelledby="report-history-heading">
              <div class="panel-heading"><div class="panel-title"><History :size="18" /><h2 id="report-history-heading">同文档、同审查包的任务</h2></div></div>
              <div class="table-scroll" tabindex="0" aria-label="相关任务明细">
                <table>
                  <thead><tr><th scope="col">文档版本</th><th scope="col">审查时间</th><th scope="col">报告所列问题</th><th scope="col">任务状态</th><th scope="col">操作</th></tr></thead>
                  <tbody><tr v-for="r in relatedReports" :key="r.id"><td>V{{ lookupVersion(r.documentId, r.versionId)?.number }}</td><td>{{ displayStamp(r.createdAt) }}</td><td>{{ reportCountLabel(r) }}</td><td>{{ runStatus(r) }}</td><td><button class="text-button" @click="openReport(r.id)">查看此报告 <ArrowUpRight :size="14" /></button></td></tr></tbody>
                </table>
              </div>
            </section>
          </template>
          <div v-else class="panel empty report-empty"><FileCheck2 :size="30" /><h2>还没有审查报告</h2><p>完成首次审查后，报告会显示在这里。</p><button class="button secondary" @click="go('reviews')">查看审查任务 <ArrowUpRight :size="15" /></button></div>
        </div>
      </main>
    </div>

    <StartingGuide v-if="guideOpen" :step="guideStep" :project-name="project?.name" :target="guideHint.target" :heading="guideHint.heading" :description="guideHint.description" :action-label="guideHint.label" @step="nextGuideStep" @action="guideAction" @finish="closeGuide" @close="closeGuide" />
    <div v-if="modal" class="dialog-overlay" @click.self="closeModal">
      <section class="dialog" :class="{ 'review-dialog': modal === 'review' }" role="dialog" aria-modal="true" aria-labelledby="dialog-title">
        <div class="dialog-heading"><div><h2 id="dialog-title" tabindex="-1">{{ modal === 'review' && followReview ? '第 2 步 · 运行审查' : { 'import': '导入需求文档', 'import-version': '上传修订版', review: '发起审查', 'project-new': '创建项目', 'project-edit': '编辑项目', 'choose-flow-project': '选择工作项目', 'choose-flow-document': requestedStage === 'document' && canWrite ? '准备需求文档' : '选择需求文档' }[modal] }}</h2><p>{{ { 'import': '保存原文并提取章节与需求条目。', 'import-version': '新增到《' + (doc?.title || '') + '》的版本历史，并对照最近两版的原件检查结果。', review: '先选要查的问题类型，再确定审查的文档和范围。', 'project-new': '需求文档、评审与报告统一归入项目。', 'project-edit': '更新项目名称和业务说明。', 'choose-flow-project': '在所选项目中继续「' + workflowSteps.find(step => step.action === requestedStage)?.title + '」。', 'choose-flow-document': requestedStage === 'document' && canWrite ? '为「' + project?.name + '」选择这次使用的文档。' : '选择本次流程使用的文档。' }[modal] }}</p></div><button class="icon-button" aria-label="关闭" :disabled="busy" @click="closeModal"><X :size="20" /></button></div>
        <div v-if="modalError" class="form-error"><CircleAlert :size="17" /><span>{{ modalError }}</span></div>
        <div v-if="modal === 'choose-flow-project' || modal === 'choose-flow-document'" class="flow-choice-dialog">
          <div v-if="modal === 'choose-flow-project'" class="flow-choice-list" data-coach="flow-choices" tabindex="-1">
            <button v-for="item in projects" :key="item.id" type="button" :data-choose-flow-project="item.id" :disabled="busy" @click="switchProject(item.id, 'home', requestedStage)">
              <FolderKanban :size="17" /><span>{{ item.name }}</span><ChevronRight :size="15" />
            </button>
          </div>
          <div v-else class="flow-choice-list" data-coach="flow-choices" tabindex="-1">
            <template v-if="requestedStage === 'document' && canWrite">
              <button type="button" data-prepare-generate :disabled="busy" @click="openDraftStudio">
                <Sparkles :size="18" /><span><strong>一键生成需求文档</strong><small class="prepare-description">填写业务目标，生成可以编辑的需求草稿。</small></span><ChevronRight :size="15" />
              </button>
              <button type="button" data-prepare-import :disabled="busy" @click="chooseFlowDocument('')">
                <UploadCloud :size="18" /><span><strong>导入已有文档</strong><small class="prepare-description">上传文件或粘贴已有的需求原文。</small></span><ChevronRight :size="15" />
              </button>
              <h3 v-if="documents.length" class="prepare-existing">继续项目中的文档</h3>
            </template>
            <button v-for="item in documents" :key="item.id" type="button" :data-choose-flow-document="item.id" :disabled="busy" @click="chooseFlowDocument(item.id)">
              <FileText :size="17" /><span>{{ item.title }} <small>V{{ item.versions[0]?.number }}</small></span><ChevronRight :size="15" />
            </button>
          </div>
          <div class="dialog-footer"><button type="button" class="button secondary" :disabled="busy" @click="closeModal">取消</button>
            <button v-if="modal === 'choose-flow-project'" type="button" class="button secondary" data-new-flow-project :disabled="busy" @click="openProjectForm(false, 'home', requestedStage)"><Plus :size="16" /> 创建新项目</button>
          </div>
        </div>
        <form v-else-if="modal.startsWith('project-')" @submit.prevent="storeProject">
          <div class="form-body"><label>项目名称<input v-model.trim="projectForm.name" data-coach="project-name" placeholder="例如：企业 IT 服务台与变更管理" maxlength="120" required></label><label>业务说明<textarea rows="4" v-model="projectForm.description" maxlength="1200" placeholder="项目服务谁，覆盖哪些主要业务？"></textarea></label></div>
          <div class="dialog-footer"><button type="button" class="button secondary" @click="closeModal" :disabled="busy">取消</button><button class="button primary" :disabled="busy || !projectForm.name.trim()">{{ modal === 'project-edit' ? '保存修改' : '创建项目' }}</button></div>
        </form>
        <form v-else-if="modal === 'import' || modal === 'import-version'" @submit.prevent="importDoc">
          <div v-if="modal === 'import'" class="tabs dialog-tabs"><button type="button" :class="{ active: importTab === 'file' }" @click="importTab = 'file'">上传文件</button><button type="button" :class="{ active: importTab === 'text' }" @click="importTab = 'text'">粘贴文本</button></div>
          <div v-if="importTab === 'file'" class="form-body">
            <input ref="fileInput" type="file" :accept="offline ? '.docx,.txt,.md,.rst' : '.docx,.pdf,.txt,.md,.markdown,.rst'" class="sr-only" tabindex="-1" @change="pick($event.target.files?.[0])">
            <button type="button" class="upload-zone" data-coach="choose-file" @click="fileInput?.click()" @dragover.prevent @drop.prevent="pick($event.dataTransfer.files?.[0])"><UploadCloud :size="27" /><strong>{{ chosenFile?.name || '点击选择或拖入原件' }}</strong><small>{{ offline ? 'DOCX、TXT、Markdown、RST · 8 MB 内' : 'DOCX、带文本的 PDF、TXT、Markdown、RST · 8 MB 内' }}</small></button>
            <div class="form-hint"><ShieldCheck :size="17" /> 导入后先查看解析结果，再决定是否提交模型审查。</div>
            <button v-if="!offline && modal === 'import'" type="button" class="text-button" data-open-library :disabled="busy" @click="openImportLibrary"><BookOpen :size="15" /> 从公开文档库选择 <ArrowUpRight :size="14" /></button>
          </div>
          <div v-else class="form-body">
            <label>文档名称<input v-model="importForm.title" placeholder="输入文档名称" maxlength="120" required></label>
            <label>文档原文<textarea v-model="importForm.text" data-coach="paste-source" rows="7" placeholder="例如：FR-001：学生可以查看活动列表。" required></textarea></label>
          </div>
          <div v-if="previousImport" class="form-hint duplicate-import" data-previous-import>
            <Files :size="17" /><span>当前项目已有相同{{ importTab === 'file' ? '文件' : '正文' }}，《{{ previousImport.document.title }}》V{{ previousImport.version.number }}。</span>
            <button type="button" class="text-button" :disabled="busy" @click="openPreviousImport">打开已有版本</button>
          </div>
          <div class="dialog-footer"><button type="button" class="button secondary" :disabled="busy" @click="closeModal">取消</button><button class="button primary" :disabled="busy || (importTab === 'file' ? !chosenFile : !importForm.title.trim() || !importForm.text.trim())"><UploadCloud :size="17" /> {{ busy ? '导入中…' : modal === 'import-version' ? '保存为新版本' : previousImport ? '另建一份文档' : '导入文档' }}</button></div>
        </form>
        <form v-else @submit.prevent="runReview">
          <div v-if="!documents.length" class="empty compact"><p>请先导入需求文档。</p><button type="button" class="button secondary" @click="openImport">导入文档</button></div>
          <div v-else class="form-body">
            <ReviewPackPicker :model-value="reviewForm.packId" :packs="formPacks" :disabled="busy" @update:model-value="selectReviewPack" />
            <p v-if="reviewPackNotice" class="review-pack-notice" role="status">{{ reviewPackNotice }}</p>
            <div v-if="latestReviewPack?.basePackId && reviewForm.packVersion !== latestReviewPack.version" class="review-context-field">
              <span>沿用上次审查的 V{{ reviewForm.packVersion }} 规则。</span>
              <button type="button" class="text-button" :disabled="busy" @click="selectReviewPack(latestReviewPack.id)">改用当前版本 V{{ latestReviewPack.version }}</button>
            </div>
            <div v-if="reviewProfile.context" class="review-context-field">
              <label for="review-basis-input">{{ reviewProfile.context.label }}</label>
              <p id="review-basis-hint">{{ reviewProfile.context.hint }}</p>
              <textarea id="review-basis-input" v-model="reviewBasis" rows="3" maxlength="3000"
                :minlength="reviewProfile.context.required ? 10 : undefined" :required="reviewProfile.context.required"
                :disabled="busy" aria-describedby="review-basis-hint review-basis-limit" :placeholder="reviewProfile.context.placeholder" />
              <small id="review-basis-limit">{{ reviewProfile.context.required ? '10–3000 字。' : '最多 3000 字。' }}所填内容会随原文发送给审查模型，并保存在本次审查记录中，有权访问项目的成员可以查看。</small>
            </div>
            <div class="review-document-fields">
              <div class="review-select-field">
                <span>需求文档</span>
                <WorkspaceSelect :model-value="reviewForm.documentId" :options="documentOptions" label="需求文档" :disabled="busy" @update:model-value="changeTarget" />
              </div>
              <div class="review-select-field">
                <span>文档版本</span>
                <WorkspaceSelect v-model="reviewForm.versionId" :options="targetVersionOptions" label="文档版本" :disabled="busy" />
              </div>
            </div>
            <div v-if="!reviewUsesRules && reviewResumeIds.length" class="form-hint"><ClipboardCheck :size="17" /> 沿用指定的 {{ reviewResumeIds.length }} 个目标条款。<button type="button" class="text-button" @click="reviewResumeIds = []">重新选择范围</button></div>
            <div v-else-if="!reviewUsesRules" class="review-select-field">
              <span>{{ offline ? '评审范围' : 'AI 审查范围' }}</span>
              <WorkspaceSelect v-model="reviewSection" :options="reviewScopeOptions" :label="offline ? '评审范围' : 'AI 审查范围'" :disabled="busy" />
            </div>
            <div v-if="!offline" class="review-select-field" data-review-execution>
              <span>执行方式</span>
              <WorkspaceSelect v-if="modelReady && !reviewProfile.requiresModel" v-model="reviewForm.mode" :options="reviewModeOptions" label="执行方式" :disabled="busy" />
              <strong v-else>{{ reviewProfile.requiresModel ? '联合审查（本地规则 + AI）' : '仅本地规则检查' }}</strong>
            </div>
            <div v-if="hasPreviousReview" class="review-select-field" data-repeat-options>
              <span>相同条件再次提交时</span>
              <WorkspaceSelect v-model="forceFreshReview" :options="repeatOptions" label="重复审查方式" :disabled="busy" />
              <small>{{ forceFreshReview ? (reviewForm.mode === 'MODEL' ? '将重新调用模型，发现的问题可能不同。相同任务已在执行时可直接查看进度。' : '将按当前规则重新检查，并保留原任务。') : '文档版本、范围、规则、补充依据和执行配置均一致时，优先打开已有的完整结果。' }}</small>
            </div>
            <div class="form-hint"><ShieldCheck :size="17" />
              <span v-if="reviewProfile.requiresModel && !modelReady">此包的检查项需要 AI。当前可选常规综合审查运行本地检查。</span>
              <span v-else-if="reviewUsesRules">本地规则检查整份原文和已启用的项目规则，不调用模型。</span>
              <span v-else-if="reviewForm.mode === 'MODEL' && modelDestination">本地规则检查整份原文，AI 按审查包核对所选的 {{ targetItems.length }} 条需求，两路结果汇入同一份报告。新开审查时，所需原文、关联条款<template v-if="reviewBasis.trim()">和补充依据</template>将发送给 {{ modelDestination }}。</span>
              <span v-else-if="reviewForm.mode === 'MODEL'">{{ modelLoading ? '正在读取默认模型信息…' : '暂时无法读取默认模型信息。' }} <button v-if="!modelLoading" type="button" class="text-button" @click="loadModel">重试</button></span>
              <span v-else>{{ targetItems.length }} 条目标需求。此次使用样例结果体验复核流程。</span>
            </div>
          </div>
          <div class="dialog-footer"><button type="button" class="button secondary" :disabled="busy" @click="closeModal">取消</button><button class="button primary" data-coach="submit-review" :disabled="!canSubmitReview"><ScanLine :size="17" /> {{ busy ? '正在提交…' : reviewUsesRules ? '开始本地检查' : reviewForm.mode === 'MODEL' ? '开始联合审查' : '开始审查' }}</button></div>
        </form>
      </section>
    </div>
    <div v-if="toast" class="toast" :class="{ 'toast-error': toastError }" role="status"><component :is="toastError ? CircleAlert : Check" :size="18" />{{ toast }}<button class="icon-button" aria-label="关闭提示" @click="toast = ''"><X :size="16" /></button></div>
  </div>
</template>

<style scoped>
.dialog.review-dialog { width: min(100%, 640px); }
.review-document-fields { display: grid; grid-template-columns: minmax(0, 2fr) minmax(0, 1fr); gap: 12px; }
.review-context-field { display: grid; gap: 5px; min-width: 0; }
.review-context-field label { font-size: 13px; }
.review-context-field textarea { width: 100%; resize: vertical; }
.review-pack-notice { color: var(--muted); font-size: 13px; }
.review-context-field p, .review-context-field small { color: var(--muted); line-height: 1.55; font-size: 12px; }
.report-quote[data-report-basis-evidence] strong { color: var(--primary); font-size: 12px; }
.report-pack-snapshot { padding: 13px 16px; }
.report-pack-snapshot summary { cursor: pointer; color: var(--primary); font-size: 13px; font-weight: 600; }
.report-pack-snapshot dl { margin: 12px 0 0; }
.report-pack-snapshot dt { font-weight: 650; font-size: 13px; }
.report-pack-snapshot dd { margin: 2px 0 8px; color: var(--muted); font-size: 13px; overflow-wrap: anywhere; }
.report-legal-scope { display: flex; align-items: flex-start; gap: 9px; padding: 12px 15px; color: var(--muted); font-size: 13px; line-height: 1.6; }
.report-legal-scope svg { flex: none; margin-top: 1px; color: var(--primary); }
.revision-recovery { padding: 12px 16px; }
.revision-recovery-row { display: flex; gap: 8px 16px; align-items: center; justify-content: space-between; flex-wrap: wrap; }
.revision-recovery-row + .revision-recovery-row { margin-top: 6px; }
.revision-recovery-row > span { font-weight: 600; }
.revision-recovery .actions { flex-wrap: wrap; }
.revision-base { padding: 12px 15px; margin-bottom: 12px; border: 1px solid #d8caad; background: #faf6eb; border-radius: 8px; }
.revision-base p, .revision-draft-note { color: var(--muted); font-size: 13px; line-height: 1.6; }
.revision-base p { margin: 4px 0; }
.revision-base label { margin-top: 8px; display: flex; align-items: center; gap: 7px; }
.revision-base input { width: auto; height: auto; accent-color: var(--primary); }
.revision-draft-note { margin: 5px 0; }
.prepare-description { display: block; margin-top: 4px; font-size: 12px; line-height: 1.55; }
.prepare-existing { font-size: 13px; font-weight: 600; margin: 9px 2px 0; color: var(--muted); }
@media (max-width: 500px) {
  .review-document-fields { grid-template-columns: minmax(0, 1fr); }
  .review-context-field textarea { font-size: 16px; }
}
</style>
