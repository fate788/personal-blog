<script setup>
import { computed, nextTick, onBeforeUnmount, onMounted, ref, shallowRef, useId, watch } from 'vue'
import { ArrowRight, X } from 'lucide-vue-next'

const props = defineProps({
  step: { type: Number, default: 0 },
  projectName: { type: String, default: '' },
  target: { type: String, default: '' },
  heading: { type: String, default: '' },
  description: { type: String, default: '' },
  actionLabel: { type: String, default: '打开入口' },
})
const emit = defineEmits(['close', 'step', 'action', 'finish'])

const steps = [
  ['准备文档', '点亮的入口可以导入原件或新建需求。先确认待审查的文档和版本。'],
  ['执行检查', '选择文档版本和审查包。联合审查会在同一次任务中运行本地规则和 AI 语义检查。'],
  ['复核证据', '打开审查结果，点提示里的行号查看原文和关联证据。'],
  ['保存修订并复查', '上传修订稿作为新版本，用同一规则复查两版结果。'],
  ['交付', '在交付准备中核对审查和测试记录，再导出报告。'],
]
const active = computed(() => Number.isInteger(props.step) && props.step >= 0 && props.step < steps.length ? props.step : 0)
const headingText = computed(() => props.heading || steps[active.value][0])
const detailText = computed(() => props.description || steps[active.value][1])
const headingId = useId()
const detailId = useId()
const panel = ref(null)
const title = ref(null)
const closeButton = ref(null)
const outline = ref(null)
const placement = shallowRef(null)
const spotlight = shallowRef(null)

const INSET = 12
const GAP = 13
const TARGET_WAIT = 150
const FOCUSABLE = 'button:not([disabled]), a[href], input:not([disabled]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex="-1"])'

let returnFocus = null
let describedAnchor = null
let observedAnchor = null
let resizeObserver
let mutationObserver
let frame = 0
let waitTimer = 0
let waitElapsed = false
let revealTarget = true
let focusTip = true

const clamp = (value, min, max) => Math.min(Math.max(value, min), Math.max(min, max))
const pixels = value => Math.round(value * 10) / 10 + 'px'
const panelStyle = computed(() => placement.value ? {
  left: pixels(placement.value.left),
  top: pixels(placement.value.top),
  '--coach-arrow-x': pixels(placement.value.arrowX),
  '--coach-arrow-y': pixels(placement.value.arrowY),
} : {})
const spotlightStyle = computed(() => spotlight.value ? {
  left: pixels(spotlight.value.left),
  top: pixels(spotlight.value.top),
  width: pixels(spotlight.value.right - spotlight.value.left),
  height: pixels(spotlight.value.bottom - spotlight.value.top),
} : {})

function viewportBounds() {
  const view = window.visualViewport
  const left = view?.offsetLeft || 0
  const top = view?.offsetTop || 0
  const width = view?.width || window.innerWidth
  const height = view?.height || window.innerHeight
  return { left, top, width, height, right: left + width, bottom: top + height }
}

function visibleBounds(element, view) {
  const rect = element.getBoundingClientRect()
  let left = Math.max(view.left, rect.left)
  let top = Math.max(view.top, rect.top)
  let right = Math.min(view.right, rect.right)
  let bottom = Math.min(view.bottom, rect.bottom)
  for (let parent = element.parentElement; parent && parent !== document.body; parent = parent.parentElement) {
    const style = getComputedStyle(parent)
    const clipsX = /auto|scroll|hidden|clip/.test(style.overflowX)
    const clipsY = /auto|scroll|hidden|clip/.test(style.overflowY)
    if (!clipsX && !clipsY) continue
    const bounds = parent.getBoundingClientRect()
    if (clipsX) {
      left = Math.max(left, bounds.left)
      right = Math.min(right, bounds.right)
    }
    if (clipsY) {
      top = Math.max(top, bounds.top)
      bottom = Math.min(bottom, bounds.bottom)
    }
  }
  return right > left && bottom > top ? { left, top, right, bottom } : null
}

function locateTarget(view) {
  if (!props.target) return {}
  let matches
  try {
    matches = document.querySelectorAll(props.target)
  } catch {
    return {}
  }
  let concealed
  for (const element of matches) {
    const bounds = element.getBoundingClientRect()
    if (!bounds.width || !bounds.height || getComputedStyle(element).visibility !== 'visible' || element.closest('[inert], [aria-hidden="true"]')) continue
    const shown = visibleBounds(element, view)
    if (shown) return { element, shown }
    concealed ??= element
  }
  return { element: concealed }
}

function updateAnchor(element) {
  if (observedAnchor !== element) {
    if (observedAnchor) resizeObserver?.unobserve(observedAnchor)
    if (element) resizeObserver?.observe(element)
    observedAnchor = element
  }
  const focusable = element?.matches(FOCUSABLE) ? element : element?.querySelector(FOCUSABLE) || null
  if (describedAnchor === focusable) return
  if (describedAnchor) {
    const names = (describedAnchor.getAttribute('aria-describedby') || '').split(/\s+/).filter(name => name && name !== detailId)
    if (names.length) describedAnchor.setAttribute('aria-describedby', names.join(' '))
    else describedAnchor.removeAttribute('aria-describedby')
  }
  describedAnchor = focusable
  if (focusable) {
    const names = (focusable.getAttribute('aria-describedby') || '').split(/\s+/).filter(Boolean)
    focusable.setAttribute('aria-describedby', [...new Set([...names, detailId])].join(' '))
  }
}

function dock(view, size) {
  return {
    left: view.width <= 680 ? view.left + (view.width - size.width) / 2 : view.right - size.width - INSET,
    top: view.bottom - size.height - INSET,
    side: '',
    arrowX: 0,
    arrowY: 0,
  }
}

function align(view, target, size) {
  const middleX = (target.left + target.right) / 2
  const middleY = (target.top + target.bottom) / 2
  const baselineX = clamp(middleX - size.width / 2, view.left + INSET, view.right - INSET - size.width)
  const baselineY = clamp(middleY - size.height / 2, view.top + INSET, view.bottom - INSET - size.height)
  const choices = {
    right: { left: target.right + GAP, top: baselineY },
    left: { left: target.left - GAP - size.width, top: baselineY },
    bottom: { left: baselineX, top: target.bottom + GAP },
    top: { left: baselineX, top: target.top - GAP - size.height },
  }
  const priority = view.width <= 680 ? ['bottom', 'top', 'right', 'left'] : ['right', 'left', 'bottom', 'top']
  for (const side of priority) {
    const { left, top } = choices[side]
    if (left < view.left + INSET || top < view.top + INSET
      || left + size.width > view.right - INSET || top + size.height > view.bottom - INSET) continue
    return {
      left, top, side,
      arrowX: clamp(middleX - left, 14, size.width - 14),
      arrowY: clamp(middleY - top, 14, size.height - 14),
    }
  }
  return dock(view, size)
}

function clearWait() {
  window.clearTimeout(waitTimer)
  waitTimer = 0
  waitElapsed = false
}

function showTip() {
  if (!focusTip) return
  focusTip = false
  const focusedBefore = document.activeElement
  nextTick(() => {
    if (document.activeElement === focusedBefore && (focusedBefore === returnFocus
      || focusedBefore === document.body || panel.value?.contains(focusedBefore))) {
      title.value?.focus({ preventScroll: true })
    }
  })
}

function measure() {
  if (!panel.value) return
  const view = viewportBounds()
  const { element, shown } = locateTarget(view)
  updateAnchor(shown ? element : null)
  if (!shown && element && revealTarget) {
    revealTarget = false
    element.scrollIntoView({ block: 'nearest', inline: 'nearest', behavior: 'instant' })
    queueMeasure()
    return
  }
  if (shown) {
    revealTarget = false
    clearWait()
  } else if (props.target && !waitElapsed) {
    spotlight.value = null
    if (!waitTimer) {
      waitTimer = window.setTimeout(() => {
        waitTimer = 0
        waitElapsed = true
        queueMeasure()
      }, TARGET_WAIT)
    }
    return
  }
  panel.value.style.setProperty('--coach-width', pixels(Math.min(300, view.width - INSET * 2)))
  panel.value.style.setProperty('--coach-max-height', pixels(view.height - INSET * 2))
  const size = panel.value.getBoundingClientRect()
  spotlight.value = shown || null
  placement.value = shown ? align(view, shown, size) : dock(view, size)
  showTip()
}

function queueMeasure() {
  if (frame) return
  frame = window.requestAnimationFrame(() => {
    frame = 0
    measure()
  })
}

function handleKey(event) {
  if (event.defaultPrevented || event.altKey || event.ctrlKey || event.metaKey) return
  if (event.key === 'Escape') {
    emit('close')
    return
  }
  if (event.key !== 'Tab' || !describedAnchor || !placement.value?.side) return
  if (!event.shiftKey && document.activeElement === describedAnchor) {
    event.preventDefault()
    closeButton.value?.focus({ preventScroll: true })
  } else if (event.shiftKey && (document.activeElement === closeButton.value || document.activeElement === title.value)) {
    event.preventDefault()
    describedAnchor.focus({ preventScroll: true })
  }
}

function hasExternalChange(records) {
  return records.some(({ target }) => target !== outline.value && target !== panel.value && !panel.value?.contains(target))
}

watch(() => [props.step, props.target], () => {
  focusTip = panel.value?.contains(document.activeElement)
  revealTarget = true
  clearWait()
  queueMeasure()
}, { flush: 'post' })
watch([headingText, detailText], queueMeasure, { flush: 'post' })

onMounted(() => {
  returnFocus = document.activeElement
  if (window.ResizeObserver) {
    resizeObserver = new ResizeObserver(queueMeasure)
    resizeObserver.observe(panel.value)
  }
  mutationObserver = new MutationObserver(records => {
    if (hasExternalChange(records)) queueMeasure()
  })
  mutationObserver.observe(document.body, {
    childList: true, subtree: true, attributes: true,
    attributeFilter: ['class', 'style', 'hidden', 'disabled', 'aria-hidden', 'data-coach'],
  })
  window.addEventListener('resize', queueMeasure)
  window.addEventListener('scroll', queueMeasure, true)
  window.visualViewport?.addEventListener('resize', queueMeasure)
  window.visualViewport?.addEventListener('scroll', queueMeasure)
  document.addEventListener('keydown', handleKey)
  queueMeasure()
})

onBeforeUnmount(() => {
  window.cancelAnimationFrame(frame)
  clearWait()
  mutationObserver?.disconnect()
  resizeObserver?.disconnect()
  window.removeEventListener('resize', queueMeasure)
  window.removeEventListener('scroll', queueMeasure, true)
  window.visualViewport?.removeEventListener('resize', queueMeasure)
  window.visualViewport?.removeEventListener('scroll', queueMeasure)
  document.removeEventListener('keydown', handleKey)
  const fallbackFocus = describedAnchor
  updateAnchor(null)
  if (panel.value?.contains(document.activeElement)) {
    const destination = returnFocus?.isConnected && returnFocus !== document.body ? returnFocus : fallbackFocus
    destination?.focus({ preventScroll: true })
  }
})
</script>

<template>
  <Teleport to="body">
    <div v-if="spotlight" ref="outline" class="coach-outline" :style="spotlightStyle" aria-hidden="true"></div>
    <section
      ref="panel"
      class="coach-panel"
      :class="{ 'coach-ready': placement }"
      :style="panelStyle"
      :data-side="placement?.side"
      :aria-labelledby="headingId"
      :aria-describedby="detailId"
      role="dialog"
    >
      <div class="coach-body">
        <header class="coach-top">
          <span :title="projectName">新手引导 · {{ active + 1 }}/{{ steps.length }}</span>
          <button ref="closeButton" type="button" class="coach-close" @click="emit('close')">跳过引导 <X :size="15" aria-hidden="true" /></button>
        </header>
        <h2 :id="headingId" ref="title" tabindex="-1">{{ headingText }}</h2>
        <p :id="detailId">{{ detailText }}</p>
        <footer class="coach-actions">
          <button type="button" class="button secondary coach-try" @click="emit('action', active)">{{ actionLabel }}</button>
          <button v-if="active + 1 < steps.length" type="button" class="button primary" @click="emit('step', active + 1)">下一步 <ArrowRight :size="15" aria-hidden="true" /></button>
          <button v-else type="button" class="button primary" @click="emit('finish')">完成引导</button>
        </footer>
      </div>
    </section>
  </Teleport>
</template>

<style scoped>
.coach-outline {
  position: fixed;
  z-index: 29;
  border-radius: 8px;
  outline: 2px solid #218365;
  outline-offset: 3px;
  box-shadow: 0 0 0 6px #31947920;
  pointer-events: none;
}
.coach-panel {
  --primary: #28634f;
  --primary-hover: #1f513f;
  position: fixed;
  z-index: 30;
  isolation: isolate;
  width: var(--coach-width, min(300px, calc(100vw - 24px)));
  visibility: hidden;
}
.coach-ready { visibility: visible; }
.coach-body {
  position: relative;
  max-height: var(--coach-max-height, calc(100dvh - 24px));
  overflow: auto;
  overscroll-behavior: contain;
  padding: 11px 13px 13px;
  border: 1px solid #a8c9b8;
  border-radius: 11px;
  background: var(--panel, #fff);
  color: var(--text, #172c27);
  box-shadow: 0 7px 24px #17382b29;
}
.coach-panel[data-side]:not([data-side=""])::before {
  position: absolute;
  z-index: 1;
  width: 10px;
  height: 10px;
  border-top: 1px solid #a8c9b8;
  border-right: 1px solid #a8c9b8;
  background: var(--panel, #fff);
  content: "";
  pointer-events: none;
}
.coach-panel[data-side="right"]::before { top: calc(var(--coach-arrow-y) - 5px); left: -5px; transform: rotate(225deg); }
.coach-panel[data-side="left"]::before { top: calc(var(--coach-arrow-y) - 5px); right: -5px; transform: rotate(45deg); }
.coach-panel[data-side="bottom"]::before { top: -5px; left: calc(var(--coach-arrow-x) - 5px); transform: rotate(-45deg); }
.coach-panel[data-side="top"]::before { bottom: -5px; left: calc(var(--coach-arrow-x) - 5px); transform: rotate(135deg); }
.coach-top { display: flex; align-items: center; justify-content: space-between; gap: 8px; margin: -4px -6px 2px 0; }
.coach-top span { color: #24634f; font-size: 11px; font-weight: 720; }
.coach-close { display: inline-flex; align-items: center; justify-content: center; gap: 5px; min-height: 36px; padding: 4px 7px; border: 0; border-radius: 7px; background: transparent; color: #435d52; font-size: 12px; font-weight: 650; white-space: nowrap; }
.coach-close:hover { background: #e9f4ee; }
.coach-body h2 { margin: 0; font-size: 16px; line-height: 1.35; overflow-wrap: anywhere; }
.coach-body h2:focus { outline: none; }
.coach-body p { margin: 6px 0 0; color: #435d52; font-size: 13px; line-height: 1.55; overflow-wrap: anywhere; }
.coach-actions { display: flex; flex-wrap: wrap; justify-content: flex-end; gap: 7px; margin-top: 11px; }
.coach-actions .button { min-height: 36px; padding: 6px 10px; }
.coach-actions .coach-try { white-space: normal; }
@media (pointer: coarse), (max-width: 480px) {
  .coach-close { min-height: 44px; }
  .coach-actions .button { min-height: 44px; }
}
</style>

