import { strToU8, zipSync } from 'fflate'

const declaration = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
const word = 'http://schemas.openxmlformats.org/wordprocessingml/2006/main'
const rel = 'http://schemas.openxmlformats.org/officeDocument/2006/relationships'
const contentWidth = 9406
const ink = '263B36'
const green = '205446'
const muted = '52645D'
const border = 'CFDAD4'

function escape(value) {
  return String(value).replace(/[^\x09\x0A\x0D\u0020-\uD7FF\uE000-\uFFFD\u{10000}-\u{10FFFF}]/gu, '')
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;')
}
const fonts = family => '<w:rFonts w:ascii="' + family + '" w:hAnsi="' + family + '" w:eastAsia="Microsoft YaHei" w:cs="' + family + '"/>'
const color = value => '<w:color w:val="' + value + '"/>'
const size = value => '<w:sz w:val="' + value + '"/><w:szCs w:val="' + value + '"/>'
const spacing = (before, after, line) => '<w:spacing w:before="' + before + '" w:after="' + after + '" w:line="' + line + '" w:lineRule="auto"/>'
const shading = fill => '<w:shd w:val="clear" w:color="auto" w:fill="' + fill + '"/>'
const tab = '<w:r><w:tab/></w:r>'
function run(text, properties = '') {
  const pieces = String(text).split(/(\t|\r\n|\r|\n)/).filter(Boolean)
  return pieces.length ? '<w:r>' + (properties ? '<w:rPr>' + properties + '</w:rPr>' : '') +
    pieces.map(piece => piece === '\t' ? '<w:tab/>' : /^[\r\n]/.test(piece) ? '<w:br/>' :
      '<w:t xml:space="preserve">' + escape(piece) + '</w:t>').join('') + '</w:r>' : ''
}
function paragraph(style, content, extra = '') {
  return '<w:p><w:pPr><w:pStyle w:val="' + style + '"/>' + extra + '</w:pPr>' + content + '</w:p>'
}
function style(id, name, pPr, rPr, parent = 'Normal') {
  return '<w:style w:type="paragraph" w:styleId="' + id + '"' + (id === 'Normal' ? ' w:default="1"' : '') +
    '><w:name w:val="' + name + '"/>' + (id === 'Normal' ? '' : '<w:basedOn w:val="' + parent + '"/>') +
    '<w:next w:val="Normal"/><w:qFormat/><w:pPr>' + pPr + '</w:pPr><w:rPr>' + rPr + '</w:rPr></w:style>'
}
function stylesXml() {
  const normalFont = fonts('Calibri') + color(ink) + size(22) + '<w:lang w:val="en-US" w:eastAsia="zh-CN"/>'
  const headings = [34, 27, 24, 23, 22, 22].map((points, i) => style('Heading' + (i + 1), 'heading ' + (i + 1),
    '<w:keepNext/><w:keepLines/>' + spacing(i ? 110 : 140, i ? 40 : 75, 265) + '<w:outlineLvl w:val="' + i + '"/>',
    '<w:b/>' + color(i ? ink : green) + size(points))).join('')
  return declaration + '<w:styles xmlns:w="' + word + '"><w:docDefaults><w:rPrDefault><w:rPr>' + normalFont +
    '</w:rPr></w:rPrDefault><w:pPrDefault><w:pPr><w:widowControl/></w:pPr></w:pPrDefault></w:docDefaults>' +
    style('Normal', 'Normal', '<w:widowControl/>' + spacing(0, 60, 310), normalFont) + headings +
    style('BodyList', 'Body List', spacing(0, 45, 290), '') +
    style('Quote', 'Quotation', spacing(30, 70, 290) + '<w:ind w:left="300"/>', color(muted)) +
    style('CodeBlock', 'Code Block', '<w:pBdr><w:left w:val="single" w:sz="12" w:space="5" w:color="7D9F91"/></w:pBdr>' +
      shading('F1F5F2') + spacing(40, 65, 255) + '<w:ind w:left="175" w:right="120"/>', fonts('Consolas') + color('253C34') + size(19)) +
    style('TableText', 'Table Text', spacing(0, 0, 270), size(20)) +
    style('TableHeading', 'Table Heading', spacing(0, 0, 270), '<w:b/>' + color(green) + size(20), 'TableText') +
    style('PageLabel', 'Page Label', spacing(0, 0, 240), color(muted) + size(18)) + '</w:styles>'
}

const inlineToken = /(\x60+)([^\n]+?)\1(?!\x60)|\*\*([^\n]+?)\*\*|__([^\n]+?)__|(!?)\[([^\]\n]+)\]\(([^()\s]+(?:\([^()\s]*\)[^()\s]*)*)\)|<br\s*\/?>/gi
function labelRuns(text, properties = '') {
  let result = '', last = 0
  for (const hit of text.matchAll(/(\x60+)([^\n]+?)\1(?!\x60)/g)) {
    result += run(text.slice(last, hit.index), properties) + run(hit[2], fonts('Consolas') + properties)
    last = hit.index + hit[0].length
  }
  return result + run(text.slice(last), properties)
}
function inline(text, links) {
  let xml = '', last = 0
  for (const hit of text.matchAll(inlineToken)) {
    xml += run(text.slice(last, hit.index))
    if (hit[1]) xml += run(hit[2], fonts('Consolas') + color(green))
    else if (hit[3] || hit[4]) xml += labelRuns(hit[3] || hit[4], '<w:b/>')
    else if (hit[6]) {
      const address = hit[7]
      if (/^(?:https?:\/\/|mailto:)/i.test(address)) {
        if (!links.has(address)) links.set(address, 'link' + (links.size + 1))
        xml += '<w:hyperlink r:id="' + links.get(address) + '">' + labelRuns(hit[6], color('285E56') + '<w:u w:val="single"/>') + '</w:hyperlink>'
      } else {
        // A standalone Word file may not contain the section or asset that a source-relative link refers to.
        xml += labelRuns(hit[6]) + run(' (' + address + ')', color(muted))
      }
    } else xml += '<w:r><w:br/></w:r>'
    last = hit.index + hit[0].length
  }
  return xml + run(text.slice(last))
}

function sourceLines(text, version, edits) {
  const original = version?.text?.split(/\r?\n/) || []
  const edited = new Map(edits.map(edit => [edit.line, edit.replacement]))
  const origins = []
  for (let i = 0; i < original.length; i++) {
    const replacement = edited.get(i + 1)
    const count = replacement === undefined ? 1 : replacement.split(/\r?\n/).length
    for (let n = 0; n < count; n++) origins.push(count === 1 ? i + 1 : null)
  }
  const titles = new Map((version?.sections || []).map(section => [section.line, section]))
  return text.split(/\r?\n/).map((line, i) => {
    const number = origins[i], section = titles.get(number)
    const anchor = version?.source?.anchors?.[number]
    return { line, section: section && original[number - 1]?.trim() === line.trim() ? section : null,
      anchor, unchanged: number != null && original[number - 1] === line }
  })
}
function importedCells(row) {
  const { anchor, line } = row
  if (anchor?.table == null || !anchor.cells?.length) return null
  if (row.unchanged && anchor.cells.every(cell =>
    Number.isInteger(cell.start) && Number.isInteger(cell.end) && cell.start >= 0 && cell.end >= cell.start && cell.end <= line.length)) {
    return anchor.cells.map(cell => line.slice(cell.start, cell.end))
  }
  const cells = line.split(' │ ')
  return cells.length === anchor.cells.length ? cells : null
}

function markdownCells(line) {
  let body = line.trim()
  if (!body.includes('|')) return null
  if (body.startsWith('|')) body = body.slice(1)
  if (body.endsWith('|') && !body.endsWith('\\|')) body = body.slice(0, -1)
  const cells = []
  let part = '', ticks = 0
  for (let i = 0; i < body.length; i++) {
    const char = body[i]
    if (char === '\\' && body[i + 1] === '|') { part += '|'; i++; continue }
    if (char === '\x60') {
      let end = i + 1
      while (body[end] === '\x60') end++
      if (ticks === 0) ticks = end - i
      else if (end - i === ticks) ticks = 0
      part += body.slice(i, end)
      i = end - 1
    } else if (char === '|' && !ticks) {
      cells.push(part.trim())
      part = ''
    } else part += char
  }
  cells.push(part.trim())
  return cells
}
function estimateCell(text) {
  const plain = text.replace(/[\x60*]/g, '')
  return [...plain].reduce((width, char) => width + (char.codePointAt(0) > 255 ? 1.7 : 1), 0)
}
function tableXml(rows, header, render) {
  const columns = rows.reduce((max, row) => Math.max(max, row.length), 1)
  if (columns > 63) return rows.map(row => paragraph('Normal', run(row.join(' │ ')))).join('')
  const weights = Array.from({ length: columns }, (_, i) => {
    const widths = rows.map(row => estimateCell(row[i] || '')).sort((a, b) => a - b)
    return Math.max(7, Math.min(32, Math.max(widths[0], widths[Math.floor((widths.length - 1) * .85)], estimateCell(rows[0][i] || ''))))
  })
  const sum = weights.reduce((total, w) => total + w, 0)
  const sizes = weights.map(w => Math.floor(contentWidth * w / sum))
  sizes[sizes.length - 1] += contentWidth - sizes.reduce((total, w) => total + w, 0)
  const sides = ['top', 'left', 'bottom', 'right', 'insideH', 'insideV'].map(side =>
    '<w:' + side + ' w:val="single" w:sz="4" w:color="' + border + '"/>').join('')
  const margins = ['top', 'left', 'bottom', 'right'].map(side =>
    '<w:' + side + ' w:w="' + (side === 'top' || side === 'bottom' ? 38 : 80) + '" w:type="dxa"/>').join('')
  const body = rows.map((cells, i) => {
    const isHead = header && i === 0
    const rowProps = (cells.every(cell => cell.length < 300) ? '<w:cantSplit/>' : '') + (isHead ? '<w:tblHeader/>' : '')
    return '<w:tr><w:trPr>' + rowProps + '</w:trPr>' + sizes.map((width, col) => '<w:tc><w:tcPr>' +
      '<w:tcW w:w="' + width + '" w:type="dxa"/>' + (isHead ? shading('E6EFE8') : i % 2 === 0 ? shading('F7F9F7') : '') +
      '<w:vAlign w:val="center"/></w:tcPr>' + paragraph(isHead ? 'TableHeading' : 'TableText', render(cells[col] || '')) + '</w:tc>').join('') + '</w:tr>'
  }).join('')
  return '<w:tbl><w:tblPr><w:tblW w:w="' + contentWidth + '" w:type="dxa"/><w:tblBorders>' + sides +
    '</w:tblBorders><w:tblLayout w:type="fixed"/><w:tblCellMar>' + margins + '</w:tblCellMar></w:tblPr><w:tblGrid>' +
    sizes.map(width => '<w:gridCol w:w="' + width + '"/>').join('') + '</w:tblGrid>' + body + '</w:tbl>'
}

const headingMark = /^ {0,3}(#{1,6})[ \t]+(.+)$/
const fence = /^([ ]*)(\x60{3,}|~{3,})(.*)$/
const listItem = /^(\s*)([-*+]|\d+[.)])([ \t]+)(.+)$/
function keepWithExample(rows, i, markdown) {
  if (rows[i].line.trim().length > 80) return ''
  let next = i + 1
  while (next < rows.length && !rows[next].line.trim()) next++
  if (next === rows.length) return ''
  const table = rows[next].anchor?.table != null || markdown && next + 1 < rows.length &&
    markdownCells(rows[next].line) && markdownCells(rows[next + 1].line)?.every(cell => /^:?-{3,}:?$/.test(cell))
  return table || fence.test(rows[next].line) ? '<w:keepNext/>' : ''
}
function heading(row, markdown) {
  const mark = markdown && row.line.match(headingMark)
  if (mark) return { level: mark[1].length, text: mark[2].replace(/\s+#+\s*$/, '') }
  if (row.section?.title.trim() === row.line.trim())
    return { level: Math.max(1, Math.min(6, row.section.level)), text: row.line.trim() }
  if (/^(?:第[零一二三四五六七八九十百\d]+[章节篇]|[一二三四五六七八九十]+、|[0-9]+(?:\.[0-9]+)+[.、]?\s)\s*\S/.test(row.line)
      && row.line.length <= 58 && !/[。；;！？!?]$/.test(row.line))
    return { level: /^第.+[章篇]/.test(row.line) ? 1 : 2, text: row.line.trim() }
  return null
}
function sourceBody(text, options, links) {
  const rows = sourceLines(text, options.version, options.edits || [])
  const format = options.version?.source?.format?.toUpperCase()
  const markdown = !['PDF', 'DOCX'].includes(format)
  const render = value => markdown ? inline(value, links) : run(value)
  const levels = rows.map(row => heading(row, markdown)?.level).filter(Boolean)
  const base = levels.reduce((smallest, level) => Math.min(smallest, level), 6)
  const blocks = []
  let codeCount = 0
  let listContentIndent = null
  for (let i = 0; i < rows.length; i++) {
    const row = rows[i], line = row.line
    const cells = importedCells(row)
    if (cells) {
      const grid = [cells]
      while (i + 1 < rows.length && rows[i + 1].anchor?.table === row.anchor.table) {
        const next = importedCells(rows[i + 1])
        if (!next) break
        grid.push(next)
        i++
      }
      const header = cells.length > 1 && cells.every(cell => cell.length <= 32) &&
        cells.some(cell => /^(?:参数名|参数类型|序号|编号|名称|描述|需求编号|ID|Name|Description|Parameter)$/i.test(cell.trim()))
      blocks.push(tableXml(grid, header, run))
      continue
    }
    if (!line.trim()) continue
    const indentation = line.match(/^ */)[0].length
    if (listContentIndent != null && indentation < listContentIndent) listContentIndent = null
    // Uploaded Word revisions can contain fences restored from the previous export's code bookmarks.
    const opening = line.match(fence)
    const nested = listContentIndent != null && indentation >= listContentIndent && indentation <= listContentIndent + 3
    if (opening && (indentation <= 3 || nested)) {
      const marker = opening[2]
      const minimum = nested ? listContentIndent : 0
      const closing = new RegExp('^ {' + minimum + ',' + (minimum + 3) + '}' + marker[0] + '{' + marker.length + ',}[ \\t]*$')
      let end = i + 1
      while (end < rows.length && !closing.test(rows[end].line)) end++
      // An unclosed fence still denotes code to the end of a Markdown document.
      const code = rows.slice(i + 1, end).map(entry => entry.line)
      const short = code.length <= 10 && code.every(part => part.length < 100)
      const info = opening[3].trim()
      const id = ++codeCount
      const name = (end === rows.length ? 'ReqCodeOpen_' : 'ReqCode_') + id + '_' + (info || 'text')
      let contents
      if ((!info || /^[a-zA-Z0-9_]+$/.test(info)) && name.length <= 40) {
        contents = '<w:bookmarkStart w:id="' + id + '" w:name="' + name + '"/>' +
          run(code.join('\n')) + '<w:bookmarkEnd w:id="' + id + '"/>'
      } else {
        // Keep unusual fence attributes readable and intact on reimport.
        contents = run(rows.slice(i, Math.min(end + 1, rows.length)).map(entry => entry.line).join('\n'))
      }
      blocks.push(paragraph('CodeBlock', contents, short ? '<w:keepLines/>' : ''))
      i = end
      continue
    }
    const columns = markdown && markdownCells(line)
    if (columns && i + 1 < rows.length) {
      const delimiter = markdownCells(rows[i + 1].line)
      if (delimiter?.length === columns.length && delimiter.every(cell => /^:?-{3,}:?$/.test(cell))) {
        const grid = [columns]
        i++
        while (i + 1 < rows.length) {
          const next = markdownCells(rows[i + 1].line)
          if (!next || next.length !== columns.length) break
          grid.push(next)
          i++
        }
        blocks.push(tableXml(grid, true, render))
        continue
      }
    }
    const section = heading(row, markdown)
    if (section) {
      const level = Math.max(1, Math.min(6, section.level - base + 1))
      blocks.push(paragraph('Heading' + level, render(section.text)))
      continue
    }
    if (markdown && i + 1 < rows.length && line.trim().length < 100 && /^(?:={3,}|-{3,})\s*$/.test(rows[i + 1].line)) {
      blocks.push(paragraph(rows[++i].line.startsWith('=') ? 'Heading1' : 'Heading2', render(line)))
      continue
    }
    const list = markdown && line.match(listItem)
    if (list) {
      const level = Math.min(7, Math.floor(list[1].replace(/\t/g, '    ').length / 2))
      listContentIndent = list[1].length + list[2].length + list[3].length
      const inset = 330 + level * 270
      const indent = '<w:tabs><w:tab w:val="left" w:pos="' + inset + '"/></w:tabs><w:ind w:left="' + inset + '" w:hanging="260"/>'
      const point = list[2].length === 1 ? '•' : list[2]
      blocks.push(paragraph('BodyList', run(point) + tab + render(list[4]), keepWithExample(rows, i, markdown) + indent))
      continue
    }
    const quote = markdown && line.match(/^>\s?(.*)$/)
    blocks.push(quote ? paragraph('Quote', render(quote[1])) : paragraph('Normal', render(line), keepWithExample(rows, i, markdown)))
  }
  return blocks.join('')
}

const pageRule = (side, hex) => '<w:pBdr><w:' + side + ' w:val="single" w:sz="5" w:space="6" w:color="' + hex + '"/></w:pBdr>'
const rightTab = '<w:tabs><w:tab w:val="right" w:pos="' + contentWidth + '"/></w:tabs>'
function relationships(entries) {
  return declaration + '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">' +
    entries.map(([id, type, target, external]) => '<Relationship Id="' + id + '" Type="' + rel + '/' + type +
      '" Target="' + escape(target) + '"' + (external ? ' TargetMode="External"' : '') + '/>').join('') + '</Relationships>'
}

export function makeRevisionWord(title, text, options = {}) {
  const links = new Map()
  const body = sourceBody(text, options, links)
  const header = declaration + '<w:hdr xmlns:w="' + word + '">' + paragraph('PageLabel',
    run(options.documentTitle || title, '<w:b/>' + color(green) + size(22)) +
    (options.versionLabel ? tab + run(options.versionLabel) : ''), pageRule('bottom', 'A0B8A9') + rightTab) + '</w:hdr>'
  const footer = declaration + '<w:ftr xmlns:w="' + word + '">' + paragraph('PageLabel', run('第 ') +
    '<w:fldSimple w:instr="PAGE">' + run('1') + '</w:fldSimple>' + run(' 页'), pageRule('top', border) + '<w:jc w:val="right"/>') + '</w:ftr>'
  const document = declaration + '<w:document xmlns:w="' + word + '" xmlns:r="' + rel + '"><w:body>' + body +
    '<w:sectPr><w:headerReference w:type="default" r:id="header"/><w:footerReference w:type="default" r:id="footer"/>' +
    '<w:pgSz w:w="11906" w:h="16838"/><w:pgMar w:top="1230" w:right="1250" w:bottom="1140" w:left="1250" w:header="610" w:footer="590" w:gutter="0"/></w:sectPr></w:body></w:document>'
  const overrides = Object.entries({ document: 'document.main', styles: 'styles', header1: 'header', footer1: 'footer' }).map(([part, type]) =>
    '<Override PartName="/word/' + part + '.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.' + type + '+xml"/>').join('')
  const parts = {
    '[Content_Types].xml': declaration + '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">' +
      '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/>' + overrides + '</Types>',
    '_rels/.rels': relationships([['rId1', 'officeDocument', 'word/document.xml']]),
    'word/document.xml': document,
    'word/styles.xml': stylesXml(),
    'word/header1.xml': header,
    'word/footer1.xml': footer,
    'word/_rels/document.xml.rels': relationships([
      ['styles', 'styles', 'styles.xml'], ['header', 'header', 'header1.xml'], ['footer', 'footer', 'footer1.xml'],
      ...Array.from(links, ([address, id]) => [id, 'hyperlink', address, true]),
    ]),
  }
  return zipSync(Object.fromEntries(Object.entries(parts).map(([path, xml]) => [path, strToU8(xml)])))
}
