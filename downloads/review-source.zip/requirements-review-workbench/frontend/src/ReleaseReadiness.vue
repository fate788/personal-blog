<script setup>
import { computed, ref, watch } from 'vue'
import { ArrowUpRight, Check, ChevronLeft, ChevronRight, CircleAlert, ClipboardCheck, Download, FileText, Link2, RotateCcw, Search } from 'lucide-vue-next'
import { api, offline } from './api.js'
import ExecutionEvidence from './ExecutionEvidence.vue'
import DeliveryChecklist from './DeliveryChecklist.vue'
import WorkspaceSelect from './WorkspaceSelect.vue'
import { sourceLocation } from './workflow.js'

const props = defineProps({
  documents: { type: Array, default: () => [] },
  packs: { type: Array, default: () => [] },
  initialDocumentId: String,
  initialVersionId: String,
  initialRunId: String,
  canAudit: Boolean,
  guided: Boolean,
})
const emit = defineEmits(['source', 'review', 'start-review', 'issues', 'report', 'selection'])

const documentId = ref('')
const versionId = ref('')
const chosenRunId = ref('')
const runOptions = ref([])
const readiness = ref(null)
const trace = ref(null)
const execution = ref(null)
const readinessError = ref('')
const traceError = ref('')
const refreshing = ref(0)
const filter = ref('all')
const search = ref('')
const page = ref(1)
const pageSize = 20

const document = computed(() => props.documents.find(item => item.id === documentId.value))
const versions = computed(() => document.value?.versions || [])
const version = computed(() => versions.value.find(item => item.id === versionId.value))
const selectedReview = computed(() => readiness.value?.review)
const documentOptions = computed(() => props.documents.map(item => ({ value: item.id, label: item.title })))
const versionOptions = computed(() => versions.value.map(item => ({ value: item.id, label: 'V' + item.number })))
const reviewOptions = computed(() => runOptions.value.map(run => ({ value: run.id, label: runLabel(run) })))
const semanticReview = computed(() => selectedReview.value?.mode === 'MODEL' ? selectedReview.value : null)
const fileBase = computed(() => version.value && '/api/documents/' + encodeURIComponent(documentId.value) +
  '/versions/' + encodeURIComponent(versionId.value))

const reviewStates = { COMPLETED: '已完成', PARTIAL: '部分完成', FAILED: '失败', QUEUED: '排队中', RUNNING: '进行中' }
const evidenceTypes = { TABLE: '表内验收条件', INLINE: '内嵌验收条件', CLAUSE: '验收条款引用' }
const stepStates = {
  READY: { label: '已核对', icon: Check, tone: 'ready' },
  ATTENTION: { label: '待处理', icon: CircleAlert, tone: 'attention' },
  UNKNOWN: { label: '待核对', icon: ClipboardCheck, tone: 'unknown' },
}
const stamp = new Intl.DateTimeFormat('zh-CN', { timeZone: 'Asia/Shanghai', year: 'numeric', month: '2-digit',
  day: '2-digit', hour: '2-digit', minute: '2-digit', second: '2-digit', hourCycle: 'h23' })

watch(() => [props.documents, props.initialDocumentId, props.initialVersionId], ([documents, firstDocument, firstVersion], previous) => {
  const initial = documents.find(item => item.id === firstDocument)
  const requested = !previous || firstDocument !== previous[1] || firstVersion !== previous[2]
  const current = documents.find(item => item.id === documentId.value)
  const next = (requested && initial) || current || initial || documents[0]
  documentId.value = next?.id || ''
  const startVersion = requested && initial?.id === next?.id ? firstVersion : versionId.value
  versionId.value = next?.versions?.find(item => item.id === startVersion)?.id || next?.versions?.[0]?.id || ''
}, { immediate: true })

function selectDocument(id) {
  emit('selection', id, props.documents.find(d => d.id === id)?.versions[0]?.id || '')
}

watch(fileBase, () => {
  chosenRunId.value = ''
  runOptions.value = []
  filter.value = 'all'
  search.value = ''
  execution.value = null
}, { flush: 'sync' })

watch(() => [props.initialDocumentId, props.initialVersionId, props.initialRunId], ([doc, version, run]) => {
  if (doc === documentId.value && version === versionId.value) chosenRunId.value = run || ''
}, { immediate: true })

watch([fileBase, chosenRunId, refreshing], async ([base, runId], _previous, onCleanup) => {
  readiness.value = null
  readinessError.value = ''
  if (!base || offline) return
  let current = true
  onCleanup(() => { current = false })
  try {
    const result = await api(base + '/readiness' + (runId ? '?runId=' + encodeURIComponent(runId) : ''))
    if (!current) return
    if (result.documentId !== documentId.value || result.versionId !== versionId.value) {
      throw new Error('版本已变化，请重新加载。')
    }
    readiness.value = result
    runOptions.value = result.reviews || []
  } catch (error) {
    if (current) readinessError.value = error.message || '交付清单暂不可用。'
  }
}, { immediate: true })

watch([fileBase, refreshing], async ([base], _previous, onCleanup) => {
  trace.value = null
  traceError.value = ''
  if (!base || offline) return
  let current = true
  onCleanup(() => { current = false })
  try {
    const result = await api(base + '/trace')
    if (current) trace.value = result
  } catch (error) {
    if (current) traceError.value = error.message || '验收追溯暂不可用。'
  }
}, { immediate: true })

const requirementRows = computed(() => trace.value?.rows || [])
const ambiguousCount = computed(() => {
  const ambiguous = trace.value?.ambiguousIds
  return Array.isArray(ambiguous) ? ambiguous.length : Number(ambiguous) || 0
})
const missingCount = computed(() => Math.max(0, (trace.value?.requirements ?? 0) - (trace.value?.totalLinked ?? 0)))
const traceStep = computed(() => {
  const title = '验收追溯'
  if (!trace.value) return { title, state: 'UNKNOWN', detail: traceError.value ? '追溯暂未加载。' : '正在准备追溯结果。' }
  if (!trace.value.requirements) return { title, state: 'UNKNOWN', detail: '当前版本未识别到编号需求，请核对原文结构。' }
  if (missingCount.value || ambiguousCount.value) {
    return { title, state: 'ATTENTION',
      detail: '缺少验收依据 ' + missingCount.value + ' 条' + (ambiguousCount.value ? '，编号有歧义 ' + ambiguousCount.value + ' 个。' : '。') }
  }
  return { title, state: 'READY', detail: '已识别的编号需求均找到验收依据。执行情况以实际核验记录为准。' }
})
const requirementCode = value => String(value || '').trim().toUpperCase()
const caseResults = computed(() => {
  const results = new Map()
  for (const row of execution.value?.rows || []) {
    if (row.scope !== 'CASE') continue
    const code = requirementCode(row.requirementId)
    const counts = results.get(code) || { PASS: 0, FAIL: 0, SKIPPED: 0, NOT_RUN: 0 }
    counts[row.status]++
    results.set(code, counts)
  }
  return results
})
const executionStep = computed(() => {
  const key = 'EXECUTIONS'
  const title = '测试执行'
  if (!execution.value) return { key, title, state: 'UNKNOWN', detail: '等待当前版本的执行记录。' }
  const { counts, summaryCounts } = execution.value
  const summaries = Object.values(summaryCounts || {}).reduce((total, count) => total + count, 0)
  if (!caseResults.value.size) {
    return { key, title, state: 'UNKNOWN', detail: summaries
      ? '已有 ' + summaries + ' 条需求级报告。当前版本等待逐用例执行结果。'
      : '当前版本尚无执行记录。' }
  }
  const missing = requirementRows.value.filter(row => !caseResults.value.has(requirementCode(row.code))).length
  const attention = (counts.FAIL || 0) + (counts.SKIPPED || 0) + (counts.NOT_RUN || 0)
  const detail = '已导入用例中通过 ' + (counts.PASS || 0) + '，失败 ' + (counts.FAIL || 0) + '，跳过 ' +
    (counts.SKIPPED || 0) + '，未执行 ' + (counts.NOT_RUN || 0) + '。' +
    (missing ? '仍有 ' + missing + ' 条编号需求缺少用例记录。' : '')
  return { key, title, state: attention || missing ? 'ATTENTION' : 'UNKNOWN',
    detail: detail + (attention || missing ? '' : ' 全量计划中的用例范围待核对。') }
})
const steps = computed(() => [...(readiness.value?.steps || []), { key: 'TRACE', ...traceStep.value }, executionStep.value])
const attentionSteps = computed(() => steps.value.filter(step => step.state === 'ATTENTION').length)
const unknownSteps = computed(() => steps.value.filter(step => step.state === 'UNKNOWN').length)
const checklistSummary = computed(() => {
  if (!readiness.value) return '交付清单'
  if (attentionSteps.value) return attentionSteps.value + ' 项待处理'
  if (unknownSteps.value) return unknownSteps.value + ' 项待核对'
  return '清单已核对'
})

const shownRows = computed(() => {
  const phrase = search.value.trim().toLocaleLowerCase()
  return requirementRows.value.filter(row => {
    const links = row.links || []
    if (filter.value === 'missing' && links.length || filter.value === 'linked' && !links.length) return false
    return !phrase || [row, ...links].some(item =>
      [item.code, item.text].some(value => String(value ?? '').toLocaleLowerCase().includes(phrase)))
  })
})
const pageCount = computed(() => Math.max(1, Math.ceil(shownRows.value.length / pageSize)))
const pageRows = computed(() => shownRows.value.slice((page.value - 1) * pageSize, page.value * pageSize))
watch([trace, filter, search], () => { page.value = 1 })

function runLabel(run) {
  const date = new Date(run.createdAt)
  const name = run.packName || props.packs.find(item => item.id === run.packId)?.name || run.packId
  return [Number.isFinite(date.getTime()) ? stamp.format(date) : '时间待核对', name, run.model, reviewStates[run.status]]
    .filter(Boolean).join(' · ')
}

function source(line, column = null) {
  if (fileBase.value && Number.isInteger(line) && line > 0) emit('source', documentId.value, versionId.value, line, column)
}

function linkLocation(link) {
  const place = sourceLocation(version.value, link.line)
  return Number.isInteger(link.column) ? place + ' · 第 ' + link.column + ' 列' : place
}

function toTrace() {
  window.document.getElementById('version-trace-heading')?.focus()
}

function toExecution() {
  window.document.getElementById('version-executions')?.focus()
}

function toChecklist() {
  window.document.getElementById('version-checklist-heading')?.focus()
}

function jumpToPersonalChecklist() {
  const heading = window.document.getElementById('personal-delivery-checklist-heading')
  heading?.scrollIntoView({ block: 'start' })
  heading?.focus({ preventScroll: true })
}

function updateExecution(snapshot) {
  if (snapshot?.documentId === documentId.value && snapshot.versionId === versionId.value) execution.value = snapshot
}

function failedCases(row) {
  return caseResults.value.get(requirementCode(row.code))?.FAIL || 0
}

function csvCell(value) {
  const original = String(value ?? '')
  const safe = /^[\s\uFEFF]*[=+\-@＝＋－＠]|^[\t\r\n]/.test(original) ? "'" + original : original
  return '"' + safe.replaceAll('"', '""') + '"'
}

function exportTrace() {
  if (!version.value || !shownRows.value.length) return
  const rows = [['文档', '版本', '需求编号', '需求位置', '需求原文', '追溯状态', '验收依据', '验收类型', '验收位置', '验收原文']]
  for (const row of shownRows.value) {
    const links = row.links || []
    for (const link of links.length ? links : [null]) {
      rows.push([document.value.title, 'V' + version.value.number, row.code, sourceLocation(version.value, row.line),
        row.text, link ? '已关联' : '缺少验收依据', link?.code, evidenceTypes[link?.kind],
        link ? linkLocation(link) : '', link?.text])
    }
  }
  const blob = new Blob(['\uFEFF', rows.map(row => row.map(csvCell).join(',')).join('\r\n')], { type: 'text/csv;charset=utf-8' })
  const url = URL.createObjectURL(blob)
  const anchor = window.document.createElement('a')
  const title = document.value.title.replace(/[<>:"/\\|?*]/g, '_').slice(0, 80)
  anchor.href = url
  anchor.download = title + '-V' + version.value.number + '-验收追溯.csv'
  anchor.click()
  window.setTimeout(() => URL.revokeObjectURL(url), 1500)
}
</script>

<template>
  <section class="release-view">
    <header class="page-heading delivery-heading">
      <div>
        <h1>{{ guided ? '第 5 步 · 交付准备' : '交付准备' }}</h1>
        <p>按文档版本核对审查范围、未结问题和验收依据。</p>
      </div>
      <div v-if="version && !offline" class="actions">
        <button type="button" class="button secondary" @click="source(version.items?.[0]?.line || 1)"><FileText :size="17" />查看版本原文<ArrowUpRight :size="14" /></button>
        <button v-if="selectedReview" type="button" class="button primary" data-coach="delivery-report" @click="emit('report', selectedReview.id)">查看同版本报告<ArrowUpRight :size="14" /></button>
      </div>
    </header>

    <section v-if="offline || !version" class="panel delivery-empty">
      <ClipboardCheck :size="25" />
      <h2>{{ offline ? '交付准备在工作区中可用' : '暂无可核对的文档版本' }}</h2>
      <p>{{ offline ? '启动工作区后可核对已导入文档和保存的审查任务。' : '从需求文档导入原件后，即可选择版本查看。' }}</p>
    </section>

    <template v-else>
      <section class="panel delivery-controls" aria-label="交付范围">
        <label>文档
          <WorkspaceSelect :model-value="documentId" :options="documentOptions" label="文档" @update:model-value="selectDocument($event)" />
        </label>
        <label>交付版本
          <WorkspaceSelect :model-value="versionId" :options="versionOptions" label="交付版本" @update:model-value="emit('selection', documentId, $event)" />
        </label>
        <label>对照审查任务
          <WorkspaceSelect :model-value="selectedReview?.id || chosenRunId" :options="reviewOptions" label="对照审查任务"
            :placeholder="readiness ? '暂无已结束任务' : readinessError ? '任务暂不可用' : '加载审查任务'"
            :disabled="!runOptions.length" @update:model-value="emit('selection', documentId, versionId, $event)" />
        </label>
        <button type="button" class="icon-button delivery-refresh" title="刷新交付状态" aria-label="刷新交付状态"
          @click="refreshing++"><RotateCcw :size="16" /></button>
      </section>

      <nav class="delivery-section-nav" aria-label="交付页面章节">
        <button type="button" class="button secondary small" @click="toChecklist"><ClipboardCheck :size="15" /> 交付清单</button>
        <button type="button" class="button secondary small" @click="toExecution"><FileText :size="15" /> 执行记录</button>
        <button type="button" class="button secondary small" @click="toTrace"><Link2 :size="15" /> 验收追溯</button>
        <button v-if="readiness" type="button" class="button secondary small" @click="jumpToPersonalChecklist"><ClipboardCheck :size="15" /> 人工核对清单</button>
      </nav>

      <section class="panel delivery-snapshot" aria-labelledby="version-checklist-heading" :aria-busy="!readiness && !readinessError">
        <div class="panel-heading">
          <div class="delivery-panel-title">
            <ClipboardCheck :size="19" /><h2 id="version-checklist-heading" tabindex="-1">交付清单</h2>
            <span v-if="readiness" class="delivery-status" :class="attentionSteps ? 'attention' : unknownSteps ? 'unknown' : 'ready'">{{ checklistSummary }}</span>
          </div>
          <button v-if="selectedReview" type="button" class="text-button" @click="emit('review', selectedReview.id)">
            查看审查<ArrowUpRight :size="14" />
          </button>
        </div>
        <div v-if="readinessError" class="delivery-inline-state" role="alert">
          <CircleAlert :size="17" /><span>{{ readinessError }}</span>
          <button type="button" class="text-button" @click="refreshing++">重试</button>
        </div>
        <p v-else-if="!readiness" class="delivery-inline-state" role="status">正在加载交付清单…</p>
        <template v-else>
          <dl class="delivery-evidence">
            <div>
              <dt>原件预检提示</dt><dd>{{ readiness.checkCount }}</dd>
              <small>引用、格式和接口示例</small>
            </div>
            <div>
              <dt>模型审查覆盖</dt>
              <dd>{{ semanticReview?.coveredItems ?? '—' }}<span v-if="semanticReview"> / {{ semanticReview.totalItems }}</span></dd>
              <small>{{ semanticReview ? '以完整版本为准' : selectedReview ? '当前任务未运行模型' : '等待审查记录' }}</small>
            </div>
            <div>
              <dt>待复核疑点</dt><dd>{{ semanticReview?.pendingFindings ?? '—' }}</dd>
              <small v-if="semanticReview">已确认未纳入跟进 {{ semanticReview.confirmedUntracked }}</small>
              <small v-else-if="selectedReview">等待模型审查结果</small>
              <small v-else>等待审查记录</small>
            </div>
            <div>
              <dt>已找到验收依据</dt>
              <dd>{{ trace?.totalLinked ?? '—' }}<span v-if="trace"> / {{ trace.requirements }}</span></dd>
              <small v-if="trace">{{ trace.verificationItems }} 条验收依据</small>
              <small v-else>等待追溯结果</small>
            </div>
          </dl>
          <ul class="delivery-steps">
            <li v-for="step in steps" :key="step.key">
              <span class="delivery-step-icon" :class="(stepStates[step.state] || stepStates.UNKNOWN).tone">
                <component :is="(stepStates[step.state] || stepStates.UNKNOWN).icon" :size="16" />
              </span>
              <div><h3>{{ step.title }}</h3><p>{{ step.detail }}</p></div>
              <button v-if="step.key === 'TRACE' && trace" type="button" class="text-button delivery-step-link" @click="toTrace">查看追溯</button>
              <button v-else-if="step.key === 'EXECUTIONS'" type="button" class="text-button delivery-step-link" @click="toExecution">查看执行</button>
              <button v-else-if="step.key === 'DOCUMENT_CHECKS' && readiness.checkCount" type="button" class="text-button delivery-step-link" @click="source(version.items?.[0]?.line || 1)">查看预检</button>
              <button v-else-if="step.key === 'REVIEW_COVERAGE' && !selectedReview && canAudit" type="button" class="text-button delivery-step-link" @click="emit('start-review', documentId, versionId)">发起审查</button>
              <button v-else-if="step.key === 'ISSUE_TRACKING' && readiness.activeIssues" type="button" class="text-button delivery-step-link" @click="emit('issues')">打开问题工作台</button>
              <span v-else class="delivery-status" :class="(stepStates[step.state] || stepStates.UNKNOWN).tone">
                {{ (stepStates[step.state] || stepStates.UNKNOWN).label }}
              </span>
            </li>
          </ul>
        </template>
      </section>

      <div id="version-executions" tabindex="-1">
        <ExecutionEvidence :key="version.id" :document-id="documentId" :version="version"
          :requirements="trace?.rows" :can-import="canAudit" @source="source" @update="updateExecution" />
      </div>

      <section class="panel delivery-trace" aria-labelledby="version-trace-heading" :aria-busy="!trace && !traceError">
        <div class="panel-heading">
          <div>
            <div class="delivery-panel-title"><Link2 :size="19" /><h2 id="version-trace-heading" tabindex="-1">验收追溯</h2></div>
            <p class="delivery-trace-note">按原文明示的验收条件或用例引用关联。执行情况以实际核验记录为准。</p>
          </div>
          <button v-if="trace" type="button" class="button secondary small" :disabled="!shownRows.length" @click="exportTrace">
            <Download :size="16" />导出追溯 CSV
          </button>
        </div>
        <div v-if="traceError" class="delivery-inline-state" role="alert">
          <CircleAlert :size="17" /><span>{{ traceError }}</span>
          <button type="button" class="text-button" @click="refreshing++">重试</button>
        </div>
        <p v-else-if="!trace" class="delivery-inline-state" role="status">正在读取验收依据…</p>
        <template v-else>
          <div v-if="ambiguousCount" class="delivery-trace-warning" role="status">
            <CircleAlert :size="17" />有 {{ ambiguousCount }} 个编号存在歧义，请回到原文核对。
          </div>
          <div v-if="requirementRows.length" class="delivery-trace-controls">
            <div class="delivery-filters" role="group" aria-label="按追溯状态筛选">
              <button v-for="[id, label, count] in [['all', '全部', trace.requirements], ['missing', '缺少依据', missingCount], ['linked', '已关联', trace.totalLinked]]"
                :key="id" type="button" :aria-pressed="filter === id" @click="filter = id">{{ label }} <span>{{ count }}</span></button>
            </div>
            <label class="delivery-search"><Search :size="16" />
              <input v-model="search" type="search" placeholder="搜索需求或验收依据" aria-label="搜索需求和验收原文">
            </label>
          </div>
          <ol v-if="pageRows.length" class="delivery-trace-rows">
            <li v-for="row in pageRows" :key="row.id" class="delivery-trace-row">
              <div>
                <button class="text-button delivery-source-link" type="button" @click="source(row.line)">
                  <strong>{{ row.code }}</strong><span>{{ sourceLocation(version, row.line) }}</span><ArrowUpRight :size="14" />
                </button>
                <span v-if="failedCases(row)" class="delivery-status attention">失败用例 {{ failedCases(row) }}</span>
                <p class="delivery-row-text">{{ row.text }}</p>
              </div>
              <div class="delivery-coverage">
                <span v-if="!row.links?.length" class="delivery-status attention">缺少验收依据</span>
                <template v-else>
                  <ul class="delivery-link-list" aria-label="关联验收依据">
                    <li v-for="link in row.links.slice(0, 4)" :key="link.id">
                      <button class="text-button delivery-source-link" type="button" @click="source(link.line, link.column)">
                        <strong>{{ link.code }}</strong><span v-if="evidenceTypes[link.kind]">{{ evidenceTypes[link.kind] }}</span><span>{{ linkLocation(link) }}</span><ArrowUpRight :size="14" />
                      </button>
                      <p v-if="link.text" class="delivery-row-text">{{ link.text }}</p>
                    </li>
                  </ul>
                  <details v-if="row.links.length > 4" class="delivery-more-links">
                    <summary>其余 {{ row.links.length - 4 }} 条验收依据</summary>
                    <ul class="delivery-link-list" aria-label="其余关联验收依据">
                      <li v-for="link in row.links.slice(4)" :key="link.id">
                        <button class="text-button delivery-source-link" type="button" @click="source(link.line, link.column)">
                          <strong>{{ link.code }}</strong><span v-if="evidenceTypes[link.kind]">{{ evidenceTypes[link.kind] }}</span><span>{{ linkLocation(link) }}</span><ArrowUpRight :size="14" />
                        </button>
                        <p v-if="link.text" class="delivery-row-text">{{ link.text }}</p>
                      </li>
                    </ul>
                  </details>
                </template>
              </div>
            </li>
          </ol>
          <div v-else class="delivery-inline-state" role="status">
            {{ requirementRows.length ? '当前筛选下没有条款。' : '未识别到编号需求。补充需求编号和明确的验收依据后可建立追溯。' }}
          </div>
          <nav v-if="pageCount > 1" class="delivery-pagination" aria-label="追溯分页">
            <span>{{ (page - 1) * pageSize + 1 }}–{{ Math.min(page * pageSize, shownRows.length) }} / {{ shownRows.length }} 条</span>
            <button type="button" class="icon-button" aria-label="上一页" :disabled="page <= 1" @click="page--"><ChevronLeft :size="17" /></button>
            <button type="button" class="icon-button" aria-label="下一页" :disabled="page >= pageCount" @click="page++"><ChevronRight :size="17" /></button>
          </nav>
        </template>
      </section>
      <DeliveryChecklist v-if="readiness" :document-id="documentId" :version-id="versionId"
        :document-title="document.title" :version-number="version.number" :review-id="selectedReview?.id"
        :steps="steps" :execution-revision="execution?.batches?.[0]?.id || ''" />
    </template>
  </section>
</template>

<style scoped>
.release-view { display: grid; gap: 18px; min-width: 0; }
.delivery-heading { align-items: flex-start; margin: 0; }
.delivery-heading p { max-width: 54ch; }
.delivery-controls { display: grid; grid-template-columns: minmax(160px, 1fr) minmax(90px, .35fr) minmax(200px, 1fr) auto; align-items: end; gap: 13px; padding: 15px 18px; }
.delivery-controls label { display: grid; min-width: 0; gap: 6px; color: var(--muted); font-size: 12px; font-weight: 650; }
.delivery-controls .workspace-select { width: 100%; min-width: 0; min-height: 39px; color: var(--text); font-size: 13px; }
.delivery-refresh { min-height: 39px; width: 39px; border: 1px solid var(--line); }
.delivery-section-nav { display: flex; flex-wrap: wrap; gap: 8px; }
.delivery-section-nav button { min-height: 36px; }
#version-executions, #version-checklist-heading, #version-trace-heading, #personal-delivery-checklist-heading { scroll-margin-top: 78px; }
.delivery-panel-title { display: flex; align-items: center; flex-wrap: wrap; gap: 9px; min-width: 0; }
.delivery-panel-title > svg { flex: none; color: var(--primary); }
.delivery-panel-title h2, .delivery-empty h2 { font-size: 16px; line-height: 1.45; }
.delivery-panel-title h2:focus-visible { outline-offset: 5px; }
.delivery-status { display: inline-flex; align-items: center; justify-self: start; width: max-content; max-width: 100%; padding: 4px 8px; border-radius: 5px; font-size: 11px; font-weight: 650; line-height: 1.45; }
.delivery-status.ready, .delivery-step-icon.ready { color: #2c6049; background: #e8f3ec; }
.delivery-status.attention, .delivery-step-icon.attention { color: #895316; background: #fbf0dc; }
.delivery-status.unknown, .delivery-step-icon.unknown { color: #4c5f79; background: #ecf1f7; }
.delivery-evidence { display: grid; grid-template-columns: repeat(4, minmax(0, 1fr)); margin: 0; background: #fbfcfe; border-block-end: 1px solid var(--line); }
.delivery-evidence > div { display: grid; align-content: start; gap: 4px; min-width: 0; padding: 16px 18px; }
.delivery-evidence > div + div { border-inline-start: 1px solid var(--line); }
.delivery-evidence dt, .delivery-evidence small { color: var(--muted); font-size: 12px; }
.delivery-evidence dt { font-weight: 650; }
.delivery-evidence dd { margin: 0; font-size: 23px; font-weight: 700; font-variant-numeric: tabular-nums; line-height: 1.38; }
.delivery-evidence dd span { color: var(--muted); font-size: 14px; font-weight: 560; }
.delivery-steps { display: grid; gap: 0; margin: 0; padding: 1px 18px; list-style: none; }
.delivery-steps li { display: grid; grid-template-columns: auto minmax(0, 1fr) auto; align-items: start; gap: 11px; padding: 13px 0; }
.delivery-steps li + li { border-block-start: 1px solid var(--line); }
.delivery-step-icon { display: grid; place-items: center; width: 31px; height: 31px; border-radius: 7px; }
.delivery-steps h3 { margin: 0 0 3px; font-size: 13px; line-height: 1.4; }
.delivery-steps p, .delivery-trace-note { color: var(--muted); font-size: 12px; line-height: 1.6; }
.delivery-step-link { margin: 3px 0; }
.delivery-trace-note { margin: 5px 0 0; }
.delivery-trace-warning, .delivery-inline-state { display: flex; flex-wrap: wrap; align-items: center; gap: 8px; padding: 13px 18px; line-height: 1.6; }
.delivery-trace-warning { color: #855015; background: #fffaf0; font-size: 12px; border-block-end: 1px solid #f3e7ce; }
.delivery-inline-state { color: var(--muted); font-size: 13px; }
.delivery-empty { display: grid; justify-items: start; gap: 11px; padding: 25px 22px; }
.delivery-empty > svg { color: var(--primary); }
.delivery-empty p { color: var(--muted); line-height: 1.65; }
.delivery-trace-controls { display: flex; flex-wrap: wrap; justify-content: space-between; align-items: center; gap: 8px 13px; padding: 12px 18px; border-block-end: 1px solid var(--line); }
.delivery-filters { display: inline-flex; flex-wrap: wrap; gap: 4px; }
.delivery-filters button { padding: 5px 8px; min-height: 35px; border: 1px solid transparent; border-radius: 6px; color: var(--muted); background: transparent; font-size: 12px; font-weight: 630; white-space: nowrap; }
.delivery-filters button:hover { background: #f2f5fa; }
.delivery-filters button[aria-pressed="true"] { color: var(--primary); background: var(--soft); border-color: var(--line); }
.delivery-filters span { margin-inline-start: 3px; font-variant-numeric: tabular-nums; }
.delivery-search { display: inline-flex; flex: 0 1 245px; gap: 7px; align-items: center; min-width: 0; min-height: 35px; padding: 0 9px; border: 1px solid var(--line); border-radius: 7px; color: var(--muted); }
.delivery-search input { width: 100%; min-width: 0; padding: 6px 0; border: 0; background: transparent; font-size: 12px; }
.delivery-search input:focus-visible { outline-offset: 2px; }
.delivery-search > svg { flex: none; }
.delivery-trace-rows, .delivery-link-list { margin: 0; padding: 0; list-style: none; }
.delivery-trace-row { display: grid; grid-template-columns: minmax(0, 1.15fr) minmax(0, 1fr); gap: 18px; padding: 15px 18px; }
.delivery-trace-row + .delivery-trace-row { border-block-start: 1px solid var(--line); }
.delivery-coverage { border-inline-start: 1px solid var(--line); padding-inline-start: 16px; min-width: 0; }
.delivery-source-link { justify-content: flex-start; flex-wrap: wrap; gap: 3px 7px; width: fit-content; max-width: 100%; padding: 3px 0; text-align: start; white-space: normal; overflow-wrap: anywhere; }
.delivery-source-link > strong { font-size: 13px; }
.delivery-source-link > span { color: var(--muted); font-size: 11px; font-weight: 550; }
.delivery-source-link > svg { flex: none; }
.delivery-row-text { display: -webkit-box; margin-block-start: 3px; overflow: hidden; color: var(--text); font-size: 12px; line-height: 1.6; overflow-wrap: anywhere; -webkit-line-clamp: 3; -webkit-box-orient: vertical; }
.delivery-coverage .delivery-row-text { color: var(--muted); -webkit-line-clamp: 2; }
.delivery-link-list li + li { margin-block-start: 7px; }
.delivery-more-links { margin-block-start: 9px; color: var(--muted); font-size: 12px; }
.delivery-more-links summary { width: fit-content; margin-block-end: 5px; color: var(--primary); cursor: pointer; }
.delivery-pagination { display: flex; justify-content: flex-end; align-items: center; gap: 6px; padding: 8px 13px; border-block-start: 1px solid var(--line); }
.delivery-pagination span { margin-inline-end: 5px; color: var(--muted); font-size: 12px; font-variant-numeric: tabular-nums; }
.delivery-pagination button { width: 34px; height: 34px; }
@media (max-width: 960px) {
  .delivery-controls { grid-template-columns: minmax(0, 1fr) minmax(0, .5fr); gap: 10px; }
  .delivery-controls label:nth-child(3) { grid-column: 1 / 2; }
  .delivery-refresh { justify-self: end; }
}
@media (max-width: 650px) {
  .release-view { gap: 13px; }
  .delivery-heading { flex-wrap: wrap; }
  .delivery-controls, .delivery-trace-controls, .delivery-trace-row, .delivery-inline-state { padding-inline: 12px; }
  .delivery-evidence { grid-template-columns: repeat(2, minmax(0, 1fr)); }
  .delivery-evidence > div { padding: 12px; }
  .delivery-evidence > div:nth-child(3) { border-inline-start: 0; }
  .delivery-evidence > div:nth-child(n+3) { border-block-start: 1px solid var(--line); }
  .delivery-steps { padding-inline: 12px; }
  .delivery-steps li { gap: 8px; }
  .delivery-steps li > :last-child { grid-column: 2; }
  .delivery-trace .panel-heading { align-items: flex-start; flex-wrap: wrap; }
  .delivery-trace-row { grid-template-columns: minmax(0, 1fr); gap: 8px; }
  .delivery-coverage { margin-inline-start: 4px; padding-inline-start: 8px; }
  .delivery-search { flex-basis: 100%; }
}
</style>
