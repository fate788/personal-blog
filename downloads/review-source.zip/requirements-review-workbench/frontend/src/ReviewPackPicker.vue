<script setup>
import { computed, ref } from 'vue'
import {
  ArrowRight, ArrowUpRight, Check, ChevronRight, ClipboardCheck, Copy, Pencil, Scale, ShieldCheck, Target,
} from 'lucide-vue-next'
import WorkspaceSelect from './WorkspaceSelect.vue'
import CustomPackEditor from './CustomPackEditor.vue'
import { reviewPackProfile } from './review-pack-profiles.js'

const props = defineProps({
  modelValue: String,
  packs: { type: Array, default: () => [] },
  catalog: Boolean,
  disabled: Boolean,
  allowStart: Boolean,
  manage: Boolean,
  projectId: String,
})
const emit = defineEmits(['update:modelValue', 'start', 'saved'])
const editingPack = ref(null)
const icons = {
  general: ClipboardCheck,
  'information-security': ShieldCheck,
  'business-fit': Target,
  'legal-risk': Scale,
}
const packageOrder = Object.keys(icons)
const orderOf = id => packageOrder.includes(id) ? packageOrder.indexOf(id) : packageOrder.length
const orderedPacks = computed(() => [...props.packs].sort((a, b) => orderOf(a.id) - orderOf(b.id)))
const selected = computed(() => props.packs.find(item => item.id === props.modelValue)
  || (props.catalog ? orderedPacks.value[0] : undefined))
const profile = computed(() => reviewPackProfile(selected.value))
const options = computed(() => orderedPacks.value.map(pack => ({
  value: pack.id,
  label: pack.name,
  detail: pack.basePackId ? '项目审查包 · V' + pack.version + (pack.description ? ' · ' + pack.description : '') : reviewPackProfile(pack).goal,
})))
const groups = computed(() => [
  { name: '常规审查', packs: orderedPacks.value.filter(item => item.id === 'general') },
  { name: '专项审查', packs: orderedPacks.value.filter(item => item.id !== 'general' && !item.basePackId) },
  { name: '项目审查包', packs: orderedPacks.value.filter(item => item.basePackId) },
].filter(group => group.packs.length))

function saved(pack, projectId) {
  editingPack.value = null
  emit('saved', pack, projectId)
  emit('update:modelValue', pack.id)
}
</script>

<template>
  <CustomPackEditor v-if="catalog && editingPack && manage" :pack="editingPack" :project-id="projectId"
    @cancel="editingPack = null" @saved="saved" />
  <div v-else class="review-pack-picker" :class="{ 'is-catalog': catalog }">
    <div v-if="catalog" class="panel pack-navigation" role="group" aria-label="按目标选择审查包">
      <template v-for="group in groups" :key="group.name">
        <h2>{{ group.name }}</h2>
        <button v-for="pack in group.packs" :key="pack.id" class="pack-choice" type="button"
          :data-pack-id="pack.id" :aria-pressed="selected?.id === pack.id"
          @click="emit('update:modelValue', pack.id)">
          <component :is="icons[pack.basePackId || pack.id] || ClipboardCheck" :size="19" aria-hidden="true" />
          <span>{{ pack.name }}</span>
          <Check v-if="selected?.id === pack.id" class="pack-selected" :size="16" aria-hidden="true" />
        </button>
      </template>
    </div>
    <div v-else class="review-select-field">
      <span>审查包</span>
      <WorkspaceSelect :model-value="modelValue" :options="options" label="审查包" :disabled="disabled"
        @update:model-value="emit('update:modelValue', $event)" />
    </div>

    <section v-if="selected" :key="selected.id" data-pack-guide :data-selected-pack="selected.id"
      class="pack-guide" :class="{ panel: catalog }" :aria-label="selected.name + '说明'">
      <template v-if="catalog">
        <div class="pack-guide-heading">
          <div>
            <h2>{{ selected.name }}</h2>
            <small v-if="selected.basePackId" class="pack-version">项目审查包 · V{{ selected.version }} · {{ selected.rules.length }} 个检查项</small>
            <p>{{ profile.goal }}</p>
          </div>
          <div class="pack-actions">
          <button v-if="allowStart" type="button" class="button primary small" @click="emit('start', selected.id)">
            用这个审查包 <ArrowRight :size="16" aria-hidden="true" />
          </button>
          <button v-if="manage && projectId && !selected.basePackId" type="button" class="button secondary small" data-pack-copy @click="editingPack = selected">
            <Copy :size="15" aria-hidden="true" /> 基于模板自定义
          </button>
          <button v-else-if="manage && projectId" type="button" class="button secondary small" data-pack-edit @click="editingPack = selected">
            <Pencil :size="15" aria-hidden="true" /> 编辑此包
          </button>
          </div>
        </div>
        <dl class="pack-facts">
          <div v-if="profile.audience"><dt>适合谁</dt><dd>{{ profile.audience }}</dd></div>
          <div v-if="profile.materials"><dt>准备什么</dt><dd>{{ profile.materials }}</dd></div>
        </dl>
      </template>
      <p v-else class="pack-goal">{{ profile.goal }}</p>

      <div v-if="profile.example" data-pack-example class="pack-example">
        <strong>示例会发现什么</strong>
        <p>{{ profile.example }}</p>
        <p v-if="catalog" class="pack-example-result">{{ profile.result }}</p>
      </div>
      <template v-if="catalog">
        <div class="pack-checks">
          <h3>会检查什么</h3>
          <ul>
            <li v-for="rule in selected.rules" :key="rule.id">{{ rule.name }}</li>
          </ul>
        </div>
        <p v-if="profile.boundary" class="pack-boundary">{{ profile.boundary }}</p>
        <p class="pack-execution">{{ profile.requiresModel ? '执行方式为 AI 审查。' : '用 AI 核对以上审核项。本地检查适合扫描原文编号、引用、接口示例和项目规则。' }}</p>
        <a v-if="profile.reference" class="pack-reference" :href="profile.reference.url" target="_blank" rel="noopener noreferrer">
          {{ profile.reference.label }} <ArrowUpRight :size="14" aria-hidden="true" />
        </a>
        <details v-if="selected.rules?.length" class="pack-rule-details">
          <summary>查看检查规则 <ChevronRight :size="15" aria-hidden="true" /></summary>
          <div class="rule-list">
            <details v-for="rule in selected.rules" :key="rule.id">
              <summary><span class="pill neutral">{{ rule.id }}</span><strong>{{ rule.name }}</strong><ChevronRight :size="15" aria-hidden="true" /></summary>
              <dl>
                <dt>审核问题</dt><dd>{{ rule.question }}</dd>
                <template v-if="rule.applies"><dt>适用条件</dt><dd>{{ rule.applies }}</dd></template>
                <template v-if="rule.criterion"><dt>判定说明</dt><dd>{{ rule.criterion }}</dd></template>
                <template v-if="rule.example"><dt>示例</dt><dd>{{ rule.example }}</dd></template>
              </dl>
            </details>
          </div>
        </details>
      </template>
      <details v-else-if="profile.materials" class="pack-compact-details">
        <summary>查看材料、结果与适用范围 <ChevronRight :size="14" aria-hidden="true" /></summary>
        <dl class="pack-facts">
          <div><dt>准备什么</dt><dd>{{ profile.materials }}</dd></div>
          <div><dt>结果示例</dt><dd>{{ profile.result }}</dd></div>
          <div><dt>适用范围</dt><dd>{{ profile.boundary }}</dd></div>
        </dl>
      </details>
    </section>
  </div>
</template>

<style scoped>
.review-pack-picker { display: grid; gap: 10px; min-width: 0; }
.review-pack-picker.is-catalog {
  grid-template-columns: minmax(220px, .46fr) minmax(0, 1fr);
  align-items: start;
  gap: 20px;
}
.pack-navigation { display: grid; gap: 6px; padding: 14px; }
.pack-navigation h2 { margin: 2px 4px 7px; font-size: 14px; line-height: 1.5; }
.pack-navigation h2:not(:first-child) { margin-top: 9px; padding-top: 11px; border-top: 1px solid var(--line); }
.pack-choice {
  display: grid;
  grid-template-columns: 19px minmax(0, 1fr) 16px;
  gap: 10px;
  align-items: center;
  min-height: 45px;
  padding: 8px 10px;
  border: 1px solid transparent;
  border-radius: 8px;
  background: transparent;
  color: var(--text);
  text-align: left;
  line-height: 1.45;
}
.pack-choice svg { color: var(--primary); }
.pack-choice span, .pack-guide { overflow-wrap: anywhere; }
.pack-choice:hover { background: #f4f0e5; }
.pack-choice[aria-pressed=true] { background: #e6eee4; border-color: #bacaba; font-weight: 680; }
.pack-choice .pack-selected { justify-self: end; }
.pack-guide {
  color: var(--text);
  min-width: 0;
  border-radius: 9px;
  background: #f6f3ea;
  border: 1px solid var(--line);
  padding: 12px;
  font-size: 13px;
  line-height: 1.65;
}
.pack-guide.panel { background: var(--panel); padding: clamp(17px, 2.5vw, 29px); font-size: 14px; }
.pack-guide-heading { display: flex; justify-content: space-between; gap: 14px; align-items: flex-start; }
.pack-guide-heading h2 { font-family: var(--display-font); font-size: clamp(23px, 3vw, 31px); line-height: 1.32; }
.pack-guide-heading p { color: var(--muted); margin-top: 6px; }
.pack-guide-heading .button { flex: 0 0 auto; min-height: 38px; }
.pack-actions { display: flex; align-items: flex-end; flex-flow: column; gap: 8px; flex: none; }
.pack-version { color: var(--muted); font-variant-numeric: tabular-nums; }
.pack-goal { font-weight: 670; }
.pack-facts {
  display: grid;
  gap: 12px;
  margin: 18px 0;
}
.panel .pack-facts { grid-template-columns: minmax(0, .72fr) minmax(0, 1fr); gap: 13px 24px; }
.pack-facts dt, .pack-example strong { color: var(--primary); font-weight: 700; }
.pack-facts dd { margin: 3px 0 0; line-height: 1.65; }
.pack-example {
  background: #f6f1e5;
  border-radius: 6px;
  border-inline-start: 2px solid #b79561;
  padding: 9px 12px;
  margin: 8px 0;
}
.pack-guide:not(.panel) .pack-example { background: #fbf8ef; }
.pack-example p { margin: 4px 0 0; }
.pack-example .pack-example-result { color: #4d5a4d; }
.pack-checks { margin-top: 18px; }
.pack-checks h3 { font-size: 14px; }
.pack-checks ul { display: flex; flex-wrap: wrap; gap: 7px; list-style: none; padding: 0; margin: 9px 0 0; }
.pack-checks li { padding: 3px 8px; background: #edf2e9; color: #294b3a; border-radius: 5px; font-size: 13px; }
.pack-boundary { color: var(--muted); margin: 15px 0 7px; }
.pack-execution { color: var(--muted); }
.pack-reference { display: inline-flex; align-items: center; gap: 5px; margin-top: 9px; color: var(--primary); }
.pack-rule-details { border-top: 1px solid var(--line); margin-top: 15px; padding-top: 9px; }
.pack-rule-details .rule-list { padding-inline: 0; }
.pack-rule-details > summary, .pack-compact-details > summary {
  display: flex;
  align-items: center;
  gap: 6px;
  color: var(--primary);
  font-weight: 650;
  cursor: pointer;
  list-style: none;
}
.pack-rule-details > summary::-webkit-details-marker, .pack-compact-details > summary::-webkit-details-marker { display: none; }
.pack-rule-details[open] > summary svg, .pack-compact-details[open] > summary svg { transform: rotate(90deg); }
.pack-compact-details .pack-facts { margin: 9px 0 0; }
@media (max-width: 790px) {
  .review-pack-picker.is-catalog { grid-template-columns: minmax(0, 1fr); gap: 14px; }
  .pack-navigation { grid-template-columns: repeat(2, minmax(0, 1fr)); padding: 10px; }
  .pack-navigation h2 { grid-column: 1 / -1; margin-bottom: 3px; }
  .pack-choice { gap: 6px; padding-inline: 7px; }
}
@media (max-width: 450px) {
  .pack-guide-heading { flex-wrap: wrap; }
  .pack-actions { flex-flow: row wrap; }
  .panel .pack-facts { grid-template-columns: 1fr; }
  .pack-choice { grid-template-columns: 16px minmax(0, 1fr); }
  .pack-choice svg { width: 16px; }
  .pack-choice .pack-selected { display: none; }
}
</style>
