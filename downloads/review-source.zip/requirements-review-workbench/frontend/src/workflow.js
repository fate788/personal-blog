export const projectIdentity = role => role === 'OWNER' ? '项目所有者' : '项目成员'

export const issueStates = {
  OPEN: '待处理',
  IN_PROGRESS: '处理中',
  FIXED: '待复查',
  VERIFIED: '已核验',
  DISMISSED: '已关闭',
}

export const transitions = {
  OPEN: ['IN_PROGRESS', 'FIXED', 'DISMISSED'],
  IN_PROGRESS: ['OPEN', 'FIXED', 'DISMISSED'],
  FIXED: ['OPEN', 'IN_PROGRESS', 'VERIFIED', 'DISMISSED'],
  VERIFIED: ['OPEN'],
  DISMISSED: ['OPEN'],
}

export const validationKinds = {
  CONFLICT: '条款对照',
  INTERNAL_CALCULATION: '文档内计算',
  EXTERNAL_FACT: '外部事实待核验',
}

export const comparisonDimensions = [
  ['subjectQuote', '适用主体'],
  ['objectQuote', '约束对象'],
  ['activityQuote', '约束行为'],
  ['conditionQuote', '适用条件'],
  ['consequenceQuote', '条款结论'],
]

export function sourceLocation(version, line) {
  const anchor = version?.source?.anchors?.[line]
  if (!anchor) return '第 ' + line + ' 行'
  if (anchor.page) {
    const pages = anchor.endPage && anchor.endPage !== anchor.page ? anchor.page + '–' + anchor.endPage : anchor.page
    return '原件第 ' + pages + ' 页' + (anchor.table && anchor.row ? ' · 表 ' + anchor.table + ' 第 ' + anchor.row + ' 行' : '')
  }
  if (anchor.table && anchor.row) return '表 ' + anchor.table + ' · 第 ' + anchor.row + ' 行'
  if (anchor.startLine) return '原件第 ' + anchor.startLine +
    (anchor.endLine && anchor.endLine !== anchor.startLine ? '–' + anchor.endLine : '') + ' 行'
  return '第 ' + line + ' 行'
}

export function sourceGutterNumber(version, line) {
  const source = version?.source
  if (!source?.fileName || source.format?.toUpperCase() === 'PDF') return line
  return source.anchors?.[line]?.startLine || ''
}

export const terminal = run => !['QUEUED', 'RUNNING'].includes(run?.status)

export function isLocalRuleReview(run) {
  return run?.mode === 'DEMO' && run.model === '本地规则检查'
}

const reviewInterruptions = {
  REVIEW_ENGINE_CHANGED: {
    label: '审查条件已更新',
    title: '排队期间审查条件发生了变化',
    detail: '请按当前配置重新提交审查。',
    retryNow: true,
  },
  MODEL_BILLING: {
    billing: true,
    label: '服务额度受限',
    title: '模型服务拒绝本次审查',
    detail: '模型服务返回 HTTP 402。请由服务管理员核对账户余额或可用额度。',
  },
  MODEL_ACCESS: {
    label: '模型服务不可用',
    title: '当前无法访问模型服务',
    detail: '请由服务管理员检查模型服务的连接与使用权限。',
  },
  MODEL_RATE_LIMIT: {
    label: '模型服务限流',
    title: '模型服务暂时限流',
    detail: '模型服务的请求频率达到上限。等待服务恢复后可继续审查。',
  },
  TIMEOUT: {
    label: '模型响应超时',
    title: '本次模型审查超过等待时间',
    detail: '可以重新提交，也可在审查弹窗缩小范围。',
    retryNow: true,
  },
  UNUSABLE: {
    label: '模型结果待重试',
    title: '模型未返回可核验的判断',
    detail: '响应不完整或未通过格式、证据校验。可以重新提交，也可在审查弹窗缩小范围。',
    retryNow: true,
  },
  OTHER: {
    label: '模型审查未完成',
    title: '本次模型审查未完成',
    detail: '打开检查范围与执行记录可查看原因。',
    retryNow: true,
  },
}

export function reviewInterruption(run) {
  if (run?.mode !== 'MODEL' || !['FAILED', 'PARTIAL'].includes(run.status)) return null
  const code = run.modelTrace?.findLast(entry => entry.outbound !== false)?.statusCode
  const types = new Set(run.diagnostics?.map(entry => entry.type))
  if (types.has('REVIEW_ENGINE_CHANGED')) return reviewInterruptions.REVIEW_ENGINE_CHANGED
  if (code === 402 || types.has('MODEL_BILLING')) return reviewInterruptions.MODEL_BILLING
  if (code === 429 || types.has('MODEL_RATE_LIMIT')) return reviewInterruptions.MODEL_RATE_LIMIT
  if ([401, 403].includes(code) || ['MODEL_ACCESS', 'EGRESS_BLOCKED', 'MODEL_CONFIG_CHANGED'].some(type => types.has(type))) {
    return reviewInterruptions.MODEL_ACCESS
  }
  if (run.status !== 'FAILED') return null
  if (types.has('MODEL_TIMEOUT') || types.has('TIME_BUDGET')) return reviewInterruptions.TIMEOUT
  if (['FORMAT_ERROR', 'OUTPUT_TRUNCATED', 'INVALID_EVIDENCE', 'COVERAGE_GAP'].some(type => types.has(type))) {
    return reviewInterruptions.UNUSABLE
  }
  return reviewInterruptions.OTHER
}

export function relatedWarningLabel(warning) {
  if (warning.type === 'WORKED_OCCURRENCE_MISMATCH') return '计算输入'
  if (warning.type === 'SQL_EXAMPLE_FUNCTION_MISMATCH') return '示例结果表头'
  if (warning.type === 'HTTP_REQUEST_CONTEXT_PATH_MISSING') return '请求路径声明'
  if (warning.type === 'HTTP_REQUEST_METHOD_MISMATCH' || warning.type === 'HTTP_SECTION_EXAMPLE_METHOD_DIFFERS') return '接口方法声明'
  return '关联原文'
}
