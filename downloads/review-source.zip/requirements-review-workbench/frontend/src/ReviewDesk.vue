<script setup>
import { computed, nextTick, reactive, ref, watch } from 'vue'
import { ArrowLeft, ArrowUpRight, Check, ChevronDown, CircleAlert, FileText, Link2, ListFilter, RotateCcw, Search, X } from 'lucide-vue-next'
import IssueWorkflow from './IssueWorkflow.vue'
import EvidenceRepairPanel from './EvidenceRepairPanel.vue'
import WorkspaceSelect from './WorkspaceSelect.vue'
import { comparisonDimensions, isLocalRuleReview, issueStates, reviewInterruption, sourceGutterNumber, sourceLocation } from './workflow.js'
import { combinedScopeLabel, isCombinedReview, problemSourceLabel, reviewResult, reviewTemplateId } from './review-findings.js'

const props = defineProps({ run: Object, document: Object, version: Object, pack: Object, busy: Boolean, initialFinding: String,
  issues: Array, members: Array, role: String, currentUser: String, canEdit: Boolean, canDecide: Boolean, canAudit: Boolean, modelReady: Boolean, offline: Boolean,
  flowStage: Number, rechecked: Boolean, canProbe: Boolean, serviceProbe: Object, openRevision: Boolean })
const emit = defineEmits(['back', 'decision', 'report', 'retry', 'continue', 'issue', 'start-model', 'upload-revision', 'view-revision', 'delivery', 'advance-evidence', 'flow-revision', 'repairs-applied', 'repairs-opened', 'check-service', 'locate'])

const desk = ref(null)
const queue = ref(null)
const paper = ref(null)
const sourcePanel = ref(null)
const detail = ref(null)
const returnTarget = ref(null)
const filter = ref('all')
const query = ref('')
const priority = ref('')
const activeId = ref(props.initialFinding || '')
const activeLine = ref(null)
const activeEvidence = ref(null)
const nearbyOnly = ref(false)
const showDiagnostics = ref(props.run.status === 'FAILED' && !reviewInterruption(props.run))
const drafts = reactive(new Map())

const severity = { HIGH: '高', MEDIUM: '中', LOW: '低' }
const severityOptions = [
  { value: '', label: '全部风险' },
  ...Object.entries(severity).map(([value, label]) => ({ value, label: label + '风险' })),
]
const chapterOptions = computed(() => (props.version?.sections || []).map(section => ({
  value: section.line, label: section.title,
})))
const severityOrder = { HIGH: 0, MEDIUM: 1, LOW: 2 }
const decisions = { PENDING: '待确认', CONFIRMED: '已确认', REJECTED: '已排除' }
const filters = [
  ['all', '全部问题'], ['pending', '待确认'], ['tracking', '跟进中'], ['confirmed', '已确认'], ['rejected', '已排除'],
]
const narrowWidth = 740

const needsReview = problem => problem.finding?.decision === 'PENDING'
const result = computed(() => reviewResult(props.run, props.version))
const allProblems = computed(() => [...result.value.listed, ...result.value.excluded])
const problems = computed(() => result.value.listed)
const localProblems = computed(() => problems.value.filter(problem => problem.source === 'rule' || problem.source === 'both'))
const issueByFinding = computed(() => new Map((props.issues || []).map(item => [item.findingId, item])))
const items = computed(() => new Map((props.version?.items || []).map(item => [item.id, item])))
const pendingCount = computed(() => problems.value.filter(needsReview).length)
const hasRejected = computed(() => result.value.excluded.length > 0)
const scope = computed(() => props.run.scope || {})
const canContinue = computed(() => props.canAudit && props.run.mode === 'MODEL' && scope.value.omittedItemIds?.length)
const interruption = computed(() => reviewInterruption(props.run))
const blockedBeforeResults = computed(() => !!interruption.value && !scope.value.coveredChecks && !problems.value.some(problem => problem.kind === 'model'))
const hasRepairMaterial = computed(() => problems.value.length > 0)
const canExportRevision = computed(() => hasRepairMaterial.value || props.document?.versions?.some(v => v.number > props.version?.number))
const diagnostics = computed(() => props.run.diagnostics || [])
const localReview = computed(() => isLocalRuleReview(props.run))
const localFinished = computed(() => localReview.value && ['COMPLETED', 'PARTIAL'].includes(props.run.status))
const status = computed(() => (props.run.status === 'FAILED' && interruption.value?.label) ||
  ({ COMPLETED: '审查完成', PARTIAL: '部分完成', FAILED: '执行失败', QUEUED: '等待审查', RUNNING: '正在审查' }[props.run.status] || props.run.status))
const itemCodes = ids => (ids || []).map(id => items.value.get(id)?.code || id).join('、') || '无'
const findingCode = problem => items.value.get(problem.finding?.itemId)?.code || problem.evidence[0]?.code

function matchesState(problem) {
  if (filter.value === 'pending') return needsReview(problem)
  if (filter.value === 'tracking') return issueByFinding.value.has(problem.id)
  if (filter.value === 'confirmed') return problem.finding?.decision === 'CONFIRMED'
  if (filter.value === 'rejected') return problem.finding?.decision === 'REJECTED'
  return true
}

const results = computed(() => {
  const keyword = query.value.trim().toLowerCase()
  const source = filter.value === 'rejected' ? allProblems.value : problems.value
  return source.filter(problem => {
    if (priority.value && priority.value !== problem.finding?.severity) return false
    if (keyword && ![problem.title, problem.impact, problem.finding?.category, problem.finding?.ruleId, findingCode(problem),
      ...problem.evidence.flatMap(entry => [entry.code, String(entry.line), sourceLocation(props.version, entry.line)])]
      .some(value => value?.toLowerCase().includes(keyword))) return false
    return matchesState(problem)
  }).sort((left, right) => Number(left.kind !== 'rule') - Number(right.kind !== 'rule')
    || Number(!needsReview(left)) - Number(!needsReview(right))
    || (severityOrder[left.finding?.severity] ?? 3) - (severityOrder[right.finding?.severity] ?? 3))
})
const active = computed(() => results.value.find(problem => problem.id === activeId.value) || results.value[0])
const activeFinding = computed(() => active.value?.finding)
const currentIssue = computed(() => issueByFinding.value.get(active.value?.id))
const nextAction = computed(() => {
  if (props.run.status === 'FAILED' && !problems.value.length) return null
  if (props.flowStage === 1) return { title: props.rechecked ? '修订版复查已生成结果' : '当前版本已生成审查结果',
    text: problems.value.length ? '查看发现的问题，并到原文中核对。' : '查看本次结果，确认是否可以进入下一步。', button: '下一步：复核证据', action: 'advance-evidence' }
  if (currentIssue.value?.status === 'FIXED' && currentIssue.value.resolutionVersionId) {
    return { title: '核验修订', text: '打开此问题关联的修订版，核对修复后回到问题记录。', button: '查看关联修订版', action: 'view-revision' }
  }
  const pending = problems.value.find(needsReview)
  if (pending && props.canDecide) return { title: '核对待确认的问题', text: '用原文确认问题，再把需要处理的事项登记下来。', button: '查看待确认问题', action: 'triage', finding: pending }
  const untracked = problems.value.find(problem => problem.finding?.decision === 'CONFIRMED' && !issueByFinding.value.has(problem.id))
  if (untracked && props.canDecide) return { title: '登记已确认的问题', text: '确定负责人及处理状态，后续可关联修订版并核验。', button: '打开跟进表单', action: 'track', finding: untracked }
  const hasFixes = localProblems.value.length > 0 || props.issues?.some(issue => ['OPEN', 'IN_PROGRESS'].includes(issue.status))
  if (hasFixes && props.canEdit && !props.offline && hasRepairMaterial.value) {
    return { title: '选择修订方式', text: '先核对系统给出的改动，也可以导出证据自行修改。',
      button: props.flowStage === 2 ? '下一步：修订与复查' : '查看修订方式', action: 'repair-options' }
  }
  if (hasFixes && props.canEdit) return { title: '根据证据提交修订', text: '修订后保存为新版本，再复查相关提示。',
    button: props.flowStage === 2 ? '下一步：修订与复查' : props.offline ? '编辑修订版' : '上传修订版',
    action: props.flowStage === 2 ? 'flow-revision' : 'upload-revision', optionalRevision: false }
  if (interruption.value) return null
  if (canContinue.value) return { title: '继续覆盖未审查范围', text: '先核对执行明细，再补审剩余条款。', button: '补审未覆盖范围', action: 'continue' }
  if (props.flowStage === 2 && !props.rechecked) return { title: '确认是否需要修订', text: '有修改可保存为新版本，也可以跳过修订，继续核对交付条件。',
    button: '下一步：修订与复查', action: 'flow-revision', optionalRevision: true }
  return { title: props.offline ? '整理审查报告' : '核对交付材料', text: props.offline ? '查看当前审查版本的证据和处理记录。' : '查看本版的审查、问题及验收依据。',
    button: props.flowStage === 2 ? '下一步：检查交付' : props.offline ? '查看审查报告' : '查看交付准备', action: 'delivery' }
})
const comparison = computed(() => activeFinding.value?.comparison)
const comparisonItems = computed(() => [comparison.value?.left, comparison.value?.right].map(side => items.value.get(side?.itemId)))
const note = computed({
  get: () => drafts.get(activeFinding.value?.id) ?? activeFinding.value?.note ?? '',
  set: value => { if (activeFinding.value) drafts.set(activeFinding.value.id, value) },
})
const lines = computed(() => (props.version?.text || '').split(/\r?\n/))
const headings = computed(() => new Set((props.version?.sections || []).map(section => Number(section.line))))
const evidenceByLine = computed(() => {
  const entries = new Map()
  for (const evidence of active.value?.evidence || []) {
    const line = Number(evidence.line)
    if (!entries.has(line)) entries.set(line, evidence)
  }
  return entries
})
const displayedLines = computed(() => {
  const rows = lines.value.map((text, index) => ({ text, line: index + 1 }))
  if (!nearbyOnly.value || !evidenceByLine.value.size) return rows
  const nearby = new Set()
  for (const line of evidenceByLine.value.keys()) {
    for (let offset = -2; offset <= 2; offset++) nearby.add(line + offset)
  }
  return rows.filter(row => nearby.has(row.line))
})

function verdict(problem) {
  if (problem.kind === 'rule') return ['原文可核对', 'neutral']
  const issue = issueByFinding.value.get(problem.id)
  if (issue) return [issueStates[issue.status], issue.status === 'VERIFIED' ? 'success' : 'info']
  if (needsReview(problem)) return [decisions.PENDING, 'amber']
  return [decisions[problem.finding.decision] || '待确认', problem.finding.decision === 'CONFIRMED' ? 'success' : 'neutral']
}

function textParts(text, line) {
  const anchor = Number(activeEvidence.value?.line) === line ? activeEvidence.value : evidenceByLine.value.get(line)
  if (!anchor?.quote || !text) return [{ text: text || ' ', hit: false }]
  const start = Number.isInteger(anchor.start) && text.slice(anchor.start, anchor.end) === anchor.quote
    ? anchor.start : text.indexOf(anchor.quote)
  if (start < 0) return [{ text, hit: false }]
  return [
    { text: text.slice(0, start), hit: false },
    { text: anchor.quote, hit: true },
    { text: text.slice(start + anchor.quote.length), hit: false },
  ]
}

function setFilter(value) {
  filter.value = value
}

function resetFilter() {
  filter.value = 'all'
  query.value = ''
  priority.value = ''
}

async function followNextAction() {
  const next = nextAction.value
  if (!next) return
  if (next.action === 'repair-options') {
    openRepairOptions()
    return
  }
  if (next.action === 'advance-evidence') {
    emit('advance-evidence')
    await nextTick()
    desk.value?.querySelector('.findings-panel')?.scrollIntoView({ block: 'nearest' })
    return
  }
  if (next.action === 'triage' || next.action === 'track') {
    resetFilter()
    setFilter(next.action === 'triage' ? 'pending' : 'confirmed')
    chooseFinding(next.finding)
    await nextTick()
    detail.value?.focus({ preventScroll: true })
    detail.value?.scrollIntoView({ block: 'start' })
  } else if (next.action === 'flow-revision') emit('flow-revision', next.optionalRevision)
  else if (next.action === 'view-revision') emit('view-revision', currentIssue.value.resolutionVersionId)
  else if (next.action === 'delivery' && props.offline) emit('report', props.run.id)
  else emit(next.action)
}

function openRepairOptions() {
  const panel = desk.value?.querySelector('#evidence-repair-panel')
  if (!panel) return
  panel.open = true
  panel.querySelector('summary')?.focus({ preventScroll: true })
  panel.scrollIntoView({ block: 'start' })
  emit('repairs-opened')
}

watch(() => [props.openRevision, props.run.id, canExportRevision.value], ([open, , available]) => {
  if (open && available) nextTick(openRepairOptions)
}, { immediate: true })

function jumpToLine(line, { evidence = null, trigger = null, full = false, reveal = false } = {}) {
  const number = Number(line)
  if (!Number.isInteger(number) || number < 1 || number > lines.value.length) return
  if (full) nearbyOnly.value = false
  activeLine.value = number
  activeEvidence.value = evidence
  returnTarget.value = trigger
  nextTick(() => {
    const row = paper.value?.querySelector('[data-line="' + number + '"]')
    if (!row) return
    if (trigger && (reveal || desk.value?.clientWidth < narrowWidth)) {
      sourcePanel.value?.focus({ preventScroll: true })
      sourcePanel.value?.scrollIntoView({ block: 'start' })
    }
    paper.value.scrollTop = Math.max(0, row.offsetTop - Math.min(72, paper.value.clientHeight / 5))
  })
}

function returnToReview() {
  const trigger = returnTarget.value
  const target = trigger?.isConnected ? trigger : detail.value || queue.value
  target?.focus({ preventScroll: true })
  target?.scrollIntoView({ block: 'center' })
}

function chooseFinding(finding) {
  activeId.value = finding.id
  emit('locate', finding.id)
  const evidence = finding.evidence?.[0]
  if (evidence) jumpToLine(evidence.line, { evidence })
  if (desk.value?.clientWidth < narrowWidth) {
    nextTick(() => {
      detail.value?.focus({ preventScroll: true })
      detail.value?.scrollIntoView({ block: 'start' })
    })
  }
}

function toggleNearby() {
  const previousTarget = returnTarget.value
  nearbyOnly.value = !nearbyOnly.value
  if (nearbyOnly.value && !evidenceByLine.value.has(activeLine.value)) {
    const first = active.value?.evidence?.[0]
    if (first) jumpToLine(first.line, { evidence: first })
  } else if (activeLine.value) jumpToLine(activeLine.value, { evidence: activeEvidence.value })
  returnTarget.value = previousTarget
}

function openWarningPanel() {
  const first = localProblems.value[0]
  if (!first) return
  resetFilter()
  chooseFinding(first)
  nextTick(() => {
    detail.value?.focus({ preventScroll: true })
    detail.value?.scrollIntoView({ block: 'start' })
  })
}

watch(() => props.run.id, () => {
  resetFilter()
  drafts.clear()
  nearbyOnly.value = false
  activeId.value = props.initialFinding || ''
  showDiagnostics.value = props.run.status === 'FAILED' && !reviewInterruption(props.run)
})
watch(() => props.initialFinding, id => {
  if (!id) return
  resetFilter()
  if (allProblems.value.find(problem => problem.id === id)?.finding?.decision === 'REJECTED') setFilter('rejected')
  activeId.value = id
}, { immediate: true })
watch(() => active.value?.id, id => {
  activeLine.value = null
  activeEvidence.value = null
  returnTarget.value = null
  if (!evidenceByLine.value.size) nearbyOnly.value = false
  const first = active.value?.evidence?.[0]
  if (first) jumpToLine(first.line, { evidence: first })
  nextTick(() => {
    const row = Array.from(queue.value?.children || []).find(button => button.dataset.findingId === id)
    if (!row || !queue.value) return
    if (row.offsetTop < queue.value.scrollTop) queue.value.scrollTop = row.offsetTop
    else if (row.offsetTop + row.offsetHeight > queue.value.scrollTop + queue.value.clientHeight) {
      queue.value.scrollTop = row.offsetTop + row.offsetHeight - queue.value.clientHeight
    }
  })
}, { immediate: true })
watch(() => activeFinding.value?.note, saved => {
  const id = activeFinding.value?.id
  if (id && drafts.get(id) === saved) drafts.delete(id)
})
</script>

<template>
  <div ref="desk" class="review-desk">
    <div class="page-heading review-heading">
      <div class="review-heading-copy">
        <button class="text-button back-link" @click="emit('back')"><ArrowLeft :size="16" /> 返回审查任务</button>
        <h1>{{ document?.title || '审查任务' }}</h1>
        <div class="heading-meta">
          <span class="pill" :class="run.status === 'COMPLETED' || localFinished ? 'success' : run.status === 'FAILED' && !interruption ? 'danger' : 'amber'">{{ localFinished ? '原件检查完成' : status }}</span>
          <span>V{{ version?.number ?? '—' }}</span>
          <template v-if="!localReview"><span class="dot"></span><span>{{ pack?.name || '审查包' }}</span></template>
          <span class="dot"></span><span>{{ isCombinedReview(run) ? '本地规则 + AI 语义审查' : localReview ? '本地规则检查' : run.model || 'AI 审查' }}</span>
        </div>
      </div>
      <div class="actions review-heading-actions">
        <button v-if="canExportRevision" class="button secondary" data-open-revision @click="openRepairOptions">导出修订稿</button>
        <button v-if="canAudit && run.status === 'FAILED' && !interruption" class="button primary" @click="emit('retry')"><RotateCcw :size="16" /> 重新审查</button>
        <button class="button secondary" @click="emit('report', run.id)">查看报告 <ArrowUpRight :size="16" /></button>
      </div>
    </div>

    <section v-if="interruption" class="review-interruption" aria-labelledby="review-interruption-title">
      <CircleAlert :size="20" aria-hidden="true" />
      <div class="review-interruption-copy">
        <h2 id="review-interruption-title">{{ interruption.title }}</h2>
        <p>{{ interruption.detail }}</p>
        <p>{{ blockedBeforeResults ? '模型审查尚未返回结果。' : '已保留中断前找到的问题。' }}<template v-if="localProblems.length"> 问题清单包含已查到的原文问题。</template></p>
        <p v-if="serviceProbe?.message" role="status" class="review-probe-message">{{ serviceProbe.message }}</p>
      </div>
      <div class="actions review-interruption-actions">
        <button v-if="localProblems.length" class="button secondary small" @click="openWarningPanel">查看已找到的问题 <ArrowUpRight :size="14" /></button>
        <button v-if="canProbe && modelReady && !interruption.retryNow && !serviceProbe?.success" class="button secondary small" :disabled="serviceProbe?.pending" @click="emit('check-service')">{{ serviceProbe?.pending ? '正在检查服务' : '检查服务状态' }}</button>
        <button v-if="modelReady && (blockedBeforeResults ? canAudit : canContinue)" class="button secondary small" @click="emit(blockedBeforeResults ? 'retry' : 'continue')"><RotateCcw :size="14" />{{ (serviceProbe?.success && !interruption.billing) || interruption.retryNow ? (blockedBeforeResults ? '重新审查' : '补审未覆盖范围') : (blockedBeforeResults ? '服务恢复后重试' : '服务恢复后补审') }}</button>
      </div>
    </section>

    <section v-if="nextAction" class="flow-next" aria-label="下一步">
      <div><small>{{ flowStage == null ? '下一步' : `第 ${flowStage + 1} 步 / 共 5 步` }}</small><h2>{{ nextAction.title }}</h2><p>{{ nextAction.text }}</p></div>
      <button class="button primary small" data-coach="review-next" @click="followNextAction">{{ nextAction.button }} <ArrowUpRight :size="15" /></button>
    </section>

    <section class="review-scope" aria-label="审查问题汇总">
      <div class="review-scope-summary">
        <dl class="scope-board">
          <div><dt>问题清单</dt><dd v-if="result.inconclusive">尚无结论</dd><dd v-else>{{ problems.length }} <small>个</small></dd></div>
        </dl>
        <p v-if="result.sourceSummary" data-problem-sources>{{ result.sourceSummary }}</p>
        <p v-if="isCombinedReview(run)">{{ combinedScopeLabel(run) }}</p>
        <p v-if="reviewTemplateId(run) === 'legal-risk'">AI 初筛发现的个人信息保护线索需由法务复核。</p>
        <p v-if="localReview">检查了文档编号、引用、接口示例和已启用的项目规则。</p>
        <p v-else-if="result.message && problems.length">{{ result.message }}</p>
        <p v-else-if="pendingCount">有 {{ pendingCount }} 个问题还需要结合原文确认。</p>
        <p v-else-if="run.status === 'PARTIAL'">当前数字统计已完成部分找到的问题。</p>
      </div>
      <div class="review-scope-footer">
        <button v-if="localReview && canAudit && modelReady" class="button secondary small" @click="emit('start-model')">发起联合审查 <ArrowUpRight :size="15" /></button>
        <button class="text-button scope-link" :aria-expanded="showDiagnostics" aria-controls="review-run-diagnostics" @click="showDiagnostics = !showDiagnostics">
          {{ showDiagnostics ? '收起执行记录' : '检查范围与执行记录' }} <ChevronDown :size="15" />
        </button>
      </div>
    </section>

    <section v-if="showDiagnostics" id="review-run-diagnostics" class="panel diagnostic-panel" aria-label="检查范围与执行记录" tabindex="-1">
      <dl v-if="localReview" class="diagnostic-facts">
        <div><dt>检查范围</dt><dd>当前版本原文（第 {{ version?.number ?? '—' }} 版）</dd></div>
        <div><dt>任务耗时</dt><dd>{{ run.elapsedMs ?? 0 }} 毫秒</dd></div>
        <div><dt>模型调用</dt><dd>{{ run.usage?.calls ?? 0 }} 次</dd></div>
      </dl>
      <dl v-else class="diagnostic-facts">
        <div v-if="isCombinedReview(run)"><dt>本地规则范围</dt><dd>当前版本全文</dd></div>
        <div v-if="isCombinedReview(run)"><dt>AI 审查范围</dt><dd>所选条款 · {{ run.model }}</dd></div>
        <div><dt>已覆盖条款</dt><dd>{{ itemCodes(scope.coveredItemIds) }}</dd></div>
        <div><dt>未覆盖条款</dt><dd>{{ itemCodes(scope.omittedItemIds) }}</dd></div>
        <div v-if="scope.overBudgetItemIds?.length"><dt>预算外的条款</dt><dd>{{ itemCodes(scope.overBudgetItemIds) }}</dd></div>
        <div v-if="scope.oversizedItemIds?.length"><dt>需拆分的条款</dt><dd>{{ itemCodes(scope.oversizedItemIds) }}</dd></div>
        <div><dt>调用与用量</dt><dd>{{ run.usage?.calls ?? 0 }} 次 · {{ run.elapsedMs ?? 0 }} ms · 输入 {{ run.usage?.inputTokens ?? '—' }} / 输出 {{ run.usage?.outputTokens ?? '—' }} token</dd></div>
      </dl>
      <div v-for="(entry, index) in diagnostics" :key="index" class="diagnostic"><CircleAlert :size="16" /><span>{{ entry.detail || entry.type }}</span></div>
      <details v-if="scope.details?.length" class="batch-detail"><summary>分批明细</summary>
        <p v-for="batch in scope.details" :key="batch.number">第 {{ batch.number }} 批 · {{ batch.completed ? '完成' : '存在未通过的检查' }} · 核验 {{ batch.coveredChecks }} 项<br>目标条款：{{ itemCodes(batch.primaryItemIds) }}<br>关联条款：{{ itemCodes(batch.contextItemIds) }}</p>
      </details>
      <details v-if="run.modelTrace?.length" class="batch-detail"><summary>模型调用记录</summary>
        <div class="table-scroll" tabindex="0"><table><thead><tr><th>批次 / 尝试</th><th>服务与模型</th><th>状态</th><th>耗时</th><th>输入 / 输出 token</th></tr></thead><tbody>
          <tr v-for="entry in run.modelTrace" :key="entry.batch + ':' + entry.attempt"><td>{{ entry.batch }} / {{ entry.attempt }}</td><td>{{ entry.providerLabel }} · {{ entry.actualModel || entry.requestedModel }}</td><td>{{ entry.status }} {{ entry.statusCode || '' }}</td><td>{{ entry.elapsedMs }} ms</td><td>{{ entry.inputTokens ?? '—' }} / {{ entry.outputTokens ?? '—' }}</td></tr>
        </tbody></table></div>
      </details>
    </section>

    <div class="review-grid" :class="{ 'has-detail': active }">
      <section class="panel findings-panel" aria-labelledby="review-problems">
        <div class="panel-heading"><div class="panel-title"><ListFilter :size="19" /><h2 id="review-problems">问题清单</h2></div><span v-if="filter !== 'all' || query || priority" class="count-label" role="status">{{ results.length }} 个</span></div>
        <div v-if="allProblems.some(problem => problem.kind === 'model')" class="tabs finding-tabs" role="group" aria-label="筛选问题">
          <button v-for="[value, label] in filters.filter(([value]) => value !== 'rejected' || hasRejected)" :key="value" :class="{ active: filter === value }" :aria-pressed="filter === value" @click="setFilter(value)">
            {{ label }}
          </button>
        </div>
        <div v-if="allProblems.length" class="finding-search">
          <label class="search"><Search :size="16" /><input v-model="query" type="search" placeholder="搜索问题或原文行号" aria-label="搜索问题"></label>
          <WorkspaceSelect v-if="allProblems.some(problem => problem.finding?.severity)" v-model="priority" :options="severityOptions" label="筛选问题风险" />
        </div>
        <div v-if="results.length" ref="queue" class="finding-list" tabindex="0" aria-label="找到的问题">
          <button v-for="problem in results" :key="problem.id" :data-finding-id="problem.id" :data-problem-source="problem.source" class="finding-toggle"
            :class="{ 'is-current': active?.id === problem.id }" :aria-current="active?.id === problem.id ? 'true' : undefined" aria-controls="review-active-finding" @click="chooseFinding(problem)">
            <span class="queue-copy">
              <strong>{{ problem.title }}</strong>
              <small><span>{{ sourceLocation(version, problem.evidence[0].line) }}</span><span>{{ problemSourceLabel(problem) }}</span><span v-if="problem.finding && severity[problem.finding.severity]" :class="problem.finding.severity.toLowerCase()">{{ severity[problem.finding.severity] }}风险</span></small>
            </span>
            <span class="pill" :class="verdict(problem)[1]">{{ verdict(problem)[0] }}</span>
          </button>
        </div>
        <div v-else class="empty compact">
          <template v-if="filter !== 'all' || query || priority"><Search :size="23" /><p>当前筛选没有结果</p><button class="text-button" @click="resetFilter">清除筛选</button></template>
          <template v-else>
            <CircleAlert v-if="result.inconclusive || run.status === 'PARTIAL' && !localReview" :size="23" /><Check v-else :size="23" />
            <p>{{ result.message }}</p>
            <button v-if="hasRejected" class="text-button" @click="setFilter('rejected')">查看人工排除的疑点</button>
          </template>
        </div>
      </section>

      <section v-if="active" id="review-active-finding" ref="detail" class="panel finding selected review-detail" aria-labelledby="review-finding-title" tabindex="-1">
        <div class="finding-detail">
          <div class="finding-detail-title"><h2 id="review-finding-title">{{ active.title }}</h2><span class="pill" :class="verdict(active)[1]">{{ verdict(active)[0] }}</span></div>
          <section class="finding-evidence" aria-labelledby="review-finding-evidence">
            <h3 id="review-finding-evidence">哪里有问题</h3>
            <p class="finding-source">发现方式 · {{ problemSourceLabel(active) }}</p>
            <div class="evidence-list">
              <button v-for="(evidence, i) in active.evidence" :key="i" class="evidence" :class="{ 'is-current': activeEvidence === evidence, 'warning-anchor': active.kind === 'rule' }"
                :data-coach="active.kind === 'rule' ? 'rule-evidence' : undefined"
                @click="jumpToLine(evidence.line, { evidence, trigger: $event.currentTarget, reveal: active.kind === 'rule' })">
                <span><Link2 :size="14" /> {{ evidence.label || evidence.code || '原文' }} · {{ sourceLocation(version, evidence.line) }} <ArrowUpRight :size="14" /></span>
                <q>{{ evidence.quote }}</q>
              </button>
            </div>
          </section>

          <section v-if="active.basisEvidence?.length" class="finding-explanation finding-basis" aria-labelledby="review-finding-basis">
            <h3 id="review-finding-basis">{{ reviewTemplateId(run) === 'legal-risk' ? '法规核对依据' : '公司核对依据' }}</h3>
            <ul>
              <li v-for="(source, index) in active.basisEvidence" :key="index">
                <strong>{{ source.code }}</strong><p>{{ source.quote }}</p>
              </li>
            </ul>
          </section>
          <section v-if="active.impact" class="finding-explanation" aria-labelledby="review-finding-impact">
            <h3 id="review-finding-impact">可能的影响</h3><p>{{ active.impact }}</p>
          </section>
          <section v-if="active.action" class="suggestion finding-explanation" aria-labelledby="review-finding-action">
            <h3 id="review-finding-action">建议怎么改</h3><p>{{ active.action }}</p>
          </section>
          <details v-if="comparison?.left && comparison?.right" class="conflict-proof">
            <summary>对照两处要求</summary>
            <p v-if="comparison.sharedScenario">{{ comparison.sharedScenario }}</p>
            <div class="table-scroll"><table>
              <thead><tr><th scope="col">核对项</th><th v-for="(item, index) in comparisonItems" :key="index" scope="col"><button v-if="item" class="text-button proof-link" @click="jumpToLine(item.line, { trigger: $event.currentTarget, full: !evidenceByLine.has(item.line) })">{{ item.code }} <ArrowUpRight :size="13" /></button><span v-else>条款 {{ index + 1 }}</span></th></tr></thead>
              <tbody><tr v-for="[key, label] in comparisonDimensions" :key="key"><th scope="row">{{ label }}</th><td>{{ comparison.left[key] || '—' }}</td><td>{{ comparison.right[key] || '—' }}</td></tr></tbody>
            </table></div>
          </details>

          <section v-if="activeFinding && canDecide" class="review-decision" aria-label="人工复核">
            <label class="note-label" :for="'note-' + active.id">复核备注</label>
            <textarea :id="'note-' + active.id" v-model="note" rows="2" maxlength="2000" placeholder="记录确认依据或驳回原因"></textarea>
            <div class="finding-actions">
              <button class="button secondary small" :disabled="busy || (activeFinding.decision === 'REJECTED' && note === (activeFinding.note || ''))" @click="emit('decision', active.id, 'REJECTED', note)"><X :size="16" /> 排除此项</button>
              <button class="button primary small" :disabled="busy || (activeFinding.decision === 'CONFIRMED' && note === (activeFinding.note || ''))" @click="emit('decision', active.id, 'CONFIRMED', note)"><Check :size="16" /> {{ reviewTemplateId(run) === 'legal-risk' ? '纳入法务复核' : '确认问题' }}</button>
            </div>
          </section>
          <div v-else-if="activeFinding?.note" class="review-recorded-note"><h3>复核备注</h3><p>{{ activeFinding.note }}</p></div>
          <IssueWorkflow v-if="activeFinding && (currentIssue || activeFinding.decision === 'CONFIRMED')" :finding="activeFinding" :issue="currentIssue" :members="members || []" :role="role" :current-user="currentUser" :busy="busy" :versions="document?.versions" :review-version="version?.number" @save="(id, payload) => emit('issue', id, payload)" />
        </div>
      </section>

      <section ref="sourcePanel" class="panel source-panel" tabindex="-1" aria-labelledby="review-source-title">
        <div class="panel-heading"><div class="panel-title"><FileText :size="19" /><h2 id="review-source-title">文档原文</h2></div><span class="pill neutral">V{{ version?.number ?? '—' }}</span></div>
        <div v-if="version?.sections?.length || evidenceByLine.size" class="source-nav">
          <WorkspaceSelect v-if="chapterOptions.length" :options="chapterOptions" label="跳转章节" placeholder="跳转章节"
            @update:model-value="jumpToLine($event, { full: true })" />
          <button v-if="evidenceByLine.size" class="text-button nearby-switch" :aria-pressed="nearbyOnly" @click="toggleNearby">{{ nearbyOnly ? '查看全文' : '仅看引文附近' }}</button>
        </div>
        <div v-if="activeLine" class="source-position">
          <span aria-live="polite">{{ sourceLocation(version, activeLine) }}</span>
          <button v-if="returnTarget" class="text-button source-return" @click="returnToReview"><ArrowLeft :size="15" /> 返回查阅处</button>
        </div>
        <div class="paper" ref="paper" tabindex="0" aria-label="需求文档原文">
          <template v-for="(row, index) in displayedLines" :key="row.line">
            <div v-if="index && displayedLines[index - 1].line !== row.line - 1" class="source-break" aria-label="省略其他行">…</div>
            <div :data-line="row.line" :title="sourceLocation(version, row.line)" class="source-line"
              :class="{ 'source-heading': headings.has(row.line), 'source-marked': evidenceByLine.has(row.line), 'source-focused': activeLine === row.line }">
              <span>{{ sourceGutterNumber(version, row.line) }}</span><div><template v-for="(part, partIndex) in textParts(row.text, row.line)" :key="partIndex"><mark v-if="part.hit">{{ part.text }}</mark><template v-else>{{ part.text }}</template></template></div>
            </div>
          </template>
        </div>
        <div v-if="evidenceByLine.size" class="source-footer"><span class="legend-square"></span> 当前问题对应的原文</div>
      </section>
    </div>
    <EvidenceRepairPanel v-if="canExportRevision" :key="run.id" :run="run" :document="document" :version="version" :issues="issues" :can-edit="canEdit" :busy="busy"
      @applied="emit('repairs-applied', $event)" @upload="emit('upload-revision')" />
  </div>
</template>

<style scoped src="./review-desk.css"></style>
