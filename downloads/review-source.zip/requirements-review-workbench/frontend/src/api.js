import { demo } from './demo.js'

export const offline = location.protocol === 'file:' || new URLSearchParams(location.search).get('mode') === 'demo'

export async function api(path, { method = 'GET', body } = {}) {
  if (offline) return demo(path, { method, body })
  const multipart = body instanceof FormData
  const response = await fetch(path, {
    method,
    headers: {
      'X-Review-Client': 'web',
      ...(body && !multipart ? { 'Content-Type': 'application/json' } : {}),
    },
    body: multipart || !body ? body : JSON.stringify(body),
  })
  const payload = await response.json().catch(() => null)
  if (!response.ok) {
    const error = new Error(payload?.message || payload?.detail || ('请求失败（' + response.status + '）'))
    error.status = response.status
    throw error
  }
  if (!payload) throw new Error('服务没有返回有效结果。请检查后端是否已启动。')
  return payload
}
