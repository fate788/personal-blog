<script setup>
import { ref, watch } from 'vue'
import { Check, CircleAlert, GitCompareArrows, Link2 } from 'lucide-vue-next'
import { api } from './api.js'
import { relatedWarningLabel, sourceLocation } from './workflow.js'

const props = defineProps({ documentId: String, before: Object, after: Object })
const emit = defineEmits(['source'])
const results = ref(null)
const error = ref('')
const attempt = ref(0)

watch(() => [props.documentId, props.before.id, props.after.id, attempt.value], async ([documentId], _previous, onCleanup) => {
  let active = true
  onCleanup(() => { active = false })
  results.value = null
  error.value = ''
  const before = props.before
  const after = props.after
  const base = '/api/documents/' + encodeURIComponent(documentId) + '/checks/compare'
  try {
    const result = await api(base + '?' + new URLSearchParams({ before: before.id, after: after.id }))
    if (active) results.value = [
      { version: before, label: '上一版', warnings: result.before },
      { version: after, label: '最新版', warnings: result.after },
    ]
  } catch (failure) {
    if (active) error.value = failure.message || '检查结果暂不可用。'
  }
}, { immediate: true })
</script>

<template>
  <section id="source-check-comparison" aria-labelledby="source-comparison-title" class="source-comparison">
    <header>
      <GitCompareArrows :size="19" />
      <div><h3 id="source-comparison-title">原件检查对照</h3><p>用同一组本地规则重新检查两版原文，点击提示定位证据。</p></div>
    </header>
    <p v-if="error" class="compare-message" role="alert">{{ error }} <button class="text-button" @click="attempt++">重试</button></p>
    <p v-else-if="!results" class="compare-message" role="status">正在检查两个版本…</p>
    <div v-else class="compare-results">
      <article v-for="entry in results" :key="entry.version.id">
        <div class="compare-version"><h4>V{{ entry.version.number }} <span>{{ entry.label }}</span></h4><span class="pill" :class="entry.warnings.length ? 'amber' : 'success'">{{ entry.warnings.length }} 条提示</span></div>
        <p v-if="entry.version.source?.fileName" class="compare-filename" :title="entry.version.source.fileName">{{ entry.version.source.fileName }}</p>
        <ul v-if="entry.warnings.length">
          <li v-for="(warning, index) in entry.warnings" :key="warning.type + ':' + warning.line + ':' + index">
            <CircleAlert :size="15" />
            <div class="compare-warning">
              <button v-if="warning.line > 0" class="compare-source-link" @click="emit('source', entry.version.id, warning.line)">
                <span>{{ warning.detail }}</span><small><Link2 :size="13" /> {{ warning.relatedLine ? '调用示例 · ' : '' }}{{ sourceLocation(entry.version, warning.line) }}</small>
              </button><span v-else>{{ warning.detail }}</span>
              <button v-if="warning.relatedLine" class="text-button compare-related-link" @click="emit('source', entry.version.id, warning.relatedLine)"><Link2 :size="13" /> {{ relatedWarningLabel(warning) }} · {{ sourceLocation(entry.version, warning.relatedLine) }}</button>
            </div>
          </li>
        </ul>
        <p v-else class="compare-message"><Check :size="16" /> 当前规则未发现提示</p>
      </article>
    </div>
  </section>
</template>

<style scoped>
.source-comparison { margin: 18px 20px; padding: 16px; border: 1px solid #dedff0; border-radius: 14px; background: #f6f6fc; }
.source-comparison header { display: flex; align-items: flex-start; gap: 10px; color: #45438b; }
.source-comparison header svg { flex: 0 0 auto; margin-top: 2px; }
.source-comparison h3, .source-comparison h4 { margin: 0; color: #262744; }
.source-comparison h3 { font-size: 15px; }
.source-comparison header p { margin: 3px 0 0; font-size: 13px; color: #575b72; }
.compare-results { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 10px; margin-top: 13px; }
.compare-results article { min-width: 0; padding: 12px; background: white; border: 1px solid #e1e4ee; border-radius: 10px; }
.compare-version { display: flex; justify-content: space-between; align-items: center; gap: 8px; flex-wrap: wrap; }
.compare-version h4 span { color: #5b6378; font-weight: 500; }
.compare-filename { margin: 3px 0; color: #5b6378; font-size: 12px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.compare-results ul { list-style: none; padding: 0 4px 0 0; margin: 8px 0 0; max-height: 240px; overflow: auto; }
.compare-results li { display: flex; align-items: baseline; gap: 6px; padding-block: 6px; color: #68471c; font-size: 13px; }
.compare-results li > svg { flex: 0 0 auto; align-self: flex-start; margin-top: 3px; }
.compare-results li + li { border-top: 1px solid #ebe8df; }
.compare-warning { min-width: 0; }
.compare-source-link { display: grid; gap: 4px; padding: 0; border: 0; background: none; color: inherit; text-align: left; line-height: 1.5; cursor: pointer; overflow-wrap: anywhere; }
.compare-source-link:hover small { text-decoration: underline; }
.compare-source-link small, .compare-message { display: flex; align-items: center; flex-wrap: wrap; gap: 5px; color: #4e5082; }
.compare-related-link { color: #4e5082; font-size: 12px; padding: 0; min-height: 28px; text-align: left; }
.compare-message { margin: 10px 0 0; font-size: 13px; }
@media (max-width: 720px) {
  .source-comparison { margin: 12px; padding: 12px; }
  .compare-results { grid-template-columns: minmax(0, 1fr); }
}
</style>
