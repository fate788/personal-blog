import { strToU8, zipSync } from 'fflate'
import { makeRevisionWord } from './revision-word.js'

const xml = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
const namespace = 'http://schemas.openxmlformats.org/wordprocessingml/2006/main'
const officeDocument = 'http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument'
const escape = value => value.replace(/[\x00-\x08\x0b\x0c\x0e-\x1f]/g, '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
const cleanName = title => title.replace(/[<>:"/\\|?*\x00-\x1F]/g, '_').slice(0, 115) || '需求规格说明书'

function paragraph(line, title = false, literal = false) {
  const heading = !title && /^(?:#{1,6}\s|第[一二三四五六七八九十0-9]+[章节]|\d+(?:\.\d+)*(?:[.、]|\s))/.test(line)
  const size = title ? '42' : heading ? '28' : '22'
  const style = (title || heading ? '<w:b/>' : '') + '<w:color w:val="' + (heading ? '284A75' : '17263D') + '"/><w:sz w:val="' + size + '"/>'
  const text = literal ? line : line.replace(/^#{1,6}\s+/, '')
  return '<w:p><w:pPr><w:spacing w:after="100" w:line="320" w:lineRule="auto"/>' +
    (title || heading ? '<w:keepNext/>' : '') + '</w:pPr><w:r><w:rPr>' + style +
    '<w:rFonts w:eastAsia="Microsoft YaHei" w:ascii="Calibri"/></w:rPr><w:t xml:space="preserve">' + escape(text) + '</w:t></w:r></w:p>'
}

export function makeWord(title, text, options = {}) {
  if (options.sourceBody) return makeRevisionWord(title, text, options)
  const types = xml + '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">' +
    '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>' +
    '<Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/></Types>'
  const relationships = xml + '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="' +
    officeDocument + '" Target="word/document.xml"/></Relationships>'
  const content = xml + '<w:document xmlns:w="' + namespace + '"><w:body>' +
    paragraph(title, true) + text.split(/\r?\n/).map(line => paragraph(line)).join('') +
    '<w:sectPr><w:pgSz w:w="11906" w:h="16838"/><w:pgMar w:top="1050" w:right="1000" w:bottom="1050" w:left="1000"/></w:sectPr></w:body></w:document>'
  return zipSync({ '[Content_Types].xml': strToU8(types), '_rels/.rels': strToU8(relationships), 'word/document.xml': strToU8(content) })
}

export function downloadWord(title, text, options) {
  const blob = new Blob([makeWord(title, text, options)], { type: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document' })
  const url = URL.createObjectURL(blob)
  const link = document.createElement('a')
  link.href = url
  link.download = cleanName(title) + '.docx'
  link.click()
  setTimeout(() => URL.revokeObjectURL(url), 5000)
}
