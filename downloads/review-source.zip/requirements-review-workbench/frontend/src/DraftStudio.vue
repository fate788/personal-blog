<script setup>
import { nextTick, ref, watch } from 'vue'
import { CircleAlert, ClipboardList, FileDown, FileText, Info, Sparkles } from 'lucide-vue-next'

const props = defineProps({ form: Object, draft: Object, busy: Boolean, generating: Boolean, error: String, modelReady: Boolean, modelDestination: String, modelLoading: Boolean })
const emit = defineEmits(['generate', 'model-retry', 'save', 'export'])
const outline = ['项目目标与范围', '角色与术语', '功能需求与异常', '数据和外部接口', '质量与非功能要求', '验收条件与待确认']
const resultHeading = ref(null)
watch(() => props.draft, async value => {
  if (value) {
    await nextTick()
    resultHeading.value?.focus()
  }
})
function fillExample() {
  Object.assign(props.form, {
    goal: '统一处理企业员工的 IT 工单与生产变更，跟踪服务时限。',
    roles: '员工提交和追踪本人工单\n一线服务台受理并分派工单\n运维工程师处理与恢复\n变更审批人核对风险与执行窗口',
    features: '维护事件工单状态和转派记录\n跟踪首次响应时限并提醒超时\n记录变更审批、执行和回退',
    scope: '首期覆盖企业内部员工 IT 支持与计划变更，暂不接入外部客户。',
    constraints: '员工只查看本人或被授权工单。生产变更单的申请人和审批人分离。',
    nfr: '',
    integrations: '企业身份目录和邮件网关，接口字段与重试策略待定。',
    acceptance: '按员工、服务台、工程师、审批人四类角色验证权限和主要状态流转。',
  })
}
</script>

<template>
  <div class="page-heading"><div><h1>一键生成需求文档</h1><p>写下要解决的问题，生成草稿后可以编辑内容，再保存到当前项目。</p></div><button v-if="!draft && !Object.values(form).some(Boolean)" class="button secondary" :disabled="busy" @click="fillExample">填入业务示例</button></div>
  <div class="draft-layout">
    <form class="panel draft-intake" @submit.prevent="emit('generate')">
      <div class="panel-heading"><div class="panel-title"><ClipboardList :size="18" /><h2>填写业务信息</h2></div></div>
      <div class="form-body">
        <label><span>业务目标 <span class="required">*</span></span><textarea v-model="form.goal" data-draft-goal :disabled="busy" rows="4" maxlength="4000" required placeholder="这个软件为谁服务，要解决什么问题，预期达到什么结果？"></textarea></label>
        <details class="optional-fields">
          <summary>补充角色、流程与验收要求（选填）</summary>
          <div>
            <div class="form-pair">
              <label>使用角色<textarea v-model="form.roles" :disabled="busy" rows="3" maxlength="4000" placeholder="列出使用人及其主要职责"></textarea></label>
              <label>功能与关键流程<textarea v-model="form.features" :disabled="busy" rows="3" maxlength="6000" placeholder="每行填写一个功能或操作场景"></textarea></label>
            </div>
            <label>范围和边界<textarea v-model="form.scope" :disabled="busy" rows="2" maxlength="4000" placeholder="写明首期覆盖的业务及未纳入的事项"></textarea></label>
            <label>业务规则与约束<textarea v-model="form.constraints" :disabled="busy" rows="2" maxlength="4000" placeholder="例如权限、状态转换、数据保留或关键规则"></textarea></label>
            <label>验收条件<textarea v-model="form.acceptance" :disabled="busy" rows="2" maxlength="4000" placeholder="怎样证明功能或业务目标达成？"></textarea></label>
            <label>外部系统与接口<textarea v-model="form.integrations" :disabled="busy" rows="2" maxlength="4000" placeholder="例如身份目录、支付、通知服务"></textarea></label>
            <label>非功能要求<textarea v-model="form.nfr" :disabled="busy" rows="2" maxlength="4000" placeholder="如响应时间、容量、可靠性或日志留存"></textarea></label>
          </div>
        </details>
        <div class="form-hint"><Info :size="16" />
          <span v-if="modelDestination && modelReady">生成时，已填写的业务信息将发送给 {{ modelDestination }}。未明确的业务规则会列为待确认项。</span>
          <span v-else-if="modelReady">{{ modelLoading ? '正在读取默认模型信息…' : '暂时无法读取默认模型信息。' }} <button v-if="!modelLoading" type="button" class="text-button" @click="emit('model-retry')">重试</button></span>
          <span v-else>未明确的业务规则会列为待确认项。</span>
        </div>
        <div v-if="error" class="form-error" role="alert"><CircleAlert :size="17" /><span>{{ error }}</span></div>
        <button class="button primary" type="submit" data-draft-generate :aria-busy="generating" :disabled="busy || !form.goal.trim() || (modelReady && !modelDestination)"><Sparkles :size="17" /> {{ generating ? '正在生成草稿…' : '生成需求文档' }}</button>
      </div>
    </form>
    <section class="panel draft-output">
      <div class="panel-heading"><div class="panel-title"><FileText :size="18" /><h2 ref="resultHeading" tabindex="-1">{{ draft ? '核对生成的草稿' : '文档结构' }}</h2></div><span v-if="draft" class="pill amber">草稿</span></div>
      <div v-if="!draft" class="draft-outline"><p>{{ modelReady ? '工作台默认模型根据业务信息整理以下章节。' : '当前使用模板整理业务信息与待确认项。' }}</p><ul><li v-for="section in outline" :key="section"><FileText :size="15" />{{ section }}</li></ul></div>
      <div v-else class="form-body">
        <label>文档名称<input v-model="draft.title" data-draft-title :disabled="busy" maxlength="120" required></label>
        <label>需求规格说明书<textarea v-model="draft.text" data-draft-text :disabled="busy" rows="18" spellcheck="false"></textarea></label>
        <div class="actions">
          <button class="button primary" data-draft-review :disabled="busy || !draft.text.trim() || !draft.title.trim()" @click="emit('save', true)">保存并进入审查</button>
          <button class="button secondary" data-draft-save :disabled="busy || !draft.text.trim() || !draft.title.trim()" @click="emit('save', false)">保存到项目</button>
          <button class="button secondary" :disabled="!draft.text.trim()" @click="emit('export')"><FileDown :size="17" /> 下载 Word</button>
        </div>
      </div>
    </section>
  </div>
</template>
