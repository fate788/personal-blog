import { plainFinding } from './problem-language.js'
import { isLocalRuleReview, relatedWarningLabel } from './workflow.js'

const focusedPacks = new Set(['business-fit', 'legal-risk', 'user-journey', 'information-security'])
const basisSource = /^basis-(?:company|pipl-(?:6|17|19|28|47))$/
export const isFocusedReviewPack = packId => focusedPacks.has(packId) || !!packId?.startsWith('custom-')
export const reviewTemplateId = run => run?.packSnapshot?.basePackId || run?.packId
export const isCombinedReview = run => run?.mode === 'MODEL' && run.executionStrategy === 'COMBINED'
export function combinedScopeLabel(run) {
  if (!isCombinedReview(run)) return ''
  const count = run.targetItemIds?.length ?? run.scope?.items
  return '本地规则检查本版全文，AI 按审查包核对本次选定的' + (count == null ? '条款。' : ' ' + count + ' 个条款。')
}
export const includesLocalResults = run => isCombinedReview(run) || run?.executionStrategy === 'LOCAL_ONLY' || !isFocusedReviewPack(run?.packId)
const sourceLabels = { rule: '本地规则', model: 'AI 语义审查', both: '本地规则和 AI 均发现', sample: '样例判断' }
export const problemSourceLabel = problem => sourceLabels[problem.source]

function warningDescription(warning) {
  const detail = warning.detail || ''
  switch (warning.type) {
    case 'HTTP_SECTION_EXAMPLE_METHOD_DIFFERS': {
      const methods = detail.match(/本节声明使用 (\w+)，本节唯一标为请求示例的调用使用 (\w+)/)
      return {
        title: methods ? '本节写的是 ' + methods[1] + '，请求示例却用了 ' + methods[2] : '本节声明和请求示例用了不同的请求方式',
        impact: '照着说明和照着示例会发出两种不同的请求，读者难以判断该用哪一种。',
        action: '核对本节要演示的接口和部署方式，确认示例该用哪个请求方法。',
      }
    }
    case 'HTTP_REQUEST_METHOD_MISMATCH': {
      const [, declared, actual] = detail.match(/接口声明使用 (\w+)，curl 请求示例使用 (\w+)/) || []
      return {
        title: declared && actual ? `接口写的是 ${declared}，调用示例却用了 ${actual}` : '接口文档和调用示例用了不同的请求方式',
        impact: '照着示例发请求，服务器可能拒绝这次调用。',
        action: '以实际接口支持的请求方式为准，把接口声明和调用示例写成一致。',
      }
    }
    case 'HTTP_REQUEST_CONTEXT_PATH_MISSING': {
      const prefix = detail.match(/缺少 (\S+) 上下文前缀/)?.[1]
      return {
        title: prefix ? `调用示例少写了 ${prefix}` : '调用示例少写了请求路径的开头',
        impact: '按文档里的默认部署方式，照着示例可能找不到这个接口。',
        action: prefix ? `在调用示例的路径开头补上 ${prefix}，再核对完整地址。` : '把文档中声明的默认路径前缀补到调用示例里。',
      }
    }
    case 'INVALID_JSON_EXAMPLE':
      if (detail.includes('省略占位')) return null
      return {
        title: '这段 JSON 示例有格式错误',
        impact: '直接复制时，程序可能读不出这段数据。',
        action: '核对标记行附近的括号、引号和逗号，修改后确认示例能够被 JSON 解析器读取。',
      }
    case 'WORKED_OCCURRENCE_MISMATCH':
      return { title: '示例结果表里的出现次数算错了', impact: detail, action: '用示例中的输入逐项累计出现次数，改正结果表里对应的位置。' }
    case 'SQL_EXAMPLE_FUNCTION_MISMATCH': {
      const names = detail.match(/示例查询调用 (\w+)，紧随其后的结果列和文档语法写的是 (\w+)/)
      return {
        title: names ? '示例调用了 ' + names[1] + '，结果表却写着 ' + names[2] : '示例查询和结果表使用了不同的函数名',
        impact: '读者复制示例后，实际调用的函数和文档展示的结果对不上。',
        action: '核对文档要演示的函数，统一查询与结果表，在相同参数下重新获取示例结果。',
      }
    }
    case 'EMPTY_JSON_EXAMPLE':
      return { title: '标成 JSON 示例的地方没有内容', impact: '读者无法从这里看到数据应当怎样填写。', action: '放入一段有效的示例数据，或删掉空的示例框。' }
    case 'UNCLOSED_JSON_EXAMPLE':
      return { title: 'JSON 示例末尾少了结束标记', impact: '后面的文档文字可能也会显示成示例的一部分。', action: '在示例最后一行之后补上代码块的结束标记。' }
    case 'INVALID_UUID_URN':
      return { title: '示例中的唯一标识格式不正确', impact: '使用这段标识时，校验可能失败。', action: '核对标识是否按 8-4-4-4-12 的分组填写十六进制字符。' }
    case 'DUPLICATE_ID':
    case 'DUPLICATE_CODE':
      return { title: '不同需求用了同一个编号', impact: '引用这个编号时，读者不知道说的是哪一条。', action: '给每条需求分配不同编号，再更新引用这些编号的位置。' }
    case 'MISSING_REFERENCE':
    case 'UNKNOWN_REFERENCE': {
      const reference = detail.match(/(?:显式引用的 |引用的 )([A-Z][A-Z0-9_-]*\d+)/)?.[1]
      return {
        title: reference ? `找不到被引用的条款 ${reference}` : '引用指向了找不到的条款',
        impact: '读者无法沿着这处引用找到对应要求。',
        action: '核对是否写错编号或漏列条款，并在引用处写明正确的条款编号。',
      }
    }
    default: {
      const mandatory = /^项目规则「(.+?)」 V\d+。发现表述「.+?」，同一条目中缺少「(.+?)」。/u.exec(detail)
      if (!warning.type?.startsWith('PROJECT_RULE_') || !mandatory) return null
      return {
        title: `条目漏写了项目要求的「${mandatory[2]}」`,
        impact: `这条需求还没有满足项目启用的「${mandatory[1]}」规则。`,
        action: detail.slice(mandatory[0].length).trim() || `按照项目规则，在这条需求里补上「${mandatory[2]}」。`,
      }
    }
  }
}

function warningEvidence(warning, lines) {
  const excerpts = []
  if (warning.line > 0 && warning.line <= lines.length) {
    const labels = { WORKED_OCCURRENCE_MISMATCH: '示例结果', SQL_EXAMPLE_FUNCTION_MISMATCH: '示例查询' }
    const label = labels[warning.type] || (warning.relatedLine ? '调用示例' : '问题所在')
    excerpts.push({ line: warning.line, quote: lines[warning.line - 1].trim(), label })
  }
  if (warning.relatedLine > 0 && warning.relatedLine <= lines.length && warning.relatedLine !== warning.line) {
    excerpts.push({ line: warning.relatedLine, quote: lines[warning.relatedLine - 1].trim(), label: relatedWarningLabel(warning) })
  }
  return excerpts
}

// A confirmed pair of source lines can also be cited by a model finding about the same HTTP methods.
// Keep the model row actionable and keep the source check whenever the model row is rejected.
export function sameRequestMethod(rule, problem) {
  const warning = rule.warning
  if (!['HTTP_SECTION_EXAMPLE_METHOD_DIFFERS', 'HTTP_REQUEST_METHOD_MISMATCH'].includes(warning.type)
      || !warning.relatedLine || problem.finding.decision === 'REJECTED') return false
  const declared = problem.evidence.find(e => e.line === warning.relatedLine)
  const example = problem.evidence.find(e => e.line === warning.line)
  if (!declared || !example) return false
  const verbs = /\b(?:GET|POST|PUT|DELETE|PATCH|HEAD|OPTIONS|TRACE|CONNECT)\b/g
  const first = declared.quote.match(verbs)
  const second = example.quote.match(verbs)
  if (first?.length !== 1 || second?.length !== 1 || first[0] === second[0]) return false
  const wording = problem.title + ' ' + problem.impact
  if (/权限|授权|鉴权|认证|幂等|请求路径|请求头|返回值|响应码|状态码|响应体|参数(?:类型|名称|格式|顺序)|permission|authorization|idempoten|response code|status code|request path/i.test(problem.title)) return false
  const methodTitle = /请求方式|请求方法|HTTP\s*(?:方法|动词)|request method/i.test(problem.title)
    || problem.title.includes(first[0]) && problem.title.includes(second[0])
  return methodTitle
    && wording.includes(first[0]) && wording.includes(second[0])
    && /不一致|不.{0,2}相同|矛盾|不同|却|冲突|mismatch|differ/i.test(wording)
}

export function reviewProblems(run, version, { includeRejected = false } = {}) {
  const lines = (version?.text || '').split(/\r?\n/)
  const seenWarnings = new Set()
  const combined = isCombinedReview(run)
  const ruleWarnings = includesLocalResults(run) ? (run?.ruleWarnings || []) : []
  const ruleProblems = ruleWarnings.flatMap((warning, warningIndex) => {
    const description = warningDescription(warning)
    const evidence = warningEvidence(warning, lines)
    const key = JSON.stringify([warning.type, warning.line, warning.relatedLine, warning.detail])
    if (!description || evidence.length === 0 || seenWarnings.has(key)) return []
    seenWarnings.add(key)
    return [{ id: 'rule:' + warningIndex, kind: 'rule', source: 'rule', warning, warningIndex, evidence, ...description }]
  })

  const modelProblems = (run?.findings || []).flatMap(finding => {
    if (finding.status !== 'ISSUE' || (!includeRejected && finding.decision === 'REJECTED')) return []
    const sources = finding.evidence || []
    const evidence = sources.filter(source => source.line > 0 && source.line <= lines.length && source.quote?.trim())
    const basisEvidence = sources.filter(source => source.line === 0 && basisSource.test(source.itemId) && source.quote?.trim())
    if (evidence.length === 0) return []
    const { title, reason: impact, suggestion: action } = plainFinding(finding)
    const source = run.mode === 'DEMO' ? 'sample' : 'model'
    return [{ id: finding.id, kind: 'model', source, title, impact, action, finding, evidence, basisEvidence }]
  })

  const remaining = ruleProblems.filter(rule => {
    const match = modelProblems.find(problem => problem.finding.decision !== 'REJECTED' &&
      ((combined && rule.warning.matchingFindingId && rule.warning.matchingFindingId === problem.id) || sameRequestMethod(rule, problem)))
    if (!match) return true
    if (match.source !== 'sample') match.source = 'both'
    return false
  })
  return [...remaining, ...modelProblems]
}

export function reviewResult(run, version) {
  const all = reviewProblems(run, version, { includeRejected: true })
  const excluded = all.filter(problem => problem.finding?.decision === 'REJECTED')
  const listed = all.filter(problem => problem.finding?.decision !== 'REJECTED')
  const hasModelEvidence = all.some(problem => problem.kind === 'model')
  const hasJudgment = run?.scope?.substantiveChecks == null
    ? run?.findings?.some(finding => finding.status === 'PASS')
    : run.scope.substantiveChecks > 0
  const noModelJudgment = run?.mode === 'MODEL' && !hasModelEvidence && !hasJudgment
  const inconclusive = !listed.length && (noModelJudgment || run?.status === 'FAILED')
  let message = ''
  if (noModelJudgment) {
    message = '本轮没有取得可核验的模型结论。' + (listed.length
      ? '清单中的 ' + listed.length + ' 个问题均来自原文规则检查。' : '文档是否存在问题仍待核对。')
  } else if (!listed.length) {
    if (run?.status === 'FAILED') message = '审查未完成，当前无法判断文档是否有问题。'
    else if (excluded.length) message = '复核人已排除全部 ' + excluded.length + ' 条疑点，本轮没有保留的问题。'
    else if (isLocalRuleReview(run)) message = '本次原文规则检查未发现问题。'
    else if (run?.status === 'PARTIAL') message = '已完成的检查未发现问题，剩余范围仍待审查。'
    else message = '在本轮有明确判断的检查项中，未发现有原文依据的问题。'
  }
  let sourceSummary = ''
  if (isCombinedReview(run) && listed.length) {
    const counts = { rule: 0, model: 0, both: 0 }
    for (const problem of listed) counts[problem.source]++
    sourceSummary = [
      counts.rule && '仅本地规则发现 ' + counts.rule + ' 个',
      counts.model && '仅 AI 发现 ' + counts.model + ' 个',
      counts.both && '两者共同发现 ' + counts.both + ' 个',
    ].filter(Boolean).join('，') + '。'
  }
  return { listed, excluded, inconclusive, message, sourceSummary }
}
