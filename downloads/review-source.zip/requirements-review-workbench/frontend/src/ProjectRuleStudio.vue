<script setup>
import { computed, ref, watch } from 'vue'
import { ArrowUpRight, FlaskConical, History, ListChecks, Plus, Settings2 } from 'lucide-vue-next'
import WorkspaceSelect from './WorkspaceSelect.vue'
import { api } from './api.js'
import { sourceLocation } from './workflow.js'

const props = defineProps({ project: Object, documents: Array, canDecide: Boolean })
const emit = defineEmits(['source'])
const rows = ref([])
const ruleId = ref('')
const form = ref(null)
const documentId = ref('')
const versionId = ref('')
const trial = ref(null)
const history = ref(null)
const loading = ref(true)
const busy = ref(false)
const error = ref('')
const status = ref('')
const canManage = computed(() => props.project?.role === 'OWNER')
const base = '/api/projects/' + encodeURIComponent(props.project.id) + '/review-rules'
const selected = computed(() => rows.value.find(entry => entry.rule.id === ruleId.value))
const rule = computed(() => selected.value?.rule)
const path = computed(() => base + '/' + encodeURIComponent(ruleId.value))
const doc = computed(() => props.documents.find(entry => entry.id === documentId.value))
const version = computed(() => doc.value?.versions.find(entry => entry.id === versionId.value))
const kinds = { FLAG_PHRASE: '命中指定表述', REQUIRE_PHRASE: '命中时补足约定表述' }
const scopes = { REQUIREMENTS: '解析条目', FULL_TEXT: '全文逐行' }
const kindOptions = Object.entries(kinds).map(([value, label]) => ({ value, label }))
const scopeOptions = Object.entries(scopes).map(([value, label]) => ({ value, label }))
const documentOptions = computed(() => props.documents.map(entry => ({ value: entry.id, label: entry.title })))
const versionOptions = computed(() => (doc.value?.versions || []).map(entry => ({ value: entry.id, label: 'V' + entry.number })))
const suggestions = {
  ENABLE_CANDIDATE: '至少两份文档确认了此规则的命中，尚无误报反馈。可以启用这条规则。',
  REFINE_TRIGGER: '至少两份文档出现了误报。建议缩小检查范围或把触发表述改得更具体，再用原文试跑。',
}

watch(() => props.documents, documents => {
  if (!documents.some(doc => doc.id === documentId.value)) documentId.value = documents[0]?.id || ''
}, { immediate: true })
watch(documentId, () => { versionId.value = doc.value?.versions[0]?.id || '' })
if (doc.value) versionId.value = doc.value.versions[0]?.id || ''
watch([ruleId, documentId, versionId], () => { trial.value = null; history.value = null; status.value = '' }, { flush: 'sync' })

async function run(task) {
  if (busy.value) return
  busy.value = true
  error.value = ''
  try { await task() } catch (failure) { error.value = failure.message }
  finally { busy.value = false }
}

async function load() {
  await run(async () => {
    rows.value = await api(base)
    if (!selected.value) ruleId.value = rows.value[0]?.rule.id || ''
  })
  loading.value = false
}
load()

function choose(id) {
  ruleId.value = id
  form.value = null
  error.value = ''
}
function create() {
  form.value = { id: '', revision: 0, name: '', kind: 'FLAG_PHRASE', scope: 'REQUIREMENTS', trigger: '', required: '', guidance: '', enabled: false }
}
function replace(entry) {
  rows.value = [entry, ...rows.value.filter(row => row.rule.id !== entry.rule.id)]
  ruleId.value = entry.rule.id
}
function save() {
  run(async () => {
    const input = form.value
    const endpoint = input.id ? base + '/' + encodeURIComponent(input.id) : base
    replace(await api(endpoint, { method: input.id ? 'PUT' : 'POST', body: input }))
    form.value = null
    trial.value = null
    history.value = null
    status.value = '规则已保存，可用真实文档试跑。'
  })
}
function toggle() {
  run(async () => {
    const input = { ...rule.value, enabled: !rule.value.enabled }
    replace(await api(path.value, { method: 'PUT', body: input }))
    trial.value = null
    history.value = null
    status.value = input.enabled ? '规则已启用，下一次原件检查会执行该版本。' : '规则已停用，可在规则历史查看之前的版本。'
  })
}
function tryRule() {
  run(async () => {
    trial.value = null
    status.value = ''
    const result = await api(path.value + '/trial', { method: 'POST', body: { documentId: documentId.value, versionId: versionId.value } })
    if (result.revision !== rule.value.revision) throw new Error('规则已有新版本，请刷新后重新试跑。')
    trial.value = result
  })
}
function giveFeedback(hit, verdict) {
  run(async () => {
    const body = { documentId: documentId.value, versionId: versionId.value, revision: trial.value.revision, line: hit.line, verdict }
    replace(await api(path.value + '/feedback', { method: 'POST', body }))
    hit.verdict = verdict
    history.value = null
    status.value = '复核反馈已保存。'
  })
}
function toggleHistory() {
  if (history.value) { history.value = null; return }
  run(async () => { history.value = await api(path.value + '/history') })
}
</script>

<template>
  <div class="rule-studio" :aria-busy="busy">
    <div class="studio-toolbar">
      <p>用项目文档试跑规则，记录有用提示和误报，再决定是否启用。</p>
      <div class="actions"><button class="button secondary small" :disabled="busy" @click="load">刷新</button><button v-if="canManage" class="button primary small" :disabled="busy" @click="create"><Plus :size="16" /> 新建规则</button></div>
    </div>
    <p v-if="error" class="form-error" role="alert">{{ error }}</p>
    <p v-if="status" class="studio-status" role="status">{{ status }}</p>

    <form v-if="form" class="panel studio-form" @submit.prevent="save">
      <h2>{{ form.id ? '编辑项目规则' : '新建项目规则' }}</h2>
      <div class="studio-fields">
        <label>规则名称<input v-model.trim="form.name" required maxlength="100" placeholder="例如：响应期限应写明时间单位"></label>
        <label>检查类型<WorkspaceSelect v-model="form.kind" :options="kindOptions" label="检查类型" /></label>
        <label>检查范围<WorkspaceSelect v-model="form.scope" :options="scopeOptions" label="检查范围" /></label>
        <label>触发表述<input v-model.trim="form.trigger" required maxlength="120" placeholder="输入要精确匹配的文字"></label>
        <label v-if="form.kind === 'REQUIRE_PHRASE'">必备表述<input v-model.trim="form.required" required maxlength="120" placeholder="应出现在同一条目或行内"></label>
        <label>处理建议<input v-model.trim="form.guidance" maxlength="400" placeholder="给编写人的说明（选填）"></label>
      </div>
      <p v-if="form.id && form.enabled" class="studio-hint">保存会更新已启用规则。建议先停用，再编辑和试跑。</p>
      <div class="actions"><button type="button" class="button secondary small" :disabled="busy" @click="form = null">取消</button><button class="button primary small" :disabled="busy">{{ form.id ? '保存新版本' : '保存为草稿' }}</button></div>
    </form>

    <div v-if="loading" class="panel empty compact" role="status">正在加载项目规则…</div>
    <div v-else-if="!rows.length && !form && !error" class="panel empty compact"><ListChecks :size="24" /><p>该项目暂无自定义规则。</p></div>
    <div v-else-if="rows.length" class="studio-grid">
      <section class="panel studio-list" aria-label="项目规则列表">
        <button v-for="entry in rows" :key="entry.rule.id" class="version-row" :class="{ active: ruleId === entry.rule.id }" :disabled="busy" @click="choose(entry.rule.id)">
          <strong>{{ entry.rule.name }}</strong><small>V{{ entry.rule.revision }} · {{ entry.rule.enabled ? '已启用' : '未启用' }}</small>
        </button>
      </section>
      <section v-if="rule" class="panel studio-details">
        <header class="studio-detail-heading"><div><h2>{{ rule.name }}</h2><p>{{ kinds[rule.kind] }} · {{ scopes[rule.scope] }} · V{{ rule.revision }}</p></div><span class="pill" :class="rule.enabled ? 'success' : 'neutral'">{{ rule.enabled ? '已启用' : '未启用' }}</span></header>
        <dl class="studio-rule-values"><div><dt>触发表述</dt><dd>{{ rule.trigger }}</dd></div><div v-if="rule.kind === 'REQUIRE_PHRASE'"><dt>必备表述</dt><dd>{{ rule.required }}</dd></div><div v-if="rule.guidance"><dt>处理建议</dt><dd>{{ rule.guidance }}</dd></div></dl>
        <div class="studio-evidence"><strong>本版本复核</strong><span>{{ selected.stats.confirmed }} 条确认 · {{ selected.stats.falsePositives }} 条误报</span><p v-if="selected.suggestion">{{ suggestions[selected.suggestion] }}</p></div>
        <div class="actions studio-actions">
          <button v-if="canManage" class="button secondary small" :disabled="busy" @click="form = { ...rule }"><Settings2 :size="15" /> 编辑</button>
          <button v-if="canManage" class="button secondary small" :disabled="busy" @click="toggle">{{ rule.enabled ? '停用规则' : '启用规则' }}</button>
          <button class="button secondary small" :disabled="busy" @click="toggleHistory"><History :size="15" /> {{ history ? '收起历史' : '规则历史' }}</button>
        </div>
        <ul v-if="history" class="studio-history"><li v-for="entry in history" :key="entry.rule.revision"><strong>V{{ entry.rule.revision }} · {{ entry.rule.name }}</strong><span>{{ entry.rule.enabled ? '已启用' : '未启用' }} · {{ entry.rule.trigger }}<template v-if="entry.rule.required"> → {{ entry.rule.required }}</template> · {{ entry.stats.confirmed }} 条确认 · {{ entry.stats.falsePositives }} 条误报</span></li></ul>
        <section class="studio-trial" aria-label="用原件试跑">
          <h3><FlaskConical :size="17" /> 用原件试跑</h3>
          <form v-if="documents.length" class="studio-trial-form" @submit.prevent="tryRule">
            <label>文档<WorkspaceSelect v-model="documentId" :options="documentOptions" label="文档" :disabled="busy" /></label>
            <label>版本<WorkspaceSelect v-model="versionId" :options="versionOptions" label="版本" :disabled="busy" /></label>
            <button class="button primary small" :disabled="busy || !version">运行试查</button>
          </form>
          <p v-else class="studio-hint">导入文档后可试跑这条规则。</p>
          <template v-if="trial">
            <p class="studio-hint" role="status">命中 {{ trial.total }} 处<template v-if="trial.total > trial.hits.length">，展示前 {{ trial.hits.length }} 处</template>。</p>
            <ul v-if="trial.hits.length" class="studio-hits"><li v-for="hit in trial.hits" :key="hit.line">
              <button class="text-button studio-source" @click="emit('source', documentId, versionId, hit.line)">{{ sourceLocation(version, hit.line) }} <ArrowUpRight :size="13" /></button>
              <p>{{ hit.text }}</p>
              <div v-if="canDecide" class="actions"><button class="button small secondary" :aria-pressed="hit.verdict === 'CONFIRMED'" :disabled="busy" @click="giveFeedback(hit, 'CONFIRMED')">确认有效</button><button class="button small secondary" :aria-pressed="hit.verdict === 'FALSE_POSITIVE'" :disabled="busy" @click="giveFeedback(hit, 'FALSE_POSITIVE')">标记误报</button></div>
              <span v-else-if="hit.verdict" class="pill neutral">{{ hit.verdict === 'CONFIRMED' ? '已确认' : '已标记误报' }}</span>
            </li></ul>
          </template>
        </section>
      </section>
    </div>
  </div>
</template>

<style scoped>
.rule-studio { display: grid; gap: 14px; }
.studio-toolbar, .studio-detail-heading { display: flex; align-items: flex-start; justify-content: space-between; flex-wrap: wrap; gap: 9px; }
.studio-toolbar p, .studio-detail-heading p, .studio-hint { margin: 0; font-size: 13px; color: var(--muted); }
.studio-toolbar p { padding-block: 6px; }
.studio-grid { display: grid; grid-template-columns: minmax(175px, .3fr) minmax(0, 1fr); gap: 14px; align-items: start; }
.studio-list { overflow: hidden; }
.studio-list strong, .studio-rule-values dd { overflow-wrap: anywhere; }
.studio-form, .studio-details { padding: 16px; min-width: 0; }
.studio-form h2, .studio-details h2 { font-size: 17px; margin: 0; }
.studio-detail-heading p { margin-top: 4px; }
.studio-fields { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 12px; margin: 14px 0; }
.studio-fields label, .studio-trial-form label { display: grid; gap: 5px; min-width: 0; font-size: 13px; font-weight: 600; }
.studio-fields :is(input, .workspace-select), .studio-trial-form .workspace-select { width: 100%; min-width: 0; min-height: 35px; }
.studio-rule-values { display: flex; flex-wrap: wrap; gap: 10px 20px; margin: 14px 0; }
.studio-rule-values dt, .studio-history span { color: var(--muted); font-size: 12px; }
.studio-rule-values dd { margin: 4px 0 0; font-size: 14px; }
.studio-evidence, .studio-status { margin: 0; padding: 10px 12px; border-radius: 9px; background: #edf2fc; color: #304673; font-size: 13px; }
.studio-evidence span { margin-inline-start: 10px; }
.studio-evidence p { margin: 5px 0 0; }
.studio-actions, .studio-form .actions { justify-content: flex-start; margin: 12px 0; }
.studio-trial { padding-top: 12px; border-top: 1px solid var(--line); }
.studio-trial h3 { display: flex; align-items: center; gap: 7px; margin: 0 0 10px; font-size: 15px; }
.studio-trial-form { display: grid; grid-template-columns: minmax(0, 1fr) minmax(65px, .25fr) auto; gap: 8px; align-items: end; margin: 0 0 9px; }
.studio-trial-form > button { min-height: 35px; }
.studio-hits, .studio-history { list-style: none; margin: 8px 0 0; padding: 0; }
.studio-history { border-block-start: 1px solid var(--line); margin-block-end: 10px; max-height: 260px; overflow: auto; }
.studio-history li, .studio-hits li { display: grid; gap: 6px; padding: 8px 0; border-block-end: 1px solid var(--line); }
.studio-hits p { margin: 0; color: var(--text); font-size: 13px; overflow-wrap: anywhere; white-space: pre-wrap; }
.studio-hits .actions { justify-content: flex-start; }
.studio-hits button[aria-pressed='true'] { background: #e9f0ff; border-color: #8da2ce; color: #253c6b; }
.studio-source { justify-self: start; }
@media (max-width: 780px) { .studio-grid { grid-template-columns: minmax(0, 1fr); } }
@media (max-width: 460px) { .studio-fields { grid-template-columns: minmax(0, 1fr); } .studio-trial-form > button { grid-column: 1 / -1; justify-self: start; } }
</style>
