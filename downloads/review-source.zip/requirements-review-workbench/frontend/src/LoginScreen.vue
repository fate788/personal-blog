<script setup>
import { computed, ref, watch } from 'vue'
import { ArrowRight, CircleAlert, ClipboardCheck, Eye, EyeOff, FileText, GitCompareArrows, ScanLine, Sparkles } from 'lucide-vue-next'
import archivePhoto from './assets/login-archive.webp'

const props = defineProps({ session: Object, offline: Boolean, busy: Boolean, error: String })
const emit = defineEmits(['authenticate', 'register', 'demo'])
const emptyForm = () => ({ username: '', password: '', displayName: '', setupToken: '' })
const form = ref(emptyForm())
const visible = ref(false)
const registerRequested = ref(false)
const showError = ref(true)
const setup = computed(() => props.session?.initialized === false && !props.offline)
const canRegister = computed(() => !!props.session?.initialized && !!props.session?.registrationEnabled && !props.offline)
const mode = computed(() => setup.value ? 'setup' : canRegister.value && registerRequested.value ? 'register' : 'login')
const creating = computed(() => mode.value !== 'login')
const title = computed(() => ({ setup: '创建管理员账户', register: '创建账户', login: '登录工作空间' })[mode.value])
const description = computed(() => ({
  setup: '首次启动时设置管理员，完成后进入工作空间。',
  register: '注册成功后将进入工作空间，可以创建第一个项目。',
  login: '使用账户登录，继续处理你的项目需求。',
})[mode.value])
const submitLabel = computed(() => props.busy
  ? (creating.value ? '正在创建账户…' : '正在登录…')
  : ({ setup: '创建并进入', register: '注册并进入', login: '登录' })[mode.value])
const usernamePattern = '[a-zA-Z0-9][a-zA-Z0-9._\\-]{2,39}'
const workflow = [
  { icon: FileText, title: '整理需求' },
  { icon: ClipboardCheck, title: '复核证据' },
  { icon: GitCompareArrows, title: '追踪修订' },
]

watch(canRegister, allowed => {
  if (!allowed) registerRequested.value = false
})
watch(mode, () => {
  form.value = emptyForm()
  visible.value = false
  showError.value = false
}, { flush: 'sync' })
watch(() => props.error, error => {
  if (error) showError.value = true
})

function changeMode(register) {
  if (!props.busy && canRegister.value) registerRequested.value = register
}

function submit() {
  if (props.busy) return
  showError.value = true
  if (mode.value === 'register') {
    const { username, displayName, password } = form.value
    emit('register', { username, displayName, password })
  } else {
    emit('authenticate', setup.value, { ...form.value })
  }
}
</script>

<template>
  <main class="account-access">
    <div class="account-sheet">
      <section class="account-intro" aria-labelledby="account-product-name">
        <img class="account-intro-art" :src="archivePhoto" alt="" aria-hidden="true" decoding="async">
        <header class="account-brand">
          <span class="account-brand-icon"><ScanLine :size="21" aria-hidden="true" /></span>
          <span>需求审查</span>
        </header>
        <div class="account-intro-copy">
          <h1 id="account-product-name"><span>软件需求</span><span>审查工作台</span></h1>
          <p>核对原文证据，跟踪审查与修订。</p>
        </div>
        <ul class="account-workflow">
          <li v-for="item in workflow" :key="item.title">
            <component :is="item.icon" :size="18" aria-hidden="true" />
            <span>{{ item.title }}</span>
          </li>
        </ul>
      </section>

      <section class="account-panel" aria-labelledby="login-heading">
        <div class="login-form">
          <div v-if="canRegister" class="account-mode" role="group" aria-label="账户操作">
            <button type="button" :aria-pressed="mode === 'login'" aria-controls="account-entry-form" :disabled="busy" @click="changeMode(false)">登录</button>
            <button type="button" :aria-pressed="mode === 'register'" aria-controls="account-entry-form" :disabled="busy" @click="changeMode(true)">注册</button>
          </div>
          <h2 id="login-heading">{{ title }}</h2>
          <p class="account-description">{{ description }}</p>
          <form id="account-entry-form" :key="mode" :aria-busy="busy" @submit.prevent="submit">
            <fieldset :disabled="busy" class="account-fields" aria-labelledby="login-heading">
              <div class="account-field">
                <label for="account-username">用户名</label>
                <input id="account-username" v-model.trim="form.username" minlength="3" maxlength="40" :pattern="usernamePattern" autocomplete="username" autocapitalize="none" spellcheck="false" :aria-describedby="creating ? 'account-username-hint' : undefined" placeholder="输入用户名" required>
                <small v-if="creating" id="account-username-hint">3–40 个字母、数字、点、下划线或连字符，以字母或数字开头。</small>
              </div>
              <div v-if="creating" class="account-field">
                <label for="account-display-name">显示名称 <small>选填</small></label>
                <input id="account-display-name" v-model.trim="form.displayName" maxlength="100" :autocomplete="setup ? 'name' : 'nickname'" placeholder="例如林晓">
              </div>
              <div class="account-field">
                <label for="login-password">密码</label>
                <div class="password-field">
                  <input id="login-password" v-model="form.password" :type="visible ? 'text' : 'password'" :minlength="setup ? 12 : undefined" :maxlength="setup ? 128 : undefined" :autocomplete="creating ? 'new-password' : 'current-password'" :placeholder="setup ? '12–128 个字符' : '输入密码'" required>
                  <button class="icon-button" type="button" :aria-label="visible ? '隐藏密码' : '显示密码'" :aria-pressed="visible" aria-controls="login-password" @click="visible = !visible"><EyeOff v-if="visible" :size="18" aria-hidden="true" /><Eye v-else :size="18" aria-hidden="true" /></button>
                </div>
              </div>
              <div v-if="setup && session?.setupTokenRequired" class="account-field">
                <label for="account-setup-code">初始化口令</label>
                <input id="account-setup-code" v-model="form.setupToken" type="password" autocomplete="off" maxlength="512" required>
              </div>
            </fieldset>
            <p v-if="error && showError" class="login-error" role="alert"><CircleAlert :size="16" aria-hidden="true" /> <span>{{ error }}</span></p>
            <button class="button primary login-submit" :disabled="busy">{{ submitLabel }} <ArrowRight :size="17" aria-hidden="true" /></button>
          </form>
          <button v-if="offline" class="button secondary login-demo" :disabled="busy" @click="emit('demo')"><Sparkles :size="17" aria-hidden="true" /> 进入交互演示</button>
        </div>
      </section>
    </div>
  </main>
</template>

<style scoped>
.account-access {
  display: grid;
  place-items: center;
  min-height: 100vh;
  min-height: 100svh;
  padding: clamp(28px, 5vw, 72px);
  background: radial-gradient(ellipse at 46% 10%, #fcf9ee, transparent 75%), #eeeae0;
  color: #172920;
  --text: #172920;
  --muted: #5c6459;
  --line: #dbd2bd;
  --primary: #19362a;
  --primary-hover: #244736;
  --serif: "Noto Serif SC", "Noto Serif CJK SC", "Source Han Serif SC", "Songti SC", SimSun, Georgia, serif;
}

.account-sheet {
  display: grid;
  grid-template-columns: minmax(0, 1.05fr) minmax(0, 1fr);
  width: min(100%, 1072px);
  min-height: 568px;
  overflow: hidden;
  border: 1px solid #cabb99;
  border-radius: 15px;
  background: #fffcf4;
  box-shadow: 0 29px 66px -23px #30291d44, 0 3px 9px #30291d13;
}

.account-intro {
  display: grid;
  grid-template-rows: auto 1fr auto;
  gap: 35px;
  position: relative;
  isolation: isolate;
  min-width: 0;
  overflow: hidden;
  padding: clamp(28px, 4.35vw, 62px);
  background:
    repeating-linear-gradient(101deg, #ecd9a409 0 1px, transparent 1px 5px),
    radial-gradient(ellipse at 12% 0, #365044 0, transparent 68%),
    linear-gradient(151deg, #19352b, #101f18 75%);
  color: #f8f2e4;
}

.account-intro::before {
  content: "";
  position: absolute;
  pointer-events: none;
  z-index: -1;
  inset: 12px;
  border: 1px solid #d8bf8057;
  border-radius: 8px;
}

.account-intro-art {
  position: absolute;
  z-index: -2;
  right: -11%;
  bottom: -6%;
  width: 100%;
  height: 68%;
  object-fit: cover;
  object-position: 64% 68%;
  opacity: .86;
  mask-image: radial-gradient(ellipse at 83% 83%, #000 24%, #000c 45%, transparent 76%);
  pointer-events: none;
}

.account-brand {
  display: flex;
  align-items: center;
  gap: 11px;
  font-size: 14px;
  font-weight: 680;
  letter-spacing: .06em;
}

.account-brand-icon {
  display: grid;
  place-items: center;
  flex: none;
  width: 39px;
  height: 39px;
  border: 1px solid #b69e6b;
  border-radius: 8px;
  background: linear-gradient(150deg, #c1a8782c, #c1a87808);
  color: #ecd5a3;
}

.account-intro-copy {
  align-self: center;
}

.account-intro h1 {
  font-family: var(--serif);
  font-size: clamp(35px, 4.1vw, 59px);
  font-synthesis: weight;
  font-weight: 700;
  line-height: 1.21;
  letter-spacing: .018em;
}

.account-intro h1 span {
  display: block;
}

.account-intro h1 span:last-child {
  color: #ead7ab;
}

.account-intro-copy p {
  margin-top: 17px;
  color: #eeeadb;
  font-size: 15px;
  line-height: 1.8;
}

.account-workflow {
  display: grid;
  grid-template-columns: repeat(3, minmax(0, 1fr));
  margin: 0;
  padding: 17px 0 0;
  border-top: 1px solid #dabd8159;
  list-style: none;
}

.account-workflow li {
  display: flex;
  align-items: center;
  gap: 7px;
  min-width: 0;
  color: #f0e9d9;
  font-size: 12px;
  font-weight: 620;
}

.account-workflow svg {
  flex: none;
  color: #ddc38c;
}

.account-panel {
  display: grid;
  place-items: center;
  min-width: 0;
  padding: clamp(28px, 5vw, 74px);
  background: linear-gradient(145deg, #fffdf8 0, #f9f5e9 100%);
}

.account-panel .login-form {
  width: min(100%, 360px);
}

.account-mode {
  display: flex;
  align-items: stretch;
  gap: 24px;
  margin-bottom: 27px;
  border-bottom: 1px solid var(--line);
}

.account-mode button {
  flex: 0 0 auto;
  min-height: 41px;
  margin-bottom: -1px;
  padding: 0 3px;
  border: 0;
  border-bottom: 2px solid transparent;
  background: transparent;
  color: var(--muted);
  font-size: 14px;
  font-weight: 650;
}

.account-mode button:not(:disabled):hover,
.account-mode button[aria-pressed="true"] {
  color: var(--primary-hover);
}

.account-mode button[aria-pressed="true"] {
  border-bottom-color: #95723e;
  font-weight: 750;
}

.account-panel h2 {
  font-family: var(--serif);
  font-size: clamp(26px, 2.6vw, 35px);
  font-synthesis: weight;
  font-weight: 700;
  line-height: 1.23;
  letter-spacing: .018em;
}

.account-panel .account-description {
  margin: 9px 0 26px;
  color: var(--muted);
  font-size: 14px;
  line-height: 1.65;
}

.account-panel form,
.account-fields,
.account-field {
  display: grid;
}

.account-panel form,
.account-fields {
  gap: 16px;
}

.account-fields {
  min-width: 0;
  margin: 0;
  padding: 0;
  border: 0;
}

.account-field {
  gap: 7px;
}

.account-panel .account-field label {
  display: flex;
  align-items: baseline;
  gap: 8px;
  color: #30483b;
  font-size: 14px;
  font-weight: 650;
}

.account-field small {
  color: var(--muted);
  font-size: 12px;
  font-weight: 500;
  line-height: 1.6;
}

.account-panel .account-field input {
  min-height: 47px;
  border: 1px solid #d5ccb6;
  border-radius: 8px;
  background: #fffdf8;
  color: var(--text);
}

.account-panel .account-field input::placeholder {
  color: #666c61;
  opacity: 1;
}

.account-access :focus-visible {
  outline-color: #3e7f66;
}

.account-panel .password-field input {
  padding-right: 48px;
}

.account-panel .password-field button {
  top: 50%;
  right: 4px;
  width: 38px;
  height: 38px;
  transform: translateY(-50%);
  color: #4d6658;
}

.account-panel .password-field button:not(:disabled):hover {
  background: #f1eadb;
}

.account-panel .login-submit,
.account-panel .login-demo {
  min-height: 46px;
  margin: 0;
}

.account-panel .login-submit {
  justify-content: space-between;
  margin-top: 3px;
  padding-inline: 15px;
  box-shadow: 0 4px 13px #152b2421, inset 0 1px 0 #d4b78942;
}

.login-submit svg {
  color: #e8cb96;
}

.account-panel .login-demo {
  margin-top: 11px;
}

.account-panel .login-error {
  display: flex;
  align-items: flex-start;
  gap: 7px;
  border: 1px solid #f1dfe0;
  background: #fff1f0;
  color: #87363f;
}

.login-error svg {
  flex: none;
  margin-top: 1px;
}

@media (max-width: 760px) {
  .account-access {
    place-items: start center;
    padding: 18px 14px 28px;
  }

  .account-sheet {
    grid-template-columns: 1fr;
    width: min(100%, 480px);
    min-height: 0;
    border-radius: 15px;
  }

  .account-intro {
    display: flex;
    flex-direction: column;
    gap: 22px;
    padding: 23px 24px 27px;
  }

  .account-intro::before {
    inset: 7px;
  }

  .account-intro-art {
    right: -6%;
    bottom: -10%;
    width: 74%;
    height: 100%;
    opacity: .6;
    mask-image: radial-gradient(ellipse at 97% 103%, #000 18%, transparent 72%);
  }

  .account-brand-icon {
    width: 32px;
    height: 32px;
  }

  .account-intro-copy {
    align-self: stretch;
  }

  .account-intro h1 {
    font-size: clamp(24px, 6vw, 29px);
  }

  .account-intro h1 span {
    display: inline;
  }

  .account-intro-copy p {
    margin-top: 7px;
    font-size: 13px;
  }

  .account-workflow {
    display: none;
  }

  .account-panel {
    min-height: 0;
    padding: 24px 22px 28px;
  }

  .account-panel .login-form {
    width: 100%;
  }

  .account-mode {
    margin-bottom: 19px;
  }

  .account-mode button {
    min-height: 42px;
  }

  .account-panel .account-description {
    margin-bottom: 20px;
  }

  .account-panel .account-field input {
    font-size: 16px;
  }
}
</style>
