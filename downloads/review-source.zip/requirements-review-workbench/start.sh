#!/bin/sh
set -eu
cd "$(dirname "$0")"
: "${SERVER_PORT:=8080}"
export SERVER_PORT
printf '%s\n' "Open http://127.0.0.1:$SERVER_PORT when the service is ready."
exec java -jar app/req-audit-1.0.0.jar
