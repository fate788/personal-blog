"""Build the application first, then exercise a fresh local database and review workflow."""

import argparse
from contextlib import contextmanager
from http.cookiejar import CookieJar
import json
import os
from pathlib import Path
import re
import secrets
import subprocess
import tempfile
import time
from urllib.error import HTTPError
from urllib.request import HTTPCookieProcessor, Request, build_opener

ROOT = Path(__file__).resolve().parents[1]


@contextmanager
def scratch_server(jar):
    env = {k: v for k, v in os.environ.items() if not k.upper().startswith(
        ("REVIEW_", "EVOLINK_", "SPRING_", "SERVER_", "DB_", "JDK_JAVA_OPTIONS", "JAVA_TOOL_OPTIONS", "_JAVA_OPTIONS")
    )}
    with tempfile.TemporaryDirectory(prefix="requirements-review-") as name:
        folder = Path(name)
        log = folder / "startup.log"
        with log.open("wb") as output:
            server = subprocess.Popen(
                ["java", "-jar", str(jar), "--server.port=0", "--server.address=127.0.0.1"],
                cwd=folder, env=env, stdout=output, stderr=subprocess.STDOUT,
            )
        try:
            for _ in range(240):
                if server.poll() is not None:
                    raise RuntimeError("The temporary application exited during startup.")
                match = re.search(r"Tomcat started on port (\d+)", log.read_text("utf-8", errors="replace"))
                if match:
                    yield f"http://127.0.0.1:{match[1]}"
                    return
                time.sleep(0.25)
            raise TimeoutError("The temporary application did not become ready.")
        finally:
            server.terminate()
            try:
                server.wait(timeout=10)
            except subprocess.TimeoutExpired:
                server.kill()
                server.wait()


def exercise(base):
    client = build_opener(HTTPCookieProcessor(CookieJar()))

    def api(path, data=None):
        request = Request(base + "/api" + path, headers={"X-Review-Client": "web", "Content-Type": "application/json"},
                          data=None if data is None else json.dumps(data).encode())
        with client.open(request, timeout=30) as response:
            return json.load(response)

    with client.open(base + "/", timeout=10) as response:
        assert "需求审查" in response.read().decode("utf-8"), "Build the frontend before packaging the backend."
    assert not api("/session")["initialized"]
    account = {"username": "review-smoke", "displayName": "示例复核人", "password": secrets.token_urlsafe(24)}
    assert api("/session/setup", account)["user"]["role"] == "ADMIN"
    project = api("/projects/sample", {})
    workspace = api("/workspace?projectId=" + project["id"])
    document = workspace["documents"][0]
    version = max(document["versions"], key=lambda v: v["number"])
    pack = next(p for p in workspace["packs"] if p["id"] == "general")
    run = api("/reviews", {
        "documentId": document["id"], "versionId": version["id"], "packId": pack["id"], "mode": "DEMO",
        "async": False, "executionStrategy": "LOCAL_ONLY",
    })
    report = api(f"/reviews/{run['id']}/report")
    assert report["run"]["id"] == run["id"] and report["run"]["status"] == "COMPLETED"
    assert report["documentTitle"] == document["title"] and report["versionNumber"] == version["number"]
    cases = api(f"/projects/{project['id']}/cases")
    assert len(cases) == 6
    first = cases[0]["sample"]["id"]
    imported = api(f"/projects/{project['id']}/cases/{first}/import", {})
    assert imported and api(f"/projects/{project['id']}/cases")[0]["imported"]
    # A second browser cannot read the signed-in project.
    try:
        with build_opener().open(base + "/api/workspace?projectId=" + project["id"], timeout=10):
            raise AssertionError("Authenticated project data was accessible to an anonymous session.")
    except HTTPError as error:
        assert error.code == 401, error.code
    print("Verified first setup, session isolation, sample project, version-bound local review, report and public case import.")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--jar", type=Path, default=ROOT / "backend/target/req-audit-1.0.0.jar")
    jar = parser.parse_args().jar.resolve(strict=True)
    with scratch_server(jar) as base_url:
        exercise(base_url)
