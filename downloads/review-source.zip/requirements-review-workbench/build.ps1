$ErrorActionPreference = 'Stop'
Push-Location -LiteralPath $PSScriptRoot
try {
    Push-Location -LiteralPath 'frontend'
    try {
        npm.cmd ci --no-audit --no-fund
        if ($LASTEXITCODE -ne 0) { throw 'Frontend dependency installation failed.' }
        npm.cmd run build
        if ($LASTEXITCODE -ne 0) { throw 'Frontend build failed.' }
        node build-review.mjs
        if ($LASTEXITCODE -ne 0) { throw 'Offline review build failed.' }
    } finally {
        Pop-Location
    }
    mvn.cmd -f backend/pom.xml clean package
    if ($LASTEXITCODE -ne 0) { throw 'Backend build failed.' }
    New-Item -ItemType Directory -Force -Path 'app' | Out-Null
    Copy-Item -LiteralPath 'backend/target/req-audit-1.0.0.jar' -Destination 'app/'
    Copy-Item -LiteralPath 'frontend/dist/preview.html' -Destination 'review-preview.html'
} finally {
    Pop-Location
}
