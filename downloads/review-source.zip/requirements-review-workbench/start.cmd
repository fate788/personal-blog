@echo off
setlocal
cd /d "%~dp0"
if not defined SERVER_PORT set "SERVER_PORT=8080"
echo Open http://127.0.0.1:%SERVER_PORT% when the service is ready.
java -jar app/req-audit-1.0.0.jar
exit /b %ERRORLEVEL%
