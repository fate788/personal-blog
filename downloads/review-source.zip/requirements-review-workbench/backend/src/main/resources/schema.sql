CREATE TABLE IF NOT EXISTS review_document (
  id VARCHAR(64) PRIMARY KEY,
  title VARCHAR(200) NOT NULL,
  created_at VARCHAR(40) NOT NULL,
  updated_at VARCHAR(40) NOT NULL
);

CREATE TABLE IF NOT EXISTS document_version (
  id VARCHAR(64) PRIMARY KEY,
  document_id VARCHAR(64) NOT NULL,
  version_no INT NOT NULL,
  payload LONGTEXT NOT NULL,
  CONSTRAINT fk_version_document FOREIGN KEY (document_id) REFERENCES review_document(id),
  CONSTRAINT uq_document_version UNIQUE (document_id, version_no)
);

CREATE TABLE IF NOT EXISTS review_run (
  id VARCHAR(64) PRIMARY KEY,
  document_id VARCHAR(64) NOT NULL,
  version_id VARCHAR(64) NOT NULL,
  created_at VARCHAR(40) NOT NULL,
  payload LONGTEXT NOT NULL,
  CONSTRAINT fk_run_document FOREIGN KEY (document_id) REFERENCES review_document(id),
  CONSTRAINT fk_run_version FOREIGN KEY (version_id) REFERENCES document_version(id)
);

CREATE TABLE IF NOT EXISTS finding_decision (
  id VARCHAR(64) PRIMARY KEY,
  run_id VARCHAR(64) NOT NULL,
  finding_id VARCHAR(64) NOT NULL,
  prior_decision VARCHAR(16) NOT NULL,
  new_decision VARCHAR(16) NOT NULL,
  note LONGTEXT NOT NULL,
  created_at VARCHAR(40) NOT NULL,
  CONSTRAINT fk_decision_run FOREIGN KEY (run_id) REFERENCES review_run(id)
);

CREATE TABLE IF NOT EXISTS studio_account (
  id VARCHAR(64) PRIMARY KEY,
  username VARCHAR(40) NOT NULL UNIQUE,
  display_name VARCHAR(100) NOT NULL,
  password_hash VARCHAR(256) NOT NULL,
  account_role VARCHAR(16) NOT NULL,
  created_at VARCHAR(40) NOT NULL
);

CREATE TABLE IF NOT EXISTS studio_session (
  token_hash VARCHAR(64) PRIMARY KEY,
  account_id VARCHAR(64) NOT NULL,
  expires_ms BIGINT NOT NULL,
  CONSTRAINT fk_session_account FOREIGN KEY (account_id) REFERENCES studio_account(id)
);

CREATE TABLE IF NOT EXISTS studio_onboarding (
  account_id VARCHAR(64) PRIMARY KEY,
  shown_at VARCHAR(40) NOT NULL,
  CONSTRAINT fk_onboarding_account FOREIGN KEY (account_id) REFERENCES studio_account(id)
);

CREATE TABLE IF NOT EXISTS delivery_checklist (
  actor_id VARCHAR(64) NOT NULL,
  version_id VARCHAR(64) NOT NULL,
  review_id VARCHAR(64) NOT NULL,
  item_key VARCHAR(32) NOT NULL,
  evidence_signature VARCHAR(1200) NOT NULL,
  checked_at VARCHAR(40) NOT NULL,
  PRIMARY KEY (actor_id, version_id, review_id, item_key),
  CONSTRAINT fk_delivery_check_actor FOREIGN KEY (actor_id) REFERENCES studio_account(id),
  CONSTRAINT fk_delivery_check_version FOREIGN KEY (version_id) REFERENCES document_version(id)
);

CREATE TABLE IF NOT EXISTS studio_project (
  id VARCHAR(64) PRIMARY KEY,
  owner_id VARCHAR(64) NOT NULL,
  name VARCHAR(120) NOT NULL,
  description VARCHAR(2000) NOT NULL,
  created_at VARCHAR(40) NOT NULL,
  updated_at VARCHAR(40) NOT NULL,
  CONSTRAINT fk_project_owner FOREIGN KEY (owner_id) REFERENCES studio_account(id)
);

CREATE TABLE IF NOT EXISTS document_scope (
  document_id VARCHAR(64) PRIMARY KEY,
  project_id VARCHAR(64) NOT NULL,
  CONSTRAINT fk_scope_project FOREIGN KEY (project_id) REFERENCES studio_project(id),
  CONSTRAINT fk_scope_document FOREIGN KEY (document_id) REFERENCES review_document(id)
);

CREATE TABLE IF NOT EXISTS review_job (
  run_id VARCHAR(64) PRIMARY KEY,
  job_status VARCHAR(16) NOT NULL,
  accepted_at VARCHAR(40) NOT NULL,
  CONSTRAINT fk_job_run FOREIGN KEY (run_id) REFERENCES review_run(id)
);

CREATE TABLE IF NOT EXISTS review_queue_guard (
  id INT PRIMARY KEY
);

CREATE TABLE IF NOT EXISTS review_reuse_slot (
  fingerprint CHAR(64) PRIMARY KEY,
  execution_revision VARCHAR(80) NOT NULL,
  active_run_id VARCHAR(64) UNIQUE,
  completed_run_id VARCHAR(64),
  CONSTRAINT fk_reuse_active FOREIGN KEY (active_run_id) REFERENCES review_run(id),
  CONSTRAINT fk_reuse_completed FOREIGN KEY (completed_run_id) REFERENCES review_run(id)
);

INSERT INTO review_queue_guard (id)
SELECT 1 WHERE NOT EXISTS (SELECT 1 FROM review_queue_guard WHERE id = 1);

CREATE TABLE IF NOT EXISTS project_member (
  project_id VARCHAR(64) NOT NULL,
  account_id VARCHAR(64) NOT NULL,
  project_role VARCHAR(16) NOT NULL,
  PRIMARY KEY (project_id, account_id),
  CONSTRAINT fk_member_project FOREIGN KEY (project_id) REFERENCES studio_project(id),
  CONSTRAINT fk_member_account FOREIGN KEY (account_id) REFERENCES studio_account(id)
);

CREATE TABLE IF NOT EXISTS project_rule_revision (
  rule_id VARCHAR(64) NOT NULL,
  revision_no INT NOT NULL,
  project_id VARCHAR(64) NOT NULL,
  rule_name VARCHAR(100) NOT NULL,
  rule_kind VARCHAR(30) NOT NULL,
  rule_scope VARCHAR(30) NOT NULL,
  trigger_text VARCHAR(120) NOT NULL,
  required_text VARCHAR(120) NOT NULL,
  guidance VARCHAR(400) NOT NULL,
  enabled BOOLEAN NOT NULL,
  actor_id VARCHAR(64) NOT NULL,
  created_at VARCHAR(40) NOT NULL,
  PRIMARY KEY (rule_id, revision_no),
  CONSTRAINT fk_rule_project FOREIGN KEY (project_id) REFERENCES studio_project(id),
  CONSTRAINT fk_rule_actor FOREIGN KEY (actor_id) REFERENCES studio_account(id)
);

CREATE TABLE IF NOT EXISTS project_rule_feedback (
  rule_id VARCHAR(64) NOT NULL,
  revision_no INT NOT NULL,
  version_id VARCHAR(64) NOT NULL,
  line_no INT NOT NULL,
  verdict VARCHAR(16) NOT NULL,
  actor_id VARCHAR(64) NOT NULL,
  updated_at VARCHAR(40) NOT NULL,
  PRIMARY KEY (rule_id, revision_no, version_id, line_no),
  CONSTRAINT fk_rule_feedback_revision FOREIGN KEY (rule_id, revision_no) REFERENCES project_rule_revision(rule_id, revision_no),
  CONSTRAINT fk_rule_feedback_version FOREIGN KEY (version_id) REFERENCES document_version(id),
  CONSTRAINT fk_rule_feedback_actor FOREIGN KEY (actor_id) REFERENCES studio_account(id)
);

CREATE TABLE IF NOT EXISTS review_issue (
  run_id VARCHAR(64) NOT NULL,
  finding_id VARCHAR(64) NOT NULL,
  issue_status VARCHAR(16) NOT NULL,
  assignee_id VARCHAR(64),
  due_date VARCHAR(10),
  resolution_version_id VARCHAR(64),
  note LONGTEXT NOT NULL,
  updated_by VARCHAR(64) NOT NULL,
  updated_at VARCHAR(40) NOT NULL,
  revision_no INT NOT NULL,
  PRIMARY KEY (run_id, finding_id),
  CONSTRAINT fk_issue_run FOREIGN KEY (run_id) REFERENCES review_run(id),
  CONSTRAINT fk_issue_assignee FOREIGN KEY (assignee_id) REFERENCES studio_account(id),
  CONSTRAINT fk_issue_actor FOREIGN KEY (updated_by) REFERENCES studio_account(id),
  CONSTRAINT fk_issue_version FOREIGN KEY (resolution_version_id) REFERENCES document_version(id)
);

CREATE TABLE IF NOT EXISTS issue_event (
  run_id VARCHAR(64) NOT NULL,
  finding_id VARCHAR(64) NOT NULL,
  revision_no INT NOT NULL,
  prior_status VARCHAR(16) NOT NULL,
  new_status VARCHAR(16) NOT NULL,
  assignee_id VARCHAR(64),
  assignee_name VARCHAR(100),
  due_date VARCHAR(10),
  resolution_version_id VARCHAR(64),
  note LONGTEXT NOT NULL,
  actor_id VARCHAR(64) NOT NULL,
  actor_name VARCHAR(100) NOT NULL,
  created_at VARCHAR(40) NOT NULL,
  PRIMARY KEY (run_id, finding_id, revision_no),
  CONSTRAINT fk_event_issue FOREIGN KEY (run_id, finding_id) REFERENCES review_issue(run_id, finding_id)
);

CREATE TABLE IF NOT EXISTS execution_batch (
  id VARCHAR(64) PRIMARY KEY,
  document_id VARCHAR(64) NOT NULL,
  version_id VARCHAR(64) NOT NULL,
  import_no BIGINT NOT NULL,
  import_key VARCHAR(64) NOT NULL,
  record_scope VARCHAR(32) NOT NULL,
  source_label VARCHAR(500) NOT NULL,
  file_name VARCHAR(200) NOT NULL,
  file_sha256 VARCHAR(64) NOT NULL,
  observed_at VARCHAR(40),
  imported_at VARCHAR(40) NOT NULL,
  imported_by VARCHAR(64) NOT NULL,
  row_count INT NOT NULL,
  CONSTRAINT fk_execution_batch_document FOREIGN KEY (document_id) REFERENCES review_document(id),
  CONSTRAINT fk_execution_batch_version FOREIGN KEY (version_id) REFERENCES document_version(id),
  CONSTRAINT fk_execution_batch_actor FOREIGN KEY (imported_by) REFERENCES studio_account(id),
  CONSTRAINT uq_execution_batch_order UNIQUE (version_id, import_no),
  CONSTRAINT uq_execution_batch_input UNIQUE (version_id, import_key)
);

CREATE TABLE IF NOT EXISTS execution_record (
  batch_id VARCHAR(64) NOT NULL,
  row_no INT NOT NULL,
  requirement_id VARCHAR(160) NOT NULL,
  requirement_key VARCHAR(160) NOT NULL,
  case_id VARCHAR(160) NOT NULL,
  case_key VARCHAR(64) NOT NULL,
  related_case_ids VARCHAR(500) NOT NULL,
  record_status VARCHAR(16) NOT NULL,
  executed_at VARCHAR(40),
  effective_ms BIGINT NOT NULL,
  evidence LONGTEXT NOT NULL,
  PRIMARY KEY (batch_id, row_no),
  CONSTRAINT fk_execution_record_batch FOREIGN KEY (batch_id) REFERENCES execution_batch(id)
);

CREATE TABLE IF NOT EXISTS project_pack (
  id VARCHAR(64) PRIMARY KEY,
  project_id VARCHAR(64) NOT NULL,
  current_revision INT NOT NULL,
  archived BOOLEAN NOT NULL,
  CONSTRAINT fk_project_pack_project FOREIGN KEY (project_id) REFERENCES studio_project(id)
);

CREATE TABLE IF NOT EXISTS project_pack_revision (
  pack_id VARCHAR(64) NOT NULL,
  revision_no INT NOT NULL,
  payload LONGTEXT NOT NULL,
  PRIMARY KEY (pack_id, revision_no),
  CONSTRAINT fk_pack_revision_pack FOREIGN KEY (pack_id) REFERENCES project_pack(id)
);
