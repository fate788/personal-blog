package studio.reqaudit;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import static studio.reqaudit.Domain.*;

@Repository
class ProjectPacks {
    record Input(String basePackId, String name, String description, List<Rule> rules, Integer revision) {}
    private static final Pattern CUSTOM_RULE_ID = Pattern.compile("C-[A-Za-z0-9][A-Za-z0-9-]{0,27}");
    private static final String CURRENT = """
            SELECT v.payload FROM project_pack h JOIN project_pack_revision v
                ON v.pack_id = h.id AND v.revision_no = h.current_revision
            WHERE h.project_id = ? AND h.archived = FALSE
            """;

    private final JdbcTemplate jdbc;
    private final AuditCatalog catalog;
    private final AuditRepository audit;

    ProjectPacks(JdbcTemplate jdbc, AuditCatalog catalog, AuditRepository audit) {
        this.jdbc = jdbc;
        this.catalog = catalog;
        this.audit = audit;
    }

    List<Pack> list(String projectId) {
        return jdbc.query(CURRENT + " ORDER BY h.id", (rs, index) -> audit.read(rs.getString(1), Pack.class), projectId);
    }

    List<Pack> selectable(String projectId) {
        var result = new ArrayList<>(catalog.getPacks());
        result.addAll(list(projectId));
        return result;
    }

    Run historical(Run run) {
        if (run.packSnapshot() != null) return run;
        Pack known = catalog.requirePack(run.packId());
        if (!known.version().equals(run.packVersion())) {
            // Earlier releases kept the version and findings but did not retain that version's rule definitions.
            known = new Pack(known.id(), known.name(), known.description(), run.packVersion(), List.of());
        }
        return run.withPackSnapshot(known);
    }

    Pack forDocument(String documentId, String id, String requestedVersion) {
        if (!id.startsWith("custom-")) {
            Pack builtin = catalog.requirePack(id);
            if (requestedVersion != null && !builtin.version().equals(requestedVersion)) {
                throw ApiFailure.conflict("审查模板已更新，请重新选择。");
            }
            return builtin;
        }
        // Scope the lookup to the target document even when the caller supplies a valid pack ID or revision.
        String sql = """
                SELECT v.payload FROM project_pack h JOIN document_scope s ON s.project_id = h.project_id
                JOIN project_pack_revision v ON v.pack_id = h.id
                WHERE s.document_id = ? AND h.id = ? AND h.archived = FALSE AND v.revision_no =
                """;
        List<String> rows;
        if (requestedVersion == null) {
            rows = jdbc.queryForList(sql + " h.current_revision", String.class, documentId, id);
        } else {
            int revision;
            try {
                revision = Integer.parseInt(requestedVersion);
            } catch (NumberFormatException e) {
                throw ApiFailure.badRequest("审查包版本无效。");
            }
            rows = jdbc.queryForList(sql + " ?", String.class, documentId, id, revision);
        }
        return audit.read(rows.stream().findFirst().orElseThrow(() -> ApiFailure.notFound("当前项目没有可用的该审查包版本。")), Pack.class);
    }

    @Transactional
    Pack create(String projectId, Input input) {
        String id = "custom-" + AuditRepository.id();
        Pack pack = validated(id, 1, input);
        jdbc.update("INSERT INTO project_pack (id, project_id, current_revision, archived) VALUES (?, ?, 1, FALSE)", id, projectId);
        insertRevision(pack);
        return pack;
    }

    @Transactional
    Pack update(String projectId, String id, Input input) {
        Pack current = current(projectId, id);
        if (input == null || !current.revision().equals(input.revision())) throw changed();
        if (!current.basePackId().equals(input.basePackId())) throw ApiFailure.badRequest("编辑时请保留原模板。");
        Pack pack = validated(id, current.revision() + 1, input);
        int count = jdbc.update("""
                UPDATE project_pack SET current_revision = ? WHERE id = ? AND project_id = ?
                AND current_revision = ? AND archived = FALSE
                """, pack.revision(), id, projectId, current.revision());
        if (count != 1) throw changed();
        insertRevision(pack);
        return pack;
    }

    @Transactional
    void archive(String projectId, String id, int revision) {
        current(projectId, id);
        if (jdbc.update("""
                UPDATE project_pack SET archived = TRUE WHERE project_id = ? AND id = ?
                AND current_revision = ? AND archived = FALSE
                """, projectId, id, revision) != 1) throw changed();
    }

    private Pack current(String projectId, String id) {
        return jdbc.query(CURRENT + " AND h.id = ?", (rs, index) -> audit.read(rs.getString(1), Pack.class),
                        projectId, id).stream().findFirst().orElseThrow(() -> ApiFailure.notFound("当前项目没有此自定义审查包。"));
    }

    private void insertRevision(Pack pack) {
        jdbc.update("INSERT INTO project_pack_revision (pack_id, revision_no, payload) VALUES (?, ?, ?)",
                pack.id(), pack.revision(), audit.write(pack));
    }

    private static ApiFailure changed() {
        return ApiFailure.conflict("审查包已被更新，请刷新后再编辑。");
    }

    private Pack validated(String id, int revision, Input input) {
        if (input == null) throw ApiFailure.badRequest("请填写审查包内容。");
        Pack base = catalog.getPacks().stream().filter(pack -> pack.id().equals(input.basePackId())).findFirst()
                .orElseThrow(() -> ApiFailure.badRequest("请选择可用的审查模板。"));
        String name = ApiFailure.requireText(input.name(), "审查包名称", 100).strip();
        String description = ApiFailure.optionalText(input.description(), "审查说明", 600);
        if (input.rules() == null || input.rules().isEmpty() || input.rules().size() > 24) {
            throw ApiFailure.badRequest("每个自定义审查包可设置 1 至 24 个检查项。");
        }
        Map<String, Rule> inherited = base.rules().stream().collect(Collectors.toMap(Rule::id, rule -> rule));
        Set<String> used = new HashSet<>();
        List<Rule> rules = new ArrayList<>();
        for (Rule rule : input.rules()) {
            if (rule == null) throw ApiFailure.badRequest("检查项不能为空。");
            String ruleId = rule.id() == null || rule.id().isBlank()
                    ? newRuleId() : rule.id().strip();
            Rule original = inherited.get(ruleId);
            if ((original == null && !CUSTOM_RULE_ID.matcher(ruleId).matches()) || !used.add(ruleId)) {
                throw ApiFailure.badRequest("检查项编号无效或重复。自建检查项请使用 C- 开头的独立编号。");
            }
            String ruleName = ApiFailure.requireText(rule.name(), "检查项名称", 100).strip();
            String question = ApiFailure.requireText(rule.question(), "检查问题", 600).strip();
            String applies = ApiFailure.optionalText(rule.applies(), "适用条件", 600);
            String criterion = ApiFailure.optionalText(rule.criterion(), "判断标准", 600);
            String example = ApiFailure.optionalText(rule.example(), "示例", 600);
            // Built-in IDs can require specific evidence (e.g. two clauses or particular legal articles).
            // Rewritten checks get independent IDs; any evidence policy for the whole template still applies.
            if (original != null && (!question.equals(original.question())
                    || !applies.equals(original.applies()) || !criterion.equals(original.criterion()))) {
                do {
                    ruleId = newRuleId();
                } while (!used.add(ruleId));
            }
            rules.add(new Rule(ruleId, ruleName, question, applies, criterion, example));
        }
        return new Pack(id, name, description, Integer.toString(revision), List.copyOf(rules), base.id(), revision);
    }

    private static String newRuleId() { return "C-" + AuditRepository.id().substring(0, 18); }
}
