package studio.reqaudit;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.io.IOException;
import java.util.List;

import static studio.reqaudit.StudioAccess.ACCOUNT;

@RestController
@RequestMapping("/api/projects/{projectId}/cases")
class VerifiedCasesController {
    private final Projects projects;
    private final VerifiedCases cases;

    VerifiedCasesController(Projects projects, VerifiedCases cases) {
        this.projects = projects;
        this.cases = cases;
    }

    @GetMapping
    List<VerifiedCases.Card> list(@RequestAttribute(ACCOUNT) Accounts.User user, @PathVariable String projectId) {
        projects.accessible(user.id(), projectId);
        return cases.list(projectId);
    }

    @GetMapping("/{caseId}/reference")
    VerifiedCases.Example reference(@RequestAttribute(ACCOUNT) Accounts.User user, @PathVariable String projectId,
                                    @PathVariable String caseId, @RequestParam String runId) {
        projects.accessible(user.id(), projectId);
        return cases.upstreamReference(projectId, caseId, runId);
    }

    @PostMapping("/{caseId}/import")
    VerifiedCases.Imported importCase(@RequestAttribute(ACCOUNT) Accounts.User user, @PathVariable String projectId,
                                      @PathVariable String caseId) throws IOException {
        if (!projects.accessible(user.id(), projectId).role().mayEdit()) {
            throw ApiFailure.forbidden("请项目所有者或编辑者导入案例。");
        }
        return cases.importCase(projectId, caseId);
    }
    @PostMapping("/import")
    List<VerifiedCases.Card> importAll(@RequestAttribute(ACCOUNT) Accounts.User user, @PathVariable String projectId)
            throws IOException {
        if (!projects.accessible(user.id(), projectId).role().mayEdit()) {
            throw ApiFailure.forbidden("请项目所有者或编辑者导入文档。");
        }
        return cases.importAll(projectId);
    }
}
