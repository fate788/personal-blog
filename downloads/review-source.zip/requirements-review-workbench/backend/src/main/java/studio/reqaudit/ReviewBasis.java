package studio.reqaudit;

import java.util.List;
import java.util.Set;

import static studio.reqaudit.Domain.*;

record ReviewBasis(String submitted, List<Reference> references, String scenario) {
    record Reference(String id, String code, String text) {}

    static final String COMPANY = "business-fit";
    static final String PRIVACY = "legal-risk";
    static final String JOURNEY = "user-journey";
    static final String COMPANY_SOURCE = "basis-company";
    static final int TEXT_LIMIT = 3_000;

    private static final List<Reference> PRIVACY_REFERENCES = List.of(
            privacy("6", "第六条", "处理目的须明确、合理，并与收集内容直接相关。收集范围限于实现目的所必要的个人信息，采用对个人权益影响最小的方式。"),
            privacy("17", "第十七条", "处理前通常要清楚告知处理者及联系方式、处理目的和方式、信息种类及保存期限、行使权利的方式和程序。"),
            privacy("19", "第十九条", "法律或行政法规另有要求的除外，保存时间以实现处理目的所需的最短期限为准。"),
            privacy("28", "第二十八条", "敏感个人信息包括生物识别、医疗健康、金融账户、行踪轨迹等信息。处理须有特定目的和充分必要性，并采取严格保护措施。"),
            privacy("47", "第四十七条", "在处理目的已实现或不再必要、停止服务、保存期限届满等法定情形下应主动删除。法定期限未届满或删除技术上难以实现时，原则上只保留存储和必要的安全保护。")
    );

    private static Reference privacy(String id, String article, String text) {
        return new Reference("basis-pipl-" + id, "《个人信息保护法》" + article + "要点", text);
    }

    static ReviewBasis prepare(String packId, Mode mode, String raw) {
        if (Set.of(COMPANY, PRIVACY, JOURNEY, "information-security").contains(packId) && mode != Mode.MODEL) {
            throw ApiFailure.badRequest("此审查包需要使用 AI 审查。");
        }
        String text = raw == null ? "" : raw.strip();
        if (text.length() > TEXT_LIMIT) throw ApiFailure.tooLarge("审查依据最多支持 3000 个字符。");
        if (COMPANY.equals(packId)) {
            if (text.length() < 10) throw ApiFailure.badRequest("请提供至少 10 个字的公司目标、原则或限制。");
            return new ReviewBasis(text, List.of(new Reference(COMPANY_SOURCE, "本次提交的公司依据", text)), "");
        }
        if (PRIVACY.equals(packId)) return new ReviewBasis(text, PRIVACY_REFERENCES, text);
        if (!text.isEmpty()) throw ApiFailure.badRequest("当前审查包无需附加审查依据。");
        return new ReviewBasis("", List.of(), "");
    }

    static Set<String> sourcesFor(String ruleId) {
        return switch (ruleId) {
            case "B-01", "B-02" -> Set.of(COMPANY_SOURCE);
            case "L-01" -> Set.of("basis-pipl-6", "basis-pipl-28");
            case "L-02" -> Set.of("basis-pipl-17");
            case "L-03" -> Set.of("basis-pipl-19", "basis-pipl-47");
            default -> Set.of();
        };
    }

    Reference reference(String id) {
        return references.stream().filter(reference -> reference.id().equals(id)).findFirst().orElse(null);
    }
}
