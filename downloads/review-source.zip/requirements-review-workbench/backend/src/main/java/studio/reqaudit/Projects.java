package studio.reqaudit;

import org.springframework.core.io.ClassPathResource;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Transactional;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import static studio.reqaudit.Domain.Mode.DEMO;

@Service
class Projects {
    enum ProjectRole {
        OWNER, EDITOR, REVIEWER, VIEWER;

        boolean mayEdit() { return this == OWNER || this == EDITOR; }
        boolean mayReview() { return this == OWNER || this == REVIEWER; }
        boolean mayStartReview() { return this != VIEWER; }
    }

    record Project(String id, String name, String description, String createdAt, String updatedAt, ProjectRole role) {}
    record ProjectInput(String name, String description) {}
    record Member(String userId, String username, String displayName, ProjectRole role) {}
    record MemberInput(String username, ProjectRole role) {}
    record MemberInvitation(String username) {}

    private static final RowMapper<Project> PROJECT = (row, index) -> new Project(
            row.getString(1), row.getString(2), row.getString(3), row.getString(4), row.getString(5),
            ProjectRole.valueOf(row.getString(6)));
    private static final RowMapper<Member> MEMBER = (row, index) -> new Member(
            row.getString(1), row.getString(2), row.getString(3), ProjectRole.valueOf(row.getString(4)));
    private static final String PROJECT_ACCESS = """
            SELECT p.id, p.name, p.description, p.created_at, p.updated_at,
                   CASE WHEN p.owner_id = ? THEN 'OWNER' ELSE m.project_role END AS project_role
            FROM studio_project p
            LEFT JOIN project_member m ON p.id = m.project_id AND m.account_id = ?
            """;
    private static final String HAS_ACCESS = "(p.owner_id = ? OR m.account_id IS NOT NULL) ";

    private final JdbcTemplate jdbc;
    private final AuditRepository docs;
    private final ReviewService reviews;
    private final EnterpriseDemo enterprise;

    Projects(JdbcTemplate jdbc, AuditRepository docs, ReviewService reviews, EnterpriseDemo enterprise) {
        this.jdbc = jdbc;
        this.docs = docs;
        this.reviews = reviews;
        this.enterprise = enterprise;
    }

    List<Project> list(String accountId) {
        return jdbc.query(PROJECT_ACCESS + "WHERE " + HAS_ACCESS + "ORDER BY p.updated_at DESC, p.id",
                PROJECT, accountId, accountId, accountId);
    }

    Project accessible(String accountId, String id) {
        return requireAccess(accountId, "", "p.id = ?", id, "项目不存在或无权访问。");
    }

    Project selected(String accountId, String id) {
        if (id != null && !id.isBlank()) return accessible(accountId, id);
        return list(accountId).stream().filter(project -> project.role().mayEdit()).findFirst()
                .orElseThrow(() -> ApiFailure.badRequest("请先新建或打开可编辑的项目，再添加需求文档。"));
    }

    Project create(String accountId, ProjectInput input) {
        return insert(AuditRepository.id(), accountId, input);
    }

    Project update(String accountId, String id, ProjectInput input) {
        requireOwner(accountId, id);
        String name = ApiFailure.requireText(input.name(), "项目名称", 120).strip();
        String description = ApiFailure.optionalText(input.description(), "项目说明", 2000);
        if (jdbc.update("""
                UPDATE studio_project SET name = ?, description = ?, updated_at = ?
                WHERE id = ? AND owner_id = ?
                """, name, description, Instant.now().toString(), id, accountId) == 0) {
            throw ApiFailure.notFound("项目不存在或无权访问。");
        }
        return accessible(accountId, id);
    }

    @Transactional
    Project sample(String accountId) {
        String id = UUID.nameUUIDFromBytes(("sample:" + accountId).getBytes(StandardCharsets.UTF_8)).toString();
        var existing = list(accountId).stream().filter(project -> id.equals(project.id())).findFirst();
        if (existing.isPresent()) return existing.get();
        var resource = new ClassPathResource("enterprise-sample.txt");
        boolean enterpriseAvailable = resource.exists();
        String sample = getSample(resource, enterpriseAvailable);
        String name = enterpriseAvailable ? "企业 IT 服务台与变更管理" : AuditCatalog.SAMPLE_TITLE;
        Project project;
        try {
            project = insert(id, accountId, new ProjectInput(name,
                    "开放评审用样例，演示范围确认、原文证据、人工复核及版本复查。"));
        } catch (DuplicateKeyException ex) {
            throw ApiFailure.conflict("示例项目正在创建，请刷新后查看。");
        }
        var document = docs.addDocument(AuditRepository.id(), id, name + " · 需求规格说明书", sample, Map.of());
        var first = document.versions().get(0);
        reviews.run(document.id(), first.id(), "baseline", DEMO,
                enterpriseAvailable ? enterprise.targets(first) : null);
        var revision = new ClassPathResource("enterprise-sample-v2.txt");
        if (enterpriseAvailable && revision.exists()) {
            var updated = docs.addVersion(document.id(), getSample(revision, true)).versions().get(0);
            reviews.run(document.id(), updated.id(), "baseline", DEMO, enterprise.targets(updated));
        }
        return project;
    }

    Project forDocument(String accountId, String documentId) {
        return requireAccess(accountId, "JOIN document_scope s ON p.id = s.project_id ",
                "s.document_id = ?", documentId, "文档不存在或无权访问。");
    }

    Project forRun(String accountId, String runId) {
        return requireAccess(accountId, """
                JOIN document_scope s ON p.id = s.project_id
                JOIN review_run r ON r.document_id = s.document_id
                """, "r.id = ?", runId, "审查记录不存在或无权访问。");
    }

    List<Member> members(String accountId, String projectId) {
        accessible(accountId, projectId);
        return projectMembers(projectId);
    }

    @Transactional(isolation = Isolation.READ_COMMITTED)
    List<Member> grant(String accountId, String projectId, MemberInput input) {
        return saveMember(accountId, projectId, input.username(), input.role(), true);
    }

    @Transactional(isolation = Isolation.READ_COMMITTED)
    List<Member> invite(String accountId, String projectId, MemberInvitation input) {
        return saveMember(accountId, projectId, input.username(), ProjectRole.VIEWER, false);
    }

    private List<Member> saveMember(String accountId, String projectId, String usernameInput, ProjectRole role,
                                    boolean updateExisting) {
        requireOwner(accountId, projectId);
        lock(projectId);
        if (role == null || role == ProjectRole.OWNER) {
            throw ApiFailure.badRequest("请选择编辑者、评审者或查看者。");
        }
        String username = Accounts.normalizedUsername(usernameInput);
        String grantee = jdbc.query("SELECT id FROM studio_account WHERE username = ?",
                        (row, index) -> row.getString(1), username).stream().findFirst()
                .orElseThrow(() -> ApiFailure.notFound("未找到该账号，请核对账号名后重试。"));
        if (grantee.equals(accountId)) throw ApiFailure.badRequest("项目拥有者的权限无需设置。");
        String previous = jdbc.query("SELECT project_role FROM project_member WHERE project_id = ? AND account_id = ?",
                        (row, index) -> row.getString(1), projectId, grantee).stream().findFirst().orElse(null);
        if (previous == null) {
            jdbc.update("INSERT INTO project_member (project_id, account_id, project_role) VALUES (?, ?, ?)",
                    projectId, grantee, role.name());
        } else if (updateExisting && !previous.equals(role.name())) {
            jdbc.update("UPDATE project_member SET project_role = ? WHERE project_id = ? AND account_id = ?",
                    role.name(), projectId, grantee);
        }
        return projectMembers(projectId);
    }

    @Transactional
    List<Member> revoke(String accountId, String projectId, String memberId) {
        requireOwner(accountId, projectId);
        lock(projectId);
        if (memberId.equals(accountId)) throw ApiFailure.badRequest("项目拥有者无法被移除。");
        jdbc.update("DELETE FROM project_member WHERE project_id = ? AND account_id = ?", projectId, memberId);
        return projectMembers(projectId);
    }

    Member assignable(String projectId, String assigneeId) {
        return projectMembers(projectId).stream().filter(member -> member.userId().equals(assigneeId)
                        && member.role() != ProjectRole.VIEWER).findFirst()
                .orElseThrow(() -> ApiFailure.badRequest("负责人须是当前项目的拥有者、编辑者或评审者。"));
    }

    void lock(String projectId) {
        jdbc.query("SELECT id FROM studio_project WHERE id = ? FOR UPDATE",
                (row, index) -> row.getString(1), projectId).stream().findFirst()
                .orElseThrow(() -> ApiFailure.notFound("项目不存在。"));
    }

    private Project requireAccess(String accountId, String joins, String selector, String id, String message) {
        return jdbc.query(PROJECT_ACCESS + joins + "WHERE " + HAS_ACCESS + "AND " + selector,
                        PROJECT, accountId, accountId, accountId, id).stream().findFirst()
                .orElseThrow(() -> ApiFailure.notFound(message));
    }

    private void requireOwner(String accountId, String projectId) {
        if (accessible(accountId, projectId).role() != ProjectRole.OWNER) {
            throw ApiFailure.forbidden("只有项目拥有者可更改项目资料或成员权限。");
        }
    }

    private List<Member> projectMembers(String projectId) {
        return jdbc.query("""
                SELECT a.id AS account_id, a.username, a.display_name, 'OWNER' AS project_role
                FROM studio_project p JOIN studio_account a ON p.owner_id = a.id WHERE p.id = ?
                UNION ALL
                SELECT a.id AS account_id, a.username, a.display_name, m.project_role
                FROM project_member m JOIN studio_account a ON m.account_id = a.id WHERE m.project_id = ?
                ORDER BY username
                """, MEMBER, projectId, projectId);
    }

    private Project insert(String id, String accountId, ProjectInput input) {
        String name = ApiFailure.requireText(input.name(), "项目名称", 120).strip();
        String description = ApiFailure.optionalText(input.description(), "项目说明", 2000);
        String now = Instant.now().toString();
        jdbc.update("""
                INSERT INTO studio_project (id, owner_id, name, description, created_at, updated_at)
                VALUES (?, ?, ?, ?, ?, ?)
                """, id, accountId, name, description, now, now);
        return new Project(id, name, description, now, now, ProjectRole.OWNER);
    }

    private static String getSample(ClassPathResource resource, boolean enterprise) {
        if (!enterprise) return AuditCatalog.SAMPLE;
        try {
            return resource.getContentAsString(StandardCharsets.UTF_8);
        } catch (IOException ex) {
            throw new IllegalStateException("无法加载示例需求文档。", ex);
        }
    }
}
