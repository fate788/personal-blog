package studio.reqaudit;

import com.fasterxml.jackson.databind.JsonNode;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.time.Duration;
import java.time.Instant;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.*;
import java.util.function.Consumer;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static studio.reqaudit.Domain.*;
import static studio.reqaudit.Domain.FindingStatus.*;
import static studio.reqaudit.Domain.ModelProfile.PRIMARY;
import static studio.reqaudit.ModelGateway.ProviderFailure;

@Service
class ReviewService {
    // Advance this revision when changing prompts, planning, source validation or inference settings.
    private static final int REVIEW_ENGINE_REVISION = 3;
    private static final int MAX_RECOVERY_CALLS = 12;
    private static final Set<String> HARD_MODEL_STOPS = Set.of("MODEL_BILLING", "MODEL_ACCESS", "MODEL_RATE_LIMIT",
            "EGRESS_BLOCKED", "TIME_BUDGET");
    private static final Set<String> RECOVERABLE_OUTPUT = Set.of("FORMAT_ERROR", "OUTPUT_TRUNCATED");
    private final AuditCatalog catalog;
    private final AuditRepository repository;
    private final ProjectRules projectRules;
    private final ReviewPlanner planner;
    private final ModelGateway model;
    private final DemoReview demo;
    private final EnterpriseDemo enterprise;
    private final long maxElapsedNanos;

    ReviewService(AuditCatalog catalog, AuditRepository repository, ProjectRules projectRules,
                  ReviewPlanner planner, ModelGateway model, DemoReview demo, EnterpriseDemo enterprise,
                  @Value("${review.audit.max-elapsed-seconds}") int maxElapsedSeconds) {
        this.catalog = catalog;
        this.repository = repository;
        this.projectRules = projectRules;
        this.planner = planner;
        this.model = model;
        this.demo = demo;
        this.enterprise = enterprise;
        if (maxElapsedSeconds < 2 || maxElapsedSeconds > 7_200) {
            throw new IllegalArgumentException("REVIEW_AUDIT_MAX_ELAPSED_SECONDS 需设为 2 至 7200。");
        }
        maxElapsedNanos = Duration.ofSeconds(maxElapsedSeconds).toNanos();
    }

    Run run(String documentId, String versionId, String packId, Mode mode) {
        return run(documentId, versionId, packId, mode, null);
    }

    Run run(String documentId, String versionId, String packId, Mode mode, List<String> itemIds) {
        return run(documentId, versionId, packId, mode, itemIds, null);
    }

    Run run(String documentId, String versionId, String packId, Mode mode, List<String> itemIds, ModelProfile profile) {
        return run(documentId, versionId, catalog.requirePack(packId), mode, itemIds, profile, null, null);
    }

    Run run(String documentId, String versionId, Pack pack, Mode mode, List<String> itemIds, ModelProfile profile,
            String reviewBasis, ExecutionStrategy strategy) {
        Run result = evaluate(AuditRepository.id(), documentId, versionId, pack, Instant.now().toString(), mode,
                itemIds, profile, null, List.of(), reviewBasis, strategy);
        repository.addRun(result);
        return result;
    }

    String executionRevision() {
        return REVIEW_ENGINE_REVISION + "/" + planner.batchLimit() + "/" + maxElapsedNanos;
    }

    record Prepared(Run run, String fingerprint, String executionRevision) {}

    Prepared prepare(String documentId, String versionId, Pack pack, Mode mode, List<String> itemIds,
                     ModelProfile requested, String reviewBasis, ExecutionStrategy strategy) {
        Version version = repository.requireVersion(documentId, versionId);
        ReviewBasis basis = prepareBasis(pack, mode, reviewBasis);
        var ids = selectItems(version, itemIds);
        boolean referenceOnly = ruleChecksOnly(mode, strategy, version);
        var plan = plan(version, ids, mode, false, referenceOnly);
        ModelProfile profile = selectedProfile(mode, requested);
        var coverage = coverage(ids, pack, plan, new ReviewProgress());
        String name = mode == Mode.MODEL ? model.model(profile) : referenceOnly ? "本地规则检查" : "样例演示";
        var rules = projectRules.snapshot(documentId, version);
        var run = new Run(AuditRepository.id(), documentId, versionId, pack.id(), Instant.now().toString(), mode,
                RunStatus.QUEUED, coverage, 0, usage(List.of()), List.of(), List.of(),
                rules.warnings(), pack.version(), name, ids,
                profile, List.of(), mode == Mode.MODEL ? model.revision(profile) : null, basis.submitted(), pack, strategy);
        if (mode != Mode.MODEL) return new Prepared(run, null, null);
        // A version is immutable and owns the source anchors, finding IDs and human decisions on its runs.
        String executionRevision = executionRevision();
        var keyParts = new ArrayList<>(List.of(executionRevision, documentId, versionId, pack, ids, mode,
                profile, run.modelConfigRevision(), basis, rules.enabledRevisions()));
        if (strategy != null) keyParts.add(strategy);
        String inputs = repository.write(keyParts);
        try {
            String fingerprint = HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256")
                    .digest(inputs.getBytes(StandardCharsets.UTF_8)));
            return new Prepared(run, fingerprint, executionRevision);
        } catch (NoSuchAlgorithmException failure) {
            throw new IllegalStateException("无法生成审查条件指纹。", failure);
        }
    }

    Run evaluate(Run job, Consumer<Run> progress) {
        ModelProfile profile = selectedProfile(job.mode(), job.profile());
        if (job.mode() == Mode.MODEL && (!model.configured(profile) || !job.model().equals(model.model(profile))
                || job.modelConfigRevision() != null && !job.modelConfigRevision().equals(model.revision(profile)))) {
            return job.withStatus(RunStatus.FAILED, List.of(new Diagnostic("MODEL_CONFIG_CHANGED",
                    "排队后模型配置已改变。请核对连接后重新提交。")));
        }
        Pack pack = job.packSnapshot() == null ? catalog.requirePack(job.packId()) : job.packSnapshot();
        if (!job.packVersion().equals(pack.version())) {
            return job.withStatus(RunStatus.FAILED, List.of(new Diagnostic("PACK_VERSION_CHANGED",
                    "排队后的审查包版本已改变。请选择新版审查包并重新提交。")));
        }
        return evaluate(job.id(), job.documentId(), job.versionId(), pack, job.createdAt(), job.mode(),
                job.targetItemIds(), profile, progress, job.ruleWarnings(), job.reviewBasis(), job.executionStrategy());
    }

    private static ReviewBasis prepareBasis(Pack pack, Mode mode, String text) {
        if (pack.basePackId() != null && mode != Mode.MODEL) {
            throw ApiFailure.badRequest("自定义审查包需要使用 AI 审查。");
        }
        return ReviewBasis.prepare(pack.basisPackId(), mode, text);
    }

    private Run evaluate(String id, String documentId, String versionId, Pack pack, String timestamp, Mode mode,
                         List<String> itemIds, ModelProfile requested, Consumer<Run> progress, List<RuleWarning> existingWarnings,
                         String reviewBasis, ExecutionStrategy strategy) {
        Version version = repository.requireVersion(documentId, versionId);
        ReviewBasis basis = prepareBasis(pack, mode, reviewBasis);
        var targetIds = selectItems(version, itemIds);
        long started = System.nanoTime();
        boolean referenceOnly = ruleChecksOnly(mode, strategy, version);
        ReviewPlanner.Plan plan = plan(version, targetIds, mode, true, referenceOnly);
        ModelProfile profile = selectedProfile(mode, requested);
        String modelName = mode == Mode.MODEL ? model.model(profile) : referenceOnly ? "本地规则检查" : "样例演示";
        String revision = profile == null ? null : model.revision(profile);
        var findings = new ArrayList<Finding>();
        var diagnostics = new ArrayList<Diagnostic>();
        var warnings = progress == null ? projectRules.check(documentId, version) : existingWarnings;
        var conflicts = new HashSet<List<String>>();
        var traces = new ArrayList<ModelTrace>();
        var state = new ReviewProgress();
        int consecutiveTransportErrors = 0;
        int recoveryCalls = 0;
        long deadline = started + maxElapsedNanos;
        for (var batch : plan.batches()) {
            if (System.nanoTime() - started >= maxElapsedNanos) {
                diagnostics.add(new Diagnostic("TIME_BUDGET", "本次运行已达到任务时长预算。可对未核验条款发起新任务。"));
                break;
            }
            var checked = new LinkedHashMap<Check, FindingStatus>();
            String failure = "";
            if (mode == Mode.MODEL) {
                var requestedChecks = batchChecks(batch, pack);
                int firstTrace = traces.size();
                failure = modelAttempt(batch, pack, basis, profile, deadline, requestedChecks, 0,
                        checked, diagnostics, findings, conflicts, traces);
                var missing = requestedChecks.stream().filter(check -> !checked.containsKey(check)).toList();
                if (!missing.isEmpty() && (failure.isEmpty() || RECOVERABLE_OUTPUT.contains(failure))
                        && recoveryCalls < MAX_RECOVERY_CALLS && System.nanoTime() < deadline) {
                    diagnostics.add(new Diagnostic("BATCH_RECHECK", "批次 " + batch.number()
                            + " 正在分组补查 " + missing.size() + " 个未核验的检查项。"));
                    int groupSize = (missing.size() + 1) / 2;
                    for (int start = 0; start < missing.size() && recoveryCalls < MAX_RECOVERY_CALLS
                            && System.nanoTime() < deadline; start += groupSize) {
                        List<Check> group = missing.subList(start, Math.min(start + groupSize, missing.size()));
                        var recovery = recoveryBatch(batch, group);
                        recoveryCalls++;
                        failure = modelAttempt(recovery, pack, basis, profile, deadline, group, traces.size() - firstTrace,
                                checked, diagnostics, findings, conflicts, traces);
                        if (HARD_MODEL_STOPS.contains(failure)) break;
                    }
                }
                if ("MODEL_ERROR".equals(failure) || "MODEL_TIMEOUT".equals(failure)) {
                    if (++consecutiveTransportErrors >= 3) {
                        failure = "MODEL_ACCESS";
                        diagnostics.add(new Diagnostic(failure, "连续三个批次调用失败。后续调用已暂停，已核验的结果仍可复核。"));
                    }
                } else {
                    consecutiveTransportErrors = 0;
                }
            } else {
                validate(batch, pack, basis, demo.evaluate(batch, pack, version), batchChecks(batch, pack), checked,
                        diagnostics, findings, conflicts, false);
            }
            state.add(batch, pack, checked);
            int uncovered = batch.primary().size() * pack.rules().size() - checked.size();
            if (uncovered > 0 && (failure.isEmpty() || !checked.isEmpty())) {
                diagnostics.add(new Diagnostic("COVERAGE_GAP", "批次 " + batch.number() + " 有 "
                        + uncovered + " 个审核项未获得有效判定。"));
            }
            if (progress != null && batch.number() < plan.batches().size()) {
                var reported = SqlExampleChecks.group(findings, warnings, mode == Mode.MODEL && pack.id().equals("general"), strategy);
                progress.accept(new Run(id, documentId, versionId, pack.id(), timestamp, mode, RunStatus.RUNNING,
                        coverage(targetIds, pack, plan, state), elapsed(started), usage(traces), reported.findings(),
                        List.copyOf(diagnostics), reported.warnings(), pack.version(), modelName, targetIds, profile,
                        List.copyOf(traces), revision, basis.submitted(), pack, strategy));
            }
            if (HARD_MODEL_STOPS.contains(failure)) break;
        }
        if (!plan.oversizedItemIds().isEmpty()) {
            diagnostics.add(new Diagnostic("ITEM_TOO_LONG", "有 " + plan.oversizedItemIds().size()
                    + " 个条目超出单条字符上限。请拆分条款后重新审查。"));
        }
        if (!plan.overBudgetItemIds().isEmpty()) {
            diagnostics.add(new Diagnostic("BATCH_BUDGET", "另有 " + plan.overBudgetItemIds().size()
                    + " 个条目已计划但超出本次批次数预算。可仅提交这些条款继续审查。"));
        }
        if (mode == Mode.DEMO) {
            diagnostics.add(new Diagnostic("DEMO_SCOPE", strategy == ExecutionStrategy.LOCAL_ONLY
                    ? "已对整份文档执行通用本地检查和已启用的项目规则。"
                    : referenceOnly
                    ? "已执行通用本地检查和已启用的项目规则。语义审核项待核验。"
                    : "当前检查使用已标注样例，未调用 AI 服务。"));
        }
        Scope coverage = coverage(targetIds, pack, plan, state);
        RunStatus status = strategy == ExecutionStrategy.LOCAL_ONLY ? RunStatus.COMPLETED
                : referenceOnly ? RunStatus.PARTIAL : coverage.coveredChecks() == 0 ? RunStatus.FAILED
                : coverage.omittedItemIds().isEmpty() ? RunStatus.COMPLETED : RunStatus.PARTIAL;
        var reported = SqlExampleChecks.group(findings, warnings, mode == Mode.MODEL && pack.id().equals("general"), strategy);
        if (reported.merged() > 0) diagnostics.add(new Diagnostic("MATCHING_SQL_EVIDENCE",
                "查询和结果表头的相同函数名差异已合并，原文共核对 " + reported.merged() + " 条重复提示。"));
        var sorted = reported.findings().stream().sorted(Comparator.comparing(Finding::status)
                .thenComparing(Finding::severity).thenComparing(Finding::ruleId)).toList();
        return new Run(id, documentId, versionId, pack.id(), timestamp, mode, status,
                coverage, elapsed(started), usage(traces), sorted, List.copyOf(diagnostics), reported.warnings(), pack.version(),
                modelName, targetIds, profile, List.copyOf(traces), revision, basis.submitted(), pack, strategy);
    }

    private String modelAttempt(ReviewPlanner.Batch batch, Pack pack, ReviewBasis basis, ModelProfile profile, long deadline,
                                List<Check> requests, int previousAttempts, Map<Check, FindingStatus> checked,
                                List<Diagnostic> diagnostics, List<Finding> findings, Set<List<String>> conflicts,
                                List<ModelTrace> traces) {
        var expected = new LinkedHashMap<String, List<String>>();
        for (Check request : requests) {
            expected.computeIfAbsent(request.itemId(), ignored -> new ArrayList<>()).add(request.ruleId());
        }
        try {
            var response = model.review(batch, pack, basis, profile, deadline, expected, previousAttempts);
            traces.addAll(response.traces());
            var answers = parse(response.data(), batch, pack, diagnostics);
            validate(batch, pack, basis, answers, requests, checked, diagnostics, findings, conflicts, true);
            return "";
        } catch (ProviderFailure ex) {
            traces.addAll(ex.traces());
            diagnostics.add(new Diagnostic(ex.type(), "批次 " + batch.number() + "：" + ex.getMessage()));
            return ex.type();
        }
    }

    private static List<Check> batchChecks(ReviewPlanner.Batch batch, Pack pack) {
        return batch.primary().stream().flatMap(item -> pack.rules().stream()
                .map(rule -> new Check(item.id(), rule.id()))).toList();
    }

    private static ReviewPlanner.Batch recoveryBatch(ReviewPlanner.Batch batch, List<Check> group) {
        var ids = group.stream().map(Check::itemId).collect(Collectors.toSet());
        var primary = batch.primary().stream().filter(item -> ids.contains(item.id())).toList();
        var context = Stream.concat(batch.primary().stream().filter(item -> !ids.contains(item.id())),
                batch.context().stream()).toList();
        return new ReviewPlanner.Batch(batch.number(), primary, context, batch.sourceLines());
    }

    private ReviewPlanner.Plan plan(Version version, List<String> targetIds, Mode mode, boolean addContext, boolean referenceOnly) {
        if (referenceOnly) {
            return new ReviewPlanner.Plan(List.of(), 0, planner.batchLimit(), List.of(), List.of());
        }
        var plan = planner.plan(version.items(), Set.copyOf(targetIds),
                mode == Mode.DEMO && addContext ? enterprise.related(version) : Map.of(), addContext);
        return mode == Mode.MODEL && addContext ? SourceNeighborhood.include(version, plan) : plan;
    }

    private boolean ruleChecksOnly(Mode mode, ExecutionStrategy strategy, Version version) {
        return mode == Mode.DEMO && (strategy == ExecutionStrategy.LOCAL_ONLY ||
                !(version.text().strip().equals(AuditCatalog.SAMPLE) || enterprise.isKnownText(version)));
    }

    private static ModelProfile selectedProfile(Mode mode, ModelProfile requested) {
        return mode == Mode.MODEL ? requested == null ? PRIMARY : requested : null;
    }

    private static long elapsed(long started) {
        return (System.nanoTime() - started) / 1_000_000L;
    }

    private static Scope coverage(List<String> targets, Pack pack, ReviewPlanner.Plan plan, ReviewProgress state) {
        int checks = targets.size() * pack.rules().size();
        int recorded = state.substantive + state.insufficient + state.notApplicable;
        return new Scope(targets.size(), checks, state.details.size(), List.copyOf(state.fullItems),
                targets.stream().filter(id -> !state.fullItems.contains(id)).toList(), recorded,
                List.copyOf(state.details), state.substantive, state.insufficient, state.notApplicable, checks - recorded,
                plan.plannedBatches(), plan.batchLimit(), plan.overBudgetItemIds(), plan.oversizedItemIds(),
                List.copyOf(state.analyzedItems));
    }

    private static Usage usage(List<ModelTrace> traces) {
        int[] counts = new int[4];
        boolean[] known = new boolean[4];
        boolean fullyReported = true;
        int calls = 0;
        for (ModelTrace trace : traces) {
            if (Boolean.FALSE.equals(trace.outbound())) continue;
            calls++;
            Integer[] values = {trace.inputTokens(), trace.outputTokens(), trace.cachedInputTokens(), trace.reasoningTokens()};
            if (values[0] == null || values[1] == null) fullyReported = false;
            for (int index = 0; index < values.length; index++) {
                if (values[index] != null && Integer.MAX_VALUE - counts[index] >= values[index]) {
                    known[index] = true;
                    counts[index] += values[index];
                }
            }
        }
        return new Usage(calls, known[0] || calls == 0 ? counts[0] : null,
                known[1] || calls == 0 ? counts[1] : null, known[2] ? counts[2] : null,
                known[3] ? counts[3] : null, fullyReported);
    }

    private static final class ReviewProgress {
        private final List<BatchScope> details = new ArrayList<>();
        private final Set<String> fullItems = new LinkedHashSet<>();
        private final Set<String> analyzedItems = new LinkedHashSet<>();
        private int substantive;
        private int insufficient;
        private int notApplicable;

        void add(ReviewPlanner.Batch batch, Pack pack, Map<Check, FindingStatus> checked) {
            List<String> ids = batch.primary().stream().map(Item::id).toList();
            for (String id : ids) {
                if (checked.keySet().stream().filter(check -> check.itemId().equals(id)).count() == pack.rules().size()) {
                    fullItems.add(id);
                }
            }
            int analyzed = 0;
            for (var entry : checked.entrySet()) {
                switch (entry.getValue()) {
                    case INSUFFICIENT -> insufficient++;
                    case NOT_APPLICABLE -> notApplicable++;
                    case PASS, ISSUE -> {
                        analyzedItems.add(entry.getKey().itemId());
                        analyzed++;
                    }
                }
            }
            substantive += analyzed;
            details.add(new BatchScope(batch.number(), ids, batch.context().stream().map(Item::id).toList(),
                    checked.size() == ids.size() * pack.rules().size(), checked.size(), analyzed));
        }
    }

    private static List<String> selectItems(Version version, List<String> requested) {
        List<String> available = version.items().stream().map(Item::id).toList();
        if (requested == null || requested.isEmpty()) return available;
        var selected = new HashSet<>(requested);
        if (selected.contains(null) || !new HashSet<>(available).containsAll(selected)) {
            throw ApiFailure.badRequest("所选审查条目不存在于该文档版本，请刷新后重新选择。");
        }
        return available.stream().filter(selected::contains).toList();
    }

    private record Check(String itemId, String ruleId) {}

    private void validate(ReviewPlanner.Batch batch, Pack pack, ReviewBasis basis, List<Assessment> answers, List<Check> requests,
                          Map<Check, FindingStatus> checked, List<Diagnostic> diagnostics, List<Finding> findings,
                          Set<List<String>> conflicts, boolean modelRun) {
        Map<String, Item> byId = Stream.of(batch.primary(), batch.context(), batch.sourceLines()).flatMap(List::stream)
                .collect(Collectors.toMap(Item::id, item -> item));
        var expected = Set.copyOf(requests);
        var rules = pack.rules().stream().collect(Collectors.toMap(Rule::id, rule -> rule));
        for (Assessment assessment : answers) {
            try {
                Check check = new Check(assessment.itemId(), assessment.ruleId());
                Rule rule = rules.get(check.ruleId());
                if (rule == null || !expected.contains(check) || checked.containsKey(check)) {
                    throw new ProviderFailure("FORMAT_ERROR", "审核项或主条目不属于当前批次，或判断重复。");
                }
                Set<String> basisIds = check.ruleId().startsWith("C-")
                        ? basis.references().stream().map(ReviewBasis.Reference::id).collect(Collectors.toUnmodifiableSet())
                        : ReviewBasis.sourcesFor(check.ruleId());
                List<Evidence> sources = validateEvidence(assessment, byId, basis, basisIds);
                if ((assessment.status() == ISSUE) && (sources.isEmpty()
                        || sources.stream().noneMatch(source -> source.itemId().equals(check.itemId())))) {
                    throw new ProviderFailure("INVALID_EVIDENCE", "疑点没有当前主条目的原文证据。");
                }
                if (assessment.status() == ISSUE && check.ruleId().equals(AuditCatalog.CONFLICT.id())
                        && sources.stream().map(Evidence::itemId).distinct().count() < 2) {
                    throw new ProviderFailure("INVALID_EVIDENCE", "跨条款冲突缺少至少两个不同条目的原文证据。");
                }
                if (assessment.status() == ISSUE && !basisIds.isEmpty()
                        && (assessment.validationKind() != ValidationKind.DOCUMENT
                        || sources.stream().noneMatch(source -> basisIds.contains(source.itemId())))) {
                    throw new ProviderFailure("INVALID_EVIDENCE", "专项问题必须同时引用送审原文和该审核项对应的依据。");
                }
                var result = SemanticValidation.verify(assessment, byId, sources, modelRun);
                if (result.diagnostic() != null) {
                    String detail = result.status() == PASS ? "候选的矛盾或计算差异未成立。" : result.reason();
                    diagnostics.add(new Diagnostic(result.diagnostic(), "批次 " + batch.number() + " · "
                            + byId.get(check.itemId()).code() + " · " + detail));
                }
                checked.put(check, result.status());
                if (result.status() == PASS) {
                    continue;
                }
                if (result.status() == ISSUE && result.kind() == ValidationKind.CONFLICT) {
                    List<String> pair = result.pair().isEmpty()
                            ? sources.stream().map(Evidence::itemId).distinct().sorted().toList() : result.pair();
                    if (!conflicts.add(pair)) {
                        diagnostics.add(new Diagnostic("DUPLICATE_CONFLICT", "同一对约束的冲突已登记，保留首个疑点。"));
                        continue;
                    }
                }
                Severity severity = result.status() == INSUFFICIENT && assessment.status() == ISSUE
                        ? Severity.LOW : assessment.severity();
                findings.add(new Finding(AuditRepository.id(), check.ruleId(), result.title(), rule.name(), severity,
                        result.status(), result.reason(), result.suggestion(), sources, Decision.PENDING, "", null,
                        check.itemId(), result.kind(), result.comparison()));
            } catch (ProviderFailure ex) {
                diagnostics.add(new Diagnostic(ex.type(), "批次 " + batch.number() + "：" + ex.getMessage()));
            }
        }
    }

    private List<Evidence> validateEvidence(Assessment assessment, Map<String, Item> allowed,
                                            ReviewBasis basis, Set<String> basisIds) {
        var result = new ArrayList<Evidence>();
        for (ProposedEvidence reference : assessment.evidence()) {
            Item item = allowed.get(reference.itemId());
            var basisReference = basisIds.contains(reference.itemId()) ? basis.reference(reference.itemId()) : null;
            String quote = reference.quote();
            String text = item != null ? item.text() : basisReference == null ? "" : basisReference.text();
            int start = text.indexOf(quote);
            if (start < 0 || quote.isBlank()) {
                throw new ProviderFailure("INVALID_EVIDENCE", "引用无法在当前版本和批次的原文中定位。");
            }
            if (text.indexOf(quote, start + 1) >= 0) {
                throw new ProviderFailure("INVALID_EVIDENCE", "引用在同一条目存在多个位置，请使用更完整的原文。");
            }
            result.add(item != null ? new Evidence(item.id(), item.code(), quote, item.line(), start, start + quote.length())
                    : new Evidence(basisReference.id(), basisReference.code(), quote, 0, start, start + quote.length()));
        }
        return result.stream().distinct().toList();
    }

    private List<Assessment> parse(JsonNode response, ReviewPlanner.Batch batch, Pack pack, List<Diagnostic> diagnostics) {
        JsonNode rows = response.path("assessments");
        if (!rows.isArray() || rows.isEmpty() || rows.size() > 100) {
            throw new ProviderFailure("FORMAT_ERROR", "模型未返回有效的 assessments 数组。");
        }
        Set<String> itemIds = batch.primary().stream().map(Item::id).collect(Collectors.toSet());
        Set<String> ruleIds = pack.rules().stream().map(Rule::id).collect(Collectors.toSet());
        var result = new ArrayList<Assessment>();
        int rowIndex = 0;
        for (JsonNode row : rows) {
            String location = "批次 " + batch.number() + " · 第 " + (++rowIndex) + " 行";
            try {
                String itemId = field(row.path("itemId"), "itemId", 30, false).strip();
                if (!itemIds.contains(itemId)) throw invalid("itemId", "超出当前批次的主条目");
                location += " · " + itemId;
                String ruleId = field(row.path("ruleId"), "ruleId", 30, false).strip();
                if (!ruleIds.contains(ruleId)) throw invalid("ruleId", "不属于本次审查包");
                location += " · " + ruleId;
                FindingStatus status = enumField(row.path("status"), "status", FindingStatus.class, null);
                Severity severity = enumField(row.path("severity"), "severity", Severity.class,
                        status == ISSUE ? null : Severity.LOW);
                ValidationKind kind = enumField(row.path("validationKind"), "validationKind", ValidationKind.class,
                        ValidationKind.DOCUMENT);
                boolean conflict = AuditCatalog.CONFLICT.id().equals(ruleId) || kind == ValidationKind.CONFLICT;
                String title = field(row.path("title"), "title", 200, status != ISSUE).strip();
                String reason = field(row.path("reason"), "reason", 2_000, status != ISSUE).strip();
                String suggestion = field(row.path("suggestion"), "suggestion", 2_000,
                        status != ISSUE || conflict || kind != ValidationKind.DOCUMENT).strip();
                if (title.isEmpty()) title = defaultTitle(status);
                if (reason.isEmpty()) reason = "模型未提供该判定的说明。";
                List<ProposedEvidence> evidence = references(row.path("evidence"), "evidence", 8,
                        ReviewPlanner.MAX_PRIMARY_CHARS);
                ConflictComparison comparison = null;
                String calculation = "";
                if (conflict && (status == ISSUE || status == INSUFFICIENT)) {
                    try {
                        comparison = parseComparison(row.path("comparison"));
                    } catch (ProviderFailure ex) {
                        diagnostics.add(new Diagnostic("CONFLICT_PROOF_FORMAT", location + " · " + ex.getMessage()));
                    }
                } else if (status == ISSUE && kind == ValidationKind.INTERNAL_CALCULATION) {
                    try {
                        calculation = field(row.path("calculationQuote"), "calculationQuote", 240, true);
                    } catch (ProviderFailure ex) {
                        diagnostics.add(new Diagnostic("CALCULATION_PROOF_FORMAT", location + " · " + ex.getMessage()));
                    }
                }
                result.add(new Assessment(itemId, ruleId, status, severity, title, reason, suggestion,
                        evidence, kind, comparison, calculation));
            } catch (ProviderFailure ex) {
                diagnostics.add(new Diagnostic("FORMAT_ERROR", location + " · " + ex.getMessage()));
            }
        }
        return result;
    }

    private static ConflictComparison parseComparison(JsonNode node) {
        if (node.isNull() || node.isMissingNode()) return null;
        if (!node.isObject()) throw invalid("comparison", "应为对象或 null");
        return new ConflictComparison(parseSide(node.path("left"), "comparison.left"),
                parseSide(node.path("right"), "comparison.right"),
                enumField(node.path("subject"), "comparison.subject", ScopeRelation.class, null),
                enumField(node.path("object"), "comparison.object", ScopeRelation.class, null),
                enumField(node.path("activity"), "comparison.activity", ScopeRelation.class, null),
                enumField(node.path("condition"), "comparison.condition", ScopeRelation.class, null),
                enumField(node.path("consequence"), "comparison.consequence", ConsequenceRelation.class, null),
                field(node.path("sharedScenario"), "comparison.sharedScenario", 500, false),
                references(node.path("scopeEvidence"), "comparison.scopeEvidence", 4, 800));
    }

    private static ComparisonSide parseSide(JsonNode node, String path) {
        if (!node.isObject()) throw invalid(path, "应为对象");
        return new ComparisonSide(field(node.path("itemId"), path + ".itemId", 30, false).strip(),
                field(node.path("subjectQuote"), path + ".subjectQuote", 400, false),
                field(node.path("objectQuote"), path + ".objectQuote", 400, false),
                field(node.path("activityQuote"), path + ".activityQuote", 400, false),
                field(node.path("conditionQuote"), path + ".conditionQuote", 500, true),
                field(node.path("consequenceQuote"), path + ".consequenceQuote", 800, false));
    }

    private static List<ProposedEvidence> references(JsonNode node, String path, int count, int quoteLimit) {
        if (node.isMissingNode() || node.isNull()) return List.of();
        if (!node.isArray() || node.size() > count) throw invalid(path, "应为不超过 " + count + " 项的数组");
        var references = new ArrayList<ProposedEvidence>();
        for (int index = 0; index < node.size(); index++) {
            var row = node.get(index);
            String entry = path + "[" + index + "]";
            references.add(new ProposedEvidence(field(row.path("itemId"), entry + ".itemId", 30, false).strip(),
                    field(row.path("quote"), entry + ".quote", quoteLimit, false)));
        }
        return List.copyOf(references);
    }

    private static String field(JsonNode node, String path, int limit, boolean optional) {
        if (optional && (node.isNull() || node.isMissingNode())) return "";
        if (!node.isTextual() || node.textValue().length() > limit || !optional && node.textValue().isBlank()) {
            throw invalid(path, optional ? "应为有效长度的字符串或 null" : "应为非空、有效长度的字符串");
        }
        return node.textValue();
    }

    private static <E extends Enum<E>> E enumField(JsonNode node, String path, Class<E> type, E fallback) {
        String value = field(node, path, 40, fallback != null).strip();
        if (value.isEmpty()) return fallback;
        try {
            return Enum.valueOf(type, value.toUpperCase(Locale.ROOT));
        } catch (IllegalArgumentException error) {
            throw invalid(path, "枚举值不受支持");
        }
    }

    private static String defaultTitle(FindingStatus status) {
        return switch (status) {
            case INSUFFICIENT -> "信息不足";
            case NOT_APPLICABLE -> "审核项不适用";
            case PASS -> "未报告疑点";
            case ISSUE -> "需求疑点";
        };
    }

    private static ProviderFailure invalid(String path, String detail) {
        return new ProviderFailure("FORMAT_ERROR", "字段 " + path + " " + detail + "。");
    }
}
