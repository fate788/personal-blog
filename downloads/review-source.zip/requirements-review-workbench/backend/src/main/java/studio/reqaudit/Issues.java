package studio.reqaudit;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

import static studio.reqaudit.Accounts.User;
import static studio.reqaudit.Domain.*;
import static studio.reqaudit.Projects.Project;
import static studio.reqaudit.Projects.ProjectRole;

@Service
class Issues {
    enum Status {
        OPEN, IN_PROGRESS, FIXED, VERIFIED, DISMISSED;

        boolean accepts(Status next) {
            if (this == next) return true;
            return switch (this) {
                case OPEN -> next == IN_PROGRESS || next == FIXED || next == DISMISSED;
                case IN_PROGRESS -> next == OPEN || next == FIXED || next == DISMISSED;
                case FIXED -> next == OPEN || next == IN_PROGRESS || next == VERIFIED || next == DISMISSED;
                case VERIFIED, DISMISSED -> next == OPEN;
            };
        }

        boolean recordsRepair() { return this == FIXED || this == VERIFIED; }
    }

    record Issue(String findingId, Status status, String assigneeId, String assigneeName,
                 String dueDate, String resolutionVersionId, String note, String updatedAt,
                 String updatedBy, String updatedByName, List<Event> history) {}
    record Event(Status fromStatus, Status toStatus, String assigneeId, String assigneeName, String dueDate,
                 String resolutionVersionId, String note, String actorId, String actorName, String createdAt) {}
    record Summary(String runId, String findingId, String title, String documentTitle, int versionNumber,
                   Status status, String assigneeId, String assigneeName, String dueDate, String updatedAt) {}
    private record SummaryRow(String runId, String findingId, String documentTitle, int versionNumber,
                              Status status, String assigneeId, String assigneeName, String dueDate, String updatedAt) {}
    private record EventRow(String findingId, Event event) {}
    private record Stored(String findingId, Status status, String assigneeId, String assigneeName, String dueDate,
                          String versionId, String note, String updatedAt, String actorId, String actorName,
                          int revision) {
        Issue view(List<Event> history) {
            return new Issue(findingId, status, assigneeId, assigneeName, dueDate, versionId, note,
                    updatedAt, actorId, actorName, history);
        }
    }

    private static final String ISSUE_VIEW = """
            SELECT i.finding_id, i.issue_status, i.assignee_id, assignee.display_name, i.due_date,
                   i.resolution_version_id, i.note, i.updated_at, i.updated_by, actor.display_name, i.revision_no
            FROM review_issue i LEFT JOIN studio_account assignee ON assignee.id = i.assignee_id
            JOIN studio_account actor ON actor.id = i.updated_by
            WHERE i.run_id = ?
            """;
    private static final RowMapper<Stored> ISSUE = (row, index) -> new Stored(
            row.getString(1), Status.valueOf(row.getString(2)), row.getString(3), row.getString(4),
            row.getString(5), row.getString(6), row.getString(7), row.getString(8), row.getString(9),
            row.getString(10), row.getInt(11));
    private static final String EVENT_VIEW = """
            SELECT finding_id, prior_status, new_status, assignee_id, assignee_name, due_date,
                   resolution_version_id, note, actor_id, actor_name, created_at
            FROM issue_event WHERE run_id = ?
            """;
    private static final RowMapper<EventRow> EVENT = (row, index) -> new EventRow(row.getString(1),
            new Event(Status.valueOf(row.getString(2)), Status.valueOf(row.getString(3)), row.getString(4),
                    row.getString(5), row.getString(6), row.getString(7), row.getString(8), row.getString(9),
                    row.getString(10), row.getString(11)));

    private final JdbcTemplate jdbc;
    private final AuditRepository audits;
    private final Projects projects;

    Issues(JdbcTemplate jdbc, AuditRepository audits, Projects projects) {
        this.jdbc = jdbc;
        this.audits = audits;
        this.projects = projects;
    }

    @Transactional(readOnly = true, isolation = Isolation.REPEATABLE_READ)
    List<Issue> list(User user, String runId) {
        projects.forRun(user.id(), runId);
        var events = jdbc.query(EVENT_VIEW + "ORDER BY finding_id, revision_no", EVENT, runId).stream()
                .collect(Collectors.groupingBy(EventRow::findingId,
                Collectors.mapping(EventRow::event, Collectors.toList())));
        return jdbc.query(ISSUE_VIEW + "ORDER BY i.updated_at DESC, i.finding_id", ISSUE, runId)
                .stream().map(issue -> issue.view(events.getOrDefault(issue.findingId(), List.of()))).toList();
    }

    @Transactional(readOnly = true, isolation = Isolation.REPEATABLE_READ)
    List<Summary> inbox(User user, String projectId) {
        projects.accessible(user.id(), projectId);
        var summaries = jdbc.query("""
                SELECT i.run_id, i.finding_id, d.title, v.version_no, i.issue_status,
                        i.assignee_id, a.display_name, i.due_date, i.updated_at
                FROM review_issue i
                JOIN review_run r ON r.id = i.run_id
                JOIN review_document d ON d.id = r.document_id
                JOIN document_version v ON v.id = r.version_id
                JOIN document_scope s ON s.document_id = r.document_id
                LEFT JOIN studio_account a ON a.id = i.assignee_id
                WHERE s.project_id = ?
                ORDER BY i.updated_at DESC, i.run_id, i.finding_id LIMIT 200
                """, (row, index) -> new SummaryRow(row.getString(1), row.getString(2), row.getString(3),
                        row.getInt(4), Status.valueOf(row.getString(5)), row.getString(6), row.getString(7),
                        row.getString(8), row.getString(9)), projectId);
        Map<String, Map<String, String>> titlesByRun = new HashMap<>();
        return summaries.stream().map(row -> {
            var titles = titlesByRun.computeIfAbsent(row.runId(), id -> audits.requireRun(id, false).findings()
                    .stream().collect(Collectors.toMap(Finding::id, Finding::title)));
            return new Summary(row.runId(), row.findingId(), titles.getOrDefault(row.findingId(), "审查问题"),
                    row.documentTitle(), row.versionNumber(), row.status(), row.assigneeId(), row.assigneeName(),
                    row.dueDate(), row.updatedAt());
        }).toList();
    }

    @Transactional(isolation = Isolation.READ_COMMITTED)
    Issue update(User user, String runId, String findingId, ObjectNode patch) {
        Project project = projects.forRun(user.id(), runId);
        projects.lock(project.id());
        project = projects.forRun(user.id(), runId);
        if (project.role() == ProjectRole.VIEWER) throw ApiFailure.forbidden("查看者不能处置问题。");

        Run run = audits.requireRun(runId, true);
        if (run.status() == RunStatus.QUEUED || run.status() == RunStatus.RUNNING) {
            throw ApiFailure.conflict("审查完成后才可记录问题处理。");
        }
        Finding finding = run.findings().stream().filter(candidate -> candidate.id().equals(findingId)).findFirst()
                .orElseThrow(() -> ApiFailure.notFound("该审查任务没有对应的问题。"));
        if (finding.status() != FindingStatus.ISSUE) throw ApiFailure.badRequest("只有疑点可以跟踪问题处理。");

        Stored previous = jdbc.query(ISSUE_VIEW + "AND i.finding_id = ?", ISSUE, runId, findingId)
                .stream().findFirst().orElse(new Stored(findingId, Status.OPEN, null, null, null, null,
                        "", null, null, null, 0));
        Status status = readStatus(patch, previous.status());
        String assignee = field(patch, "assigneeId", previous.assigneeId(), "负责人编号", 64);
        String deadline = field(patch, "dueDate", previous.dueDate(), "期限", 10);
        String versionId = field(patch, "resolutionVersionId", previous.versionId(), "修订版本编号", 64);
        String note = Objects.requireNonNullElse(field(patch, "note", previous.note(), "处理备注", 2000), "");

        if (project.role() == ProjectRole.EDITOR) {
            requireEditorAssigned(user.id(), previous, status, assignee, deadline);
        }
        validateStatus(finding, previous.status(), status, patch, note);
        validateDate(deadline);
        String assigneeName = previous.assigneeName();
        if (!Objects.equals(assignee, previous.assigneeId())) {
            assigneeName = assignee == null ? null : projects.assignable(project.id(), assignee).displayName();
        }
        if (status.recordsRepair()) {
            requireNewerVersion(run, versionId);
            if (previous.status() == Status.VERIFIED && !Objects.equals(versionId, previous.versionId())) {
                throw ApiFailure.conflict("已核验的问题须重新打开后，才可变更修订版本。");
            }
        } else if (patch.hasNonNull("resolutionVersionId") && versionId != null) {
            throw ApiFailure.badRequest("请在提交修订或核验时关联修订版本。");
        } else {
            versionId = null;
        }

        if (previous.revision() != 0 && status == previous.status() && Objects.equals(assignee, previous.assigneeId())
                && Objects.equals(deadline, previous.dueDate()) && Objects.equals(versionId, previous.versionId())
                && note.equals(previous.note())) {
            return previous.view(historyFor(runId, findingId));
        }
        var next = new Stored(findingId, status, assignee, assigneeName, deadline, versionId, note,
                Instant.now().toString(), user.id(), user.displayName(), previous.revision() + 1);
        save(runId, previous.status(), next);
        return next.view(historyFor(runId, findingId));
    }

    private void requireEditorAssigned(String editor, Stored previous, Status status, String assignee, String deadline) {
        if (!editor.equals(previous.assigneeId()) || !Objects.equals(assignee, previous.assigneeId())
                || !Objects.equals(deadline, previous.dueDate()) || previous.status() == Status.VERIFIED
                || previous.status() == Status.DISMISSED || status == Status.VERIFIED || status == Status.DISMISSED) {
            throw ApiFailure.forbidden("编辑者只可跟进自己负责的开放问题及提交复查。");
        }
    }

    private void validateStatus(Finding finding, Status before, Status after, ObjectNode patch, String note) {
        if (!before.accepts(after)) throw ApiFailure.conflict("此状态无法直接变更，请先处理或重新打开问题。");
        if ((after == Status.IN_PROGRESS || after.recordsRepair()) && finding.decision() != Decision.CONFIRMED) {
            throw ApiFailure.conflict("请先由评审者确认此疑点，再进行整改。");
        }
        if (before != after && (after == Status.VERIFIED || after == Status.DISMISSED)) {
            if (finding.decision() == Decision.PENDING) throw ApiFailure.conflict("请先记录疑点的复核结论。");
            if (!patch.hasNonNull("note") || note.isBlank()) {
                throw ApiFailure.badRequest("请填写此次核验或关闭的依据。");
            }
        }
    }

    private void requireNewerVersion(Run run, String versionId) {
        if (versionId == null) throw ApiFailure.badRequest("请选择修订后的文档版本。");
        if (audits.requireVersion(run.documentId(), versionId).number()
                <= audits.requireVersion(run.documentId(), run.versionId()).number()) {
            throw ApiFailure.badRequest("请选择比审查版本更新的修订版本。");
        }
    }

    private static Status readStatus(ObjectNode patch, Status current) {
        String supplied = field(patch, "status", current.name(), "处理状态", 16);
        try {
            if (supplied != null) return Status.valueOf(supplied);
        } catch (IllegalArgumentException ignored) {
            // Map unknown values to the same field error as an empty status.
        }
        throw ApiFailure.badRequest("处理状态无效。");
    }

    private static String field(ObjectNode patch, String key, String fallback, String label, int length) {
        if (!patch.has(key)) return fallback;
        JsonNode value = patch.get(key);
        if (value.isNull()) return null;
        if (!value.isTextual()) throw ApiFailure.badRequest(label + "必须是文本。");
        String clean = ApiFailure.optionalText(value.textValue(), label, length);
        return clean.isEmpty() ? null : clean;
    }

    private static void validateDate(String deadline) {
        if (deadline == null) return;
        try {
            var date = LocalDate.parse(deadline);
            if (date.getYear() > 0 && date.toString().equals(deadline)) return;
        } catch (DateTimeParseException ignored) {
            // Use a localized error for invalid and out-of-range dates.
        }
        throw ApiFailure.badRequest("期限请使用有效的 YYYY-MM-DD 日期。");
    }

    private void save(String runId, Status priorStatus, Stored next) {
        if (next.revision() == 1) {
            jdbc.update("""
                    INSERT INTO review_issue (run_id, finding_id, issue_status, assignee_id, due_date,
                        resolution_version_id, note, updated_by, updated_at, revision_no)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """, runId, next.findingId(), next.status().name(), next.assigneeId(), next.dueDate(),
                    next.versionId(), next.note(), next.actorId(), next.updatedAt(), next.revision());
        } else {
            jdbc.update("""
                    UPDATE review_issue SET issue_status = ?, assignee_id = ?, due_date = ?,
                        resolution_version_id = ?, note = ?, updated_by = ?, updated_at = ?, revision_no = ?
                    WHERE run_id = ? AND finding_id = ?
                    """, next.status().name(), next.assigneeId(), next.dueDate(), next.versionId(), next.note(),
                    next.actorId(), next.updatedAt(), next.revision(), runId, next.findingId());
        }
        jdbc.update("""
                INSERT INTO issue_event (run_id, finding_id, revision_no, prior_status, new_status,
                    assignee_id, assignee_name, due_date, resolution_version_id, note, actor_id, actor_name, created_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, runId, next.findingId(), next.revision(), priorStatus.name(), next.status().name(),
                next.assigneeId(), next.assigneeName(), next.dueDate(), next.versionId(), next.note(),
                next.actorId(), next.actorName(), next.updatedAt());
    }

    private List<Event> historyFor(String runId, String findingId) {
        return jdbc.query(EVENT_VIEW + "AND finding_id = ? ORDER BY revision_no", EVENT, runId, findingId)
                .stream().map(EventRow::event).toList();
    }
}
