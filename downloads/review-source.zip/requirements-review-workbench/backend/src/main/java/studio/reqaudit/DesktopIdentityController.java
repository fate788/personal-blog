package studio.reqaudit;

import jakarta.servlet.http.HttpServletResponse;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import java.io.IOException;
import java.nio.channels.FileChannel;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.security.*;
import java.security.interfaces.ECPublicKey;
import java.security.spec.*;
import java.util.Base64;
import java.util.List;
import java.util.regex.Pattern;

@RestController
class DesktopIdentityController {
    private static final Pattern CHALLENGE = Pattern.compile("[0-9a-f]{32}(?:[0-9a-f]{32})?");
    private static final Base64.Encoder B64 = Base64.getEncoder();
    private static final Path DIRECTORY = Path.of("data", "desktop-identity");
    private KeyPair keys;

    record Proof(String publicKey, String challenge, String signature) {}

    @GetMapping("/api/desktop/identity")
    @StudioAccess.PublicEndpoint
    Proof sign(@RequestParam String challenge, HttpServletResponse response) {
        if (!CHALLENGE.matcher(challenge).matches()) throw ApiFailure.badRequest("桌面连接校验码格式错误。");
        try {
            var pair = keys();
            var signature = Signature.getInstance("SHA256withECDSAinP1363Format");
            signature.initSign(pair.getPrivate());
            signature.update(("REQAUDIT-DESKTOP-V2\n" + challenge).getBytes(StandardCharsets.US_ASCII));
            String proof = B64.encodeToString(signature.sign());
            response.setHeader("Cache-Control", "no-store");
            response.setHeader("X-Review-Desktop-Proof", proof);
            var point = ((ECPublicKey) pair.getPublic()).getW();
            var raw = new byte[65];
            raw[0] = 4;
            copyCoordinate(point.getAffineX().toByteArray(), raw, 1);
            copyCoordinate(point.getAffineY().toByteArray(), raw, 33);
            return new Proof(B64.encodeToString(raw), challenge, proof);
        } catch (IOException | GeneralSecurityException | IllegalArgumentException ex) {
            throw new ResponseStatusException(HttpStatus.SERVICE_UNAVAILABLE, "主机身份暂时无法读取。", ex);
        }
    }

    private static void copyCoordinate(byte[] value, byte[] into, int offset) {
        int size = Math.min(32, value.length);
        System.arraycopy(value, value.length - size, into, offset + 32 - size, size);
    }

    private synchronized KeyPair keys() throws IOException, GeneralSecurityException {
        if (keys != null) return keys;
        Files.createDirectories(DIRECTORY);
        Path file = DIRECTORY.resolve("host-keypair");
        try (var channel = FileChannel.open(DIRECTORY.resolve("host.lock"), StandardOpenOption.CREATE, StandardOpenOption.WRITE);
             var lock = channel.lock()) {
            if (Files.exists(file)) {
                if (Files.size(file) > 2048) throw new IOException("Invalid host identity size");
                var lines = Files.readAllLines(file, StandardCharsets.US_ASCII);
                if (lines.size() != 2) throw new IOException("Incomplete host identity");
                var factory = KeyFactory.getInstance("EC");
                keys = new KeyPair(factory.generatePublic(new X509EncodedKeySpec(Base64.getDecoder().decode(lines.get(0)))),
                        factory.generatePrivate(new PKCS8EncodedKeySpec(Base64.getDecoder().decode(lines.get(1)))));
            } else {
                var generator = KeyPairGenerator.getInstance("EC");
                generator.initialize(new ECGenParameterSpec("secp256r1"));
                var pair = generator.generateKeyPair();
                Path tmp = Files.createTempFile(DIRECTORY, "identity-", ".tmp");
                try {
                    Files.write(tmp, List.of(B64.encodeToString(pair.getPublic().getEncoded()), B64.encodeToString(pair.getPrivate().getEncoded())), StandardCharsets.US_ASCII);
                    try { Files.move(tmp, file, StandardCopyOption.ATOMIC_MOVE); }
                    catch (AtomicMoveNotSupportedException ex) { Files.move(tmp, file); }
                } finally { Files.deleteIfExists(tmp); }
                keys = pair;
            }
            return keys;
        }
    }
}
