package studio.reqaudit;

import com.fasterxml.jackson.annotation.JsonInclude;

import java.util.List;
import java.util.Map;

final class Domain {
    private Domain() {}

    enum Mode { DEMO, MODEL }
    enum ExecutionStrategy { COMBINED, LOCAL_ONLY }
    enum ModelProfile { PRIMARY, BACKUP }
    enum RunStatus { QUEUED, RUNNING, COMPLETED, PARTIAL, FAILED }
    enum FindingStatus { ISSUE, INSUFFICIENT, NOT_APPLICABLE, PASS }
    enum Severity { HIGH, MEDIUM, LOW }
    enum Decision { PENDING, CONFIRMED, REJECTED }
    enum ValidationKind { DOCUMENT, CONFLICT, INTERNAL_CALCULATION, EXTERNAL_FACT }
    enum ScopeRelation { OVERLAP, DISJOINT, UNKNOWN }
    enum ConsequenceRelation { INCOMPATIBLE, COMPATIBLE, UNKNOWN }

    record Document(String id, String title, String createdAt, String updatedAt, List<Version> versions) {}
    record Version(String id, int number, String text, String createdAt, List<Section> sections, List<Item> items,
                   SourceMetadata source) {
        Version(String id, int number, String text, String createdAt, List<Section> sections, List<Item> items) {
            this(id, number, text, createdAt, sections, items, null);
        }
    }
    record SourceMetadata(String format, String fileName, Integer pageCount, List<String> warnings,
                          Map<Integer, SourceAnchor> anchors, String fileSha256) {
        SourceMetadata(String format, String fileName, Integer pageCount, List<String> warnings, Map<Integer, SourceAnchor> anchors) {
            this(format, fileName, pageCount, warnings, anchors, null);
        }
    }
    record SourceAnchor(Integer page, Integer endPage, Integer startLine, Integer endLine, Integer table,
                        Integer row, List<SourceCell> cells) {}
    record SourceCell(int column, int start, int end) {}
    record Section(String id, String title, int line, int level) {}
    record Item(String id, String code, String text, int line, String section) {}
    record Rule(String id, String name, String question, String applies, String criterion, String example) {}
    record Pack(String id, String name, String description, String version, List<Rule> rules,
                @JsonInclude(JsonInclude.Include.NON_NULL) String basePackId,
                @JsonInclude(JsonInclude.Include.NON_NULL) Integer revision) {
        Pack(String id, String name, String description, String version, List<Rule> rules) {
            this(id, name, description, version, rules, null, null);
        }

        String basisPackId() { return basePackId == null ? id : basePackId; }
    }
    record Evidence(String itemId, String code, String quote, int line, int start, int end) {}
    record Finding(String id, String ruleId, String title, String category, Severity severity, FindingStatus status,
                   String reason, String suggestion, List<Evidence> evidence, Decision decision, String note,
                   String decidedAt, String itemId, ValidationKind validationKind, ConflictComparison comparison) {
        Finding decided(Decision next, String nextNote, String timestamp) {
            return new Finding(id, ruleId, title, category, severity, status, reason, suggestion, evidence,
                    next, nextNote, timestamp, itemId, validationKind, comparison);
        }
    }
    record Scope(int items, int checks, int batches, List<String> coveredItemIds, List<String> omittedItemIds,
                 int coveredChecks, List<BatchScope> details, Integer substantiveChecks, Integer insufficientChecks,
                 Integer notApplicableChecks, Integer unconfirmedChecks, Integer plannedBatches, Integer batchLimit,
                 List<String> overBudgetItemIds, List<String> oversizedItemIds, List<String> analyzedItemIds) {}
    record BatchScope(int number, List<String> primaryItemIds, List<String> contextItemIds,
                      boolean completed, int coveredChecks, Integer substantiveChecks) {}
    record Usage(int calls, Integer inputTokens, Integer outputTokens, Integer cachedInputTokens,
                 Integer reasoningTokens, Boolean complete) {}
    record ModelTrace(int batch, int attempt, ModelProfile profile, String providerLabel, String requestedModel,
                      String actualModel, String requestId, String status, Integer statusCode, String finishReason,
                      long elapsedMs, Integer inputTokens, Integer outputTokens, Integer cachedInputTokens,
                      Integer reasoningTokens, Boolean outbound) {}
    record Diagnostic(String type, String detail) {}
    record RuleWarning(String type, String detail, int line,
                       @JsonInclude(JsonInclude.Include.NON_NULL) Integer relatedLine,
                       @JsonInclude(JsonInclude.Include.NON_NULL) String matchingFindingId) {
        RuleWarning(String type, String detail, int line, Integer relatedLine) { this(type, detail, line, relatedLine, null); }
        RuleWarning(String type, String detail, int line) { this(type, detail, line, null); }
    }
    record Run(String id, String documentId, String versionId, String packId, String createdAt, Mode mode,
               RunStatus status, Scope scope, long elapsedMs, Usage usage, List<Finding> findings,
               List<Diagnostic> diagnostics, List<RuleWarning> ruleWarnings, String packVersion, String model,
               List<String> targetItemIds, ModelProfile profile, List<ModelTrace> modelTrace, String modelConfigRevision,
               @JsonInclude(JsonInclude.Include.NON_EMPTY) String reviewBasis,
               @JsonInclude(JsonInclude.Include.NON_NULL) Pack packSnapshot,
               @JsonInclude(JsonInclude.Include.NON_NULL) ExecutionStrategy executionStrategy) {
        Run withFindings(List<Finding> updated) {
            return new Run(id, documentId, versionId, packId, createdAt, mode, status, scope, elapsedMs, usage,
                    updated, diagnostics, ruleWarnings, packVersion, model, targetItemIds, profile, modelTrace,
                    modelConfigRevision, reviewBasis, packSnapshot, executionStrategy);
        }

        Run withStatus(RunStatus newStatus, List<Diagnostic> updatedDiagnostics) {
            return new Run(id, documentId, versionId, packId, createdAt, mode, newStatus, scope, elapsedMs, usage,
                    findings, updatedDiagnostics, ruleWarnings, packVersion, model, targetItemIds, profile, modelTrace,
                    modelConfigRevision, reviewBasis, packSnapshot, executionStrategy);
        }

        Run withPackSnapshot(Pack pack) {
            return new Run(id, documentId, versionId, packId, createdAt, mode, status, scope, elapsedMs, usage,
                    findings, diagnostics, ruleWarnings, packVersion, model, targetItemIds, profile, modelTrace,
                    modelConfigRevision, reviewBasis, pack, executionStrategy);
        }
    }
    record Workspace(List<Document> documents, List<Pack> packs, List<Run> runs, Mode mode,
                     List<Projects.Project> projects, Projects.Project project) {}
    record Report(String documentTitle, int versionNumber, String packName, Run run, List<DecisionLog> decisions) {}
    record DecisionLog(String findingId, Decision priorDecision, Decision newDecision, String note, String createdAt) {}
    record Draft(String title, String text, Mode mode, ModelProfile profile, List<ModelTrace> modelTrace) {
        Draft(String title, String text, Mode mode) {
            this(title, text, mode, null, List.of());
        }
    }

    record DraftInput(String goal, String roles, String features, String constraints, String scope,
                      String acceptance, String nfr, String integrations, Mode mode, ModelProfile profile) {
        DraftInput(String goal, String roles, String features, String constraints, String scope,
                   String acceptance, String nfr, String integrations, Mode mode) {
            this(goal, roles, features, constraints, scope, acceptance, nfr, integrations, mode, null);
        }
    }
    record ProposedEvidence(String itemId, String quote) {}
    record ComparisonSide(String itemId, String subjectQuote, String objectQuote, String activityQuote,
                          String conditionQuote, String consequenceQuote) {}
    record ConflictComparison(ComparisonSide left, ComparisonSide right, ScopeRelation subject,
                              ScopeRelation object, ScopeRelation activity, ScopeRelation condition,
                              ConsequenceRelation consequence, String sharedScenario, List<ProposedEvidence> scopeEvidence) {}
    record Assessment(String itemId, String ruleId, FindingStatus status, Severity severity, String title,
                      String reason, String suggestion, List<ProposedEvidence> evidence,
                      ValidationKind validationKind, ConflictComparison comparison, String calculationQuote) {
        Assessment(String itemId, String ruleId, FindingStatus status, Severity severity, String title,
                   String reason, String suggestion, List<ProposedEvidence> evidence) {
            this(itemId, ruleId, status, severity, title, reason, suggestion, evidence, null, null, null);
        }
    }
}
