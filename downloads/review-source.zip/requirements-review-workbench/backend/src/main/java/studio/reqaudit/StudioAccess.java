package studio.reqaudit;

import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.util.concurrent.ConcurrentHashMap;

@Configuration
class StudioAccess implements WebMvcConfigurer, HandlerInterceptor {
    static final String COOKIE = "review_studio_session";
    static final String ACCOUNT = "reviewStudioAccount";
    private static final long WINDOW_MS = 60_000;
    private static final int MAX_ADDRESSES = 2_000;
    private static final int MAX_ATTEMPTS = 8;
    private static final int MAX_REGISTRATIONS = 4;
    private final Accounts accounts;
    private final ConcurrentHashMap<String, AttemptWindow> attempts = new ConcurrentHashMap<>();
    private final ConcurrentHashMap<String, AttemptWindow> registrations = new ConcurrentHashMap<>();

    @Target(ElementType.METHOD)
    @Retention(RetentionPolicy.RUNTIME)
    @interface PublicEndpoint {}

    private record AttemptWindow(long until, int count) {}

    StudioAccess(Accounts accounts) {
        this.accounts = accounts;
    }

    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        registry.addInterceptor(this).addPathPatterns("/api/**");
    }

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) {
        response.setHeader("Cache-Control", "no-store");
        response.setHeader("X-Content-Type-Options", "nosniff");
        if (!request.getMethod().equals("GET") && !request.getMethod().equals("HEAD")) {
            String site = request.getHeader("Sec-Fetch-Site");
            if ((site != null && !site.equals("same-origin") && !site.equals("none"))
                    || !"web".equals(request.getHeader("X-Review-Client"))) {
                throw ApiFailure.forbidden("请求来源未通过校验。");
            }
        }
        if (!(handler instanceof HandlerMethod method)) return true;
        var user = accounts.fromToken(token(request));
        request.setAttribute(ACCOUNT, user);
        if (!method.hasMethodAnnotation(PublicEndpoint.class) && user == null) {
            throw ApiFailure.unauthorized("请登录后继续。");
        }
        return true;
    }

    static String token(HttpServletRequest request) {
        Cookie[] cookies = request.getCookies();
        if (cookies == null) return null;
        for (Cookie cookie : cookies) {
            if (cookie.getName().equals(COOKIE)) return cookie.getValue();
        }
        return null;
    }

    void limitAuthentication(HttpServletRequest request) {
        limit(request, attempts, MAX_ATTEMPTS, "登录尝试过多，请稍后重试。");
    }

    void limitRegistration(HttpServletRequest request) {
        limit(request, registrations, MAX_REGISTRATIONS, "注册尝试过多，请稍后重试。");
    }

    private static void limit(HttpServletRequest request, ConcurrentHashMap<String, AttemptWindow> windows,
                              int maxAttempts, String message) {
        var address = request.getRemoteAddr();
        long now = System.currentTimeMillis();
        if (windows.size() >= MAX_ADDRESSES) {
            windows.entrySet().removeIf(entry -> entry.getValue().until <= now);
            if (!windows.containsKey(address) && windows.size() >= MAX_ADDRESSES) {
                throw ApiFailure.busy(message);
            }
        }
        AttemptWindow window = windows.compute(address, (key, old) ->
                old == null || old.until <= now ? new AttemptWindow(now + WINDOW_MS, 1)
                        : new AttemptWindow(old.until, Math.min(maxAttempts + 1, old.count + 1)));
        if (window.count > maxAttempts) throw ApiFailure.busy(message);
    }

    void clearAuthenticationLimit(HttpServletRequest request) {
        attempts.remove(request.getRemoteAddr());
    }
}
