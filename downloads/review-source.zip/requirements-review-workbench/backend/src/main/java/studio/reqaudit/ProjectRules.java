package studio.reqaudit;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import static studio.reqaudit.Domain.*;

@Service
class ProjectRules {
    enum Kind { FLAG_PHRASE, REQUIRE_PHRASE }
    enum Scope { REQUIREMENTS, FULL_TEXT }
    enum Verdict { CONFIRMED, FALSE_POSITIVE }
    record Input(String name, Kind kind, Scope scope, String trigger, String required,
                 String guidance, boolean enabled, int revision) {}
    record Rule(String id, int revision, String name, Kind kind, Scope scope, String trigger,
                String required, String guidance, boolean enabled, String updatedAt) {}
    record Stats(int confirmed, int falsePositives, int confirmedDocuments, int falsePositiveDocuments) {}
    record RuleView(Rule rule, Stats stats, String suggestion) {}
    record Feedback(int revision, String documentId, String versionId, int line, Verdict verdict) {}
    record Target(String documentId, String versionId) {}
    record Hit(int line, String text, Verdict verdict) {}
    record Trial(int revision, int total, List<Hit> hits) {}
    record Comparison(List<RuleWarning> before, List<RuleWarning> after) {}

    private static final int MAX_RULES = 30;
    private static final int HIT_LIMIT = 100;
    private static final int TRIAL_LIMIT = 80;
    private static final RowMapper<Rule> RULE = (row, index) -> new Rule(row.getString("rule_id"),
            row.getInt("revision_no"), row.getString("rule_name"), Kind.valueOf(row.getString("rule_kind")),
            Scope.valueOf(row.getString("rule_scope")), row.getString("trigger_text"), row.getString("required_text"),
            row.getString("guidance"), row.getBoolean("enabled"), row.getString("created_at"));
    private static final String LATEST = """
            SELECT r.* FROM project_rule_revision r
            WHERE r.project_id = ? AND NOT EXISTS (
              SELECT 1 FROM project_rule_revision newer
              WHERE newer.rule_id = r.rule_id AND newer.revision_no > r.revision_no)
            ORDER BY r.created_at DESC, r.rule_id
            """;

    private final JdbcTemplate jdbc;
    private final DocumentParser parser;

    ProjectRules(JdbcTemplate jdbc, DocumentParser parser) {
        this.jdbc = jdbc;
        this.parser = parser;
    }

    List<RuleView> list(String projectId) {
        return current(projectId).stream().map(this::view).toList();
    }

    List<RuleView> history(String projectId, String ruleId) {
        return jdbc.query("""
                SELECT * FROM project_rule_revision WHERE project_id = ? AND rule_id = ?
                ORDER BY revision_no DESC
                """, RULE, projectId, ruleId).stream().map(this::view).toList();
    }

    @Transactional
    RuleView save(String projectId, String ruleId, String actorId, Input input) {
        lockProject(projectId);
        Rule existing = ruleId == null ? null : requireRule(projectId, ruleId);
        if (existing == null && current(projectId).size() >= MAX_RULES) {
            throw ApiFailure.conflict("每个项目最多保存 " + MAX_RULES + " 条规则。");
        }
        if (existing != null && input.revision() != existing.revision()) {
            throw ApiFailure.conflict("规则已有新版本，请刷新后再修改。");
        }
        if (input.kind() == null || input.scope() == null) throw ApiFailure.badRequest("请选择检查类型和范围。");
        String trigger = literal(input.trigger(), "触发表述");
        String required = input.kind() == Kind.REQUIRE_PHRASE ? literal(input.required(), "必备表述") : "";
        if (input.kind() == Kind.REQUIRE_PHRASE && trigger.contains(required)) {
            throw ApiFailure.badRequest("触发表述已包含必备表述，请调整检查条件。");
        }
        Rule rule = new Rule(existing == null ? AuditRepository.id() : existing.id(),
                existing == null ? 1 : existing.revision() + 1, ApiFailure.requireText(input.name(), "规则名称", 100).strip(),
                input.kind(), input.scope(), trigger, required, ApiFailure.optionalText(input.guidance(), "处理建议", 400),
                existing != null && input.enabled(), Instant.now().toString());
        jdbc.update("""
                INSERT INTO project_rule_revision (rule_id, revision_no, project_id, rule_name, rule_kind, rule_scope,
                    trigger_text, required_text, guidance, enabled, actor_id, created_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, rule.id(), rule.revision(), projectId, rule.name(), rule.kind().name(), rule.scope().name(),
                rule.trigger(), rule.required(), rule.guidance(), rule.enabled(), actorId, rule.updatedAt());
        return view(rule);
    }

    Trial trial(String projectId, String ruleId, Version version) {
        Rule rule = requireRule(projectId, ruleId);
        var reviewed = new HashMap<Integer, Verdict>();
        jdbc.query("""
                SELECT line_no, verdict FROM project_rule_feedback
                WHERE rule_id = ? AND revision_no = ? AND version_id = ?
                """, row -> { reviewed.put(row.getInt(1), Verdict.valueOf(row.getString(2))); },
                ruleId, rule.revision(), version.id());
        var hits = scan(rule, version);
        return new Trial(rule.revision(), hits.size(), hits.stream().limit(TRIAL_LIMIT)
                .map(hit -> new Hit(hit.line(), hit.text(), reviewed.get(hit.line()))).toList());
    }

    @Transactional
    RuleView feedback(String projectId, String ruleId, String actorId, Version version, Feedback input) {
        lockProject(projectId);
        Rule rule = requireRule(projectId, ruleId);
        if (rule.revision() != input.revision()) throw ApiFailure.conflict("规则版本已变化，请重新试跑。");
        if (input.verdict() == null || scan(rule, version).stream().noneMatch(hit -> hit.line() == input.line())) {
            throw ApiFailure.badRequest("请先试跑并选择该版本原文中实际命中的条目。");
        }
        String now = Instant.now().toString();
        jdbc.update("""
                INSERT INTO project_rule_feedback (rule_id, revision_no, version_id, line_no, verdict, actor_id, updated_at)
                VALUES (?, ?, ?, ?, ?, ?, ?)
                ON DUPLICATE KEY UPDATE verdict = ?, actor_id = ?, updated_at = ?
                """, rule.id(), rule.revision(), version.id(), input.line(), input.verdict().name(), actorId,
                now, input.verdict().name(), actorId, now);
        return view(rule);
    }

    List<RuleWarning> check(String documentId, Version version) {
        return check(version, forDocument(documentId));
    }

    record CheckSnapshot(List<RuleWarning> warnings, List<String> enabledRevisions) {}

    CheckSnapshot snapshot(String documentId, Version version) {
        var enabled = forDocument(documentId);
        return new CheckSnapshot(check(version, enabled), enabled.stream()
                .map(rule -> rule.id() + "/" + rule.revision()).sorted().toList());
    }

    Comparison compare(String documentId, Version before, Version after) {
        var rules = forDocument(documentId);
        return new Comparison(check(before, rules), check(after, rules));
    }

    private List<Rule> forDocument(String documentId) {
        var projectIds = jdbc.queryForList("SELECT project_id FROM document_scope WHERE document_id = ?", String.class, documentId);
        return projectIds.isEmpty() ? List.of() : current(projectIds.get(0)).stream().filter(Rule::enabled).toList();
    }

    private List<RuleWarning> check(Version version, List<Rule> rules) {
        var warnings = new ArrayList<>(parser.checkReferences(version));
        int count = 0;
        for (Rule rule : rules) {
            String type = "PROJECT_RULE_" + rule.id() + "_V" + rule.revision();
            String message = "项目规则「" + rule.name() + "」 V" + rule.revision() + "。" + explanation(rule);
            if (!rule.guidance().isBlank()) message += " " + rule.guidance();
            for (Hit hit : scan(rule, version)) {
                if (count++ < HIT_LIMIT) warnings.add(new RuleWarning(type, message, hit.line()));
            }
        }
        if (count > HIT_LIMIT) warnings.add(new RuleWarning("PROJECT_RULE_LIMIT", "另有 " + (count - HIT_LIMIT) + " 条项目规则提示，可在规则试跑中查看触发情况。", 0));
        return List.copyOf(warnings);
    }

    private static String explanation(Rule rule) {
        return rule.kind() == Kind.FLAG_PHRASE ? "发现表述「" + rule.trigger() + "」。"
                : "发现表述「" + rule.trigger() + "」，同一条目中缺少「" + rule.required() + "」。";
    }

    private static List<Hit> scan(Rule rule, Version version) {
        Set<Integer> clauses = rule.scope() == Scope.REQUIREMENTS
                ? version.items().stream().map(Item::line).collect(Collectors.toSet()) : null;
        var hits = new ArrayList<Hit>();
        String[] lines = version.text().split("\n", -1);
        for (int index = 0; index < lines.length; index++) {
            if (clauses != null && !clauses.contains(index + 1)) continue;
            String text = lines[index];
            if (text.contains(rule.trigger()) && (rule.kind() == Kind.FLAG_PHRASE || !text.contains(rule.required()))) {
                hits.add(new Hit(index + 1, text, null));
            }
        }
        return hits;
    }

    private List<Rule> current(String projectId) {
        return jdbc.query(LATEST, RULE, projectId);
    }

    private Rule requireRule(String projectId, String ruleId) {
        return current(projectId).stream().filter(rule -> rule.id().equals(ruleId)).findFirst()
                .orElseThrow(() -> ApiFailure.notFound("当前项目中没有该规则。"));
    }

    private RuleView view(Rule rule) {
        Stats stats = jdbc.queryForObject("""
                SELECT COUNT(CASE WHEN f.verdict = 'CONFIRMED' THEN 1 END),
                       COUNT(CASE WHEN f.verdict = 'FALSE_POSITIVE' THEN 1 END),
                       COUNT(DISTINCT CASE WHEN f.verdict = 'CONFIRMED' THEN v.document_id END),
                       COUNT(DISTINCT CASE WHEN f.verdict = 'FALSE_POSITIVE' THEN v.document_id END)
                FROM project_rule_feedback f JOIN document_version v ON v.id = f.version_id
                WHERE f.rule_id = ? AND f.revision_no = ?
                """, (row, index) -> new Stats(row.getInt(1), row.getInt(2), row.getInt(3), row.getInt(4)),
                rule.id(), rule.revision());
        String suggestion = stats.falsePositiveDocuments() >= 2 ? "REFINE_TRIGGER"
                : (!rule.enabled() && stats.confirmedDocuments() >= 2 && stats.falsePositives() == 0 ? "ENABLE_CANDIDATE" : null);
        return new RuleView(rule, stats, suggestion);
    }

    private void lockProject(String projectId) {
        jdbc.queryForObject("SELECT id FROM studio_project WHERE id = ? FOR UPDATE", String.class, projectId);
    }

    private static String literal(String value, String label) {
        String text = ApiFailure.requireText(value, label, 120).strip();
        if (text.lines().count() > 1) throw ApiFailure.badRequest(label + "须为单行文字。");
        return text;
    }
}
