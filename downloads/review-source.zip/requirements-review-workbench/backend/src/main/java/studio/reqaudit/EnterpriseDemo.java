package studio.reqaudit;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import static studio.reqaudit.Domain.*;

@Component
class EnterpriseDemo {
    private record Fixture(String rule, Severity severity, FindingStatus status, String title, String reason,
                           String suggestion, List<List<String>> refs) {}
    private final List<Fixture> fixtures;
    private final List<String> exampleTexts;

    EnterpriseDemo(ObjectMapper mapper) throws IOException {
        try (var input = new ClassPathResource("enterprise-findings.json").getInputStream()) {
            fixtures = mapper.readValue(input, new TypeReference<>() {});
        }
        var texts = new ArrayList<String>();
        for (String file : List.of("enterprise-sample.txt", "enterprise-sample-v2.txt")) {
            var resource = new ClassPathResource(file);
            if (resource.exists()) {
                texts.add(resource.getContentAsString(StandardCharsets.UTF_8).strip());
            }
        }
        exampleTexts = List.copyOf(texts);
    }

    boolean isVersion(Version version) {
        return version.text().contains("SRS-ITSM-001");
    }

    boolean isKnownText(Version version) {
        return exampleTexts.contains(version.text().strip());
    }

    List<String> targets(Version version) {
        var codes = fixtures.stream().map(f -> f.refs().get(0).get(0)).toList();
        return version.items().stream().filter(i -> codes.contains(i.code())).map(Item::id).toList();
    }

    Map<String, Set<String>> related(Version version) {
        if (!isVersion(version)) return Map.of();
        Map<String, Set<String>> related = new LinkedHashMap<>();
        for (Fixture fixture : fixtures) {
            List<Item> items = fixture.refs().stream().map(ref -> resolve(ref, version.items())).toList();
            if (items.stream().anyMatch(java.util.Objects::isNull)) continue;
            for (int index = 1; index < items.size(); index++) {
                if (!items.get(0).id().equals(items.get(index).id())) {
                    related.computeIfAbsent(items.get(0).id(), ignored -> new LinkedHashSet<>()).add(items.get(index).id());
                }
            }
        }
        return related;
    }

    Assessment assess(Item item, Rule rule, List<Item> scope, boolean knownSample) {
        for (Fixture fixture : fixtures) {
            if (!fixture.rule().equals(rule.id()) || !fixture.refs().get(0).get(0).equals(item.code())) continue;
            List<Item> items = fixture.refs().stream().map(ref -> resolve(ref, scope)).toList();
            if (items.get(0) == null || !items.get(0).id().equals(item.id())
                    || items.stream().anyMatch(java.util.Objects::isNull)) continue;
            var evidence = new ArrayList<ProposedEvidence>();
            for (int i = 0; i < items.size(); i++) {
                evidence.add(new ProposedEvidence(items.get(i).id(), fixture.refs().get(i).get(1)));
            }
            return new Assessment(item.id(), rule.id(), fixture.status() == null ? FindingStatus.ISSUE : fixture.status(),
                    fixture.severity(), fixture.title(), fixture.reason(), fixture.suggestion(), List.copyOf(evidence));
        }
        return new Assessment(item.id(), rule.id(), knownSample ? FindingStatus.PASS : FindingStatus.INSUFFICIENT,
                Severity.LOW, "演示样例没有预设判断",
                "此处仅使用已标注的演示样例，可连接模型审查修改后的需求。", "", List.of());
    }

    private static Item resolve(List<String> reference, List<Item> scope) {
        return scope.stream().filter(item -> item.code().equals(reference.get(0)) && item.text().contains(reference.get(1)))
                .findFirst().orElse(null);
    }
}
