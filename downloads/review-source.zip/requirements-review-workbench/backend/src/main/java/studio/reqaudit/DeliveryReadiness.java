package studio.reqaudit;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import static studio.reqaudit.Domain.*;

@Service
class DeliveryReadiness {
    enum State { READY, ATTENTION, UNKNOWN }

    record ReviewOption(String id, String createdAt, String model, String packId, String packName, RunStatus status) {}
    record ReviewDetail(String id, Mode mode, RunStatus status, int coveredItems, int totalItems,
                        Integer substantiveChecks, int totalChecks, Integer insufficientChecks,
                        Integer unconfirmedChecks, long pendingFindings, long confirmedUntracked,
                        int activeIssues) {}
    record Step(String key, State state, String title, String detail) {}
    record Snapshot(String documentId, String versionId, int versionNumber, List<ReviewOption> reviews,
                    ReviewDetail review, int checkCount, int activeIssues, List<Step> steps) {}

    private final AuditRepository repository;
    private final Projects projects;
    private final ProjectRules projectRules;
    private final JdbcTemplate jdbc;
    private final ProjectPacks packs;

    DeliveryReadiness(AuditRepository repository, Projects projects, ProjectRules projectRules, JdbcTemplate jdbc, ProjectPacks packs) {
        this.repository = repository;
        this.projects = projects;
        this.projectRules = projectRules;
        this.jdbc = jdbc;
        this.packs = packs;
    }

    @Transactional(readOnly = true, isolation = Isolation.REPEATABLE_READ)
    Snapshot snapshot(String userId, String documentId, String versionId, String requestedRun) {
        projects.forDocument(userId, documentId);
        Version version = repository.requireVersion(documentId, versionId);
        String runId = ApiFailure.optionalText(requestedRun, "审查任务编号", 64);
        List<Run> versionRuns = repository.listVersionRuns(documentId, version.id());
        List<Run> terminal = versionRuns.stream().filter(DeliveryReadiness::terminal).toList();
        Run run = selectedRun(runId, versionRuns, terminal);
        List<ReviewOption> options = terminal.stream()
                .map(candidate -> new ReviewOption(candidate.id(), candidate.createdAt(), candidate.model(),
                        candidate.packId(), packs.historical(candidate).packSnapshot().name(), candidate.status())).toList();
        int warnings = projectRules.check(documentId, version).size();
        int activeIssues = countActiveIssues(documentId, version.number());
        ReviewDetail detail = run == null ? null : detail(run, version, activeIssues);
        return new Snapshot(documentId, version.id(), version.number(), options, detail, warnings, activeIssues,
                List.of(documentChecks(warnings), coverage(detail), findings(detail), issueTracking(activeIssues)));
    }

    private static boolean terminal(Run run) {
        return run.status() == RunStatus.COMPLETED || run.status() == RunStatus.PARTIAL
                || run.status() == RunStatus.FAILED;
    }

    private static Run selectedRun(String runId, List<Run> versionRuns, List<Run> terminal) {
        if (runId.isEmpty()) return terminal.isEmpty() ? null : terminal.get(0);
        Run run = versionRuns.stream().filter(candidate -> candidate.id().equals(runId)).findFirst()
                .orElseThrow(() -> ApiFailure.notFound("审查任务不存在或不属于此文档版本。"));
        if (!terminal(run)) throw ApiFailure.conflict("审查任务尚未结束，结果生成后可查看交付准备情况。");
        return run;
    }

    private ReviewDetail detail(Run run, Version version, int activeIssues) {
        Scope scope = run.scope();
        Set<String> itemIds = version.items().stream().map(Item::id).collect(Collectors.toUnmodifiableSet());
        int coveredItems = scope == null || scope.coveredItemIds() == null ? 0
                : (int) scope.coveredItemIds().stream().filter(itemIds::contains).distinct().count();
        List<Finding> issues = run.findings().stream().filter(finding -> finding.status() == FindingStatus.ISSUE).toList();
        long pending = issues.stream().filter(finding -> finding.decision() == Decision.PENDING).count();
        Set<String> tracked = Set.copyOf(jdbc.queryForList(
                "SELECT finding_id FROM review_issue WHERE run_id = ?", String.class, run.id()));
        long untracked = issues.stream().filter(finding -> finding.decision() == Decision.CONFIRMED
                && !tracked.contains(finding.id())).count();
        return new ReviewDetail(run.id(), run.mode(), run.status(), coveredItems, itemIds.size(),
                scope == null ? null : scope.substantiveChecks(), scope == null ? 0 : scope.checks(),
                scope == null ? null : scope.insufficientChecks(), scope == null ? null : scope.unconfirmedChecks(),
                pending, untracked, activeIssues);
    }

    private int countActiveIssues(String documentId, int versionNumber) {
        // Later corrections cannot provide verification for an earlier delivery target.
        return jdbc.queryForObject("""
                SELECT COUNT(*)
                FROM review_issue i
                JOIN review_run r ON r.id = i.run_id
                JOIN document_version sv ON sv.id = r.version_id AND sv.document_id = r.document_id
                LEFT JOIN document_version rv ON rv.id = i.resolution_version_id
                    AND rv.document_id = r.document_id
                WHERE r.document_id = ? AND sv.version_no <= ?
                    AND (i.issue_status IN ('OPEN', 'IN_PROGRESS', 'FIXED')
                         OR (i.issue_status = 'VERIFIED'
                             AND (rv.version_no IS NULL OR rv.version_no > ?)))
                """, Integer.class, documentId, versionNumber, versionNumber);
    }

    private static Step documentChecks(int count) {
        return new Step("DOCUMENT_CHECKS", count == 0 ? State.READY : State.ATTENTION, "原件规则",
                count == 0 ? "已运行原件规则，当前没有提示。"
                        : "有 " + count + " 条原件规则提示，请回到文档核对。");
    }

    private static Step coverage(ReviewDetail review) {
        String key = "REVIEW_COVERAGE";
        String title = "语义审查范围";
        if (review == null) return new Step(key, State.UNKNOWN, title, "该版本尚无已结束的审查任务。");
        if (review.mode() != Mode.MODEL) return new Step(key, State.UNKNOWN, title, "该任务采用本地或示例检查。");
        if (review.status() == RunStatus.FAILED) return new Step(key, State.ATTENTION, title, "该审查任务执行失败，请查看诊断。");
        String covered = "已覆盖 " + review.coveredItems() + " / " + review.totalItems() + " 条版本原文";
        if (review.status() == RunStatus.PARTIAL || review.coveredItems() < review.totalItems()
                || positive(review.insufficientChecks()) || positive(review.unconfirmedChecks())) {
            return new Step(key, State.ATTENTION, title, covered + "。请核对未覆盖项、待确认项或执行诊断。");
        }
        if (!positive(review.substantiveChecks()) || review.insufficientChecks() == null
                || review.unconfirmedChecks() == null) {
            return new Step(key, State.UNKNOWN, title, covered + "，实质判断或历史覆盖信息不足。");
        }
        return new Step(key, State.READY, title, covered + "。所选规则包有 "
                + review.substantiveChecks() + " 个实质判断。");
    }

    private static boolean positive(Integer value) {
        return value != null && value > 0;
    }

    private static Step findings(ReviewDetail review) {
        String key = "FINDING_REVIEW";
        String title = "人工复核";
        if (review != null && (review.pendingFindings() > 0 || review.confirmedUntracked() > 0)) {
            return new Step(key, State.ATTENTION, title, "所选任务有 " + review.pendingFindings()
                    + " 条待复核疑点，" + review.confirmedUntracked() + " 条已确认但未登记跟踪的问题。");
        }
        if (review == null || review.mode() != Mode.MODEL || review.status() == RunStatus.FAILED) {
            return new Step(key, State.UNKNOWN, title, "等待该版本的语义审查结果供复核。");
        }
        return new Step(key, State.READY, title, "所选任务没有待复核或已确认而未登记的问题。");
    }

    private static Step issueTracking(int activeIssues) {
        return new Step("ISSUE_TRACKING", activeIssues == 0 ? State.READY : State.ATTENTION, "关联问题跟踪",
                activeIssues == 0 ? "当前及更早版本的跟踪记录中，没有待处理或仅在更晚版本核验的事项。"
                        : "当前及更早版本有 " + activeIssues + " 个跟踪问题待处理，或仅在更晚版本核验。");
    }
}
