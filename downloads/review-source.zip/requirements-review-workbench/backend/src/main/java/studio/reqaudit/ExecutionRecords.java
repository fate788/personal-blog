package studio.reqaudit;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.charset.CharacterCodingException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.time.Instant;
import java.time.OffsetDateTime;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.HashSet;
import java.util.HexFormat;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import static studio.reqaudit.Domain.Section;
import static studio.reqaudit.Domain.Version;

@Service
class ExecutionRecords {
    enum Scope { CASE, REQUIREMENT_SUMMARY }
    enum Status { PASS, FAIL, SKIPPED, NOT_RUN }

    record Row(Scope scope, String requirementId, String caseId, String relatedCaseIds, Status status,
               String executedAt, String evidence, String batchId) {}
    record Batch(String id, Scope scope, String source, String fileName, String sha256, String observedAt,
                 String importedAt, String importedBy, int rowCount) {}
    record Snapshot(String documentId, String versionId, Map<Status, Integer> counts,
                    Map<Status, Integer> summaryCounts, List<Row> rows, List<Batch> batches) {}
    record BatchDetails(Batch batch, List<Row> rows) {}

    private record Pair(String requirement, String testCase) {}
    private record ImportRow(int line, String requirement, String testCase, String relatedCases,
                             Status status, Instant executedAt, String evidence) {}
    private record RawRow(int line, List<String> fields) {}

    private static final int MAX_ROWS = 5_000;
    private static final int MAX_FILE_BYTES = 8 * 1024 * 1024;
    private static final Pattern IDENTIFIER = Pattern.compile("[\\p{L}\\p{N}][\\p{L}\\p{N}_.:/#-]{0,159}");
    private static final Pattern RFC3339 = Pattern.compile(
            "\\d{4}-\\d{2}-\\d{2}[Tt]\\d{2}:\\d{2}:\\d{2}(?:\\.\\d{1,9})?(?:[Zz]|[+-]\\d{2}:\\d{2})");
    private static final Set<String> REQUIRED = Set.of("requirement_id", "case_id", "status");
    private static final Set<String> HEADERS = Set.of("requirement_id", "case_id", "status", "executed_at",
            "evidence", "case_ids");
    private static final String BATCHES = """
            SELECT b.id, b.record_scope, b.source_label, b.file_name, b.file_sha256,
                   b.observed_at, b.imported_at, a.display_name, b.row_count
            FROM execution_batch b JOIN studio_account a ON a.id = b.imported_by
            WHERE b.document_id = ? AND b.version_id = ?
            """;
    private static final RowMapper<Batch> BATCH = (row, index) -> new Batch(
            row.getString(1), Scope.valueOf(row.getString(2)), row.getString(3), row.getString(4),
            row.getString(5), row.getString(6), row.getString(7), row.getString(8), row.getInt(9));
    private static final RowMapper<Row> ROW = (row, index) -> new Row(
            Scope.valueOf(row.getString(1)), row.getString(2), row.getString(3), row.getString(4),
            Status.valueOf(row.getString(5)), row.getString(6), row.getString(7), row.getString(8));

    private final JdbcTemplate jdbc;
    private final Projects projects;
    private final AuditRepository repository;
    private final DocumentParser parser;

    ExecutionRecords(JdbcTemplate jdbc, Projects projects, AuditRepository repository, DocumentParser parser) {
        this.jdbc = jdbc;
        this.projects = projects;
        this.repository = repository;
        this.parser = parser;
    }

    @Transactional(readOnly = true, isolation = Isolation.REPEATABLE_READ)
    Snapshot list(String userId, String documentId, String versionId) {
        projects.forDocument(userId, documentId);
        repository.requireVersion(documentId, versionId);
        return snapshot(documentId, versionId);
    }

    @Transactional(readOnly = true, isolation = Isolation.REPEATABLE_READ)
    BatchDetails details(String userId, String documentId, String versionId, String batchId) {
        projects.forDocument(userId, documentId);
        repository.requireVersion(documentId, versionId);
        Batch batch = jdbc.query(BATCHES + "AND b.id = ?", BATCH, documentId, versionId, batchId).stream()
                .findFirst().orElseThrow(() -> ApiFailure.notFound("该版本没有对应的执行记录批次。"));
        List<Row> rows = jdbc.query("""
                SELECT b.record_scope, r.requirement_id, r.case_id, r.related_case_ids,
                       r.record_status, r.executed_at, r.evidence, r.batch_id
                FROM execution_record r JOIN execution_batch b ON b.id = r.batch_id
                WHERE b.id = ? ORDER BY r.row_no
                """, ROW, batch.id());
        return new BatchDetails(batch, rows);
    }

    @Transactional(isolation = Isolation.READ_COMMITTED)
    Snapshot importFile(String userId, String documentId, String versionId, MultipartFile file,
                        String rawScope, String rawSource, String rawObservedAt) {
        var project = projects.forDocument(userId, documentId);
        requireWriter(project);
        Version version = repository.requireVersion(documentId, versionId);
        Scope scope = parseScope(rawScope);
        String source = ApiFailure.optionalText(rawSource, "执行记录来源", 500);
        Instant observedAt = parseTime(rawObservedAt, "来源记录时间");
        String filename = filename(file);
        byte[] body = read(file);
        String sha = sha256(body);
        String importKey = sha256((scope.name() + "\n" + sha + "\n" + timeText(observedAt) + "\n" + source)
                .getBytes(StandardCharsets.UTF_8));
        List<ImportRow> rows = validate(decode(body), scope, knownRequirements(version));

        projects.lock(project.id());
        requireWriter(projects.forDocument(userId, documentId));
        Integer alreadyImported = jdbc.queryForObject(
                "SELECT COUNT(*) FROM execution_batch WHERE version_id = ? AND import_key = ?",
                Integer.class, versionId, importKey);
        if (alreadyImported == 0) {
            insert(documentId, versionId, userId, scope, source, observedAt, filename, sha, importKey, rows);
        }
        return snapshot(documentId, versionId);
    }

    private void insert(String documentId, String versionId, String userId, Scope scope, String source,
                        Instant observedAt, String filename, String sha, String importKey, List<ImportRow> rows) {
        String batchId = AuditRepository.id();
        Instant recordedAt = Instant.now();
        long importNo = jdbc.queryForObject(
                "SELECT COALESCE(MAX(import_no), 0) FROM execution_batch WHERE version_id = ?", Long.class, versionId) + 1;
        jdbc.update("""
                INSERT INTO execution_batch (id, document_id, version_id, import_no, import_key, record_scope,
                  source_label, file_name, file_sha256, observed_at, imported_at, imported_by, row_count)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, batchId, documentId, versionId, importNo, importKey, scope.name(), source, filename,
                sha, timeText(observedAt), timeText(recordedAt), userId, rows.size());
        var inputs = new ArrayList<Object[]>(rows.size());
        for (ImportRow row : rows) {
            Instant effective = row.executedAt() == null ? observedAt : row.executedAt();
            if (effective == null) effective = recordedAt;
            String caseKey = sha256(key(row.testCase()).getBytes(StandardCharsets.UTF_8));
            inputs.add(new Object[]{batchId, row.line(), row.requirement(), key(row.requirement()), row.testCase(),
                caseKey, row.relatedCases(), row.status().name(), timeText(row.executedAt()),
                effective.toEpochMilli(), row.evidence()});
        }
        jdbc.batchUpdate("""
                INSERT INTO execution_record (batch_id, row_no, requirement_id, requirement_key, case_id, case_key,
                    related_case_ids, record_status, executed_at, effective_ms, evidence)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, inputs);
    }

    private Snapshot snapshot(String documentId, String versionId) {
        List<Batch> batches = jdbc.query(BATCHES + "ORDER BY b.import_no DESC", BATCH, documentId, versionId);
        List<Row> rows = jdbc.query("""
                SELECT record_scope, requirement_id, case_id, related_case_ids, record_status,
                       executed_at, evidence, batch_id
                FROM (
                    SELECT b.record_scope, r.requirement_id, r.requirement_key, r.case_id, r.case_key,
                           r.related_case_ids, r.record_status, r.executed_at, r.evidence, r.batch_id,
                           ROW_NUMBER() OVER (PARTITION BY b.record_scope, r.requirement_key, r.case_key
                             ORDER BY r.effective_ms DESC, b.import_no DESC) AS rank_no
                    FROM execution_record r JOIN execution_batch b ON b.id = r.batch_id
                    WHERE b.document_id = ? AND b.version_id = ?
                ) ranked
                WHERE rank_no = 1 ORDER BY record_scope, requirement_key, case_id
                """, ROW, documentId, versionId);
        var counts = emptyCounts();
        var summaryCounts = emptyCounts();
        for (Row row : rows) {
            var counter = row.scope() == Scope.CASE ? counts : summaryCounts;
            counter.merge(row.status(), 1, Integer::sum);
        }
        return new Snapshot(documentId, versionId, counts, summaryCounts, rows, batches);
    }

    private Map<String, String> knownRequirements(Version version) {
        var headings = version.sections().stream().collect(Collectors.toMap(Section::line, Section::level));
        Version structure = parser.parse(version.id(), version.number(), version.text(), headings, version.source());
        var trace = RequirementTrace.inspect(structure);
        Set<String> ambiguous = new HashSet<>(trace.ambiguousIds());
        Map<String, String> known = new HashMap<>();
        for (var requirement : trace.rows()) {
            String key = key(requirement.code());
            if (!ambiguous.contains(key)) known.put(key, requirement.code());
        }
        return known;
    }

    private static void requireWriter(Projects.Project project) {
        if (!project.role().mayStartReview()) {
            throw ApiFailure.forbidden("查看者可以查阅执行证据，导入需由可发起审查的项目成员操作。");
        }
    }

    private static Map<Status, Integer> emptyCounts() {
        var counts = new EnumMap<Status, Integer>(Status.class);
        for (Status status : Status.values()) counts.put(status, 0);
        return counts;
    }

    private static byte[] read(MultipartFile file) {
        if (file.isEmpty()) throw ApiFailure.badRequest("请选择包含执行记录的 CSV。");
        if (file.getSize() > MAX_FILE_BYTES) throw ApiFailure.tooLarge("执行记录 CSV 上限为 8 MB。");
        try {
            return file.getBytes();
        } catch (IOException ex) {
            throw ApiFailure.badRequest("无法读取执行记录 CSV。");
        }
    }

    private static String decode(byte[] bytes) {
        try {
            String text = StandardCharsets.UTF_8.newDecoder().decode(ByteBuffer.wrap(bytes)).toString();
            if (text.indexOf('\0') >= 0) throw ApiFailure.badRequest("CSV 含有无效控制字符。");
            return text.startsWith("\uFEFF") ? text.substring(1) : text;
        } catch (CharacterCodingException ex) {
            throw ApiFailure.badRequest("执行记录需要 UTF-8 编码的 CSV。");
        }
    }

    private static String filename(MultipartFile file) {
        String name = file.getOriginalFilename();
        if (name == null || name.isBlank()) return "执行记录.csv";
        name = name.replace('\\', '/');
        name = name.substring(name.lastIndexOf('/') + 1).strip();
        if (!name.toLowerCase(Locale.ROOT).endsWith(".csv") || name.chars().anyMatch(Character::isISOControl)) {
            throw ApiFailure.badRequest("执行记录文件必须是 CSV。");
        }
        return ApiFailure.requireText(name, "CSV 文件名", 200);
    }

    private static Scope parseScope(String input) {
        if (input == null || input.isBlank()) return Scope.CASE;
        try {
            return Scope.valueOf(key(input.strip()));
        } catch (IllegalArgumentException ex) {
            throw ApiFailure.badRequest("请选择逐用例记录或需求汇总。");
        }
    }

    private static Instant parseTime(String input, String field) {
        if (input == null || input.isBlank()) return null;
        input = input.strip();
        if (RFC3339.matcher(input).matches()) {
            try {
                return OffsetDateTime.parse(input).toInstant();
            } catch (DateTimeParseException ignored) {
                // Report the invalid field without echoing arbitrary CSV text.
            }
        }
        throw ApiFailure.badRequest(field + "应使用包含时区的 RFC 3339 时间。");
    }

    private static String timeText(Instant instant) {
        return instant == null ? null : instant.toString();
    }

    private static String sha256(byte[] input) {
        try {
            return HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(input));
        } catch (NoSuchAlgorithmException ex) {
            throw new IllegalStateException("JDK does not provide SHA-256", ex);
        }
    }

    private static String key(String id) {
        return id.toUpperCase(Locale.ROOT);
    }

    private static List<ImportRow> validate(String text, Scope scope, Map<String, String> known) {
        var reader = new Csv(text);
        RawRow header = reader.row();
        if (header == null) throw ApiFailure.badRequest("CSV 没有列名。");
        var fields = new HashMap<String, Integer>();
        for (int index = 0; index < header.fields().size(); index++) {
            String field = header.fields().get(index).strip().toLowerCase(Locale.ROOT);
            if (!HEADERS.contains(field) || fields.putIfAbsent(field, index) != null) {
                throw invalidLine(header.line(), "列名无法识别或重复。");
            }
        }
        if (!fields.keySet().containsAll(REQUIRED)) {
            throw invalidLine(header.line(), "需要 requirement_id、case_id 和 status 列。");
        }
        var rows = new ArrayList<ImportRow>();
        var pairs = new HashSet<Pair>();
        for (RawRow raw = reader.row(); raw != null; raw = reader.row()) {
            if (rows.size() >= MAX_ROWS) throw ApiFailure.tooLarge("每次最多导入 5000 条执行记录。");
            if (raw.fields().size() != fields.size()) throw invalidLine(raw.line(), "列数与表头不一致。");
            ImportRow row = validateRow(raw, fields, scope, known);
            if (!pairs.add(new Pair(key(row.requirement()), key(row.testCase())))) {
                throw invalidLine(row.line(), "同一需求和用例组合在此批次重复。");
            }
            rows.add(row);
        }
        if (rows.isEmpty()) throw ApiFailure.badRequest("CSV 中没有执行记录。");
        return rows;
    }

    private static ImportRow validateRow(RawRow raw, Map<String, Integer> fields, Scope scope,
                                         Map<String, String> known) {
        int line = raw.line();
        String requirementId = field(raw, fields, "requirement_id");
        String requirement = known.get(key(requirementId));
        if (!IDENTIFIER.matcher(requirementId).matches() || requirement == null) {
            throw invalidLine(line, "需求编号未在所选版本中唯一识别，请核对原件及目标版本。");
        }
        String testCase = field(raw, fields, "case_id");
        String related = field(raw, fields, "case_ids");
        String time = field(raw, fields, "executed_at");
        Status status = parseStatus(field(raw, fields, "status"), line);
        if (scope == Scope.CASE) {
            if (!IDENTIFIER.matcher(testCase).matches()) throw invalidLine(line, "用例编号不能为空或含不支持的字符。");
            if (!related.isEmpty()) throw invalidLine(line, "逐用例记录只填写 case_id。");
            if (status == Status.NOT_RUN && !time.isEmpty()) throw invalidLine(line, "未执行记录不可填写执行时间。");
        } else if (!testCase.isEmpty() || !time.isEmpty()) {
            throw invalidLine(line, "需求汇总不包含单条用例执行编号或执行时间，所列用例可写在 case_ids。");
        }
        String evidence = field(raw, fields, "evidence");
        if (related.length() > 500 || evidence.length() > 2_000) {
            throw invalidLine(line, "所列用例或证据说明超出长度限制。");
        }
        Instant executedAt = parseTime(time, "CSV 第 " + line + " 行的执行时间");
        return new ImportRow(line, requirement, testCase, related, status, executedAt, evidence);
    }

    private static String field(RawRow raw, Map<String, Integer> columns, String name) {
        Integer column = columns.get(name);
        return column == null ? "" : raw.fields().get(column).strip();
    }

    private static Status parseStatus(String input, int line) {
        return switch (key(input).replace(' ', '_').replace('-', '_')) {
            case "PASS", "PASSED" -> Status.PASS;
            case "FAIL", "FAILED" -> Status.FAIL;
            case "SKIP", "SKIPPED" -> Status.SKIPPED;
            case "NOT_RUN", "NOTRUN" -> Status.NOT_RUN;
            default -> throw invalidLine(line, "状态需为 PASS、FAIL、SKIPPED 或 NOT_RUN。");
        };
    }

    private static ApiFailure invalidLine(int line, String message) {
        return ApiFailure.badRequest("CSV 第 " + line + " 行：" + message);
    }

    private static final class Csv {
        private final String text;
        private int offset;
        private int line = 1;

        private Csv(String text) {
            this.text = text;
        }

        RawRow row() {
            while (offset < text.length()) {
                int startLine = line;
                List<String> fields = new ArrayList<>();
                fields.add(field());
                while (offset < text.length() && text.charAt(offset) == ',') {
                    offset++;
                    if (fields.size() >= HEADERS.size()) throw invalidLine(startLine, "列数过多。");
                    fields.add(field());
                }
                if (offset < text.length()) newline();
                if (fields.size() != 1 || !fields.get(0).isBlank()) return new RawRow(startLine, fields);
            }
            return null;
        }

        private String field() {
            if (offset < text.length() && text.charAt(offset) == '"') return quoted();
            int start = offset;
            while (offset < text.length() && !delimiter(text.charAt(offset))) {
                if (text.charAt(offset) == '"') throw invalidLine(line, "字段引号须成对并包住整个字段。");
                offset++;
            }
            return text.substring(start, offset);
        }

        private String quoted() {
            int startLine = line;
            var value = new StringBuilder();
            offset++;
            while (offset < text.length()) {
                char character = text.charAt(offset);
                if (character == '\r' || character == '\n') {
                    newline();
                    value.append('\n');
                    continue;
                }
                offset++;
                if (character == '"') {
                    if (offset == text.length() || delimiter(text.charAt(offset))) return value.toString();
                    if (text.charAt(offset) != '"') throw invalidLine(line, "字段结束引号后需接分隔符。");
                    offset++;
                }
                value.append(character);
            }
            throw invalidLine(startLine, "字段引号未闭合。");
        }

        private void newline() {
            if (text.charAt(offset++) == '\r' && offset < text.length() && text.charAt(offset) == '\n') offset++;
            line++;
        }

        private static boolean delimiter(char value) {
            return value == ',' || value == '\r' || value == '\n';
        }
    }
}
