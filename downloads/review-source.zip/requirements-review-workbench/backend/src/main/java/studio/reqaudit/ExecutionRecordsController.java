package studio.reqaudit;

import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import static studio.reqaudit.StudioAccess.ACCOUNT;

@RestController
@RequestMapping("/api/documents/{documentId}/versions/{versionId}/executions")
class ExecutionRecordsController {
    private final ExecutionRecords records;

    ExecutionRecordsController(ExecutionRecords records) {
        this.records = records;
    }

    @GetMapping
    ExecutionRecords.Snapshot list(@RequestAttribute(ACCOUNT) Accounts.User actor,
                                   @PathVariable String documentId, @PathVariable String versionId) {
        return records.list(actor.id(), documentId, versionId);
    }

    @GetMapping("/batches/{batchId}")
    ExecutionRecords.BatchDetails details(@RequestAttribute(ACCOUNT) Accounts.User actor,
                                          @PathVariable String documentId, @PathVariable String versionId,
                                          @PathVariable String batchId) {
        return records.details(actor.id(), documentId, versionId, batchId);
    }

    @PostMapping(consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    ExecutionRecords.Snapshot importFile(@RequestAttribute(ACCOUNT) Accounts.User actor,
                                         @PathVariable String documentId, @PathVariable String versionId,
                                         @RequestPart("file") MultipartFile file,
                                         @RequestParam(required = false) String scope,
                                         @RequestParam(required = false) String source,
                                         @RequestParam(required = false) String observedAt) {
        return records.importFile(actor.id(), documentId, versionId, file, scope, source, observedAt);
    }
}
