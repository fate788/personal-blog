package studio.reqaudit;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.event.EventListener;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

/** Let the Windows host operator stop Spring and the database through a per-launch local file. */
@Component
final class LocalHostShutdown {
    private static final Logger LOG = LoggerFactory.getLogger(LocalHostShutdown.class);
    private final String stopFile;
    private final JdbcTemplate jdbc;

    LocalHostShutdown(@Value("${REVIEW_HOST_STOP_FILE:}") String stopFile, JdbcTemplate jdbc) {
        this.stopFile = stopFile;
        this.jdbc = jdbc;
    }

    @EventListener
    void started(ApplicationReadyEvent event) {
        if (stopFile.isBlank()) return;
        var request = Path.of(stopFile);
        var context = event.getApplicationContext();
        var thread = new Thread(() -> watch(request, context), "local-host-control");
        thread.setDaemon(true);
        thread.start();
    }

    private void watch(Path request, ConfigurableApplicationContext context) {
        try {
            while (context.isActive()) {
                Thread.sleep(500);
                if (!Files.deleteIfExists(request)) continue;
                var jobs = jdbc.queryForObject(
                        "SELECT COUNT(*) FROM review_job WHERE job_status IN ('QUEUED','RUNNING')", Integer.class);
                if (jobs != null && jobs > 0) {
                    Files.writeString(request.resolveSibling(request.getFileName() + ".busy"), "busy");
                    continue;
                }
                context.close();
                return;
            }
        } catch (InterruptedException interrupted) {
            Thread.currentThread().interrupt();
        } catch (IOException | RuntimeException failure) {
            LOG.warn("Local service stop control ended", failure);
        }
    }
}
