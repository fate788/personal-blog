package studio.reqaudit;

import java.util.*;
import java.util.stream.Stream;

import static studio.reqaudit.Domain.*;

/** Nearby source that would otherwise be lost when the parser selects normative paragraphs. */
final class SourceNeighborhood {
    private static final int RADIUS = 32;
    private static final int MAX_LINES = 40;
    private static final int MAX_CHARS = 4_200;
    private static final int SHORT_DOCUMENT_LINES = 120;
    private static final int SHORT_DOCUMENT_CHARS = 6_000;

    static ReviewPlanner.Plan include(Version version, ReviewPlanner.Plan plan) {
        if (plan.batches().isEmpty() || version.source() == null ||
                !Set.of("MARKDOWN", "TEXT", "TXT", "RST").contains(version.source().format())) return plan;
        String[] text = version.text().split("\n", -1);
        Set<Integer> excluded = new HashSet<>();
        var parsedItems = new HashMap<Integer, Item>();
        version.items().forEach(item -> parsedItems.put(item.line(), item));
        var codeSections = new HashMap<Integer, String>();
        boolean frontMatter = text.length > 0 && text[0].strip().equals("---");
        boolean comment = false;
        String fence = "";
        int fenceStart = 0;
        for (int i = 0; i < text.length; i++) {
            String line = text[i].strip();
            if (frontMatter || comment || line.contains("<!--") || line.isEmpty()) excluded.add(i + 1);
            if (frontMatter && i > 0 && (line.equals("---") || line.equals("..."))) frontMatter = false;
            if (line.contains("<!--")) comment = true;
            if (line.contains("-->")) comment = false;
            if (excluded.contains(i + 1)) continue;
            if (!fence.isEmpty()) {
                codeSections.put(i + 1, "第" + fenceStart + "行起的代码块");
                if (line.length() >= fence.length() && line.chars().allMatch(c -> c == line.charAt(0))
                        && line.charAt(0) == fence.charAt(0)) fence = "";
            } else if (line.startsWith("```") || line.startsWith("~~~")) {
                int length = 3;
                while (length < line.length() && line.charAt(length) == line.charAt(0)) length++;
                fence = line.substring(0, length);
                fenceStart = i + 1;
                codeSections.put(i + 1, "第" + fenceStart + "行起的代码块");
            }
        }
        var result = new ArrayList<ReviewPlanner.Batch>();
        for (var batch : plan.batches()) {
            int used = Stream.concat(batch.primary().stream(), batch.context().stream()).mapToInt(x -> x.text().length()).sum();
            int available = ReviewPlanner.MAX_TOTAL_CHARS - used;
            var supplied = new HashSet<Integer>();
            Stream.concat(batch.primary().stream(), batch.context().stream()).forEach(item -> supplied.add(item.line()));
            boolean shortDocument = text.length <= SHORT_DOCUMENT_LINES && version.text().length() <= Math.min(SHORT_DOCUMENT_CHARS, available);
            var distance = new HashMap<Integer, Integer>();
            if (shortDocument) {
                // A short source fits without dropping the body or result of a worked example, even across sections.
                for (int n = 1; n <= text.length; n++) {
                    if (!excluded.contains(n) && !supplied.contains(n)) distance.put(n, 0);
                }
            } else {
                for (Item primary : batch.primary()) {
                    for (int n = Math.max(1, primary.line() - RADIUS); n <= Math.min(text.length, primary.line() + RADIUS); n++) {
                        if (!excluded.contains(n) && !parsedItems.containsKey(n)) distance.merge(n, Math.abs(n - primary.line()), Math::min);
                    }
                }
            }
            int budget = Math.min(available, shortDocument ? SHORT_DOCUMENT_CHARS : MAX_CHARS);
            int lineLimit = shortDocument ? SHORT_DOCUMENT_LINES : MAX_LINES;
            var lines = new ArrayList<Item>();
            for (int n : distance.keySet().stream().sorted(Comparator.<Integer>comparingInt(distance::get).thenComparingInt(x -> x)).toList()) {
                String source = text[n - 1];
                if (source.length() > budget) continue;
                var parsed = parsedItems.get(n);
                lines.add(parsed != null ? parsed : new Item("item-" + n, "L-" + n, source, n, codeSections.getOrDefault(n, "邻近原文")));
                budget -= source.length();
                if (lines.size() == lineLimit || budget == 0) break;
            }
            lines.sort(Comparator.comparingInt(Item::line));
            result.add(new ReviewPlanner.Batch(batch.number(), batch.primary(), batch.context(), List.copyOf(lines)));
        }
        return new ReviewPlanner.Plan(List.copyOf(result), plan.plannedBatches(), plan.batchLimit(),
                plan.overBudgetItemIds(), plan.oversizedItemIds());
    }
}
