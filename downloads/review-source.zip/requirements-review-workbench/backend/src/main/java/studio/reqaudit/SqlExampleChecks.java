package studio.reqaudit;

import java.util.List;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Pattern;

import static studio.reqaudit.Domain.*;

/** Compare a single literal SELECT with the result table printed immediately after it. */
final class SqlExampleChecks {
    private static final Pattern SIGNATURE = Pattern.compile("(?i)^([a-z_][a-z0-9_]*)\\s*\\(\\s*<.+\\)\\s*;?$");
    private static final Pattern SELECT = Pattern.compile("(?i)^select\\s+([a-z_][a-z0-9_]*)\\s*\\((.*)\\)\\s*;?$");
    private static final Pattern HEADER = Pattern.compile("(?i)^\\|\\s*([a-z_][a-z0-9_]*)\\s*\\((.*)\\)\\s*\\|$");
    private static final Pattern ARGUMENT = Pattern.compile("\\s*('(?:[^'\\\\]++|'')*+'|[+-]?\\d++(?:\\.\\d++)?|(?i:true|false|null))\\s*(,|$)");
    private static final Pattern BORDER = Pattern.compile("\\+-+\\+");
    private static final Pattern DIFFERENT_NAMES = Pattern.compile("示例查询调用 (\\w+)，紧随其后的结果列和文档语法写的是 (\\w+)");
    private static final Pattern FUNCTION_NAME = Pattern.compile("函数名|调用的函数|调用函数|\\bfunction name\\b",Pattern.CASE_INSENSITIVE);
    private static final Pattern MISMATCH = Pattern.compile("不一致|不匹配|不同|错用|用错|混用|对不上|\\bmismatch\\b",Pattern.CASE_INSENSITIVE);
    private static final Pattern OTHER_DEFECT = Pattern.compile("参数(?:数量|类型|顺序|取值)|返回类型|溢出|精度|行数|空值|权限");
    record ReportEvidence(List<Finding> findings, List<RuleWarning> warnings, int merged) {}
    private String documentedName;
    private int lastQueryClose = -1;
    private int queryLine;
    private String queryFunction;
    private List<String> queryArgs;

    RuleWarning block(String language, String[] lines, int start, int end, boolean syntaxSection) {
        if (language.equals("sql")) {
            lastQueryClose = -1;
            if (end != start + 1 || lines[start].length() > 4000) return null;
            String statement = lines[start].strip();
            if (syntaxSection) {
                var signature = SIGNATURE.matcher(statement);
                if (signature.matches()) documentedName = signature.group(1);
                return null;
            }
            var select = SELECT.matcher(statement);
            if (!select.matches() || documentedName == null) return null;
            queryArgs = arguments(select.group(2));
            if (queryArgs.isEmpty()) return null;
            queryFunction = select.group(1);
            queryLine = start + 1;
            lastQueryClose = end;
            return null;
        }
        if (!language.matches("text|plaintext|console|") || lastQueryClose < 0 || end - start < 4) return null;
        for (int line = lastQueryClose + 1; line < start - 1; line++) if (!lines[line].isBlank()) return null;
        if (!BORDER.matcher(lines[start].strip()).matches() || !lines[start].strip().equals(lines[start + 2].strip())
                || lines[start + 1].length() > 4000) return null;
        var header = HEADER.matcher(lines[start + 1].strip());
        if (!header.matches() || !header.group(1).equalsIgnoreCase(documentedName)
                || header.group(1).equalsIgnoreCase(queryFunction) || !queryArgs.equals(arguments(header.group(2)))) return null;
        return new RuleWarning("SQL_EXAMPLE_FUNCTION_MISMATCH",
                "示例查询调用 " + queryFunction + "，紧随其后的结果列和文档语法写的是 " + documentedName
                        + "。参数相同，请核对查询与结果是否配对。", queryLine, start + 2);
    }

    private static List<String> arguments(String text) {
        var tokens = new java.util.ArrayList<String>();
        var matcher = ARGUMENT.matcher(text);
        int position = 0;
        while (position < text.length()) {
            matcher.region(position, text.length());
            if (!matcher.lookingAt()) return List.of();
            String value = matcher.group(1);
            tokens.add(value.startsWith("'") ? value : value.toLowerCase(Locale.ROOT));
            position = matcher.end();
            if (position == text.length() && !matcher.group(2).isEmpty()) return List.of();
        }
        return tokens;
    }

    static ReportEvidence group(List<Finding> findings, List<RuleWarning> warnings, boolean generalModel) {
        return group(findings, warnings, generalModel, null);
    }

    static ReportEvidence group(List<Finding> findings, List<RuleWarning> warnings, boolean generalModel, ExecutionStrategy strategy) {
        boolean combined = strategy == ExecutionStrategy.COMBINED;
        List<RuleWarning> sourceChecks = generalModel || combined ? warnings.stream()
                .filter(w -> w.type().equals("SQL_EXAMPLE_FUNCTION_MISMATCH") && w.relatedLine() != null).toList() : List.of();
        if (sourceChecks.isEmpty()) return new ReportEvidence(List.copyOf(findings), warnings, 0);
        Map<RuleWarning, String> represented = new HashMap<>();
        List<Finding> kept = new ArrayList<>();
        for (Finding finding : findings) {
            RuleWarning match = sourceChecks.stream().filter(w -> matchesFinding(w, finding)
                    && (!combined || finding.evidence().stream().noneMatch(e -> e.line() <= 0))).findFirst().orElse(null);
            if (match == null || represented.putIfAbsent(match, finding.id()) == null) kept.add(finding);
        }
        // Combined reports retain the rule and its identity even if a reviewer later rejects the model's explanation.
        var remaining = combined ? warnings.stream().map(w -> represented.containsKey(w)
                ? new RuleWarning(w.type(), w.detail(), w.line(), w.relatedLine(), represented.get(w)) : w).toList()
                : warnings.stream().filter(w -> !represented.containsKey(w)).toList();
        return new ReportEvidence(List.copyOf(kept), remaining, findings.size() - kept.size() + represented.size());
    }

    static boolean matchesFinding(RuleWarning warning, Finding finding) {
        if (finding.status() != FindingStatus.ISSUE || finding.validationKind() != ValidationKind.DOCUMENT
                || !FUNCTION_NAME.matcher(finding.title()).find() || !MISMATCH.matcher(finding.title()).find()
                || OTHER_DEFECT.matcher(finding.title()).find()) return false;
        var names = DIFFERENT_NAMES.matcher(warning.detail());
        if (!names.find()) return false;
        String called = names.group(1).toLowerCase(Locale.ROOT), documented = names.group(2).toLowerCase(Locale.ROOT);
        String reason = finding.reason().toLowerCase(Locale.ROOT);
        if (!reason.contains(called) || !reason.contains(documented)) return false;
        return finding.evidence().stream().anyMatch(e -> e.line() == warning.line() && e.quote().toLowerCase(Locale.ROOT).contains(called + "("))
                && finding.evidence().stream().anyMatch(e -> e.line() == warning.relatedLine() && e.quote().toLowerCase(Locale.ROOT).contains(documented + "("));
    }
}
