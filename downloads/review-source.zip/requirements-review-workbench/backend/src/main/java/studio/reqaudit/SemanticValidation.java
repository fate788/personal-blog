package studio.reqaudit;

import java.math.BigDecimal;
import java.text.Normalizer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import static studio.reqaudit.Domain.*;
import static studio.reqaudit.Domain.FindingStatus.INSUFFICIENT;
import static studio.reqaudit.Domain.FindingStatus.ISSUE;
import static studio.reqaudit.Domain.FindingStatus.PASS;

final class SemanticValidation {
    private static final Pattern CONDITIONAL = Pattern.compile(
            "(?iu)\\b(?:if|when|unless|except|provided|during|before|after|while|until|for\\s+each)\\b"
                    + "|当|如果|若|除非|仅在|仅当|仅限|之后|之前|期间|条件下|时段");
    private static final String NUMBER = "([+−-]?\\d{1,12}(?:\\.\\d{1,6})?)";
    private static final Pattern EQUATION = Pattern.compile(
            "^\\s*" + NUMBER + "\\s*([+−\\-*/×÷])\\s*" + NUMBER + "\\s*[=＝]\\s*" + NUMBER + "\\s*$");
    private static final Pattern BOUND = Pattern.compile(
            "^\\s*(.{1,80}?)\\s*(<=|>=|[<>≤≥=])\\s*" + NUMBER + "\\s*([\\p{L}%]+)?\\s*$");
    private static final Pattern ALIAS = Pattern.compile(
            "(?iu)\\b(?:name|refers to|known as|defined as|means)\\b|简称|指代|称为|定义为|属性名"
                    + "|^[a-z][a-z0-9_-]{1,40}\\s*=");
    private static final Pattern DEMONSTRATIVE = Pattern.compile("(?iu)^(?:this|that|the\\s+current)\\s+(.+)$|^(?:该|此)(.+)$");
    private static final Pattern DISJUNCTION = Pattern.compile("(?iu)\\s+or\\s+|或者|或");
    private static final Pattern NAMED_ALTERNATIVE = Pattern.compile("(?iu)^[a-z_][a-z0-9_-]*$");
    private static final Pattern SCOPE_LABEL = Pattern.compile("(?iu)^(?:component|property|attribute|field|parameter|element) name:\\s*"
            + "|^(?:(?:inside|within|in|for) (?:an? |the )?|the )"
            + "|\\s+(?:calendar )?(?:components?|properties|attributes?|fields?|parameters?|elements?)$");
    private static final Pattern REPEAT_ALLOWED = Pattern.compile("(?iu)\\b(?:may|can|must|shall)\\s+"
            + "(?:occur|be specified|be included|appear)\\s+more than once\\b");
    private static final Pattern ONE_ONLY = Pattern.compile("(?iu)\\b(?:at most once|only once|no more than once|"
            + "(?:must|shall) not\\b.{0,45}more than once)\\b");
    private static final Pattern CONFORMANCE_ONCE = Pattern.compile("(?iu)\\b(?:can|may)\\s+(?:occur|be specified|be included|appear) once\\b");
    private static final Pattern POSITIVE_OCCURRENCE = Pattern.compile("(?iu)\\b(?:can|may)\\s+(?:occur|be specified|be included|appear)(?=\\s+(?:in|within|for)\\b|[.。;；]|$)");
    private static final Pattern QUALIFIER = Pattern.compile("(?iu)\\b(?:not|never|except|unless|only|once|twice|maximum|minimum|must|shall|requires?)\\b|\\d|不得|仅当|除非");
    private static final Pattern DEFINITION = Pattern.compile("(?iu)\\b(?:corresponds? to|represents?|denotes?|is interpreted as)\\b");
    private static final Pattern PROHIBITED_USE = Pattern.compile("(?iu)\\b(?:must not|shall not)\\s+(?:be (?:specified|used|set|included)|specify|use|set|include)\\b");
    private static final Pattern EXCEPTION = Pattern.compile("(?iu)\\b(?:invalid|otherwise|fallback|unless|except|override|deprecated)\\b|无效|除非|例外");
    private static final Pattern SCALAR_FIELD = Pattern.compile("(?i)^\\s*\\|\\s*`?([a-z_][a-z0-9_-]*)`?\\s*\\|\\s*`?(?:string|varchar|text)`?\\s*\\|");
    private static final Pattern MANY = Pattern.compile("(?iu)多个|多值|多选|多项|批量|数组|列表|\\b(?:multiple|multi-value|batch|array|list)\\b");
    private static final Pattern ENCODING = Pattern.compile("(?iu)分隔|分割|多次传|重复传|拼接|逗号|分号|\\b(?:delimiter|separator|repeat(?:ed)? parameter)\\b");
    private static final Pattern RETURN_VALUE = Pattern.compile("(?iu)(?:返回|得到|输出|returns?)\\s*`?(NULL|TRUE|FALSE|[45]\\d{2}|空值|空数组)(?![\\w])");
    private static final Pattern CONDITIONAL_ROW = Pattern.compile("(?iu)^\\s*(?:[-*]|\\d+[.、)])\\s*(?:如果|若|当|如遇|仅在|在|if\\b|when\\b|unless\\b)");
    private static final Pattern SUMMARY = Pattern.compile("(?iu)某些情况|部分情况|以下情[形况]|下列情[形况]|详见|\\b(?:in some cases|in the following cases|see below)\\b");
    private static final Pattern LOCAL_COMPLETENESS = Pattern.compile("只看|单看|仅看|单独阅读|没有直接列|未直接列|没有在.{0,8}(?:本|这|同一)(?:段|节|处)|未在.{0,8}(?:本|这|同一)(?:段|节|处)");
    private static final Pattern DISTINCT_CONCERN = Pattern.compile("(?iu)优先级|发生顺序|同时满足|另一个条件|另外一个|既.{0,8}又|最大长度|大小写|截断|转义|空字符串|\\b(?:precedence|priority|truncation|escaping)\\b");
    private static final Set<String> GRAMMAR = Set.of("a", "an", "the", "is", "are", "be", "to", "in", "with", "by",
            "for", "of", "from", "on", "at", "when", "if", "rule", "part", "shall", "must", "may", "can");

    record Result(FindingStatus status, ValidationKind kind, ConflictComparison comparison, List<String> pair,
                  String diagnostic, String title, String reason, String suggestion) {}

    private SemanticValidation() {}

    static Result verify(Assessment result, Map<String, Item> allowed, List<Evidence> evidence, boolean modelRun) {
        ValidationKind kind = result.validationKind() == null ? ValidationKind.DOCUMENT : result.validationKind();
        boolean conflict = AuditCatalog.CONFLICT.id().equals(result.ruleId()) || kind == ValidationKind.CONFLICT;
        if (!modelRun) return original(result, conflict ? ValidationKind.CONFLICT : kind, null, List.of());
        if (kind == ValidationKind.EXTERNAL_FACT && (result.status() == ISSUE || result.status() == PASS)) {
            return insufficient(kind, "EXTERNAL_FACT_UNVERIFIED", "外部事实需独立核验",
                    "现有送审材料只能定位原文中的事实或标准表述。当前任务没有经批准的外部来源来验证该表述。",
                    "补充权威出处、版本和适用范围，再由评审人员核对。");
        }
        if (result.status() == INSUFFICIENT && conflict && result.comparison() != null) {
            return verifyConflict(result, allowed, evidence);
        }
        if (result.status() != ISSUE) return original(result, kind, null, List.of());
        if (conflict) return verifyConflict(result, allowed, evidence);
        if (kind == ValidationKind.INTERNAL_CALCULATION) return verifyCalculation(result, evidence);
        if (kind == ValidationKind.DOCUMENT && DocumentScope.advisoryHeadingOnly(result, allowed, evidence)) {
            return notSupported(kind, "ADVISORY_HEADING_ONLY");
        }
        if (kind == ValidationKind.DOCUMENT && Set.of("R-01", "R-06", "R-08").contains(result.ruleId())) {
            if (unsupportedMultiplicity(result, allowed, evidence)) {
                return insufficient(kind, "MULTIVALUE_PREMISE_MISSING", "多值输入的前提待确认",
                        "已引用的契约只声明一个标量值，缺少该字段支持同时提交多个值的约定。",
                        "若团队确实要求批量输入，请补充该要求，再核对格式。");
            }
            if (summaryHasConditions(result, allowed, evidence)) return notSupported(kind, "SUMMARY_EXPLAINED_IN_CONTEXT");
        }
        return original(result, kind, null, List.of());
    }

    private static boolean unsupportedMultiplicity(Assessment assessment, Map<String, Item> allowed, List<Evidence> evidence) {
        Item target = allowed.get(assessment.itemId());
        if (target == null || !MANY.matcher(assessment.reason()).find() || !ENCODING.matcher(assessment.reason()).find()
                || DISTINCT_CONCERN.matcher(assessment.reason()).find()) return false;
        var field = SCALAR_FIELD.matcher(target.text());
        if (!field.find()) return false;
        String name = Pattern.quote(field.group(1));
        var mention = Pattern.compile("(?i)(?<![\\w-])" + name + "(?![\\w-])");
        var multiExample = Pattern.compile("(?iu)" + name + "[\"'`]?\\s*[:=]\\s*(?:\\[|[\"']?[^\\s\"',;&]{1,60}[,;，、][^\\s\"',;&])");
        var assign = Pattern.compile("(?i)(?<![\\w-])" + name + "\\s*=");
        long assignments = 0;
        for (Item item : allowed.values()) {
            if (!mention.matcher(item.text()).find()) continue;
            assignments += assign.matcher(item.text()).results().limit(2).count();
            if (MANY.matcher(item.text()).find() || ENCODING.matcher(item.text()).find()
                    || multiExample.matcher(item.text()).find() || assignments > 1) return false;
        }
        return evidence.stream().noneMatch(entry -> MANY.matcher(entry.quote()).find() || ENCODING.matcher(entry.quote()).find());
    }

    private static boolean summaryHasConditions(Assessment assessment, Map<String, Item> allowed, List<Evidence> evidence) {
        Item summary = allowed.get(assessment.itemId());
        if (summary == null || !SUMMARY.matcher(summary.text()).find() || !LOCAL_COMPLETENESS.matcher(assessment.reason()).find()
                || DISTINCT_CONCERN.matcher(assessment.reason()).find()) return false;
        var outcome = RETURN_VALUE.matcher(summary.text());
        if (!outcome.find()) return false;
        String value = outcome.group(1);
        // Use the exact conditional rows cited by the reviewer. A single example cannot establish the scope of a rule.
        return evidence.stream().map(e -> allowed.get(e.itemId())).filter(Objects::nonNull).distinct()
                .filter(item -> item.line() > summary.line() && item.line() - summary.line() <= 10)
                .filter(item -> sectionParent(item.section()).equals(sectionParent(summary.section())))
                .filter(item -> CONDITIONAL_ROW.matcher(item.text()).find())
                .filter(item -> RETURN_VALUE.matcher(item.text()).results().anyMatch(m -> value.equalsIgnoreCase(m.group(1))))
                .limit(2).count() == 2;
    }

    private static String sectionParent(String section) {
        int boundary = section.lastIndexOf(" / ");
        return boundary < 0 ? "" : section.substring(0, boundary);
    }

    private static Result verifyConflict(Assessment result, Map<String, Item> allowed, List<Evidence> evidence) {
        var proof = result.comparison();
        if (proof == null) return unproved("CONFLICT_PROOF_MISSING");
        var left = proof.left();
        var right = proof.right();
        if (left.itemId().equals(right.itemId())
                || !result.itemId().equals(left.itemId()) && !result.itemId().equals(right.itemId())
                || evidence.stream().noneMatch(entry -> entry.itemId().equals(left.itemId()))
                || evidence.stream().noneMatch(entry -> entry.itemId().equals(right.itemId()))) {
            return unproved("INVALID_CONFLICT_PROOF");
        }
        Item leftItem = allowed.get(left.itemId());
        Item rightItem = allowed.get(right.itemId());
        List<ProposedEvidence> links = proof.scopeEvidence();
        if (!anchored(leftItem, left) || !anchored(rightItem, right)
                || links.stream().anyMatch(link -> !allowed.containsKey(link.itemId())
                        || !allowed.get(link.itemId()).text().contains(link.quote()))) {
            return unproved("INVALID_CONFLICT_PROOF");
        }
        var relations = List.of(proof.subject(), proof.object(), proof.activity(), proof.condition());
        if (relations.contains(ScopeRelation.DISJOINT) || proof.consequence() == ConsequenceRelation.COMPATIBLE) {
            return result.status() == ISSUE ? notSupported(ValidationKind.CONFLICT, "CONFLICT_NOT_SUPPORTED")
                    : original(result, ValidationKind.CONFLICT, proof, List.of());
        }
        var capability = DocumentScope.capabilityConflict(proof, leftItem, rightItem, evidence, allowed);
        if (capability != null) {
            var pair = List.of(left.itemId(), right.itemId()).stream().sorted().toList();
            String object = capability.left().objectQuote(), action = capability.left().activityQuote();
            return new Result(ISSUE, ValidationKind.CONFLICT, capability, pair, "CAPABILITY_CONFLICT_VERIFIED",
                    "两处对“" + object + "”能否" + action + "的说明不一致", capability.sharedScenario(),
                    "请确认允许该操作的条件，并在两处说明中使用相同口径。");
        }
        var unresolved = new ArrayList<String>();
        boolean subjectCondition = sharedNamedAlternative(left.subjectQuote(), right.subjectQuote());
        if (proof.subject() != ScopeRelation.OVERLAP || !subjectCondition
                && !related(left.subjectQuote(), right.subjectQuote(), leftItem, rightItem, links, allowed)) {
            unresolved.add("适用主体");
        }
        if (proof.object() != ScopeRelation.OVERLAP
                || !related(left.objectQuote(), right.objectQuote(), leftItem, rightItem, links, allowed)) {
            unresolved.add("约束对象");
        }
        boolean sameCondition = sameCondition(leftItem, rightItem, left.conditionQuote(), right.conditionQuote(), links, allowed)
                || subjectCondition && componentCondition(left, right, leftItem, rightItem);
        if (proof.condition() != ScopeRelation.OVERLAP || !sameCondition) {
            unresolved.add("适用条件");
        }
        boolean repeatConflict = allowsRepeat(left) && limitsToOne(right, rightItem)
                || allowsRepeat(right) && limitsToOne(left, leftItem);
        boolean repeatCompatible = repeatCompatible(left, right, rightItem) || repeatCompatible(right, left, leftItem);
        if (proof.activity() != ScopeRelation.OVERLAP
                || !related(left.activityQuote(), right.activityQuote(), leftItem, rightItem, links, allowed)
                && !repeatConflict && !repeatCompatible
                && !definitionAndProhibition(left, right)
                && !definitionAndProhibition(right, left)) {
            unresolved.add("约束行为");
        }
        if (proof.consequence() != ConsequenceRelation.INCOMPATIBLE || proof.sharedScenario().isBlank()) {
            unresolved.add("互斥结果");
        }
        if (!unresolved.isEmpty()) {
            return new Result(INSUFFICIENT, ValidationKind.CONFLICT, proof, List.of(), "CONFLICT_SCOPE_UNVERIFIED",
                    "跨条款一致性需补充适用范围", "已定位两处原文。待核对" + String.join("、", unresolved) + "。",
                    "补充同一场景下两处生效条款的原文，再判定是否冲突。");
        }
        if (result.status() == INSUFFICIENT) return original(result, ValidationKind.CONFLICT, proof, List.of());
        if (same(left.consequenceQuote(), right.consequenceQuote())
                || compatibleNumericBounds(left.consequenceQuote(), right.consequenceQuote())
                || repeatCompatible) {
            return notSupported(ValidationKind.CONFLICT, "CONFLICT_NOT_SUPPORTED");
        }
        var pair = List.of(left.itemId(), right.itemId()).stream().sorted().toList();
        return new Result(ISSUE, ValidationKind.CONFLICT, proof, pair, null, result.title(), result.reason(),
                "请需求负责人确认当两处约束同时生效时采用的口径，并同步对应条款和验收场景。");
    }

    private static boolean anchored(Item item, ComparisonSide side) {
        if (item == null) return false;
        return List.of(side.subjectQuote(), side.objectQuote(), side.activityQuote())
                .stream().allMatch(quote -> !quote.isBlank() && sourceContains(item, quote))
                && !side.consequenceQuote().isBlank() && item.text().contains(side.consequenceQuote())
                && (side.conditionQuote().isBlank() || sourceContains(item, side.conditionQuote()));
    }

    private static boolean sourceContains(Item item, String quote) {
        return item.text().contains(quote) || item.section().contains(quote);
    }

    private static boolean sharedNamedAlternative(String left, String right) {
        var lhs = namedAlternatives(left);
        var rhs = namedAlternatives(right);
        return !lhs.isEmpty() && lhs.stream().anyMatch(rhs::contains);
    }

    private static List<String> namedAlternatives(String quote) {
        var alternatives = Arrays.stream(DISJUNCTION.split(quote))
                .map(part -> normalize(SCOPE_LABEL.matcher(part.strip()).replaceAll("")))
                .toList();
        return alternatives.stream().allMatch(part -> NAMED_ALTERNATIVE.matcher(part).matches())
                ? alternatives : List.of();
    }

    private static boolean componentCondition(ComparisonSide left, ComparisonSide right, Item leftItem, Item rightItem) {
        var lhs = namedAlternatives(left.conditionQuote());
        var rhs = namedAlternatives(right.conditionQuote());
        if (lhs.isEmpty() && rhs.isEmpty()) return false;
        var leftSubjects = namedAlternatives(left.subjectQuote());
        var rightSubjects = namedAlternatives(right.subjectQuote());
        if (lhs.isEmpty() && !left.conditionQuote().isBlank() || rhs.isEmpty() && !right.conditionQuote().isBlank()) return false;
        if (lhs.isEmpty() && CONDITIONAL.matcher(leftItem.text()).find()
                || rhs.isEmpty() && CONDITIONAL.matcher(rightItem.text()).find()) return false;
        return leftSubjects.stream().anyMatch(name -> rightSubjects.contains(name)
                && (lhs.isEmpty() || lhs.contains(name)) && (rhs.isEmpty() || rhs.contains(name)));
    }

    private static boolean allowsRepeat(ComparisonSide side) {
        return REPEAT_ALLOWED.matcher(side.consequenceQuote()).find() && !EXCEPTION.matcher(side.consequenceQuote()).find();
    }

    private static boolean limitsToOne(ComparisonSide side, Item item) {
        String quote = side.consequenceQuote();
        return ONE_ONLY.matcher(quote).find() || CONFORMANCE_ONCE.matcher(quote).find()
                && (item.text().toLowerCase(Locale.ROOT).contains("conformance:")
                || item.section().toLowerCase(Locale.ROOT).endsWith("conformance"));
    }

    private static boolean repeatCompatible(ComparisonSide repeated, ComparisonSide other, Item otherItem) {
        if (!allowsRepeat(repeated) || limitsToOne(other, otherItem)) return false;
        String outcome = other.consequenceQuote();
        if (allowsRepeat(other)) return true;
        var declared = POSITIVE_OCCURRENCE.matcher(otherItem.text());
        return declared.find() && outcome.contains(declared.group())
                && !QUALIFIER.matcher(otherItem.text().replaceFirst("^[A-Za-z]+-\\d+\\s*:\\s*", "")).find();
    }

    private static boolean definitionAndProhibition(ComparisonSide defined, ComparisonSide prohibited) {
        String definition = defined.consequenceQuote();
        String prohibition = prohibited.consequenceQuote();
        return !defined.conditionQuote().isBlank() && !prohibited.conditionQuote().isBlank()
                && DEFINITION.matcher(definition).find() && !EXCEPTION.matcher(definition).find()
                && PROHIBITED_USE.matcher(prohibition).find() && !EXCEPTION.matcher(prohibition).find();
    }

    private static boolean sameCondition(Item leftItem, Item rightItem, String left, String right,
                                         List<ProposedEvidence> links, Map<String, Item> allowed) {
        if (left.isBlank() && right.isBlank()) {
            return !CONDITIONAL.matcher(leftItem.text()).find() && !CONDITIONAL.matcher(rightItem.text()).find();
        }
        if (left.isBlank() || right.isBlank()) return false;
        if (related(left, right, leftItem, rightItem, links, allowed)) return true;
        // Only consider a common branch when each side's polarity and named predicate agree.
        return Arrays.stream(DISJUNCTION.split(left)).anyMatch(a ->
                Arrays.stream(DISJUNCTION.split(right)).anyMatch(b -> {
                    Set<String> branch = conditionWords(a);
                    return !branch.isEmpty() && branch.equals(conditionWords(b));
                }));
    }

    private static Set<String> conditionWords(String phrase) {
        Set<String> tokens = words(phrase);
        if (!tokens.contains("not") && !tokens.contains("absent")) tokens.remove("present");
        return tokens;
    }

    private static boolean related(String left, String right, Item leftItem, Item rightItem,
                                   List<ProposedEvidence> links, Map<String, Item> allowed) {
        if (same(left, right) || equalWords(left, right)) return true;
        if (sectionAlias(left, right, leftItem) || sectionAlias(right, left, rightItem)) return true;
        for (ProposedEvidence link : links) {
            if (!ALIAS.matcher(link.quote()).find()) continue;
            Set<String> bridge = words(link.quote());
            if (bridge.containsAll(words(left)) && bridge.containsAll(words(right))
                    && !words(left).isEmpty() && !words(right).isEmpty()) return true;
            Item location = allowed.get(link.itemId());
            if (isAlias(left, right, leftItem, location, bridge) || isAlias(right, left, rightItem, location, bridge)) {
                return true;
            }
        }
        return false;
    }

    private static boolean sectionAlias(String phrase, String name, Item location) {
        Set<String> defined = words(name);
        return DEMONSTRATIVE.matcher(normalize(phrase)).matches() && location.text().contains(phrase)
                && !defined.isEmpty() && words(location.section()).containsAll(defined);
    }

    private static boolean isAlias(String reference, String identifier, Item source, Item location, Set<String> bridge) {
        var match = DEMONSTRATIVE.matcher(normalize(reference));
        if (!match.matches() || !source.section().equals(location.section()) || Math.abs(source.line() - location.line()) > 24) {
            return false;
        }
        Set<String> noun = words(match.group(1) == null ? match.group(2) : match.group(1));
        Set<String> name = words(identifier);
        return !noun.isEmpty() && !name.isEmpty() && bridge.containsAll(noun) && bridge.containsAll(name);
    }

    private static boolean equalWords(String left, String right) {
        Set<String> lhs = words(left);
        return !lhs.isEmpty() && lhs.equals(words(right));
    }

    private static Set<String> words(String text) {
        return Arrays.stream(normalize(text).split("[^\\p{L}\\p{N}_-]+"))
                .filter(word -> !word.isBlank()).map(SemanticValidation::stem)
                .filter(word -> !GRAMMAR.contains(word)).collect(Collectors.toSet());
    }

    private static String stem(String word) {
        if (word.matches("occur(?:s|red|ring|rence|rences)?")) return "present";
        if (Set.of("present", "specify", "specified", "included").contains(word)) return "present";
        if (word.endsWith("ies") && word.length() > 4) return word.substring(0, word.length() - 3) + "y";
        if (word.endsWith("s") && !word.endsWith("ss") && word.length() > 3) return word.substring(0, word.length() - 1);
        return word;
    }

    private static boolean same(String left, String right) {
        String normalizedLeft = normalize(left);
        return !normalizedLeft.isBlank() && normalizedLeft.equals(normalize(right));
    }

    private static String normalize(String text) {
        return Normalizer.normalize(text, Normalizer.Form.NFKC).toLowerCase(Locale.ROOT)
                .strip().replaceAll("\\s+", " ").replaceAll("^[`\"“‘]+|[。.!！`\"”’]+$", "").strip();
    }

    private static boolean compatibleNumericBounds(String left, String right) {
        var lhs = BOUND.matcher(normalize(left));
        var rhs = BOUND.matcher(normalize(right));
        if (!lhs.matches() || !rhs.matches() || !same(lhs.group(1), rhs.group(1))
                || !Objects.equals(lhs.group(4), rhs.group(4))) return false;
        String leftOp = lhs.group(2);
        String rightOp = rhs.group(2);
        BigDecimal leftValue = decimal(lhs.group(3));
        BigDecimal rightValue = decimal(rhs.group(3));
        if (leftOp.equals("=")) return accepts(rightOp, leftValue, rightValue);
        if (rightOp.equals("=")) return accepts(leftOp, rightValue, leftValue);
        boolean lower = leftOp.equals(">") || leftOp.equals(">=") || leftOp.equals("≥");
        boolean sameDirection = lower == (rightOp.equals(">") || rightOp.equals(">=") || rightOp.equals("≥"));
        if (sameDirection) return true;
        BigDecimal min = lower ? leftValue : rightValue;
        BigDecimal max = lower ? rightValue : leftValue;
        int order = min.compareTo(max);
        return order < 0 || (order == 0 && !List.of(">", "<").contains(leftOp) && !List.of(">", "<").contains(rightOp));
    }

    private static boolean accepts(String operator, BigDecimal value, BigDecimal boundary) {
        int order = value.compareTo(boundary);
        return switch (operator) {
            case "=" -> order == 0;
            case ">" -> order > 0;
            case "<" -> order < 0;
            case ">=", "≥" -> order >= 0;
            case "<=", "≤" -> order <= 0;
            default -> false;
        };
    }

    private static Result verifyCalculation(Assessment result, List<Evidence> evidence) {
        String quote = result.calculationQuote() == null ? "" : result.calculationQuote();
        var match = EQUATION.matcher(Normalizer.normalize(quote, Normalizer.Form.NFKC));
        if (!match.matches() || evidence.stream().noneMatch(entry -> entry.itemId().equals(result.itemId())
                && entry.quote().contains(quote))) {
            return insufficient(ValidationKind.INTERNAL_CALCULATION, "CALCULATION_UNVERIFIED", "计算依据待核对",
                    "原文证据尚未给出可逐字定位的简单数值等式。依赖外部数值、单位换算或舍入的结论需另行核验。",
                    "补充原文中的计算式、单位、舍入口径及输入来源。");
        }
        BigDecimal left = decimal(match.group(1));
        BigDecimal right = decimal(match.group(3));
        BigDecimal asserted = decimal(match.group(4));
        String operator = match.group(2);
        if ((operator.equals("/") || operator.equals("÷")) && right.signum() == 0) {
            return insufficient(ValidationKind.INTERNAL_CALCULATION, "CALCULATION_UNVERIFIED", "计算条件待确认",
                    "原文等式的除数为零，无法按普通除法核验结果。", "请确认是否允许零值及应采用的异常规则。");
        }
        boolean matches = switch (operator) {
            case "+" -> left.add(right).compareTo(asserted) == 0;
            case "-", "−" -> left.subtract(right).compareTo(asserted) == 0;
            case "*", "×" -> left.multiply(right).compareTo(asserted) == 0;
            case "/", "÷" -> right.multiply(asserted).compareTo(left) == 0;
            default -> throw new IllegalStateException("计算运算符无效。");
        };
        if (matches) return notSupported(ValidationKind.INTERNAL_CALCULATION, "CALCULATION_MATCH");
        return new Result(ISSUE, ValidationKind.INTERNAL_CALCULATION, null, List.of(), null,
                "原文数值等式与计算不符", "审查系统复算了引用中的字面等式，等号两侧不相等。",
                "请需求负责人核对原始输入、运算关系和应记录的结果。");
    }

    private static BigDecimal decimal(String value) {
        return new BigDecimal(value.replace('−', '-'));
    }

    private static Result unproved(String diagnostic) {
        return insufficient(ValidationKind.CONFLICT, diagnostic, "跨条款一致性需补充适用范围",
                "当前证据未共同明确发生冲突时的主体、对象、动作或阶段、条件及不可同时满足的结果。",
                "补充同一场景下两处生效条款的原文，再判定是否冲突。");
    }

    private static Result insufficient(ValidationKind kind, String diagnostic, String title, String reason, String suggestion) {
        return new Result(INSUFFICIENT, kind, null, List.of(), diagnostic, title, reason, suggestion);
    }

    private static Result notSupported(ValidationKind kind, String diagnostic) {
        return new Result(PASS, kind, null, List.of(), diagnostic, "", "", "");
    }

    private static Result original(Assessment result, ValidationKind kind, ConflictComparison comparison, List<String> pair) {
        return new Result(result.status(), kind, comparison, pair, null, result.title(), result.reason(), result.suggestion());
    }
}
