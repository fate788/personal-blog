package studio.reqaudit;

import org.apache.pdfbox.Loader;
import org.apache.pdfbox.io.IOUtils;
import org.apache.pdfbox.io.RandomAccessReadBuffer;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.encryption.InvalidPasswordException;
import org.apache.pdfbox.text.PDFTextStripper;
import org.apache.pdfbox.text.TextPosition;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.regex.Pattern;

import static studio.reqaudit.DocumentParser.*;
import static studio.reqaudit.Domain.*;

final class PdfRequirements {
    private static final int MAX_PAGES = 240;
    private static final int MAX_GLYPHS = MAX_TEXT * 3;
    private static final Pattern REPORT_FOOTER = Pattern.compile("^NASA[/ ]TM[-–]\\S+(?:\\s+\\d+)?$");
    private static final Pattern TABLE_CAPTION = Pattern.compile("(?i)^(?:table\\s+\\d|表\\s*\\d).*");

    record Result(List<SourceLine> lines, int pageCount, List<String> warnings) {}
    private record Glyph(float x, float width, String text) {}
    private record PdfLine(int page, int line, String text, List<Glyph> glyphs) {}
    private record CellText(float x, String text) {}

    static Result extract(MultipartFile file) throws IOException {
        try (var source = new RandomAccessReadBuffer(file.getBytes());
             var pdf = Loader.loadPDF(source, IOUtils.createTempFileOnlyStreamCache())) {
            if (pdf.isEncrypted() || !pdf.getCurrentAccessPermission().canExtractContent()) {
                throw ApiFailure.badRequest("PDF 已加密或限制文本提取，请提供可读取的文本版本。");
            }
            int pages = pdf.getNumberOfPages();
            if (pages > MAX_PAGES) {
                throw ApiFailure.tooLarge("PDF 超过 " + MAX_PAGES + " 页，请按章节拆分后导入。");
            }
            var reader = new LayoutReader();
            reader.writeText(pdf, Writer.nullWriter());
            if (reader.lines.isEmpty()) {
                throw ApiFailure.badRequest("PDF 没有可提取的文本层。请先转换为可搜索的 PDF、TXT 或 DOCX。");
            }
            var parser = new Rows(reader.lines);
            var extracted = parser.read();
            var warnings = new ArrayList<String>();
            warnings.add("PDF 按可提取的文本层解析。图像、扫描内容和复杂布局需按原页核对。");
            int blankPages = pages - (int) reader.lines.stream().map(PdfLine::page).distinct().count();
            if (blankPages > 0) {
                warnings.add(blankPages + " 页没有可提取文本，未纳入审查。");
            }
            if (parser.unresolvedTables > 0) {
                warnings.add(parser.unresolvedTables + " 个需求表表头未能可靠确定列范围，请核对提取顺序。");
            }
            return new Result(extracted, pages, List.copyOf(warnings));
        } catch (InvalidPasswordException ex) {
            throw ApiFailure.badRequest("PDF 已加密，请提供可读取的文本版本。");
        }
    }

    private static final class LayoutReader extends PDFTextStripper {
        private final List<PdfLine> lines = new ArrayList<>();
        private final StringBuilder current = new StringBuilder();
        private final List<Glyph> glyphs = new ArrayList<>();
        private int page;
        private int line;
        private int glyphCount;

        LayoutReader() throws IOException {
            setSortByPosition(true);
        }

        @Override
        protected void startPage(PDPage value) {
            page = getCurrentPageNo();
            line = 1;
        }

        @Override
        protected void endPage(PDPage value) {
            flush();
        }

        @Override
        protected void writeString(String text, List<TextPosition> positions) {
            current.append(text);
            for (var position : positions) {
                glyphs.add(new Glyph(position.getXDirAdj(), position.getWidthDirAdj(), position.getUnicode()));
            }
        }

        @Override
        protected void writeWordSeparator() {
            current.append(' ');
        }

        @Override
        protected void writeLineSeparator() {
            flush();
            line++;
        }

        @Override
        protected void processTextPosition(TextPosition position) {
            if (++glyphCount > MAX_GLYPHS) {
                throw ApiFailure.tooLarge("PDF 文本量超出导入限制，请按章节拆分。");
            }
            super.processTextPosition(position);
        }

        private void flush() {
            String text = clean(current.toString());
            if (!text.isBlank()) {
                if (lines.size() >= MAX_SOURCE_LINES) {
                    throw ApiFailure.tooLarge("PDF 可提取的文本行数超出导入限制，请按章节拆分。");
                }
                lines.add(new PdfLine(page, line, text, List.copyOf(glyphs)));
            }
            current.setLength(0);
            glyphs.clear();
        }
    }

    private static String clean(String value) {
        return value.replace("\u0002", "-").replace("\u00ad", "-")
                .replaceAll("[\\p{Cc}&&[^\\t]]", "").strip();
    }

    private static final class Rows {
        private final List<PdfLine> raw;
        private final List<SourceLine> result = new ArrayList<>();
        private float[] columnStarts;
        private String[] current;
        private PdfLine first;
        private PdfLine last;
        private int tableNumber;
        private int rowNumber;
        private int unresolvedTables;
        private int headerPage;
        private String headerText = "";
        private String tableCaption = "";

        Rows(List<PdfLine> raw) {
            this.raw = raw;
        }

        List<SourceLine> read() {
            for (int index = 0; index < raw.size(); index++) {
                PdfLine line = raw.get(index);
                if (requirementHeader(line.text())) {
                    flush();
                    configure(line, index);
                    result.add(plain(line));
                    continue;
                }
                if (!consume(line)) {
                    flush();
                    columnStarts = null;
                    if (TABLE_CAPTION.matcher(line.text()).matches()) tableCaption = line.text();
                    result.add(plain(line));
                }
            }
            flush();
            return List.copyOf(result);
        }

        private void configure(PdfLine header, int index) {
            columnStarts = null;
            if (index + 1 >= raw.size()) return;
            var labels = splitOnGap(header.glyphs());
            var firstRow = splitOnGap(raw.get(index + 1).glyphs());
            if (labels.size() < 3 || labels.size() != firstRow.size()
                    || explicitCode(firstRow.get(0).text()) == null
                    || raw.get(index + 1).page() != header.page()) {
                unresolvedTables++;
                return;
            }
            columnStarts = new float[firstRow.size()];
            for (int column = 0; column < columnStarts.length; column++) {
                columnStarts[column] = firstRow.get(column).x() - 2.0f;
            }
            String normalizedHeader = header.text().replaceAll("\\s+", " ").toLowerCase(Locale.ROOT);
            if (tableNumber == 0 || !tableCaption.isEmpty() || header.page() != headerPage + 1
                    || !normalizedHeader.equals(headerText)) {
                tableNumber++;
                rowNumber = 0;
                tableCaption = "";
            }
            headerPage = header.page();
            headerText = normalizedHeader;
        }

        private boolean consume(PdfLine line) {
            if (columnStarts == null || REPORT_FOOTER.matcher(line.text()).matches()) return false;
            List<String> cells = splitOnColumns(line.glyphs(), columnStarts);
            String idCell = cells.get(0);
            if (!idCell.isBlank() && explicitCode(idCell) == null) return false;
            if (!idCell.isBlank()) {
                flush();
                first = line;
                current = cells.toArray(String[]::new);
            } else if (current != null && line.page() == last.page()) {
                for (int index = 1; index < cells.size(); index++) {
                    current[index] = joinWrapped(current[index], cells.get(index));
                }
            } else {
                return false;
            }
            last = line;
            return true;
        }

        private void flush() {
            if (current == null) return;
            var anchor = new SourceAnchor(first.page(), last.page(), first.line(), last.line(),
                    tableNumber, ++rowNumber, List.of());
            result.add(tableRow(Arrays.asList(current), anchor));
            current = null;
        }

        private SourceLine plain(PdfLine line) {
            return new SourceLine(line.text(), 0,
                    new SourceAnchor(line.page(), line.page(), line.line(), line.line(), null, null, List.of()));
        }
    }

    private static boolean requirementHeader(String source) {
        String line = source.toLowerCase(Locale.ROOT).replaceAll("\\s+", " ");
        return line.matches("^(?:sw )?(?:req(?:uirement)? id|requirement no\\.?)\\b.*\\btitle\\b.*\\brequirement\\b.*")
                || line.matches("^需求编号.*(?:标题|名称).*需求(?:内容|描述).*");
    }

    private static List<CellText> splitOnGap(List<Glyph> glyphs) {
        var cells = new ArrayList<CellText>();
        var text = new StringBuilder();
        float start = 0;
        float end = 0;
        for (Glyph glyph : glyphs) {
            if (text.length() > 0 && glyph.x() - end > 8.0f) {
                cells.add(new CellText(start, clean(text.toString())));
                text.setLength(0);
            }
            if (text.length() == 0) start = glyph.x();
            appendGlyph(text, glyph, end);
            end = glyph.x() + glyph.width();
        }
        if (!text.isEmpty()) cells.add(new CellText(start, clean(text.toString())));
        return cells;
    }

    private static List<String> splitOnColumns(List<Glyph> glyphs, float[] starts) {
        var cells = new ArrayList<StringBuilder>();
        for (int index = 0; index < starts.length; index++) cells.add(new StringBuilder());
        float end = 0;
        for (Glyph glyph : glyphs) {
            int column = 0;
            while (column + 1 < starts.length && glyph.x() >= starts[column + 1]) column++;
            appendGlyph(cells.get(column), glyph, end);
            end = glyph.x() + glyph.width();
        }
        return cells.stream().map(cell -> clean(cell.toString())).toList();
    }

    private static void appendGlyph(StringBuilder text, Glyph glyph, float previousEnd) {
        if (!text.isEmpty() && !Character.isWhitespace(text.charAt(text.length() - 1))
                && glyph.x() - previousEnd > 2.0f && !glyph.text().isBlank()) {
            text.append(' ');
        }
        text.append(glyph.text());
    }

    private PdfRequirements() {}
}
