package studio.reqaudit;

import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Pattern;

import static studio.reqaudit.Domain.*;

/** Narrow checks for two interpretations that can be resolved directly against the quoted document. */
final class DocumentScope {
    private static final Pattern EMPHASIZED = Pattern.compile("^(?:\\*\\*([^*\\n]{2,48})\\*\\*|__([^_\\n]{2,48})__|#{1,6}\\s+(.{2,48}))$");
    private static final Pattern ADVICE = Pattern.compile("建议|指南|指引|最佳实践|使用说明|参考说明");
    private static final Pattern TOPIC = Pattern.compile("^(?:按(?:照)?|依据|根据|关于|如何|概述|简介)");
    private static final Pattern TOPIC_LABEL = Pattern.compile("^(?:#{1,6}\\s+|>\\s*[“‘\"]?)([\\p{IsHan}A-Za-z ]{0,12}(?:规划|指南|说明|概述|简介|建议|指引))[”’\"]?$");
    private static final Pattern COMMITMENT = Pattern.compile("必须|需要|应当|应[当该]?|不得|禁止|允许|不能|不可|支持|保证|承诺|系统|服务须|须|自动|返回|立即|至少|至多|仅|不超过|\\d|[。；;，,：:！？!?]");
    private static final Pattern GAP = Pattern.compile("口径|阈值|标准|定义|验收|量化|指标|衡量|未说明|缺少|未解释");
    private static final String ACTION = "修改|变更|编辑|调整|更新|删除|撤销|停用|启用";
    private static final Pattern OBJECT = Pattern.compile("[\\p{IsHan}A-Za-z][\\p{IsHan}A-Za-z0-9_]{1,29}");
    private static final Pattern UNIVERSAL = Pattern.compile("(?:每个|每一个|任一|任意一个|每种|所有|全部)([\\p{IsHan}]{2,16}?)(?:下(?:的|会)|对应的|中的|的)");
    private static final Pattern GENERIC_SECTION = Pattern.compile("(?:行为|功能|操作|使用|配置|业务|系统|产品|接口|字段|技术)?(?:规则|说明|建议|指引|约束|限制|指南|要求|规范)|正文");
    private static final Pattern SCOPE_CHANGE = Pattern.compile("(?iu)版本|模式|环境|角色|租户|[版态]下|阶段|期间|之前|之后|完成后|上线后|创建后|发布后|迁移后|草稿|归档|只读|仅|只允许|除外|除非|例外|默认|通常|建议|不推荐|管理员|维护者|操作员|用户组|账号|账户|客户端|服务端|只对|只在|针对|适用于|限于|若|如果|当.{0,30}时|在.{1,32}(?:时|中|内|下)|[vV]\\d|企业版|基础版|社区版|测试版");
    private DocumentScope() {}

    static boolean advisoryHeadingOnly(Assessment result, Map<String, Item> allowed, List<Evidence> evidence) {
        if (!Set.of("R-01", "R-05", "R-06").contains(result.ruleId()) || evidence.isEmpty()
                || evidence.stream().anyMatch(e -> !e.itemId().equals(result.itemId()))) return false;
        Item item = allowed.get(result.itemId());
        if (item == null || !GAP.matcher(result.title() + result.reason()).find()) return false;
        var label = TOPIC_LABEL.matcher(item.text().strip());
        if (label.matches() && !COMMITMENT.matcher(label.group(1)).find()) return true;
        if (!ADVICE.matcher(item.section()).find()) return false;
        var marked = EMPHASIZED.matcher(item.text().strip());
        if (!marked.matches()) return false;
        String heading = marked.group(1) != null ? marked.group(1) : marked.group(2) != null ? marked.group(2) : marked.group(3);
        return TOPIC.matcher(heading).find() && !COMMITMENT.matcher(heading).find()
                && allowed.values().stream().anyMatch(body -> body.section().equals(item.section())
                        && body.line() > item.line() && body.line() <= item.line() + 4 && body.text().length() > heading.length());
    }

    static ConflictComparison capabilityConflict(ConflictComparison proof, Item left, Item right,
                                                List<Evidence> evidence, Map<String, Item> allowed) {
        if (proof.subject() != ScopeRelation.OVERLAP || proof.object() != ScopeRelation.OVERLAP
                || proof.activity() != ScopeRelation.OVERLAP || proof.consequence() != ConsequenceRelation.INCOMPATIBLE
                || proof.sharedScenario().isBlank() || !proof.left().objectQuote().equals(proof.right().objectQuote())
                || !compatibleSections(left.section(), right.section())) return null;
        boolean reversed = !proof.left().conditionQuote().isBlank();
        ComparisonSide no = reversed ? proof.right() : proof.left(), yes = reversed ? proof.left() : proof.right();
        Item prohibition = reversed ? right : left, permission = reversed ? left : right;
        String object = no.objectQuote(), condition = yes.conditionQuote();
        if (!OBJECT.matcher(object).matches() || !no.conditionQuote().isBlank() || condition.isBlank()
                || !condition.endsWith("时") || condition.length() > 56
                || SCOPE_CHANGE.matcher(prohibition.text()).find()
                || SCOPE_CHANGE.matcher(permission.text().replace(condition, "")).find()
                || SCOPE_CHANGE.matcher(condition.replaceFirst("^在", "").replaceFirst("时$", "")).find()
                || hasScopeIntroduction(prohibition, allowed) || hasScopeIntroduction(permission, allowed)) return null;
        String field = Pattern.quote(object);
        var denied = Pattern.compile("(?:^|的\\s*|[，,。；;：:]\\s*)(" + field + "(?:暂|尚|一律|均|都)?(?:不支持|不能|不允许|不得|禁止)(" + ACTION + "))(?=[，,。；;]|$)").matcher(prohibition.text());
        if (!denied.find()) return null;
        String action = denied.group(2);
        // A universal owner in the same source sentence must own this exact property, including on the allowed branch.
        var owner = UNIVERSAL.matcher(prohibition.text());
        String entity = null;
        while (owner.find()) {
            String noun = owner.group(1);
            if (prohibition.text().contains(noun + "对应的" + object) || prohibition.text().contains(noun + "的" + object)
                    || prohibition.text().contains(noun + "中的" + object)) {
                entity = noun;
                break;
            }
        }
        if (entity == null || !UNIVERSAL.matcher(prohibition.text().strip()).lookingAt()
                || !Pattern.compile("(?:修改|变更|编辑|调整|更新)" + Pattern.quote(entity) + "(?:时|或|、)").matcher(condition).find()) return null;
        String affirmative = "(?:可以|可|支持|允许|能够)", operation = "(?:设置|配置)?" + action;
        String embedded = field + affirmative + Pattern.quote(condition) + operation;
        String prefixed = Pattern.quote(condition) + "\\s*[,，]\\s*(?:其" + field + affirmative + operation + "|" + affirmative + operation + "其" + field + ")";
        // The antecedent of 其 is the changed owner only if the clause starts with that owner condition, without an intervening actor.
        var granted = Pattern.compile("(?:(?:^|的\\s*|[，,。；;：:]\\s*)(" + embedded + ")|(?:^|[。；;]\\s*)(" + prefixed + "))(?=[，,。；;]|$)").matcher(permission.text());
        if (!granted.find()) return null;
        String statement = granted.group(1) != null ? granted.group(1) : granted.group(2);
        if (!cited(evidence, prohibition, denied.group(1)) || !cited(evidence, permission, statement)) return null;
        var negative = new ComparisonSide(no.itemId(), entity, object, action, "", denied.group(1));
        var positive = new ComparisonSide(yes.itemId(), entity, object, action, condition, statement);
        String scenario = "一处写“" + denied.group(1) + "”，另一处写“" + statement
                + "”。读者无法确定变更同一个" + entity + "时能否" + action + "其" + object + "。";
        return new ConflictComparison(reversed ? positive : negative, reversed ? negative : positive,
                ScopeRelation.OVERLAP, ScopeRelation.OVERLAP, ScopeRelation.OVERLAP, ScopeRelation.OVERLAP,
                ConsequenceRelation.INCOMPATIBLE, scenario, proof.scopeEvidence());
    }

    private static boolean cited(List<Evidence> evidence, Item item, String text) {
        return evidence.stream().anyMatch(e -> e.itemId().equals(item.id()) && e.quote().contains(text));
    }

    private static boolean compatibleSections(String left, String right) {
        if (left.equals(right)) return true;
        int l = left.lastIndexOf(" / "), r = right.lastIndexOf(" / ");
        return l == r && (l < 0 || left.substring(0, l).equals(right.substring(0, r)))
                && GENERIC_SECTION.matcher(left.substring(l < 0 ? 0 : l + 3)).matches()
                && GENERIC_SECTION.matcher(right.substring(r < 0 ? 0 : r + 3)).matches();
    }

    private static boolean hasScopeIntroduction(Item item, Map<String, Item> allowed) {
        return allowed.values().stream().filter(other -> item.line() > other.line() && item.line() - other.line() <= 6)
                .filter(other -> other.section().equals(item.section()) || other.section().equals("邻近原文"))
                .map(Item::text).anyMatch(text -> (text.endsWith("：") || text.endsWith(":") || text.contains("以下")
                        || text.contains("本节") || text.contains("下文")) && SCOPE_CHANGE.matcher(text).find());
    }
}
