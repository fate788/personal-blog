package studio.reqaudit;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.TreeMap;
import java.util.regex.Pattern;

import static studio.reqaudit.Domain.*;

final class RequirementTrace {
    record Result(int requirements, int totalLinked, int verificationItems, List<String> ambiguousIds,
                  List<Row> rows) {}
    record Row(String id, String code, int line, String text, List<Link> links) {}
    record Link(String id, String code, int line, String text, String kind, Integer column) {}

    private record Table(int criterion, int method, int expectedColumns) {}

    private static final Pattern ACCEPTANCE_ID = Pattern.compile("(?i)^(?:AC|AT|TC|TEST|VERIFY|VFY)[-_].+");
    private static final Pattern SUPPORTING_ID = Pattern.compile("(?i)^(?:BG|GOAL|OBJ|RISK|DEC|DD|ADR|TERM)[-_].+");
    private static final Pattern TOKEN = Pattern.compile(DocumentParser.DOTTED_ID + "|[a-zA-Z][a-zA-Z0-9_/-]{1,119}(?:\\.\\d{1,8})?");
    private static final Pattern FORWARD = Pattern.compile(
            "(?iu)\\b(?:acceptance (?:criteria|cases?|tests?)|verification(?: criteria)?|test cases?)\\s*[:：]"
                    + "|(?:验收(?:标准|条件|用例)|测试用例|验证(?:标准|条件))\\s*[:：]|\\bverified by\\s+");
    private static final Pattern BACKWARD = Pattern.compile(
            "(?iu)\\b(?:covers?|verifies|requirements? covered)\\s*[:：]|(?:覆盖|验证|对应)(?:需求)?\\s*[:：]");
    private static final Pattern END_RELATION = Pattern.compile("[。；;!?]|\\.(?=\\s|$)");
    private static final Pattern LINK_LIST = Pattern.compile(
            "(?iu)^\\s*[`*#]*[a-z][a-z0-9_/-]*[-_]\\d");
    private static final Pattern PLACEHOLDER = Pattern.compile(
            "(?iu)^(?:\\[?(?:tbd|tbc|n/?a|none|not applicable)\\b|\\[?(?:待确认|待补|暂无|不适用)|[.…—_-]+$)");
    private static final Pattern PDF_HEADER = Pattern.compile(
            "(?iu)^(?:sw )?(?:req(?:uirement)? id|requirement no\\.?) title requirement"
                    + "( rationale)? verification method verification (?:statement|criteria|criterion)$");
    private static final Pattern DOTTED_DECLARATION = Pattern.compile(
            "(?:^|(?<=[.!?)]\\s))(" + DocumentParser.DOTTED_ID + ")\\s+[-–—]\\s+(?=\\p{L})");

    private RequirementTrace() {}

    static Result inspect(Version version) {
        var groups = new LinkedHashMap<String, List<Item>>();
        for (Item item : traceItems(version)) {
            String code = DocumentParser.explicitCode(item.text());
            if (code != null && !DocumentParser.traceMappingRow(item.text(), item.section())) {
                groups.computeIfAbsent(key(code), ignored -> new ArrayList<>()).add(item);
            }
        }
        var unambiguous = new LinkedHashMap<String, Item>();
        var ambiguous = new ArrayList<String>();
        groups.forEach((code, items) -> {
            if (items.size() == 1) unambiguous.put(code, items.get(0));
            else ambiguous.add(code);
        });
        var rows = new ArrayList<Row>();
        var links = new HashMap<String, LinkedHashMap<String, Link>>();
        var representedVerification = new LinkedHashSet<String>();
        for (Item item : unambiguous.values()) {
            if (acceptance(item)) {
                representedVerification.add(item.id());
                for (String code : related(item.text(), BACKWARD)) {
                    Item target = unambiguous.get(code);
                    if (requirement(target)) add(links, target, clause(item));
                }
                continue;
            }
            if (!requirement(item)) continue;
            for (String code : related(item.text(), FORWARD)) {
                Item target = unambiguous.get(code);
                if (target != null && acceptance(target)) add(links, item, clause(target));
            }
            var label = FORWARD.matcher(item.text());
            if (label.find()) {
                String text = relationValue(item.text(), label.end());
                if (usable(text) && !LINK_LIST.matcher(text).find()) {
                    var link = new Link(item.id() + ":inline", "文字验收条件", item.line(), text, "INLINE", null);
                    add(links, item, link);
                    representedVerification.add(link.id());
                }
            }
        }

        String[] source = version.text().split("\n", -1);
        Map<Integer, Link> declarations = tableDeclarations(version.source(), source);
        for (Item item : unambiguous.values()) {
            Link link = declarations.get(item.line());
            if (requirement(item) && link != null) {
                add(links, item, link);
                representedVerification.add(link.id());
            }
        }
        matrixLinks(version, source, unambiguous, links);
        int linked = 0;
        for (var group : groups.values()) {
            for (Item item : group) {
                if (!requirement(item)) continue;
                var matched = links.get(item.id());
                List<Link> evidence = matched == null ? List.of() : List.copyOf(matched.values());
                if (!evidence.isEmpty()) linked++;
                rows.add(new Row(item.id(), item.code(), item.line(), item.text(), evidence));
            }
        }
        return new Result(rows.size(), linked, representedVerification.size(), List.copyOf(ambiguous), List.copyOf(rows));
    }

    private static List<Item> traceItems(Version version) {
        if (version.source() == null || !"PDF".equals(version.source().format())) return version.items();
        var recovered = new ArrayList<Item>();
        for (Item item : version.items()) {
            // Older imports could join neighboring dotted declarations at a PDF line break.
            var matching = DOTTED_DECLARATION.matcher(item.text());
            if (!matching.find() || matching.start() != 0) {
                recovered.add(item);
                continue;
            }
            int start = 0;
            String code = matching.group(1);
            int index = 1;
            while (matching.find()) {
                recovered.add(dottedPart(item, index++, code, start, matching.start()));
                code = matching.group(1);
                start = matching.start();
            }
            recovered.add(index == 1 ? item : dottedPart(item, index, code, start, item.text().length()));
        }
        return recovered;
    }

    private static Item dottedPart(Item original, int part, String code, int start, int end) {
        String id = part == 1 ? original.id() : original.id() + ":part-" + part;
        return new Item(id, code, original.text().substring(start, end).strip(), original.line(), original.section());
    }

    private static void matrixLinks(Version version, String[] lines, Map<String, Item> items,
                                    Map<String, LinkedHashMap<String, Link>> links) {
        var headings = new HashMap<Integer, Section>();
        version.sections().forEach(section -> headings.put(section.line(), section));
        var path = new TreeMap<Integer, String>();
        var markup = new DocumentParser.Markup();
        for (int index = 0; index < lines.length; index++) {
            String line = lines[index];
            if (markup.metadata(line, index)) continue;
            var heading = headings.get(index + 1);
            if (heading != null) {
                path.tailMap(heading.level(), true).clear();
                path.put(heading.level(), heading.title());
            }
            if (!DocumentParser.traceMappingRow(line, String.join(" / ", path.values()))) continue;
            var refs = TOKEN.matcher(line);
            if (!refs.find()) continue;
            Item from = items.get(key(refs.group()));
            if (!requirement(from)) continue;
            while (refs.find()) {
                Item to = items.get(key(refs.group()));
                if (to != null && acceptance(to)) add(links, from, clause(to));
            }
        }
    }

    private static Map<Integer, Link> tableDeclarations(SourceMetadata source, String[] lines) {
        var result = new HashMap<Integer, Link>();
        if (source == null || source.anchors() == null) return result;
        var schemas = new HashMap<Integer, Table>();
        Table previousHeader = null;
        int headerLine = 0;
        Integer headerPage = null;
        for (int index = 0; index < lines.length; index++) {
            int line = index + 1;
            var anchor = source.anchors().get(line);
            if (anchor == null) continue;
            String text = lines[index];
            var pdfHeader = PDF_HEADER.matcher(label(text));
            if ("PDF".equals(source.format()) && pdfHeader.matches()) {
                int count = pdfHeader.group(1) == null ? 5 : 6;
                previousHeader = new Table(count, count - 1, count);
                headerLine = line;
                headerPage = anchor.page();
            }
            if (anchor.table() == null || anchor.cells() == null || anchor.cells().isEmpty()) continue;
            var ownHeader = tableHeader(anchor, text);
            if (ownHeader != null) {
                schemas.put(anchor.table(), ownHeader);
                continue;
            }
            if (!schemas.containsKey(anchor.table()) && previousHeader != null
                    && line <= headerLine + 3 && previousHeader.expectedColumns() == anchor.cells().size()
                    && java.util.Objects.equals(anchor.page(), headerPage)) {
                schemas.put(anchor.table(), previousHeader);
            }
            var schema = schemas.get(anchor.table());
            if (schema == null) continue;
            String criterion = cell(anchor, text, schema.criterion());
            if (!usable(criterion)) continue;
            String method = cell(anchor, text, schema.method());
            result.put(line, new Link("item-" + line + ":table", method.isBlank() ? "表中验收条件" : method,
                    line, criterion, "TABLE", schema.criterion()));
        }
        return result;
    }

    private static Table tableHeader(SourceAnchor anchor, String text) {
        int method = 0;
        int criterion = 0;
        boolean numbered = false;
        for (var cell : anchor.cells()) {
            String label = label(cell(anchor, text, cell.column()));
            if (label.matches("(?:sw )?(?:req(?:uirement)? id|requirement no\\.?|id)|(?:软件)?需求编号|编号")) numbered = true;
            if (label.matches("verification method|acceptance method|验证方法|验收方式|验收方法")) method = cell.column();
            if (label.matches("verification (?:statement|criteria|criterion)|acceptance (?:criteria|criterion)|验收(?:条件|标准|准则)|验证(?:语句|条件|标准)")) criterion = cell.column();
        }
        return numbered && criterion > 0 ? new Table(criterion, method, anchor.cells().size()) : null;
    }

    private static String cell(SourceAnchor anchor, String text, int number) {
        for (var cell : anchor.cells()) {
            if (cell.column() == number && cell.start() >= 0 && cell.end() >= cell.start() && cell.end() <= text.length()) {
                return text.substring(cell.start(), cell.end()).strip();
            }
        }
        return "";
    }

    private static String label(String text) {
        return text.strip().toLowerCase(Locale.ROOT).replaceAll("\\s+", " ");
    }

    private static String relationValue(String text, int start) {
        String tail = text.substring(start);
        var boundary = END_RELATION.matcher(tail);
        return (boundary.find() ? tail.substring(0, boundary.start()) : tail).strip();
    }

    private static List<String> related(String text, Pattern cue) {
        var refs = new LinkedHashSet<String>();
        var labels = cue.matcher(text);
        while (labels.find()) {
            var tokens = TOKEN.matcher(relationValue(text, labels.end()));
            while (tokens.find()) refs.add(key(tokens.group()));
        }
        return List.copyOf(refs);
    }

    private static boolean usable(String text) {
        return text.length() >= 4 && !PLACEHOLDER.matcher(text).find();
    }

    private static String key(String code) {
        return code.toUpperCase(Locale.ROOT);
    }

    private static boolean acceptance(Item item) {
        return ACCEPTANCE_ID.matcher(item.code()).matches();
    }

    private static boolean requirement(Item item) {
        return item != null && !acceptance(item) && !SUPPORTING_ID.matcher(item.code()).matches();
    }

    private static Link clause(Item item) {
        return new Link(item.id(), item.code(), item.line(), item.text(), "CLAUSE", null);
    }

    private static void add(Map<String, LinkedHashMap<String, Link>> links, Item item, Link link) {
        links.computeIfAbsent(item.id(), ignored -> new LinkedHashMap<>()).putIfAbsent(link.id(), link);
    }
}
