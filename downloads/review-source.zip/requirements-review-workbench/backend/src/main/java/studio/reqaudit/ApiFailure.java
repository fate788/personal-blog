package studio.reqaudit;

import org.springframework.http.HttpStatus;

final class ApiFailure extends RuntimeException {
    private final HttpStatus status;

    private ApiFailure(HttpStatus status, String message) {
        super(message);
        this.status = status;
    }

    HttpStatus status() {
        return status;
    }

    static ApiFailure badRequest(String message) {
        return new ApiFailure(HttpStatus.BAD_REQUEST, message);
    }

    static ApiFailure notFound(String message) {
        return new ApiFailure(HttpStatus.NOT_FOUND, message);
    }

    static ApiFailure tooLarge(String message) {
        return new ApiFailure(HttpStatus.PAYLOAD_TOO_LARGE, message);
    }

    static ApiFailure provider(String message) {
        return new ApiFailure(HttpStatus.BAD_GATEWAY, message);
    }

    static ApiFailure unauthorized(String message) {
        return new ApiFailure(HttpStatus.UNAUTHORIZED, message);
    }

    static ApiFailure forbidden(String message) {
        return new ApiFailure(HttpStatus.FORBIDDEN, message);
    }

    static ApiFailure conflict(String message) {
        return new ApiFailure(HttpStatus.CONFLICT, message);
    }

    static ApiFailure busy(String message) {
        return new ApiFailure(HttpStatus.TOO_MANY_REQUESTS, message);
    }

    static String requireText(String value, String label, int limit) {
        if (value == null || value.isBlank()) {
            throw badRequest(label + "不能为空。");
        }
        if (value.length() > limit) {
            throw tooLarge(label + "最多支持 " + limit + " 个字符。");
        }
        return value;
    }

    static String optionalText(String value, String label, int limit) {
        if (value == null || value.isBlank()) {
            return "";
        }
        return requireText(value, label, limit).strip();
    }
}
