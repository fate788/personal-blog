package studio.reqaudit;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import static studio.reqaudit.Domain.*;

@Repository
class AuditRepository {
    private record DocumentHeader(String id, String title, String created, String updated) {}

    private final JdbcTemplate jdbc;
    private final ObjectMapper json;
    private final DocumentParser parser;

    AuditRepository(JdbcTemplate jdbc, ObjectMapper json, DocumentParser parser) {
        this.jdbc = jdbc;
        this.json = json;
        this.parser = parser;
    }

    @Transactional(readOnly = true)
    List<Document> listDocuments(String projectId) {
        var headers = jdbc.query(
                """
                SELECT d.id, d.title, d.created_at, d.updated_at
                FROM review_document d JOIN document_scope s ON d.id = s.document_id
                WHERE s.project_id = ? ORDER BY d.updated_at DESC, d.id
                """,
                (row, index) -> new DocumentHeader(row.getString(1), row.getString(2), row.getString(3), row.getString(4)),
                projectId);
        return headers.stream().map(this::withVersions).toList();
    }

    Document requireDocument(String id) {
        return withVersions(readHeader(id, false));
    }

    Version requireVersion(String documentId, String versionId) {
        return jdbc.query("SELECT payload FROM document_version WHERE document_id = ? AND id = ?",
                        (row, index) -> read(row.getString(1), Version.class), documentId, versionId)
                .stream().findFirst().orElseThrow(() -> ApiFailure.notFound("文档版本不存在或不属于此文档。"));
    }

    @Transactional
    Document addDocument(String id, String projectId, String title, String text, Map<Integer, Integer> headings) {
        return addDocument(id, projectId, title, text, headings, null);
    }

    @Transactional
    Document addDocument(String id, String projectId, String title, String text, Map<Integer, Integer> headings,
                         SourceMetadata source) {
        String name = ApiFailure.requireText(title, "文档名称", 200).strip();
        Version version = parser.parse(id + "-v1", 1, text, headings, source);
        jdbc.update("INSERT INTO review_document (id, title, created_at, updated_at) VALUES (?, ?, ?, ?)",
                id, name, version.createdAt(), version.createdAt());
        insertVersion(id, version);
        jdbc.update("INSERT INTO document_scope (document_id, project_id) VALUES (?, ?)", id, projectId);
        return new Document(id, name, version.createdAt(), version.createdAt(), List.of(version));
    }

    @Transactional
    Document addVersion(String documentId, String text) {
        return addVersion(documentId, text, null);
    }

    @Transactional
    Document addTextVersion(String documentId, String text, String expectedLatestVersionId) {
        if (expectedLatestVersionId != null) requireLatest(documentId, expectedLatestVersionId);
        return addVersion(documentId, text, null);
    }

    @Transactional
    Document addVersion(String documentId, DocumentParser.Imported imported) {
        return addVersion(documentId, imported.text(), imported);
    }

    @Transactional
    Document addVersionIfLatest(String documentId, String expectedVersionId, DocumentParser.Imported revision) {
        requireLatest(documentId, expectedVersionId);
        return addVersion(documentId, revision);
    }

    private void requireLatest(String documentId, String expectedVersionId) {
        readHeader(documentId, true);
        String latest = jdbc.queryForObject(
                "SELECT id FROM document_version WHERE document_id = ? ORDER BY version_no DESC LIMIT 1 FOR UPDATE",
                String.class, documentId);
        if (!expectedVersionId.equals(latest)) {
            throw ApiFailure.conflict("已有更新的文档版本，请先核对最新版，再决定如何保存修订。");
        }
    }

    private Document addVersion(String documentId, String text, DocumentParser.Imported imported) {
        var header = readHeader(documentId, true);
        int next = jdbc.queryForObject(
                "SELECT COALESCE(MAX(version_no), 0) + 1 FROM document_version WHERE document_id = ?", Integer.class,
                documentId);
        var headings = imported == null
                ? parser.preserveHeadings(requireVersion(documentId, documentId + "-v" + (next - 1)), text)
                : imported.headings();
        Version version = parser.parse(documentId + "-v" + next, next, text, headings,
                imported == null ? null : imported.source());
        insertVersion(documentId, version);
        jdbc.update("UPDATE review_document SET updated_at = ? WHERE id = ?", version.createdAt(), documentId);
        return withVersions(new DocumentHeader(header.id(), header.title(), header.created(), version.createdAt()));
    }

    List<Run> listRuns(String projectId) {
        return jdbc.query("""
                SELECT r.payload FROM review_run r JOIN document_scope s ON r.document_id = s.document_id
                WHERE s.project_id = ? ORDER BY r.created_at DESC, r.id
                """, (row, index) -> read(row.getString(1), Run.class), projectId);
    }

    List<Run> listVersionRuns(String documentId, String versionId) {
        return jdbc.query("""
                SELECT payload FROM review_run
                WHERE document_id = ? AND version_id = ? ORDER BY created_at DESC, id
                """, (row, index) -> read(row.getString(1), Run.class), documentId, versionId);
    }

    void addRun(Run run) {
        jdbc.update("INSERT INTO review_run (id, document_id, version_id, created_at, payload) VALUES (?, ?, ?, ?, ?)",
                run.id(), run.documentId(), run.versionId(), run.createdAt(), write(run));
    }

    void replaceRun(Run run) {
        jdbc.update("UPDATE review_run SET payload = ? WHERE id = ?", write(run), run.id());
    }

    Run requireRun(String id, boolean lock) {
        String sql = "SELECT payload FROM review_run WHERE id = ?" + (lock ? " FOR UPDATE" : "");
        return jdbc.query(sql, (row, index) -> read(row.getString(1), Run.class), id)
                .stream().findFirst().orElseThrow(() -> ApiFailure.notFound("审查记录不存在。"));
    }

    @Transactional
    Run decide(String runId, String findingId, Decision decision, String note, String now) {
        Run old = requireRun(runId, true);
        if (old.status() == RunStatus.QUEUED || old.status() == RunStatus.RUNNING) {
            throw ApiFailure.conflict("审查完成后才能处置疑点。");
        }
        Finding current = old.findings().stream().filter(finding -> finding.id().equals(findingId)).findFirst()
                .orElseThrow(() -> ApiFailure.notFound("此审查中没有对应问题。"));
        if (current.status() != FindingStatus.ISSUE) {
            throw ApiFailure.badRequest("仅疑点支持确认、驳回或恢复待复核。");
        }
        if (current.decision() == decision && current.note().equals(note)) {
            return old;
        }
        List<Finding> next = old.findings().stream().map(finding -> finding.id().equals(findingId)
                ? finding.decided(decision, note, now) : finding).toList();
        Run updated = old.withFindings(next);
        jdbc.update("UPDATE review_run SET payload = ? WHERE id = ?", write(updated), runId);
        jdbc.update("""
                INSERT INTO finding_decision (id, run_id, finding_id, prior_decision, new_decision, note, created_at)
                VALUES (?, ?, ?, ?, ?, ?, ?)
                """, id(), runId, findingId, current.decision().name(), decision.name(), note, now);
        return updated;
    }

    List<DecisionLog> listDecisions(String runId) {
        return jdbc.query("""
                SELECT finding_id, prior_decision, new_decision, note, created_at FROM finding_decision
                WHERE run_id = ? ORDER BY created_at ASC, id ASC
                """, (row, index) -> new DecisionLog(row.getString(1), Decision.valueOf(row.getString(2)),
                Decision.valueOf(row.getString(3)), row.getString(4), row.getString(5)), runId);
    }

    static String id() {
        return UUID.randomUUID().toString();
    }

    private Document withVersions(DocumentHeader header) {
        List<Version> versions = jdbc.query(
                "SELECT payload FROM document_version WHERE document_id = ? ORDER BY version_no DESC",
                (row, index) -> read(row.getString(1), Version.class), header.id());
        return new Document(header.id(), header.title(), header.created(), header.updated(), versions);
    }

    private DocumentHeader readHeader(String id, boolean lock) {
        String sql = "SELECT id, title, created_at, updated_at FROM review_document WHERE id = ?" +
                (lock ? " FOR UPDATE" : "");
        return jdbc.query(sql,
                        (row, index) -> new DocumentHeader(row.getString(1), row.getString(2), row.getString(3), row.getString(4)),
                        id)
                .stream().findFirst().orElseThrow(() -> ApiFailure.notFound("文档不存在。"));
    }

    private void insertVersion(String documentId, Version version) {
        jdbc.update("INSERT INTO document_version (id, document_id, version_no, payload) VALUES (?, ?, ?, ?)",
                version.id(), documentId, version.number(), write(version));
    }

    <T> T read(String data, Class<T> type) {
        try {
            return json.readValue(data, type);
        } catch (JsonProcessingException ex) {
            throw new IllegalStateException("保存的审查数据无效。", ex);
        }
    }

    String write(Object data) {
        try {
            return json.writeValueAsString(data);
        } catch (JsonProcessingException ex) {
            throw new IllegalStateException("无法保存审查数据。", ex);
        }
    }
}
