package studio.reqaudit;

import org.apache.poi.xwpf.usermodel.*;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.charset.CharacterCodingException;
import java.nio.charset.StandardCharsets;
import java.security.DigestInputStream;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.time.Instant;
import java.util.*;
import java.util.regex.Pattern;

import static studio.reqaudit.Domain.*;

@Component
class DocumentParser {
    static final int MAX_TEXT = 200_000;
    static final int MAX_SOURCE_LINES = 12_000;
    private static final int MAX_UPLOAD_BYTES = 8 * 1024 * 1024;
    private static final String SIMPLE_ID = "[A-Za-z]{2,12}[-_][0-9]{1,8}";
    private static final String COMPOUND_ID = "[A-Za-z][A-Za-z0-9]{0,12}(?:[-/][A-Za-z0-9]{1,15}(?:\\.[0-9]{1,6})?){1,7}-[0-9]{1,8}(?:\\.[0-9]{1,8})?";
    static final String DOTTED_ID = "(?:[A-Za-z][A-Za-z0-9_-]{0,14}\\.){2,6}[0-9]{1,8}";
    private static final String RST_ID = "[A-Za-z][A-Za-z0-9_]{0,119}__[A-Za-z0-9_]{1,120}";
    private static final String IDENTIFIER = RST_ID + "|" + COMPOUND_ID + "|" + DOTTED_ID + "|" + SIMPLE_ID;
    private static final Pattern CODE = Pattern.compile(
            "^\\s*(?:[-*+]\\s+|\\|\\s*)?(?:\\*\\*|`)?(" + IDENTIFIER
                    + ")(?:\\*\\*|`)?(?=[:：\\s|│、。]|$)");
    private static final Pattern TRACE_SECTION = Pattern.compile("(?iu)\\b(?:traceability|trace)\\s+matrix\\b|追溯矩阵|跟踪矩阵");
    private static final Pattern PLAIN_TABLE_ROW = Pattern.compile("^\\s*\\|?\\s*(?:\\*\\*|`)?(?:"
            + IDENTIFIER + ")(?:\\*\\*|`)?\\s*\\|");
    private static final Pattern REFERENCE = Pattern.compile(
            "(?:参见|参考|依照|见|(?i:see|refer to))\\s*(" + DOTTED_ID + "|" + SIMPLE_ID + ")\\b");
    private static final Pattern MARKDOWN = Pattern.compile("^\\s*(#{1,6})\\s+\\S.*");
    private static final Pattern NUMERIC = Pattern.compile("^\\s*(\\d+(?:\\.\\d+){1,5})[.、]?\\s*\\S.*");
    private static final Pattern CHAPTER = Pattern.compile("^\\s*第[\\d一二三四五六七八九十百]+([章节篇])\\s*\\S.*");
    private static final Pattern STYLE = Pattern.compile("(?i)(?:heading|标题)[ _-]*([1-6])");
    private static final Pattern RST_REQUIREMENT = Pattern.compile("^\\s*\\.\\.\\s+[A-Za-z_]*(?:req|requirement)::\\s*(.*)$");
    private static final Pattern RST_PROPERTY = Pattern.compile("^\\s*:[A-Za-z_]+:\\s*(.*)$");
    private static final Pattern RST_ID_PROPERTY = Pattern.compile("^\\s*:id:\\s*(" + RST_ID + "|" + COMPOUND_ID + "|" + SIMPLE_ID + ")\\s*$");
    private static final Pattern SETEXT = Pattern.compile("^([=#~^*+_-])\\1{2,}$");
    private static final Pattern LIST_START = Pattern.compile("^\\s*(?:[-*+]\\s+|\\d+[.)、]\\s+|[a-z][.)]\\s+)");
    private static final Pattern CONTENTS = Pattern.compile("(?i)^\\s*(?:table of contents|contents|目\\s*录)\\s*$");
    private static final Pattern NORMATIVE = Pattern.compile(
            "(?iu)\\b(?:shall|must|should|required to)\\b|\\bMAY\\b|应当|必须|不得|应(?:支持|具备|提供|确保|能够|允许|校验|返回|记录|保存|删除|响应|使用|验证)");
    private static final Pattern END_SENTENCE = Pattern.compile("[。！？.!?；;]([”’\"')）\\]】]*)$");
    private static final Pattern BOILERPLATE = Pattern.compile("(?iu)^(?:\\s*[-*=#]+\\s*$|"
            + "(?:copyright|licen[cs]e|spdx-license-identifier|版权所有|保留一切权利|目录|table of contents)\\b.*|"
            + "(?:version|author|prepared by|document (?:id|version|number)|date|版本|作者|编制单位)\\s*[:：].*|"
            + "NASA[/ ]TM[-–]\\S+(?:\\s+\\d+)?$|\\d+$|\\.\\.(?:\\s.*)?$|:[A-Za-z_]+:.*)");

    record Imported(String title, String text, Map<Integer, Integer> headings, SourceMetadata source) {
        Imported withFileDigest(String sha256) {
            var identified = new SourceMetadata(source.format(), source.fileName(), source.pageCount(), source.warnings(), source.anchors(), sha256);
            return new Imported(title, text, headings, identified);
        }
    }
    record SourceLine(String text, int heading, SourceAnchor anchor) {}

    Imported read(MultipartFile file) {
        Imported parsed = readContents(file);
        try (var input = new DigestInputStream(file.getInputStream(), MessageDigest.getInstance("SHA-256"))) {
            input.transferTo(java.io.OutputStream.nullOutputStream());
            return parsed.withFileDigest(HexFormat.of().formatHex(input.getMessageDigest().digest()));
        } catch (NoSuchAlgorithmException ex) {
            throw new IllegalStateException(ex);
        } catch (IOException ex) {
            throw ApiFailure.badRequest("无法完整读取上传的文件，请重新选择。");
        }
    }

    private Imported readContents(MultipartFile file) {
        String rawFilename = Objects.toString(file.getOriginalFilename(), "");
        String filename = rawFilename.replace('\\', '/').replaceFirst("^.*/", "");
        String lower = filename.toLowerCase(Locale.ROOT);
        String title = filename.replaceFirst("(?i)\\.(docx|txt|md|markdown|rst|pdf)$", "");
        if (file.isEmpty()) throw ApiFailure.badRequest("上传文件为空。");
        if (file.getSize() > MAX_UPLOAD_BYTES) throw ApiFailure.tooLarge("上传文件超过 8 MB。");
        try {
            if (lower.endsWith(".docx")) {
                try (var input = file.getInputStream(); var docx = new XWPFDocument(input)) {
                    return canonical(title, "DOCX", filename, null, docxLines(docx), List.of());
                }
            }
            if (lower.endsWith(".pdf")) {
                var extracted = PdfRequirements.extract(file);
                return canonical(title, "PDF", filename, extracted.pageCount(), extracted.lines(), extracted.warnings());
            }
            if (lower.endsWith(".txt") || lower.endsWith(".md") || lower.endsWith(".markdown") || lower.endsWith(".rst")) {
                String format = lower.endsWith(".rst") ? "RST" : lower.endsWith(".txt") ? "TXT" : "MARKDOWN";
                String text = StandardCharsets.UTF_8.newDecoder().decode(ByteBuffer.wrap(file.getBytes())).toString();
                return canonical(title, format, filename, null, textLines(requireContent(text), Map.of()), List.of());
            }
        } catch (ApiFailure ex) {
            throw ex;
        } catch (CharacterCodingException ex) {
            throw ApiFailure.badRequest("文本文件需保存为 UTF-8 编码。");
        } catch (IOException | RuntimeException ex) {
            if (lower.endsWith(".docx")) {
                throw ApiFailure.badRequest("无法读取该 DOCX，请检查文件是否损坏或加密。");
            }
            if (lower.endsWith(".pdf")) {
                throw ApiFailure.badRequest("无法读取该 PDF，请检查文件是否损坏或加密。");
            }
            throw ApiFailure.badRequest("无法读取上传的文本文件。");
        }
        throw ApiFailure.badRequest("请选择 DOCX、PDF、UTF-8 TXT、Markdown 或 RST 文件。");
    }

    private List<SourceLine> docxLines(XWPFDocument docx) {
        var lines = new ArrayList<SourceLine>();
        var code = new RevisionCodeFences(docx.getBodyElements());
        int paragraphNumber = 0;
        int tableNumber = 0;
        int characters = 0;
        for (var element : docx.getBodyElements()) {
            if (element instanceof XWPFParagraph paragraph) {
                String id = paragraph.getStyle();
                XWPFStyles styles = docx.getStyles();
                XWPFStyle style = styles == null || id == null ? null : styles.getStyle(id);
                int level = styledHeading(id);
                if (level == 0 && style != null) level = styledHeading(style.getName());
                var properties = paragraph.getCTP().getPPr();
                if (level == 0 && properties != null && properties.isSetOutlineLvl()
                        && properties.getOutlineLvl().getVal() != null) {
                    int declared = properties.getOutlineLvl().getVal().intValue();
                    if (declared >= 0 && declared < 9) level = declared + 1;
                }
                SourceAnchor origin = new SourceAnchor(null, null, ++paragraphNumber, paragraphNumber, null, null, List.of());
                String text = paragraph.getText();
                if (code.opening.containsKey(paragraph)) text = code.opening.get(paragraph) + "\n" + text;
                if (code.closing.containsKey(paragraph)) text = text + "\n" + code.closing.get(paragraph);
                String[] paragraphLines = text.split("\\R", -1);
                for (int index = 0; index < paragraphLines.length; index++) {
                    lines.add(new SourceLine(paragraphLines[index], index == 0 ? level : 0, origin));
                    characters += paragraphLines[index].length() + 1;
                }
            } else if (element instanceof XWPFTable table) {
                tableNumber++;
                int rowNumber = 0;
                for (var row : table.getRows()) {
                    var cells = row.getTableCells().stream()
                            .map(cell -> plainParagraph(cell.getTextRecursively()))
                            .toList();
                    var origin = new SourceAnchor(null, null, null, null, tableNumber, ++rowNumber, List.of());
                    var result = tableRow(cells, origin);
                    lines.add(result);
                    characters += result.text().length() + 1;
                    checkDocxLimits(lines, characters);
                }
            }
            checkDocxLimits(lines, characters);
        }
        return lines;
    }

    private static void checkDocxLimits(List<SourceLine> lines, int characters) {
        if (characters > MAX_TEXT || lines.size() > MAX_SOURCE_LINES) {
            throw ApiFailure.tooLarge("DOCX 提取后的正文超过导入限制，请按章节拆分。");
        }
    }

    private static String plainParagraph(String text) {
        return text.replaceAll("\\h*\\R\\h*", " ");
    }

    static SourceLine tableRow(List<String> values, SourceAnchor origin) {
        var text = new StringBuilder();
        var cells = new ArrayList<SourceCell>();
        for (int index = 0; index < values.size(); index++) {
            if (index > 0) text.append(" │ ");
            int start = text.length();
            text.append(values.get(index));
            cells.add(new SourceCell(index + 1, start, text.length()));
        }
        var located = new SourceAnchor(origin.page(), origin.endPage(), origin.startLine(), origin.endLine(),
                origin.table(), origin.row(), List.copyOf(cells));
        return new SourceLine(text.toString(), 0, located);
    }

    Version parse(String id, int number, String input, Map<Integer, Integer> styledHeadings) {
        var normalized = canonical("", "TEXT", null, null,
                textLines(ApiFailure.requireText(input, "文档正文", MAX_TEXT), styledHeadings), List.of());
        return parse(id, number, normalized.text(), normalized.headings(), normalized.source());
    }

    Version parse(String id, int number, String input, Map<Integer, Integer> styledHeadings, SourceMetadata source) {
        if (source == null) return parse(id, number, input, styledHeadings);
        String text = requireContent(input);
        var sections = new ArrayList<Section>();
        var paragraphs = new ArrayList<Item>();
        var requirements = new ArrayList<Item>();
        var tableRequirements = new ArrayList<Item>();
        var outlinedRequirements = new ArrayList<Item>();
        var hierarchy = new TreeMap<Integer, String>();
        String[] lines = text.split("\n", -1);
        var markdown = new Markup();
        for (int index = 0; index < lines.length; index++) {
            String line = lines[index];
            int lineNumber = index + 1;
            boolean skip = markdown.metadata(line, index);
            boolean heading = !skip && styledHeadings.containsKey(lineNumber);
            if (heading) {
                int level = styledHeadings.get(lineNumber);
                String title = line.strip().replaceFirst("^#{1,6}\\s+", "");
                sections.add(new Section("section-" + lineNumber, title, lineNumber, level));
                hierarchy.tailMap(level, true).clear();
                hierarchy.put(level, title);
            } else if (!skip && !line.isBlank() && !boilerplate(line)) {
                String candidate = requirementColumns(line, lineNumber, source);
                String code = explicitCode(candidate);
                String section = hierarchy.isEmpty() ? "正文" : String.join(" / ", hierarchy.values());
                if (traceMappingRow(candidate, section)) continue;
                var item = new Item("item-" + lineNumber, code == null ? "P-" + lineNumber : code,
                        candidate, lineNumber, section);
                paragraphs.add(item);
                boolean normative = NORMATIVE.matcher(candidate).find();
                if (code != null || normative) requirements.add(item);
                if ("PDF".equals(source.format())) {
                    SourceAnchor sourceAnchor = source.anchors().get(lineNumber);
                    if (code != null && (sourceAnchor != null && sourceAnchor.table() != null || normative)) {
                        tableRequirements.add(item);
                    }
                    if (code != null || normative && LIST_START.matcher(candidate).find()) outlinedRequirements.add(item);
                }
            }
        }
        boolean pdfWithTables = "PDF".equals(source.format()) && source.anchors().values().stream()
                .anyMatch(anchor -> anchor.table() != null);
        boolean pdfWithOutline = outlinedRequirements.size() >= 3
                && outlinedRequirements.size() * 2 >= requirements.size();
        var items = pdfWithTables && !tableRequirements.isEmpty()
                ? tableRequirements : pdfWithOutline ? outlinedRequirements : requirements.isEmpty() ? paragraphs : requirements;
        if (items.isEmpty()) throw ApiFailure.badRequest("正文没有可审查的段落，请补充需求内容。");
        if (items != requirements && !requirements.isEmpty() && items.size() < requirements.size()) {
            var messages = new ArrayList<>(source.warnings());
            messages.add("优先纳入结构化需求表或规范性编号条款。原文中仍保留其他段落，供人工核对。");
            source = new SourceMetadata(source.format(), source.fileName(), source.pageCount(), List.copyOf(messages), source.anchors(), source.fileSha256());
        }
        return new Version(id, number, text, Instant.now().toString(), List.copyOf(sections), List.copyOf(items), source);
    }

    private static String requirementColumns(String line, int lineNumber, SourceMetadata source) {
        if (source.anchors() == null || !"PDF".equals(source.format())) return line;
        SourceAnchor anchor = source.anchors().get(lineNumber);
        if (anchor == null || anchor.cells() == null || anchor.cells().size() < 3) return line;
        // The PDF requirement-table detector recognizes columns ID, title, requirement, then optional rationale/tests.
        return line.substring(0, anchor.cells().get(2).end());
    }

    private Imported canonical(String title, String format, String fileName, Integer pageCount,
                               List<SourceLine> originals, List<String> warnings) {
        var lines = new ArrayList<String>();
        var headings = new HashMap<Integer, Integer>();
        var anchors = new HashMap<Integer, SourceAnchor>();
        var headingStyles = new LinkedHashMap<Character, Integer>();
        var contentsPages = new HashSet<Integer>();
        if ("PDF".equals(format)) {
            for (var source : originals) {
                if (CONTENTS.matcher(source.text()).matches()) contentsPages.add(source.anchor().page());
            }
        }
        var markup = new Markup();
        int unresolvedRstRequirements = 0;
        for (int index = 0; index < originals.size(); index++) {
            SourceLine source = originals.get(index);
            String line = source.text();
            boolean protectedLine = markup.metadata(line, index);
            List<SourceLine> properties = List.of();
            var directive = RST_REQUIREMENT.matcher(line);
            if (!protectedLine && directive.matches()) {
                var requirement = readRstRequirement(originals, index, directive.group(1));
                if (requirement != null) {
                    line = requirement.text();
                    source = new SourceLine(line, 0, range(source.anchor(), originals.get(requirement.end()).anchor()));
                    properties = requirement.properties();
                    index = requirement.end();
                    protectedLine = true;
                } else {
                    unresolvedRstRequirements++;
                }
            }
            int level = protectedLine || contentsPages.contains(source.anchor().page()) ? 0 : heading(source);
            if (level == 0 && !protectedLine && !line.isBlank() && index + 1 < originals.size()
                    && line.length() <= 90 && !boilerplate(line) && explicitCode(line) == null
                    && !NORMATIVE.matcher(line).find()) {
                var underline = SETEXT.matcher(originals.get(index + 1).text().strip());
                if (underline.matches()) {
                    char key = underline.group(1).charAt(0);
                    level = headingStyles.computeIfAbsent(key, style -> headingStyles.size() + 1);
                    index++;
                }
            }
            if (level > 0) headings.put(lines.size() + 1, level);
            if (!protectedLine && level == 0 && source.anchor().table() == null
                    && !contentsPages.contains(source.anchor().page()) && !boilerplate(line)
                    && (explicitCode(line) != null || NORMATIVE.matcher(line).find() || LIST_START.matcher(line).find())) {
                int last = index;
                while (last + 1 < originals.size()
                        && mayContinue(line, originals.get(last), originals.get(last + 1), "DOCX".equals(format))) {
                    line = joinWrapped(line, originals.get(++last).text());
                }
                if (last != index) {
                    source = new SourceLine(line, 0, range(source.anchor(), originals.get(last).anchor()));
                    index = last;
                }
            }
            if (!line.isBlank() || source.anchor().table() != null) anchors.put(lines.size() + 1, source.anchor());
            lines.add(line);
            for (var property : properties) {
                anchors.put(lines.size() + 1, property.anchor());
                lines.add(property.text());
            }
        }
        var messages = new ArrayList<>(warnings);
        if (unresolvedRstRequirements > 0) {
            messages.add(unresolvedRstRequirements + " 个 RST 需求块没有有效编号或正文，原文保留，请人工核对。");
        }
        String text = requireContent(String.join("\n", lines));
        return new Imported(title, text, Map.copyOf(headings),
                new SourceMetadata(format, fileName, pageCount, List.copyOf(messages), Map.copyOf(anchors)));
    }

    private record RstRequirement(String text, int end, List<SourceLine> properties) {}

    private static RstRequirement readRstRequirement(List<SourceLine> lines, int start, String title) {
        String id = null;
        String body = "";
        int last = start;
        boolean metadata = true;
        var properties = new ArrayList<SourceLine>();
        for (int index = start + 1; index < lines.size(); index++) {
            String raw = lines.get(index).text();
            if (raw.isBlank()) continue;
            if (!Character.isWhitespace(raw.charAt(0))) break;
            String part = raw.strip();
            if (part.startsWith(".. ")) break;
            var identified = RST_ID_PROPERTY.matcher(raw);
            if (metadata && identified.matches()) {
                id = identified.group(1);
            } else if (metadata && RST_PROPERTY.matcher(raw).matches()) {
                properties.add(lines.get(index));
            } else {
                metadata = false;
                body = joinWrapped(body, part);
            }
            last = index;
        }
        if (id == null || body.isBlank()) return null;
        return new RstRequirement(id + "："
                + (title.isBlank() ? "" : title.strip() + " — ") + body, last, properties);
    }

    private static boolean mayContinue(String current, SourceLine previous, SourceLine next, boolean docx) {
        String candidate = next.text();
        if (candidate.isBlank() || heading(next) > 0 || next.anchor().table() != null
                || !Objects.equals(previous.anchor().page(), next.anchor().page())
                || docx && !Objects.equals(previous.anchor().startLine(), next.anchor().startLine())
                || explicitCode(candidate) != null || LIST_START.matcher(candidate).find()
                || SETEXT.matcher(candidate.strip()).matches() || boilerplate(candidate)
                || candidate.stripLeading().startsWith("```") || candidate.stripLeading().startsWith("~~~")) {
            return false;
        }
        return !END_SENTENCE.matcher(current.stripTrailing()).find();
    }

    private static boolean boilerplate(String text) {
        return BOILERPLATE.matcher(text.strip()).matches();
    }

    static final class Markup {
        private String fence;
        private boolean frontMatter;
        private boolean rstDirective;
        private boolean htmlComment;

        boolean metadata(String raw, int index) {
            String line = raw.stripLeading();
            if (frontMatter) {
                if (line.strip().equals("---") || line.strip().equals("...")) frontMatter = false;
                return true;
            }
            if (index == 0 && line.equals("---")) {
                frontMatter = true;
                return true;
            }
            if (fence != null) {
                if (line.startsWith(fence)) fence = null;
                return true;
            }
            if (line.startsWith("```") || line.startsWith("~~~")) {
                fence = line.substring(0, 3);
                return true;
            }
            if (htmlComment || line.startsWith("<!--")) {
                htmlComment = !line.contains("-->");
                return true;
            }
            if (rstDirective) {
                if (raw.isBlank() || !raw.equals(line)) return true;
                rstDirective = false;
            }
            if (line.startsWith("..") && !RST_REQUIREMENT.matcher(raw).matches()) {
                rstDirective = true;
                return true;
            }
            return false;
        }
    }

    Imported publicExcerpt(String title, String format, String filename, String text, int firstSourceLine) {
        var lines = textLines(requireContent(text), Map.of(), firstSourceLine);
        return canonical(title, format, filename, null, lines, List.of());
    }

    private static List<SourceLine> textLines(String text, Map<Integer, Integer> headings) {
        return textLines(text, headings, 1);
    }

    private static List<SourceLine> textLines(String text, Map<Integer, Integer> headings, int firstSourceLine) {
        String normalized = text.replaceFirst("^\\uFEFF", "").replace("\r\n", "\n").replace('\r', '\n');
        if (normalized.indexOf('\0') >= 0) throw ApiFailure.badRequest("文本包含无效控制字符，请确认是 UTF-8 文本。");
        if (normalized.chars().filter(character -> character == '\n').count() >= MAX_SOURCE_LINES) {
            throw ApiFailure.tooLarge("文档超过 " + MAX_SOURCE_LINES + " 行，请按章节拆分。");
        }
        String[] lines = normalized.split("\n", -1);
        var result = new ArrayList<SourceLine>();
        for (int index = 0; index < lines.length; index++) {
            int number = index + 1;
            int physicalLine = firstSourceLine + index;
            var anchor = new SourceAnchor(null, null, physicalLine, physicalLine, null, null, List.of());
            result.add(new SourceLine(lines[index], headings.getOrDefault(number, 0), anchor));
        }
        return result;
    }

    private static String requireContent(String text) {
        if (text.length() > MAX_TEXT) throw ApiFailure.tooLarge("提取后的正文超过 20 万字符，请按章节拆分。");
        return ApiFailure.requireText(text, "文档正文", MAX_TEXT);
    }

    static String explicitCode(String line) {
        var matcher = CODE.matcher(line);
        if (!matcher.find()) return null;
        String code = matcher.group(1);
        return code.contains("__") ? code : code.toUpperCase(Locale.ROOT);
    }

    static String joinWrapped(String first, String next) {
        String suffix = next.strip();
        if (suffix.isEmpty()) return first;
        if (first.isEmpty()) return suffix;
        String prefix = first.stripTrailing();
        int left = prefix.codePointBefore(prefix.length());
        int right = suffix.codePointAt(0);
        boolean bothHan = Character.UnicodeScript.of(left) == Character.UnicodeScript.HAN
                && Character.UnicodeScript.of(right) == Character.UnicodeScript.HAN;
        return prefix + ((left == '-' || bothHan) ? "" : " ") + suffix;
    }

    private static SourceAnchor range(SourceAnchor first, SourceAnchor last) {
        return new SourceAnchor(first.page(), last.endPage(), first.startLine(), last.endLine(),
                first.table(), first.row(), first.cells());
    }

    Map<Integer, Integer> preserveHeadings(Version previous, String edited) {
        ApiFailure.requireText(edited, "文档正文", MAX_TEXT);
        String[] originalLines = previous.text().split("\n", -1);
        var styles = new HashMap<String, Integer>();
        var conflicts = new HashSet<String>();
        for (Section section : previous.sections()) {
            if (section.line() < 1 || section.line() > originalLines.length) continue;
            String original = originalLines[section.line() - 1].strip();
            Integer level = styles.putIfAbsent(original, section.level());
            if (level != null && level != section.level()) conflicts.add(original);
        }
        var headings = new HashMap<Integer, Integer>();
        String[] editedLines = edited.replace("\r\n", "\n").replace('\r', '\n').split("\n", -1);
        for (int index = 0; index < editedLines.length; index++) {
            String candidate = editedLines[index].strip();
            if (styles.containsKey(candidate) && !conflicts.contains(candidate)) {
                headings.put(index + 1, styles.get(candidate));
            }
        }
        return headings;
    }

    List<RuleWarning> checkReferences(Version version) {
        var warnings = new ArrayList<RuleWarning>();
        var known = new HashMap<String, Integer>();
        for (Item item : version.items()) {
            if (traceMappingRow(item.text(), item.section())) continue;
            String code = explicitCode(item.text());
            if (code == null) continue;
            Integer initial = known.putIfAbsent(code.toUpperCase(Locale.ROOT), item.line());
            if (initial != null) {
                warnings.add(new RuleWarning("DUPLICATE_ID",
                        item.code() + " 与第 " + initial + " 行使用了同一需求编号。", item.line()));
            }
        }
        for (Item item : version.items()) {
            if (traceMappingRow(item.text(), item.section())) continue;
            var refs = REFERENCE.matcher(item.text());
            var missing = new LinkedHashSet<String>();
            while (refs.find()) {
                String referenced = refs.group(1).toUpperCase(Locale.ROOT);
                if (!known.containsKey(referenced)) missing.add(referenced);
            }
            for (String code : missing) {
                warnings.add(new RuleWarning("MISSING_REFERENCE", "未找到显式引用的 " + code + "。", item.line()));
            }
        }
        warnings.addAll(SourceChecks.inspect(version.text()));
        return List.copyOf(warnings);
    }

    static boolean traceMappingRow(String line, String section) {
        return TRACE_SECTION.matcher(section).find() && PLAIN_TABLE_ROW.matcher(line).find();
    }

    private static int heading(SourceLine source) {
        if (source.heading() > 0) return source.heading();
        if (source.anchor().table() != null) return 0;
        String line = source.text();
        var markdown = MARKDOWN.matcher(line);
        if (markdown.matches()) return markdown.group(1).length();
        if (line.length() > 90 || line.matches(".*[。；！？].*") || NORMATIVE.matcher(line).find()) return 0;
        var numeric = NUMERIC.matcher(line);
        if (numeric.matches()) return numeric.group(1).split("\\.").length;
        var chapter = CHAPTER.matcher(line);
        return chapter.matches() ? ("节".equals(chapter.group(1)) ? 2 : 1) : 0;
    }

    private static int styledHeading(String style) {
        if (style == null) return 0;
        var matcher = STYLE.matcher(style);
        return matcher.find() ? Integer.parseInt(matcher.group(1)) : 0;
    }
}
