package studio.reqaudit;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ReviewStudioApplication {
    public static void main(String[] args) {
        SpringApplication.run(ReviewStudioApplication.class, args);
    }
}
