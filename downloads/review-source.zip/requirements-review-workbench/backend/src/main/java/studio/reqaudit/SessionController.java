package studio.reqaudit;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseCookie;
import org.springframework.web.bind.annotation.*;

import java.time.Duration;
import java.util.List;

import static studio.reqaudit.Accounts.*;
import static studio.reqaudit.StudioAccess.*;

@RestController
@RequestMapping("/api")
class SessionController {
    private record SessionView(boolean initialized, User user, boolean setupTokenRequired, boolean registrationEnabled) {}
    private record Onboarding(boolean show) {}

    private final Accounts accounts;
    private final StudioAccess access;
    private final boolean secure;
    private final boolean registrationEnabled;

    SessionController(Accounts accounts, StudioAccess access, @Value("${review.session.secure}") boolean secure,
                      @Value("${review.registration.enabled}") boolean registrationEnabled) {
        this.accounts = accounts;
        this.access = access;
        this.secure = secure;
        this.registrationEnabled = registrationEnabled;
    }

    @GetMapping("/session")
    @PublicEndpoint
    SessionView present(@RequestAttribute(value = ACCOUNT, required = false) User user) {
        boolean initialized = accounts.initialized();
        return new SessionView(initialized, user, !initialized && accounts.requiresSetupToken(), initialized && registrationEnabled);
    }

    @PostMapping("/session/onboarding")
    Onboarding onboarding(@RequestAttribute(ACCOUNT) User user) {
        return new Onboarding(accounts.claimOnboarding(user));
    }

    @PostMapping("/session/setup")
    @PublicEndpoint
    @ResponseStatus(HttpStatus.CREATED)
    SessionView setup(@RequestBody Credentials credentials, HttpServletRequest request, HttpServletResponse response) {
        access.limitAuthentication(request);
        Session session = accounts.setup(credentials);
        access.clearAuthenticationLimit(request);
        return signedIn(session, request, response);
    }

    @PostMapping("/session/login")
    @PublicEndpoint
    SessionView login(@RequestBody Credentials credentials, HttpServletRequest request, HttpServletResponse response) {
        access.limitAuthentication(request);
        Session session = accounts.login(credentials, token(request));
        access.clearAuthenticationLimit(request);
        return signedIn(session, request, response);
    }

    @PostMapping("/session/register")
    @PublicEndpoint
    @ResponseStatus(HttpStatus.CREATED)
    SessionView register(@RequestBody Credentials credentials, HttpServletRequest request, HttpServletResponse response) {
        if (!registrationEnabled) throw ApiFailure.forbidden("此工作区由管理员开通账号。");
        access.limitRegistration(request);
        return signedIn(accounts.register(credentials, token(request)), request, response);
    }

    @PostMapping("/session/logout")
    @PublicEndpoint
    SessionView logout(HttpServletRequest request, HttpServletResponse response) {
        accounts.logout(token(request));
        setCookie("", Duration.ZERO, request, response);
        return present(null);
    }

    @GetMapping("/users")
    List<User> list(@RequestAttribute(ACCOUNT) User user) {
        return accounts.members(user);
    }

    @PostMapping("/users")
    @ResponseStatus(HttpStatus.CREATED)
    User create(@RequestAttribute(ACCOUNT) User user, @RequestBody Credentials credentials) {
        return accounts.addMember(user, credentials);
    }

    private SessionView signedIn(Session session, HttpServletRequest request, HttpServletResponse response) {
        setCookie(session.token(), SESSION_LENGTH, request, response);
        return new SessionView(true, session.user(), false, registrationEnabled);
    }

    private void setCookie(String token, Duration duration, HttpServletRequest request, HttpServletResponse response) {
        // A TLS-terminating proxy can strengthen the cookie even when the last hop uses HTTP.
        boolean secureCookie = secure || request.isSecure() || "https".equalsIgnoreCase(request.getHeader("X-Forwarded-Proto"));
        var cookie = ResponseCookie.from(COOKIE, token).maxAge(duration).path("/api")
                .httpOnly(true).secure(secureCookie).sameSite("Strict").build();
        response.addHeader(HttpHeaders.SET_COOKIE, cookie.toString());
    }
}
