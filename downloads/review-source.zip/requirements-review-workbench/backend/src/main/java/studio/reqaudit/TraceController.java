package studio.reqaudit;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.stream.Collectors;

import static studio.reqaudit.StudioAccess.ACCOUNT;

@RestController
@RequestMapping("/api/documents/{documentId}/versions/{versionId}/trace")
class TraceController {
    private final Projects projects;
    private final AuditRepository repository;
    private final DocumentParser parser;

    TraceController(Projects projects, AuditRepository repository, DocumentParser parser) {
        this.projects = projects;
        this.repository = repository;
        this.parser = parser;
    }

    @GetMapping
    RequirementTrace.Result trace(@RequestAttribute(ACCOUNT) Accounts.User user, @PathVariable String documentId,
                                  @PathVariable String versionId) {
        projects.forDocument(user.id(), documentId);
        var original = repository.requireVersion(documentId, versionId);
        var headings = original.sections().stream()
                .collect(Collectors.toMap(Domain.Section::line, Domain.Section::level));
        var structure = parser.parse(original.id(), original.number(), original.text(), headings, original.source());
        return RequirementTrace.inspect(structure);
    }
}
