package studio.reqaudit;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.core.io.ClassPathResource;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Transactional;

import java.io.IOException;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.HashSet;
import java.util.HexFormat;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.UUID;

@Service
class VerifiedCases {
    @JsonIgnoreProperties(ignoreUnknown = true)
    record Source(String file, String commit, String url, int startLine, int endLine, String sha256,
                  List<Integer> focusLines) {}
    record SupportingReference(String title, String beforeUrl, String afterUrl, String scope) {}
    @JsonIgnoreProperties(ignoreUnknown = true)
    record Example(String id, String title, String project, String language, String kind, String summary,
                   String expectedIssue, String expectedFix, String reviewHint, String license, String fixUrl,
                   String evidenceBasis, String scopeNote, String corroborationUrl, List<SupportingReference> supportingReferences,
                   Source before, Source after) {}
    @JsonIgnoreProperties(ignoreUnknown = true)
    private record Manifest(int schemaVersion, List<Example> cases) {}
    record Imported(String documentId, String beforeVersionId, String afterVersionId) {}
    record SourceInfo(String url, String commit, int startLine, int endLine, String sha256) {
        SourceInfo(Source source) {
            this(source.url(), source.commit(), source.startLine(), source.endLine(), source.sha256());
        }
    }
    record Listing(String id, String title, String project, String language, String kind, String summary,
                   String license, SourceInfo before, SourceInfo after) {
        Listing(Example example) {
            this(example.id(), example.title(), example.project(), example.language(), example.kind(), example.summary(),
                    example.license(), new SourceInfo(example.before()), new SourceInfo(example.after()));
        }
    }
    record Card(Listing sample, Imported imported) {}

    private final JdbcTemplate jdbc;
    private final AuditRepository docs;
    private final DocumentParser parser;
    private final List<Example> examples;

    VerifiedCases(ObjectMapper mapper, JdbcTemplate jdbc, AuditRepository docs, DocumentParser parser) throws IOException {
        this.jdbc = jdbc;
        this.docs = docs;
        this.parser = parser;
        try (var input = new ClassPathResource("verified-cases/manifest.json").getInputStream()) {
            var manifest = mapper.readValue(input, Manifest.class);
            if (manifest.schemaVersion() != 1 || manifest.cases() == null || manifest.cases().isEmpty()) {
                throw new IOException("公开案例清单不可用。");
            }
            examples = List.copyOf(manifest.cases());
        }
    }

    List<Card> list(String projectId) {
        var imported = importedDocumentIds(projectId);
        return examples.stream().map(sample -> {
            String id = documentId(projectId, sample);
            return new Card(new Listing(sample), imported.contains(id) ? reference(id) : null);
        }).toList();
    }

    @Transactional(isolation = Isolation.READ_COMMITTED, rollbackFor = IOException.class)
    Imported importCase(String projectId, String caseId) throws IOException {
        var sample = example(caseId);
        lockProject(projectId);
        return importExample(projectId, sample, importedDocumentIds(projectId));
    }
    @Transactional(isolation = Isolation.READ_COMMITTED, rollbackFor = IOException.class)
    List<Card> importAll(String projectId) throws IOException {
        lockProject(projectId);
        var existing = importedDocumentIds(projectId);
        for (var sample : examples) importExample(projectId, sample, existing);
        return list(projectId);
    }
    private Set<String> importedDocumentIds(String projectId) {
        return new HashSet<>(jdbc.queryForList("SELECT document_id FROM document_scope WHERE project_id = ?",
                String.class, projectId));
    }
    private void lockProject(String projectId) {
        jdbc.queryForObject("SELECT id FROM studio_project WHERE id = ? FOR UPDATE", String.class, projectId);
    }
    private Imported importExample(String projectId, Example sample, Set<String> existing) throws IOException {
        String id = documentId(projectId, sample);
        if (!existing.contains(id)) {
            var before = read(sample.before());
            var after = read(sample.after());
            String title = sample.project() + " · " + sample.title();
            docs.addDocument(id, projectId, title, before.text(), before.headings(), before.source());
            docs.addVersion(id, after);
        }
        return reference(id);
    }

    private static Imported reference(String id) {
        return new Imported(id, id + "-v1", id + "-v2");
    }
    Example upstreamReference(String projectId, String caseId, String runId) {
        var sample = example(caseId);
        String documentId = documentId(projectId, sample);
        var run = docs.requireRun(runId, false);
        if (!documentId.equals(run.documentId()) || !reference(documentId).beforeVersionId().equals(run.versionId())) {
            throw ApiFailure.notFound("当前原版没有这份审查记录。");
        }
        if (run.status() != Domain.RunStatus.COMPLETED && run.status() != Domain.RunStatus.PARTIAL) {
            throw ApiFailure.conflict("原版取得审查结果后可核对上游修订。");
        }
        return sample;
    }
    private Example example(String caseId) {
        return examples.stream().filter(item -> item.id().equals(caseId)).findFirst()
                .orElseThrow(() -> ApiFailure.notFound("找不到该公开案例。"));
    }

    private static String documentId(String projectId, Example sample) {
        String key = String.join("/", "public-case", projectId, sample.id(), sample.before().sha256(), sample.after().sha256());
        return UUID.nameUUIDFromBytes(key.getBytes(StandardCharsets.UTF_8)).toString();
    }

    private DocumentParser.Imported read(Source source) throws IOException {
        if (source.file() == null || !source.file().matches("[A-Za-z0-9_./-]+") || source.file().startsWith("/")
                || source.file().contains("..") || source.startLine() < 1 || source.endLine() < source.startLine()) {
            throw new IOException("公开案例的原文索引无效。");
        }
        byte[] bytes = new ClassPathResource("verified-cases/" + source.file()).getContentAsByteArray();
        try {
            String digest = HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(bytes));
            if (!digest.equalsIgnoreCase(source.sha256())) throw new IOException("公开案例原文校验失败。");
        } catch (NoSuchAlgorithmException impossible) {
            throw new IllegalStateException(impossible);
        }
        String path = URI.create(source.url()).getPath();
        String file = path.substring(path.lastIndexOf('/') + 1);
        String ext = file.toLowerCase(Locale.ROOT);
        String format = ext.endsWith(".rst") ? "RST" : ext.endsWith(".txt") ? "TXT" : "MARKDOWN";
        return parser.publicExcerpt(file, format, file, new String(bytes, StandardCharsets.UTF_8), source.startLine())
                .withFileDigest(source.sha256());
    }
}
