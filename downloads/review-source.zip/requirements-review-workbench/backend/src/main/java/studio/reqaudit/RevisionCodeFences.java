package studio.reqaudit;

import java.math.BigInteger;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;
import org.apache.poi.xwpf.usermodel.IBodyElement;
import org.apache.poi.xwpf.usermodel.XWPFParagraph;

/** Restore code block boundaries around the current Word text, including edits that split a paragraph. */
final class RevisionCodeFences {
    private static final Pattern NAME = Pattern.compile("^ReqCode(Open)?_[0-9]+_([A-Za-z0-9_]{1,32})$");
    final Map<IBodyElement, String> opening = new HashMap<>();
    final Map<IBodyElement, String> closing = new HashMap<>();

    RevisionCodeFences(List<IBodyElement> body) {
        BigInteger id = null;
        XWPFParagraph start = null;
        String language = "";
        boolean closed = false;
        int backticks = 2, tildes = 2;
        for (IBodyElement element : body) {
            if (!(element instanceof XWPFParagraph p)) {
                id = null;
                continue;
            }
            if ("CodeBlock".equals(p.getStyle())) {
                for (var mark : p.getCTP().getBookmarkStartList()) {
                    var match = NAME.matcher(mark.getName() == null ? "" : mark.getName());
                    if (!match.matches()) continue;
                    start = p;
                    id = mark.getId();
                    language = match.group(2);
                    closed = match.group(1) == null;
                    backticks = tildes = 2;
                    break;
                }
            }
            if (id == null) continue;
            for (String line : p.getText().split("\\R")) {
                String value = line.stripLeading();
                backticks = Math.max(backticks, leading(value, '`'));
                tildes = Math.max(tildes, leading(value, '~'));
            }
            for (var end : p.getCTP().getBookmarkEndList()) {
                if (!id.equals(end.getId())) continue;
                String marker = backticks <= tildes ? "`".repeat(backticks + 1) : "~".repeat(tildes + 1);
                opening.put(start, marker + language);
                if (closed) closing.put(p, marker);
                id = null;
                break;
            }
        }
    }

    private static int leading(String text, char character) {
        int n = 0;
        while (n < text.length() && text.charAt(n) == character) n++;
        return n;
    }
}
