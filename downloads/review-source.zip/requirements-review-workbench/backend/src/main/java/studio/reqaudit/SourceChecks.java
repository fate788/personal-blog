package studio.reqaudit;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectReader;

import java.util.ArrayList;
import java.util.ArrayDeque;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.regex.Pattern;

import static studio.reqaudit.Domain.RuleWarning;

final class SourceChecks {
    private static final ObjectReader JSON = new ObjectMapper().reader().with(DeserializationFeature.FAIL_ON_TRAILING_TOKENS);
    private static final Pattern FENCE = Pattern.compile("^\\s*(`{3,}|~{3,})(.*)$");
    private static final Pattern UUID_URN = Pattern.compile("(?i)\\burn:uuid:([a-z0-9_-]+)");
    private static final Pattern UUID = Pattern.compile("(?i)[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}");
    private static final Pattern HEADING = Pattern.compile("^ {0,3}(#{1,6})\\s+(.+)$");
    private static final Pattern NEGATIVE_CAPTION = Pattern.compile("(?iu)^(?:反例|错误示范|错误写法|无效(?:的)?\\s*(?:JSON|请求|输入)\\s*(?:示例|样例)?|错误(?:的)?\\s*(?:JSON|请求)\\s*(?:示例|样例)|(?:invalid|malformed|incorrect)\\s+(?:JSON|request|input)(?:\\s+examples?)?|counterexample)(?:\\s*[:：].*)?$");
    private static final int MAX_WARNINGS = 100;

    private record Block(String marker, int openLine, String language, boolean counterexample) {
        boolean json() { return language.equals("json"); }
        boolean shell() { return RequestExampleChecks.SHELL.matcher(language).matches(); }
    }

    private SourceChecks() {}

    static List<RuleWarning> inspect(String text) {
        return inspect(text, null);
    }

    static List<RuleWarning> inspect(String text, java.util.Set<Integer> verifiedCommaLines) {
        String[] lines = text.split("\n", -1);
        var warnings = new ArrayList<RuleWarning>();
        Block block = null;
        String caption = "";
        int negativeSection = 0;
        boolean syntaxSection = false;
        var sql = new SqlExampleChecks();
        var worked = new WorkedArrayChecks();
        int used = 0;
        for (int index = 0; index < lines.length; index++) {
            String line = lines[index];
            var fence = FENCE.matcher(line);
            if (fence.matches()) {
                if (block == null) {
                    String language = fence.group(2).strip().toLowerCase(Locale.ROOT);
                    block = new Block(fence.group(1), index + 1, language,
                            negativeSection > 0 || negativeCaption(caption));
                    caption = "";
                    continue;
                }
                if (fence.group(1).startsWith(block.marker()) && fence.group(2).isBlank()) {
                    if (block.json() && !block.counterexample()) {
                        String json = String.join("\n", Arrays.copyOfRange(lines, block.openLine(), index));
                        RuleWarning warning = json.isBlank()
                                ? new RuleWarning("EMPTY_JSON_EXAMPLE", "标记为 JSON 的代码块未包含 JSON 值。", block.openLine())
                                : checkJson(json, block.openLine() + 1, verifiedCommaLines);
                        if (warning != null && used++ < MAX_WARNINGS) warnings.add(warning);
                    } else if (block.shell() && !block.counterexample()) {
                        for (var command : CurlExamples.read(lines, block.openLine(), index)) {
                            var body = command.jsonBody();
                            if (body == null) continue;
                            RuleWarning warning = checkJson(body.value(), body.line(), verifiedCommaLines);
                            if (warning != null && used++ < MAX_WARNINGS) warnings.add(warning);
                        }
                    }
                    if (!block.counterexample()) {
                        RuleWarning warning = sql.block(block.language(), lines, block.openLine(), index, syntaxSection);
                        if (warning != null && used++ < MAX_WARNINGS) warnings.add(warning);
                        var mismatch = worked.block(block.language(), lines, block.openLine(), index);
                        if (mismatch != null && used++ < MAX_WARNINGS) warnings.add(mismatch);
                    }
                    block = null;
                    continue;
                }
            }
            if (block == null && !line.isBlank()) {
                var heading = HEADING.matcher(line);
                if (heading.matches()) {
                    int level = heading.group(1).length();
                    syntaxSection = heading.group(2).strip().matches("(?i)语法|语法格式|syntax|synopsis");
                    if (level == 1 || syntaxSection) sql = new SqlExampleChecks();
                    if (level == 1) worked = new WorkedArrayChecks();
                    if (level <= negativeSection) negativeSection = 0;
                    if (negativeSection == 0 && negativeCaption(heading.group(2))) negativeSection = level;
                }
                if (negativeSection == 0 && !negativeCaption(line)) worked.definition(line);
                caption = line;
            }
            if (block != null && block.counterexample()) continue;
            var uris = UUID_URN.matcher(line);
            while (uris.find()) {
                String value = uris.group(1);
                if (!looksLikeUuid(value) || line.startsWith("…", uris.end()) || line.startsWith("...", uris.end())) continue;
                if (!UUID.matcher(value).matches() && used++ < MAX_WARNINGS) {
                    warnings.add(new RuleWarning("INVALID_UUID_URN",
                            "UUID URN 的标识应为 8-4-4-4-12 位十六进制字符。请核对原文中的标识。", index + 1));
                }
            }
        }
        if (block != null && block.json() && used++ < MAX_WARNINGS) {
            warnings.add(new RuleWarning("UNCLOSED_JSON_EXAMPLE", "标记为 JSON 的代码块缺少结束标记。", block.openLine()));
        }
        for (RuleWarning warning : RequestExampleChecks.inspect(lines)) {
            if (used++ < MAX_WARNINGS) warnings.add(warning);
        }
        if (used > MAX_WARNINGS) {
            warnings.add(new RuleWarning("SOURCE_CHECK_LIMIT", "另有 " + (used - MAX_WARNINGS) + " 条原件检查提示未展开。", 0));
        }
        return warnings;
    }

    private static boolean looksLikeUuid(String value) {
        return value.length() >= 18 && value.chars().filter(character -> character == '-').count() >= 2
                && value.chars().anyMatch(character -> character >= '0' && character <= '9');
    }

    private static boolean negativeCaption(String line) {
        return NEGATIVE_CAPTION.matcher(line.strip().replaceFirst("^[-*+]\\s+", "").replace("**", "")).matches();
    }

    private static RuleWarning checkJson(String text, int startLine, java.util.Set<Integer> verifiedCommaLines) {
        try {
            JSON.readTree(text);
            return null;
        } catch (JsonProcessingException failure) {
            if (text.contains("...") || text.contains("…")) {
                try {
                    JSON.readTree(fillOmissions(text));
                    return null;
                } catch (JsonProcessingException remaining) {
                    failure = remaining;
                }
            }
            String[] lines = text.split("\n", -1);
            int row = failure.getLocation() == null ? 0 : failure.getLocation().getLineNr() - 1;
            row = Math.max(0, Math.min(lines.length - 1, row));
            if (row > 0 && lines[row].stripLeading().matches("^[}\\]].*")
                    && lines[row - 1].stripTrailing().endsWith(",")) {
                row--;
                if (verifiedCommaLines != null) {
                    int comma = lines[row].stripTrailing().length() - 1;
                    lines[row] = lines[row].substring(0, comma) + lines[row].substring(comma + 1);
                    try {
                        JSON.readTree(String.join("\n", lines));
                        verifiedCommaLines.add(startLine + row);
                    } catch (JsonProcessingException stillMalformed) { /* No automatic replacement for this example. */ }
                }
            }
            return new RuleWarning("INVALID_JSON_EXAMPLE",
                    "JSON 示例无法按严格 JSON 解析。请核对该行及相邻行的分隔符、引号或括号。", startLine + row);
        }
    }

    /** Replace only unquoted omission tokens in structural positions; other syntax errors remain visible. */
    private static String fillOmissions(String text) {
        var result = new StringBuilder(text.length());
        var stack = new ArrayDeque<Character>();
        boolean quoted = false;
        char previous = 0;
        for (int i = 0; i < text.length(); i++) {
            char ch = text.charAt(i);
            if (quoted) {
                result.append(ch);
                if (ch == '\\' && i + 1 < text.length()) result.append(text.charAt(++i));
                else if (ch == '"') { quoted = false; previous = '"'; }
                continue;
            }
            if ((ch == '…' || text.startsWith("...", i)) && !stack.isEmpty() && "{[:,".indexOf(previous) >= 0) {
                int end = i + 1;
                while (end < text.length() && text.charAt(end) == ch) end++;
                if (end == text.length() || ",}] \r\n\t".indexOf(text.charAt(end)) >= 0) {
                    result.append(stack.peek() == '{' && previous != ':' ? "\"__omitted__\":null" : "null");
                    i = end - 1;
                    previous = 'l';
                    continue;
                }
            }
            if (ch == '"') quoted = true;
            else if (ch == '{' || ch == '[') stack.push(ch);
            else if ((ch == '}' || ch == ']') && !stack.isEmpty()) stack.pop();
            if (!Character.isWhitespace(ch)) previous = ch;
            result.append(ch);
        }
        return result.toString();
    }
}
