package studio.reqaudit;

import java.util.*;
import java.util.regex.Pattern;

import static studio.reqaudit.Domain.RuleWarning;

/** Recompute a documented occurrence-count operation only after a definition and a worked example agree. */
final class WorkedArrayChecks {
    private static final String NAME = "([A-Za-z_][A-Za-z0-9_]*)";
    private static final Pattern WITNESS = Pattern.compile(NAME + "\\s*\\(([^()=]{1,1500})\\)\\s*=\\s*(\\[[+\\-\\d,\\s]+])");
    private static final Pattern QUERY = Pattern.compile("(?i)^select\\s+" + NAME + "\\s*\\((.+)\\)\\s*;?$");
    private static final Pattern HEADER = Pattern.compile("^\\|\\s*" + NAME + "\\s*\\((.+)\\)\\s*\\|$");
    private static final Pattern VECTOR = Pattern.compile("(?i)\\s*(?:\\[([^\\[\\]()]+)]|array\\s*\\(([^()\\[\\]]+)\\))\\s*(,|$)");
    private static final Pattern INTEGER = Pattern.compile("[+-]?[0-9]{1,9}");
    private final Map<String, Set<Boolean>> documented = new HashMap<>();
    private List<List<Integer>> query;
    private String name;
    private int queryClose;

    void definition(String text) {
        if (text.length() > 2200) return;
        boolean multi = text.contains("元组") && text.contains("相同位置");
        boolean occurrence = text.contains("相同值") && text.contains("中的位置")
                || text.contains("第几次出现");
        if (!occurrence) return;
        var witness = WITNESS.matcher(text);
        while (witness.find()) {
            var inputs = vectors(witness.group(2));
            var outputs = vectors(witness.group(3));
            if (inputs.isEmpty() || outputs.size() != 1 || inputs.size() > 1 && !multi) continue;
            List<Integer> example = counts(inputs);
            if (example.equals(outputs.get(0)) && example.stream().anyMatch(n -> n > 1)) {
                documented.computeIfAbsent(witness.group(1).toLowerCase(Locale.ROOT), k -> new HashSet<>()).add(inputs.size() > 1);
            }
        }
    }

    RuleWarning block(String language, String[] lines, int start, int end) {
        if (language.equals("sql")) {
            query = null;
            if (end - start != 1 || lines[start].length() > 2000) return null;
            var match = QUERY.matcher(lines[start].strip());
            if (!match.matches()) return null;
            name = match.group(1).toLowerCase(Locale.ROOT);
            var arities = documented.get(name);
            if (arities == null) return null;
            var inputs = vectors(match.group(2));
            if (!inputs.isEmpty() && arities.contains(inputs.size() > 1)) {
                query = inputs;
                queryClose = end;
            }
            return null;
        }
        var inputs = query;
        query = null;
        if (inputs == null || !Set.of("text", "plaintext", "console", "").contains(language) || end - start != 5) return null;
        for (int i = queryClose + 1; i < start - 1; i++) if (!lines[i].isBlank()) return null;
        String border = lines[start].strip();
        if (!border.matches("\\+-+\\+") || !border.equals(lines[start + 2].strip()) || !border.equals(lines[start + 4].strip())) return null;
        if (lines[start + 1].length() > 2000 || lines[start + 3].length() > 2000) return null;
        var header = HEADER.matcher(lines[start + 1].strip());
        if (!header.matches() || !name.equalsIgnoreCase(header.group(1)) || !inputs.equals(vectors(header.group(2)))) return null;
        String cell = lines[start + 3].strip();
        if (!cell.startsWith("|") || !cell.endsWith("|") || cell.length() < 3) return null;
        var result = vectors(cell.substring(1, cell.length() - 1));
        var expected = counts(inputs);
        if (result.size() != 1 || result.get(0).size() != expected.size()) return null;
        for (int i = 0; i < expected.size(); i++) {
            if (!expected.get(i).equals(result.get(0).get(i))) {
                return new RuleWarning("WORKED_OCCURRENCE_MISMATCH", "按文档给出的出现次序定义，第 " + (i + 1)
                        + " 项截至此处出现 " + expected.get(i) + " 次，结果表写的是 " + result.get(0).get(i) + "。",
                        start + 4, queryClose);
            }
        }
        return null;
    }

    private static List<List<Integer>> vectors(String text) {
        var arrays = new ArrayList<List<Integer>>();
        var m = VECTOR.matcher(text);
        for (int pos = 0; pos < text.length();) {
            m.region(pos, text.length());
            if (arrays.size() == 8 || !m.lookingAt()) return List.of();
            String values = m.group(1) == null ? m.group(2) : m.group(1);
            var row = new ArrayList<Integer>();
            for (String token : values.split(",", -1)) {
                if (row.size() == 128 || !INTEGER.matcher(token.strip()).matches()) return List.of();
                row.add(Integer.parseInt(token.strip()));
            }
            if (!arrays.isEmpty() && row.size() != arrays.get(0).size()) return List.of();
            arrays.add(row);
            pos = m.end();
            if (!m.group(3).isEmpty() && pos == text.length()) return List.of();
        }
        return arrays;
    }

    private static List<Integer> counts(List<List<Integer>> arrays) {
        var occurrences = new HashMap<List<Integer>, Integer>();
        var output = new ArrayList<Integer>();
        for (int i = 0; i < arrays.get(0).size(); i++) {
            var tuple = new ArrayList<Integer>();
            for (var array : arrays) tuple.add(array.get(i));
            output.add(occurrences.merge(tuple, 1, Integer::sum));
        }
        return output;
    }
}
