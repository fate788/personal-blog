package studio.reqaudit;

import org.springframework.stereotype.Component;
import org.springframework.beans.factory.annotation.Value;

import java.util.*;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import static studio.reqaudit.Domain.*;

@Component
class ReviewPlanner {
    static final int MAX_PRIMARY_CHARS = 11_000;
    static final int PER_BATCH = 4;
    static final int MAX_CONTEXT_ITEMS = 7;
    static final int MAX_TOTAL_CHARS = 11_000;
    private static final int NORMAL_PRIMARY_BUDGET = 8_000;

    private static final Pattern TERMS_IN_TEXT = Pattern.compile("[\\p{IsHan}]+|[a-z0-9_]{2,}");
    private static final Pattern TERMS = Pattern.compile("(?i)术语|名词|词汇|定义|glossary|definitions");
    private static final Pattern REFERENCES = Pattern.compile("(?i)(?<![A-Z0-9])([A-Z][A-Z0-9]{0,12}-\\d{1,12})(?![A-Z0-9])");
    private final int maxBatches;

    record Batch(int number, List<Item> primary, List<Item> context, List<Item> sourceLines) {
        Batch(int number, List<Item> primary, List<Item> context) {
            this(number, primary, context, List.of());
        }
    }
    record Plan(List<Batch> batches, int plannedBatches, int batchLimit, List<String> overBudgetItemIds,
                List<String> oversizedItemIds) {}
    private record Features(Set<String> words, Set<String> references, boolean glossary) {}
    private record Related(Item item, int score) {}

    ReviewPlanner(@Value("${review.audit.max-batches}") int maxBatches) {
        if (maxBatches < 1 || maxBatches > 512) {
            throw new IllegalArgumentException("REVIEW_AUDIT_MAX_BATCHES 需设为 1 至 512。");
        }
        this.maxBatches = maxBatches;
    }

    int batchLimit() { return maxBatches; }

    Plan plan(List<Item> items, Set<String> selected, Map<String, Set<String>> knownRelations, boolean addContext) {
        var eligible = items.stream().filter(item -> item.text().length() <= MAX_PRIMARY_CHARS).toList();
        var primaryCandidates = eligible.stream().filter(item -> selected.contains(item.id())).toList();
        var oversized = items.stream().filter(item -> selected.contains(item.id()) && item.text().length() > MAX_PRIMARY_CHARS)
                .map(Item::id).toList();
        var groups = partition(primaryCandidates);
        int scheduled = Math.min(groups.size(), maxBatches);
        var omitted = groups.subList(scheduled, groups.size()).stream().flatMap(List::stream).map(Item::id).toList();
        if (!addContext) {
            var scheduledGroups = new ArrayList<Batch>();
            for (List<Item> group : groups.subList(0, scheduled)) {
                scheduledGroups.add(new Batch(scheduledGroups.size() + 1, group, List.of()));
            }
            return new Plan(List.copyOf(scheduledGroups), groups.size(), maxBatches, omitted, oversized);
        }
        var features = new HashMap<String, Features>();
        for (Item item : eligible) {
            features.put(item.id(), features(item));
        }
        var batches = new ArrayList<Batch>();
        for (List<Item> primary : groups.subList(0, scheduled)) {
            var primaryIds = primary.stream().map(Item::id).collect(Collectors.toSet());
            var relatedIds = primary.stream().flatMap(item -> knownRelations.getOrDefault(item.id(), Set.of()).stream())
                    .collect(Collectors.toSet());
            var ranked = eligible.stream().filter(item -> !primaryIds.contains(item.id()))
                    .map(item -> new Related(item, relationship(primary, item, features)
                            + (relatedIds.contains(item.id()) ? 1_000 : 0)))
                    .filter(entry -> entry.score() > 0)
                    .sorted(Comparator.comparingInt(Related::score).reversed()
                            .thenComparingInt(entry -> entry.item().line())).toList();
            var context = new ArrayList<Item>();
            int available = MAX_TOTAL_CHARS - primary.stream().mapToInt(item -> item.text().length()).sum();
            for (Related entry : ranked) {
                int length = entry.item().text().length();
                if (context.size() >= MAX_CONTEXT_ITEMS) {
                    break;
                }
                if (length <= available) {
                    context.add(entry.item());
                    available -= length;
                }
            }
            batches.add(new Batch(batches.size() + 1, primary, List.copyOf(context)));
        }
        return new Plan(List.copyOf(batches), groups.size(), maxBatches, omitted, oversized);
    }

    private static List<List<Item>> partition(List<Item> items) {
        var groups = new ArrayList<List<Item>>();
        var current = new ArrayList<Item>();
        int chars = 0;
        for (Item item : items) {
            int length = item.text().length();
            if (!current.isEmpty() && (current.size() == PER_BATCH || chars + length > NORMAL_PRIMARY_BUDGET)) {
                groups.add(List.copyOf(current));
                current.clear();
                chars = 0;
            }
            current.add(item);
            chars += length;
        }
        if (!current.isEmpty()) groups.add(List.copyOf(current));
        return groups;
    }

    private int relationship(List<Item> primary, Item item, Map<String, Features> features) {
        int max = 0;
        Features itemFeatures = features.get(item.id());
        for (Item target : primary) {
            int score = 0;
            Features targetFeatures = features.get(target.id());
            if (targetFeatures.references().contains(item.code()) || itemFeatures.references().contains(target.code())) {
                score += 60;
            }
            if (item.section().equals(target.section())) {
                score += 10;
            }
            if (itemFeatures.glossary()) {
                score += 9;
            }
            if (Math.abs(item.line() - target.line()) <= 3) {
                score += 4;
            }
            int overlap = 0;
            for (String word : itemFeatures.words()) {
                if (targetFeatures.words().contains(word) && ++overlap >= 30) break;
            }
            score += overlap;
            max = Math.max(max, score);
        }
        return max;
    }

    private Features features(Item item) {
        var grams = new HashSet<String>();
        String text = item.text();
        var sequences = TERMS_IN_TEXT.matcher(text.toLowerCase(Locale.ROOT));
        while (sequences.find()) {
            String word = sequences.group();
            if (word.charAt(0) <= 127) {
                grams.add(word);
                continue;
            }
            for (int index = 1; index < word.length(); index++) {
                grams.add(word.substring(index - 1, index + 1));
            }
        }
        var refs = new HashSet<String>();
        var matcher = REFERENCES.matcher(text);
        while (matcher.find()) refs.add(matcher.group(1).toUpperCase(Locale.ROOT));
        return new Features(grams, refs, TERMS.matcher(item.section()).find());
    }
}
