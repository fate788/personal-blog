package studio.reqaudit;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;
import java.nio.charset.StandardCharsets;
import java.security.GeneralSecurityException;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.time.Duration;
import java.time.Instant;
import java.util.Arrays;
import java.util.Base64;
import java.util.List;
import java.util.Locale;

@Service
class Accounts {
    static final Duration SESSION_LENGTH = Duration.ofHours(12);
    private static final String ADMIN_ID = "initial-administrator";
    private static final int ITERATIONS = 600_000;
    private static final Base64.Encoder ENCODER = Base64.getUrlEncoder().withoutPadding();
    private static final Base64.Decoder DECODER = Base64.getUrlDecoder();
    private static final SecureRandom RANDOM = new SecureRandom();
    private static final byte[] DUMMY_SALT = new byte[16];

    enum Role { ADMIN, MEMBER }
    record User(String id, String username, String displayName, Role role) {}
    record Credential(User user, String passwordHash) {}
    record Session(String token, User user) {}
    record Credentials(String username, String password, String displayName, String setupToken) {}

    private final JdbcTemplate jdbc;
    private final byte[] setupToken;

    Accounts(JdbcTemplate jdbc, @Value("${review.setup.token}") String setupToken) {
        this.jdbc = jdbc;
        this.setupToken = setupToken.getBytes(StandardCharsets.UTF_8);
    }

    boolean initialized() {
        return jdbc.queryForObject("SELECT COUNT(*) FROM studio_account", Long.class) > 0;
    }

    boolean requiresSetupToken() { return setupToken.length != 0; }

    boolean claimOnboarding(User user) {
        try {
            jdbc.update("INSERT INTO studio_onboarding (account_id, shown_at) VALUES (?, ?)", user.id(), Instant.now().toString());
            return true;
        } catch (DuplicateKeyException alreadyShown) {
            return false;
        }
    }

    @Transactional
    Session setup(Credentials credentials) {
        if (initialized()) {
            throw ApiFailure.conflict("管理员已创建，请登录。");
        }
        String supplied = credentials.setupToken() == null ? "" : credentials.setupToken();
        if (requiresSetupToken() && (supplied.length() > 512 ||
                !MessageDigest.isEqual(setupToken, supplied.getBytes(StandardCharsets.UTF_8)))) {
            throw ApiFailure.forbidden("初始化令牌无效。");
        }
        validateManagedPassword(credentials.password());
        var user = create(ADMIN_ID, credentials, Role.ADMIN);
        migrateLegacyDocuments(user.id());
        return start(user);
    }

    @Transactional
    User addMember(User administrator, Credentials credentials) {
        requireAdmin(administrator);
        validateManagedPassword(credentials.password());
        return create(AuditRepository.id(), credentials, Role.MEMBER);
    }

    @Transactional
    Session register(Credentials credentials, String previousToken) {
        if (!initialized()) throw ApiFailure.conflict("工作区尚未初始化，请联系管理员。");
        User user = create(AuditRepository.id(), credentials, Role.MEMBER);
        logout(previousToken);
        return start(user);
    }

    List<User> members(User administrator) {
        requireAdmin(administrator);
        return jdbc.query("SELECT id, username, display_name, account_role FROM studio_account ORDER BY created_at, id",
                (row, index) -> new User(row.getString(1), row.getString(2), row.getString(3),
                        Role.valueOf(row.getString(4))));
    }

    @Transactional
    Session login(Credentials credentials, String previousToken) {
        String username = normalizedUsername(credentials.username());
        String password = credentials.password();
        if (password == null || password.isEmpty()) {
            throw ApiFailure.unauthorized("账号或密码不正确。");
        }
        var credential = jdbc.query(
                "SELECT id, username, display_name, account_role, password_hash FROM studio_account WHERE username = ?",
                (row, index) -> new Credential(new User(row.getString(1), row.getString(2), row.getString(3),
                        Role.valueOf(row.getString(4))), row.getString(5)), username).stream().findFirst();
        if (credential.isEmpty()) {
            derive(password, DUMMY_SALT, ITERATIONS);
            throw ApiFailure.unauthorized("账号或密码不正确。");
        }
        if (!verified(password, credential.get().passwordHash())) {
            throw ApiFailure.unauthorized("账号或密码不正确。");
        }
        logout(previousToken);
        return start(credential.get().user());
    }

    User fromToken(String token) {
        if (!validTokenFormat(token)) return null;
        return jdbc.query("""
                SELECT a.id, a.username, a.display_name, a.account_role
                FROM studio_session s JOIN studio_account a ON a.id = s.account_id
                WHERE s.token_hash = ? AND s.expires_ms > ?
                """, (row, index) -> new User(row.getString(1), row.getString(2), row.getString(3),
                        Role.valueOf(row.getString(4))), digest(token), System.currentTimeMillis())
                .stream().findFirst().orElse(null);
    }

    void logout(String token) {
        if (validTokenFormat(token)) jdbc.update("DELETE FROM studio_session WHERE token_hash = ?", digest(token));
    }

    private Session start(User user) {
        long now = System.currentTimeMillis();
        jdbc.update("DELETE FROM studio_session WHERE expires_ms <= ?", now);
        String token = ENCODER.encodeToString(random(32));
        jdbc.update("INSERT INTO studio_session (token_hash, account_id, expires_ms) VALUES (?, ?, ?)",
                digest(token), user.id(), now + SESSION_LENGTH.toMillis());
        return new Session(token, user);
    }

    private User create(String id, Credentials credentials, Role role) {
        String username = normalizedUsername(credentials.username());
        String displayName = ApiFailure.optionalText(credentials.displayName(), "显示名称", 100);
        if (displayName.isEmpty()) displayName = username;
        String password = credentials.password();
        if (password == null || password.isEmpty()) throw ApiFailure.badRequest("请输入密码。");
        byte[] salt = random(16);
        String passwordHash = ITERATIONS + ":" + ENCODER.encodeToString(salt) + ":" +
                ENCODER.encodeToString(derive(password, salt, ITERATIONS));
        try {
            jdbc.update("""
                    INSERT INTO studio_account (id, username, display_name, password_hash, account_role, created_at)
                    VALUES (?, ?, ?, ?, ?, ?)
                    """, id, username, displayName, passwordHash, role.name(), Instant.now().toString());
        } catch (DuplicateKeyException ex) {
            throw ApiFailure.conflict(role == Role.ADMIN ? "管理员已创建，请登录。" : "此账号名已被使用。");
        }
        return new User(id, username, displayName, role);
    }

    private void migrateLegacyDocuments(String owner) {
        if (jdbc.queryForObject("""
                SELECT COUNT(*) FROM review_document d
                LEFT JOIN document_scope s ON d.id = s.document_id WHERE s.document_id IS NULL
                """, Long.class) == 0) return;
        String now = Instant.now().toString();
        String project = AuditRepository.id();
        jdbc.update("""
                INSERT INTO studio_project (id, owner_id, name, description, created_at, updated_at)
                VALUES (?, ?, ?, ?, ?, ?)
                """, project, owner, "旧版文档迁移", "保留首次安装前的文档版本和审查历史。", now, now);
        jdbc.update("""
                INSERT INTO document_scope (document_id, project_id)
                SELECT d.id, ? FROM review_document d
                LEFT JOIN document_scope s ON d.id = s.document_id WHERE s.document_id IS NULL
                """, project);
    }

    private static void requireAdmin(User user) {
        if (user.role() != Role.ADMIN) throw ApiFailure.forbidden("只有管理员可管理登录账号。");
    }

    private static void validateManagedPassword(String password) {
        if (password == null || password.length() < 12 || password.length() > 128 || password.isBlank()) {
            throw ApiFailure.badRequest("密码须为 12 至 128 个字符。");
        }
    }

    static String normalizedUsername(String value) {
        String username = value == null ? "" : value.strip().toLowerCase(Locale.ROOT);
        if (!username.matches("[a-z0-9][a-z0-9._-]{2,39}")) {
            throw ApiFailure.badRequest("账号名须为 3 至 40 个字母、数字、点、下划线或连字符，并以字母或数字开头。");
        }
        return username;
    }

    private static byte[] derive(String password, byte[] salt, int iterations) {
        char[] characters = password.toCharArray();
        var spec = new PBEKeySpec(characters, salt, iterations, 256);
        try {
            return SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).getEncoded();
        } catch (GeneralSecurityException ex) {
            throw new IllegalStateException("无法处理账号凭据。", ex);
        } finally {
            spec.clearPassword();
            Arrays.fill(characters, '\0');
        }
    }

    private static boolean verified(String password, String stored) {
        String[] fields = stored.split(":", -1);
        if (fields.length != 3) return false;
        return MessageDigest.isEqual(DECODER.decode(fields[2]), derive(password, DECODER.decode(fields[1]),
                Integer.parseInt(fields[0])));
    }

    private static byte[] random(int count) {
        byte[] value = new byte[count];
        RANDOM.nextBytes(value);
        return value;
    }

    private static boolean validTokenFormat(String token) {
        return token != null && token.length() == 43 && token.matches("[A-Za-z0-9_-]+");
    }

    private static String digest(String token) {
        try {
            return ENCODER.encodeToString(MessageDigest.getInstance("SHA-256")
                    .digest(token.getBytes(StandardCharsets.UTF_8)));
        } catch (GeneralSecurityException ex) {
            throw new IllegalStateException("无法处理登录会话。", ex);
        }
    }
}
