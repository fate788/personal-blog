package studio.reqaudit;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;

import static studio.reqaudit.Accounts.User;
import static studio.reqaudit.Domain.Pack;
import static studio.reqaudit.Projects.ProjectRole.OWNER;
import static studio.reqaudit.StudioAccess.ACCOUNT;

@RestController
@RequestMapping("/api/projects/{projectId}/packs")
class ProjectPacksController {
    private final ProjectPacks packs;
    private final Projects projects;

    ProjectPacksController(ProjectPacks packs, Projects projects) {
        this.packs = packs;
        this.projects = projects;
    }

    @GetMapping
    List<Pack> list(@RequestAttribute(ACCOUNT) User user, @PathVariable String projectId) {
        projects.accessible(user.id(), projectId);
        return packs.list(projectId);
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    Pack create(@RequestAttribute(ACCOUNT) User user, @PathVariable String projectId,
                @RequestBody ProjectPacks.Input body) {
        requireOwner(user, projectId);
        return packs.create(projectId, body);
    }

    @PutMapping("/{id}")
    Pack update(@RequestAttribute(ACCOUNT) User user, @PathVariable String projectId,
                @PathVariable String id, @RequestBody ProjectPacks.Input body) {
        requireOwner(user, projectId);
        return packs.update(projectId, id, body);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    void archive(@RequestAttribute(ACCOUNT) User user, @PathVariable String projectId,
                 @PathVariable String id, @RequestParam int revision) {
        requireOwner(user, projectId);
        packs.archive(projectId, id, revision);
    }

    private void requireOwner(User user, String projectId) {
        if (projects.accessible(user.id(), projectId).role() != OWNER) {
            throw ApiFailure.forbidden("仅项目所有者可以维护本项目的自定义审查包。");
        }
    }
}
