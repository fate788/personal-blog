package studio.reqaudit;

import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.EnumMap;
import java.util.HexFormat;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import static studio.reqaudit.Domain.ModelProfile;
import static studio.reqaudit.Domain.ModelProfile.BACKUP;
import static studio.reqaudit.Domain.ModelProfile.PRIMARY;

@Component
class ModelProfiles {
    private static final String EVOLINK_ENDPOINT = "https://direct.evolink.ai/v1/chat/completions";
    private static final String EVOLINK_MODEL = "deepseek-v4.1-flash";
    private static final String EVOLINK_LABEL = "DeepSeek V4.1 Flash · EvoLink";

    enum OutputFormat { PROMPT, JSON_OBJECT, JSON_SCHEMA }
    enum TokenLimit { MAX_TOKENS, MAX_COMPLETION_TOKENS }
    enum Thinking { AUTO, OFF, ON }

    record Settings(ModelProfile id, String label, URI endpoint, String model, String key, OutputFormat format,
                    int timeoutSeconds, int maxOutputTokens, int retries, TokenLimit tokenLimit, String reasoningEffort,
                    Thinking thinking, String revision) {
        boolean configured() { return endpoint != null; }

        String origin() {
            return configured() ? endpoint.getScheme() + "://" + endpoint.getAuthority() : "";
        }
    }

    private final Map<ModelProfile, Settings> settings;
    private final boolean allowPrivateEndpoints;

    ModelProfiles(Environment environment) {
        var profiles = new EnumMap<ModelProfile, Settings>(ModelProfile.class);
        Settings backup = read(environment, BACKUP, "review.model.backup.", "备用模型", "");
        boolean useProviderDefault = environment.getProperty("REVIEW_USE_EVOLINK", Boolean.class, false);
        String evoLinkKey = useProviderDefault && !backup.configured()
                ? environment.getProperty("EVOLINK_API_KEY", "").strip() : "";
        profiles.put(PRIMARY, read(environment, PRIMARY, "review.model.", "主模型", evoLinkKey));
        profiles.put(BACKUP, backup);
        for (Settings profile : profiles.values()) {
            for (Settings other : profiles.values()) {
                if (other.key().isEmpty()) continue;
                if (profile.label().contains(other.key()) || profile.model().contains(other.key())
                        || profile.endpoint() != null && profile.endpoint().toString().contains(other.key())) {
                    throw new IllegalArgumentException("模型名称、标签和接口地址必须与密钥分开配置。");
                }
            }
        }
        settings = Map.copyOf(profiles);
        allowPrivateEndpoints = environment.getProperty("review.model.allow-private", Boolean.class, false);
    }

    Settings get(ModelProfile profile) {
        return settings.get(profile == null ? PRIMARY : profile);
    }

    List<Settings> available() {
        return List.of(settings.get(PRIMARY), settings.get(BACKUP));
    }

    boolean allowPrivateEndpoints() { return allowPrivateEndpoints; }

    private static Settings read(Environment environment, ModelProfile profile, String prefix, String defaultLabel,
                                 String evoLinkKey) {
        String model = text(environment, prefix, "name", "");
        String address = text(environment, prefix, "endpoint", "");
        String key = text(environment, prefix, "api-key", "");
        String label = text(environment, prefix, "label", defaultLabel);
        if (label.isBlank()) label = defaultLabel;
        boolean useEvoLink = address.isEmpty() && model.isEmpty() && key.isEmpty() && !evoLinkKey.isEmpty();
        if (useEvoLink) {
            address = EVOLINK_ENDPOINT;
            model = EVOLINK_MODEL;
            key = evoLinkKey;
            label = EVOLINK_LABEL;
        }
        if (address.isBlank() != model.isBlank()) {
            throw new IllegalArgumentException(defaultLabel + "的接口地址与模型名称需要一起配置。");
        }
        if (model.length() > 160 || !safeLabel(model) || label.isBlank() || label.length() > 100 || !safeLabel(label)
                || !key.isEmpty() && (label.contains(key) || model.contains(key))) {
            throw new IllegalArgumentException(defaultLabel + "的名称或标签格式无效。");
        }
        if (key.length() > 4_096 || !key.chars().allMatch(ch -> ch >= 33 && ch <= 126)) {
            throw new IllegalArgumentException(defaultLabel + "的密钥格式无效。");
        }
        URI endpoint = address.isBlank() ? null : endpoint(address, defaultLabel);
        OutputFormat format = useEvoLink ? OutputFormat.JSON_OBJECT
                : validEnum(environment, prefix, "format", OutputFormat.class, OutputFormat.PROMPT);
        TokenLimit tokenLimit = validEnum(environment, prefix, "token-limit-field", TokenLimit.class,
                TokenLimit.MAX_TOKENS);
        int timeout = bounded(environment, prefix, "timeout-seconds", 30, 2, 180);
        int output = bounded(environment, prefix, "max-output-tokens", 6_144, 512, 32_768);
        int retries = bounded(environment, prefix, "retries", 1, 0, 2);
        Thinking thinking = useEvoLink ? Thinking.OFF : thinking(environment, prefix);
        String effort = text(environment, prefix, "reasoning-effort", "").toLowerCase(Locale.ROOT);
        if (!List.of("", "none", "minimal", "low", "medium", "high", "xhigh", "max").contains(effort)) {
            throw new IllegalArgumentException(defaultLabel + "的推理强度设置无效。");
        }
        if (thinking == Thinking.ON && effort.equals("none")) {
            throw new IllegalArgumentException(defaultLabel + "开启思考后，推理强度不能设为 none。");
        }
        if (thinking == Thinking.OFF) effort = "";
        String[] wireSettings = { address, model, label, format.name(), tokenLimit.name(), effort,
                String.valueOf(timeout), String.valueOf(output), String.valueOf(retries) };
        String revision = thinking == Thinking.AUTO ? digest(wireSettings)
                : digest(String.join("\n", wireSettings), thinking.name());
        return new Settings(profile, label, endpoint, model, key, format, timeout, output, retries, tokenLimit,
                effort, thinking, revision);
    }

    private static Thinking thinking(Environment environment, String prefix) {
        return switch (text(environment, prefix, "thinking", "AUTO").toUpperCase(Locale.ROOT)) {
            case "AUTO" -> Thinking.AUTO;
            case "OFF", "DISABLED" -> Thinking.OFF;
            case "ON", "ENABLED" -> Thinking.ON;
            default -> throw new IllegalArgumentException(prefix + "thinking 需设为 AUTO、OFF 或 ON。");
        };
    }

    static boolean literalLoopback(String host) {
        return List.of("localhost", "127.0.0.1", "::1", "[::1]").contains(host.toLowerCase(Locale.ROOT));
    }

    private static URI endpoint(String address, String label) {
        URI uri = null;
        try {
            uri = new URI(address);
        } catch (java.net.URISyntaxException ignored) {
            // Preserve the operator-facing message without logging the configured URL.
        }
        if (uri == null || uri.getHost() == null || uri.getRawUserInfo() != null || uri.getRawFragment() != null
                || uri.getRawQuery() != null || uri.getRawPath() == null || uri.getRawPath().isBlank()
                || uri.getPort() > 65_535
                || !("https".equalsIgnoreCase(uri.getScheme())
                || "http".equalsIgnoreCase(uri.getScheme()) && literalLoopback(uri.getHost()))) {
            throw new IllegalArgumentException(label + "须使用 HTTPS 完整接口地址。本机回环地址可使用 HTTP。"
                    + " 地址不能包含登录凭据、查询或片段。");
        }
        return uri;
    }

    private static boolean safeLabel(String value) {
        return value.codePoints().allMatch(ch -> !Character.isISOControl(ch) && ch != 0x202E && ch != 0x202D);
    }

    private static String text(Environment environment, String prefix, String key, String defaultValue) {
        return environment.getProperty(prefix + key, defaultValue).strip();
    }

    private static int bounded(Environment environment, String prefix, String key, int initial, int min, int max) {
        try {
            int value = Integer.parseInt(text(environment, prefix, key, String.valueOf(initial)));
            if (value >= min && value <= max) return value;
        } catch (NumberFormatException ignored) {
            // The supplied string is intentionally excluded from the error.
        }
        throw new IllegalArgumentException(prefix + key + " 需设为 " + min + " 至 " + max + " 的整数。");
    }

    private static <E extends Enum<E>> E validEnum(Environment environment, String prefix, String name,
                                                   Class<E> type, E fallback) {
        try {
            return Enum.valueOf(type, text(environment, prefix, name, fallback.name()).toUpperCase(Locale.ROOT));
        } catch (IllegalArgumentException failure) {
            throw new IllegalArgumentException(prefix + name + " 配置值无效。");
        }
    }

    private static String digest(String... values) {
        try {
            byte[] bytes = String.join("\n", values).getBytes(StandardCharsets.UTF_8);
            return HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(bytes), 0, 12);
        } catch (NoSuchAlgorithmException failure) {
            throw new IllegalStateException("无法生成模型配置版本。");
        }
    }
}
