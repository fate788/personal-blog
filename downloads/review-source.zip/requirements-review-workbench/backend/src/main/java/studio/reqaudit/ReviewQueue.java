package studio.reqaudit;

import com.fasterxml.jackson.annotation.JsonUnwrapped;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.context.event.ApplicationStartedEvent;
import org.springframework.context.event.EventListener;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;

import static studio.reqaudit.Domain.*;

@Repository
class ReviewQueue {
    enum Disposition { CREATED, REUSED, IN_PROGRESS }
    record Submission(@JsonUnwrapped Run run, Disposition submissionDisposition) {}
    private record Slot(String active, String completed) {}
    private final AuditRepository audits;
    private final JdbcTemplate jdbc;

    ReviewQueue(AuditRepository audits, JdbcTemplate jdbc) {
        this.audits = audits;
        this.jdbc = jdbc;
    }

    @Transactional
    Submission submit(ReviewService.Prepared prepared, boolean fresh, boolean async) {
        Run run = prepared.run();
        String fingerprint = prepared.fingerprint();
        jdbc.queryForObject("SELECT id FROM review_queue_guard WHERE id = 1 FOR UPDATE", Integer.class);
        Slot slot = null;
        if (fingerprint != null) {
            slot = jdbc.query("SELECT active_run_id, completed_run_id FROM review_reuse_slot WHERE fingerprint = ? FOR UPDATE",
                    (row, i) -> new Slot(row.getString(1), row.getString(2)), fingerprint).stream().findFirst().orElse(null);
            if (slot != null && slot.active() != null)
                return new Submission(audits.requireRun(slot.active(), false), Disposition.IN_PROGRESS);
            if (!fresh && slot != null && slot.completed() != null)
                return new Submission(audits.requireRun(slot.completed(), false), Disposition.REUSED);
        }
        int jobs = jdbc.queryForObject("SELECT COUNT(*) FROM review_job", Integer.class);
        if (jobs >= 32) throw ApiFailure.busy("审查队列已满，请稍后重试。");
        int ownerJobs = jdbc.queryForObject("""
                SELECT COUNT(*) FROM review_job j JOIN review_run r ON r.id = j.run_id
                JOIN document_scope s ON r.document_id = s.document_id
                JOIN studio_project p ON s.project_id = p.id WHERE p.owner_id = (
                    SELECT requested.owner_id FROM document_scope own
                    JOIN studio_project requested ON own.project_id = requested.id WHERE own.document_id = ?
                )
                """, Integer.class, run.documentId());
        if (ownerJobs >= 5) throw ApiFailure.busy("项目所属工作区已有 5 个审查任务，请等待任务完成。");
        if (!async) run = run.withStatus(RunStatus.RUNNING, List.of());
        audits.addRun(run);
        jdbc.update("INSERT INTO review_job (run_id, job_status, accepted_at) VALUES (?, ?, ?)",
                run.id(), run.status().name(), run.createdAt());
        if (fingerprint != null) {
            if (slot == null) jdbc.update("INSERT INTO review_reuse_slot (fingerprint, execution_revision, active_run_id) VALUES (?, ?, ?)",
                    fingerprint, prepared.executionRevision(), run.id());
            else jdbc.update("UPDATE review_reuse_slot SET active_run_id = ? WHERE fingerprint = ?", run.id(), fingerprint);
        }
        return new Submission(run, Disposition.CREATED);
    }

    @Transactional
    Run take(String executionRevision) {
        var ids = jdbc.queryForList("""
                SELECT run_id FROM review_job WHERE job_status = 'QUEUED' ORDER BY accepted_at, run_id LIMIT 1
                """, String.class);
        if (ids.isEmpty()) return null;
        String id = ids.get(0);
        if (jdbc.update("UPDATE review_job SET job_status = 'RUNNING' WHERE run_id = ? AND job_status = 'QUEUED'", id) == 0) {
            return null;
        }
        var stored = jdbc.queryForList("SELECT execution_revision FROM review_reuse_slot WHERE active_run_id = ?", String.class, id);
        if (!stored.isEmpty() && !stored.get(0).equals(executionRevision)) {
            fail(id, new Diagnostic("REVIEW_ENGINE_CHANGED", "排队后工作台的审查引擎或执行预算已改变，请按当前条件重新提交。"));
            return null;
        }
        Run running = audits.requireRun(id, true).withStatus(RunStatus.RUNNING, List.of());
        audits.replaceRun(running);
        return running;
    }

    @Transactional
    void complete(Run run) {
        if (jdbc.update("DELETE FROM review_job WHERE run_id = ? AND job_status = 'RUNNING'", run.id()) > 0) {
            audits.replaceRun(run);
            boolean usable = run.status() == RunStatus.COMPLETED && run.scope() != null
                    && run.scope().substantiveChecks() != null && run.scope().substantiveChecks() > 0;
            if (usable) jdbc.update("UPDATE review_reuse_slot SET active_run_id = NULL, completed_run_id = ? WHERE active_run_id = ?", run.id(), run.id());
            else jdbc.update("UPDATE review_reuse_slot SET active_run_id = NULL WHERE active_run_id = ?", run.id());
        }
    }

    private boolean lockRunningJob(String id) {
        return !jdbc.queryForList("SELECT run_id FROM review_job WHERE run_id = ? AND job_status = 'RUNNING' FOR UPDATE",
                String.class, id).isEmpty();
    }

    @Transactional
    void progress(Run run) {
        if (lockRunningJob(run.id())) audits.replaceRun(run);
    }

    @Transactional
    void recover() {
        for (String id : jdbc.queryForList("SELECT run_id FROM review_job WHERE job_status = 'RUNNING'", String.class)) {
            fail(id, new Diagnostic("JOB_INTERRUPTED", "审核在运行期间因服务停止而中断。可重新提交。"));
        }
    }

    @Transactional
    void fail(String id, Diagnostic problem) {
        if (!lockRunningJob(id)) return;
        Run current = audits.requireRun(id, true);
        var diagnostics = new ArrayList<>(current.diagnostics());
        diagnostics.add(problem);
        RunStatus status = current.scope() != null && current.scope().coveredChecks() > 0
                ? RunStatus.PARTIAL : RunStatus.FAILED;
        complete(current.withStatus(status, List.copyOf(diagnostics)));
    }
}

@Component
@EnableScheduling
class ReviewWorker {
    private static final Logger LOG = LoggerFactory.getLogger(ReviewWorker.class);
    private final ReviewQueue queue;
    private final ReviewService review;
    private volatile boolean ready;

    ReviewWorker(ReviewQueue queue, ReviewService review) {
        this.queue = queue;
        this.review = review;
    }

    @EventListener(ApplicationStartedEvent.class)
    void begin() {
        queue.recover();
        ready = true;
    }

    @Scheduled(fixedDelay = 600)
    void process() {
        if (!ready) return;
        Run run = queue.take(review.executionRevision());
        if (run == null) return;
        try {
            queue.complete(review.evaluate(run, queue::progress));
        } catch (RuntimeException ex) {
            LOG.warn("Review job {} failed with {}", run.id(), ex.getClass().getSimpleName());
            queue.fail(run.id(), new Diagnostic("JOB_ERROR", "审查任务未能完成，请检查模型连接并重新提交。"));
        }
    }
}
