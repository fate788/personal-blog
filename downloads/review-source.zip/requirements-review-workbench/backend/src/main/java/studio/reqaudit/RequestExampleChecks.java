package studio.reqaudit;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.regex.Pattern;

import static studio.reqaudit.Domain.RuleWarning;

final class RequestExampleChecks {
    private static final String HTTP_METHODS = "GET|HEAD|POST|PUT|PATCH|DELETE|OPTIONS|TRACE|CONNECT";
    private static final Pattern METHOD = Pattern.compile("(?:" + HTTP_METHODS + ")", Pattern.CASE_INSENSITIVE);
    private static final Pattern HEADING = Pattern.compile("^ {0,3}(#{1,6})\\s+(.+?)\\s*#*\\s*$");
    private static final Pattern FENCE = Pattern.compile("^\\s*(`{3,}|~{3,})(.*)$");
    static final Pattern SHELL = Pattern.compile("shell|sh|bash|zsh|console", Pattern.CASE_INSENSITIVE);
    private static final Pattern METHOD_HEADING = Pattern.compile("请求(?:方式|方法)|HTTP\\s*(?:方法|方式|method)|request method", Pattern.CASE_INSENSITIVE);
    private static final Pattern PATH_HEADING = Pattern.compile("请求\\s*(?:URL|路径|地址)|request (?:URL|path)", Pattern.CASE_INSENSITIVE);
    private static final Pattern EXAMPLE_HEADING = Pattern.compile("(?:请求|调用|用法)?示例|(?:request |usage )?examples?", Pattern.CASE_INSENSITIVE);
    private static final Pattern EXAMPLE_LABEL = Pattern.compile("^(?:[-*+]\\s+)?(?:\\*\\*)?((?:请求|调用|返回|响应|错误|失败)示例|(?:request|response|invalid|error) examples?)(?:[:：])?(?:\\*\\*)?$", Pattern.CASE_INSENSITIVE);
    private static final Pattern CONTEXT_PATH = Pattern.compile("`\\$?([\\w.-]*context[._-]?path)`[^`]*?(?:默认(?:值)?为|defaults to)\\s*`(/[\\w.~/-]+)`", Pattern.CASE_INSENSITIVE);
    private static final Pattern DEFAULT_EXAMPLE_CONTEXT = Pattern.compile(
            "(?:下列|以下|下面|下述|本文|本节)[^`。！？]*?(?:示例|样例|API)[^`。！？]*?(?:采用|使用|按)\\s*默认\\s*`\\$?([^`]+)`(?=[^`。！？]*(?:展示|演示)|[。！？\\s]*$)"
                    + "|\\b(?:examples?|samples?)\\b[^`.!?]*?\\b(?:use|assume)\\s+(?:the\\s+)?default\\s+`\\$?([^`]+)`", Pattern.CASE_INSENSITIVE);
    private static final Pattern NEGATED_DEFAULT = Pattern.compile("不(?:是|推荐|建议)?(?:采用|使用|按)|并非|\\bnot (?:use|assume)\\b", Pattern.CASE_INSENSITIVE);
    private static final Pattern NON_DEFAULT_EXAMPLE = Pattern.compile(
            "反例|相对路径|(?:自定义|非默认|省略|不带)\\s*(?:默认)?上下文|\\b(?:relative (?:path|URL)|non-default context|counterexample)\\b", Pattern.CASE_INSENSITIVE);
    private static final Pattern REQUEST_LABEL = Pattern.compile("请求示例|request example", Pattern.CASE_INSENSITIVE);
    private static final Pattern ALTERNATE_ROUTE = Pattern.compile(
            "代理|网关|重写|重映射|转发|非默认|自定义|备选|替代|其他接口|反例|错误示例|失败示例|"
            + "\\b(?:prox(?:y|ied)|gateway|rewrite|remap|forward|alternate|alternative|non-default|custom|counterexample)\\b",
            Pattern.CASE_INSENSITIVE);
    private static final Pattern VERSIONED_ROUTE = Pattern.compile("/v[1-9][0-9]*(?:/[A-Za-z0-9_~-][A-Za-z0-9._~-]*){3,}");
    private static final Pattern SINGLE_PREFIX = Pattern.compile("/[A-Za-z][A-Za-z0-9_-]*");
    private static final Pattern URL = Pattern.compile("((?:https?://)?[\\w.~-]+(?::[0-9]+)?)?(/[^/?#\\s'\"`][^?#\\s'\"`]*|/)(?:[?#][^\\s'\"`]*)?", Pattern.CASE_INSENSITIVE);

    private enum Field { METHOD, PATH }

    private record ContextPath(String setting, String value, boolean usedInExamples) {}

    private record Example(String method, String path, String host, boolean literalPath, int methodLine, int pathLine) {}

    private record CodeBlock(String marker, boolean shell, int firstContent) {}

    private static final class Endpoint {
        private final int level;
        private final List<Example> examples = new ArrayList<>();
        private String method;
        private int methodLine;
        private String path;
        private String host;
        private int pathLine;
        private boolean ambiguous;
        private final boolean namedSection;
        private boolean alternateRoute;
        private boolean literalPath;
        private int requestLabels;
        private int shellBlocks;
        private int curlStarts;

        private Endpoint(int level, String parent) {
            this.level = level;
            namedSection = parent != null && !parent.matches("(?iu)接口|API|endpoints?|接口列表|接口文档|参考");
            alternateRoute = parent != null && ALTERNATE_ROUTE.matcher(parent).find();
        }

        private void declare(Field field, String value, int line) {
            if (field == Field.METHOD) {
                if (method != null || !METHOD.matcher(value).matches()) {
                    ambiguous = true;
                    return;
                }
                method = value.toUpperCase(Locale.ROOT);
                methodLine = line;
            } else {
                var url = URL.matcher(value);
                if (path != null || !url.matches()) { ambiguous = true; return; }
                path = url.group(2);
                host = hostOf(url.group(1));
                literalPath = value.indexOf('?') < 0 && value.indexOf('#') < 0;
                pathLine = line;
            }
        }

        private void inspect(List<RuleWarning> warnings, ContextPath context) {
            if (ambiguous || method == null || path == null) return;
            for (Example example : examples) {
                if (host != null && example.host() != null && !host.equals(example.host())) continue;
                boolean omittedContext = context != null && omitsContext(path, example.path(), context.value());
                if (!path.equals(example.path()) && !omittedContext) {
                    if (context == null && !method.equals(example.method()) && sameSectionRequest(example)) {
                        warnings.add(new RuleWarning("HTTP_SECTION_EXAMPLE_METHOD_DIFFERS",
                                "本节声明使用 " + method + "，本节唯一标为请求示例的调用使用 " + example.method()
                                + "。两处含相同的版本化路由，请核对预期的调用方式。", example.methodLine(), methodLine));
                    }
                    continue;
                }
                if (!method.equals(example.method())) {
                    warnings.add(new RuleWarning("HTTP_REQUEST_METHOD_MISMATCH",
                            "接口声明使用 " + method + "，curl 请求示例使用 " + example.method()
                                    + "。请核对 " + path + " 的请求方法。", example.methodLine(), methodLine));
                }
                if (omittedContext && context.usedInExamples() && example.host() != null) {
                    warnings.add(new RuleWarning("HTTP_REQUEST_CONTEXT_PATH_MISSING",
                            "按文档声明的默认部署配置，curl 请求示例缺少 " + context.value()
                                    + " 上下文前缀。请核对接口声明的路径 " + path + "。", example.pathLine(), pathLine));
                }
            }
        }

        private boolean sameSectionRequest(Example example) {
            if (!namedSection || alternateRoute || requestLabels != 1 || shellBlocks != 1 || curlStarts != 1
                    || examples.size() != 1 || !literalPath || !example.literalPath() || example.host() == null) return false;
            String route = example.path();
            if (!VERSIONED_ROUTE.matcher(route).matches() || !path.endsWith(route)) return false;
            return SINGLE_PREFIX.matcher(path.substring(0, path.length() - route.length())).matches();
        }
    }

    private RequestExampleChecks() {}

    static List<RuleWarning> inspect(String[] lines) {
        var warnings = new ArrayList<RuleWarning>();
        ContextPath context = null;
        boolean endpointsStarted = false;
        Endpoint endpoint = null;
        Field activeField = null;
        CodeBlock block = null;
        boolean inExample = false;
        String[] headings = new String[7];
        for (int index = 0; index < lines.length; index++) {
            String line = lines[index];
            String content = line.strip();
            var fence = FENCE.matcher(line);
            if (block != null) {
                if (fence.matches() && fence.group(1).startsWith(block.marker()) && fence.group(2).isBlank()) {
                    if (block.shell()) {
                        endpoint.shellBlocks++;
                        for (int row = block.firstContent(); row < index; row++) {
                            if (CurlExamples.startsCommand(lines[row])) endpoint.curlStarts++;
                        }
                        for (var command : CurlExamples.read(lines, block.firstContent(), index)) {
                            Example example = parseExample(command);
                            if (example != null) endpoint.examples.add(example);
                        }
                    }
                    block = null;
                }
                continue;
            }
            var heading = HEADING.matcher(line);
            if (heading.matches()) {
                int level = heading.group(1).length();
                String label = heading.group(2).replaceFirst("[:：]$", "").strip();
                java.util.Arrays.fill(headings, level, headings.length, null);
                headings[level] = label;
                if (endpoint != null && level < endpoint.level) {
                    endpoint.inspect(warnings, context);
                    endpoint = null;
                }
                activeField = fieldOf(label);
                if (activeField != null) {
                    endpointsStarted = true;
                    if (endpoint == null) {
                        int parent = level - 1;
                        while (parent > 0 && headings[parent] == null) parent--;
                        endpoint = new Endpoint(level, headings[parent]);
                    }
                    if (endpoint.level != level) {
                        endpoint.ambiguous = true;
                        activeField = null;
                    }
                }
                inExample = endpoint != null && EXAMPLE_HEADING.matcher(label).matches();
                if (endpoint != null) {
                    if (REQUEST_LABEL.matcher(label).matches()) endpoint.requestLabels++;
                    if (ALTERNATE_ROUTE.matcher(label).find()) endpoint.alternateRoute = true;
                }
                continue;
            }
            if (fence.matches()) {
                block = new CodeBlock(fence.group(1), inExample && SHELL.matcher(fence.group(2).strip()).matches(), index + 1);
                activeField = null;
                continue;
            }
            if (!endpointsStarted) context = readContext(context, line);
            if (endpoint != null && ALTERNATE_ROUTE.matcher(content).find()) endpoint.alternateRoute = true;
            var exampleLabel = EXAMPLE_LABEL.matcher(content);
            if (endpoint != null && exampleLabel.matches()) {
                inExample = EXAMPLE_HEADING.matcher(exampleLabel.group(1)).matches();
                if (REQUEST_LABEL.matcher(exampleLabel.group(1)).matches()) endpoint.requestLabels++;
                activeField = null;
                continue;
            }
            if (inExample && NON_DEFAULT_EXAMPLE.matcher(content).find()) inExample = false;
            if (activeField != null && !content.isBlank()) endpoint.declare(activeField, unwrapCode(content), index + 1);
        }
        if (endpoint != null) endpoint.inspect(warnings, context);
        return warnings;
    }

    private static ContextPath readContext(ContextPath context, String line) {
        if (context == null) {
            var declaration = CONTEXT_PATH.matcher(line);
            if (!declaration.find()) return null;
            return new ContextPath(declaration.group(1), declaration.group(2).replaceFirst("/+$", ""), false);
        }
        if (context.usedInExamples() || NEGATED_DEFAULT.matcher(line).find()) return context;
        var scope = DEFAULT_EXAMPLE_CONTEXT.matcher(line);
        if (!scope.find()) return context;
        String setting = scope.group(1) == null ? scope.group(2) : scope.group(1);
        return context.setting().equalsIgnoreCase(setting) ? new ContextPath(context.setting(), context.value(), true) : context;
    }

    private static Field fieldOf(String label) {
        if (METHOD_HEADING.matcher(label).matches()) return Field.METHOD;
        return PATH_HEADING.matcher(label).matches() ? Field.PATH : null;
    }

    private static String unwrapCode(String value) {
        if (value.length() > 1 && value.startsWith("`") && value.endsWith("`")) return value.substring(1, value.length() - 1);
        return value;
    }

    private static Example parseExample(CurlExamples.Command command) {
        if (command.method() == null || !METHOD.matcher(command.method().value()).matches()) return null;
        var target = URL.matcher(command.target().value());
        if (!target.matches() || target.group(2).matches(".*[$\\{\\}`].*")) return null;
        return new Example(command.method().value().toUpperCase(Locale.ROOT), target.group(2),
                hostOf(target.group(1)), command.target().value().indexOf('?') < 0 && command.target().value().indexOf('#') < 0,
                command.method().line(), command.target().line());
    }

    private static String hostOf(String authority) {
        if (authority == null) return null;
        String name = authority.replaceFirst("(?i)^https?://", "").toLowerCase(Locale.ROOT);
        return Character.isLetterOrDigit(name.charAt(0))
                && (authority.contains("://") || name.contains(".") || name.contains(":") || name.equals("localhost")) ? name : null;
    }

    private static boolean omitsContext(String declared, String example, String contextPath) {
        return !contextPath.isEmpty() && declared.startsWith(contextPath + "/")
                && declared.substring(contextPath.length()).equals(example);
    }
}
