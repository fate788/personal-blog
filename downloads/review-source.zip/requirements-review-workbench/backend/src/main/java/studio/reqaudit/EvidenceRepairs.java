package studio.reqaudit;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Transactional;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.HexFormat;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.regex.Pattern;

import static studio.reqaudit.Domain.*;

@Service
class EvidenceRepairs {
    private static final String METHOD = "HTTP_REQUEST_METHOD_MISMATCH";
    private static final String SECTION_METHOD = "HTTP_SECTION_EXAMPLE_METHOD_DIFFERS";
    private static final String CONTEXT = "HTTP_REQUEST_CONTEXT_PATH_MISSING";
    private static final Set<String> REPAIRABLE = Set.of(METHOD, SECTION_METHOD, CONTEXT, "INVALID_JSON_EXAMPLE",
            "SQL_EXAMPLE_FUNCTION_MISMATCH", "WORKED_OCCURRENCE_MISMATCH");
    private static final String METHODS = "GET|HEAD|POST|PUT|PATCH|DELETE|OPTIONS|TRACE|CONNECT";
    private static final Pattern METHOD_DECLARATION = Pattern.compile("(?:" + METHODS + ")", Pattern.CASE_INSENSITIVE);
    private static final Pattern CURL = Pattern.compile("^\\s*(?:\\$\\s+)?curl(?:\\.exe)?\\s+(?:-X\\s*|--request(?:=|\\s+))(['\"]?)("
            + METHODS + ")\\1\\s+(?:--url(?:=|\\s+))?(['\"]?)([^\\s'\"`]+)\\3(?=\\s|$)");
    private static final Pattern TARGET = Pattern.compile("(?:(?:https?://)?[\\w.~-]+(?::[0-9]+)?)?(/[^?#]*)(?:[?#].*)?", Pattern.CASE_INSENSITIVE);
    private static final Pattern LITERAL_ROUTE = Pattern.compile("/(?:(?:[A-Za-z0-9._~%-]+/)*[A-Za-z0-9._~%-]+/?)?");
    private static final Pattern PATCH_ID = Pattern.compile("[0-9a-f]{64}");
    private static final int MAX_PATCHES = 100;

    record Patch(String id, String title, String expected, String replacement, int line, String ruleType,
                 List<String> ruleTypes, int originalLine, List<Integer> relatedLines, List<Integer> relatedOriginalLines, List<String> findingIds) {}
    record Preview(String documentId, String versionId, int versionNumber, boolean latest, List<Patch> patches) {}

    private record Source(Run run, Document document, Version version) {
        boolean latest() { return version.id().equals(document.versions().get(0).id()); }
    }

    private record WarningKey(String type, int line, Integer relatedLine) {
        static WarningKey of(RuleWarning warning) {
            return new WarningKey(warning.type(), warning.line(), warning.relatedLine());
        }
    }

    private final AuditRepository repository;
    private final Projects projects;

    EvidenceRepairs(AuditRepository repository, Projects projects) {
        this.repository = repository;
        this.projects = projects;
    }

    @Transactional(readOnly = true, isolation = Isolation.REPEATABLE_READ)
    Preview preview(String accountId, String runId) {
        Source source = requireSource(accountId, runId);
        Version version = source.version();
        return new Preview(source.document().id(), version.id(), version.number(), source.latest(), patches(source));
    }

    @Transactional(isolation = Isolation.READ_COMMITTED)
    Document apply(String accountId, String runId, List<String> patchIds) {
        Source source = requireSource(accountId, runId);
        if (!source.latest()) throw ApiFailure.conflict("已有更新的文档版本，请先审查最新版本再应用修订。");
        if (patchIds == null || patchIds.isEmpty() || patchIds.size() > MAX_PATCHES
                || patchIds.stream().anyMatch(id -> id == null || !PATCH_ID.matcher(id).matches())
                || new HashSet<>(patchIds).size() != patchIds.size()) {
            throw ApiFailure.badRequest("请选择有效且不重复的修订项。");
        }
        var available = new LinkedHashMap<String, Patch>();
        patches(source).forEach(patch -> available.put(patch.id(), patch));
        if (!available.keySet().containsAll(patchIds)) {
            throw ApiFailure.conflict("所选修订无法从本次审查的原文证据复现，请刷新后重试。");
        }

        Version old = source.version();
        String[] lines = old.text().split("\n", -1);
        var selected = patchIds.stream().map(available::get).toList();
        for (Patch patch : selected) {
            if (!lines[patch.line() - 1].equals(patch.expected())) {
                throw ApiFailure.conflict("证据行已变化，请重新审查。");
            }
            lines[patch.line() - 1] = patch.replacement();
        }
        var checks = SourceChecks.inspect(String.join("\n", lines));
        if (selected.stream().anyMatch(patch -> checks.stream()
                .anyMatch(check -> check.line() == patch.line() && patch.ruleTypes().contains(check.type())))) {
            throw ApiFailure.conflict("修订后仍出现所选提示，未保存修订版。");
        }

        var headings = new LinkedHashMap<Integer, Integer>();
        old.sections().forEach(section -> headings.put(section.line(), section.level()));
        SourceMetadata original = old.source();
        SourceMetadata metadata = original == null
                ? new SourceMetadata("TEXT", null, null, List.of(), Map.of())
                : new SourceMetadata(original.format(), original.fileName(), original.pageCount(),
                original.warnings() == null ? List.of() : original.warnings(),
                original.anchors() == null ? Map.of() : original.anchors());
        var revision = new DocumentParser.Imported(source.document().title(), String.join("\n", lines), headings, metadata);
        return repository.addVersionIfLatest(source.document().id(), old.id(), revision);
    }

    private Source requireSource(String accountId, String runId) {
        if (!projects.forRun(accountId, runId).role().mayEdit()) {
            throw ApiFailure.forbidden("仅项目拥有者和编辑者可生成文档修订版。");
        }
        Run run = repository.requireRun(runId, false);
        boolean localEvidenceAvailable = run.executionStrategy() == ExecutionStrategy.COMBINED && run.status() == RunStatus.FAILED
                && run.ruleWarnings() != null && !run.ruleWarnings().isEmpty();
        if (run.status() != RunStatus.COMPLETED && run.status() != RunStatus.PARTIAL && !localEvidenceAvailable) {
            throw ApiFailure.conflict("审查完成后才能从证据生成修订。");
        }
        Document document = repository.requireDocument(run.documentId());
        Version version = document.versions().stream().filter(candidate -> candidate.id().equals(run.versionId()))
                .findFirst().orElseThrow(() -> ApiFailure.notFound("审查关联的文档版本不存在。"));
        return new Source(run, document, version);
    }

    private static List<Patch> patches(Source source) {
        var run = source.run();
        var saved = new HashSet<WarningKey>();
        if (run.ruleWarnings() != null) run.ruleWarnings().forEach(item -> saved.add(WarningKey.of(item)));
        String[] lines = source.version().text().split("\n", -1);
        var findings = new TreeMap<Integer, List<RuleWarning>>();
        var verifiedCommaLines = new HashSet<Integer>();
        for (RuleWarning item : SourceChecks.inspect(source.version().text(), verifiedCommaLines)) {
            if (!REPAIRABLE.contains(item.type())) continue;
            if (item.type().equals("INVALID_JSON_EXAMPLE") && !verifiedCommaLines.contains(item.line())) continue;
            if (!saved.contains(WarningKey.of(item)) && matchingSqlFindings(run, item).isEmpty()) continue;
            findings.computeIfAbsent(item.line(), ignored -> new ArrayList<>()).add(item);
        }

        var result = new ArrayList<Patch>();
        for (var entry : findings.entrySet()) {
            Patch patch = patch(source, lines, entry.getKey(), entry.getValue());
            if (patch != null) result.add(patch);
        }
        return List.copyOf(result);
    }

    private static Patch patch(Source source, String[] lines, int lineNumber, List<RuleWarning> warnings) {
        SourceAnchor location = anchor(source.version(), lineNumber);
        if (location != null && location.cells() != null && !location.cells().isEmpty()) return null;
        String expected = lines[lineNumber - 1];
        if (warnings.size() == 1) {
            RuleWarning warning = warnings.get(0);
            var edit = SourceExampleRepair.edit(lines, warning);
            if (edit != null) {
                List<Integer> related = warning.relatedLine() == null ? List.of() : List.of(warning.relatedLine());
                return candidate(source, lineNumber, expected, edit.text(), edit.title(),
                        List.of(warning.type()), related, matchingSqlFindings(source.run(), warning));
            }
        }
        if (warnings.stream().anyMatch(w -> !Set.of(METHOD, SECTION_METHOD, CONTEXT).contains(w.type()) || w.relatedLine() == null)) return null;
        var command = CURL.matcher(expected);
        if (!command.find()) return null;

        String method = null;
        String prefix = null;
        int prefixOffset = 0;
        var byType = new LinkedHashMap<String, Integer>();
        for (RuleWarning warning : warnings) {
            if (byType.putIfAbsent(warning.type(), warning.relatedLine()) != null) return null;
            String declaration = unwrap(lines[warning.relatedLine() - 1]);
            if (METHOD.equals(warning.type()) || SECTION_METHOD.equals(warning.type())) {
                if (!METHOD_DECLARATION.matcher(declaration).matches()) return null;
                method = declaration.toUpperCase(Locale.ROOT);
                if (method.equals(command.group(2))) return null;
            } else {
                var target = TARGET.matcher(command.group(4));
                if (!target.matches()) return null;
                String examplePath = target.group(1);
                if (!LITERAL_ROUTE.matcher(declaration).matches() || !LITERAL_ROUTE.matcher(examplePath).matches()
                        || !declaration.endsWith(examplePath)) return null;
                prefix = declaration.substring(0, declaration.length() - examplePath.length());
                if (!LITERAL_ROUTE.matcher(prefix).matches() || prefix.endsWith("/")) return null;
                prefixOffset = command.start(4) + target.start(1);
            }
        }

        var replacementBuilder = new StringBuilder(expected);
        if (prefix != null) replacementBuilder.insert(prefixOffset, prefix);
        if (method != null) replacementBuilder.replace(command.start(2), command.end(2), method);
        String replacement = replacementBuilder.toString();
        if (expected.equals(replacement)) return null;
        String title = method != null && prefix != null ? "修正请求方法及默认路径前缀"
                : byType.containsKey(SECTION_METHOD) ? "按本节声明调整示例请求方法"
                : method != null ? "修正示例请求方法" : "补齐默认路径前缀";
        List<String> types = List.copyOf(byType.keySet());
        List<Integer> related = List.copyOf(byType.values());
        return candidate(source, lineNumber, expected, replacement, title, types, related, List.of());
    }

    private static List<String> matchingSqlFindings(Run run, RuleWarning warning) {
        if (!warning.type().equals("SQL_EXAMPLE_FUNCTION_MISMATCH") || run.findings() == null) return List.of();
        return run.findings().stream().filter(f -> f.decision() != Decision.REJECTED
                && SqlExampleChecks.matchesFinding(warning, f)).map(Finding::id).toList();
    }

    private static Patch candidate(Source source, int lineNumber, String expected, String replacement, String title,
                                   List<String> types, List<Integer> related, List<String> findingIds) {
        String id = patchId(source.run().id(), source.version().id(), lineNumber, expected, replacement, types, related);
        return new Patch(id, title, expected, replacement, lineNumber, types.get(0), types,
                originalLine(source.version(), lineNumber), related,
                related.stream().map(line -> originalLine(source.version(), line)).toList(), findingIds);
    }

    private static String unwrap(String line) {
        String text = line.strip();
        return text.length() > 1 && text.startsWith("`") && text.endsWith("`") ? text.substring(1, text.length() - 1) : text;
    }

    private static SourceAnchor anchor(Version version, int line) {
        return version.source() == null || version.source().anchors() == null ? null : version.source().anchors().get(line);
    }

    private static int originalLine(Version version, int line) {
        SourceAnchor anchor = anchor(version, line);
        return anchor == null || anchor.startLine() == null ? line : anchor.startLine();
    }

    private static String patchId(String runId, String versionId, int line, String expected, String replacement,
                                  List<String> types, List<Integer> related) {
        String key = String.join("\0", runId, versionId, Integer.toString(line), expected, replacement,
                String.join(",", types), related.toString());
        try {
            return HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(key.getBytes(StandardCharsets.UTF_8)));
        } catch (NoSuchAlgorithmException ex) {
            throw new IllegalStateException("无法校验修订证据。", ex);
        }
    }
}
