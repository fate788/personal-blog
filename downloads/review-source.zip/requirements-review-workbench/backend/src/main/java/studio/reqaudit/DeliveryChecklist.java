package studio.reqaudit;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.time.Instant;
import java.util.List;
import java.util.Set;

import static studio.reqaudit.StudioAccess.ACCOUNT;

@RestController
@RequestMapping("/api/documents/{documentId}/versions/{versionId}/delivery-checklist")
class DeliveryChecklist {
    private static final Set<String> ITEMS = Set.of("VERSION_REVISION", "DOCUMENT_CHECKS", "REVIEW_COVERAGE",
            "FINDING_REVIEW", "ISSUE_TRACKING", "TRACE", "EXECUTIONS");

    record Entry(String itemKey, String evidenceSignature, boolean checked, String checkedAt) {}
    record Snapshot(String documentId, String versionId, String reviewId, boolean canCheck, List<Entry> entries) {}
    record Change(String reviewId, String itemKey, String evidenceSignature, Boolean checked) {}

    private final Projects projects;
    private final AuditRepository repository;
    private final JdbcTemplate jdbc;

    DeliveryChecklist(Projects projects, AuditRepository repository, JdbcTemplate jdbc) {
        this.projects = projects;
        this.repository = repository;
        this.jdbc = jdbc;
    }

    @GetMapping
    Snapshot load(@RequestAttribute(ACCOUNT) Accounts.User actor, @PathVariable String documentId,
                  @PathVariable String versionId, @RequestParam(required = false) String reviewId) {
        Projects.Project project = projects.forDocument(actor.id(), documentId);
        String scopedRun = validateScope(documentId, versionId, reviewId);
        List<Entry> entries = jdbc.query("""
                SELECT item_key, evidence_signature, checked_at
                FROM delivery_checklist WHERE actor_id = ? AND version_id = ? AND review_id = ?
                ORDER BY item_key
                """, (row, index) -> new Entry(row.getString(1), row.getString(2), true, row.getString(3)),
                actor.id(), versionId, scopedRun);
        return new Snapshot(documentId, versionId, scopedRun, project.role().mayStartReview(), entries);
    }

    @PutMapping
    Entry update(@RequestAttribute(ACCOUNT) Accounts.User actor, @PathVariable String documentId,
                 @PathVariable String versionId, @RequestBody Change change) {
        Projects.Project project = projects.forDocument(actor.id(), documentId);
        if (!project.role().mayStartReview()) throw ApiFailure.forbidden("当前项目角色只能查看交付清单。");
        String scopedRun = validateScope(documentId, versionId, change.reviewId());
        String key = ApiFailure.requireText(change.itemKey(), "核对项", 32);
        if (!ITEMS.contains(key)) throw ApiFailure.badRequest("未知的交付核对项。");
        if (change.checked() == null) throw ApiFailure.badRequest("请指定核对状态。");
        String signature = ApiFailure.requireText(change.evidenceSignature(), "证据标识", 1200);
        if (!change.checked()) {
            jdbc.update("""
                    DELETE FROM delivery_checklist
                    WHERE actor_id = ? AND version_id = ? AND review_id = ? AND item_key = ?
                    AND evidence_signature = ?
                    """, actor.id(), versionId, scopedRun, key, signature);
            return new Entry(key, signature, false, null);
        }

        String now = Instant.now().toString();
        jdbc.update("""
                INSERT INTO delivery_checklist (actor_id, version_id, review_id, item_key, evidence_signature, checked_at)
                VALUES (?, ?, ?, ?, ?, ?)
                ON DUPLICATE KEY UPDATE evidence_signature = ?, checked_at = ?
                """, actor.id(), versionId, scopedRun, key, signature, now, signature, now);
        return new Entry(key, signature, true, now);
    }

    private String validateScope(String documentId, String versionId, String reviewId) {
        repository.requireVersion(documentId, versionId);
        String scopedRun = ApiFailure.optionalText(reviewId, "审查任务编号", 64);
        if (!scopedRun.isEmpty() && jdbc.queryForObject("""
                SELECT COUNT(*) FROM review_run WHERE id = ? AND document_id = ? AND version_id = ?
                """, Integer.class, scopedRun, documentId, versionId) == 0) {
            throw ApiFailure.notFound("审查任务不存在或不属于此文档版本。");
        }
        return scopedRun;
    }
}
