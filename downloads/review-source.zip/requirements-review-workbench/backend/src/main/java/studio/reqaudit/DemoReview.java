package studio.reqaudit;

import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

import static studio.reqaudit.AuditCatalog.*;
import static studio.reqaudit.Domain.*;
import static studio.reqaudit.Domain.FindingStatus.*;
import static studio.reqaudit.Domain.Severity.*;

@Component
class DemoReview {
    private final EnterpriseDemo enterprise;

    DemoReview(EnterpriseDemo enterprise) {
        this.enterprise = enterprise;
    }

    List<Assessment> evaluate(ReviewPlanner.Batch batch, Pack pack, Version version) {
        boolean original = version.text().strip().equals(SAMPLE);
        boolean isEnterprise = enterprise.isVersion(version);
        boolean knownEnterprise = isEnterprise && enterprise.isKnownText(version);
        var scope = new ArrayList<>(batch.primary());
        scope.addAll(batch.context());
        var result = new ArrayList<Assessment>();
        for (Item item : batch.primary()) {
            for (Rule rule : pack.rules()) {
                result.add(isEnterprise ? enterprise.assess(item, rule, scope, knownEnterprise)
                        : assess(item, rule, scope, original));
            }
        }
        return result;
    }

    private Assessment assess(Item item, Rule rule, List<Item> scope, boolean original) {
        if (matches(item, "FR-031", "保存成功后，系统应及时通知相关学生")
                && rule.equals(CLARITY)) {
            return answer(item, rule, ISSUE, MEDIUM, "通知缺少可验收的时限",
                    "“及时通知”没有定义计时起点和完成时限，验收人员难以判断是否达标。",
                    "确认计时起点、通知渠道及最迟送达时间，并约定发送失败的反馈方式。",
                    evidence(item, "保存成功后，系统应及时通知相关学生"));
        }
        if (matches(item, "NFR-011", "系统应快速响应报名提交请求") && rule.equals(CLARITY)) {
            return answer(item, rule, ISSUE, MEDIUM, "性能要求缺少量化阈值",
                    "条目给出了 500 名学生同时在线的条件，“快速响应”缺少响应时间阈值和测量口径。",
                    "由业务和测试负责人共同确认负载模型、测量起止点、延迟指标与目标值。",
                    evidence(item, "在 500 名学生同时在线的条件下，系统应快速响应报名提交请求"));
        }
        if (matches(item, "FR-023", "报名提交失败时，系统应向学生显示失败提示。")
                && item.text().stripTrailing().endsWith("显示失败提示。") && rule.equals(EXCEPTION)) {
            var state = find(scope, "FR-021", "系统应校验活动剩余名额，并为符合条件的学生生成有效报名记录");
            if (state.isPresent()) {
                return answer(item, rule, ISSUE, HIGH, "报名失败后的数据处理待明确",
                        "已提供的报名章节描述了名额校验与记录生成。当前失败条款仅定义页面提示，"
                                + "需要澄清写入或占用部分完成时如何处理。",
                        "确认报名记录、活动名额在各失败阶段的原子性、回滚和安全重试行为。",
                        evidence(item, "报名提交失败时，系统应向学生显示失败提示"),
                        evidence(state.get(), "系统应校验活动剩余名额，并为符合条件的学生生成有效报名记录"));
            }
        }
        if (matches(item, "FR-022", "同一学生对同一活动只能保留一条有效报名记录") && rule.equals(CONFLICT)) {
            var other = find(scope, "DR-006", "同一学生对同一活动允许同时存在多条有效报名记录");
            if (other.isPresent()) {
                return answer(item, rule, ISSUE, HIGH, "有效报名记录的数量约束冲突",
                        "FR-022 与 DR-006 针对同一学生、活动及有效状态，分别要求仅一条和允许多条。",
                        "请业务负责人确认生效的数量规则，随后统一两处条款和重复提交验收用例。",
                        evidence(item, "同一学生对同一活动只能保留一条有效报名记录"),
                        evidence(other.get(), "同一学生对同一活动允许同时存在多条有效报名记录"));
            }
        }
        if (original && item.code().equals("FR-031") && rule.equals(PERMISSION)) {
            return answer(item, rule, INSUFFICIENT, LOW, "可修改字段需要补充材料",
                    "角色章节已限定管理员维护本人管理活动的报名信息。当前节选未包含字段清单。",
                    "补充报名信息字段清单与字段级修改约束。", evidence(item, "活动管理员可以修改报名信息"));
        }
        if (original && item.code().equals("NFR-011") && rule.equals(EXCEPTION)) {
            return answer(item, rule, NOT_APPLICABLE, LOW, "本性能条目不单独评价失败分支",
                    "此条单独描述响应性能。失败后记录和名额的处理在功能条款中检查。", "");
        }
        if (original) {
            return answer(item, rule, PASS, LOW, "样例检查已完成", "演示样例在此项未预设疑点。", "");
        }
        return answer(item, rule, INSUFFICIENT, LOW, "演示模式需要真实模型判断",
                "当前采用开题样例演示，通用文档的语义判断需连接模型服务。", "");
    }

    private boolean matches(Item item, String code, String quote) {
        return item.code().equals(code) && item.text().contains(quote);
    }

    private java.util.Optional<Item> find(List<Item> scope, String code, String quote) {
        return scope.stream().filter(item -> matches(item, code, quote)).findFirst();
    }

    private ProposedEvidence evidence(Item item, String text) {
        return new ProposedEvidence(item.id(), text);
    }

    private Assessment answer(Item item, Rule rule, FindingStatus status, Severity severity,
                              String title, String reason, String suggestion, ProposedEvidence... evidence) {
        return new Assessment(item.id(), rule.id(), status, severity, title, reason, suggestion, List.of(evidence));
    }
}
