package studio.reqaudit;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.regex.Pattern;

/** Reads literal arguments in documented curl commands. No shell is invoked. */
final class CurlExamples {
    private static final Pattern START = Pattern.compile("^\\s*(?:\\$\\s+)?curl(?:\\.exe)?(?=\\s|$)");
    private static final Set<String> FLAGS = Set.of("-s", "-S", "-sS", "-Ss", "-i", "-k", "-v", "-f", "-L",
            "--silent", "--show-error", "--include", "--insecure", "--verbose", "--fail", "--location");
    private static final Set<String> OPTIONS = Set.of("-H", "--header", "-X", "--request", "--url",
            "-d", "--data", "--data-raw", "--data-binary", "--json", "-u", "--user", "-m", "--max-time");
    private static final Pattern BODY = Pattern.compile("(?s)^(?:\\{\\s*(?:\"|\\})|\\[\\s*(?:\"|\\{|\\[|\\]|-?[0-9]|true\\b|false\\b|null\\b)).*");

    record Argument(String value, int line, boolean singleQuoted) {}
    record Command(Argument method, Argument target, Argument jsonBody) {}
    private record Read(List<Argument> arguments, int lastLine) {}

    private CurlExamples() {}

    static boolean startsCommand(String line) { return START.matcher(line).find(); }

    static List<Command> read(String[] lines, int start, int end) {
        List<Command> commands = new ArrayList<>();
        for (int index = start; index < end; index++) {
            var prefix = START.matcher(lines[index]);
            if (!prefix.find()) continue;
            Read parsed = arguments(lines, index, prefix.end(), end);
            index = parsed.lastLine();
            Command command = classify(parsed.arguments());
            if (command != null) commands.add(command);
        }
        return commands;
    }

    private static Read arguments(String[] lines, int first, int offset, int end) {
        List<Argument> result = new ArrayList<>();
        StringBuilder token = new StringBuilder();
        int tokenLine = -1;
        char quote = 0;
        boolean single = false;
        boolean continuation = false;
        boolean supported = true;
        for (int row = first; row < end; row++) {
            String line = lines[row];
            continuation = false;
            for (int col = row == first ? offset : 0; col < line.length(); col++) {
                char ch = line.charAt(col);
                if (quote == 0 && Character.isWhitespace(ch)) {
                    if (tokenLine >= 0) {
                        result.add(new Argument(token.toString(), tokenLine, single));
                        token.setLength(0);
                        tokenLine = -1;
                    }
                    continue;
                }
                if (quote == 0 && tokenLine < 0 && ch == '#') break;
                if (ch == '\\' && quote != '\'' && col + 1 == line.length()) {
                    continuation = true;
                    break;
                }
                if (tokenLine < 0) {
                    tokenLine = row + 1;
                    single = ch == '\'';
                } else if (quote == 0) {
                    single = false; // An adjacent quoted fragment or bare suffix changes shell semantics.
                }
                if (quote == 0 && (ch == '\'' || ch == '"')) { quote = ch; continue; }
                if (ch == quote) { quote = 0; continue; }
                if (quote == 0 && ";|&<>()`".indexOf(ch) >= 0) supported = false;
                if (ch == '\\' && quote != '\'' && col + 1 < line.length()) {
                    char next = line.charAt(++col);
                    if (quote == '"' && "\\\"$`".indexOf(next) < 0) token.append('\\');
                    token.append(next);
                } else {
                    token.append(ch);
                }
            }
            if (continuation) continue;
            if (quote != 0) { token.append('\n'); continue; }
            if (tokenLine >= 0) result.add(new Argument(token.toString(), tokenLine, single));
            return new Read(supported ? result : List.of(), row);
        }
        return new Read(List.of(), end - 1);
    }

    private static Command classify(List<Argument> args) {
        Argument method = null, target = null, data = null;
        boolean jsonAllowed = true;
        for (int i = 0; i < args.size(); i++) {
            Argument token = args.get(i);
            String flag = token.value();
            if (FLAGS.contains(flag)) continue;
            if (flag.startsWith("-")) {
                Argument value;
                int split = flag.startsWith("--") ? flag.indexOf('=') : -1;
                if (split > 2 || flag.startsWith("-X") && flag.length() > 2) {
                    int length = split > 2 ? split : 2;
                    value = new Argument(flag.substring(split > 2 ? split + 1 : length), token.line(), false);
                    flag = flag.substring(0, length);
                } else if (OPTIONS.contains(flag) && i + 1 < args.size()) {
                    value = args.get(++i);
                } else return null;
                switch (flag) {
                    case "-X", "--request" -> {
                        if (method != null) return null;
                        method = value;
                    }
                    case "--url" -> {
                        if (target != null) return null;
                        target = value;
                    }
                    case "-d", "--data", "--data-raw", "--data-binary", "--json" -> {
                        if (data != null) jsonAllowed = false;
                        data = value;
                    }
                    case "-H", "--header" -> {
                        String header = value.value().toLowerCase(Locale.ROOT);
                        if (header.startsWith("content-type:")) {
                            String type = header.substring(13).split(";", 2)[0].strip();
                            if (!type.equals("application/json") && !type.endsWith("+json")) jsonAllowed = false;
                        }
                    }
                    case "-u", "--user", "-m", "--max-time" -> { }
                    default -> { return null; }
                }
            } else {
                if (target != null) return null;
                target = token;
            }
        }
        if (target == null) return null;
        return new Command(method, target, jsonAllowed && data != null && data.singleQuoted()
                && BODY.matcher(data.value().stripLeading()).matches() ? data : null);
    }
}
