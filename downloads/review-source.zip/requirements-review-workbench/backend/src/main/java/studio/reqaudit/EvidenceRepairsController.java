package studio.reqaudit;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

import static studio.reqaudit.StudioAccess.ACCOUNT;

@RestController
@RequestMapping("/api/reviews/{runId}/repairs")
class EvidenceRepairsController {
    private record Selection(List<String> patchIds) {}

    private final EvidenceRepairs repairs;

    EvidenceRepairsController(EvidenceRepairs repairs) {
        this.repairs = repairs;
    }

    @GetMapping
    EvidenceRepairs.Preview preview(@RequestAttribute(ACCOUNT) Accounts.User user, @PathVariable String runId) {
        return repairs.preview(user.id(), runId);
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    Domain.Document apply(@RequestAttribute(ACCOUNT) Accounts.User user, @PathVariable String runId,
                          @RequestBody Selection selection) {
        return repairs.apply(user.id(), runId, selection.patchIds());
    }
}
