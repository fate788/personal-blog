package studio.reqaudit;

import com.fasterxml.jackson.databind.node.ObjectNode;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.time.Instant;
import java.util.List;
import java.util.Map;

import static studio.reqaudit.Accounts.User;
import static studio.reqaudit.Domain.*;
import static studio.reqaudit.Projects.Member;
import static studio.reqaudit.Projects.MemberInvitation;
import static studio.reqaudit.Projects.MemberInput;
import static studio.reqaudit.Projects.Project;
import static studio.reqaudit.Projects.ProjectInput;
import static studio.reqaudit.StudioAccess.ACCOUNT;
import static studio.reqaudit.StudioAccess.PublicEndpoint;

@RestController
@RequestMapping("/api")
class WorkspaceController {
    private record NewDocument(String title, String text, String projectId) {}
    private record NewVersion(String text, String expectedLatestVersionId) {}
    private record StartReview(String documentId, String versionId, String packId, boolean async, Mode mode,
                               List<String> itemIds, ModelProfile profile, String reviewBasis, String packVersion,
                               boolean forceFresh, ExecutionStrategy executionStrategy) {}
    private record RecordDecision(Decision decision, String note) {}
    private record ModelTestInput(ModelProfile profile) {}

    private final AuditRepository repository;
    private final AuditCatalog catalog;
    private final DocumentParser parser;
    private final ReviewService reviews;
    private final ModelGateway model;
    private final Projects projects;
    private final ReviewQueue queue;
    private final Issues issues;
    private final DeliveryReadiness readiness;
    private final ProjectRules projectRules;
    private final ProjectPacks projectPacks;

    WorkspaceController(AuditRepository repository, AuditCatalog catalog, DocumentParser parser,
                        ReviewService reviews, ModelGateway model, Projects projects, ReviewQueue queue, Issues issues,
                        DeliveryReadiness readiness, ProjectRules projectRules, ProjectPacks projectPacks) {
        this.repository = repository;
        this.catalog = catalog;
        this.parser = parser;
        this.reviews = reviews;
        this.model = model;
        this.projects = projects;
        this.queue = queue;
        this.issues = issues;
        this.readiness = readiness;
        this.projectRules = projectRules;
        this.projectPacks = projectPacks;
    }

    @GetMapping("/health")
    @PublicEndpoint
    Map<String, String> health() {
        return Map.of("status", "UP");
    }

    @GetMapping("/projects")
    List<Project> listProjects(@RequestAttribute(ACCOUNT) User user) {
        return projects.list(user.id());
    }

    @PostMapping("/projects")
    @ResponseStatus(HttpStatus.CREATED)
    Project createProject(@RequestAttribute(ACCOUNT) User user, @RequestBody ProjectInput body) {
        return projects.create(user.id(), body);
    }

    @PatchMapping("/projects/{id}")
    Project updateProject(@RequestAttribute(ACCOUNT) User user, @PathVariable String id, @RequestBody ProjectInput body) {
        return projects.update(user.id(), id, body);
    }

    @GetMapping("/projects/{id}/members")
    List<Member> members(@RequestAttribute(ACCOUNT) User user, @PathVariable String id) {
        return projects.members(user.id(), id);
    }

    @PostMapping("/projects/{id}/members")
    List<Member> inviteMember(@RequestAttribute(ACCOUNT) User user, @PathVariable String id,
                              @RequestBody MemberInvitation body) {
        return projects.invite(user.id(), id, body);
    }

    @PutMapping("/projects/{id}/members")
    List<Member> grantMember(@RequestAttribute(ACCOUNT) User user, @PathVariable String id,
                             @RequestBody MemberInput body) {
        return projects.grant(user.id(), id, body);
    }

    @DeleteMapping("/projects/{id}/members/{userId}")
    List<Member> revokeMember(@RequestAttribute(ACCOUNT) User user, @PathVariable String id,
                              @PathVariable String userId) {
        return projects.revoke(user.id(), id, userId);
    }

    @GetMapping("/projects/{id}/issues")
    List<Issues.Summary> issueInbox(@RequestAttribute(ACCOUNT) User user, @PathVariable String id) {
        return issues.inbox(user, id);
    }

    @PostMapping("/projects/sample")
    Project sample(@RequestAttribute(ACCOUNT) User user) {
        return projects.sample(user.id());
    }

    @GetMapping("/workspace")
    Workspace workspace(@RequestAttribute(ACCOUNT) User user, @RequestParam(required = false) String projectId,
                        @RequestParam(defaultValue = "false") boolean directory) {
        var available = projects.list(user.id());
        Project project = projectId != null && !projectId.isBlank() ? projects.accessible(user.id(), projectId)
                : directory || available.isEmpty() ? null : available.get(0);
        if (project == null) {
            return new Workspace(List.of(), catalog.getPacks(), List.of(), model.mode(), available, null);
        }
        var runs = repository.listRuns(project.id()).stream().map(projectPacks::historical).toList();
        return new Workspace(repository.listDocuments(project.id()), projectPacks.selectable(project.id()), runs,
                model.mode(), available, project);
    }

    @PostMapping("/documents")
    @ResponseStatus(HttpStatus.CREATED)
    Document create(@RequestAttribute(ACCOUNT) User user, @RequestBody NewDocument body) {
        var project = projects.selected(user.id(), body.projectId());
        requireEditor(project);
        return repository.addDocument(AuditRepository.id(), project.id(), body.title(), body.text(), Map.of());
    }

    @PostMapping(value = "/documents/import", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    @ResponseStatus(HttpStatus.CREATED)
    Document importFile(@RequestAttribute(ACCOUNT) User user, @RequestPart("file") MultipartFile file,
                        @RequestParam(required = false) String title, @RequestParam(required = false) String projectId) {
        var project = projects.selected(user.id(), projectId);
        requireEditor(project);
        var imported = parser.read(file);
        String name = title == null || title.isBlank() ? imported.title() : title;
        return repository.addDocument(AuditRepository.id(), project.id(), name, imported.text(), imported.headings(),
                imported.source());
    }

    @PostMapping("/documents/{id}/versions")
    @ResponseStatus(HttpStatus.CREATED)
    Document version(@RequestAttribute(ACCOUNT) User user, @PathVariable String id, @RequestBody NewVersion body) {
        requireEditor(projects.forDocument(user.id(), id));
        return repository.addTextVersion(id, body.text(), body.expectedLatestVersionId());
    }

    @PostMapping(value = "/documents/{id}/versions/import", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    @ResponseStatus(HttpStatus.CREATED)
    Document importVersion(@RequestAttribute(ACCOUNT) User user, @PathVariable String id,
                           @RequestPart("file") MultipartFile file) {
        requireEditor(projects.forDocument(user.id(), id));
        return repository.addVersion(id, parser.read(file));
    }

    @GetMapping("/documents/{id}/versions/{versionId}/checks")
    List<RuleWarning> versionChecks(@RequestAttribute(ACCOUNT) User user, @PathVariable String id,
                                    @PathVariable String versionId) {
        projects.forDocument(user.id(), id);
        return projectRules.check(id, repository.requireVersion(id, versionId));
    }

    @GetMapping("/documents/{id}/checks/compare")
    ProjectRules.Comparison compareChecks(@RequestAttribute(ACCOUNT) User user, @PathVariable String id,
                                         @RequestParam String before, @RequestParam String after) {
        projects.forDocument(user.id(), id);
        return projectRules.compare(id, repository.requireVersion(id, before), repository.requireVersion(id, after));
    }

    @GetMapping("/documents/{id}/versions/{versionId}/readiness")
    DeliveryReadiness.Snapshot versionReadiness(@RequestAttribute(ACCOUNT) User user, @PathVariable String id,
                                                 @PathVariable String versionId,
                                                 @RequestParam(required = false) String runId) {
        return readiness.snapshot(user.id(), id, versionId, runId);
    }

    @PostMapping("/reviews")
    ResponseEntity<ReviewQueue.Submission> review(@RequestAttribute(ACCOUNT) User user, @RequestBody StartReview body) {
        String documentId = ApiFailure.requireText(body.documentId(), "文档编号", 64);
        if (!projects.forDocument(user.id(), documentId).role().mayStartReview()) {
            throw ApiFailure.forbidden("查看者不能发起审查。");
        }
        String versionId = ApiFailure.requireText(body.versionId(), "版本编号", 64);
        String packId = ApiFailure.requireText(body.packId(), "审查包编号", 64);
        Pack pack = projectPacks.forDocument(documentId, packId, body.packVersion());
        if (body.executionStrategy() == ExecutionStrategy.COMBINED && body.mode() != Mode.MODEL) {
            throw ApiFailure.badRequest("联合审查需要选择模型执行方式。");
        }
        if (body.executionStrategy() == ExecutionStrategy.LOCAL_ONLY && body.mode() != Mode.DEMO) {
            throw ApiFailure.badRequest("仅本地规则检查需要选择本地执行方式。");
        }
        ModelProfile profile = workspaceProfile(user, body.profile());
        Mode mode = model.resolve(body.mode(), profile);
        if (mode != Mode.MODEL && !body.async()) {
            Run local = reviews.run(documentId, versionId, pack, mode, body.itemIds(), profile, body.reviewBasis(), body.executionStrategy());
            return ResponseEntity.status(HttpStatus.CREATED).body(new ReviewQueue.Submission(local, ReviewQueue.Disposition.CREATED));
        }
        var prepared = reviews.prepare(documentId, versionId, pack, mode, body.itemIds(), profile, body.reviewBasis(),
                body.executionStrategy());
        var submission = queue.submit(prepared, body.forceFresh(), body.async());
        if (submission.submissionDisposition() == ReviewQueue.Disposition.REUSED) return ResponseEntity.ok(submission);
        if (body.async() || submission.submissionDisposition() == ReviewQueue.Disposition.IN_PROGRESS) {
            return ResponseEntity.accepted().body(submission);
        }
        Run completed;
        try {
            completed = reviews.evaluate(submission.run(), queue::progress);
            queue.complete(completed);
        } catch (RuntimeException failure) {
            queue.fail(submission.run().id(), new Diagnostic("JOB_ERROR", "审查任务未能完成，请检查模型连接并重新提交。"));
            throw failure;
        }
        return ResponseEntity.status(HttpStatus.CREATED).body(new ReviewQueue.Submission(completed, ReviewQueue.Disposition.CREATED));
    }

    @GetMapping("/reviews/{id}")
    Run review(@RequestAttribute(ACCOUNT) User user, @PathVariable String id) {
        projects.forRun(user.id(), id);
        return projectPacks.historical(repository.requireRun(id, false));
    }

    @PatchMapping("/reviews/{runId}/findings/{findingId}")
    Run decide(@RequestAttribute(ACCOUNT) User user, @PathVariable String runId, @PathVariable String findingId,
               @RequestBody RecordDecision body) {
        if (!projects.forRun(user.id(), runId).role().mayReview()) {
            throw ApiFailure.forbidden("仅项目拥有者和评审者可确认或驳回疑点。");
        }
        if (body.decision() == null) {
            throw ApiFailure.badRequest("请选择复核结论。");
        }
        String note = ApiFailure.optionalText(body.note(), "备注", 2_000);
        return projectPacks.historical(repository.decide(runId, findingId, body.decision(), note, Instant.now().toString()));
    }

    @GetMapping("/reviews/{runId}/issues")
    List<Issues.Issue> issues(@RequestAttribute(ACCOUNT) User user, @PathVariable String runId) {
        return issues.list(user, runId);
    }

    @PatchMapping("/reviews/{runId}/issues/{findingId}")
    Issues.Issue issue(@RequestAttribute(ACCOUNT) User user, @PathVariable String runId,
                       @PathVariable String findingId, @RequestBody ObjectNode body) {
        return issues.update(user, runId, findingId, body);
    }

    @GetMapping("/reviews/{id}/report")
    Report report(@RequestAttribute(ACCOUNT) User user, @PathVariable String id) {
        projects.forRun(user.id(), id);
        Run run = projectPacks.historical(repository.requireRun(id, false));
        if (run.status() == RunStatus.QUEUED || run.status() == RunStatus.RUNNING) {
            throw ApiFailure.conflict("审查任务尚未完成，结果生成后可查看报告。");
        }
        Document document = repository.requireDocument(run.documentId());
        Version version = repository.requireVersion(run.documentId(), run.versionId());
        return new Report(document.title(), version.number(), run.packSnapshot().name(),
                run, repository.listDecisions(id));
    }

    @PostMapping("/drafts")
    Draft draft(@RequestAttribute(ACCOUNT) User user, @RequestBody DraftInput body) {
        DraftInput input = new DraftInput(
                ApiFailure.requireText(body.goal(), "项目目标或业务需求", 4_000).strip(),
                ApiFailure.optionalText(body.roles(), "用户角色", 4_000),
                ApiFailure.optionalText(body.features(), "核心功能", 6_000),
                ApiFailure.optionalText(body.constraints(), "业务约束", 4_000),
                ApiFailure.optionalText(body.scope(), "范围与边界", 4_000),
                ApiFailure.optionalText(body.acceptance(), "验收条件", 4_000),
                ApiFailure.optionalText(body.nfr(), "非功能需求", 4_000),
                ApiFailure.optionalText(body.integrations(), "数据与外部接口", 4_000),
                body.mode(), workspaceProfile(user, body.profile()));
        return model.draft(input);
    }

    @GetMapping("/model")
    ModelGateway.Connection model() {
        return model.connection();
    }

    @PostMapping("/model/test")
    ModelGateway.ConnectionTest testModel(@RequestAttribute(ACCOUNT) User user,
                                          @RequestBody(required = false) ModelTestInput input) {
        if (user.role() != Accounts.Role.ADMIN) {
            throw ApiFailure.forbidden("仅系统管理员可测试模型连接。");
        }
        return model.testConnection(input == null ? null : input.profile());
    }

    private static void requireEditor(Project project) {
        if (!project.role().mayEdit()) throw ApiFailure.forbidden("仅项目拥有者和编辑者可维护需求文档。");
    }

    private ModelProfile workspaceProfile(User user, ModelProfile requested) {
        return user.role() == Accounts.Role.ADMIN && requested != null ? requested : model.defaultProfile();
    }
}
