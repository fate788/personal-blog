package studio.reqaudit;

import studio.reqaudit.Domain.RuleWarning;
import java.util.regex.Pattern;

/** Small literal substitutions for an already reproduced source warning. */
final class SourceExampleRepair {
    record Edit(String title, String text) {}
    private static final Pattern SQL_CALL = Pattern.compile("(?i)^\\s*select\\s+([a-z_][a-z0-9_]*)\\s*\\(");
    private static final Pattern SQL_HEADER = Pattern.compile("(?i)^\\s*\\|\\s*([a-z_][a-z0-9_]*)\\s*\\(");
    private static final Pattern ARRAY_ROW = Pattern.compile("^\\s*\\|\\s*\\[([0-9, +\\-]+)]\\s*\\|\\s*$");
    private static final Pattern NUMBER = Pattern.compile("[+\\-]?[0-9]+");
    private static final Pattern COUNT = Pattern.compile("第 ([0-9]+) 项截至此处出现 ([0-9]+) 次，结果表写的是 ([+\\-]?[0-9]+)");

    static Edit edit(String[] lines, RuleWarning warning) {
        String line = lines[warning.line() - 1];
        return switch (warning.type()) {
            case "INVALID_JSON_EXAMPLE" -> {
                int comma = line.stripTrailing().length() - 1;
                boolean closes = warning.line() < lines.length && lines[warning.line()].stripLeading().matches("^[}\\]].*");
                yield closes && comma >= 0 && line.charAt(comma) == ','
                        ? new Edit("删除 JSON 最后一项后的逗号", line.substring(0, comma) + line.substring(comma + 1)) : null;
            }
            case "SQL_EXAMPLE_FUNCTION_MISMATCH" -> {
                var call = SQL_CALL.matcher(line);
                var header = SQL_HEADER.matcher(lines[warning.relatedLine() - 1]);
                yield call.find() && header.find() ? new Edit("统一查询和结果表中的函数名",
                        line.substring(0, call.start(1)) + header.group(1) + line.substring(call.end(1))) : null;
            }
            case "WORKED_OCCURRENCE_MISMATCH" -> count(line, warning.detail());
            default -> null;
        };
    }

    private static Edit count(String line, String warning) {
        var diagnostic = COUNT.matcher(warning);
        var row = ARRAY_ROW.matcher(line);
        if (!diagnostic.find() || !row.matches()) return null;
        var values = NUMBER.matcher(line).region(row.start(1), row.end(1));
        int target = Integer.parseInt(diagnostic.group(1));
        for (int index = 1; values.find(); index++) {
            if (index == target && Integer.parseInt(values.group()) == Integer.parseInt(diagnostic.group(3))) {
                return new Edit("修正结果表中第 " + index + " 项的出现次数",
                        line.substring(0, values.start()) + diagnostic.group(2) + line.substring(values.end()));
            }
        }
        return null;
    }

    private SourceExampleRepair() {}
}
