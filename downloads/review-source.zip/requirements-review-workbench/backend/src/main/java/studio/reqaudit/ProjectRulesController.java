package studio.reqaudit;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;

import static studio.reqaudit.Accounts.User;
import static studio.reqaudit.Domain.Version;
import static studio.reqaudit.ProjectRules.*;
import static studio.reqaudit.Projects.ProjectRole.OWNER;
import static studio.reqaudit.StudioAccess.ACCOUNT;

@RestController
@RequestMapping("/api/projects/{projectId}/review-rules")
class ProjectRulesController {
    private final Projects projects;
    private final AuditRepository repository;
    private final ProjectRules rules;

    ProjectRulesController(Projects projects, AuditRepository repository, ProjectRules rules) {
        this.projects = projects;
        this.repository = repository;
        this.rules = rules;
    }

    @GetMapping
    List<RuleView> list(@RequestAttribute(ACCOUNT) User user, @PathVariable String projectId) {
        projects.accessible(user.id(), projectId);
        return rules.list(projectId);
    }

    @GetMapping("/{ruleId}/history")
    List<RuleView> history(@RequestAttribute(ACCOUNT) User user, @PathVariable String projectId, @PathVariable String ruleId) {
        projects.accessible(user.id(), projectId);
        return rules.history(projectId, ruleId);
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    RuleView create(@RequestAttribute(ACCOUNT) User user, @PathVariable String projectId, @RequestBody Input input) {
        requireOwner(user, projectId);
        return rules.save(projectId, null, user.id(), input);
    }

    @PutMapping("/{ruleId}")
    RuleView update(@RequestAttribute(ACCOUNT) User user, @PathVariable String projectId,
                    @PathVariable String ruleId, @RequestBody Input input) {
        requireOwner(user, projectId);
        return rules.save(projectId, ruleId, user.id(), input);
    }

    @PostMapping("/{ruleId}/trial")
    Trial trial(@RequestAttribute(ACCOUNT) User user, @PathVariable String projectId,
                @PathVariable String ruleId, @RequestBody Target input) {
        return rules.trial(projectId, ruleId, target(user, projectId, input.documentId(), input.versionId()));
    }

    @PostMapping("/{ruleId}/feedback")
    RuleView feedback(@RequestAttribute(ACCOUNT) User user, @PathVariable String projectId,
                      @PathVariable String ruleId, @RequestBody Feedback input) {
        if (!projects.accessible(user.id(), projectId).role().mayReview()) {
            throw ApiFailure.forbidden("反馈需要项目负责人或复核人权限。");
        }
        return rules.feedback(projectId, ruleId, user.id(), target(user, projectId, input.documentId(), input.versionId()), input);
    }

    private Version target(User user, String projectId, String documentId, String versionId) {
        if (!projects.forDocument(user.id(), documentId).id().equals(projectId)) {
            throw ApiFailure.notFound("此版本不属于当前项目。");
        }
        return repository.requireVersion(documentId, versionId);
    }

    private void requireOwner(User user, String projectId) {
        if (projects.accessible(user.id(), projectId).role() != OWNER) {
            throw ApiFailure.forbidden("仅项目负责人可维护规则。");
        }
    }
}
