# 无障碍走查工作台 v1.0 源码包

原始发布归档为 `无障碍走查工作台-v1.0.zip`。压缩包保留其中 11 份文本文件的原始路径与字节，本文件为导出说明。

在 Node.js 22 或更新版本运行 npm test 和 npm run build，打开 dist/index.html。
