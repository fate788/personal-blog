import {createHash, randomBytes, scrypt, scryptSync, timingSafeEqual} from "node:crypto";
import {closeSync, mkdirSync, openSync, readFileSync} from "node:fs";
import {createServer} from "node:http";
import {dirname, resolve} from "node:path";
import {DatabaseSync} from "node:sqlite";
import {fileURLToPath} from "node:url";
import {parseArgs, promisify} from "node:util";
import {actors, createWorkspace, dispatch} from "./domain.mjs";

const loopback = new Set(["127.0.0.1", "localhost", "::1", "[::1]"]);
const maxBody = 24 * 1024;
const demoAge = 30 * 24 * 3600;
const teamAge = 12 * 3600;
const localActors = new Map(actors.map(actor => [actor.id, actor]));
const deriveKey = promisify(scrypt);
const files = new Map([
  ["/", ["index.html", "text/html; charset=utf-8"]],
  ["/index.html", ["index.html", "text/html; charset=utf-8"]],
  ["/styles.css", ["styles.css", "text/css; charset=utf-8"]],
  ["/app.mjs", ["app.mjs", "text/javascript; charset=utf-8"]],
  ["/transport.mjs", ["transport.mjs", "text/javascript; charset=utf-8"]],
  ["/offline.mjs", ["offline.mjs", "text/javascript; charset=utf-8"]],
  ["/storage.mjs", ["storage.mjs", "text/javascript; charset=utf-8"]],
  ["/sw.js", ["sw.js", "text/javascript; charset=utf-8"]],
  ["/manifest.webmanifest", ["manifest.webmanifest", "application/manifest+json"]],
  ["/icon-192.png", ["icon-192.png", "image/png"]],
  ["/icon-512.png", ["icon-512.png", "image/png"]],
  ["/hero.webp", ["hero.webp", "image/webp"]],
  ["/scan-station.webp", ["scan-station.webp", "image/webp"]],
]);

class HTTPError extends Error {
  constructor(status, message, code) {
    super(message);
    this.status = status;
    this.code = code;
  }
}

function required(condition, status, message, code) {
  if (!condition) throw new HTTPError(status, message, code);
}

function teamAccounts() {
  const rolePasswords = [
    ["counter-a", "INVENTORY_COUNTER_A_PASSWORD"],
    ["counter-b", "INVENTORY_COUNTER_B_PASSWORD"],
    ["reviewer", "INVENTORY_REVIEWER_PASSWORD"],
  ];
  const used = new Set();
  return new Map(rolePasswords.map(([id, key]) => {
    const password = process.env[key];
    if (typeof password !== "string" || password.length < 12 || password.length > 256 || used.has(password))
      throw new Error(`${key} 应包含 12 到 256 个字符，各账号密码应不同。`);
    used.add(password);
    const salt = randomBytes(16);
    return [id, {salt, key:scryptSync(password, salt, 64)}];
  }));
}

function originConfig(host, origin, secureCookie) {
  const url = origin ? new URL(origin) : null;
  if (url && (!["http:", "https:"].includes(url.protocol) || origin !== url.origin))
    throw new Error("--origin 应为完整源地址，例如 https://inventory.example.com。");
  const external = !loopback.has(host) || (url && !loopback.has(url.hostname));
  if ((external || secureCookie) && url?.protocol !== "https:")
    throw new Error("外部访问需配置 HTTPS 反向代理和 --origin。");
  return {url, secure:url?.protocol === "https:"};
}

function checkRequest(request, {url,secure}) {
  let host;
  try { host = new URL(`${secure ? "https" : "http"}://${request.headers.host || ""}`); }
  catch { throw new HTTPError(400, "请求主机地址无效。"); }
  required(host.pathname === "/" && !host.username && !host.password && !host.search && !host.hash,
    400, "请求主机地址无效。");
  required(url ? host.host === url.host : loopback.has(host.hostname), 400, "请求主机与工作台配置不匹配。");
  required(request.url?.startsWith("/") && !request.url.startsWith("//") && !request.url.includes("\\"), 400, "请求路径无效。");
  const path = new URL(request.url, url || host);
  required(path.origin === (url || host).origin, 400, "请求路径无效。");
  return path;
}

function verifyAPI(request, origin, method) {
  const site = request.headers["sec-fetch-site"];
  required(!site || site === "same-origin" || site === "none", 403, "该操作仅允许从工作台发起。");
  required(!request.headers.origin || request.headers.origin === origin, 403, "请求源与工作台不一致。");
  if (method !== "POST") return;
  required(request.headers["x-workspace-request"] === "1", 403, "请求未通过校验，请刷新页面。");
  required(/^application\/json(?:\s*;|$)/i.test(request.headers["content-type"] || ""),
    415, "请提交 JSON 请求。");
}

async function readBody(request) {
  required(Number(request.headers["content-length"] || 0) <= maxBody, 413, "请求内容过长。");
  const chunks = [];
  let bytes = 0;
  for await (const chunk of request.iterator({destroyOnReturn:false})) {
    bytes += chunk.length;
    if (bytes > maxBody) {
      request.resume();
      throw new HTTPError(413, "请求内容过长。");
    }
    chunks.push(chunk);
  }
  let value;
  try { value = JSON.parse(Buffer.concat(chunks).toString("utf8")); }
  catch { throw new HTTPError(400, "无法读取请求中的 JSON。"); }
  required(value && typeof value === "object" && !Array.isArray(value), 400, "请提交 JSON 对象。");
  return value;
}

function digest(token) { return createHash("sha256").update(token).digest("hex"); }
function opaqueToken() { return randomBytes(32).toString("hex"); }

function readCookie(request, name) {
  for (const entry of (request.headers.cookie || "").split(";")) {
    const [key,value] = entry.trim().split("=",2);
    if (key === name && /^[a-f0-9]{64}$/.test(value)) return digest(value);
  }
  return "";
}

function openStore(path, mode) {
  if (path !== ":memory:") {
    mkdirSync(dirname(resolve(path)), {recursive:true, mode:0o700});
    closeSync(openSync(path, "a", 0o600));
  }
  const db = new DatabaseSync(path);
  db.exec(`
    PRAGMA journal_mode=WAL;
    PRAGMA busy_timeout=4000;
    PRAGMA foreign_keys=ON;
    CREATE TABLE IF NOT EXISTS workspaces(
      id TEXT PRIMARY KEY, mode TEXT NOT NULL, state TEXT NOT NULL, touched_at INTEGER NOT NULL
    ) STRICT;
    CREATE UNIQUE INDEX IF NOT EXISTS inventory_single_team ON workspaces(mode) WHERE mode='team';
    CREATE TABLE IF NOT EXISTS sessions(
      token TEXT PRIMARY KEY, workspace_id TEXT NOT NULL REFERENCES workspaces(id) ON DELETE CASCADE,
      actor_id TEXT NOT NULL, expires_at INTEGER NOT NULL
    ) STRICT;
    CREATE INDEX IF NOT EXISTS inventory_session_expiration ON sessions(expires_at);
    CREATE INDEX IF NOT EXISTS inventory_workspace_retention ON workspaces(mode,touched_at);
  `);
  const put = db.prepare("INSERT INTO workspaces(id,mode,state,touched_at) VALUES(?,?,?,?)");
  const lookup = db.prepare("SELECT id FROM workspaces WHERE mode='team'");
  const sign = db.prepare("INSERT INTO sessions(token,workspace_id,actor_id,expires_at) VALUES(?,?,?,?)");
  const lookupSession = db.prepare(`SELECT w.id,w.state,s.actor_id FROM sessions s
    JOIN workspaces w ON w.id=s.workspace_id WHERE s.token=? AND s.expires_at>? AND w.mode=?`);
  const removeSession = db.prepare("DELETE FROM sessions WHERE token=?");
  const changeActor = db.prepare("UPDATE sessions SET actor_id=? WHERE token=?");
  const write = db.prepare("UPDATE workspaces SET state=?,touched_at=? WHERE id=?");
  const clearSessions = db.prepare("DELETE FROM sessions WHERE expires_at<=?");
  const clearDemo = db.prepare("DELETE FROM workspaces WHERE mode='demo' AND touched_at<?");
  let lastCleanup = 0;

  function transaction(callback) {
    db.exec("BEGIN IMMEDIATE");
    try {
      const result = callback();
      db.exec("COMMIT");
      return result;
    } catch (error) {
      db.exec("ROLLBACK");
      throw error;
    }
  }
  function create(now) {
    const id = opaqueToken();
    put.run(id,mode,JSON.stringify(createWorkspace(now)),now);
    return id;
  }

  const shared = mode === "team" ? transaction(() => lookup.get()?.id || create(Date.now())) : "";
  return {
    db, transaction,
    cleanup(now) {
      if (now-lastCleanup < 60_000) return;
      clearSessions.run(now);
      clearDemo.run(now-demoAge*1000);
      lastCleanup = now;
    },
    session(token, now) { return token && lookupSession.get(token,now,mode); },
    issue(actorId, now) {
      const token = opaqueToken();
      const id = shared || create(now);
      sign.run(digest(token),id,actorId,now+(shared ? teamAge : demoAge)*1000);
      return {id,token};
    },
    remove(token, now) {
      if (token && lookupSession.get(token,now,mode)) removeSession.run(token);
    },
    changeActor(token, actorId) { changeActor.run(actorId,token); },
    save(session, state, now) { write.run(JSON.stringify(state),now,session.id); },
  };
}

export function startServer({port=8808, host="127.0.0.1", dbPath, origin, secureCookie=false, team=false} = {}) {
  const config = originConfig(host,origin,secureCookie);
  const mode = team ? "team" : "demo";
  const accounts = team ? teamAccounts() : null;
  const database = dbPath || fileURLToPath(new URL(`./data/${mode}.sqlite`,import.meta.url));
  const store = openStore(database,mode);
  const cookieName = (config.secure ? "__Host-" : "") + (team ? "inventoryTeam" : "inventoryDemo");
  const cookie = (token, age) => `${cookieName}=${token}; Path=/; HttpOnly; SameSite=Strict; Max-Age=${age}${config.secure ? "; Secure" : ""}`;
  const publicSession = (actorId,id) => ({
    mode, actor:localActors.get(actorId) || null, actors:team ? [] : actors, workspaceId:id || null,
  });
  const attempts = new Map();
  const fallback = {salt:randomBytes(16),key:randomBytes(64)};

  function send(response,status,body,headers={}) {
    response.writeHead(status,{"Content-Type":"application/json; charset=utf-8","Cache-Control":"no-store",...headers});
    response.end(JSON.stringify(body));
  }

  async function login(request,response,input,oldToken) {
    required(accounts,404,"当前工作区使用演示身份。");
    const address = request.socket.remoteAddress;
    const now = Date.now();
    for (const [key, attempt] of attempts) if (attempt.expires <= now) attempts.delete(key);
    const attempt = attempts.get(address) || {count:0,expires:now+60_000};
    required(attempt.count<24,429,"尝试次数过多，请稍后重试。");
    attempts.set(address,{...attempt,count:attempt.count+1});
    const {id,password} = input;
    required(typeof id === "string" && typeof password === "string" && password.length>=1 && password.length<=256,
      400,"请填写账号和密码。");
    const account = accounts.get(id);
    const expected = account || fallback;
    const checked = await deriveKey(password,expected.salt,expected.key.length);
    required(timingSafeEqual(checked,expected.key) && account,401,"账号或密码不正确。");
    const result = store.transaction(() => {
      store.remove(oldToken,Date.now());
      return store.issue(id,Date.now());
    });
    send(response,200,publicSession(id,result.id),{"Set-Cookie":cookie(result.token,teamAge)});
  }

  function routeAPI(request,response,method,path,body,token) {
    const now = Date.now();
    const result = store.transaction(() => {
      store.cleanup(now);
      const session = store.session(token,now);
      if (method === "GET" && path === "/api/session") {
        if (!session && !team) {
          const fresh = store.issue("counter-a",now);
          return {status:200, body:publicSession("counter-a",fresh.id), signed:cookie(fresh.token,demoAge)};
        }
        return {status:200,body:publicSession(session?.actor_id,session?.id)};
      }
      if (method === "POST" && path === "/api/logout") {
        required(team,404,"演示工作区无需退出。");
        store.remove(token,now);
        return {status:200,body:publicSession(),signed:cookie("",0)};
      }
      required(session,401,"请先打开工作区或重新登录。");
      if (method === "POST" && path === "/api/session/role") {
        required(!team,403,"团队角色由登录账号决定。");
        required(localActors.has(body.id),400,"请选择有效的演示身份。");
        store.changeActor(token,body.id);
        return {status:200,body:publicSession(body.id,session.id)};
      }
      const scopedRead = method === "GET" && path === "/api/workspace"
        && (request.headers["x-workspace-id"] !== undefined || request.headers["x-workspace-actor"] !== undefined);
      if (method === "POST" || scopedRead) {
        required(request.headers["x-workspace-id"] === session.id && request.headers["x-workspace-actor"] === session.actor_id,
          409, "工作区或身份已经切换，请回到原身份再同步。","SESSION_SCOPE_CHANGED");
      }
      const state = JSON.parse(session.state);
      const result = dispatch(state,{method,path,actorId:session.actor_id,now,body});
      if (method === "POST" && result.status<400) store.save(session,state,now);
      return result;
    });
    send(response,result.status,result.body,result.signed ? {"Set-Cookie":result.signed} : {});
  }

  const server = createServer({maxHeaderSize:16*1024,requestTimeout:10_000,headersTimeout:8000},async (request,response) => {
    response.setHeader("X-Content-Type-Options","nosniff");
    response.setHeader("Referrer-Policy","no-referrer");
    response.setHeader("X-Frame-Options","DENY");
    response.setHeader("Cross-Origin-Resource-Policy","same-origin");
    response.setHeader("Content-Security-Policy",
      "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'self'; manifest-src 'self'; worker-src 'self'; object-src 'none'; base-uri 'none'; form-action 'self'; frame-ancestors 'none'");
    try {
      const url = checkRequest(request,config);
      const {method} = request;
      if (url.pathname.startsWith("/api/")) {
        required(method === "GET" || method === "POST",405,"不支持的接口方法。");
        verifyAPI(request,url.origin,method);
        const body = method === "POST" ? await readBody(request) : {};
        const token = readCookie(request,cookieName);
        if (method === "POST" && url.pathname === "/api/login") await login(request,response,body,token);
        else routeAPI(request,response,method,url.pathname,body,token);
        return;
      }
      const file = files.get(url.pathname);
      required(file && (method === "GET" || method === "HEAD"),404,"未找到页面。");
      const [name,type] = file;
      const contents = readFileSync(new URL(`./static/${name}`,import.meta.url));
      response.writeHead(200,{"Content-Type":type,"Content-Length":contents.length,"Cache-Control":"no-cache"});
      response.end(method === "HEAD" ? undefined : contents);
    } catch (error) {
      if (response.destroyed) return;
      if (error instanceof HTTPError) send(response,error.status,{error:error.message,code:error.code});
      else {
        console.error(error.code || error.name || "RequestError");
        send(response,500,{error:"工作台暂时不可用，请稍后重试。"});
      }
    }
  });
  server.on("close",() => store.db.close());
  return server.listen(port,host);
}

if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const {values} = parseArgs({options:{
    port:{type:"string",default:"8808"},host:{type:"string",default:"127.0.0.1"},
    db:{type:"string"},origin:{type:"string"},team:{type:"boolean"},"secure-cookie":{type:"boolean"},
  }});
  if (!/^\d{1,5}$/.test(values.port) || Number(values.port)>65535) throw new Error("端口应为 0 至 65535。");
  const server = startServer({
    host:values.host,port:Number(values.port),dbPath:values.db,origin:values.origin,
    secureCookie:values["secure-cookie"],team:values.team,
  });
  server.on("listening",() => {
    const address = server.address();
    const host = address.family === "IPv6" ? `[${address.address}]` : address.address;
    console.log(`http://${host}:${address.port}/`);
  });
}
