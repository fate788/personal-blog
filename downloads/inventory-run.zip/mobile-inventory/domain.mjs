export const actors = Object.freeze([
  Object.freeze({ id: "counter-a", name: "仓员甲", role: "counter" }),
  Object.freeze({ id: "counter-b", name: "仓员乙", role: "counter" }),
  Object.freeze({ id: "reviewer", name: "仓库主管", role: "reviewer" }),
]);

const locations = [
  { id: "a01", name: "A01 包材架", zone: "A 区 · 出库包装" },
  { id: "a02", name: "A02 辅料架", zone: "A 区 · 出库包装" },
  { id: "b01", name: "B01 工具柜", zone: "B 区 · 备货工作区" },
];

function stockItem(id, locationId, name, sku, barcode, unit, expected) {
  return { id, locationId, name, sku, barcode, unit, expected, status: "open", revision: 0, counts: [] };
}

export function createWorkspace(now = Date.now()) {
  const state = {
    locations: locations.map(location => ({ ...location })),
    items: [
      stockItem("a01-tape", "a01", "牛皮纸封箱胶带", "PK-104", "2900000000018", "卷", 24),
      stockItem("a01-carton", "a01", "中号瓦楞箱", "PK-208", "2900000000025", "个", 32),
      stockItem("a01-wrap", "a01", "蜂窝缓冲纸", "PK-313", "2900000000032", "卷", 18),
      stockItem("a02-label", "a02", "条码标签纸", "PK-408", "2900000000049", "卷", 48),
      stockItem("a02-sleeve", "a02", "防静电包装袋", "PK-512", "2900000000056", "包", 12),
      stockItem("b01-cutter", "b01", "安全开箱刀", "TO-601", "2900000000063", "把", 10),
      stockItem("b01-marker", "b01", "黑色油性记号笔", "TO-708", "2900000000070", "支", 0),
    ],
    history: [],
    receipts: [],
  };

  // These closed stock checks illustrate an agreement and a difference while A01 remains available to count.
  const label = state.items.find(item => item.id === "a02-label");
  const cutter = state.items.find(item => item.id === "b01-cutter");
  submitCount(state, actors[0], label, "sample-label-a", 48, now - 15 * 60_000);
  submitCount(state, actors[1], label, "sample-label-b", 48, now - 14 * 60_000);
  submitCount(state, actors[0], cutter, "sample-cutter-a", 10, now - 12 * 60_000);
  submitCount(state, actors[1], cutter, "sample-cutter-b", 9, now - 11 * 60_000);
  return state;
}

function response(body, status = 200) {
  return { status, body };
}

function reject(status, code, error) {
  return response({ error, code }, status);
}

function audit(state, item, actor, at, type, details = {}) {
  state.history.push({
    id: "event-" + (state.history.length + 1),
    itemId: item.id,
    at,
    type,
    actorId: actor.id,
    actorName: actor.name,
    ...details,
  });
}

function submitCount(state, actor, item, opId, quantity, now) {
  const count = { id: opId, actorId: actor.id, actorName: actor.name, quantity, at: now };
  item.counts.push(count);
  item.revision += 1;
  audit(state, item, actor, now, "counted", { quantity });

  if (item.counts.length === 2) {
    if (item.counts.every(entry => entry.quantity === item.expected)) {
      item.status = "agreed";
      item.finalQuantity = item.expected;
    } else {
      item.status = "review";
    }
    audit(state, item, { id: "system", name: "系统" }, now, item.status);
  }

  const result = { itemId: item.id, revision: item.revision, status: item.status };
  state.receipts.push({ opId, itemId: item.id, actorId: actor.id, quantity, result });
  return { ...result };
}

function workspace(state, actor) {
  const reviewer = actor.role === "reviewer";
  return {
    actor: { ...actor },
    locations: state.locations.map(location => ({ ...location })),
    items: state.items.map(item => {
      const { expected, finalQuantity, counts, decision, ...header } = item;
      return {
        ...header,
        ...(reviewer ? { expected } : {}),
        ...(finalQuantity !== undefined && (reviewer || item.status === "closed") ? { finalQuantity } : {}),
        ...(reviewer && decision ? { decision: { ...decision } } : {}),
        counts: counts.filter(entry => reviewer || entry.actorId === actor.id).map(entry => ({ ...entry })),
      };
    }),
    history: [...state.history].reverse().filter(entry => reviewer || entry.actorId === actor.id)
      .map(({ actorId, ...entry }) => entry),
  };
}

function validQuantity(quantity) {
  return Number.isSafeInteger(quantity) && quantity >= 0;
}

function countItem(state, actor, body, now) {
  if (actor.role !== "counter")
    return reject(403, "COUNTER_ONLY", "只有盘点员可以提交实点数量。");

  const { opId, itemId, quantity } = body;
  if (typeof opId !== "string" || !/^[a-z0-9][a-z0-9._:-]{0,127}$/iu.test(opId) || typeof itemId !== "string")
    return reject(422, "INVALID_OPERATION", "请提供有效的操作编号和商品编号。");
  if (!validQuantity(quantity))
    return reject(422, "INVALID_QUANTITY", "实点数量必须为 0 或正整数。");

  const previous = state.receipts.find(entry => entry.opId === opId);
  if (previous) {
    if (previous.itemId !== itemId || previous.actorId !== actor.id || previous.quantity !== quantity)
      return reject(409, "OPERATION_CONFLICT", "该操作编号已经用于另一条盘点记录。");
    return response({ ...previous.result, replayed: true });
  }

  const item = state.items.find(entry => entry.id === itemId);
  if (!item) return reject(404, "ITEM_NOT_FOUND", "没有找到该库位商品。");
  if (item.counts.some(entry => entry.actorId === actor.id))
    return reject(409, "ALREADY_COUNTED", "你已经提交过这件商品的盘点记录，原记录已保留。");
  if (item.status !== "open")
    return reject(409, "COUNTING_ENDED", "这件商品已经结束盘点。");

  return response(submitCount(state, actor, item, opId, quantity, now), 201);
}

function resolveItem(state, actor, id, body, now) {
  if (actor.role !== "reviewer")
    return reject(403, "REVIEWER_ONLY", "只有主管可以作出复核决定。");

  const item = state.items.find(entry => entry.id === id);
  if (!item) return reject(404, "ITEM_NOT_FOUND", "没有找到该库位商品。");

  const { revision, quantity } = body;
  const note = typeof body.note === "string" ? body.note.trim() : "";
  if (!Number.isSafeInteger(revision) || revision < 0)
    return reject(422, "INVALID_REVISION", "请重新打开要复核的商品。");
  if (!validQuantity(quantity))
    return reject(422, "INVALID_QUANTITY", "复核数量必须为 0 或正整数。");
  if (!note || note.length > 500)
    return reject(422, "INVALID_NOTE", "请填写不超过 500 字的复核依据。");
  if (item.revision !== revision)
    return reject(409, "STALE_REVISION", "数据已更新，请刷新后重新核对。");
  if (item.status !== "review")
    return reject(409, "NOT_PENDING_REVIEW", "这件商品当前无需复核。");

  item.status = "closed";
  item.revision += 1;
  item.finalQuantity = quantity;
  item.decision = { actorId: actor.id, actorName: actor.name, quantity, note, at: now };
  audit(state, item, actor, now, "closed", { quantity, note });
  return response({ itemId: id, revision: item.revision, status: item.status });
}

export function dispatch(state, { method, path, actorId, now = Date.now(), body = {} }) {
  const actor = actors.find(person => person.id === actorId);
  if (!actor) return reject(401, "UNKNOWN_ACTOR", "请先选择工作身份。");
  if (method === "GET" && path === "/api/workspace") return response(workspace(state, actor));
  if (method !== "POST") return reject(404, "UNKNOWN_ROUTE", "没有找到该操作。");
  if (!body || typeof body !== "object" || Array.isArray(body))
    return reject(422, "INVALID_BODY", "请提供有效的请求内容。");
  if (path === "/api/counts") return countItem(state, actor, body, now);
  const resolve = /^\/api\/items\/([a-z0-9-]+)\/resolve$/u.exec(path);
  if (resolve) return resolveItem(state, actor, resolve[1], body, now);
  return reject(404, "UNKNOWN_ROUTE", "没有找到该操作。");
}
