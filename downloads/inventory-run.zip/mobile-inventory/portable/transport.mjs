import {actors,createWorkspace,dispatch} from "../domain.mjs";
import {storage} from "./storage.mjs";

export default async function request(path,{method="GET",body={},session}={}){
  let result;
  await storage("simulation-server",prior=>{
    const state=prior || {id:crypto.randomUUID(),actorId:"counter-a",workspace:createWorkspace()};
    const identity=()=>({mode:"demo",workspaceId:state.id,actors,actor:actors.find(actor=>actor.id===state.actorId)});
    if(method==="GET" && path==="/api/session"){
      result={status:200,body:identity()};
    }else if(method==="POST" && path==="/api/session/role"){
      const actor=actors.find(item=>item.id===body.id);
      if(!actor)result={status:422,body:{error:"没有该演练身份。"}};
      else{state.actorId=actor.id;result={status:200,body:identity()};}
    }else if(!session || session.workspaceId!==state.id || session.actor?.id!==state.actorId){
      result={status:409,body:{error:"工作台身份已更新，请重新连接后同步。",code:"SESSION_CHANGED"}};
    }else{
      result=dispatch(state.workspace,{path,method,body,actorId:state.actorId,now:Date.now()});
    }
    return state;
  });
  if(result.status>=400)throw Object.assign(new Error(result.body.error),{status:result.status,code:result.body.code});
  return result.body;
}
