import assert from "node:assert/strict";
import {spawn} from "node:child_process";
import {once} from "node:events";
import {mkdtemp, rm, rmdir} from "node:fs/promises";
import {get} from "node:http";
import {tmpdir} from "node:os";
import {join} from "node:path";
import test from "node:test";

const credentials = {
  "counter-a":"valid-fixture-counter-a",
  "counter-b":"valid-fixture-counter-b",
  reviewer:"valid-fixture-reviewer",
};
const directory = new URL("../",import.meta.url);

async function host(t,{db=":memory:",team=false}={}) {
  const env = {...process.env,
    INVENTORY_COUNTER_A_PASSWORD:credentials["counter-a"],
    INVENTORY_COUNTER_B_PASSWORD:credentials["counter-b"],
    INVENTORY_REVIEWER_PASSWORD:credentials.reviewer,
  };
  const args = ["server.mjs","--port","0","--db",db,...(team ? ["--team"] : [])];
  const processHandle = spawn(process.execPath,args,{cwd:directory,env,stdio:["ignore","pipe","pipe"]});
  let output = "", errors = "";
  processHandle.stderr.on("data",message => { errors += message; });
  const exit = once(processHandle,"exit");
  const stop = async () => {
    if (processHandle.exitCode === null && processHandle.signalCode === null) processHandle.kill();
    await exit.catch(() => {});
  };
  t.after(stop);
  const base = await new Promise((resolve,reject) => {
    processHandle.stdout.on("data",out => {
      output += out;
      const url = output.match(/http:\/\/127\.0\.0\.1:\d+\//u);
      if (url) resolve(url[0].slice(0,-1));
    });
    processHandle.on("error",reject);
    processHandle.on("exit",code => reject(new Error(`Host exited (${code}) ${errors}`)));
  });
  return {base,stop};
}

function browser(base) {
  let cookie = "", session;
  return { async api(path,body,extra={}) {
    const headers = {...(cookie ? {Cookie:cookie} : {})};
    if (session?.workspaceId) {
      headers["X-Workspace-Id"] = session.workspaceId;
      headers["X-Workspace-Actor"] = session.actor.id;
    }
    if (body !== undefined) {
      headers["Content-Type"] = "application/json";
      headers["X-Workspace-Request"] = "1";
    }
    const response = await fetch(base+path,{
      method:body === undefined ? "GET" : "POST",
      body:body === undefined ? undefined : JSON.stringify(body),
      headers:{...headers,...extra},
    });
    const data = await response.json();
    const saved = response.headers.get("Set-Cookie");
    if (saved) cookie = saved.split(";",1)[0];
    if (response.ok && Object.hasOwn(data,"workspaceId")) session = data;
    return {body:data,status:response.status,headers:response.headers};
  }};
}

const readTape = workspace => workspace.items.find(item => item.id === "a01-tape");
const count = (opId,quantity) => ({opId,itemId:"a01-tape",quantity});
const decision = (revision,quantity) => ({revision,quantity,note:"主管现场复点"});
const workspace = "/api/workspace";
const resolveTape = "/api/items/a01-tape/resolve";
const pickRole = "/api/session/role";

test("demo workspace stays isolated, rejects stale identity, and replays a queued count exactly once", {timeout:15_000}, async t => {
  const {base} = await host(t);
  const worker = browser(base);
  const first = await worker.api("/api/session");
  assert.equal(first.body.actor.id,"counter-a");
  assert.equal(first.body.mode,"demo");
  assert.match(first.headers.get("Set-Cookie"),/HttpOnly/u);
  assert.match(first.headers.get("Cache-Control"),/no-store/u);
  const results = await Promise.all([
    worker.api("/api/counts",count("offline-a",23)),
    worker.api("/api/counts",count("offline-a",23)),
  ]);
  assert.deepEqual(results.map(result=>result.status).sort(),[200,201]);
  assert.equal(results.find(result=>result.status === 200).body.replayed,true);
  assert.equal((await worker.api("/api/counts",count("offline-a",22))).body.code,"OPERATION_CONFLICT");
  assert.equal((await worker.api(resolveTape,decision(1,23))).status,403);

  const switched = await worker.api(pickRole,{id:"counter-b"});
  assert.equal(switched.body.workspaceId,first.body.workspaceId);
  const stale = {"X-Workspace-Actor":"counter-a"};
  assert.equal((await worker.api(workspace,undefined,stale)).body.code,"SESSION_SCOPE_CHANGED");
  assert.equal((await worker.api("/api/counts",count("offline-b",24),stale)).status,409);
  assert.deepEqual(readTape((await worker.api(workspace)).body).counts,[]);
  assert.equal((await worker.api("/api/counts",count("offline-b",24))).body.status,"review");
  await worker.api(pickRole,{id:"reviewer"});
  const before = readTape((await worker.api(workspace)).body);
  assert.deepEqual(before.counts.map(entry=>entry.quantity),[23,24]);
  assert.equal((await worker.api(resolveTape,decision(1,24))).body.code,"STALE_REVISION");
  assert.equal((await worker.api(resolveTape,decision(before.revision,24))).body.status,"closed");

  const fresh = browser(base);
  const independent = await fresh.api("/api/session");
  assert.notEqual(independent.body.workspaceId,first.body.workspaceId);
  assert.deepEqual(readTape((await fresh.api(workspace)).body).counts,[]);
  const misdirected = await new Promise((resolve,reject) => {
    get(base+"/api/session",{headers:{Host:"untrusted.example"}},response => {
      response.resume();
      resolve(response.statusCode);
    }).on("error",reject);
  });
  assert.equal(misdirected,400);
  assert.equal((await worker.api(workspace,undefined,{Origin:"https://invalid.example"})).status,403);
  assert.equal((await worker.api("/api/counts",count("too-large",2),{"X-Workspace-Request":"0"})).status,403);
  assert.equal((await worker.api("/api/counts",{...count("too-large",2),extra:"A".repeat(25*1024)})).status,413);
  assert.equal((await fetch(base+"/domain.mjs")).status,404);
});

test("team sessions authenticate separately, share count progress, and keep the scope across server restarts", {timeout:15_000}, async t => {
  const temp = await mkdtemp(join(tmpdir(),"inventory-http-"));
  const db = join(temp,"trial.sqlite");
  let service;
  try {
    service = await host(t,{db,team:true});
    const user = browser(service.base), other = browser(service.base);
    const login = (client,id) => client.api("/api/login",{id,password:credentials[id]});
    assert.equal((await user.api("/api/session")).body.actor,null);
    assert.equal((await user.api(workspace)).status,401);
    assert.equal((await user.api("/api/login",{id:"counter-a",password:"incorrect"})).status,401);
    const account = await login(user,"counter-a");
    assert.equal(account.body.mode,"team");
    assert.deepEqual(account.body.actors,[]);
    const scope = account.body.workspaceId;
    assert.equal((await user.api(pickRole,{id:"reviewer"})).status,403);
    assert.equal((await user.api("/api/counts",count("team-a",0))).status,201);
    assert.equal((await login(other,"counter-b")).body.workspaceId,scope);
    assert.equal((await other.api("/api/counts",count("team-b",24))).body.status,"review");
    assert.equal((await user.api("/api/logout",{})).status,200);
    assert.equal((await user.api(workspace)).status,401);
    await service.stop();

    service = await host(t,{db,team:true});
    const manager = browser(service.base);
    assert.equal((await login(manager,"reviewer")).body.workspaceId,scope);
    const pending = readTape((await manager.api(workspace)).body);
    assert.equal(pending.status,"review");
    assert.deepEqual(pending.counts.map(entry => entry.quantity),[0,24]);
    assert.equal((await manager.api(resolveTape,decision(pending.revision,24))).body.status,"closed");
  } finally {
    if (service) await service.stop();
    for (const filename of [db,db+"-shm",db+"-wal"]) await rm(filename,{force:true});
    await rmdir(temp);
  }
});
