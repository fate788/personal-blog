import assert from "node:assert/strict";
import { test } from "node:test";
import { actors, createWorkspace, dispatch } from "../domain.mjs";

const start = Date.UTC(2026, 10, 28, 1);
const target = "a01-tape";

function client(state, actorId) {
  return {
    workspace: () => dispatch(state, { method: "GET", path: "/api/workspace", actorId }),
    count: (opId, quantity, itemId = target, now = start) => dispatch(state, {
      method: "POST", path: "/api/counts", actorId, now, body: { opId, itemId, quantity },
    }),
    resolve: (revision, quantity, note, itemId = target, now = start + 120_000) => dispatch(state, {
      method: "POST", path: `/api/items/${itemId}/resolve`, actorId, now,
      body: { revision, quantity, note },
    }),
  };
}

function selected(view, itemId = target) {
  return view.body.items.find(item => item.id === itemId);
}

test("the three roles share after serialization while blind counters only receive their own observations", () => {
  const state = JSON.parse(JSON.stringify(createWorkspace(start)));
  const first = client(state, actors[0].id);
  const second = client(state, actors[1].id);
  const supervisor = client(state, actors[2].id);
  assert.equal(first.count("a-23", 23).status, 201);
  const own = selected(first.workspace());
  assert.equal(own.counts.length, 1);
  assert.equal(own.counts[0].quantity, 23);
  const before = selected(second.workspace());
  assert.equal(before.counts.length, 0);
  assert.equal("expected" in before, false);
  assert.equal(second.workspace().body.history.some(entry => entry.itemId === target), false);

  assert.equal(second.count("b-24", 24, target, start + 10).body.status, "review");
  const pending = selected(supervisor.workspace());
  assert.equal(pending.expected, 24);
  assert.equal(pending.revision, 2);
  assert.deepEqual(pending.counts.map(entry => entry.quantity), [23, 24]);
  assert.equal("finalQuantity" in selected(first.workspace()), false);
  assert.equal(first.resolve(2, 25, "越权提交。").status, 403);
  assert.equal(supervisor.count("r-no", 44).status, 403);

  const resolution = supervisor.resolve(2, 24, "人工复点确认 24 卷。");
  assert.deepEqual(resolution.body, { itemId: target, revision: 3, status: "closed" });
  const reviewed = selected(supervisor.workspace());
  assert.deepEqual(reviewed.counts.map(entry => entry.quantity), [23, 24]);
  assert.equal(reviewed.decision.note, "人工复点确认 24 卷。");
  assert.equal(reviewed.decision.at, start + 120_000);
  const blindClosed = selected(first.workspace());
  assert.equal(blindClosed.finalQuantity, 24);
  assert.deepEqual(blindClosed.counts.map(entry => entry.quantity), [23]);
  assert.equal("decision" in blindClosed, false);
  assert.deepEqual(supervisor.workspace().body.history.filter(entry => entry.itemId === target).map(entry => entry.type),
    ["closed", "review", "counted", "counted"]);
});

test("replaying an offline operation returns the original receipt and adds no new count or audit event", () => {
  const state = createWorkspace(start);
  const first = client(state, "counter-a");
  const second = client(state, "counter-b");
  const supervisor = client(state, "reviewer");
  const operation = first.count("submit-001", 23);
  second.count("submit-002", 24);
  supervisor.resolve(2, 24, "实际复点为 24 卷。");
  const beforeRetry = JSON.stringify(state);
  const replay = first.count("submit-001", 23, target, start + 1_000_000);
  assert.equal(replay.status, 200);
  assert.deepEqual(replay.body, { ...operation.body, replayed: true });
  assert.equal(first.count("submit-001", 24).body.code, "OPERATION_CONFLICT");
  assert.equal(first.count("submit-001", 23, "a01-wrap").body.code, "OPERATION_CONFLICT");
  assert.equal(second.count("submit-001", 23).body.code, "OPERATION_CONFLICT");
  assert.equal(first.count("submit-003", 24).body.code, "ALREADY_COUNTED");
  assert.equal(supervisor.resolve(2, 25, "旧页面再次复核。").body.code, "STALE_REVISION");
  assert.equal(supervisor.resolve(3, 25, "当前结论也不能覆盖。").body.code, "NOT_PENDING_REVIEW");
  assert.equal(JSON.stringify(state), beforeRetry);
});

test("zero and agreement against expected are valid, agreement against a different baseline needs review", () => {
  const state = createWorkspace(start);
  const first = client(state, "counter-a");
  const second = client(state, "counter-b");
  const supervisor = client(state, "reviewer");
  const marker = "b01-marker";
  first.count("zero-a", 0, marker);
  assert.equal(second.count("zero-b", 0, marker).body.status, "agreed");
  assert.equal(selected(supervisor.workspace(), marker).finalQuantity, 0);
  assert.equal("finalQuantity" in selected(second.workspace(), marker), false);

  first.count("different-a", 30, "a01-carton");
  assert.equal(second.count("different-b", 30, "a01-carton").body.status, "review");
  assert.equal(selected(supervisor.workspace(), "a01-carton").expected, 32);
  const reviewedZero = supervisor.resolve(2, 0, "该位置实际已经移空。", "a01-carton");
  assert.equal(reviewedZero.body.status, "closed");
  assert.equal(selected(second.workspace(), "a01-carton").finalQuantity, 0);
});

test("invalid and unopened actions do not mutate stored history or receipt state", () => {
  const state = createWorkspace(start);
  const first = client(state, "counter-a");
  const supervisor = client(state, "reviewer");
  const immutable = JSON.stringify(state);
  for (const invalid of [-1, 1.5, "4", Infinity, Number.MAX_SAFE_INTEGER + 1, null]) {
    assert.equal(first.count("invalid-quantity", invalid).status, 422);
  }
  assert.equal(first.count("empty item", 3).status, 422);
  assert.equal(first.count("unknown", 3, "definitely-missing").status, 404);
  assert.equal(supervisor.resolve(0, 3, "未开始的商品。").body.code, "NOT_PENDING_REVIEW");
  assert.equal(supervisor.resolve(2, 3, "  ", "b01-cutter").body.code, "INVALID_NOTE");
  assert.equal(supervisor.resolve(2, 3, "字".repeat(501), "b01-cutter").body.code, "INVALID_NOTE");
  assert.equal(client(state, "unknown").workspace().status, 401);
  assert.equal(dispatch(state, { method: "POST", path: "/api/counts", actorId: "counter-a", body: null }).status, 422);
  assert.equal(JSON.stringify(state), immutable);
});

test("a workspace response cannot mutate previously accepted immutable observations", () => {
  const state = createWorkspace(start);
  const first = client(state, "counter-a");
  first.count("immutable-a", 23);
  const view = first.workspace();
  selected(view).counts[0].quantity = 88;
  view.body.locations[0].name = "no";
  assert.equal(selected(first.workspace()).counts[0].quantity, 23);
  assert.notEqual(first.workspace().body.locations[0].name, "no");
});
