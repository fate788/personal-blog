export const edition=document.documentElement.dataset.edition || "server";
const name="warehouse-count-"+edition;
const objectStore="records";

const database=new Promise((resolve,reject)=>{
  try{
    const opening=indexedDB.open(name,1);
    opening.onupgradeneeded=()=>opening.result.createObjectStore(objectStore);
    opening.onsuccess=()=>resolve(opening.result);
    opening.onerror=()=>reject(opening.error || new Error("无法打开浏览器离线存储。"));
    opening.onblocked=()=>reject(new Error("另一页面正在使用旧版离线存储。"));
  }catch(error){reject(error);}
});

export async function storage(key,update) {
  const db=await database;
  return new Promise((resolve,reject)=>{
    const tx=db.transaction(objectStore,update?"readwrite":"readonly");
    const store=tx.objectStore(objectStore);
    const reading=store.get(key);
    let value,failure;
    reading.onsuccess=()=>{
      try{
        value=update?update(reading.result):reading.result;
        if(update)store.put(value,key);
      }catch(error){failure=error;tx.abort();}
    };
    tx.oncomplete=()=>resolve(value);
    tx.onabort=()=>reject(failure || tx.error || new Error("无法保存浏览器中的盘点记录。"));
  });
}
