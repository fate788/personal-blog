import request from "./transport.mjs";
import {storage} from "./storage.mjs";

const noWorkspace={actor:null, locations:[], items:[], history:[]};
const blankSession={mode:"demo",actor:null,actors:[],workspaceId:null};
const keyFor=session=>[session.workspaceId,session.actor.id].join(":");
const transportError=error=>error.status===undefined || error.status>=500;
function queueError(error){
  return error?.message || "操作未完成，请稍后重试。";
}

export async function openInventory(){
  let session=blankSession, workspace=noWorkspace, pending=[], forcedOffline=false, unavailable=false;
  let syncing=false, error="", inFlight=null, mapping=false;
  const listeners=new Set();
  const snapshot=()=>({session,workspace,pending,offline:forcedOffline||!navigator.onLine||unavailable,
    forcedOffline,syncing,error});
  const notify=()=>{for(const listener of listeners)listener(snapshot());};
  if("serviceWorker" in navigator && /^https?:$/u.test(location.protocol))
    navigator.serviceWorker.register("./sw.js").catch(()=>{});

  async function applySession(next){
    const old=session.actor ? keyFor(session) : "";
    const key=next.actor ? keyFor(next) : "";
    if(old!==key || !key)workspace=noWorkspace;
    session=next;
    await storage("session",()=>next.mode==="team"&&!next.actor?{...next,workspaceId:null}:next);
    if(!key){pending=[];notify();return;}
    const [cached,queue]=await Promise.all([storage("workspace:"+key),storage("queue:"+key)]);
    workspace=cached || noWorkspace;
    pending=queue || [];
    notify();
  }

  async function load(){
    if(!session.actor)return;
    const current=session,key=keyFor(current);
    const cached=await request("/api/workspace",{session:current});
    if(session!==current)return;
    workspace=cached;
    await storage("workspace:"+key,()=>cached);
    notify();
  }

  async function refresh(){
    if(mapping || forcedOffline || !navigator.onLine)return snapshot();
    mapping=true;
    try {
      const next=await request("/api/session");
      await applySession(next);
      unavailable=false;
      await load();
      error="";
    } catch(fault){
      unavailable=transportError(fault);
      error=queueError(fault);
    } finally {
      mapping=false;
      notify();
    }
    return snapshot();
  }

  async function patchQueue(key,apply){
    const updated=await storage("queue:"+key,queue=>apply(queue || []));
    if(session.actor && key===keyFor(session))pending=updated;
    notify();
    return updated;
  }

  async function deliver(){
    if(!session.actor || mapping || forcedOffline || !navigator.onLine)return {sent:0,failed:0};
    let sent=0,failed=0;
    const current=session,key=keyFor(current);
    syncing=true;error="";notify();
    try{
      // Each acknowledged entry is removed only after the server commits it.
      const attempted=new Set();
      for(;;){
        if(!session.actor || key!==keyFor(session) || forcedOffline || !navigator.onLine)break;
        const operation=(await storage("queue:"+key) || []).find(entry=>!entry.error && !attempted.has(entry.opId));
        if(!operation)break;
        attempted.add(operation.opId);
        const {opId,itemId,quantity}=operation;
        try{
          await request("/api/counts",{method:"POST",session:current,body:{opId,itemId,quantity}});
          await patchQueue(key,queue=>queue.filter(entry=>entry.opId!==opId));
          unavailable=false;
          sent++;
        }catch(fault){
          failed++;
          error=queueError(fault);
          if(transportError(fault)){unavailable=true;break;}
          if(fault.status===401 || fault.status===403 || ["SESSION_CHANGED","SESSION_SCOPE_CHANGED"].includes(fault.code)){
            await refresh();
            error=queueError(fault);
            break;
          }
          await patchQueue(key,queue=>queue.map(entry=>entry.opId===opId?{...entry,error}:entry));
        }
      }
      if(!forcedOffline && navigator.onLine && !unavailable)await load();
    }catch(fault){
      error=queueError(fault);
      unavailable=transportError(fault);
    } finally {
      syncing=false;notify();
    }
    return {sent,failed};
  }

  function sync(){
    if(!inFlight)inFlight=(async()=>{
      if(unavailable)await refresh();
      return deliver();
    })().finally(()=>{inFlight=null;});
    return inFlight;
  }
  async function saveCount(itemId,quantity){
    const actor=session.actor;
    if(actor?.role!=="counter" || mapping)throw new Error("当前身份不能记录数量。");
    if(!workspace.items.some(item=>item.id===itemId && item.status==="open" && !item.counts.length))
      throw new Error("这项货品已登记或未分配给当前工作台。");
    if(!Number.isSafeInteger(quantity)||quantity<0)throw new Error("请输入 0 或正整数。");
    const key=keyFor(session);
    const entry={opId:crypto.randomUUID(),itemId,quantity,actorId:actor.id,at:Date.now()};
    await patchQueue(key,queue=>{
      if(queue.some(item=>item.itemId===itemId))throw new Error("该货品已有本地记录，请先处理同步队列。");
      return [...queue,entry];
    });
    if(!snapshot().offline)void sync();
    return entry;
  }
  async function setOffline(value){
    if(session.mode!=="demo")throw new Error("仅演练提供网络开关。");
    forcedOffline=Boolean(value);
    await storage("forced-offline",()=>forcedOffline);
    notify();
    if(!forcedOffline){
      await refresh();
      return sync();
    }
    return {sent:0,failed:0};
  }
  async function changeIdentity(path,body){
    if(mapping || forcedOffline || !navigator.onLine)throw new Error("连接后才能切换身份。");
    mapping=true;
    try {
      if(inFlight)await inFlight;
      const next=await request(path,{method:"POST",body});
      await applySession(next);
      unavailable=false;
      error="";
      try {await load();}
      catch(fault){unavailable=transportError(fault);error=queueError(fault);}
    } finally {mapping=false;notify();}
    if(session.actor)void sync();
    return session;
  }
  async function resolve(itemId,body){
    if(snapshot().offline || mapping)throw new Error("复核需要连接服务器。");
    const current=session;
    const result=await request("/api/items/"+encodeURIComponent(itemId)+"/resolve",{method:"POST",session:current,body});
    await load();
    return result;
  }
  async function discardRejected(opId){
    if(!session.actor)throw new Error("请登录原账号处理本地记录。");
    await patchQueue(keyFor(session),queue=>queue.filter(entry=>entry.opId!==opId || !entry.error));
  }
  async function connectionChanged(){
    if(navigator.onLine && !forcedOffline)await refresh();
    notify();
    if(!snapshot().offline)void sync();
  }
  window.addEventListener("online",()=>void connectionChanged());
  window.addEventListener("offline",notify);
  const [cached,savedDisconnection]=await Promise.all([storage("session"),storage("forced-offline")]);
  forcedOffline=Boolean(savedDisconnection);
  if(cached)await applySession(cached);
  if(!cached || !forcedOffline)await refresh();
  if(!snapshot().offline && pending.length)void sync();
  return {
    get snapshot(){return snapshot();},
    subscribe(listener){listeners.add(listener);return ()=>listeners.delete(listener);},
    saveCount,sync,setOffline,refresh,resolve,discardRejected,
    switchRole:id=>changeIdentity("/api/session/role",{id}),
    login:(id,password)=>changeIdentity("/api/login",{id,password}),
    logout:()=>changeIdentity("/api/logout",{}),
  };
}
