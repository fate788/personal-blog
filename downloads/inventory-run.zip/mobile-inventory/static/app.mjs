import {openInventory} from "./offline.mjs";

const main = document.querySelector("#inventory-main");
const toolbar = document.querySelector("#toolbar");
const navigation = document.querySelector("#navigation");
const dialog = document.querySelector("#work-dialog");
const formContent = document.querySelector("#form-content");
const notice = document.querySelector("#notice");
const routes = {
  count:["盘点任务","box"], queue:["同步队列","sync"],
  review:["差异复核","clipboard"], history:["作业记录","clock"],
};
const stateLabels = {
  open:"待盘点", local:"待同步", counted:"已提交", agreed:"两次一致", review:"待复核", closed:"已结案",
};
const eventLabels = {
  counted:"提交实点", agreed:"两次一致", review:"进入差异复核", closed:"主管确认结案",
};
const paths = {
  box:"M4 7l8-4 8 4v10l-8 4-8-4zM4 7l8 4 8-4m-8 4v10m-4-16 8 4",
  pin:"M19 10c0 4.5-7 10-7 10S5 14.5 5 10a7 7 0 1 1 14 0zm-4 0a3 3 0 1 1-6 0 3 3 0 0 1 6 0z",
  clipboard:"M8 4h8v4H8zM8 6H5v15h14V6h-3M8 13h8m-8 4h5",
  sync:"M19 8a8 8 0 0 0-14-1L3 9m0-5v5h5m-3 7a8 8 0 0 0 14 1l2-2m0 5v-5h-5",
  clock:"M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0zm-9-5v5l3 2",
  user:"M16 8a4 4 0 1 1-8 0 4 4 0 0 1 8 0zM4 20a8 8 0 0 1 16 0",
  arrow:"M4 12h15m-5-5 5 5-5 5",
  search:"M16 10a6 6 0 1 1-12 0 6 6 0 0 1 12 0zm-2 4 5 5",
  code:"M4 5h4m-4 0v4m16-4h-4m4 0v4M4 19h4m-4 0v-4m16 4h-4m4 0v-4M8 8v8m3-8v8m3-8v8m2-8v8",
  info:"M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0zm-9 0v4m0-8h.01",
  close:"M6 6l12 12M18 6L6 18",
  check:"M4 12l5 5L20 6",
};
const date = new Intl.DateTimeFormat("zh-CN",{month:"2-digit",day:"2-digit",hour:"2-digit",minute:"2-digit",hourCycle:"h23"});
const number = new Intl.NumberFormat("zh-CN");
let inventory;
let snapshot;
let tab = "count";
let search = "";
let location = "";
let actorBusy = false;
let actionBusy = false;
let notificationTimer;

function esc(value) {
  return String(value??"").replace(/[&<>'"]/gu,char=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[char]);
}
function icon(name) {
  return `<span class="icon" aria-hidden="true"><svg viewBox="0 0 24 24"><path d="${paths[name]}"/></svg></span>`;
}
function time(value) {
  return Number.isFinite(new Date(value).valueOf()) && value!=null ? date.format(new Date(value)) : "—";
}
function qty(value) {
  return Number.isSafeInteger(value) ? number.format(value) : "—";
}
function go(target) {
  if(window.location.hash===target){render();return;}
  window.location.hash=target;
}
function state() {
  return snapshot?.workspace || {items:[],locations:[],history:[]};
}
function actor() {
  return snapshot?.session?.actor;
}
function demo() {
  return snapshot?.session?.mode==="demo";
}
function reviewer() {
  return actor()?.role==="reviewer";
}
function queue() {
  return (snapshot?.pending || []).filter(entry=>entry.actorId===actor()?.id);
}
function findItem(itemId) {
  return state().items.find(item=>item.id===itemId);
}
function findLocation(locationId) {
  return state().locations.find(entry=>entry.id===locationId);
}
function own(item) {
  return item.counts?.find(entry=>entry.actorId===actor()?.id);
}
function ownPending(item) {
  return queue().find(entry=>entry.itemId===item.id);
}
function countState(item) {
  return ownPending(item) ? "local" : own(item) && item.status==="open" ? "counted" : item.status;
}
function labelState(status) {
  const kind={local:"pending",counted:"received",review:"conflict",agreed:"done",closed:"done"}[status] || "";
  return `<span class="tag ${kind}">${esc(stateLabels[status] || status)}</span>`;
}
function link(text,href,styling="",symbol="arrow") {
  return `<a class="btn ${styling}" href="${esc(href)}">${esc(text)}${symbol?icon(symbol):""}</a>`;
}
function button(text,attr,styling="",symbol="") {
  return `<button class="btn ${styling}" type="button" ${attr}>${symbol?icon(symbol):""}${esc(text)}</button>`;
}
function note(text,error=false) {
  return `<p class="notice-inline${error?" error":""}"${error?' role="alert"':""}>${icon("info")}${esc(text)}</p>`;
}
function heading(title,subtitle,actions="") {
  return `<header class="heading"><div><h1>${esc(title)}</h1><p>${esc(subtitle)}</p></div>${actions?`<div class="actions">${actions}</div>`:""}</header>`;
}
function panel(title,subtitle,body,actions="") {
  return `<section class="panel"><header class="panel-head"><div><h2>${esc(title)}</h2>${subtitle?`<p>${esc(subtitle)}</p>`:""}</div>${actions}</header>${body}</section>`;
}
function flash(message) {
  clearTimeout(notificationTimer);
  notice.textContent=message;
  notice.hidden=false;
  notificationTimer=setTimeout(()=>{notice.hidden=true;},3100);
}
function setToolbar() {
  const a=actor();
  const offline=!!snapshot?.offline;
  const network=`<span class="network ${offline?"offline":"online"}" data-network="${offline?"offline":"online"}" role="status">${snapshot?.syncing?"正在同步":offline?"离线模式":"网络可用"}</span>`;
  const sim=demo()?button(snapshot.forcedOffline?"恢复连接":"模拟断网","data-offline","quiet"):"";
  const identity=demo()&&a?`<details class="identity-control"><summary aria-label="切换演示身份，当前${esc(a.name)}">${icon("user")}${esc(a.name)}</summary>
    <div class="identity-options" role="group" aria-label="演示身份">${snapshot.session.actors.map(person=>
      `<button type="button" data-actor="${esc(person.id)}" aria-pressed="${person.id===a.id}" ${snapshot.offline||actorBusy?'disabled':""}>${esc(person.name)} · ${person.role==="reviewer"?"复核":"盘点"}</button>`
    ).join("")}</div></details>`:a?`<span class="operator">${icon("user")}${esc(a.name)}</span>${button("退出","data-logout","quiet")}`:"";
  const opened=toolbar.querySelector(".identity-control")?.open;
  toolbar.innerHTML=network+sim+identity;
  if(opened)toolbar.querySelector(".identity-control")?.setAttribute("open","");
  document.querySelector("#mode").textContent=demo()?"隔离演练工作区":"仓库团队工作区";
}
function setNav() {
  const pending=queue().length;
  const reviews=reviewer()?state().items.filter(item=>item.status==="review").length:0;
  const label=document.querySelector("#breadcrumb");
  label.textContent=actor()?routes[tab][0]:"团队登录";
  navigation.innerHTML=actor()?Object.entries(routes).map(([id,[title,symbol]])=>{
    const amount=id==="queue"?pending:id==="review"?reviews:0;
    return `<a class="rail-link" href="#${id}"${tab===id?' aria-current="page"':""}>${icon(symbol)}${title}
      ${amount?`<span class="nav-count">${qty(amount)}</span>`:""}</a>`;
  }).join(""):"";
}
function loginView() {
  main.innerHTML=`<section class="panel login"><div class="panel-head"><div><h1>登录仓库团队</h1><p>使用主管分配的盘点员或复核账号。</p></div></div>
    <form id="login-form" class="form-grid panel-body" method="post"><label class="field">账号<input name="account" autocomplete="username" required maxlength="90"></label>
      <label class="field">密码<input name="password" type="password" autocomplete="current-password" required maxlength="180"></label>
      <p class="form-error" role="alert" hidden></p><div class="actions"><button class="btn primary" type="submit">登录工作台 ${icon("arrow")}</button></div>
    </form></section>`;
}
function homeHero() {
  const practice=demo()&&!reviewer();
  return `<header class="warehouse-hero"><div class="hero-visual" aria-hidden="true"><img src="./hero.webp" alt="" width="1440" height="960" fetchpriority="high"></div>
    <div class="hero-copy"><h1>库位盘点</h1><p>${reviewer()?"查找库位商品，核对盘点进度和差异。":"按库位确认商品，录入实际清点的数量。"}</p>
    <div class="actions">${button("查找商品","data-focus-lookup","primary","code")}${practice?button("开始离线盘点","data-try-offline","quiet"):""}</div></div></header>`;
}
function metrics() {
  const {items,locations}=state();
  const pending=queue().length;
  const last=reviewer()?[items.filter(item=>item.status==="review").length,"待复核商品"]:
    [items.filter(item=>countState(item)==="open").length,"待盘商品"];
  return `<dl class="panel metric-strip" aria-label="盘点概况">
    <div class="metric">${icon("pin")}<dt>盘点库位</dt><dd><strong>${qty(locations.length)}</strong></dd></div>
    <div class="metric">${icon(reviewer()?"clipboard":"box")}<dt>${last[1]}</dt><dd><strong>${qty(last[0])}</strong></dd></div>
    <div class="metric${pending?" warning":""}">${icon("sync")}<dt>待同步</dt><dd><strong data-pending-count>${qty(pending)}</strong></dd></div></dl>`;
}
function lookup() {
  const picks=state().locations.map(entry=>{
    const code=entry.id.toUpperCase();
    const name=entry.name.startsWith(code+" ")?entry.name.slice(code.length+1):entry.name;
    return `<button class="slot-filter" type="button" data-location="${esc(entry.id)}" aria-label="${esc(entry.name)}" aria-pressed="${entry.id===location}"><b class="mono">${esc(code)}</b><span>${esc(name)}</span></button>`;
  }).join("");
  return `<div class="lookup-body"><label class="lookup">${icon("code")}<span class="sr-only">查找商品</span>
    <input id="lookup" type="search" inputmode="search" autocomplete="off" value="${esc(search)}" placeholder="输入品名、SKU 或条码"></label>
    <div class="slot-filters" role="group" aria-label="按库位筛选"><button class="slot-filter all-slots" type="button" data-location="" aria-pressed="${!location}">${icon("pin")}全部库位</button>${picks}</div></div>`;
}
function matchingItems() {
  const match=search.trim().toLocaleLowerCase();
  return state().items.filter(item=>(!location||item.locationId===location)&&
    (!match||[item.name,item.sku,item.barcode].some(text=>String(text).toLocaleLowerCase().includes(match))));
}
function itemMarkup(items) {
  if(!items.length)return '<p class="state-text">没有匹配的商品。请检查品名、SKU 或条码。</p>';
  return items.map(item=>{
    const status=countState(item);
    const place=findLocation(item.locationId);
    const pending=ownPending(item);
    const saved=own(item);
    const count=pending||saved;
    const detail=count?` · ${qty(count.quantity)} ${esc(item.unit)}`:"";
    return `<button class="row inventory-row" type="button" data-item="${esc(item.id)}" data-count-state="${status}">
      <span class="row-mark${pending?" amber":""}">${icon("box")}</span><span class="row-copy"><strong>${esc(item.name)}</strong>
      <small>${esc(place?.name || item.locationId)} <span aria-hidden="true">·</span> <span class="mono">${esc(item.sku)}</span>${detail}</small></span>
      ${labelState(status)}<span class="row-arrow">${icon("arrow")}</span></button>`;
  }).join("");
}
function updateItemList() {
  const items=matchingItems();
  main.querySelector("#filter-count").textContent=`${qty(items.length)} 项`;
  main.querySelector("#item-list").innerHTML=itemMarkup(items);
}
function scanGuide() {
  const message=snapshot.offline?"当前离线，新记录会先保存在这台设备。":
    "连接中断时照常录入，待发送的记录可在同步队列查看。";
  return `<aside class="panel scan-guide"><img src="./scan-station.webp" alt="在包装台用手持扫码枪读取纸箱条码" width="720" height="480">
    <div class="panel-body"><h2>现场扫码</h2><p>点商品输入框后，用扫码枪读取条码，也可以手动输入。唯一匹配时按回车打开盘点。</p>
    <div class="guide-status">${icon("sync")}<p>${message}</p></div>${link("打开同步队列","#queue","full")}</div></aside>`;
}
function support() {
  const pending=queue().length;
  const network=snapshot.offline?"记录会先保存在这台设备。恢复连接后会自动补传。":
    pending?"待同步记录已保存在这台设备，可手动尝试补传。":"提交的原始数量随作业记录保留。盘点结果不一致时，由主管复核。";
  const blind=reviewer()?"复核时会同时看到两位盘点员的报数、账面数量和结案理由。":
    "盘点时只会显示自己的记录。两位盘点员各自报数后，系统再判断是否需要主管复核。";
  return `<div class="content-stack">
    ${panel("同步状态","",`<div class="panel-body"><p>${network}</p>${link("打开同步队列","#queue","full")}</div>`)}
    ${panel("独立盘点","",`<div class="panel-body"><p>${blind}</p>${link("查看复核入口","#review","full")}</div>`)}</div>`;
}
function renderCounts() {
  const items=matchingItems();
  main.innerHTML=homeHero()+metrics()+`<div class="content-grid count-grid"><section class="panel task-panel">
    <header class="panel-head"><h2>库位商品</h2><span class="result-count" id="filter-count" role="status">${qty(items.length)} 项</span></header>
    ${lookup()}<div id="item-list" class="list">${itemMarkup(items)}</div></section>${scanGuide()}</div>`;
}
function renderQueue() {
  const pending=queue();
  const safeRows=pending.map(entry=>{
    const item=findItem(entry.itemId);
    const failed=entry.error?.message || entry.error;
    return `<li><div class="row" data-queue-item="${esc(entry.itemId)}"><span class="row-mark amber">${icon(failed?"info":"sync")}</span>
      <span class="row-copy"><strong>${esc(item?.name || entry.itemId)}</strong>
        <small>${qty(entry.quantity)} ${esc(item?.unit || "")} · ${time(entry.at)}${failed?` · ${esc(failed)}`:""}</small></span>
      <span class="tag ${failed?"conflict":"pending"}">${failed?"未被接收":"待发送"}</span>
      ${failed?button("处理",`data-queue-review="${esc(entry.opId)}"`,"quiet"):""}</div></li>`;
  }).join("");
  main.innerHTML=heading("同步队列","保存到本机的记录会在连接可用时补传。",
    button(snapshot.syncing?"正在同步":"立即同步",`data-sync ${snapshot.forcedOffline||!navigator.onLine||snapshot.syncing||!pending.some(entry=>!entry.error)?"disabled":""}`,"primary","sync"))+
    (snapshot.offline?note("当前离线。已保存的盘点可在关闭工作台或重新打开后继续同步。"):"")+
    `<div class="content-grid">${panel("本机待发送",`${qty(pending.length)} 条记录`,safeRows?
      `<ul class="list">${safeRows}</ul>`:'<p class="state-text">没有待同步记录。新的离线盘点会出现在这里。</p>')}${support()}</div>`;
}
function compareValue(value,unit) {
  return value==null?"—":`${qty(value)} <small>${esc(unit)}</small>`;
}
function compare(item) {
  const counted=item.counts || [];
  const originalCounts=["第一位盘点员","第二位盘点员"].map((fallback,index)=>{
    const value=counted[index]?.quantity;
    const delta=value!=null&&item.expected!=null?value-item.expected:0;
    return `<div class="${delta?"has-difference":""}"><dt>${esc(counted[index]?.actorName || fallback)}</dt><dd>${compareValue(value,item.unit)}
      ${delta?`<span class="difference">${delta>0?"多":"少"} ${qty(Math.abs(delta))} ${esc(item.unit)}</span>`:""}</dd></div>`;
  });
  return `<dl class="compare-grid"><div><dt>账面数量</dt><dd>${compareValue(item.expected,item.unit)}</dd></div>${originalCounts.join("")}</dl>`;
}
function reviewRows(items,closed=false) {
  if(!items.length)return `<p class="state-text">${closed?"还没有已复核的商品。":"当前没有待复核的盘点差异。"}</p>`;
  return items.map(item=>{
    const place=findLocation(item.locationId);
    return `<button type="button" class="row inventory-row" data-review-item="${esc(item.id)}" data-review-state="${item.status}">
      <span class="row-mark${closed?"":" amber"}">${icon(closed?"check":"clipboard")}</span>
      <span class="row-copy"><strong>${esc(item.name)}</strong><small>${esc(place?.name || item.locationId)} · <span class="mono">${esc(item.sku)}</span>
      ${closed?` · 确认 ${compareValue(item.finalQuantity,item.unit)}`:""}</small></span>
      ${labelState(item.status)}<span class="row-arrow">${icon("arrow")}</span></button>`;
  }).join("");
}
function renderReview() {
  const isReviewer=reviewer();
  const items=state().items;
  const tasks=items.filter(item=>item.status==="review");
  const closed=items.filter(item=>item.status==="closed");
  const switcher=!isReviewer&&demo()&&!snapshot.offline?button("切换到主管",'data-actor="reviewer"',"primary","user"):"";
  const help=isReviewer?"对比账面和两次独立实点，填入最终确认数量和理由。":
    "盘点员可查看进度。主管登录后可以核对原始数量并结案。";
  main.innerHTML=heading("差异复核",help,switcher)+(snapshot.offline?note("当前离线。可以查看最近缓存的任务，恢复连接后才能复核结案。"):"")+
    (isReviewer?`<div class="content-grid"><div class="content-stack">
      ${panel("待复核商品",`${qty(tasks.length)} 项差异待处理`,`<div class="list">${reviewRows(tasks)}</div>`)}
      ${panel("已结案","保留两次原始盘点与最后的复核决定",`<div class="list">${reviewRows(closed,true)}</div>`)}</div>
      ${panel("复核依据","",'<div class="panel-body"><p>主管确认时填写最终数量和理由。若另一位主管已经处理，刷新任务后需重新核对。</p></div>')}</div>`:
      panel("主管复核入口","",'<p class="state-text">完成两次盘点后，差异会送入主管的复核队列。</p>'));
}
function renderHistory() {
  const events=state().history;
  const lines=events.map(event=>{
    const item=findItem(event.itemId);
    return `<li data-history-type="${esc(event.type)}"><div class="row"><span class="row-mark">${icon(event.type==="closed"?"check":"clock")}</span>
      <span class="row-copy"><strong>${esc(eventLabels[event.type] || event.type)} <span class="muted">·</span> ${esc(item?.name || event.itemId)}</strong>
      <small>${esc(event.actorName)} · ${time(event.at)}${event.quantity==null?"":` · ${qty(event.quantity)} ${esc(item?.unit || "")}`}</small>
      ${event.note?`<small class="history-note">${esc(event.note)}</small>`:""}</span></div></li>`;
  }).join("");
  main.innerHTML=heading("作业记录",reviewer()?"查看每件商品从记录实点到主管结案的过程。":"查看本账号已经提交的盘点。")+
    panel("最近作业",`${qty(events.length)} 条记录`,lines?`<ol class="list">${lines}</ol>`:'<p class="state-text">还没有已同步的作业记录。</p>');
}
function render() {
  if(!snapshot)return;
  setToolbar();
  setNav();
  if(!actor()){if(!main.querySelector("#login-form"))loginView();return;}
  if (!state().locations.length) {
    main.innerHTML=heading("库位盘点","需要先在线加载一次盘点数据。")+
      note(snapshot.error || "当前设备还没有缓存的任务。",!!snapshot.error)+
      (snapshot.forcedOffline||!navigator.onLine?"":`<div class="retry">${button("重新加载","data-refresh","primary","sync")}</div>`);
    return;
  }
  const focusLookup=document.activeElement?.id==="lookup";
  const caret=focusLookup?[document.activeElement.selectionStart,document.activeElement.selectionEnd]:null;
  if(tab==="queue")renderQueue();
  else if(tab==="review")renderReview();
  else if(tab==="history")renderHistory();
  else renderCounts();
  if(focusLookup&&tab==="count") {
    const input=main.querySelector("#lookup");
    input?.focus();
    if(input&&caret)input.setSelectionRange(...caret);
  }
  if(snapshot.error)main.insertAdjacentHTML("afterbegin",note(snapshot.error,true));
}
function presentDialog(title,subtitle,body) {
  formContent.innerHTML=`<header class="dialog-head"><div><h2 id="dialog-title">${esc(title)}</h2><p>${esc(subtitle)}</p></div>
    <button class="dialog-close" type="button" aria-label="关闭" data-dialog-close>${icon("close")}</button></header>
    <div class="dialog-body">${body}</div>`;
  if(!dialog.open)dialog.showModal();
  const input=formContent.querySelector("[name=quantity]");
  if(input)input.focus();
}
const closeControl=button("关闭","data-dialog-close","quiet");
function quantityInput(unit,value="") {
  return `<label class="field" for="quantity-field">实点数量（${esc(unit)}）</label>
    <div class="qty-field"><button class="btn" type="button" aria-label="数量减一" data-adjust="-1">−</button>
      <input id="quantity-field" name="quantity" type="number" inputmode="numeric" min="0" step="1" required value="${esc(value)}">
      <button class="btn" type="button" aria-label="数量加一" data-adjust="1">+</button></div>`;
}
function openItem(id) {
  const item=findItem(id);
  if(!item)return;
  if(reviewer()){openReview(id);return;}
  const pending=ownPending(item);
  const saved=own(item);
  const toEdit=!pending&&!saved&&item.status==="open";
  const detail=findLocation(item.locationId)?.name || item.locationId;
  const subtitle=`${detail} · ${item.sku}`;
  if(toEdit) {
    presentDialog(item.name,subtitle,`<form id="count-form" data-for-item="${esc(id)}" class="form-grid">
      <p class="slot-label">${icon("code")}<span class="mono">${esc(item.barcode)}</span></p>
      ${quantityInput(item.unit)}
      <p class="slot-label">${icon("info")}${snapshot.offline?"离线保存，恢复连接后自动补传。":"只填写现场清点结果。提交后保留原始记录。"}</p>
      <p class="form-error" role="alert" hidden></p><div class="actions">${closeControl}<button class="btn primary" type="submit">${snapshot.offline?"保存到本机":"保存盘点记录"} ${icon("arrow")}</button></div></form>`);
    return;
  }
  const count=pending||saved;
  presentDialog(item.name,subtitle,`<div class="form-grid">${labelState(countState(item))}${count?
    `<p class="read-number"><strong>${qty(count.quantity)}</strong> ${esc(item.unit)}</p><p class="slot-label">${time(count.at)} 的实点记录</p>`:
    '<p class="state-text">该商品已结束盘点。</p>'}
    ${item.finalQuantity!=null?`<p>主管确认 ${compareValue(item.finalQuantity,item.unit)}</p>`:""}
    <div class="actions">${closeControl}</div></div>`);
}
function openReview(id) {
  const item=findItem(id);
  if(!reviewer()||!item)return;
  const subtitle=`${findLocation(item.locationId)?.name || item.locationId} · ${item.sku}`;
  const comparison=compare(item);
  if(item.status==="review"&&!snapshot.offline) {
    presentDialog(item.name,subtitle,comparison+`<form id="review-form" data-for-item="${esc(id)}" data-revision="${esc(item.revision)}" class="form-grid">
      ${quantityInput(item.unit)}
      <label class="field">复核理由<textarea name="note" required maxlength="500" placeholder="填写复点或现场核对依据"></textarea></label>
      <p class="form-error" role="alert" hidden></p><div class="actions">${closeControl}<button class="btn primary" type="submit">确认结案 ${icon("check")}</button></div></form>`);
    const label=formContent.querySelector('label[for="quantity-field"]');
    label.textContent=`最终确认数量（${item.unit}）`;
  } else {
    presentDialog(item.name,subtitle,`${comparison}<div class="form-grid">${labelState(item.status)}
      ${item.decision?`<p>确认 ${compareValue(item.decision.quantity,item.unit)} · ${esc(item.decision.actorName)}</p><p>${esc(item.decision.note)}</p>`:""}
      ${item.status==="review"?note("离线时仅可查看。恢复连接后才能完成复核。"):""}<div class="actions">${closeControl}</div></div>`);
  }
}
function openRejected(opId) {
  const entry=queue().find(candidate=>candidate.opId===opId && candidate.error);
  if(!entry)return;
  const item=findItem(entry.itemId);
  presentDialog("处理未接收记录",item?.name || entry.itemId,`<div class="form-grid">
    <p>本地实点 ${qty(entry.quantity)} ${esc(item?.unit || "")} · ${time(entry.at)}</p>
    ${note(entry.error.message || entry.error,true)}
    <p>移出队列会删除本机的这一份待传记录。已同步的作业记录仍可在历史中查看。</p>
    <div class="actions">${closeControl}${button("移出队列",`data-remove-rejected="${esc(opId)}"`,"primary")}</div></div>`);
}
function formError(form,error) {
  const output=form.querySelector(".form-error");
  output.textContent=error?.message || String(error);
  output.hidden=false;
}
async function onForm(event) {
  const form=event.target;
  if(!["login-form","count-form","review-form"].includes(form.id))return;
  event.preventDefault();
  const submit=form.querySelector('[type="submit"]');
  if(submit.disabled)return;
  submit.disabled=true;
  const fields=new FormData(form);
  try {
    if(form.id==="login-form") {
      await inventory.login(fields.get("account"),fields.get("password"));
      go(actor()?.role==="reviewer"?"#review":"#count");
      return;
    }
    const quantity=Number(fields.get("quantity"));
    if(fields.get("quantity")==="" || !Number.isSafeInteger(quantity) || quantity<0)
      throw new Error("请输入 0 或正整数。");
    if(form.id==="count-form") {
      await inventory.saveCount(form.dataset.forItem,quantity);
      flash(snapshot.offline?"已保存到这台设备，等待同步。":"盘点已保存，正在检查同步状态。");
    } else {
      const noteText=fields.get("note").trim();
      if(!noteText)throw new Error("请填写复核理由。");
      await inventory.resolve(form.dataset.forItem,{revision:Number(form.dataset.revision),quantity,note:noteText});
      flash("差异已确认结案，原始盘点记录已保留。");
    }
    dialog.close();
    render();
    main.focus({preventScroll:true});
  } catch(error) {
    formError(form,error);
  } finally {
    submit.disabled=false;
  }
}
async function operate(control) {
  if(actionBusy)return;
  actionBusy=true;
  control.disabled=true;
  try {
    if(control.matches("[data-offline]")) {
      const joining=snapshot.forcedOffline;
      await inventory.setOffline(!joining);
      flash(joining?"模拟连接已恢复。":"模拟断网已开启，可继续盘点。");
    } else if(control.matches("[data-sync]")) {
      const result=await inventory.sync();
      flash(result.failed?`已补传 ${result.sent} 条，${result.failed} 条需要检查。`:`已补传 ${result.sent} 条记录。`);
    } else if(control.matches("[data-try-offline]")) {
      const item=findItem("a01-tape");
      if(!item)return;
      if(own(item)||ownPending(item)||item.status!=="open"){openItem(item.id);return;}
      if(!snapshot.offline)await inventory.setOffline(true);
      openItem(item.id);
    } else if(control.matches("[data-logout]")) {
      await inventory.logout();
      go("#count");
    } else if(control.matches("[data-refresh]")) {
      await inventory.refresh();
    } else if(control.matches("[data-remove-rejected]")) {
      await inventory.discardRejected(control.dataset.removeRejected);
      dialog.close();
      flash("已从本地队列移除。");
    }
  } catch(error) {
    flash(error.message);
  } finally {
    control.disabled=false;
    actionBusy=false;
  }
}
async function changeActor(id) {
  if(actorBusy || actor()?.id===id)return;
  actorBusy=true;
  setToolbar();
  try {
    await inventory.switchRole(id);
    toolbar.querySelector(".identity-control")?.removeAttribute("open");
    go(reviewer()?"#review":"#count");
    flash(`当前演练身份为${actor()?.name}。`);
  } catch(error) {
    flash(error.message);
  } finally {
    actorBusy=false;
    setToolbar();
  }
}
function activeTab() {
  const requested=window.location.hash.slice(1);
  tab=Object.hasOwn(routes,requested)?requested:"count";
}
function onClick(event) {
  const identity=toolbar.querySelector(".identity-control");
  if(identity?.open&&!identity.contains(event.target))identity.open=false;
  const control=event.target.closest("button");
  if(!control||!inventory)return;
  if(control.matches("[data-item]"))openItem(control.dataset.item);
  else if(control.matches("[data-review-item]"))openReview(control.dataset.reviewItem);
  else if(control.matches("[data-queue-review]"))openRejected(control.dataset.queueReview);
  else if(control.matches("[data-dialog-close]"))dialog.close();
  else if(control.matches("[data-adjust]")) {
    const input=formContent.querySelector("[name=quantity]");
    const updated=Math.max(0,Number(input.value || 0)+Number(control.dataset.adjust));
    if(Number.isSafeInteger(updated))input.value=String(updated);
    input.focus();
  } else if(control.matches("[data-location]")) {
    location=control.dataset.location;
    main.querySelectorAll("[data-location]").forEach(option=>option.setAttribute("aria-pressed",option===control));
    updateItemList();
  } else if(control.matches("[data-focus-lookup]")) {
    const input=main.querySelector("#lookup");
    input.focus({preventScroll:true});
    input.scrollIntoView({block:"nearest"});
  } else if(control.matches("[data-actor]"))void changeActor(control.dataset.actor);
  else if(control.matches("[data-offline],[data-sync],[data-try-offline],[data-logout],[data-refresh],[data-remove-rejected]"))void operate(control);
}
document.addEventListener("submit",onForm);
document.addEventListener("click",onClick);
document.addEventListener("input",event=>{
  if(event.target.id!=="lookup")return;
  search=event.target.value;
  updateItemList();
});
document.addEventListener("keydown",event=>{
  if(event.key!=="Enter"||event.target.id!=="lookup")return;
  const matches=main.querySelectorAll("#item-list button");
  if(matches.length===1)openItem(matches[0].dataset.item);
});
window.addEventListener("hashchange",()=>{
  if(dialog.open)dialog.close();
  activeTab();
  render();
  window.scrollTo(0,0);
  main.focus({preventScroll:true});
});
try {
  inventory=await openInventory();
  snapshot=inventory.snapshot;
  activeTab();
  inventory.subscribe(next=>{snapshot=next;render();});
  render();
} catch(error) {
  main.innerHTML=heading("移动盘点工作台","打开工作区时遇到问题。")+
    note(error.message,true)+`<div class="retry">${link("重新加载","./index.html","primary","sync")}</div>`;
} finally {
  main.setAttribute("aria-busy","false");
}
