export default async function request(path,{method="GET",body,session}={}) {
  const headers={Accept:"application/json"};
  if(session?.actor){
    headers["X-Workspace-Id"]=session.workspaceId;
    headers["X-Workspace-Actor"]=session.actor.id;
  }
  const options={method,headers,cache:"no-store",credentials:"same-origin"};
  if(method==="POST"){
    headers["Content-Type"]="application/json";
    headers["X-Workspace-Request"]="1";
    options.body=JSON.stringify(body || {});
  }
  const response=await fetch(path,options);
  const data=await response.json();
  if(!response.ok)throw Object.assign(new Error(data.error || "工作台请求失败。"),{status:response.status,code:data.code});
  return data;
}
