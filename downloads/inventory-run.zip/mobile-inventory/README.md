# 移动盘点工作台

适合仓库按库位盘点。盘点员打开任务，用货号或条码找到商品。断网时，数量先写入手机浏览器的 IndexedDB。重新联网后，每条记录用独立操作编号补传，服务器收到重复操作时返回原回执。两人盲盘后，只要数量不一致或偏离账面，就进入主管复核。

[打开公开演练](https://fate788.github.io/personal-blog/demos/inventory/) · [博客作品页](https://fate788.github.io/personal-blog/projects/inventory/index.html)

![移动盘点工作台实屏](docs/preview.webp)

## 两分钟演练

1. 在仓员甲的工作台，点「开始离线盘点」打开 A01 的「牛皮纸封箱胶带」，记录 23 卷。刷新页面，待同步记录仍在。
2. 点「恢复连接」同步。切到仓员乙，同一货品登记 24 卷。
3. 切到仓库主管，从差异列表打开这项货品。核对 23、24 和账面 24，填写最终盘点数量和复核理由。结案页可以回看两份原始计数及处理记录。

公开演练保存在访客当前浏览器，记录使用虚构库位和商品。浏览器的「模拟断网」暂停补传。要从初始示例再试一遍，可以用新的隐私窗口。服务版在实际网络中断时也可暂存操作，补传时身份与工作区必须和原记录一致。

## 运行

需要 Node.js 22.13 或以上版本，无需安装项目依赖。

```sh
node server.mjs
npm test
npm run build:demo
```

服务默认在 [127.0.0.1:8808](http://127.0.0.1:8808/) 监听。先连网打开工作台并读取任务，再断网工作。HTTPS 或本地回环源可由 Service Worker 缓存页面和静态资源。浏览器支持安装时，可在菜单里添加到主屏幕。待同步记录由 IndexedDB 保存，实际复核需要连接服务器。

团队试用通过 `--team` 启动，三种角色各用独立账号登录，操作写入同一 SQLite 数据库。启动前设置各账号的密码，密码至少 12 个字符。

| 登录账号 | 环境变量 |
| --- | --- |
| `counter-a` | `INVENTORY_COUNTER_A_PASSWORD` |
| `counter-b` | `INVENTORY_COUNTER_B_PASSWORD` |
| `reviewer` | `INVENTORY_REVIEWER_PASSWORD` |

```powershell
$env:INVENTORY_COUNTER_A_PASSWORD = Read-Host "盘点员甲密码" -MaskInput
$env:INVENTORY_COUNTER_B_PASSWORD = Read-Host "盘点员乙密码" -MaskInput
$env:INVENTORY_REVIEWER_PASSWORD = Read-Host "复核员密码" -MaskInput
node server.mjs --team --db data/team.sqlite
```

首版使用内置盘点任务，可在 `domain.mjs` 配置示范账目与库位。团队模式适用于内部流程试用，结案结果记录为本次盘点的最终数量和历史。需要不同设备访问时，可部署在 HTTPS 反向代理后，指定 `--origin https://盘点台域名 --secure-cookie`，代理需传入外部 Host。

## 设计与验收

- 盘点员只看到自己提交的原始数量。主管看到两个原始计数和账面数，结案时提供理由。审核提交带版本号，旧页面无法覆盖后来提交的结论。
- 服务器在 SQLite 的同一事务中保存盘点记录和操作回执。同一操作 ID 可以重试，更换内容后复用 ID 会被拒绝。客户端仅在收到回执后移出队列。
- Service Worker 只缓存应用资源。实时数据在应用内按工作区和账号隔离保存，API 请求会重新发给服务器。

按库位筛选后，可使用键盘输入模式的扫码枪读取条码，也可手动输入。只有一个匹配项时，按回车可直接打开盘点。仓库和扫码工作台照片为生成的场景素材，随安装包离线可用。工作流参考 Dynamics 365 的按库位循环盘点及 Odoo 的条码盘点。[Dynamics 365 循环盘点](https://learn.microsoft.com/en-us/dynamics365/supply-chain/warehousing/cycle-counting) · [Odoo 条码盘点](https://www.odoo.com/documentation/19.0/applications/inventory_and_mrp/barcode/operations/adjustments.html)
