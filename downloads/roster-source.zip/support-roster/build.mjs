import { mkdir, readFile, writeFile } from 'node:fs/promises';
import { dirname, resolve } from 'node:path';

const destination = resolve(process.argv[2] || 'dist/index.html');
const read = async path => (await readFile(new URL(path, import.meta.url), 'utf8')).replaceAll('\r\n', '\n');
const asModule = source => `data:text/javascript;base64,${Buffer.from(source).toString('base64')}`;
const [html, css, app, engine, sample] = await Promise.all([
  read('./static/index.html'), read('./static/styles.css'), read('./static/app.mjs'),
  read('./engine.mjs'), read('./fixtures.mjs'),
]);

function replaceModule(source, path, url) {
  return source.replaceAll(`'${path}'`, `'${url}'`).replaceAll(`"${path}"`, `"${url}"`);
}

const engineModule = asModule(engine);
const dataModule = asModule(replaceModule(sample, './engine.mjs', engineModule));
const appSource = replaceModule(replaceModule(app, '../engine.mjs', engineModule), '../fixtures.mjs', dataModule);
const cssEntry = /<link\b[^>]*href=["'](?:\.\/)?styles\.css["'][^>]*>/iu;
const jsEntry = /<script\b[^>]*src=["'](?:\.\/)?app\.mjs["'][^>]*>\s*<\/script>/iu;
if (!cssEntry.test(html) || !jsEntry.test(html)) throw new Error('找不到排班台的样式或脚本入口。');

const policy = "default-src 'none'; style-src 'unsafe-inline'; script-src data:; img-src data:; connect-src 'none'; base-uri 'none'; form-action 'none'";
const portable = html.replace('<head>', `<head>\n  <meta http-equiv="Content-Security-Policy" content="${policy}">`)
  .replace(cssEntry, () => `<style>\n${css}\n</style>`)
  .replace(jsEntry, () => `<script type="module" src="${asModule(appSource)}"></script>`);

await mkdir(dirname(destination), { recursive: true });
await writeFile(destination, portable, 'utf8');
console.log(`已生成客服排班工作台 ${destination}`);
