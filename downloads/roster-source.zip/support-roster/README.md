# 客服排班工作台

供客服班组长编排一周班表。根据各班次对技能和人数的需求，合并员工请假日期、每周班次上限和已确认的安排。保留无法覆盖的席位，方便补人后重算。

[打开工作台](https://fate788.github.io/personal-blog/demos/roster/index.html?v=1.0) · [查看请假情景](https://fate788.github.io/personal-blog/demos/roster/index.html?v=1.0&case=absence)

![一周排班与晚间班复核](docs/preview.webp)

## 体验路径

1. 打开「常规」样例，查看一周班表和每个人的班次数，选中一个班次确认人员及技能要求。
2. 切到请假情景，查看周日晚间缺口。点开专席员工的可用状态，恢复可用并重算，检查其他已锁定的安排。
3. 下载排班 CSV。可导出当前工作区的 JSON 作为模板，替换人员、技能、日期和需求后重新导入。在线版本在浏览器内处理，导出 JSON 可保存当前工作区。

## 本机使用

需要 Node.js 22 或更新版本，无额外依赖。

```sh
npm test
npm run build
node cli.mjs --demo
node cli.mjs --demo --absence
node cli.mjs --input ./week.json --out ./roster.csv
```

离线界面在 `dist/index.html`，可直接双击打开。CLI 输出包含覆盖情况、分配、缺口和每人的班次数。退出码 `0` 为完整覆盖，`2` 为存在缺口，`1` 为输入或文件错误。CLI 在完整覆盖时写入新 CSV，保留现有文件。

## 导入一周计划

在界面选择「保存计划」可获得示例 JSON。文件上限为 256 KiB，支持 80 位员工和 56 个班次条目。日期使用 `YYYY-MM-DD`，一周从周一开始。班次起止时间使用当天的 `HH:MM`。

| 字段 | 内容 |
| --- | --- |
| `name` / `weekStart` | 计划名称、周一日期 |
| `skills` | 技能的 `id` 与 `name` |
| `staff` | 员工的 `id`、`name`、技能编号 `skills`、周上限 `maxShifts`、不可排日期 `unavailable` |
| `shifts` | 班次的 `id`、`date`、`label`、`start`、`end`、技能编号 `skill`、所需人数 `count` |
| `locks` | 分配的 `shiftId` 与 `staffId`，无锁定时用 `[]` |

## 求解口径

硬约束包括技能、请假日期、同日最多一班、每周上限与已锁定安排。先最大化填补的席位数，再最小化每人班次数平方之和，以避免在相同覆盖下过度集中班次。以最小费用流连接员工、员工日期与班次席位。缺口旁的人员原因基于当前排班。所有样例人物和班次均为虚构。

问题建模参考 [OR-Tools 人员排班说明](https://developers.google.com/optimization/service/scheduling/workforce_scheduling) 和 [最小费用流分配](https://developers.google.com/optimization/flow/assignment_min_cost_flow)。项目使用同一套 JavaScript 求解器驱动浏览器和命令行。
