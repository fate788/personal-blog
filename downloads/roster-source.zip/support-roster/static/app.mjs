import { MAX_INPUT_BYTES, parseRoster, rosterCsv, solveRoster } from '../engine.mjs';
import { DEMO_ABSENCE, DEMO_BASE } from '../fixtures.mjs';

const $ = id => document.getElementById(id);
const absenceCase = new URLSearchParams(location.search).get('case') === 'absence';
const state = { problem: null, result: null, source: '', activeShift: '', activeDay: '', readVersion: 0, editor: null };
const weekdays = ['周一', '周二', '周三', '周四', '周五', '周六', '周日'];
const reasons = {
  skill: '技能不匹配', unavailable: '当天请假', 'same-day': '当天已有班次', 'weekly-limit': '达到周上限', eligible: '当前安排下可用',
};

function node(tag, className, content) {
  const element = document.createElement(tag);
  if (className) element.className = className;
  if (content !== undefined) element.textContent = content;
  return element;
}

function button(className, content) {
  const control = node('button', className, content);
  control.type = 'button';
  return control;
}

function weekDays(start) {
  const monday = new Date(`${start}T00:00:00Z`);
  return weekdays.map((weekday, index) => {
    const date = new Date(monday);
    date.setUTCDate(date.getUTCDate() + index);
    return { date: date.toISOString().slice(0, 10), day: date.getUTCDate(), month: date.getUTCMonth() + 1, weekday, weekend: index > 4 };
  });
}

function shortDate(day) {
  return `${day.month}月${day.day}日`;
}

function notice(message = '', tone = 'success') {
  const region = $('notice');
  region.hidden = !message;
  region.dataset.tone = tone;
  region.textContent = message;
}

function indexPlan() {
  const { problem, result } = state;
  const people = new Map(problem.staff.map(person => [person.id, person]));
  const skills = new Map(problem.skills.map(skill => [skill.id, skill.name]));
  const shifts = new Map(problem.shifts.map(shift => [shift.id, shift]));
  const workloads = new Map(result.workloads.map(load => [load.staffId, load]));
  const gaps = new Map(result.gaps.map(gap => [gap.shiftId, gap]));
  const assignments = new Map(problem.shifts.map(shift => [shift.id, []]));
  const scheduleByPerson = new Map(problem.staff.map(staff => [staff.id, new Set()]));
  for (const assignment of result.assignments) {
    assignments.get(assignment.shiftId).push(assignment);
    scheduleByPerson.get(assignment.staffId).add(shifts.get(assignment.shiftId).date);
  }
  return { people, skills, shifts, workloads, gaps, assignments, scheduleByPerson, days: weekDays(problem.weekStart) };
}

function commit(problem, source, { preferGap = false, resetSelection = false } = {}) {
  const result = solveRoster(problem);
  const previous = problem.shifts.find(shift => shift.id === state.activeShift);
  const firstGap = result.gaps[0]?.shiftId;
  const choice = preferGap && firstGap ? firstGap : resetSelection ? problem.shifts[0].id : previous?.id || '';
  const activeShift = problem.shifts.find(shift => shift.id === choice);
  const days = weekDays(problem.weekStart);
  const knownDay = days.some(day => day.date === state.activeDay);
  state.activeDay = activeShift?.date ?? (knownDay && !resetSelection ? state.activeDay : days[0].date);
  state.activeShift = activeShift?.id ?? '';
  state.problem = problem;
  state.result = result;
  state.source = source;
  render();
}

function renderCoverage(index) {
  const { result, problem, source } = state;
  const { assigned, requested, missing, locked } = result.totals;
  const percent = requested === 0 ? 100 : Math.round(assigned / requested * 100);
  const first = index.days[0];
  const last = index.days.at(-1);
  const year = first.date.slice(0, 4);
  const lastYear = last.date.slice(0, 4);
  const lastLabel = year === lastYear ? shortDate(last) : `${lastYear}年 ${shortDate(last)}`;
  $('week-range').textContent = `${year}年 ${shortDate(first)} – ${lastLabel}`;
  $('assigned-total').textContent = assigned;
  $('needed-total').textContent = requested;
  $('missing-total').textContent = missing;
  $('locked-total').textContent = locked;
  $('coverage').dataset.status = missing ? 'gap' : 'ready';
  $('coverage-status').textContent = missing ? '待补齐' : '已排满';
  $('coverage-progress').setAttribute('aria-valuenow', percent);
  $('coverage-progress').style.setProperty('--fill', `${percent}%`);
  $('coverage-note').textContent = missing ? '仍有空缺席位。可以查看候选限制，并导出含缺口的草案。' : '当前计划已覆盖所有需求。请核对人员安排后导出。';
  $('scenario-name').textContent = problem.name;
  $('scenario-source').textContent = source === 'import' ? '导入计划' : source === 'edited' ? '已编辑' : '样例计划';
  $('scenario-normal').setAttribute('aria-pressed', String(source === 'normal'));
  $('scenario-absence').setAttribute('aria-pressed', String(source === 'absence'));
  const csv = $('export-csv');
  csv.textContent = missing ? '导出缺口草案 CSV ↓' : '导出排班 CSV ↓';
  csv.dataset.draft = String(missing > 0);
  for (const id of ['export-csv', 'solve-roster', 'export-workspace', 'edit-absence']) $(id).disabled = false;
  $('jump-gap').hidden = missing === 0;
}

function renderShift(shift, index) {
  const assigned = index.assignments.get(shift.id);
  const gap = index.gaps.get(shift.id);
  const named = assigned.map(item => index.people.get(item.staffId).name);
  const locked = assigned.some(item => item.locked);
  const control = button('shift');
  control.dataset.shiftId = shift.id;
  control.dataset.gap = String(Boolean(gap));
  control.setAttribute('aria-pressed', String(state.activeShift === shift.id));
  control.setAttribute('aria-controls', 'spotlight');
  const label = `${shift.date} ${shift.label} ${shift.start} 至 ${shift.end}，已排 ${assigned.length} 人，需求 ${shift.count} 人`;
  control.setAttribute('aria-label', label + (gap ? `，缺 ${gap.missing} 人` : '') + (locked ? '，含锁定人员' : ''));
  const ratio = node('span', 'shift-fill', `${assigned.length} / ${shift.count}${gap ? ` · 缺${gap.missing}` : ''}`);
  if (locked) {
    const icon = node('i', 'mini-lock');
    icon.setAttribute('aria-hidden', 'true');
    ratio.append(icon);
  }
  control.append(node('span', 'shift-name', shift.label), node('span', 'shift-time', `${shift.start}–${shift.end}`),
    node('span', 'shift-people', named.join('、') || '暂无人员'), ratio);
  return control;
}

function renderCalendar(index) {
  const byDay = new Map(index.days.map(day => [day.date, []]));
  for (const shift of index.shifts.values()) byDay.get(shift.date).push(shift);
  const currentFocus = document.activeElement?.dataset;
  const controls = [];
  const columns = index.days.map(day => {
    const shifts = byDay.get(day.date).toSorted((first, second) => first.start.localeCompare(second.start) || first.end.localeCompare(second.end));
    const hasGap = shifts.some(shift => index.gaps.has(shift.id));
    const active = state.activeDay === day.date;
    const pick = button('day-select');
    pick.dataset.day = day.date;
    pick.dataset.gap = String(hasGap);
    pick.setAttribute('aria-pressed', String(active));
    pick.setAttribute('aria-label', `${day.weekday} ${shortDate(day)}${hasGap ? ' 有缺口' : ''}`);
    const date = node('time', '', day.day);
    date.dateTime = day.date;
    pick.append(node('span', '', day.weekday), date);
    controls.push(pick);

    const column = node('section', ['day', day.weekend && 'weekend', active && 'selected-day', hasGap && 'has-gap'].filter(Boolean).join(' '));
    const heading = node('h3', 'day-head');
    const time = node('time', 'day-number', `${day.month}/${day.day}`);
    time.dateTime = day.date;
    heading.append(node('span', 'day-weekday', day.weekday), time);
    const groups = node('div', 'day-shifts');
    if (shifts.length) groups.append(...shifts.map(shift => renderShift(shift, index)));
    else groups.append(node('p', 'no-shifts', '无班次'));
    column.append(heading, groups);
    return column;
  });
  $('day-strip').replaceChildren(...controls);
  $('calendar').replaceChildren(...columns);
  if (currentFocus?.day) controls.find(control => control.dataset.day === currentFocus.day)?.focus();
  if (currentFocus?.shiftId) [...$('calendar').querySelectorAll('[data-shift-id]')].find(control => control.dataset.shiftId === currentFocus.shiftId)?.focus();
}

function summarizeCandidates(index, shift, assigned) {
  const gapReasons = index.gaps.get(shift.id)?.reasons;
  const assignedIds = new Set(assigned.map(item => item.staffId));
  if (gapReasons) return gapReasons.filter(entry => !assignedIds.has(entry.staffId));
  return [...index.people.values()].filter(person => !assignedIds.has(person.id)).map(person => {
    let kind = 'eligible';
    if (!person.skills.includes(shift.skill)) kind = 'skill';
    else if (person.unavailable.includes(shift.date)) kind = 'unavailable';
    else if (index.scheduleByPerson.get(person.id).has(shift.date)) kind = 'same-day';
    else if (index.workloads.get(person.id).shifts >= person.maxShifts) kind = 'weekly-limit';
    return { staffId: person.id, kind };
  });
}

function renderAssigned(shift, index, assigned) {
  $('assigned-section').hidden = false;
  $('assigned-count').textContent = `${assigned.length} / ${shift.count}`;
  const activeLock = document.activeElement?.dataset.lockStaff;
  const rows = assigned.map(item => {
    const staff = index.people.get(item.staffId);
    const row = node('div', 'assigned-row');
    const avatar = node('span', 'avatar', [...staff.name][0]);
    avatar.setAttribute('aria-hidden', 'true');
    const lock = button('lock-button', item.locked ? '已锁定 · 解锁' : '锁定');
    lock.dataset.lockStaff = staff.id;
    lock.setAttribute('aria-pressed', String(item.locked));
    lock.setAttribute('aria-label', `${item.locked ? '解除锁定' : '锁定'} ${staff.name}`);
    row.append(avatar, node('strong', 'assigned-name', staff.name), lock);
    return row;
  });
  $('assigned-list').replaceChildren(...(rows.length ? rows : [node('p', 'assigned-empty', '此班次还没有安排人员。')]));
  if (activeLock) [...$('assigned-list').querySelectorAll('[data-lock-staff]')].find(control => control.dataset.lockStaff === activeLock)?.focus();
}

function renderSpotlight(index, openCandidates = false) {
  const shift = index.shifts.get(state.activeShift);
  const hasShift = Boolean(shift);
  $('shift-skill').hidden = !hasShift;
  $('shift-status').hidden = !hasShift;
  $('assigned-section').hidden = !hasShift;
  $('candidate-details').hidden = !hasShift;
  if (!shift) {
    $('shift-title').textContent = '选择班次';
    $('shift-meta').textContent = '从周历中选择有需求的时段。';
    return;
  }

  const gap = index.gaps.get(shift.id);
  const assigned = index.assignments.get(shift.id);
  const day = index.days.find(entry => entry.date === shift.date);
  $('shift-title').textContent = shift.label;
  $('shift-meta').textContent = `${day.weekday} ${shortDate(day)} · ${shift.start}–${shift.end}`;
  $('shift-skill').textContent = `所需技能 · ${index.skills.get(shift.skill)}`;
  const shiftStatus = $('shift-status');
  shiftStatus.textContent = gap ? `还需补 ${gap.missing} 人` : '当前需求已覆盖';
  shiftStatus.dataset.gap = String(Boolean(gap));
  renderAssigned(shift, index, assigned);

  const available = summarizeCandidates(index, shift, assigned);
  const order = ['eligible', 'unavailable', 'same-day', 'weekly-limit', 'skill'];
  const sorted = available.toSorted((left, right) => order.indexOf(left.kind) - order.indexOf(right.kind));
  $('candidate-count').textContent = `${available.length} 人`;
  $('candidate-note').textContent = '以下为当前排班下的情况，调整约束后可重算。';
  const rows = sorted.map(entry => {
    const row = node('li', 'candidate-row');
    const label = node('span', 'reason-chip', reasons[entry.kind]);
    label.dataset.reason = entry.kind;
    row.dataset.staffId = entry.staffId;
    row.append(node('span', '', index.people.get(entry.staffId).name), label);
    return row;
  });
  $('candidate-list').replaceChildren(...(rows.length ? rows : [node('li', 'candidate-row', '没有其他候选人。')]));
  if (openCandidates) $('candidate-details').open = Boolean(gap);
}

function renderPeople(index) {
  const prev = document.activeElement?.dataset.staffId;
  const controls = [...index.people.values()].map(person => {
    const { shifts, cap } = index.workloads.get(person.id);
    const control = button('staff');
    control.dataset.staffId = person.id;
    control.setAttribute('aria-label', `${person.name} 已排 ${shifts} 次，周上限 ${cap} 次，调整请假`);
    const avatar = node('span', 'avatar', [...person.name][0]);
    avatar.setAttribute('aria-hidden', 'true');
    const count = node('span', 'staff-count', `${shifts}/${cap} 班`);
    const bar = node('span', 'load-bar');
    bar.setAttribute('aria-hidden', 'true');
    bar.style.setProperty('--fill', `${cap ? shifts / cap * 100 : 0}%`);
    bar.append(node('span'));
    count.append(bar);
    const skillNames = person.skills.map(id => index.skills.get(id)).join('、') || '未配置技能';
    const note = person.unavailable.length ? `${skillNames} · 请假${person.unavailable.length}天` : skillNames;
    control.append(avatar, node('span', 'staff-name', person.name), count, node('span', 'staff-note', note));
    return control;
  });
  $('team-summary').textContent = `${controls.length} 位员工 · 点击卡片调整可排日期`;
  $('people').replaceChildren(...controls);
  if (prev) controls.find(control => control.dataset.staffId === prev)?.focus();
}

function render() {
  const index = indexPlan();
  renderCoverage(index);
  renderCalendar(index);
  renderSpotlight(index, true);
  renderPeople(index);
}

function selectShift(id, focus = false) {
  const index = indexPlan();
  const shift = index.shifts.get(id);
  if (!shift) return;
  state.activeShift = id;
  state.activeDay = shift.date;
  renderCalendar(index);
  renderSpotlight(index, true);
  if (focus || matchMedia('(max-width: 920px)').matches) $('shift-title').focus();
}

function selectDay(date) {
  const index = indexPlan();
  if (!index.days.some(day => day.date === date)) return;
  const shifts = [...index.shifts.values()].filter(shift => shift.date === date);
  state.activeDay = date;
  state.activeShift = (shifts.find(shift => index.gaps.has(shift.id)) ?? shifts[0])?.id || '';
  renderCalendar(index);
  renderSpotlight(index, true);
}

function loadSample(key, showNotice = true) {
  state.readVersion += 1;
  commit(structuredClone(key === 'absence' ? DEMO_ABSENCE : DEMO_BASE), key, { preferGap: key === 'absence', resetSelection: true });
  if (showNotice) notice();
}

function toggleLock(staffId) {
  const shiftId = state.activeShift;
  const current = state.result.assignments.find(item => item.shiftId === shiftId && item.staffId === staffId);
  if (!current) return;
  const revised = structuredClone(state.problem);
  revised.locks = current.locked ? revised.locks.filter(lock => lock.shiftId !== shiftId || lock.staffId !== staffId)
    : [...revised.locks, { shiftId, staffId }];
  try {
    commit(revised, 'edited');
    notice(current.locked ? '已解除锁定并重新求解。' : '已锁定此安排。后续重新求解会保留这个席位。');
  } catch (error) {
    notice(error.message, 'error');
  }
}

function createOptions(container, values, selected, toId, create) {
  const previouslyFocused = document.activeElement;
  const controls = values.map(value => {
    const control = create(value);
    control.setAttribute('aria-pressed', String(selected === toId(value)));
    return control;
  });
  const focusedIndex = [...container.children].indexOf(previouslyFocused);
  const scrollTop = container.scrollTop;
  container.replaceChildren(...controls);
  container.scrollTop = scrollTop;
  if (focusedIndex >= 0) controls[focusedIndex]?.focus();
}

function renderAbsenceEditor() {
  const editor = state.editor;
  const staff = state.problem.staff.find(person => person.id === editor.staffId);
  createOptions($('absence-staff'), state.problem.staff, editor.staffId, person => person.id, person => {
    const control = button('', person.name);
    control.dataset.absenceStaff = person.id;
    return control;
  });
  createOptions($('absence-date'), weekDays(state.problem.weekStart), editor.date, day => day.date, day => {
    const control = button('');
    control.dataset.absenceDate = day.date;
    control.setAttribute('aria-label', `${day.weekday} ${shortDate(day)}`);
    const date = node('time', '', `${day.month}/${day.day}`);
    date.dateTime = day.date;
    control.append(node('span', '', day.weekday), date);
    return control;
  });
  $('absence-unavailable').checked = staff.unavailable.includes(editor.date);
  $('absence-error').hidden = true;
}

function openAbsence(staffId = state.problem.staff[0].id) {
  state.editor = { staffId, date: state.activeDay || state.problem.weekStart };
  renderAbsenceEditor();
  $('absence-dialog').showModal();
}

function applyAbsence(event) {
  event.preventDefault();
  const { staffId, date } = state.editor;
  const updated = structuredClone(state.problem);
  const staff = updated.staff.find(person => person.id === staffId);
  const wasAbsent = staff.unavailable.includes(date);
  const isAbsent = $('absence-unavailable').checked;
  if (wasAbsent === isAbsent) {
    $('absence-dialog').close();
    return;
  }
  staff.unavailable = isAbsent ? [...staff.unavailable, date].sort() : staff.unavailable.filter(day => day !== date);
  try {
    const pinned = updated.locks.some(lock => lock.staffId === staffId && updated.shifts.find(shift => shift.id === lock.shiftId).date === date);
    if (isAbsent && pinned) throw new Error(`${staff.name}当天有已锁定班次。请先解除该席位的锁定，再调整请假。`);
    commit(updated, 'edited');
    $('absence-dialog').close();
    notice(isAbsent ? `已登记${staff.name}的请假并重新求解。` : `已恢复${staff.name}的可排日期并重新求解。`);
  } catch (error) {
    $('absence-error').textContent = error.message;
    $('absence-error').hidden = false;
  }
}

async function importPlan() {
  const input = $('import-workspace');
  const file = input.files[0];
  input.value = '';
  if (!file) return;
  const version = ++state.readVersion;
  try {
    if (file.size > MAX_INPUT_BYTES) throw new Error('文件超过 256 KiB，请导入更小的计划。');
    const bytes = await file.arrayBuffer();
    if (version !== state.readVersion) return;
    let text;
    try { text = new TextDecoder('utf-8', { fatal: true }).decode(bytes); }
    catch { throw new Error('请上传使用 UTF-8 编码的 JSON 计划。'); }
    const problem = parseRoster(text);
    commit(problem, 'import', { preferGap: true, resetSelection: true });
    notice(`已导入 ${file.name} 并生成排班。`);
  } catch (error) {
    if (version === state.readVersion) notice(error.message || '读取计划失败。', 'error');
  }
}

function download(contents, mime, filename) {
  const url = URL.createObjectURL(new Blob([contents], { type: mime }));
  const link = node('a');
  link.href = url;
  link.download = filename;
  document.body.append(link);
  link.click();
  link.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

$('scenario-normal').addEventListener('click', () => loadSample('normal'));
$('scenario-absence').addEventListener('click', () => loadSample('absence'));
$('solve-roster').addEventListener('click', () => {
  try {
    commit(state.problem, state.source);
    notice('已按当前技能、请假和锁定席位重新求解。');
  } catch (error) {
    notice(error.message, 'error');
  }
});
$('pick-workspace').addEventListener('click', () => $('import-workspace').click());
$('import-workspace').addEventListener('change', importPlan);
$('export-workspace').addEventListener('click', () => {
  download(`${JSON.stringify(state.problem, null, 2)}\n`, 'application/json;charset=utf-8', `排班计划-${state.problem.weekStart}.json`);
  notice('已保存计划 JSON，可重新导入或作为编辑模板。');
});
$('export-csv').addEventListener('click', () => {
  try {
    const draft = state.result.totals.missing > 0;
    const name = draft ? '缺口草案' : '排班结果';
    download(rosterCsv(state.problem, state.result), 'text/csv;charset=utf-8', `${name}-${state.problem.weekStart}.csv`);
    notice(draft ? '已导出含空缺席位的草案。' : '已导出完整排班 CSV。');
  } catch (error) {
    notice(error.message, 'error');
  }
});
$('jump-gap').addEventListener('click', () => {
  const gaps = state.result.gaps;
  const current = gaps.findIndex(gap => gap.shiftId === state.activeShift);
  selectShift(gaps[(current + 1) % gaps.length].shiftId, true);
});
$('calendar').addEventListener('click', event => {
  const control = event.target.closest('[data-shift-id]');
  if (control) selectShift(control.dataset.shiftId);
});
$('day-strip').addEventListener('click', event => {
  const control = event.target.closest('[data-day]');
  if (control) selectDay(control.dataset.day);
});
$('assigned-list').addEventListener('click', event => {
  const control = event.target.closest('[data-lock-staff]');
  if (control) toggleLock(control.dataset.lockStaff);
});
$('edit-absence').addEventListener('click', () => openAbsence());
$('people').addEventListener('click', event => {
  const control = event.target.closest('[data-staff-id]');
  if (control) openAbsence(control.dataset.staffId);
});
for (const id of ['close-absence', 'cancel-absence']) $(id).addEventListener('click', () => $('absence-dialog').close());
$('absence-form').addEventListener('submit', applyAbsence);
$('absence-staff').addEventListener('click', event => {
  const control = event.target.closest('[data-absence-staff]');
  if (control) {
    state.editor.staffId = control.dataset.absenceStaff;
    renderAbsenceEditor();
  }
});
$('absence-date').addEventListener('click', event => {
  const control = event.target.closest('[data-absence-date]');
  if (control) {
    state.editor.date = control.dataset.absenceDate;
    renderAbsenceEditor();
  }
});

try {
  loadSample(absenceCase ? 'absence' : 'normal', false);
} catch (error) {
  notice(error.message, 'error');
}
