const dates = [
  '2026-11-30', '2026-12-01', '2026-12-02', '2026-12-03', '2026-12-04', '2026-12-05', '2026-12-06',
];

const teams = [
  { id: 'general', name: '在线客服' },
  { id: 'escalation', name: '售后升级' },
];

const staff = [
  { id: 's01', name: '许嘉宁', skills: ['general'], maxShifts: 4, unavailable: [dates[3]] },
  { id: 's02', name: '林以晴', skills: ['general'], maxShifts: 4, unavailable: [dates[1], dates[6]] },
  { id: 's03', name: '孟予安', skills: ['general'], maxShifts: 4, unavailable: [dates[2]] },
  { id: 's04', name: '周启航', skills: ['general'], maxShifts: 4, unavailable: [dates[0], dates[5]] },
  { id: 's05', name: '陈知夏', skills: ['general'], maxShifts: 4, unavailable: [dates[4]] },
  { id: 's06', name: '赵书言', skills: ['general', 'escalation'], maxShifts: 4, unavailable: [dates[5], dates[6]] },
  { id: 's07', name: '唐亦可', skills: ['general', 'escalation'], maxShifts: 4, unavailable: [dates[0], dates[6]] },
  { id: 's08', name: '沈映之', skills: ['escalation'], maxShifts: 4, unavailable: [dates[1]] },
];

const shifts = dates.flatMap((date, index) => [
  { id: `d${index + 1}-day`, date, label: '日间班', start: '09:00', end: '17:00', skill: 'general', count: 2 },
  { id: `d${index + 1}-late`, date, label: '晚间班', start: '14:00', end: '22:00', skill: 'escalation', count: 1 },
]);

export const DEMO_BASE = {
  name: '双十二售前支持', weekStart: dates[0], skills: teams, staff, shifts,
  locks: [{ shiftId: 'd1-day', staffId: 's01' }],
};

export const DEMO_ABSENCE = {
  ...structuredClone(DEMO_BASE),
  name: '周日专席临时请假',
  staff: staff.map(person => person.id === 's08'
    ? { ...structuredClone(person), unavailable: [...person.unavailable, dates[6]] }
    : structuredClone(person)),
};
