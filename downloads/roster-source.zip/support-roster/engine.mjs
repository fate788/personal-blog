export const MAX_INPUT_BYTES = 262_144;
const DAY_MS = 86_400_000;
const MAX_STAFF = 80;
const MAX_SHIFTS = 56;
const MAX_SKILLS = 24;

function invalid(message) {
  throw new TypeError(message);
}

function object(value, label) {
  if (!value || typeof value !== 'object' || Array.isArray(value)) invalid(`${label}应为对象。`);
  return value;
}

function list(value, minimum, maximum, label) {
  if (!Array.isArray(value) || value.length < minimum || value.length > maximum) {
    invalid(`${label}应有 ${minimum} 到 ${maximum} 项。`);
  }
  return value;
}

function natural(value, limit, label) {
  if (!Number.isInteger(value) || value < 0 || value > limit) invalid(`${label}应是 0 到 ${limit} 的整数。`);
  return value;
}

function name(value, label) {
  if (typeof value !== 'string' || /[\0-\x1f\x7f]/u.test(value) || !value.trim() || value.trim().length > 100) {
    invalid(`${label}应是 1 到 100 字的单行文字。`);
  }
  return value.trim();
}

function id(value, label) {
  if (typeof value !== 'string' || !/^[A-Za-z0-9][A-Za-z0-9_-]{0,39}$/u.test(value)) {
    invalid(`${label}须为 1 到 40 个字母、数字、下划线或连字符，开头使用字母或数字。`);
  }
  return value;
}

function unique(value, label) {
  if (new Set(value).size !== value.length) invalid(`${label}有重复项。`);
  return value;
}

function dateStart(date, label) {
  if (typeof date !== 'string' || !/^[1-9]\d{3}-\d{2}-\d{2}$/u.test(date)) {
    invalid(`${label}应采用 YYYY-MM-DD 格式。`);
  }
  const start = Date.parse(`${date}T00:00:00.000Z`);
  if (Number.isNaN(start) || new Date(start).toISOString().slice(0, 10) !== date) invalid(`${label}无效。`);
  return start;
}

function clock(value, label) {
  if (typeof value !== 'string' || !/^(?:[01]\d|2[0-3]):[0-5]\d$/u.test(value)) invalid(`${label}应采用 HH:MM 格式。`);
  return value;
}

function normalize(problem) {
  object(problem, '排班方案');
  const start = dateStart(problem.weekStart, '周起始日期');
  if (new Date(start).getUTCDay() !== 1 || new Date(start + 6 * DAY_MS).getUTCFullYear() > 9999) {
    invalid('周起始日期应为可以覆盖完整一周的周一。');
  }
  const dates = new Set(Array.from({ length: 7 }, (_, offset) => new Date(start + offset * DAY_MS).toISOString().slice(0, 10)));
  const skills = list(problem.skills, 1, MAX_SKILLS, '技能列表').map((entry, index) => {
    const label = `第 ${index + 1} 项技能`;
    const item = object(entry, label);
    return { id: id(item.id, `${label}编号`), name: name(item.name, `${label}名称`) };
  });
  const skillsById = new Set(unique(skills.map(skill => skill.id), '技能编号'));
  const checkSkill = (value, label) => {
    if (!skillsById.has(value)) invalid(`${label}应引用已有技能。`);
    return value;
  };
  const staff = list(problem.staff, 1, MAX_STAFF, '员工列表').map((entry, index) => {
    const label = `第 ${index + 1} 位员工`;
    const item = object(entry, label);
    const employeeSkills = list(item.skills, 0, MAX_SKILLS, `${label}技能列表`);
    const unavailable = unique(list(item.unavailable, 0, 7, `${label}不可排日期`), `${label}不可排日期`);
    if (unavailable.some(date => !dates.has(date))) invalid(`${label}的不可排日期超出当前周。`);
    return {
      id: id(item.id, `${label}编号`),
      name: name(item.name, `${label}姓名`),
      skills: unique(employeeSkills.map(skill => checkSkill(skill, `${label}技能`)), `${label}技能`),
      maxShifts: natural(item.maxShifts, 7, `${label}周上限`),
      unavailable: [...unavailable],
    };
  });
  unique(staff.map(person => person.id), '员工编号');
  const shifts = list(problem.shifts, 1, MAX_SHIFTS, '班次列表').map((entry, index) => {
    const label = `第 ${index + 1} 个班次`;
    const item = object(entry, label);
    if (!dates.has(item.date)) invalid(`${label}日期超出当前周。`);
    const first = clock(item.start, `${label}开始时间`);
    const last = clock(item.end, `${label}结束时间`);
    if (last <= first) invalid(`${label}结束时间应晚于同一天的开始时间。`);
    return {
      id: id(item.id, `${label}编号`),
      date: item.date,
      label: name(item.label, `${label}名称`),
      start: first,
      end: last,
      skill: checkSkill(item.skill, `${label}技能`),
      count: natural(item.count, 40, `${label}人数`),
    };
  });
  unique(shifts.map(shift => shift.id), '班次编号');
  const locks = list(problem.locks, 0, MAX_STAFF * 7, '锁定安排').map((entry, index) => {
    const label = `第 ${index + 1} 条锁定安排`;
    const item = object(entry, label);
    return { shiftId: id(item.shiftId, `${label}班次编号`), staffId: id(item.staffId, `${label}员工编号`) };
  });
  return { name: name(problem.name, '方案名称'), weekStart: problem.weekStart, skills, staff, shifts, locks };
}

function availability(person, shift, workedDates, workload) {
  if (!person.skills.includes(shift.skill)) return 'skill';
  if (person.unavailable.includes(shift.date)) return 'unavailable';
  if (workedDates.has(shift.date)) return 'same-day';
  if (workload >= person.maxShifts) return 'weekly-limit';
  return 'eligible';
}

function buildRoster(problem) {
  const staffById = new Map(problem.staff.map(person => [person.id, person]));
  const shiftsById = new Map(problem.shifts.map(shift => [shift.id, shift]));
  const workedDates = new Map(problem.staff.map(person => [person.id, new Set()]));
  const assignedByShift = new Map(problem.shifts.map(shift => [shift.id, []]));
  const lockErrors = { skill: '缺少所需技能', unavailable: '当天不可排', 'same-day': '当天已有锁定安排', 'weekly-limit': '超出每周班次上限' };

  function assign(person, shift, locked) {
    workedDates.get(person.id).add(shift.date);
    assignedByShift.get(shift.id).push({ staffId: person.id, shiftId: shift.id, locked });
  }

  for (const lock of problem.locks) {
    const person = staffById.get(lock.staffId);
    const shift = shiftsById.get(lock.shiftId);
    if (!person || !shift) invalid(`锁定安排 ${lock.staffId} / ${lock.shiftId} 的员工或班次不存在。`);
    const dates = workedDates.get(person.id);
    const reason = availability(person, shift, dates, dates.size);
    if (reason !== 'eligible') invalid(`锁定安排 ${person.name} / ${shift.date} ${shift.label}：${lockErrors[reason]}。`);
    if (assignedByShift.get(shift.id).length >= shift.count) invalid(`锁定安排超出 ${shift.date} ${shift.label} 的班次人数。`);
    assign(person, shift, true);
  }
  return { workedDates, assignedByShift, assign };
}

export function parseRoster(text) {
  if (typeof text !== 'string') invalid('请提供 JSON 文本。');
  if (text.length > MAX_INPUT_BYTES || new TextEncoder().encode(text).length > MAX_INPUT_BYTES) invalid('排班文件应在 256 KiB 以内。');
  let document;
  try {
    document = JSON.parse(text.replace(/^\uFEFF/u, ''));
  } catch {
    invalid('无法读取 JSON，请检查文件格式。');
  }
  const problem = normalize(document);
  buildRoster(problem);
  return problem;
}

function createGraph() {
  const graph = [];
  return {
    graph,
    node() {
      graph.push([]);
      return graph.length - 1;
    },
    edge(from, to, capacity, cost = 0) {
      const forward = { to, capacity, cost, reverse: graph[to].length };
      graph[to].push({ to: from, capacity: 0, cost: -cost, reverse: graph[from].length });
      graph[from].push(forward);
      return forward;
    },
  };
}

class DistanceQueue {
  items = [];

  push(entry) {
    const queue = this.items;
    let at = queue.length;
    queue.push(entry);
    while (at > 0) {
      const parent = Math.floor((at - 1) / 2);
      if (queue[parent].distance <= entry.distance) break;
      queue[at] = queue[parent];
      at = parent;
    }
    queue[at] = entry;
  }

  pop() {
    const queue = this.items;
    const first = queue[0];
    const last = queue.pop();
    if (queue.length === 0) return first;
    let at = 0;
    while (at * 2 + 1 < queue.length) {
      const left = at * 2 + 1;
      const right = left + 1;
      const child = right < queue.length && queue[right].distance < queue[left].distance ? right : left;
      if (last.distance <= queue[child].distance) break;
      queue[at] = queue[child];
      at = child;
    }
    queue[at] = last;
    return first;
  }
}

function fillMinimumCost(graph, source, sink) {
  const potentials = new Array(graph.length).fill(0);
  while (true) {
    const distance = new Array(graph.length).fill(Infinity);
    const prev = new Array(graph.length);
    const queue = new DistanceQueue();
    distance[source] = 0;
    queue.push({ node: source, distance: 0 });

    while (queue.items.length) {
      const visit = queue.pop();
      if (visit.distance !== distance[visit.node]) continue;
      for (const edge of graph[visit.node]) {
        if (edge.capacity === 0) continue;
        const next = visit.distance + edge.cost + potentials[visit.node] - potentials[edge.to];
        if (next >= distance[edge.to]) continue;
        distance[edge.to] = next;
        prev[edge.to] = { from: visit.node, edge };
        queue.push({ node: edge.to, distance: next });
      }
    }

    if (!prev[sink]) return;
    for (let index = 0; index < graph.length; index += 1) {
      if (Number.isFinite(distance[index])) potentials[index] += distance[index];
    }
    // The employee/day edge admits one seat, so each augmenting path sends one unit.
    for (let node = sink; node !== source;) {
      const { from, edge } = prev[node];
      edge.capacity -= 1;
      graph[node][edge.reverse].capacity += 1;
      node = from;
    }
  }
}

/** Maximize covered seats, then minimize the sum of squared employee shift counts. */
export function solveRoster(input) {
  const problem = normalize(input);
  const { workedDates, assignedByShift, assign } = buildRoster(problem);
  const { graph, node, edge } = createGraph();
  const source = node();
  const sink = node();
  const openShifts = problem.shifts.filter(shift => shift.count > assignedByShift.get(shift.id).length);
  const shiftNodes = new Map(openShifts.map(shift => [shift.id, node()]));
  for (const shift of openShifts) edge(shiftNodes.get(shift.id), sink, shift.count - assignedByShift.get(shift.id).length);

  const choices = [];
  for (const person of problem.staff) {
    const dates = workedDates.get(person.id);
    if (dates.size >= person.maxShifts) continue;
    const staffNode = node();
    // Marginal cost 2k+1 for going from k to k+1 assignments, including locks already counted.
    for (let count = dates.size; count < person.maxShifts; count += 1) edge(source, staffNode, 1, 2 * count + 1);
    const dayNodes = new Map();
    for (const shift of openShifts) {
      if (availability(person, shift, dates, dates.size) !== 'eligible') continue;
      if (!dayNodes.has(shift.date)) {
        dayNodes.set(shift.date, node());
        edge(staffNode, dayNodes.get(shift.date), 1);
      }
      const option = edge(dayNodes.get(shift.date), shiftNodes.get(shift.id), 1);
      choices.push({ person, shift, option });
    }
  }
  fillMinimumCost(graph, source, sink);
  for (const { person, shift, option } of choices) {
    if (option.capacity === 0) assign(person, shift, false);
  }

  const assignments = [...assignedByShift.values()].flat();
  const gaps = problem.shifts.filter(shift => shift.count > assignedByShift.get(shift.id).length).map(shift => ({
    shiftId: shift.id,
    missing: shift.count - assignedByShift.get(shift.id).length,
    reasons: problem.staff.map(person => {
      const dates = workedDates.get(person.id);
      return { staffId: person.id, kind: availability(person, shift, dates, dates.size) };
    }),
  }));
  const workloads = problem.staff.map(person => ({ staffId: person.id, shifts: workedDates.get(person.id).size, cap: person.maxShifts }));
  const requested = problem.shifts.reduce((count, shift) => count + shift.count, 0);
  return {
    assignments,
    gaps,
    workloads,
    totals: {
      requested,
      assigned: assignments.length,
      missing: requested - assignments.length,
      locked: problem.locks.length,
      workloadCost: workloads.reduce((cost, load) => cost + load.shifts ** 2, 0),
    },
  };
}

function csvCell(value) {
  const text = String(value ?? '');
  const safe = /^\s*[=+@＝＋－＠-]|^[\t\r\n]/u.test(text) ? `'${text}` : text;
  return /[",\r\n]/u.test(safe) ? `"${safe.replaceAll('"', '""')}"` : safe;
}

export function rosterCsv(problem, result) {
  const roster = new Map(problem.shifts.map(shift => [shift.id, []]));
  const skills = new Map(problem.skills.map(skill => [skill.id, skill.name]));
  const names = new Map(problem.staff.map(person => [person.id, person.name]));
  for (const entry of result.assignments) roster.get(entry.shiftId).push(entry);
  const rows = [['日期', '班次', '开始', '结束', '技能', '员工', '状态']];
  for (const shift of problem.shifts) {
    const assigned = roster.get(shift.id);
    const details = [shift.date, shift.label, shift.start, shift.end, skills.get(shift.skill)];
    for (const entry of assigned) rows.push([...details, names.get(entry.staffId), entry.locked ? '锁定' : '已安排']);
    for (let index = assigned.length; index < shift.count; index += 1) rows.push([...details, '', '缺员']);
  }
  return `\uFEFF${rows.map(row => row.map(csvCell).join(',')).join('\r\n')}\r\n`;
}
