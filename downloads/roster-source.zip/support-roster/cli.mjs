import { open, stat, unlink } from 'node:fs/promises';
import { MAX_INPUT_BYTES, parseRoster, rosterCsv, solveRoster } from './engine.mjs';
import { DEMO_ABSENCE, DEMO_BASE } from './fixtures.mjs';

const HELP = `客服排班工作台 · 本机命令行

node cli.mjs --demo [--absence] [--out <新文件.csv>]
node cli.mjs --input <排班数据.json> [--out <新文件.csv>]

  --demo             使用内置排班样例
  --absence          使用样例中的人员请假情景
  --input <文件>     使用本机 UTF-8 JSON 文件，最大 ${MAX_INPUT_BYTES / 1024} KiB
  --out <新文件>     全部需求有覆盖时，导出 UTF-8 CSV
  --help, -h         查看帮助

标准输出为 JSON 结果，含排班、缺口、人员班量和总计。
退出码 0 表示全部需求已覆盖，2 表示存在缺口，1 表示参数、数据或文件错误。`;

class CliError extends Error {}

const flags = new Set(['--demo', '--absence']);
const paths = new Set(['--input', '--out']);

function parseArguments(args) {
  const values = new Map();
  for (let index = 0; index < args.length; index += 1) {
    const key = args[index];
    if (values.has(key) || (!flags.has(key) && !paths.has(key))) {
      throw new CliError('存在未知或重复的参数。运行 node cli.mjs --help 查看用法。');
    }
    if (flags.has(key)) {
      values.set(key, true);
      continue;
    }
    const value = args[index + 1];
    if (!value || value.startsWith('--')) throw new CliError(`${key} 需要文件路径。`);
    values.set(key, value);
    index += 1;
  }
  if (values.has('--demo') === values.has('--input')) {
    throw new CliError('请选择 --demo 或 --input。');
  }
  if (values.has('--absence') && !values.has('--demo')) throw new CliError('--absence 需要与 --demo 一起使用。');
  return values;
}

function checkInputFile(info) {
  if (!info.isFile() || info.size > MAX_INPUT_BYTES) {
    throw new CliError(`请提供不超过 ${MAX_INPUT_BYTES / 1024} KiB 的排班 JSON 文件。`);
  }
}

async function readInput(path) {
  try {
    checkInputFile(await stat(path));
    const file = await open(path, 'r');
    try {
      checkInputFile(await file.stat());
      const buffer = Buffer.allocUnsafe(MAX_INPUT_BYTES + 1);
      let size = 0;
      while (size < buffer.length) {
        const { bytesRead } = await file.read(buffer, size, buffer.length - size, null);
        if (!bytesRead) break;
        size += bytesRead;
      }
      if (size > MAX_INPUT_BYTES) throw new CliError(`排班 JSON 文件超过 ${MAX_INPUT_BYTES / 1024} KiB。`);
      try {
        return new TextDecoder('utf-8', { fatal: true }).decode(buffer.subarray(0, size));
      } catch {
        throw new CliError('排班 JSON 文件需要使用 UTF-8 编码。');
      }
    } finally {
      await file.close();
    }
  } catch (error) {
    if (error instanceof CliError) throw error;
    throw new CliError('无法读取指定的排班文件。');
  }
}

async function writeCsv(path, contents) {
  let file;
  try {
    file = await open(path, 'wx', 0o600);
  } catch (error) {
    if (error.code === 'EEXIST') throw new CliError('输出已存在，请指定一个新文件。');
    throw new CliError('无法创建指定的 CSV 文件。');
  }
  try {
    try {
      await file.writeFile(contents, 'utf8');
    } finally {
      await file.close();
    }
  } catch {
    await unlink(path).catch(() => {});
    throw new CliError('写入排班 CSV 失败。');
  }
}

function validateAndSolve(input) {
  try {
    const problem = typeof input === 'string' ? parseRoster(input) : input;
    return { problem, result: solveRoster(problem) };
  } catch (error) {
    if (error instanceof SyntaxError) throw new CliError('排班文件不是有效的 JSON。');
    throw new CliError(error.message || '无法生成排班。');
  }
}

async function main(args) {
  if (args.length === 1 && ['-h', '--help'].includes(args[0])) {
    console.log(HELP);
    return 0;
  }
  const options = parseArguments(args);
  const demo = options.has('--absence') ? DEMO_ABSENCE : DEMO_BASE;
  const input = options.has('--demo') ? demo : await readInput(options.get('--input'));
  const { problem, result } = validateAndSolve(input);
  const missing = result.totals.missing;
  const output = options.get('--out');
  if (!missing && output) await writeCsv(output, rosterCsv(problem, result));

  console.log(JSON.stringify(result, null, 2));
  if (missing && output) console.error(`排班还缺 ${missing} 个岗位名额，暂未导出 CSV。`);
  return missing ? 2 : 0;
}

try {
  process.exitCode = await main(process.argv.slice(2));
} catch (error) {
  console.error(error instanceof CliError ? error.message : '无法完成排班。请检查输入与输出设置。');
  process.exitCode = 1;
}
