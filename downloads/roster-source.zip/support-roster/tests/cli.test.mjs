import assert from 'node:assert/strict';
import { spawnSync } from 'node:child_process';
import { mkdtemp, readFile, rm, stat, writeFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { dirname, join, resolve } from 'node:path';
import test from 'node:test';
import { fileURLToPath } from 'node:url';
import { MAX_INPUT_BYTES } from '../engine.mjs';
import { DEMO_BASE } from '../fixtures.mjs';

const cli = fileURLToPath(new URL('../cli.mjs', import.meta.url));

function invoke(...parameters) {
  const run = spawnSync(process.execPath, [cli, ...parameters], { encoding: 'utf8', timeout: 5_000 });
  assert.ifError(run.error);
  assert.equal(run.signal, null);
  return run;
}

async function temporary(t) {
  const path = await mkdtemp(join(tmpdir(), 'support-roster-cli-'));
  assert.equal(dirname(path), resolve(tmpdir()));
  t.after(() => rm(path, { recursive: true, force: true }));
  return path;
}

test('demo produces stable JSON and help documents the exit contract', () => {
  const first = invoke('--demo');
  const second = invoke('--demo');
  assert.equal(first.status, 0, first.stderr);
  assert.equal(second.status, 0, second.stderr);
  const report = JSON.parse(first.stdout);
  assert.equal(report.totals.requested, 21);
  assert.equal(report.totals.assigned, 21);
  assert.equal(report.totals.missing, 0);
  assert.deepEqual(report.gaps, []);
  assert.equal(report.assignments.length, 21);
  assert.equal(new Set(report.assignments.map(item => `${item.shiftId},${item.staffId}`)).size, 21);
  assert.equal(first.stdout, second.stdout);
  const help = invoke('--help');
  assert.equal(help.status, 0, help.stderr);
  assert.match(help.stdout, /2 表示存在缺口/);
  assert.match(help.stdout, /256 KiB/);
});

test('a missing specialist produces a diagnostic report without creating an output file', async t => {
  const root = await temporary(t);
  const output = join(root, 'plan.csv');
  const unattended = invoke('--demo', '--absence');
  const withOutput = invoke('--demo', '--absence', '--out', output);
  assert.equal(unattended.status, 2, unattended.stderr);
  assert.equal(withOutput.status, 2, withOutput.stderr);
  assert.equal(unattended.stdout, withOutput.stdout);
  assert.match(withOutput.stderr, /缺 1 个/);
  const report = JSON.parse(withOutput.stdout);
  assert.equal(report.totals.requested, 21);
  assert.equal(report.totals.assigned, 20);
  assert.equal(report.totals.missing, 1);
  assert.equal(report.gaps.length, 1);
  assert.equal(report.gaps[0].missing, 1);
  assert(report.gaps[0].reasons.some(reason => reason.kind === 'unavailable'));
  await assert.rejects(stat(output), { code: 'ENOENT' });
});

test('real JSON with a UTF-8 BOM yields formula-safe CSV and preserves the source', async t => {
  const root = await temporary(t);
  const input = join(root, '请输入排班.json');
  const output = join(root, '班表.csv');
  const problem = structuredClone(DEMO_BASE);
  problem.staff[0].name = '=1+1';
  const text = '\ufeff' + JSON.stringify(problem);
  await writeFile(input, text, 'utf8');
  const run = invoke('--input', input, '--out', output);
  assert.equal(run.status, 0, run.stderr);
  const report = JSON.parse(run.stdout);
  assert.equal(report.totals.assigned, 21);
  assert(report.assignments.some(item => item.staffId === problem.staff[0].id));
  assert(!run.stdout.includes('=1+1'));
  const csv = await readFile(output, 'utf8');
  assert(csv.startsWith('\ufeff'));
  assert.match(csv, /'=1\+1/);
  assert.doesNotMatch(csv, /(?:^|,)"?=1\+1/);
  assert.equal((csv.match(/\r?\n/g) || []).length, 22);
  assert.equal(await readFile(input, 'utf8'), text);
});

test('preexisting output and same-file input are never overwritten', async t => {
  const root = await temporary(t);
  const existing = join(root, '已有文件.csv');
  const original = join(root, '排班数据.json');
  const json = JSON.stringify(DEMO_BASE);
  await writeFile(existing, 'do not replace', 'utf8');
  await writeFile(original, json, 'utf8');
  for (const [path, expected] of [[existing, 'do not replace'], [original, json]]) {
    const run = invoke('--input', original, '--out', path);
    assert.equal(run.status, 1);
    assert.match(run.stderr, /输出已存在/);
    assert.equal(await readFile(path, 'utf8'), expected);
  }
});

test('invalid input and arguments do not create a spreadsheet', async t => {
  const root = await temporary(t);
  const input = join(root, 'invalid.json');
  const output = join(root, 'should-not-write.csv');
  const oversized = join(root, 'large.json');
  const incorrectEncoding = join(root, 'broken-utf8.json');
  await writeFile(input, '{"name":bad-json}', 'utf8');
  await writeFile(oversized, Buffer.alloc(MAX_INPUT_BYTES + 1, 0x20));
  await writeFile(incorrectEncoding, Buffer.from([0x22, 0xff, 0x22]));
  for (const [path, expected] of [[input, /JSON/], [oversized, /256 KiB/], [incorrectEncoding, /UTF-8/]]) {
    const run = invoke('--input', path, '--out', output);
    assert.equal(run.status, 1);
    assert.match(run.stderr, expected);
    assert(!run.stderr.includes('bad-json'));
    assert.equal(run.stdout, '');
  }
  for (const args of [[], ['--absence'], ['--demo', '--bogus'], ['--demo', '--out'],
    ['--demo', '--demo'], ['--demo', '--input', input], ['--absence', '--input', input]]) {
    const run = invoke(...args);
    assert.equal(run.status, 1);
    assert.notEqual(run.stderr, '');
  }
  await assert.rejects(stat(output), { code: 'ENOENT' });
});
