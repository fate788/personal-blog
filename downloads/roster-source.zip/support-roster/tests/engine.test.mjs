import assert from 'node:assert/strict';
import test from 'node:test';
import { MAX_INPUT_BYTES, parseRoster, rosterCsv, solveRoster } from '../engine.mjs';
import { DEMO_ABSENCE, DEMO_BASE } from '../fixtures.mjs';

function validateAssignments(problem, result) {
  const occupied = new Set();
  const people = new Map(problem.staff.map(person => [person.id, person]));
  const shifts = new Map(problem.shifts.map(shift => [shift.id, shift]));
  const counts = new Map();
  const loads = new Map();
  for (const assignment of result.assignments) {
    const person = people.get(assignment.staffId);
    const shift = shifts.get(assignment.shiftId);
    assert(person.skills.includes(shift.skill));
    assert(!person.unavailable.includes(shift.date));
    const key = `${person.id}:${shift.date}`;
    assert(!occupied.has(key));
    occupied.add(key);
    loads.set(person.id, (loads.get(person.id) ?? 0) + 1);
    counts.set(shift.id, (counts.get(shift.id) ?? 0) + 1);
    assert(loads.get(person.id) <= person.maxShifts);
    assert(counts.get(shift.id) <= shift.count);
  }
  const keyForLock = ({ staffId, shiftId }) => `${staffId}:${shiftId}`;
  assert.deepEqual(result.assignments.filter(entry => entry.locked).map(keyForLock).sort(), problem.locks.map(keyForLock).sort());
  assert.equal(result.totals.assigned, result.assignments.length);
  assert.equal(result.totals.requested - result.totals.assigned, result.gaps.reduce((sum, gap) => sum + gap.missing, 0));
  assert.equal(result.totals.workloadCost, [...loads.values()].reduce((sum, value) => sum + value ** 2, 0));
}

test('reference week covers all 21 seats without violating a lock or staff restriction', () => {
  const original = structuredClone(DEMO_BASE);
  const solved = solveRoster(DEMO_BASE);
  assert.deepEqual(solved.totals, { requested: 21, assigned: 21, missing: 0, locked: 1, workloadCost: 57 });
  assert.deepEqual(solved.workloads.map(person => person.shifts).toSorted(), [2, 2, 2, 3, 3, 3, 3, 3]);
  assert.deepEqual(solved.gaps, []);
  validateAssignments(DEMO_BASE, solved);
  assert.deepEqual(DEMO_BASE, original);
  assert.deepEqual(solveRoster(DEMO_BASE), solved);
});

test('selecting the absence scenario leaves a visible Sunday slot with current-roster reasons', () => {
  const solved = solveRoster(DEMO_ABSENCE);
  assert.deepEqual(solved.totals, { requested: 21, assigned: 20, missing: 1, locked: 1, workloadCost: 52 });
  assert.equal(solved.gaps.length, 1);
  assert.equal(solved.gaps[0].shiftId, 'd7-late');
  assert.equal(solved.gaps[0].missing, 1);
  assert.equal(solved.gaps[0].reasons.filter(reason => reason.kind === 'skill').length, 5);
  assert.equal(solved.gaps[0].reasons.filter(reason => reason.kind === 'unavailable').length, 3);
  const updated = structuredClone(DEMO_ABSENCE);
  updated.staff.at(-1).unavailable.pop();
  assert.equal(solveRoster(updated).totals.missing, 0);
  validateAssignments(DEMO_ABSENCE, solved);
});

function tiny(staff, shifts, locks = []) {
  return {
    name: '小排班', weekStart: '2026-11-30',
    skills: [{ id: 'a', name: '在线' }, { id: 'b', name: '升级' }],
    staff: staff.map((person, index) => ({ id: `s${index}`, name: `客服${index}`, maxShifts: 2, unavailable: [], ...person })),
    shifts: shifts.map((shift, index) => ({ id: `d${index}`, label: `班次${index}`, date: '2026-11-30', start: '09:00', end: '17:00', count: 1, ...shift })),
    locks,
  };
}

// Independent exhaustive enumeration for small schedules. Each demand seat is either left
// open or assigned to a staff member. It never uses the flow network or the engine's scoring code.
function enumerate(problem) {
  const occupied = new Map(problem.staff.map(person => [person.id, new Set()]));
  const seats = problem.shifts.flatMap(shift => {
    const locks = problem.locks.filter(lock => lock.shiftId === shift.id);
    for (const lock of locks) occupied.get(lock.staffId).add(shift.date);
    return Array(shift.count - locks.length).fill(shift);
  });
  let best = { coverage: -1, cost: Infinity };
  function place(index, coverage) {
    if (index === seats.length) {
      const cost = [...occupied.values()].reduce((sum, dates) => sum + dates.size * dates.size, 0);
      if (coverage > best.coverage || (coverage === best.coverage && cost < best.cost)) best = { coverage, cost };
      return;
    }
    const shift = seats[index];
    place(index + 1, coverage);
    for (const person of problem.staff) {
      const dates = occupied.get(person.id);
      if (dates.has(shift.date) || dates.size >= person.maxShifts || !person.skills.includes(shift.skill)
          || person.unavailable.includes(shift.date)) continue;
      dates.add(shift.date);
      place(index + 1, coverage + 1);
      dates.delete(shift.date);
    }
  }
  place(0, problem.locks.length);
  return best;
}

test('finds the augmenting reassignment needed when a generalist is the only specialist', () => {
  const problem = tiny([{ skills: ['a', 'b'] }, { skills: ['a'] }], [{ skill: 'a' }, { skill: 'b' }]);
  const result = solveRoster(problem);
  assert.deepEqual(result.assignments, [
    { staffId: 's1', shiftId: 'd0', locked: false }, { staffId: 's0', shiftId: 'd1', locked: false },
  ]);
  validateAssignments(problem, result);
});

test('coverage and squared workload match an exhaustive search over varied skills and capacities', () => {
  const skillsByMask = [[], ['a'], ['b'], ['a', 'b']];
  for (let skillMask = 0; skillMask < 16; skillMask += 1) {
    for (let limit = 0; limit <= 2; limit += 1) {
      for (const unavailable of [[], ['2026-12-01']]) {
        const problem = tiny([
          { skills: skillsByMask[skillMask >> 2], maxShifts: limit },
          { skills: skillsByMask[skillMask & 3], unavailable },
          { skills: ['a'], maxShifts: 1 },
        ], [{ skill: 'a', count: 2 }, { skill: 'b' }, { skill: 'a', date: '2026-12-01' }, { skill: 'b', date: '2026-12-01' }]);
        const result = solveRoster(problem);
        assert.deepEqual({ coverage: result.totals.assigned, cost: result.totals.workloadCost }, enumerate(problem));
        validateAssignments(problem, result);
      }
    }
  }
});

test('locked assignments enter the marginal cost before free assignments are optimized', () => {
  const problem = tiny([
    { skills: ['a'] }, { skills: ['a'] },
  ], [
    { skill: 'a' }, { skill: 'a', date: '2026-12-01' },
  ], [{ staffId: 's0', shiftId: 'd0' }]);
  const result = solveRoster(problem);
  assert.deepEqual({ coverage: result.totals.assigned, cost: result.totals.workloadCost }, enumerate(problem));
  assert.deepEqual(result.workloads.map(person => person.shifts), [1, 1]);
  validateAssignments(problem, result);
});

test('rejects lock conflicts and leaves the supplied plan intact', () => {
  const problem = structuredClone(DEMO_BASE);
  problem.locks.push({ shiftId: 'd1-late', staffId: 's01' });
  assert.throws(() => solveRoster(problem), /缺少所需技能/);
  problem.locks[1] = { shiftId: 'd1-day', staffId: 's01' };
  assert.throws(() => parseRoster(JSON.stringify(problem)), /当天已有锁定安排/);
  problem.locks[1] = { shiftId: 'd1-day', staffId: 's04' };
  assert.throws(() => solveRoster(problem), /当天不可排/);
  problem.locks[1] = { shiftId: 'absent', staffId: 's01' };
  assert.throws(() => solveRoster(problem), /不存在/);
  problem.locks[1] = { shiftId: 'd2-day', staffId: 's01' };
  problem.staff[0].maxShifts = 1;
  assert.throws(() => solveRoster(problem), /超出每周班次上限/);
  problem.locks[1] = { shiftId: 'd1-day', staffId: 's02' };
  problem.shifts[0].count = 1;
  assert.throws(() => solveRoster(problem), /超出.*班次人数/);
  assert.equal(problem.locks.length, 2);
});

test('validates date boundaries, integer limits, input size and referenced IDs', () => {
  assert.deepEqual(parseRoster(`\uFEFF${JSON.stringify(DEMO_BASE)}`), DEMO_BASE);
  assert.throws(() => parseRoster('plain text'), /无法读取 JSON/);
  assert.throws(() => parseRoster('x'.repeat(MAX_INPUT_BYTES + 1)), /256 KiB/);
  assert.throws(() => parseRoster('排'.repeat(100_000)), /256 KiB/);
  assert.throws(() => solveRoster({ ...DEMO_BASE, weekStart: '2026-11-31' }), /日期无效/);
  assert.throws(() => solveRoster({ ...DEMO_BASE, weekStart: '2026-12-01' }), /周一/);
  assert.throws(() => solveRoster({ ...DEMO_BASE, staff: [...DEMO_BASE.staff, DEMO_BASE.staff[0]] }), /员工编号有重复/);
  for (const [changes, error] of [
    [{ skill: 'other' }, /已有技能/], [{ count: 40.1 }, /整数/], [{ count: 41 }, /整数/],
    [{ end: '01:00' }, /同一天/], [{ start: '9:00' }, /HH:MM/], [{ date: '2026-12-07' }, /超出当前周/],
  ]) {
    const problem = structuredClone(DEMO_BASE);
    Object.assign(problem.shifts[0], changes);
    assert.throws(() => solveRoster(problem), error);
  }
});

test('reports reasons from the actual roster when a candidate is already assigned or capped', () => {
  const problem = tiny([
    { skills: ['a'], maxShifts: 1 },
    { skills: ['a'], maxShifts: 0 },
  ], [{ skill: 'a' }, { skill: 'a' }], [{ staffId: 's0', shiftId: 'd0' }]);
  assert.deepEqual(solveRoster(problem).gaps, [{
    shiftId: 'd1', missing: 1,
    reasons: [{ staffId: 's0', kind: 'same-day' }, { staffId: 's1', kind: 'weekly-limit' }],
  }]);
});

test('CSV includes empty seats and protects text from spreadsheet formula evaluation', () => {
  const problem = structuredClone(DEMO_ABSENCE);
  problem.staff[0].name = '=1+1';
  problem.shifts[0].label = '＠班, "一"';
  const csv = rosterCsv(problem, solveRoster(problem));
  const rows = csv.trimEnd().split('\r\n');
  assert.equal(rows[0], '\uFEFF日期,班次,开始,结束,技能,员工,状态');
  assert.equal(rows.length, 22);
  assert(rows[1].includes('"\'＠班, ""一"""'));
  assert(rows[1].endsWith(",'=1+1,锁定"));
  assert(rows.at(-1).endsWith('售后升级,,缺员'));
});
