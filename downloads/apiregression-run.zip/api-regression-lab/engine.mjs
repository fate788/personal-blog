function kind(value) {
  if (Array.isArray(value)) return "array";
  return value === null ? "null" : typeof value;
}

function findPropertyPath(path, key) {
  return /^[A-Za-z_$][A-Za-z0-9_$]*$/u.test(key) ? `${path}.${key}` : `${path}[${JSON.stringify(key)}]`;
}

function pathRule(contract, name, path, pattern) {
  const rules = contract[name] || [];
  return rules.includes(path) || rules.includes(pattern);
}

function addFinding(findings, level, code, path, message, expected, actual) {
  findings.push({kind: level, code, path, message, expected: structuredClone(expected), actual: structuredClone(actual)});
}

function inspectValue(before, after, path, pattern, result) {
  if (Object.is(before, after)) return;
  const {contract, findings, ignored} = result;
  if (pathRule(contract, "ignorePaths", path, pattern)) {
    // Fixture values are JSON. Ignore duplicate copies of unchanged objects as well as scalars.
    if (JSON.stringify(before) !== JSON.stringify(after)) ignored.push({path, message: "动态字段按契约忽略。"});
    return;
  }

  const expectedType = kind(before);
  const actualType = kind(after);
  if (expectedType !== actualType) {
    if (expectedType === "null" || actualType === "null") {
      const expected = contract.nullableTypes?.[path] ?? contract.nullableTypes?.[pattern];
      if (expected && (expectedType === "null" ? actualType : expectedType) === expected) {
        addFinding(findings, "change", "NULLABLE_VALUE_CHANGED", path, "可空字段已更新。", before, after);
        return;
      }
    }
    addFinding(findings, "blocker", "TYPE_CHANGED", path, `字段类型由 ${expectedType} 变为 ${actualType}。`, before, after);
    return;
  }

  if (expectedType === "array") {
    if (before.length !== after.length) {
      addFinding(findings, "blocker", "ARRAY_LENGTH_CHANGED", path, "固定案例中的数组元素数量发生变化。", before.length, after.length);
    }
    for (let index = 0; index < Math.min(before.length, after.length); index++) {
      inspectValue(before[index], after[index], `${path}[${index}]`, `${pattern}[*]`, result);
    }
  } else if (expectedType === "object") {
    for (const [key, value] of Object.entries(before)) {
      const child = findPropertyPath(path, key);
      const childPattern = findPropertyPath(pattern, key);
      if (Object.hasOwn(after, key)) {
        inspectValue(value, after[key], child, childPattern, result);
      } else if (pathRule(contract, "ignorePaths", child, childPattern)) {
        ignored.push({path: child, message: "动态字段按契约忽略。"});
      } else if (pathRule(contract, "optionalPaths", child, childPattern)) {
        addFinding(findings, "change", "OPTIONAL_FIELD_REMOVED", child, "可选字段已省略。", value, undefined);
      } else {
        addFinding(findings, "blocker", "FIELD_MISSING", child, "候选响应缺少基线的必需字段。", value, undefined);
      }
    }
    for (const [key, value] of Object.entries(after)) {
      if (Object.hasOwn(before, key)) continue;
      const child = findPropertyPath(path, key);
      if (pathRule(contract, "ignorePaths", child, findPropertyPath(pattern, key))) ignored.push({path: child, message: "动态字段按契约忽略。"});
      else addFinding(findings, "change", "FIELD_ADDED", child, "候选响应新增字段，原有字段仍受校验。", undefined, value);
    }
  } else if (pathRule(contract, "allowValuePaths", path, pattern)) {
    addFinding(findings, "change", "ALLOWED_VALUE_CHANGED", path, "此字段允许改值，类型仍需兼容。", before, after);
  } else {
    addFinding(findings, "blocker", "STABLE_VALUE_CHANGED", path, "固定案例中的业务值发生变化。", before, after);
  }
}

function snapshot(responses, id) {
  return responses && Object.hasOwn(responses, id) ? responses[id] : null;
}

function isResponse(value) {
  return Number.isInteger(value?.status) && value.status >= 100 && value.status <= 599 &&
    Object.hasOwn(value, "body") && value.body !== undefined;
}

function inspectCase(testCase, baselineResponses, candidateResponses) {
  const baseline = snapshot(baselineResponses, testCase.id);
  const candidate = snapshot(candidateResponses, testCase.id);
  const findings = [];
  const ignored = [];
  if (!isResponse(baseline) || !isResponse(candidate)) {
    const unavailable = [!isResponse(baseline) && "基线", !isResponse(candidate) && "候选"].filter(Boolean).join("及");
    addFinding(findings, "blocker", "RESPONSE_MISSING", "$", `${unavailable}响应无法用于验收。`, undefined, undefined);
  } else {
    if (baseline.status !== candidate.status) {
      addFinding(findings, "blocker", "HTTP_STATUS_CHANGED", "HTTP 状态", "候选响应的 HTTP 状态码与基线不同。", baseline.status, candidate.status);
    }
    inspectValue(baseline.body, candidate.body, "$", "$", {contract: testCase.contract || {}, findings, ignored});
  }
  const bestAvailable = (response) => isResponse(response) ? structuredClone(response) : {status: null, body: null};
  return {id: testCase.id, title: testCase.title, group: testCase.group,
    method: testCase.method, path: testCase.path, description: testCase.description,
    verdict: findings.some(({kind}) => kind === "blocker") ? "blocked" : "passed",
    baseline: bestAvailable(baseline), candidate: bestAvailable(candidate), findings, ignored};
}

export function evaluateRelease({suite, baseline, candidate, baselineResponses, candidateResponses}) {
  const cases = suite.cases.map((testCase) => inspectCase(testCase, baselineResponses, candidateResponses));
  const blocked = cases.filter(({verdict}) => verdict === "blocked").length;
  const changes = cases.reduce((total, entry) => total + entry.findings.filter(({kind}) => kind === "change").length, 0);
  const ignored = cases.reduce((total, entry) => total + entry.ignored.length, 0);
  return {suiteId: suite.id, suiteTitle: suite.title, baseline, candidate,
    verdict: blocked ? "blocked" : "passed", totals: {cases: cases.length, passed: cases.length - blocked, blocked, changes, ignored}, cases};
}
