import { readFile } from "node:fs/promises";
import { createServer } from "node:http";
import { resolve } from "node:path";
import { fileURLToPath } from "node:url";
import { isDeepStrictEqual, parseArgs } from "node:util";
import { getFixtureResponse, releases, suite } from "./fixtures.mjs";

const siteFiles = new Map([
  ["/", "static/index.html"], ["/index.html", "static/index.html"], ["/app.mjs", "static/app.mjs"],
  ["/styles.css", "static/styles.css"], ["/transport.mjs", "static/transport.mjs"],
  ["/engine.mjs", "engine.mjs"], ["/fixtures.mjs", "fixtures.mjs"],
  ["/static/index.html", "static/index.html"], ["/static/app.mjs", "static/app.mjs"],
  ["/static/styles.css", "static/styles.css"], ["/static/transport.mjs", "static/transport.mjs"]
]);
const types = { html: "text/html; charset=utf-8", css: "text/css; charset=utf-8", mjs: "text/javascript; charset=utf-8" };
const policy = "default-src 'self'; script-src 'self'; connect-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; object-src 'none'; base-uri 'none'; frame-ancestors 'none'; form-action 'none'";
const maxBodyBytes = 16_384;
const fixturePaths = new Map();
for (const release of releases) {
  for (const testCase of suite.cases) {
    const path = `/fixtures/${release.id}${testCase.path}`;
    if (!fixturePaths.has(path)) fixturePaths.set(path, new Map());
    const methods = fixturePaths.get(path);
    if (methods.has(testCase.method)) throw new Error(`${testCase.method} ${path} 样例重复。`);
    methods.set(testCase.method, { release, testCase });
  }
}

function reply(response, status, body, type, head = false) {
  const noContent = [204, 205, 304].includes(status);
  response.writeHead(status, {
    "Content-Type": type,
    ...(noContent ? {} : { "Content-Length": Buffer.byteLength(body) }),
    "Cache-Control": "no-store",
    "X-Content-Type-Options": "nosniff",
    "Content-Security-Policy": policy
  });
  response.end(head || noContent ? undefined : body);
}

function json(response, status, value, head = false) {
  reply(response, status, JSON.stringify(value), "application/json; charset=utf-8", head);
}

function inputError(status, message) {
  return Object.assign(new Error(message), { status });
}

function readBody(request) {
  return new Promise((accept, reject) => {
    const chunks = [];
    let size = 0;
    request.on("data", chunk => {
      size += chunk.length;
      if (size <= maxBodyBytes) chunks.push(chunk);
      else reject(inputError(413, "请求体超过样例上限。"));
    });
    request.once("end", () => accept(Buffer.concat(chunks).toString("utf8")));
    request.once("error", reject);
  });
}

async function verifyFixtureBody(request, expected) {
  const raw = await readBody(request);
  if (expected === undefined && !raw) return;
  if (!/^application\/json\s*(?:;|$)/iu.test(request.headers["content-type"] || "")) {
    throw inputError(415, "样例请求体需要使用 JSON。");
  }
  let input;
  try {
    input = JSON.parse(raw);
  } catch {
    throw inputError(400, "无法解析样例请求体。");
  }
  if (!isDeepStrictEqual(input, expected)) throw inputError(400, "请求体需要与固定样例一致。");
}

export function startServer({ port = 8824 } = {}) {
  const server = createServer(async (request, response) => {
    const head = request.method === "HEAD";
    const address = server.address();
    const host = request.headers.host?.toLowerCase();
    try {
      if (![ `127.0.0.1:${address.port}`, `localhost:${address.port}` ].includes(host)) {
        throw inputError(403, "该服务仅供本机演练使用。");
      }
      const source = request.headers.origin;
      if (source && source !== `http://${host}`) throw inputError(403, "样例请求需要来自同源工作台。");
      if (!request.url?.startsWith("/") || request.url.startsWith("//")) throw inputError(400, "样例地址无效。");
      const url = new URL(request.url, `http://${host}`);
      if (url.origin !== `http://${host}` || url.hash) throw inputError(400, "样例地址无效。");

      if (url.pathname.startsWith("/fixtures/")) {
        const methods = fixturePaths.get(url.pathname + url.search);
        if (!methods) throw inputError(404, "未找到该样例接口。");
        const scenario = methods.get(request.method);
        if (!scenario) {
          response.setHeader("Allow", [...methods.keys()].join(", "));
          throw inputError(405, "该方法不在样例中。");
        }
        const { release, testCase } = scenario;
        await verifyFixtureBody(request, testCase.requestBody);
        const fixture = getFixtureResponse(release.id, testCase.id);
        response.setHeader("X-Regression-Fixture", testCase.id);
        json(response, fixture.status, fixture.body);
        return;
      }
      if (request.method !== "GET" && !head) {
        response.setHeader("Allow", "GET, HEAD");
        throw inputError(405, "静态页面仅支持读取。");
      }
      const file = siteFiles.get(url.pathname);
      if (!file) throw inputError(404, "页面不存在。");
      const body = await readFile(new URL(file, import.meta.url));
      reply(response, 200, body, types[file.split(".").at(-1)], head);
    } catch (error) {
      switch (true) {
        case Boolean(error.status): json(response, error.status, { error: error.message }, head); break;
        case error.code === "ENOENT": json(response, 404, { error: "页面不存在。" }, head); break;
        case error.code === "ERR_INVALID_URL": json(response, 400, { error: "样例地址无效。" }, head); break;
        default:
          console.error(error);
          json(response, 500, { error: "样例服务暂时不可用。" }, head);
      }
    }
  });
  return server.listen(port, "127.0.0.1");
}

if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const { values } = parseArgs({ options: { port: { type: "string", default: "8824" } } });
  const port = Number(values.port);
  if (!/^\d{1,5}$/u.test(values.port) || port > 65535) throw new Error("端口应为 0 至 65535。");
  const server = startServer({ port });
  server.on("listening", () => console.log(`接口回归验收台 http://127.0.0.1:${server.address().port}/`));
}
