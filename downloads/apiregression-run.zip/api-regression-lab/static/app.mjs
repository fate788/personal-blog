import { releases, suite } from "../fixtures.mjs";
import { executionMode, runRegression } from "./transport.mjs";

const byId = id => document.getElementById(id);
const baseline = releases.find(release => release.id === "baseline");
const candidates = releases.filter(release => release.id !== baseline.id);
const summary = byId("run-summary");
const runButton = byId("run-suite");
const exportButton = byId("export-report");
const workspace = byId("workspace");
const list = byId("case-list");
const detail = byId("case-detail");
const params = new URLSearchParams(location.search);
let candidateId = candidates.find(release => release.id === (params.get("candidate") || params.get("release")))?.id ?? candidates[0].id;
let filter = "all";
let currentCase = params.get("case") || "";
let currentPath = "";
let report;
let running = false;

const escaped = value => String(value ?? "").replace(/[&<>"']/gu, character => ({
  "&":"&amp;", "<":"&lt;", ">":"&gt;", '"':"&quot;", "'":"&#39;"
})[character]);
const versionNumber = release => release.label.split(" ").at(-1);

function releaseControls() {
  byId("product-area").textContent = suite.subject;
  const label = byId("execution-label");
  label.textContent = executionMode === "http" ? "本地 HTTP 样例服务" : "浏览器样例环境";
  label.hidden = false;
  byId("baseline-version").innerHTML = `<span>基线版本</span><strong>${escaped(versionNumber(baseline))}</strong>`;
  byId("candidate-version").innerHTML = `<div><span class="release-label" id="candidate-label">候选版本</span>
    <div role="group" class="release-buttons" aria-labelledby="candidate-label">${candidates.map(release =>
      `<button type="button" data-candidate="${escaped(release.id)}" aria-pressed="${release.id === candidateId}"${running ? " disabled" : ""}>${escaped(versionNumber(release))}</button>`
    ).join("")}</div></div><p>${escaped(candidates.find(release => release.id === candidateId).description)}</p>`;
}

function counts(result) {
  const blocked = result.verdict === "blocked";
  const {totals} = result;
  return `<div class="verdict-heading${blocked ? " block" : " pass"}"><span class="verdict-mark" aria-hidden="true">${blocked ? "!" : "✓"}</span>
    <div><h2>${blocked ? "发布阻断" : "验收通过"}</h2><p>基线 ${escaped(versionNumber(result.baseline))} <span aria-hidden="true">→</span> 候选 ${escaped(versionNumber(result.candidate))}</p></div></div>
    <dl class="summary-counts"><div><dt>验收用例</dt><dd>${totals.cases}</dd></div><div><dt>阻断</dt><dd class="${blocked ? "warning-text" : ""}">${totals.blocked}</dd></div><div><dt>通过</dt><dd>${totals.passed}</dd></div><div><dt>兼容变化</dt><dd>${totals.changes}</dd></div></dl>`;
}

function shownCases() {
  return report?.cases.filter(item => filter === "all" || item.verdict === filter) ?? [];
}

function updateCases() {
  const shown = shownCases();
  const active = shown.find(item => item.id === currentCase) ?? shown.find(item => item.verdict === "blocked") ?? shown[0];
  if (active?.id !== currentCase) currentPath = "";
  currentCase = active?.id ?? "";
  byId("case-amount").textContent = `${shown.length} / ${report.cases.length}`;
  for (const button of byId("case-filters").querySelectorAll("button")) {
    button.setAttribute("aria-pressed", String(button.dataset.filter === filter));
  }
  const existingScroll = list.querySelector(".case-rows")?.scrollTop ?? 0;
  list.innerHTML = shown.length ? `<ol class="case-rows">${shown.map(item => {
    const blockers = item.findings.filter(entry => entry.kind === "blocker").length;
    return `<li><button type="button" class="case-row" data-case="${escaped(item.id)}" aria-pressed="${item.id === currentCase}">
      <span class="case-label"><strong>${escaped(item.title)}</strong><small><span class="verb">${escaped(item.method)}</span><span class="endpoint">${escaped(item.path)}</span></small></span>
      <span class="case-state ${item.verdict}">${item.verdict === "blocked" ? `${blockers} 处阻断` : "通过"}</span></button></li>`;
  }).join("")}</ol>` : '<p class="empty-list">当前筛选没有用例。</p>';
  const rows = list.querySelector(".case-rows");
  if (rows) rows.scrollTop = existingScroll;
  showDetail(active);
}

function jsonRows(value) {
  const rows = [];
  function print(value, path, depth, prefix = "", suffix = "") {
    const indent = "  ".repeat(depth);
    if (value === null || typeof value !== "object") {
      rows.push({path, text:indent + prefix + (JSON.stringify(value) ?? "—") + suffix});
      return;
    }
    const array = Array.isArray(value);
    const open = array ? "[" : "{";
    const close = array ? "]" : "}";
    const entries = Object.entries(value);
    if (!entries.length) {
      rows.push({path, text:indent + prefix + open + close + suffix});
      return;
    }
    rows.push({path, text:indent + prefix + open});
    entries.forEach(([key, child], index) => {
      const property = /^[A-Za-z_$][A-Za-z0-9_$]*$/u.test(key) ? `.${key}` : `[${JSON.stringify(key)}]`;
      print(child, path + (array ? `[${key}]` : property), depth + 1, array ? "" : JSON.stringify(key) + ": ", index < entries.length - 1 ? "," : "");
    });
    rows.push({path:"", text:indent + close + suffix});
  }
  print(value, "$", 0);
  return rows;
}

function valueToken(line) {
  const tokenSeparator = /("(?:[^"\\]|\\.)*")(\s*:)?|\b(true|false|null)\b|(-?\d+(?:\.\d+)?)(?=,?$)/gu;
  const segments = [];
  let cursor = 0;
  for (const match of line.matchAll(tokenSeparator)) {
    const [token, quoted, colon, literal] = match;
    const className = colon ? "json-key" : quoted ? "json-string" : literal ? "json-literal" : "json-number";
    segments.push(escaped(line.slice(cursor,match.index)), `<span class="${className}">${escaped(token)}</span>`);
    cursor = match.index + token.length;
  }
  return segments.join("") + escaped(line.slice(cursor));
}

function response(label, item, side) {
  const message = item[side];
  const serialized = jsonRows(message.body);
  const hasPath = serialized.some(line => line.path === currentPath);
  const status = String(message.status ?? "—");
  const statusSelected = currentPath.startsWith("HTTP") || currentPath === "status";
  const missingPath = currentPath.startsWith("$") && !hasPath;
  return `<section class="response ${side}" aria-label="${escaped(label)}响应"><div class="response-head"><h4>${escaped(label)}</h4><span class="http-status${Number(status) >= 400 ? " http-error" : ""}${statusSelected ? " is-target" : ""}">${escaped(status)}</span></div>
    <pre tabindex="0" aria-label="${escaped(label)} JSON"><code>${serialized.map((line, index) =>
      `<span class="code-line${line.path && line.path === currentPath ? " is-target" : ""}" data-json-path="${escaped(line.path)}"><span class="line-no" aria-hidden="true">${index + 1}</span><span>${valueToken(line.text)}</span></span>`
    ).join("")}</code></pre>${missingPath ? `<p class="missing-path">响应中没有 <code>${escaped(currentPath)}</code></p>` : ""}</section>`;
}

function showDetail(item) {
  if (!item) {
    detail.innerHTML = '<div class="empty-detail">请选择有结果的用例。</div>';
    return;
  }
  const ignored = item.ignored.map(entry => ({...entry, kind:"ignored"}));
  const rows = [...item.findings, ...ignored];
  if (!rows.some(entry => entry.path === currentPath)) currentPath = item.findings[0]?.path ?? "";
  const verdict = item.verdict === "blocked" ? "阻断" : "通过";
  const request = suite.cases.find(entry => entry.id === item.id)?.requestBody;
  detail.innerHTML = `<header class="detail-head"><div><p class="path"><span class="verb">${escaped(item.method)}</span><code>${escaped(item.path)}</code></p>
    <h2 class="detail-title" tabindex="-1">${escaped(item.title)}</h2><p class="description">${escaped(item.description)}</p></div><span class="detail-verdict ${item.verdict}">${verdict}</span></header>
    <div class="detail-body">${request ? `<details class="request-body"><summary>请求体 <span>JSON</span></summary><pre><code>${escaped(JSON.stringify(request,null,2))}</code></pre></details>` : ""}
    <section class="finding-section" aria-labelledby="findings-heading"><h3 id="findings-heading">差异与检查项</h3>
    ${item.findings.length ? findingsMarkup(item.findings) : '<p class="no-findings">响应符合既有契约。</p>'}
    ${ignored.length ? `<details class="ignored-meta"${ignored.some(entry => entry.path === currentPath) ? " open" : ""}><summary>${ignored.length} 个动态字段已忽略</summary>${findingsMarkup(ignored)}</details>` : ""}</section>
    <div class="snapshot-heading"><h3>响应对照</h3><span>JSON</span></div><div class="snapshots">${response("基线 " + versionNumber(report.baseline), item, "baseline")}${response("候选 " + versionNumber(report.candidate), item, "candidate")}</div></div>`;
}

function findingsMarkup(entries) {
  return `<ul class="findings">${entries.map(entry => `<li><button type="button" class="finding ${escaped(entry.kind)}" data-path="${escaped(entry.path)}" aria-pressed="${entry.path === currentPath}">
    <span class="finding-label">${entry.kind === "blocker" ? "阻断" : entry.kind === "change" ? "兼容" : "已忽略"}</span><code>${escaped(entry.path)}</code><span class="finding-copy">${escaped(entry.message)}</span></button></li>`).join("")}</ul>`;
}

async function run() {
  if (running) return;
  running = true;
  report = undefined;
  runButton.disabled = true;
  runButton.setAttribute("aria-busy", "true");
  exportButton.disabled = true;
  workspace.hidden = true;
  summary.className = "run-summary";
  summary.innerHTML = '<p class="loading">正在执行两版接口的验收用例…</p>';
  releaseControls();
  try {
    report = await runRegression(candidateId);
    summary.className = `run-summary ${report.verdict}`;
    summary.innerHTML = counts(report);
    filter = "all";
    currentPath = "";
    if (params.get("case") !== currentCase) currentCase = "";
    updateCases();
    workspace.hidden = false;
    exportButton.disabled = false;
  } catch (error) {
    summary.className = "run-summary error";
    summary.innerHTML = `<p class="loading">验收未完成。${escaped(error?.message || "请稍后重试。")}</p>`;
  } finally {
    running = false;
    runButton.disabled = false;
    runButton.removeAttribute("aria-busy");
    releaseControls();
  }
}

function download() {
  if (!report) return;
  const link = document.createElement("a");
  link.href = URL.createObjectURL(new Blob([JSON.stringify(report, null, 2) + "\n"], {type:"application/json;charset=utf-8"}));
  link.download = `发布验收-${report.candidate.id}.json`;
  link.click();
  setTimeout(() => URL.revokeObjectURL(link.href), 1000);
}

byId("candidate-version").addEventListener("click", event => {
  const button = event.target.closest("[data-candidate]");
  if (!button || button.dataset.candidate === candidateId) return;
  candidateId = button.dataset.candidate;
  releaseControls();
  byId("candidate-version").querySelector('[aria-pressed="true"]').focus({preventScroll:true});
  report = undefined;
  exportButton.disabled = true;
  workspace.hidden = true;
  summary.className = "run-summary";
  summary.innerHTML = '<p class="loading">候选版本已切换。运行验收后可查看这一版本的结果。</p>';
});
byId("case-filters").addEventListener("click", event => {
  const button = event.target.closest("[data-filter]");
  if (!button || button.dataset.filter === filter) return;
  filter = button.dataset.filter;
  updateCases();
});
list.addEventListener("click", event => {
  const button = event.target.closest("[data-case]");
  if (!button) return;
  if (button.dataset.case !== currentCase) {
    currentPath = "";
    currentCase = button.dataset.case;
    updateCases();
  }
  if (matchMedia("(max-width: 820px)").matches) detail.querySelector(".detail-title")?.focus();
  else [...list.querySelectorAll("[data-case]")].find(control => control.dataset.case === currentCase)?.focus({preventScroll:true});
});
detail.addEventListener("click", event => {
  const button = event.target.closest("[data-path]");
  if (!button) return;
  currentPath = button.dataset.path;
  const wasIgnored = button.classList.contains("ignored");
  showDetail(report.cases.find(item => item.id === currentCase));
  if (wasIgnored) detail.querySelector(".ignored-meta").open = true;
  [...detail.querySelectorAll("[data-path]")].find(control => control.dataset.path === currentPath)?.focus({preventScroll:true});
  for (const code of detail.querySelectorAll("pre")) {
    const target = code.querySelector(".is-target");
    if (target) code.scrollTop = Math.max(0, target.offsetTop - code.clientHeight / 3);
  }
});
runButton.addEventListener("click", run);
exportButton.addEventListener("click", download);
releaseControls();
void run();
