import { evaluateRelease } from "../engine.mjs";
import { releases, suite } from "../fixtures.mjs";

export const executionMode = "http";

function serviceOrigin(origin) {
  if (origin === undefined) return "";
  if (typeof origin !== "string" || !/^http:\/\/127\.0\.0\.1:\d+$/u.test(origin)) {
    throw new Error("HTTP 演练仅支持本机样例服务。");
  }
  return origin;
}

async function collectResponses(release, origin, signal) {
  const entries = await Promise.all(suite.cases.map(async ({ id, method, path, requestBody }) => {
    const body = requestBody === undefined ? undefined : JSON.stringify(requestBody);
    const response = await fetch(`${origin}/fixtures/${release.id}${path}`, {
      method,
      body,
      headers: body === undefined ? undefined : { "Content-Type": "application/json" },
      signal,
      redirect: "error",
      cache: "no-store"
    });
    if (response.headers.get("X-Regression-Fixture") !== id) {
      throw new Error(`${method} ${path} 未收到对应的 ${release.label} 样例响应（HTTP ${response.status}）。`);
    }
    const payload = await response.text();
    return [id, { status: response.status, body: payload ? JSON.parse(payload) : null }];
  }));
  return Object.fromEntries(entries);
}

export async function runRegression(candidateReleaseId, { origin, signal } = {}) {
  const baseline = releases.find(release => release.id === "baseline");
  const candidate = releases.find(release => release.id === candidateReleaseId && release.id !== "baseline");
  if (!candidate) throw new RangeError("请选择有效的候选版本。");
  const base = serviceOrigin(origin);
  const requestSignal = signal ?? AbortSignal.timeout(12000);
  const [baselineResponses, candidateResponses] = await Promise.all([
    collectResponses(baseline, base, requestSignal),
    collectResponses(candidate, base, requestSignal)
  ]);
  return evaluateRelease({ suite, baseline, candidate, baselineResponses, candidateResponses });
}
