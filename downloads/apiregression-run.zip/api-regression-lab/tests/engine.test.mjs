import assert from "node:assert/strict";
import test from "node:test";
import {evaluateRelease} from "../engine.mjs";
import {getFixtureResponse, releases, suite} from "../fixtures.mjs";

const [baseline, broken, corrected] = releases;
const responsesFor = (releaseId) => Object.fromEntries(suite.cases.map(({id}) => [id, getFixtureResponse(releaseId, id)]));

function evaluate(candidate, candidateResponses = responsesFor(candidate.id)) {
  return evaluateRelease({suite, baseline, candidate, baselineResponses: responsesFor(baseline.id), candidateResponses});
}

test("candidate rc.1 is blocked for five traceable regressions despite successful HTTP responses", () => {
  const report = evaluate(broken);
  assert.equal(report.verdict, "blocked");
  assert.deepEqual(report.totals, {cases: 10, passed: 5, blocked: 5, changes: 5, ignored: 20});
  const details = report.cases.find(({id}) => id === "order-detail");
  assert.equal(details.baseline.status, 200);
  assert.equal(details.candidate.status, 200);
  assert.deepEqual(details.findings[0], {kind: "blocker", code: "TYPE_CHANGED", path: "$.data.amountCents",
    message: "字段类型由 number 变为 string。", expected: 29900, actual: "29900"});
  assert.deepEqual(report.cases.flatMap(({findings}) => findings.filter(({kind}) => kind === "blocker").map(({code}) => code)),
    ["TYPE_CHANGED", "FIELD_MISSING", "HTTP_STATUS_CHANGED", "STABLE_VALUE_CHANGED", "TYPE_CHANGED"]);
  const listFinding = report.cases.find(({id}) => id === "order-list").findings[0];
  assert.equal(listFinding.path, "$.data.orders[1].items[0].quantity");
  assert.equal(listFinding.expected, 2);
  assert.equal(listFinding.actual, undefined);
});

test("rc.2 passes including added, optional, display, and nullable fields", () => {
  const report = evaluate(corrected);
  assert.equal(report.verdict, "passed");
  assert.deepEqual(report.totals, {cases: 10, passed: 10, blocked: 0, changes: 5, ignored: 20});
  assert.deepEqual(report.cases.flatMap(({findings}) => findings.map(({code}) => code)),
    ["ALLOWED_VALUE_CHANGED", "OPTIONAL_FIELD_REMOVED", "FIELD_ADDED", "NULLABLE_VALUE_CHANGED", "ALLOWED_VALUE_CHANGED"]);
  assert.deepEqual(report.cases.find(({id}) => id === "shipment").ignored.map(({path}) => path),
    ["$.meta.requestId", "$.meta.servedAt"]);
});

test("allowing a value change does not allow an unexpected type or a new incompatible nullable value", () => {
  const candidate = responsesFor(corrected.id);
  candidate["order-summary"].body.data.displayLabel = false;
  candidate.refunds.body.data.refunds[0].settledAt = 100;
  const report = evaluate(corrected, candidate);
  assert.deepEqual(report.cases.flatMap(({findings}) => findings.filter(({kind}) => kind === "blocker").map(({path}) => path)),
    ["$.data.displayLabel", "$.data.refunds[0].settledAt"]);
});

test("optional and ignored fields may be omitted, but the pagination contract still fails closed", () => {
  const candidate = responsesFor(corrected.id);
  delete candidate["order-summary"].body.meta.requestId;
  delete candidate["empty-order-list"].body.data.nextCursor;
  candidate["order-list"].body.data.orders.pop();
  const report = evaluate(corrected, candidate);
  const optional = report.cases.find(({id}) => id === "order-summary");
  assert.equal(optional.verdict, "passed");
  assert(optional.ignored.some(({path}) => path === "$.meta.requestId"));
  assert.deepEqual(report.cases.flatMap(({findings}) => findings.filter(({kind}) => kind === "blocker").map(({code}) => code)),
    ["ARRAY_LENGTH_CHANGED", "FIELD_MISSING"]);
});

test("missing and malformed snapshots are distinguishable from a passing comparison", () => {
  const candidate = responsesFor(corrected.id);
  delete candidate["order-detail"];
  candidate["order-list"].status = "200";
  const report = evaluate(corrected, candidate);
  assert.equal(report.totals.blocked, 2);
  assert.equal(report.cases[0].findings[0].code, "RESPONSE_MISSING");
  assert.deepEqual(report.cases[0].candidate, {status: null, body: null});
});

test("fixture calls and rendered findings keep independent JSON snapshots", () => {
  const candidate = responsesFor(broken.id);
  const report = evaluate(broken, candidate);
  candidate["order-detail"].body.data.amountCents = "99900";
  assert.equal(report.cases[0].candidate.body.data.amountCents, "29900");
  assert.equal(getFixtureResponse(broken.id, "order-detail").body.data.amountCents, "29900");
  assert.throws(() => getFixtureResponse("missing", "order-detail"), RangeError);
  assert.throws(() => getFixtureResponse(baseline.id, "constructor"), RangeError);
});
