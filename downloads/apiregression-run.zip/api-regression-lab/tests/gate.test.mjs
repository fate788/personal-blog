import assert from "node:assert/strict";
import { spawnSync } from "node:child_process";
import { fileURLToPath } from "node:url";
import test from "node:test";

const entry = fileURLToPath(new URL("../scripts/gate.mjs", import.meta.url));

function gate(...args) {
  const result = spawnSync(process.execPath, [entry, ...args], { encoding: "utf8", timeout: 20000 });
  if (result.error) throw result.error;
  return result;
}

test("the command-line gate produces a report and blocks an incompatible release", () => {
  const run = gate("--candidate", "candidate-a");
  assert.equal(run.status, 1, run.stderr);
  const report = JSON.parse(run.stdout);
  assert.equal(report.candidate.id, "candidate-a");
  assert.equal(report.verdict, "blocked");
  const order = report.cases.find(entry => entry.id === "order-detail");
  assert.equal(order.baseline.status, 200);
  assert.equal(order.candidate.status, 200);
  assert(order.findings.some(finding => finding.path === "$.data.amountCents" && finding.kind === "blocker"));
});

test("compatible samples pass and invalid invocations fail without a report", () => {
  const run = gate("--candidate", "candidate-b");
  assert.equal(run.status, 0, run.stderr);
  assert.equal(JSON.parse(run.stdout).verdict, "passed");
  const invalid = gate("--candidate", "baseline");
  assert.equal(invalid.status, 2);
  assert.equal(invalid.stdout, "");
  assert.match(invalid.stderr, /--candidate/);
});
