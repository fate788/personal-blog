import assert from "node:assert/strict";
import { once } from "node:events";
import test from "node:test";
import { getFixtureResponse, releases, suite } from "../fixtures.mjs";
import { runRegression as runEmbedded } from "../portable/transport.mjs";
import { startServer } from "../server.mjs";
import { runRegression as runHttp } from "../static/transport.mjs";

async function service(t) {
  const server = startServer({ port: 0 });
  await once(server, "listening");
  t.after(() => new Promise(resolve => server.close(resolve)));
  return `http://127.0.0.1:${server.address().port}`;
}

function caseUrl(origin, release, testCase) {
  return `${origin}/fixtures/${release}${testCase.path}`;
}

function requestFor({ method, requestBody }) {
  return requestBody === undefined ? { method } : {
    method,
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(requestBody)
  };
}

test("fixed calls return the expected status and payload on the wire, including business errors", async t => {
  const origin = await service(t);
  for (const release of releases) {
    for (const testCase of suite.cases) {
      const fixture = getFixtureResponse(release.id, testCase.id);
      const response = await fetch(caseUrl(origin, release.id, testCase), requestFor(testCase));
      assert.equal(response.status, fixture.status, testCase.id);
      assert.equal(response.headers.get("X-Regression-Fixture"), testCase.id);
      const body = await response.text();
      assert.deepEqual(body ? JSON.parse(body) : null, fixture.body, testCase.id);
    }
  }
});

test("both candidate verdicts are identical across actual HTTP and offline embedded execution", async t => {
  const origin = await service(t);
  for (const [candidate, verdict] of [["candidate-a", "blocked"], ["candidate-b", "passed"]]) {
    const report = await runHttp(candidate, { origin });
    assert.equal(report.verdict, verdict);
    assert.deepEqual(report, await runEmbedded(candidate));
  }
  await assert.rejects(runHttp("baseline", { origin }), RangeError);
  await assert.rejects(runHttp("candidate-a", { origin: "https://example.invalid" }), /本机/u);
});

test("fixed routes reject unscheduled combinations and never tag them as fixture results", async t => {
  const origin = await service(t);
  const testCase = suite.cases.find(item => item.method === "POST" && item.requestBody !== undefined);
  assert(testCase);
  const address = caseUrl(origin, "baseline", testCase);
  const attempts = [
    [caseUrl(origin, "unknown", testCase), requestFor(testCase), 404],
    [address + "?free-form=1", requestFor(testCase), 404],
    [address, { method: "DELETE" }, 405],
    [address, { ...requestFor(testCase), body: '{"different":true}' }, 400],
    [address, { ...requestFor(testCase), body: "{" }, 400],
    [address, { method: "POST", body: "sample" }, 415],
    [address, { ...requestFor(testCase), body: '"' + "x".repeat(16_384) + '"' }, 413],
    [address, { ...requestFor(testCase), headers: { "Content-Type": "application/json", Origin: "https://example.invalid" } }, 403]
  ];
  for (const [url, options, code] of attempts) {
    const response = await fetch(url, options);
    assert.equal(response.status, code);
    assert.equal(response.headers.get("X-Regression-Fixture"), null);
    assert.equal(typeof (await response.json()).error, "string");
  }
});

test("the server exposes the frontend entry points and only listed files", async t => {
  const origin = await service(t);
  for (const [path, mime] of [["/", "text/html"], ["/styles.css", "text/css"], ["/app.mjs", "text/javascript"],
    ["/transport.mjs", "text/javascript"], ["/engine.mjs", "text/javascript"], ["/fixtures.mjs", "text/javascript"]]) {
    const reply = await fetch(origin + path, { method: "HEAD" });
    assert.equal(reply.status, 200, path);
    assert(reply.headers.get("Content-Type").startsWith(mime), path);
    assert.equal(await reply.text(), "");
  }
  assert.equal((await fetch(origin + "/package.json")).status, 404);
});
