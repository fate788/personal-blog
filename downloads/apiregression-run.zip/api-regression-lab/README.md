# 接口回归验收台

用同一组电商订单接口请求验证两个版本。在发布前检查 HTTP 状态、必填字段、字段类型和稳定的业务值。报告能定位到具体的 JSON 路径，保留基线与候选两份响应，区分阻断发布的差异、兼容变更和可忽略字段。

[打开公开验收台](https://fate788.github.io/personal-blog/demos/apiregression/index.html?v=1.1) · [打开金额断言](https://fate788.github.io/personal-blog/demos/apiregression/index.html?v=1.1&candidate=candidate-a&case=order-detail&path=%24.data.amountCents) · [博客作品页](https://fate788.github.io/personal-blog/projects/apiregression/index.html)

![接口回归验收台实屏](docs/preview.webp)

## 体验一次发布验收

1. 用订单服务 `1.8.0` 对照 `1.8.1-rc.1`。筛出阻断项，也可以搜「查询订单详情」或接口路径。打开金额断言，两版虽都返回 HTTP 200，`$.data.amountCents` 的实际值却从数字变成了字符串。
2. 对照两版证据值和原始响应。复制当前用例链接，可重新打开对应候选版、用例和断言。
3. 切到修订版 `1.8.1-rc.2` 重跑并导出报告，检查放行结论和仍需记录的兼容变化。

## 启动与命令行验收

需要 Node.js 20 或以上，无需安装依赖。Windows 可双击 `start-regression.cmd`，也可在项目目录运行：

```sh
node server.mjs
npm test
npm run build:demo
```

本机工作台地址为 [127.0.0.1:8824](http://127.0.0.1:8824/)。在本机运行时，工作台发送实际 HTTP 请求到同进程里的样例订单服务。公开演示和便携 HTML 使用同样的验收逻辑与固定响应。在 `dist/index.html` 可以离线复跑。

命令行会自动启动临时本机订单服务，执行对应版本的同一套验收并输出 JSON，运行结束后释放端口。GitHub Actions 用这条命令生成样例报告。

```sh
node scripts/gate.mjs --candidate candidate-a > blocked.json
node scripts/gate.mjs --candidate candidate-b > passed.json
```

退出码 `0` 代表验收通过，`1` 代表发现阻断项，`2` 代表参数或执行失败。演示数据是虚构订单。用例、两版响应和协议检查字段都可在 `fixtures.mjs` 核对。

设计参考了批量运行请求和把接口兼容性结论用于发布流程的做法。 [Postman 请求集合运行](https://learning.postman.com/docs/tests-and-scripts/running-collections/intro-to-collection-runs/) · [Pact Can I Deploy](https://docs.pact.io/pact_broker/can_i_deploy)
