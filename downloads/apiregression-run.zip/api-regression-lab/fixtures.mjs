export const releases = [
  {id: "baseline", label: "订单服务 1.8.0", description: "线上兼容基线，订单查询、创建及售后流程。"},
  {id: "candidate-a", label: "订单服务 1.8.1-rc.1", description: "首次候选版，调整金额、订单明细及异常响应。"},
  {id: "candidate-b", label: "订单服务 1.8.1-rc.2", description: "修订后的候选版，保留原有契约并新增可选信息。"},
];

const sharedIgnore = ["$.meta.requestId", "$.meta.servedAt"];

function testCase(id, title, group, method, path, description, rules = {}, requestBody) {
  return {id, title, group, method, path, description, requestBody, contract: {...rules, ignorePaths: sharedIgnore}};
}

export const suite = {
  id: "partner-order-api",
  title: "合作方订单 API 回归套件",
  subject: "零售订单服务 · 合作方集成",
  cases: [
    testCase("order-detail", "查询订单详情", "订单读取", "GET", "/v1/orders/ORD-7821",
      "合作方使用整数分对账，订单 ID、币种与金额含义必须稳定。"),
    testCase("order-list", "分页读取订单", "订单读取", "GET", "/v1/orders?limit=2",
      "合作方维护每个 SKU 的库存，列表元素的商品数量及分页游标参与校验。"),
    testCase("order-summary", "读取订单统计", "订单读取", "GET", "/v1/orders/summary",
      "核心计数保持稳定，展示标题可调整。弃用的看板链接可以缺省。",
      {allowValuePaths: ["$.data.displayLabel"], optionalPaths: ["$.data.legacyReportLink"]}),
    testCase("empty-order-list", "查询无结果订单", "订单读取", "GET", "/v1/orders?status=REJECTED",
      "查不到记录时保留空数组和空游标，客户端可以继续迭代列表。"),
    testCase("create-order", "创建一笔合作方订单", "订单写入", "POST", "/v1/orders",
      "客户端用 HTTP 201 区分创建成功。创建回执中的订单号和金额仍须可读。", {},
      {partnerOrderId: "PO-DEMO-801", sku: "LT-301", quantity: 2}),
    testCase("cancel-order", "取消待发货订单", "订单写入", "POST", "/v1/orders/ORD-7822/cancel",
      "调用端只有收到 CANCELLED 才会关闭订单和释放后续作业。", {}, {reason: "CUSTOMER_REQUEST"}),
    testCase("shipment", "查询发货信息", "履约售后", "GET", "/v1/orders/ORD-7821/shipment",
      "承运商与运单码供合作方展示和查询，新的通知方式可选。"),
    testCase("refunds", "读取退款记录", "履约售后", "GET", "/v1/orders/ORD-7822/refunds",
      "对已完成的历史退款补齐到账时间。旧记录允许 null，新值必须是字符串，金额仍按整数分读取。",
      {nullableTypes: {"$.data.refunds[*].settledAt": "string"}, allowValuePaths: ["$.data.refunds[*].settledAt"]}),
    testCase("order-not-found", "读取不存在的订单", "异常兼容", "GET", "/v1/orders/ORD-9999",
      "调用端根据 404 与业务错误码展示订单不存在。错误文字可调整。",
      {allowValuePaths: ["$.error.message"]}),
    testCase("invalid-order", "拒绝数量无效的订单", "异常兼容", "POST", "/v1/orders/validation-demo",
      "HTTP 422、业务错误码及具体字段用于保留订单表单错误提示。", {},
      {partnerOrderId: "PO-DEMO-802", sku: "LT-301", quantity: 0}),
  ],
};

const original = {
  "order-detail": {status: 200, body: {data: {id: "ORD-7821", partnerOrderId: "PO-DEMO-800", status: "SHIPPED",
    amountCents: 29900, currency: "CNY", items: [{sku: "LT-301", name: "显示器挂灯 Pro", quantity: 1, unitPriceCents: 29900}]}}},
  "order-list": {status: 200, body: {data: {orders: [
    {id: "ORD-7821", amountCents: 29900, items: [{sku: "LT-301", quantity: 1}]},
    {id: "ORD-7822", amountCents: 33800, items: [{sku: "LT-302", quantity: 2}]},
  ], nextCursor: "ORD-7822"}}},
  "order-summary": {status: 200, body: {data: {total: 12, open: 4, currency: "CNY", displayLabel: "订单概览", legacyReportLink: "/reports/orders"}}},
  "empty-order-list": {status: 200, body: {data: {orders: [], nextCursor: null}}},
  "create-order": {status: 201, body: {data: {id: "ORD-7823", partnerOrderId: "PO-DEMO-801", status: "OPEN", amountCents: 59800}}},
  "cancel-order": {status: 200, body: {data: {id: "ORD-7822", status: "CANCELLED", reversalQueued: true}}},
  "shipment": {status: 200, body: {data: {orderId: "ORD-7821", carrier: "华辰快运", trackingCode: "DEMO-88209738", delivered: false}}},
  "refunds": {status: 200, body: {data: {orderId: "ORD-7822", refunds: [{id: "RF-0441", amountCents: 33800, status: "SETTLED", settledAt: null}]}}},
  "order-not-found": {status: 404, body: {error: {code: "ORDER_NOT_FOUND", message: "订单不存在"}}},
  "invalid-order": {status: 422, body: {error: {code: "INVALID_ORDER", message: "订单数量不正确", fields: [{field: "quantity", reason: "MINIMUM_1"}]}}},
};

const compatibleChanges = {
  shipment: (response) => { response.body.data.notificationChannel = "APP"; },
  "order-summary": (response) => {
    response.body.data.displayLabel = "订单总览";
    delete response.body.data.legacyReportLink;
  },
  "order-not-found": (response) => { response.body.error.message = "未找到此订单，请核对编号"; },
  refunds: (response) => { response.body.data.refunds[0].settledAt = "2026-11-26T02:49:00Z"; },
};

const incompatibleChanges = {
  "order-detail": (response) => { response.body.data.amountCents = "29900"; },
  "order-list": (response) => { delete response.body.data.orders[1].items[0].quantity; },
  "create-order": (response) => { response.status = 200; },
  "cancel-order": (response) => { response.body.data.status = "CANCEL_PENDING"; },
  "invalid-order": (response) => { response.body.error.fields = null; },
};

export function getFixtureResponse(releaseId, caseId) {
  const releaseIndex = releases.findIndex(({id}) => id === releaseId);
  if (releaseIndex < 0 || !Object.hasOwn(original, caseId)) throw new RangeError("未找到版本或固定验收用例。");
  const response = structuredClone(original[caseId]);
  const caseIndex = suite.cases.findIndex(({id}) => id === caseId) + 1;
  response.body.meta = {
    requestId: `demo-${releaseIndex + 1}-${String(caseIndex).padStart(2, "0")}`,
    servedAt: `2026-11-27T0${releaseIndex + 1}:15:00Z`,
  };
  if (releaseIndex > 0 && Object.hasOwn(compatibleChanges, caseId)) compatibleChanges[caseId](response);
  if (releaseIndex === 1 && Object.hasOwn(incompatibleChanges, caseId)) incompatibleChanges[caseId](response);
  return response;
}
