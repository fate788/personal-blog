import { mkdir, readFile, writeFile } from "node:fs/promises";
import { dirname, resolve } from "node:path";

const output = resolve(process.argv[2] || "dist/index.html");
const read = (path) => readFile(new URL(path, import.meta.url), "utf8");
const moduleUrl = (source) => "data:text/javascript;base64," + Buffer.from(source.replaceAll("\r\n", "\n")).toString("base64");
const [engine, fixtures, embeddedTransport, app, css, html] = await Promise.all([
  read("../engine.mjs"), read("../fixtures.mjs"), read("transport.mjs"), read("../static/app.mjs"),
  read("../static/styles.css"), read("../static/index.html")
]);

function replaceImport(source, path, url) {
  return source.replaceAll(`"${path}"`, `"${url}"`).replaceAll(`'${path}'`, `'${url}'`);
}

const engineUrl = moduleUrl(engine);
const fixturesUrl = moduleUrl(fixtures);
const inlineShared = source => replaceImport(replaceImport(source, "../engine.mjs", engineUrl), "../fixtures.mjs", fixturesUrl);
const transportUrl = moduleUrl(inlineShared(embeddedTransport));
const appUrl = moduleUrl(replaceImport(inlineShared(app), "./transport.mjs", transportUrl));
const stylesheet = /<link\b[^>]*href=["'](?:\.\/)?styles\.css["'][^>]*>/iu;
const script = /<script\b[^>]*src=["'](?:\.\/)?app\.mjs["'][^>]*>\s*<\/script>/iu;
const policy = "default-src 'none'; style-src 'unsafe-inline'; script-src data:; img-src data:; connect-src 'none'; base-uri 'none'; form-action 'none'";
if (!stylesheet.test(html) || !script.test(html)) throw new Error("缺少工作台的 HTML 入口。");

const portable = html.replace("<head>", `<head>\n  <meta http-equiv="Content-Security-Policy" content="${policy}">`)
  .replace(stylesheet, () => `<style>\n${css}\n</style>`)
  .replace(script, () => `<script type="module" src="${appUrl}"></script>`);
await mkdir(dirname(output), { recursive: true });
await writeFile(output, portable.replaceAll("\r\n", "\n"), "utf8");
console.log(`已生成便携式接口回归验收台 ${output}`);
