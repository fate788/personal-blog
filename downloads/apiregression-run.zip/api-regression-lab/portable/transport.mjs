import { evaluateRelease } from "../engine.mjs";
import { getFixtureResponse, releases, suite } from "../fixtures.mjs";

export const executionMode = "embedded";

function collectResponses(release) {
  return Object.fromEntries(suite.cases.map(({ id }) => [id, getFixtureResponse(release.id, id)]));
}

export async function runRegression(candidateReleaseId, { signal } = {}) {
  if (signal?.aborted) throw signal.reason;
  const baseline = releases.find(release => release.id === "baseline");
  const candidate = releases.find(release => release.id === candidateReleaseId && release.id !== "baseline");
  if (!candidate) throw new RangeError("请选择有效的候选版本。");
  return evaluateRelease({ suite, baseline, candidate, baselineResponses: collectResponses(baseline),
    candidateResponses: collectResponses(candidate) });
}
