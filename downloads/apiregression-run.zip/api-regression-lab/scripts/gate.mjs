import { once } from "node:events";
import { parseArgs } from "node:util";
import { releases } from "../fixtures.mjs";
import { startServer } from "../server.mjs";
import { runRegression } from "../static/transport.mjs";

let service;
try {
  const { values } = parseArgs({ options: { candidate: { type: "string" } } });
  const candidates = releases.filter(release => release.id !== "baseline");
  if (!candidates.some(release => release.id === values.candidate)) {
    throw new Error(`请用 --candidate 选择候选版本（${candidates.map(release => release.id).join(" / ")}）。`);
  }
  service = startServer({ port: 0 });
  await once(service, "listening");
  const port = service.address().port;
  const report = await runRegression(values.candidate, {
    origin: `http://127.0.0.1:${port}`,
    signal: AbortSignal.timeout(15000)
  });
  if (!["passed", "blocked"].includes(report.verdict)) throw new Error("无法识别回归报告的结论。");
  process.stdout.write(JSON.stringify(report, null, 2) + "\n");
  process.exitCode = report.verdict === "passed" ? 0 : 1;
} catch (error) {
  process.stderr.write(`接口验收执行失败。${error.message}\n`);
  process.exitCode = 2;
} finally {
  if (service) await new Promise(resolve => service.close(resolve));
}
