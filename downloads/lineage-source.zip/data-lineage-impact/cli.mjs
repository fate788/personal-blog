import { open, stat, unlink } from 'node:fs/promises';
import { MAX_INPUT_BYTES, analyzeImpact, parseWorkspace } from './engine.mjs';
import { DEMO_DROP, DEMO_TYPE, DEMO_UNUSED } from './fixtures.mjs';

const CASES = new Map([['drop', DEMO_DROP], ['unused', DEMO_UNUSED], ['type', DEMO_TYPE]]);
const EXIT_CODES = new Map([['clear', 0], ['blocked', 2], ['review', 3]]);
const HELP = `数据血缘影响台 · 本机命令行

node cli.mjs --demo [--case drop|unused|type] [--out <新报告.json>]
node cli.mjs --input <工作区.json> [--out <新报告.json>]

  --demo           使用内置工作区
  --case <场景>    drop 退役金额字段（默认），unused 退役闲置字段，type 修改金额字段类型
  --input <文件>   使用本地 UTF-8 JSON 工作区，最大 ${MAX_INPUT_BYTES / 1024} KiB
  --out <新文件>   写入与标准输出相同的 UTF-8 JSON 报告，已有文件会保留
  --help, -h       查看帮助

报告包含结论、受影响的资产与字段、依赖路径和字段映射依据。
退出码 0 表示未发现下游影响，2 表示阻断，3 表示待复核，1 表示参数、工作区或文件错误。`;

class CliError extends Error {}

const ARGUMENTS = new Set(['--demo', '--case', '--input', '--out']);

function parseArguments(args) {
  const options = new Map();
  for (let index = 0; index < args.length; index += 1) {
    const key = args[index];
    if (!ARGUMENTS.has(key) || options.has(key)) {
      throw new CliError('存在未知或重复的参数。运行 node cli.mjs --help 查看用法。');
    }
    if (key === '--demo') {
      options.set(key, true);
      continue;
    }
    const value = args[index + 1];
    if (!value || value.startsWith('--')) throw new CliError(`${key} 缺少参数值。`);
    options.set(key, value);
    index += 1;
  }
  if (options.has('--demo') === options.has('--input')) throw new CliError('请选择 --demo 或 --input。');
  if (options.has('--case') && !options.has('--demo')) throw new CliError('--case 需要与 --demo 一起使用。');
  if (options.has('--case') && !CASES.has(options.get('--case'))) {
    throw new CliError('样例场景请选择 drop、unused 或 type。');
  }
  return options;
}

function checkFile(details) {
  if (!details.isFile() || details.size > MAX_INPUT_BYTES) {
    throw new CliError(`请提供不超过 ${MAX_INPUT_BYTES / 1024} KiB 的工作区 JSON 文件。`);
  }
}

async function readInput(path) {
  try {
    checkFile(await stat(path));
    const file = await open(path, 'r');
    try {
      checkFile(await file.stat());
      const buffer = Buffer.allocUnsafe(MAX_INPUT_BYTES + 1);
      let size = 0;
      while (size < buffer.length) {
        const { bytesRead } = await file.read(buffer, size, buffer.length - size, null);
        if (!bytesRead) break;
        size += bytesRead;
      }
      if (size > MAX_INPUT_BYTES) throw new CliError(`工作区超过 ${MAX_INPUT_BYTES / 1024} KiB。`);
      try {
        return new TextDecoder('utf-8', { fatal: true }).decode(buffer.subarray(0, size));
      } catch {
        throw new CliError('工作区 JSON 文件需要使用 UTF-8 编码。');
      }
    } finally {
      await file.close();
    }
  } catch (error) {
    if (error instanceof CliError) throw error;
    throw new CliError('无法读取指定的工作区文件。');
  }
}

async function writeReport(path, contents) {
  let file;
  try {
    file = await open(path, 'wx', 0o600);
  } catch (error) {
    if (error.code === 'EEXIST') throw new CliError('输出已存在，请指定一个新报告文件。');
    throw new CliError('无法创建指定的报告文件。');
  }
  try {
    try {
      await file.writeFile(contents, 'utf8');
    } finally {
      await file.close();
    }
  } catch {
    await unlink(path).catch(() => {});
    throw new CliError('写入影响报告失败。');
  }
}

function inspect(input) {
  try {
    return analyzeImpact(typeof input === 'string' ? parseWorkspace(input) : input);
  } catch (error) {
    if (error instanceof SyntaxError) throw new CliError('工作区文件不是有效的 JSON。');
    throw new CliError(error.message || '无法分析影响。');
  }
}

async function main(args) {
  if (args.length === 1 && ['--help', '-h'].includes(args[0])) {
    console.log(HELP);
    return 0;
  }
  const options = parseArguments(args);
  const input = options.has('--demo')
    ? CASES.get(options.get('--case') ?? 'drop')
    : await readInput(options.get('--input'));
  const result = inspect(input);
  if (!EXIT_CODES.has(result.status)) throw new CliError('影响分析返回未知结论。');
  const report = JSON.stringify(result, null, 2) + '\n';
  if (options.has('--out')) await writeReport(options.get('--out'), report);
  process.stdout.write(report);
  return EXIT_CODES.get(result.status);
}

try {
  process.exitCode = await main(process.argv.slice(2));
} catch (error) {
  console.error(error instanceof CliError ? error.message : '分析失败。请检查工作区和报告路径。');
  process.exitCode = 1;
}
