export const MAX_INPUT_BYTES = 262_144;
const MAX_ASSETS = 80;
const MAX_FIELDS = 500;
const MAX_INPUTS = 3_000;
const MAX_CHANGES = 20;
const MAX_EVIDENCE_STEPS = 16_000;
const ASSET_KINDS = new Set(['source', 'model', 'metric', 'dashboard']);
const RELATIONS = new Set(['value', 'filter', 'join', 'group']);
const OPERATIONS = new Set(['drop', 'type', 'nullable']);
const SEVERITY = { clear: 0, review: 1, blocked: 2 };

function invalid(message) {
  throw new TypeError(message);
}

function object(value, label) {
  if (!value || typeof value !== 'object' || Array.isArray(value)) invalid(`${label}应为对象。`);
  return value;
}

function list(value, min, max, label) {
  if (!Array.isArray(value) || value.length < min || value.length > max) invalid(`${label}应有 ${min} 到 ${max} 项。`);
  return value;
}

function text(value, max, label, optional = false) {
  if (typeof value !== 'string' || value.trim().length > max || (!optional && !value.trim()) || /[\0-\x1f\x7f]/u.test(value)) {
    invalid(`${label}应为${optional ? '至多' : '1 到'} ${max} 字的单行文字。`);
  }
  return value.trim();
}

const identifier = /^[A-Za-z0-9][A-Za-z0-9_-]{0,63}$/u;

function id(value, label) {
  if (typeof value !== 'string' || !identifier.test(value)) invalid(`${label}应为 1 到 64 个字母、数字、连字符或下划线，开头使用字母或数字。`);
  return value;
}

function ref(value, label) {
  if (typeof value !== 'string') invalid(`${label}应为 资产编号.字段编号。`);
  const parts = value.split('.');
  if (parts.length !== 2 || !parts.every(part => identifier.test(part))) invalid(`${label}应为 资产编号.字段编号。`);
  return value;
}

function flag(value, label) {
  if (typeof value !== 'boolean') invalid(`${label}应为布尔值。`);
  return value;
}

function option(value, allowed, label) {
  if (!allowed.has(value)) invalid(`${label}应为 ${[...allowed].join(' / ')} 之一。`);
  return value;
}

function reserve(map, key, value, label) {
  if (map.has(key)) invalid(`${label}重复：${key}。`);
  map.set(key, value);
}

const lexical = (first, second) => Number(first > second) - Number(first < second);
const severity = (first, second) => SEVERITY[first] >= SEVERITY[second] ? first : second;

function prepareWorkspace(raw) {
  const input = object(raw, '工作区');
  const catalog = object(input.catalog, '数据目录');
  const proposal = object(input.proposal, '变更方案');
  const assetIndex = new Map();
  const fields = new Map();
  const catalogName = text(catalog.name, 96, '目录名称');
  let dependencyCount = 0;

  const assets = list(catalog.assets, 1, MAX_ASSETS, '资产列表').map((rawAsset, position) => {
    const rawLabel = `第 ${position + 1} 项资产`;
    const asset = object(rawAsset, rawLabel);
    const assetId = id(asset.id, `${rawLabel}编号`);
    const label = `资产 ${assetId}`;
    const normalized = {
      id: assetId,
      name: text(asset.name, 96, `${label}名称`),
      kind: option(asset.kind, ASSET_KINDS, `${label}类型`),
      owner: text(asset.owner, 80, `${label}负责人`),
      description: text(asset.description, 320, `${label}说明`, true),
      fields: [],
    };
    reserve(assetIndex, assetId, normalized, '资产编号');

    normalized.fields = list(asset.fields, 1, MAX_FIELDS, `${label}字段列表`).map((rawField, position) => {
      const rawFieldLabel = `${label}的第 ${position + 1} 个字段`;
      const field = object(rawField, rawFieldLabel);
      const fieldId = id(field.id, `${rawFieldLabel}编号`);
      const key = `${assetId}.${fieldId}`;
      const inputKinds = new Map();
      const inputs = list(field.inputs, 0, MAX_FIELDS * RELATIONS.size, `${key} 的输入`).map((rawInput, position) => {
        const inputLabel = `${key} 的第 ${position + 1} 个输入`;
        const input = object(rawInput, inputLabel);
        const from = ref(input.field, `${inputLabel}字段`);
        const kind = option(input.kind, RELATIONS, `${inputLabel}关系`);
        if (++dependencyCount > MAX_INPUTS) invalid(`目录最多支持 ${MAX_INPUTS} 条字段依赖。`);
        reserve(inputKinds, `${from} (${kind})`, true, `${key} 的输入关系`);
        return { field: from, kind, description: text(input.description, 320, `${inputLabel}说明`, true) };
      });
      const normalized = {
        id: fieldId,
        name: text(field.name, 96, `${key} 名称`),
        type: text(field.type, 80, `${key} 类型`),
        nullable: flag(field.nullable, `${key} 可空性`),
        inputs,
      };
      reserve(fields, key, { field: normalized, assetId }, '字段编号');
      if (fields.size > MAX_FIELDS) invalid(`目录最多支持 ${MAX_FIELDS} 个字段。`);
      return normalized;
    });
    return normalized;
  });

  const edges = [];
  for (const [to, { field }] of fields) {
    for (const input of field.inputs) {
      if (!fields.has(input.field)) invalid(`${to} 引用了不存在的字段 ${input.field}。`);
      edges.push({ from: input.field, to, kind: input.kind, description: input.description });
    }
  }
  edges.sort((first, second) => lexical(first.from, second.from) || lexical(first.to, second.to) || lexical(first.kind, second.kind));
  const outgoing = verifyDag(fields, edges);

  const proposalName = text(proposal.name, 96, '方案名称');
  const seenChanges = new Map();
  const changes = list(proposal.changes, 1, MAX_CHANGES, '变更列表').map((rawChange, position) => {
    const label = `第 ${position + 1} 项变更`;
    const change = object(rawChange, label);
    const key = ref(change.field, `${label}字段`);
    const target = fields.get(key)?.field;
    if (!target) invalid(`${label}引用了不存在的字段 ${key}。`);
    const op = option(change.op, OPERATIONS, `${label}操作`);
    reserve(seenChanges, key, op, '变更字段');

    if (op === 'drop') {
      if (Object.hasOwn(change, 'to')) invalid(`${label}删除字段时无需填写目标值。`);
      return { field: key, op };
    }
    const to = op === 'type' ? text(change.to, 80, `${label}目标类型`) : flag(change.to, `${label}目标可空性`);
    const unchanged = op === 'type' ? to.replace(/\s+/gu, '').toLowerCase() === target.type.replace(/\s+/gu, '').toLowerCase() : to === target.nullable;
    if (unchanged) invalid(`${label}的目标值和原值相同。`);
    return { field: key, op, to };
  });
  const paths = prepareDependencies(changes, outgoing);

  return {
    workspace: { catalog: { name: catalogName, assets }, proposal: { name: proposalName, changes } },
    edges, fields, paths,
  };
}

function verifyDag(fields, edges) {
  const outgoing = new Map([...fields.keys()].map(key => [key, []]));
  const incoming = new Map([...fields.keys()].map(key => [key, 0]));
  for (const edge of edges) {
    outgoing.get(edge.from).push(edge);
    incoming.set(edge.to, incoming.get(edge.to) + 1);
  }
  const ready = [...incoming.keys()].filter(key => incoming.get(key) === 0);
  for (let index = 0; index < ready.length; index += 1) {
    for (const { to } of outgoing.get(ready[index])) {
      const remaining = incoming.get(to) - 1;
      incoming.set(to, remaining);
      if (remaining === 0) ready.push(to);
    }
  }
  if (ready.length !== fields.size) {
    const key = [...incoming.keys()].filter(key => incoming.get(key) > 0).sort(lexical)[0];
    invalid(`目录存在循环依赖，${key} 所在的剩余依赖无法拓扑排序。`);
  }
  return outgoing;
}

export function parseWorkspace(text) {
  if (typeof text !== 'string' || !text.trim()) invalid('请输入 JSON 工作区。');
  if (text.length > MAX_INPUT_BYTES || new TextEncoder().encode(text).length > MAX_INPUT_BYTES) invalid('工作区文件不能超过 256 KiB。');
  let input;
  try {
    input = JSON.parse(text.replace(/^\uFEFF/u, ''));
  } catch {
    invalid('工作区不是有效的 JSON，请检查文件格式。');
  }
  return prepareWorkspace(input).workspace;
}

function nearestDependencies(root, outgoing, account) {
  const walk = [root];
  const previous = new Map([[root, null]]);
  const depths = new Map([[root, 0]]);
  for (let index = 0; index < walk.length; index += 1) {
    for (const edge of outgoing.get(walk[index])) {
      if (previous.has(edge.to)) continue;
      const depth = depths.get(edge.from) + 1;
      account(depth);
      previous.set(edge.to, edge);
      depths.set(edge.to, depth);
      walk.push(edge.to);
    }
  }
  previous.delete(root);
  return previous;
}

function prepareDependencies(changes, outgoing) {
  let steps = 0;
  function account(depth) {
    steps += depth;
    if (steps > MAX_EVIDENCE_STEPS) {
      invalid('方案的影响路径超过 16000 步，请拆分变更方案，或缩小目录到本次复核所需的资产。');
    }
  }
  return new Map(changes.map(({ field }) => [field, nearestDependencies(field, outgoing, account)]));
}

function recoverPath(endpoint, previous) {
  const steps = [];
  for (let edge = previous.get(endpoint); edge; edge = previous.get(edge.from)) steps.push(edge);
  return steps.reverse();
}

export function analyzeImpact(raw) {
  const { workspace, fields, edges, paths } = prepareWorkspace(raw);
  const reached = new Map();
  let status = 'clear';

  const changes = workspace.proposal.changes.map(change => {
    const { field: root, op, to } = change;
    const { type, nullable } = fields.get(root).field;
    const before = { type, nullable };
    const after = op === 'drop' ? null : { ...before, [op]: to };
    const previous = paths.get(root);
    const changeStatus = previous.size === 0 ? 'clear' : op === 'drop' ? 'blocked' : 'review';
    status = severity(status, changeStatus);
    for (const key of previous.keys()) {
      const steps = recoverPath(key, previous);
      const impact = reached.get(key) ?? { field: key, assetId: fields.get(key).assetId, distance: steps.length, status: 'clear', paths: [] };
      impact.distance = Math.min(impact.distance, steps.length);
      impact.status = severity(impact.status, changeStatus);
      impact.paths.push({ root, steps });
      reached.set(key, impact);
    }
    return { field: root, op, before, after, status: changeStatus };
  });

  const impacts = [...reached.values()].sort((first, second) => first.distance - second.distance || lexical(first.field, second.field));
  const grouped = new Map();
  for (const impact of impacts) {
    const { assetId, distance } = impact;
    const asset = grouped.get(assetId) ?? { id: assetId, distance, status: 'clear', fields: [] };
    asset.status = severity(asset.status, impact.status);
    asset.fields.push(impact.field);
    grouped.set(assetId, asset);
  }
  const assets = [...grouped.values()].sort((first, second) => first.distance - second.distance || lexical(first.id, second.id));
  const directAssets = assets.filter(asset => asset.distance === 1).length;
  return {
    status, changes, impacts, assets,
    totals: {
      changed: changes.length,
      impactedFields: impacts.length,
      impactedAssets: assets.length,
      directAssets,
      indirectAssets: assets.length - directAssets,
    },
    edges,
  };
}
