import { analyzeImpact, MAX_INPUT_BYTES, parseWorkspace } from '../engine.mjs';
import { DEMO_DROP, DEMO_TYPE, DEMO_UNUSED } from '../fixtures.mjs';

const CASES = { drop: DEMO_DROP, unused: DEMO_UNUSED, type: DEMO_TYPE };
const ASSET_KIND = { source: '源表', model: '数据模型', metric: '指标', dashboard: '看板' };
const REVIEW = { blocked: '建议阻断', review: '需要复核', clear: '无已知影响' };
const RELATION = { value: '值依赖', filter: '过滤条件', join: '关联条件', group: '分组条件' };
const OPERATION = { drop: '字段删除', type: '类型变更', nullable: '可空性变更' };
const PAGE_SIZE = 12;
const $ = id => document.getElementById(id);

const query = new URLSearchParams(location.search);
const initialCase = Object.hasOwn(CASES, query.get('case')) ? query.get('case') : 'drop';
const state = {
  example: initialCase, view: 'impact', workspace: null, result: null, index: null,
  selectedAsset: '', selectedField: '', limit: PAGE_SIZE, importToken: 0,
};

function element(tag, className, value) {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (value !== undefined) node.textContent = value;
  return node;
}

function button(className, value) {
  const node = element('button', className, value);
  node.type = 'button';
  return node;
}

function linkKey(from, to, kind) {
  return `${from}>${to}:${kind}`;
}

function indexWorkspace(workspace, result) {
  const assets = new Map(workspace.catalog.assets.map(asset => [asset.id, asset]));
  const fields = new Map();
  for (const asset of assets.values()) {
    for (const field of asset.fields) fields.set(`${asset.id}.${field.id}`, { field, asset });
  }
  const roots = new Map(result.changes.map(change => [change.field, change]));
  return {
    assets, fields, roots,
    rootAssets: new Set(result.changes.map(change => fields.get(change.field).asset.id)),
    affected: new Map(result.assets.map(asset => [asset.id, asset])),
    impacts: new Map(result.impacts.map(impact => [impact.field, impact])),
  };
}

function announce(message = '', tone = 'success') {
  const notice = $('notice');
  notice.textContent = message;
  notice.dataset.tone = tone;
  notice.hidden = !message;
}

function fieldChangeText(change) {
  if (change.op === 'drop') return `${change.before.type} · ${change.before.nullable ? '可为空' : '非空'} → 删除`;
  if (change.op === 'type') return `${change.before.type} → ${change.after.type}`;
  return `${change.before.nullable ? '可为空' : '非空'} → ${change.after.nullable ? '可为空' : '非空'}`;
}

function renderOverview() {
  const { workspace, result } = state;
  $('catalog-name').textContent = `${workspace.catalog.name} · ${workspace.catalog.assets.length} 项资产`;
  $('proposal-title').textContent = workspace.proposal.name;
  $('workspace-origin').textContent = state.example ? '合成样例' : '本地导入';
  const operations = new Set(result.changes.map(change => OPERATION[change.op]));
  $('change-operation').textContent = operations.size === 1 ? [...operations][0] : '多种字段变更';
  const root = result.changes[0];
  const labels = [element('code', '', root.field), element('span', '', fieldChangeText(root))];
  if (result.changes.length > 1) labels.push(element('span', '', `共 ${result.changes.length} 项变更，详见影响报告`));
  $('change-fields').replaceChildren(...labels);
  $('review').dataset.status = result.status;
  $('review-status').textContent = REVIEW[result.status];
  $('impact-total').textContent = result.totals.impactedAssets;
  $('field-total').textContent = result.totals.impactedFields;
  $('direct-total').textContent = result.totals.directAssets;
  $('review-note').textContent = {
    blocked: '当前目录中仍有字段依赖待删除项，建议先迁移这些依赖。',
    review: '当前目录中存在下游依赖，需要复核字段兼容性。',
    clear: '当前导入的血缘目录中未找到变更字段的下游依赖。',
  }[result.status];
  for (const control of $('case-switch').querySelectorAll('[data-case]')) {
    control.setAttribute('aria-pressed', String(control.dataset.case === state.example));
  }
  $('download-report').disabled = false;
  $('download-workspace').disabled = false;
}

function groupedAssets() {
  const { assets, rootAssets, affected } = state.index;
  const groups = new Map();
  for (const asset of assets.values()) {
    const root = rootAssets.has(asset.id);
    const impact = affected.get(asset.id);
    if (!root && !impact && state.view === 'impact') continue;
    const distance = root ? 0 : impact?.distance ?? Infinity;
    const group = groups.get(distance) ?? [];
    group.push({ asset, impact, root });
    groups.set(distance, group);
  }
  return [...groups].sort(([first], [second]) => first - second);
}

function renderGraph() {
  const lanes = groupedAssets().map(([distance, entries]) => {
    const lane = element('section', 'lane');
    const title = distance === 0 ? '变更起点' : Number.isFinite(distance) ? `${distance} 跳下游` : '其他资产';
    lane.setAttribute('aria-label', title);
    const content = element('div', 'lane-nodes');
    for (const { asset, impact, root } of entries) {
      const item = button('node');
      item.dataset.asset = asset.id;
      item.dataset.tone = root ? 'root' : impact?.status ?? 'clear';
      item.setAttribute('aria-pressed', String(asset.id === state.selectedAsset));
      item.append(element('span', 'node-kind', ASSET_KIND[asset.kind]), element('strong', 'node-name', asset.name), element('span', 'node-ref', asset.id));
      content.append(item);
    }
    lane.append(element('h3', 'lane-title', title), content);
    return lane;
  });
  $('graph-lanes').replaceChildren(...lanes);
  $('graph-impact').setAttribute('aria-pressed', String(state.view === 'impact'));
  $('graph-all').setAttribute('aria-pressed', String(state.view === 'all'));
  $('graph-note').textContent = state.view === 'all'
    ? '完整血缘展示当前目录的全部资产与已知依赖。资产之间的连线可对应多条字段关系。'
    : state.result.totals.impactedAssets
      ? '这里只显示变更字段及其下游，亮线标记当前所选字段的影响路径。'
      : '未找到变更字段的下游依赖。切换到完整血缘可以查看其他字段的关系。';
  queueGraph();
}

function getVisibleLinks() {
  const { fields, roots, impacts } = state.index;
  const selected = impacts.get(state.selectedField);
  const highlighted = new Set(selected?.paths.flatMap(path => path.steps.map(step => linkKey(step.from, step.to, step.kind))));
  const reachable = ref => roots.has(ref) || impacts.has(ref);
  const pairs = new Map();
  for (const edge of state.result.edges) {
    const relevant = reachable(edge.from) && reachable(edge.to);
    if (!relevant && state.view === 'impact') continue;
    const fromId = fields.get(edge.from).asset.id;
    const toId = fields.get(edge.to).asset.id;
    if (fromId === toId) continue;
    const type = edge.kind === 'value' ? 'value' : 'condition';
    const key = linkKey(fromId, toId, type);
    const link = pairs.get(key) || { fromId, toId, type, relevant: false, highlight: false };
    link.relevant ||= relevant;
    link.highlight ||= highlighted.has(linkKey(edge.from, edge.to, edge.kind));
    pairs.set(key, link);
  }
  return [...pairs.values()].sort((first, second) => Number(first.highlight) - Number(second.highlight));
}

function drawConnection(context, from, to, type, relevant, highlight, vertical) {
  const stripe = type === 'value' ? 0 : 1;
  const direction = vertical ? Math.sign(to.top - from.top) : Math.sign(to.left - from.left);
  const sx = vertical ? from.left + from.width * (0.47 + stripe * 0.10) : direction < 0 ? from.left : from.right;
  const sy = vertical ? direction < 0 ? from.top : from.bottom : from.top + from.height * (0.43 + stripe * 0.14);
  const tx = vertical ? to.left + to.width * (0.44 + stripe * 0.10) : direction < 0 ? to.right : to.left;
  const ty = vertical ? direction < 0 ? to.bottom : to.top : to.top + to.height * (0.43 + stripe * 0.14);
  const bendX = (sx + tx) / 2;
  const bendY = (sy + ty) / 2;
  context.strokeStyle = highlight ? (stripe ? '#e4d49e' : '#fac28a') : relevant ? (stripe ? '#a0b380' : '#c68b5f') : '#527482';
  context.fillStyle = context.strokeStyle;
  context.globalAlpha = highlight ? 1 : relevant ? 0.82 : 0.45;
  context.lineWidth = highlight ? 2.2 : 1.35;
  context.setLineDash(stripe ? [4, 3] : []);
  context.beginPath();
  context.moveTo(sx, sy);
  if (vertical) context.bezierCurveTo(sx, bendY, tx, bendY, tx, ty);
  else if (direction === 0) context.bezierCurveTo(sx + 19, sy, tx + 19, ty, tx, ty);
  else context.bezierCurveTo(bendX, sy, bendX, ty, tx, ty);
  context.stroke();
  context.setLineDash([]);
  context.beginPath();
  if (vertical) {
    const signed = direction >= 0 ? 1 : -1;
    context.moveTo(tx, ty);
    context.lineTo(tx - 3.2, ty - signed * 5);
    context.lineTo(tx + 3.2, ty - signed * 5);
  } else {
    const signed = direction > 0 ? 1 : -1;
    context.moveTo(tx, ty);
    context.lineTo(tx - signed * 5, ty - 3.2);
    context.lineTo(tx - signed * 5, ty + 3.2);
  }
  context.closePath();
  context.fill();
}

function drawGraph() {
  const canvas = $('graph-links');
  const outer = $('graph').getBoundingClientRect();
  const width = Math.round(outer.width);
  const height = Math.round(outer.height);
  if (!width || !height || !state.index) return;
  const dpr = Math.min(window.devicePixelRatio || 1, 2, 3600 / Math.max(width, height));
  canvas.width = Math.max(1, Math.round(width * dpr));
  canvas.height = Math.max(1, Math.round(height * dpr));
  const context = canvas.getContext('2d');
  if (!context) return;
  context.scale(dpr, dpr);
  const positions = new Map([...$('graph-lanes').querySelectorAll('[data-asset]')].map(button => {
    const box = button.getBoundingClientRect();
    const left = box.left - outer.left;
    const top = box.top - outer.top;
    return [button.dataset.asset, { left, top, right: left + box.width, bottom: top + box.height, width: box.width, height: box.height }];
  }));
  const stack = window.matchMedia('(max-width:660px)').matches;
  for (const link of getVisibleLinks()) {
    const from = positions.get(link.fromId);
    const to = positions.get(link.toId);
    if (!from || !to) continue;
    drawConnection(context, from, to, link.type, link.relevant, link.highlight, stack);
  }
}

let scheduledFrame = 0;
function queueGraph() {
  if (!scheduledFrame) scheduledFrame = requestAnimationFrame(() => {
    scheduledFrame = 0;
    drawGraph();
  });
}

function displayFields(asset) {
  const refs = asset.fields.map(field => `${asset.id}.${field.id}`);
  const root = refs.filter(ref => state.index.roots.has(ref));
  const impacted = refs.filter(ref => state.index.impacts.has(ref) && !state.index.roots.has(ref));
  const other = refs.filter(ref => !state.index.roots.has(ref) && !state.index.impacts.has(ref));
  return [...root, ...impacted, ...other];
}

function renderPaths(ref) {
  const heading = $('path-heading');
  const count = $('path-count');
  const target = $('path-list');
  const rootInfo = state.index.roots.get(ref);
  const impact = state.index.impacts.get(ref);
  const { field } = state.index.fields.get(ref);
  $('field-detail').textContent = `${field.name} · ${field.type} · ${field.nullable ? '可为空' : '非空'}`;
  if (!impact) {
    heading.textContent = rootInfo ? '变更字段' : '影响证据';
    count.textContent = '';
    const message = rootInfo
      ? `${fieldChangeText(rootInfo)}。${rootInfo.status === 'clear' ? '在当前目录中未发现下游依赖。' : '可在图中选择下游资产复核路径。'}`
      : '当前变更的影响路径未到达此字段。';
    const nodes = [element('p', 'evidence-empty', message)];
    if (state.view === 'all' && field.inputs.length) {
      heading.textContent = '字段上游';
      count.textContent = `${field.inputs.length} 条依赖`;
      nodes.push(renderSteps(field.inputs, 'field'));
    }
    target.replaceChildren(...nodes);
    target.scrollTop = 0;
    return;
  }
  heading.textContent = '影响证据';
  count.textContent = `${impact.paths.length} 条来源路径 · 最短 ${impact.distance} 跳`;
  const paths = impact.paths.map(path => {
    const section = element('div', 'evidence-route');
    section.append(element('code', 'route-root', path.root), renderSteps(path.steps, 'to'));
    return section;
  });
  target.replaceChildren(...paths);
  target.scrollTop = 0;
}

function renderSteps(steps, property) {
  const list = element('ol', 'route');
  for (const step of steps) {
    const row = element('li');
    row.dataset.edge = step.kind;
    const kind = element('span', 'route-kind', RELATION[step.kind]);
    kind.dataset.kind = step.kind;
    row.append(element('code', '', step[property]), kind);
    if (step.description) row.append(element('p', '', step.description));
    list.append(row);
  }
  return list;
}

function renderInspector() {
  const { assets, affected, rootAssets } = state.index;
  const asset = assets.get(state.selectedAsset);
  const status = affected.get(asset.id)?.status;
  $('asset-kind').textContent = ASSET_KIND[asset.kind];
  const flag = $('asset-status');
  flag.dataset.tone = status || 'clear';
  flag.textContent = rootAssets.has(asset.id) ? '变更起点' : status ? '受影响' : '未受此变更影响';
  $('selected-asset').textContent = asset.name;
  $('asset-ref').textContent = asset.id;
  $('asset-owner').textContent = asset.owner;
  $('asset-description').textContent = asset.description;
  $('asset-description').hidden = !asset.description;
  const buttons = displayFields(asset).map(ref => {
    const item = button('', state.index.fields.get(ref).field.id);
    item.dataset.field = ref;
    item.title = state.index.fields.get(ref).field.name;
    item.setAttribute('aria-pressed', String(ref === state.selectedField));
    return item;
  });
  $('asset-fields').replaceChildren(...buttons);
  renderPaths(state.selectedField);
}

function renderImpactList() {
  const { result, index } = state;
  $('affected-count').textContent = `${result.totals.directAssets} 项直接下游 · ${result.totals.indirectAssets} 项间接下游`;
  const rows = result.assets.slice(0, state.limit).map(impact => {
    const asset = index.assets.get(impact.id);
    const row = button('impact-entry');
    row.dataset.impact = asset.id;
    row.setAttribute('aria-pressed', String(asset.id === state.selectedAsset));
    const detail = element('span');
    detail.append(element('strong', '', asset.name), element('small', '', `${ASSET_KIND[asset.kind]} · ${asset.owner} · ${impact.fields.length} 个受影响字段`));
    row.append(detail, element('span', 'impact-flag', impact.distance === 1 ? '直接下游' : `${impact.distance} 跳下游`));
    return row;
  });
  $('impact-list').replaceChildren(...(rows.length ? rows : [element('p', 'evidence-empty', '当前目录中没有已知的受影响资产。')]));
  $('more-impacts').hidden = result.assets.length <= state.limit;
}

function selectAsset(assetId, focus = false) {
  if (!state.index.assets.has(assetId)) return;
  state.selectedAsset = assetId;
  state.selectedField = displayFields(state.index.assets.get(assetId))[0];
  for (const node of $('graph-lanes').querySelectorAll('[data-asset]')) {
    node.setAttribute('aria-pressed', String(assetId === node.dataset.asset));
  }
  for (const node of $('impact-list').querySelectorAll('[data-impact]')) {
    node.setAttribute('aria-pressed', String(assetId === node.dataset.impact));
  }
  renderInspector();
  queueGraph();
  if (focus) $('selected-asset').focus();
}

function setScope(view) {
  state.view = view;
  const { rootAssets, affected } = state.index;
  if (view === 'impact' && !rootAssets.has(state.selectedAsset) && !affected.has(state.selectedAsset)) {
    selectAsset([...rootAssets][0]);
  } else {
    renderPaths(state.selectedField);
  }
  renderGraph();
}

function showWorkspace(workspace, example, preferredAsset = null) {
  const result = analyzeImpact(workspace);
  const index = indexWorkspace(workspace, result);
  state.workspace = workspace;
  state.result = result;
  state.index = index;
  state.example = example;
  state.limit = PAGE_SIZE;
  state.view = 'impact';
  const known = index.rootAssets.has(preferredAsset) || index.affected.has(preferredAsset);
  const dashboards = result.assets.filter(asset => index.assets.get(asset.id).kind === 'dashboard');
  const aim = dashboards.at(-1)?.id ?? result.assets.at(-1)?.id ?? [...index.rootAssets][0];
  state.selectedAsset = known ? preferredAsset : aim;
  state.selectedField = displayFields(index.assets.get(state.selectedAsset))[0];
  renderOverview();
  renderGraph();
  renderInspector();
  renderImpactList();
  $('graph-scroll').scrollTo(0, 0);
}

function downloadJson(value, filename) {
  const blob = new Blob([`${JSON.stringify(value, null, 2)}\n`], { type: 'application/json;charset=utf-8' });
  const location = URL.createObjectURL(blob);
  const link = element('a');
  link.href = location;
  link.download = filename;
  document.body.append(link);
  link.click();
  link.remove();
  setTimeout(() => URL.revokeObjectURL(location), 1_000);
}

function downloadReport() {
  const { workspace, result, index } = state;
  const assets = result.assets.map(impact => {
    const asset = index.assets.get(impact.id);
    return { ...impact, name: asset.name, kind: asset.kind, owner: asset.owner };
  });
  downloadJson({ catalog: workspace.catalog.name, proposal: workspace.proposal.name, status: result.status,
    totals: result.totals, changes: result.changes, assets, impacts: result.impacts }, '字段变更影响报告.json');
}

async function importWorkspace(event) {
  const input = event.currentTarget;
  const file = input.files[0];
  input.value = '';
  if (!file) return;
  const token = ++state.importToken;
  try {
    if (file.size > MAX_INPUT_BYTES) throw new Error('请选择不超过 256 KiB 的 JSON 文件。');
    const bytes = await file.arrayBuffer();
    if (state.importToken !== token) return;
    let text;
    try { text = new TextDecoder('utf-8', { fatal: true }).decode(bytes); }
    catch { throw new Error('文件需要使用 UTF-8 编码。'); }
    showWorkspace(parseWorkspace(text), null);
    announce(`已导入 ${file.name}。`);
  } catch (error) {
    if (state.importToken === token) announce(error.message || '读取工作区失败。', 'error');
  }
}

$('case-switch').addEventListener('click', event => {
  const id = event.target.closest('[data-case]')?.dataset.case;
  if (!id || id === state.example) return;
  state.importToken += 1;
  showWorkspace(CASES[id], id);
  announce();
});
$('graph-impact').addEventListener('click', () => setScope('impact'));
$('graph-all').addEventListener('click', () => setScope('all'));
$('graph-lanes').addEventListener('click', event => {
  const id = event.target.closest('[data-asset]')?.dataset.asset;
  if (id) selectAsset(id, window.matchMedia('(max-width:660px)').matches);
});
$('asset-fields').addEventListener('click', event => {
  const ref = event.target.closest('[data-field]')?.dataset.field;
  if (!ref || state.selectedField === ref) return;
  state.selectedField = ref;
  for (const control of $('asset-fields').querySelectorAll('[data-field]')) {
    control.setAttribute('aria-pressed', String(control.dataset.field === ref));
  }
  renderPaths(ref);
  queueGraph();
});
$('impact-list').addEventListener('click', event => {
  const id = event.target.closest('[data-impact]')?.dataset.impact;
  if (id) selectAsset(id, true);
});
$('more-impacts').addEventListener('click', () => {
  const previous = state.limit;
  state.limit += PAGE_SIZE;
  renderImpactList();
  $('impact-list').children[previous]?.focus();
});
$('download-report').addEventListener('click', downloadReport);
$('download-workspace').addEventListener('click', () => downloadJson(state.workspace, '数据血缘工作区.json'));
$('pick-workspace').addEventListener('click', () => $('import-workspace').click());
$('import-workspace').addEventListener('change', importWorkspace);
new ResizeObserver(queueGraph).observe($('graph'));

showWorkspace(CASES[initialCase], initialCase, query.get('asset'));
