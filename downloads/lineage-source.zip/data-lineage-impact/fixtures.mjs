const input = (field, kind, description) => ({ field, kind, description });
const field = (id, name, type, inputs = [], nullable = false) => ({ id, name, type, nullable, inputs });
const asset = (id, name, kind, owner, description, fields) => ({ id, name, kind, owner, description, fields });

const catalog = {
  name: '零售交易数据目录',
  assets: [
    asset('orders_raw', '订单原始表', 'source', '交易平台', '逐单记录成交金额、状态和下单日期。', [
      field('order_id', '订单编号', 'string'),
      field('amount_cents', '支付金额（分）', 'bigint'),
      field('order_day', '下单日期', 'date'),
      field('status', '订单状态', 'string'),
      field('currency', '结算币种', 'string'),
      field('legacy_note', '旧导入备注', 'string', [], true),
    ]),
    asset('rates_daily', '财务每日汇率', 'source', '财务数据', '每天每种币种一个核算汇率。', [
      field('currency', '币种', 'string'),
      field('rate_day', '汇率日期', 'date'),
      field('rmb_rate', '人民币换算率', 'decimal(12,6)'),
    ]),
    asset('fact_orders', '订单事实表', 'model', '数仓建模', '将成交金额换算至元，保留订单粒度。', [
      field('order_id', '订单编号', 'string', [input('orders_raw.order_id', 'value', '沿用源订单主键。')]),
      field('net_amount', '支付金额（人民币元）', 'decimal(16,2)', [
        input('orders_raw.amount_cents', 'value', '原始支付金额由分转元，再乘核算汇率。'),
        input('rates_daily.rmb_rate', 'value', '乘当日币种对应的人民币汇率。'),
        input('orders_raw.currency', 'join', '源订单币种和汇率币种匹配。'),
        input('rates_daily.currency', 'join', '使用订单币种匹配汇率记录。'),
        input('orders_raw.order_day', 'join', '按下单日匹配汇率适用日期。'),
        input('rates_daily.rate_day', 'join', '汇率生效日期加入关联条件。'),
      ]),
      field('order_day', '下单日期', 'date', [input('orders_raw.order_day', 'value', '沿用下单日期。')]),
      field('status', '订单状态', 'string', [input('orders_raw.status', 'value', '沿用源订单状态。')]),
      field('value_band', '源币种价格带', 'string', [input('orders_raw.amount_cents', 'value', '按订单金额标记金额档位。')]),
    ]),
    asset('finance_review', '大额订单核对表', 'model', '财务核算', '收录需要额外财务复核的订单编号。', [
      field('large_order_id', '大额订单编号', 'string', [
        input('orders_raw.order_id', 'value', '保留符合条件的原始订单编号。'),
        input('orders_raw.amount_cents', 'filter', '金额至少 100000 分时纳入复核。'),
        input('orders_raw.status', 'filter', '只纳入已付款订单。'),
      ]),
    ]),
    asset('daily_revenue', '日交易汇总表', 'model', '数仓建模', '按交易日期汇总成交金额。', [
      field('day', '销售日期', 'date', [input('fact_orders.order_day', 'value', '沿用分组日期。')]),
      field('gross_revenue', '日交易总额', 'decimal(20,2)', [
        input('fact_orders.net_amount', 'value', '按日期加总人民币支付额。'),
        input('fact_orders.order_day', 'group', '按下单日期分组。'),
        input('fact_orders.status', 'filter', '只汇总已付款订单。'),
      ]),
      field('has_sales', '是否有正额成交', 'boolean', [
        input('fact_orders.order_id', 'value', '对符合条件的订单行计数并比较是否大于 0。'),
        input('fact_orders.net_amount', 'filter', '只计入支付额大于 0 的行。'),
        input('fact_orders.order_day', 'group', '在同一日内汇总判断。'),
      ]),
    ]),
    asset('metric_revenue', '成交总额指标', 'metric', '经营分析', '在所选日期区间内汇总交易总额。', [
      field('sales_total', '成交总额', 'decimal(20,2)', [input('daily_revenue.gross_revenue', 'value', '累计所选日期的日交易总额。')]),
    ]),
    asset('dashboard_trade', '交易经营看板', 'dashboard', '经营分析', '查看经营周期内的收入和已付订单量。', [
      field('revenue', '成交总额卡片', 'decimal(20,2)', [input('metric_revenue.sales_total', 'value', '显示成交总额指标值。')]),
      field('paid_orders', '已付订单计数', 'bigint', [
        input('fact_orders.order_id', 'value', '对订单编号计数。'),
        input('fact_orders.status', 'filter', '只纳入已付款订单。'),
      ]),
    ]),
    asset('dashboard_finance', '财务复核看板', 'dashboard', '财务核算', '统计进入人工核对的大额订单。', [
      field('large_orders', '待核大额订单数', 'bigint', [input('finance_review.large_order_id', 'value', '对纳入复核的订单编号计数。')]),
    ]),
    asset('dashboard_support', '订单服务看板', 'dashboard', '客服运营', '按订单状态查看售中咨询范围。', [
      field('order_status', '订单状态分布', 'string', [input('fact_orders.status', 'group', '按源订单状态分组。')]),
    ]),
  ],
};

export const DEMO_DROP = {
  catalog: structuredClone(catalog),
  proposal: { name: '退役旧版支付金额字段', changes: [{ field: 'orders_raw.amount_cents', op: 'drop' }] },
};

export const DEMO_UNUSED = {
  catalog: structuredClone(catalog),
  proposal: { name: '清理旧版订单导入备注', changes: [{ field: 'orders_raw.legacy_note', op: 'drop' }] },
};

export const DEMO_TYPE = {
  catalog: structuredClone(catalog),
  proposal: { name: '切换支付金额字段类型', changes: [{ field: 'orders_raw.amount_cents', op: 'type', to: 'decimal(16,2)' }] },
};
