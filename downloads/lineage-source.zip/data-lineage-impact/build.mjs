import { mkdir, readFile, writeFile } from 'node:fs/promises';
import { dirname, resolve } from 'node:path';

const destination = resolve(process.argv[2] || 'dist/index.html');
const read = async path => (await readFile(new URL(path, import.meta.url), 'utf8')).replaceAll('\r\n', '\n');
const moduleUrl = source => `data:text/javascript;base64,${Buffer.from(source).toString('base64')}`;
const [html, css, app, engine, fixtures] = await Promise.all([
  read('./static/index.html'), read('./static/styles.css'), read('./static/app.mjs'),
  read('./engine.mjs'), read('./fixtures.mjs'),
]);

function inlineModule(source, path, url) {
  return source.replaceAll(`'${path}'`, `'${url}'`).replaceAll(`"${path}"`, `"${url}"`);
}

const engineUrl = moduleUrl(engine);
const fixturesUrl = moduleUrl(inlineModule(fixtures, './engine.mjs', engineUrl));
const application = inlineModule(inlineModule(app, '../engine.mjs', engineUrl), '../fixtures.mjs', fixturesUrl);
const cssEntry = /<link\b[^>]*href=["'](?:\.\/)?styles\.css["'][^>]*>/iu;
const jsEntry = /<script\b[^>]*src=["'](?:\.\/)?app\.mjs["'][^>]*>\s*<\/script>/iu;
if (!cssEntry.test(html) || !jsEntry.test(html)) throw new Error('找不到分析台的样式或脚本入口。');

const policy = "default-src 'none'; style-src 'unsafe-inline'; script-src data:; img-src data:; connect-src 'none'; base-uri 'none'; form-action 'none'";
const standalone = html.replace('<head>', `<head>\n  <meta http-equiv="Content-Security-Policy" content="${policy}">`)
  .replace(cssEntry, () => `<style>\n${css}\n</style>`)
  .replace(jsEntry, () => `<script type="module" src="${moduleUrl(application)}"></script>`);

await mkdir(dirname(destination), { recursive: true });
await writeFile(destination, standalone, 'utf8');
console.log(`已生成数据血缘影响台 ${destination}`);
