import assert from 'node:assert/strict';
import test from 'node:test';
import { analyzeImpact, MAX_INPUT_BYTES, parseWorkspace } from '../engine.mjs';
import { DEMO_DROP, DEMO_TYPE, DEMO_UNUSED } from '../fixtures.mjs';

const input = (field, kind = 'value') => ({ field, kind, description: '样例关系' });
const makeField = (id, inputs = []) => ({ id, name: id, type: 'bigint', nullable: false, inputs });
const makeAsset = (id, fields) => ({ id, name: id, kind: 'model', owner: '样例组', description: '', fields });

function workspace(assets, changes) {
  return { catalog: { name: '样例目录', assets }, proposal: { name: '样例变更', changes } };
}

function findField(data, ref) {
  const [asset, field] = ref.split('.');
  return data.catalog.assets.find(item => item.id === asset).fields.find(item => item.id === field);
}

test('dropping the payment field blocks six assets and distinguishes the fields they use', () => {
  const result = analyzeImpact(DEMO_DROP);
  assert.equal(result.status, 'blocked');
  assert.deepEqual(result.totals, { changed: 1, impactedFields: 8, impactedAssets: 6, directAssets: 2, indirectAssets: 4 });
  assert.deepEqual(result.changes, [{ field: 'orders_raw.amount_cents', op: 'drop', before: { type: 'bigint', nullable: false }, after: null, status: 'blocked' }]);
  assert.deepEqual(result.assets.find(asset => asset.id === 'dashboard_trade').fields, ['dashboard_trade.revenue']);
  assert(!result.assets.some(asset => asset.id === 'dashboard_support'));
  assert.deepEqual(result.impacts.find(impact => impact.field === 'dashboard_trade.revenue').paths[0].steps.map(step => step.to), [
    'fact_orders.net_amount', 'daily_revenue.gross_revenue', 'metric_revenue.sales_total', 'dashboard_trade.revenue',
  ]);
});

test('non-value edges transmit impact, retaining each relation and its context', () => {
  const result = analyzeImpact(DEMO_DROP);
  const path = result.impacts.find(impact => impact.field === 'dashboard_finance.large_orders').paths[0];
  assert.equal(path.root, 'orders_raw.amount_cents');
  assert.deepEqual(path.steps.map(step => step.kind), ['filter', 'value']);
  assert.match(path.steps[0].description, /100000 分/u);
  assert(result.edges.some(edge => edge.from === 'rates_daily.rate_day' && edge.kind === 'join'));
  assert(result.edges.some(edge => edge.from === 'fact_orders.order_day' && edge.kind === 'group'));
});

test('type and nullability changes require review only where known dependencies exist', () => {
  for (const change of [DEMO_TYPE.proposal.changes[0], { field: 'orders_raw.amount_cents', op: 'nullable', to: true }]) {
    const data = structuredClone(DEMO_TYPE);
    data.proposal.changes = [change];
    const result = analyzeImpact(data);
    assert.equal(result.status, 'review');
    assert.equal(result.changes[0].after[change.op], change.to);
    assert(result.impacts.every(impact => impact.status === 'review'));
  }
  const result = analyzeImpact(DEMO_UNUSED);
  assert.equal(result.status, 'clear');
  assert.equal(result.totals.impactedFields, 0);
  assert.equal(result.totals.impactedAssets, 0);
  assert(result.edges.length > 0);
});

test('diamond dependencies retain one deterministic shortest path per root', () => {
  const data = workspace([
    makeAsset('d', [makeField('z', [input('c.q'), input('b.p')])]),
    makeAsset('a', [makeField('x')]),
    makeAsset('c', [makeField('q', [input('a.x')])]),
    makeAsset('b', [makeField('p', [input('a.x')])]),
  ], [{ field: 'a.x', op: 'drop' }]);
  const analyze = () => analyzeImpact(data).impacts.find(impact => impact.field === 'd.z').paths;
  assert.deepEqual(analyze().map(path => path.steps.map(step => step.to)), [['b.p', 'd.z']]);
  data.catalog.assets.reverse();
  assert.deepEqual(analyze().map(path => path.steps.map(step => step.to)), [['b.p', 'd.z']]);
  findField(data, 'd.z').inputs.push(input('a.x', 'join'));
  assert.deepEqual(analyze().map(path => path.steps.map(step => step.kind)), [['join']]);
});

test('overlapping proposals count endpoints once while retaining root-specific evidence', () => {
  const data = workspace([
    makeAsset('a', [makeField('x'), makeField('y'), makeField('z')]),
    makeAsset('b', [makeField('p', [input('a.x')])]),
    makeAsset('c', [makeField('q', [input('a.y'), input('b.p')])]),
  ], [
    { field: 'a.x', op: 'drop' }, { field: 'a.y', op: 'type', to: 'string' }, { field: 'a.z', op: 'drop' },
  ]);
  const result = analyzeImpact(data);
  assert.equal(result.status, 'blocked');
  assert.deepEqual(result.changes.map(change => change.status), ['blocked', 'review', 'clear']);
  assert.deepEqual(result.totals, { changed: 3, impactedFields: 2, impactedAssets: 2, directAssets: 2, indirectAssets: 0 });
  const impact = result.impacts.find(impact => impact.field === 'c.q');
  assert.equal(impact.status, 'blocked');
  assert.equal(impact.distance, 1);
  assert.deepEqual(impact.paths.map(({ root, steps }) => [root, steps.length]), [['a.x', 2], ['a.y', 1]]);
});

test('accepts valid BOM JSON and avoids mutating supplied metadata', () => {
  const data = structuredClone(DEMO_DROP);
  const json = JSON.stringify(data);
  assert.deepEqual(parseWorkspace(`\uFEFF${json}`), data);
  analyzeImpact(data);
  assert.equal(JSON.stringify(data), json);
  assert.throws(() => parseWorkspace('{broken'), /有效的 JSON/u);
  assert.throws(() => parseWorkspace(' ' + '字'.repeat(MAX_INPUT_BYTES / 2)), /256 KiB/u);
});

test('rejects dangling, duplicate, cyclic and unsupported catalog metadata', () => {
  const valid = () => structuredClone(DEMO_DROP);
  const cases = [
    [data => findField(data, 'fact_orders.net_amount').inputs.push(input('missing.field')), /不存在/u],
    [data => findField(data, 'orders_raw.amount_cents').inputs.push(input('dashboard_trade.revenue')), /循环/u],
    [data => findField(data, 'orders_raw.amount_cents').inputs.push(input('orders_raw.amount_cents')), /循环/u],
    [data => data.catalog.assets.push(structuredClone(data.catalog.assets[0])), /重复/u],
    [data => data.catalog.assets[0].fields.push(structuredClone(data.catalog.assets[0].fields[0])), /重复/u],
    [data => findField(data, 'fact_orders.net_amount').inputs.push(input('orders_raw.amount_cents')), /重复/u],
    [data => findField(data, 'fact_orders.net_amount').inputs.push(input('orders_raw.amount_cents', 'implicit')), /关系/u],
  ];
  for (const [mutate, message] of cases) {
    const data = valid();
    mutate(data);
    assert.throws(() => analyzeImpact(data), message);
    assert.throws(() => parseWorkspace(JSON.stringify(data)), message);
  }
});

test('rejects no-op and ambiguous proposals instead of silently approving them', () => {
  const replace = changes => analyzeImpact({ catalog: DEMO_DROP.catalog, proposal: { name: '坏方案', changes } });
  const field = 'orders_raw.amount_cents';
  assert.throws(() => replace([]), /变更列表/u);
  assert.throws(() => replace([{ field, op: 'type', to: ' BIGINT ' }]), /原值相同/u);
  assert.throws(() => replace([{ field, op: 'nullable', to: false }]), /原值相同/u);
  assert.throws(() => replace([{ field, op: 'drop', to: null }]), /删除字段/u);
  assert.throws(() => replace([{ field: 'orders_raw.missing', op: 'drop' }]), /不存在/u);
  assert.throws(() => replace([{ field, op: 'drop' }, { field, op: 'nullable', to: true }]), /重复/u);
});

test('stops path evidence expansion before building oversized exports', () => {
  const fields = Array.from({ length: 200 }, (_, index) => makeField(`f${index}`, index ? [input(`a.f${index - 1}`)] : []));
  const data = workspace([makeAsset('a', fields)], [{ field: 'a.f0', op: 'drop' }]);
  assert.throws(() => analyzeImpact(data), /16000 步.+拆分/u);
  assert.throws(() => parseWorkspace(JSON.stringify(data)), /16000 步.+拆分/u);
  data.proposal.changes[0].field = 'a.f21';
  assert.equal(analyzeImpact(data).totals.impactedFields, 178);
  data.proposal.changes.push({ field: 'a.f187', op: 'drop' });
  assert.throws(() => analyzeImpact(data), /16000 步.+拆分/u);
});
