import assert from 'node:assert/strict';
import { spawnSync } from 'node:child_process';
import { mkdtemp, readFile, rm, stat, writeFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { dirname, join, resolve } from 'node:path';
import test from 'node:test';
import { fileURLToPath } from 'node:url';
import { MAX_INPUT_BYTES } from '../engine.mjs';
import { DEMO_DROP } from '../fixtures.mjs';

const cli = fileURLToPath(new URL('../cli.mjs', import.meta.url));

function run(...args) {
  const processResult = spawnSync(process.execPath, [cli, ...args], {
    encoding: 'utf8', timeout: 5_000,
  });
  assert.ifError(processResult.error);
  assert.equal(processResult.signal, null);
  return processResult;
}

async function temporary(t) {
  const path = await mkdtemp(join(tmpdir(), 'data-lineage-cli-'));
  assert.equal(dirname(path), resolve(tmpdir()));
  t.after(() => rm(path, { recursive: true, force: true }));
  return path;
}

function field(workspace, assetId, fieldId) {
  return workspace.catalog.assets.find(asset => asset.id === assetId).fields.find(item => item.id === fieldId);
}

test('the built-in proposals return distinct exit codes and trace real downstream evidence', () => {
  const drop = run('--demo');
  assert.equal(drop.status, 2, drop.stderr);
  assert.equal(drop.stderr, '');
  assert.equal(drop.stdout, run('--demo', '--case', 'drop').stdout);
  const report = JSON.parse(drop.stdout);
  assert.equal(report.status, 'blocked');
  assert.equal(report.totals.changed, 1);
  assert.equal(report.totals.impactedAssets, 6);
  assert.equal(report.changes[0].field, 'orders_raw.amount_cents');
  const trip = report.impacts.find(item => item.field === 'dashboard_trade.revenue');
  assert.equal(trip.distance, 4);
  assert.equal(trip.paths[0].steps.length, 4);
  assert.equal(trip.paths[0].steps[0].from, 'orders_raw.amount_cents');
  assert.equal(trip.paths[0].steps.at(-1).to, 'dashboard_trade.revenue');
  const filter = report.impacts.find(item => item.field === 'finance_review.large_order_id');
  assert.equal(filter.paths[0].steps[0].kind, 'filter');

  const unused = run('--demo', '--case', 'unused');
  assert.equal(unused.status, 0, unused.stderr);
  const clear = JSON.parse(unused.stdout);
  assert.equal(clear.status, 'clear');
  assert.equal(clear.totals.impactedFields, 0);

  const type = run('--demo', '--case', 'type');
  assert.equal(type.status, 3, type.stderr);
  const needsReview = JSON.parse(type.stdout);
  assert.equal(needsReview.status, 'review');
  assert.equal(needsReview.totals.impactedAssets, report.totals.impactedAssets);
  assert.equal(needsReview.changes[0].op, 'type');
});

test('a UTF-8 JSON import with BOM can export the same report even when the change is blocked', async t => {
  const root = await temporary(t);
  const input = join(root, '工作区.json');
  const output = join(root, '影响报告.json');
  const original = '\ufeff' + JSON.stringify(DEMO_DROP);
  await writeFile(input, original, 'utf8');
  const result = run('--input', input, '--out', output);
  assert.equal(result.status, 2, result.stderr);
  assert.equal(JSON.parse(result.stdout).status, 'blocked');
  assert.equal(await readFile(output, 'utf8'), result.stdout);
  assert.equal(await readFile(input, 'utf8'), original);
});

test('an existing report or a report path equal to the input is never overwritten', async t => {
  const root = await temporary(t);
  const input = join(root, 'catalog.json');
  const existing = join(root, 'existing.json');
  const contents = JSON.stringify(DEMO_DROP);
  await writeFile(input, contents);
  await writeFile(existing, 'existing bytes');
  for (const [destination, expected] of [[existing, 'existing bytes'], [input, contents]]) {
    const result = run('--input', input, '--out', destination);
    assert.equal(result.status, 1);
    assert.equal(result.stdout, '');
    assert.match(result.stderr, /输出已存在/);
    assert.equal(await readFile(destination, 'utf8'), expected);
  }
});

test('invalid graphs from JSON reject missing references and cycles before writing a report', async t => {
  const root = await temporary(t);
  const input = join(root, 'invalid.json');
  const output = join(root, 'report.json');
  const dangling = structuredClone(DEMO_DROP);
  field(dangling, 'fact_orders', 'net_amount').inputs[0].field = 'missing_asset.field';
  const cycle = structuredClone(DEMO_DROP);
  field(cycle, 'orders_raw', 'amount_cents').inputs.push({
    field: 'dashboard_trade.revenue', kind: 'value', description: '测试闭环',
  });
  for (const [workspace, pattern] of [[dangling, /缺失|未找到|不存在|无法找到|找不到/], [cycle, /环|循环/]]) {
    await writeFile(input, JSON.stringify(workspace));
    const result = run('--input', input, '--out', output);
    assert.equal(result.status, 1);
    assert.equal(result.stdout, '');
    assert.match(result.stderr, pattern);
    await assert.rejects(stat(output), { code: 'ENOENT' });
  }
});

test('malformed JSON, invalid UTF-8 and limits fail without returning a partial report', async t => {
  const root = await temporary(t);
  const input = join(root, 'invalid.json');
  const output = join(root, 'report.json');
  const cases = [
    ['{"name":not-json}', /JSON/],
    [Buffer.from([0x22, 0xff, 0x22]), /UTF-8/],
    [Buffer.alloc(MAX_INPUT_BYTES + 1, 0x20), /256 KiB/],
  ];
  for (const [payload, pattern] of cases) {
    await writeFile(input, payload);
    const result = run('--input', input, '--out', output);
    assert.equal(result.status, 1);
    assert.equal(result.stdout, '');
    assert.match(result.stderr, pattern);
    assert.doesNotMatch(result.stderr, /not-json/);
  }
  await assert.rejects(stat(output), { code: 'ENOENT' });
});

test('help presents all statuses and unsupported flag combinations are not accepted', () => {
  const help = run('--help');
  assert.equal(help.status, 0);
  assert.match(help.stdout, /2 表示阻断，3 表示待复核/);
  assert.match(help.stdout, /drop\|unused\|type/);
  for (const args of [[], ['--demo', '--bogus'], ['--demo', '--out'], ['--demo', '--demo'],
    ['--demo', '--input', 'file.json'], ['--input', 'file.json', '--case', 'unused'],
    ['--demo', '--case'], ['--demo', '--case', 'unknown']]) {
    const result = run(...args);
    assert.equal(result.status, 1, args.join(' '));
    assert.equal(result.stdout, '');
    assert.notEqual(result.stderr, '');
  }
});
