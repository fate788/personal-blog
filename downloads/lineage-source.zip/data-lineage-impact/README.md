# 数据血缘影响台

面向数据工程、指标治理和看板维护人员。把上游字段变更与登记的列级依赖放在一起核对，沿着计算、筛选、关联和分组关系定位下游消费者，并给出每个影响字段的证据路径。

[打开分析台](https://fate788.github.io/personal-blog/demos/lineage/index.html?v=1.0) · [查看退役未引用字段](https://fate788.github.io/personal-blog/demos/lineage/index.html?v=1.0&case=unused)

![订单金额字段的影响图](docs/preview.webp)

## 三个可复跑的案例

- **退役金额字段**。`orders_raw.amount_cents` 被 6 项下游资产、8 个字段间接或直接使用，其中包含交易和财务看板。当前变更阻断。证据可以跟到各字段、依赖类型和负责人。
- **退役旧备注**。登记清单中未发现 `orders_raw.legacy_note` 的下游消费者，本次检查通过。
- **调整金额类型**。保留同一批下游依赖，提示复核类型、聚合与展示口径。

## 在本机复跑

需要 Node.js 22 或更新版本，无额外依赖。

```sh
npm test
npm run build
node cli.mjs --demo --case drop
node cli.mjs --demo --case unused
node cli.mjs --demo --case type
node cli.mjs --input ./workspace.json --out ./impact-report.json
```

构建后直接打开 `dist/index.html`。体验页支持导出样例 JSON、导入自己的工作区以及下载检查报告。导入数据在当前浏览器内处理。CLI 退出码 `0` 表示通过，`2` 表示阻断，`3` 表示待复核，`1` 表示输入或文件错误。报告可以用新路径保存。

## 清单及判定口径

工作区包含 `catalog` 与 `proposal`。资产有编号、类型、负责人和字段列表。每个字段可通过 `inputs` 声明上游字段及处理关系。方案包含一个或多个变更，支持退役、改类型和改可空性。导入时会检查字段引用及循环。分析沿字段关系保留每个变更来源到各消费者的一条最短证据链。同一消费者的严重级别按最高风险合并。

可先从体验页导出 JSON 作模板。单个文件上限为 256 KiB，目录支持 80 个资产、500 个字段和 3,000 条依赖，单次可查 20 项变更。遇到证据链累计超过 16,000 步的方案，可以按变更范围拆分工作区后重查。

结果覆盖已登记的血缘。清单中未发现依赖时，本次检查通过，实际发布仍应依据环境里的完整登记。数据为虚构零售场景。建模参考 [OpenLineage 字段级血缘](https://openlineage.io/docs/spec/facets/dataset-facets/column_lineage_facet/) 和 [dbt 下游看板登记](https://docs.getdbt.com/docs/build/exposures)。
