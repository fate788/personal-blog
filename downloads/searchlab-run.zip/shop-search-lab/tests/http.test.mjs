import assert from "node:assert/strict";
import { once } from "node:events";
import test from "node:test";
import { benchmark, categories, products } from "../catalog.mjs";
import { evaluate, search } from "../engine.mjs";
import { startServer } from "../server.mjs";

async function service(t) {
  const server = startServer({ port: 0 });
  await once(server, "listening");
  t.after(() => new Promise((resolve) => server.close(resolve)));
  return `http://127.0.0.1:${server.address().port}`;
}

test("the HTTP service serves the catalog and uses the same search engine as the portable edition", async (t) => {
  const base = await service(t);
  const catalog = await fetch(base + "/api/catalog");
  assert.equal(catalog.status, 200);
  assert.deepEqual(await catalog.json(), { products, categories });

  const params = new URLSearchParams({ q: products[0].sku, expandAliases: "0", limit: "1" });
  const request = await fetch(base + "/api/search?" + params);
  assert.equal(request.status, 200);
  assert.deepEqual(await request.json(), search(products, products[0].sku, {
    strategy: "candidate", sort: "relevance", inStock: false, expandAliases: false, limit: 1
  }));
});

test("rank evaluation is reproducible and malformed parameters receive errors", async (t) => {
  const base = await service(t);
  const score = await fetch(base + "/api/evaluate?k=5&expandAliases=0");
  assert.equal(score.status, 200);
  assert.deepEqual(await score.json(), evaluate(products, benchmark, { k: 5, expandAliases: false }));
  for (const url of ["/api/search?sort=unsupported", "/api/search?priceMax=-1", "/api/search?expandAliases=anything", "/api/evaluate?k=100"]) {
    const reply = await fetch(base + url);
    assert.equal(reply.status, 400, url);
    assert.equal(typeof (await reply.json()).error, "string");
  }
  const method = await fetch(base + "/api/search", { method: "POST" });
  assert.equal(method.status, 405);
  assert.equal(method.headers.get("Allow"), "GET, HEAD");
});

test("site assets are served with the proper types", async (t) => {
  const base = await service(t);
  const page = await fetch(base);
  assert.equal(page.status, 200);
  assert.match(await page.text(), /商品搜索实验台/);
  const media = await fetch(base + "/media/desk.webp", { method: "HEAD" });
  assert.equal(media.status, 200);
  assert.equal(media.headers.get("Content-Type"), "image/webp");
  assert.equal(await media.text(), "");
  assert.equal((await fetch(base + "/package.json")).status, 404);
});
