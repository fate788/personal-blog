import { readFile } from "node:fs/promises";
import { createServer } from "node:http";
import { resolve } from "node:path";
import { fileURLToPath } from "node:url";
import { parseArgs } from "node:util";
import { benchmark, categories, products } from "./catalog.mjs";
import { evaluate, search } from "./engine.mjs";

const siteFiles = new Map([
  ["/", "static/index.html"], ["/index.html", "static/index.html"],
  ["/styles.css", "static/styles.css"], ["/app.mjs", "static/app.mjs"],
  ["/catalog.mjs", "catalog.mjs"], ["/engine.mjs", "engine.mjs"]
]);
const types = { html: "text/html; charset=utf-8", css: "text/css; charset=utf-8", mjs: "text/javascript; charset=utf-8", webp: "image/webp" };
const policy = "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; object-src 'none'; base-uri 'none'; frame-ancestors 'none'; form-action 'none'";

function write(response, status, body, contentType, head) {
  response.writeHead(status, {
    "Content-Type": contentType,
    "Content-Length": Buffer.byteLength(body),
    "Cache-Control": "no-cache",
    "X-Content-Type-Options": "nosniff",
    "Content-Security-Policy": policy
  });
  response.end(head ? undefined : body);
}

function json(response, status, value, head) {
  write(response, status, JSON.stringify(value), "application/json; charset=utf-8", head);
}

function invalid(message) {
  throw Object.assign(new Error(message), { status: 400 });
}

function integer(params, key, min, max, fallback) {
  const value = params.get(key);
  if (value === null) return fallback;
  if (!/^\d+$/.test(value) || Number(value) < min || Number(value) > max) {
    invalid(`${key} 应填写 ${min} 到 ${max} 的整数。`);
  }
  return Number(value);
}

function flag(params, key, fallback) {
  const value = params.get(key);
  if (value === null) return fallback;
  if (value !== "0" && value !== "1") invalid(`${key} 应填写 0 或 1。`);
  return value === "1";
}

function searchFromUrl(params) {
  const query = params.get("q")?.trim() || "";
  const strategy = params.get("strategy") ?? "candidate";
  const category = params.get("category") || undefined;
  const sort = params.get("sort") ?? "relevance";
  if (query.length > 100) invalid("搜索词不能超过 100 个字符。");
  if (!["baseline", "candidate"].includes(strategy)) invalid("排序方案不存在。");
  if (category && !categories.some(item => item.id === category)) invalid("商品分类不存在。");
  if (!["relevance", "price-asc", "price-desc"].includes(sort)) invalid("排序方式不存在。");
  return search(products, query, {
    strategy, category, sort,
    inStock: flag(params, "inStock", false),
    expandAliases: flag(params, "expandAliases", true),
    priceMax: integer(params, "priceMax", 0, 1000000, undefined),
    limit: integer(params, "limit", 1, 100, 24)
  });
}

export function startServer({ port = 8818 } = {}) {
  const server = createServer(async (request, response) => {
    const head = request.method === "HEAD";
    if (!head && request.method !== "GET") {
      response.setHeader("Allow", "GET, HEAD");
      json(response, 405, { error: "此接口仅支持读取。" }, head);
      return;
    }
    try {
      const url = new URL(request.url, "http://127.0.0.1");
      const { pathname, searchParams } = url;
      if (pathname === "/api/catalog") json(response, 200, { products, categories }, head);
      else if (pathname === "/api/search") json(response, 200, searchFromUrl(searchParams), head);
      else if (pathname === "/api/evaluate") {
        const k = integer(searchParams, "k", 1, 20, 5);
        const expandAliases = flag(searchParams, "expandAliases", true);
        json(response, 200, evaluate(products, benchmark, { k, expandAliases }), head);
      } else {
        const file = siteFiles.get(pathname) || (/^\/media\/[a-z][a-z-]*\.webp$/.test(pathname) ? `static${pathname}` : "");
        if (!file) {
          json(response, 404, { error: "没有找到这个页面。" }, head);
          return;
        }
        const body = await readFile(new URL(file, import.meta.url));
        write(response, 200, body, types[file.split(".").at(-1)], head);
      }
    } catch (error) {
      if (error.status === 400 || error instanceof TypeError && error.code === "ERR_INVALID_URL") {
        json(response, 400, { error: error.status ? error.message : "无法解析请求地址。" }, head);
      } else if (error.code === "ENOENT") json(response, 404, { error: "没有找到这个文件。" }, head);
      else {
        console.error(error);
        json(response, 500, { error: "搜索服务暂时不可用。" }, head);
      }
    }
  });
  return server.listen(port, "127.0.0.1");
}

if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const { values } = parseArgs({ options: { port: { type: "string", default: "8818" } } });
  const port = Number(values.port);
  if (!/^\d{1,5}$/.test(values.port) || port > 65535) throw new Error("端口应为 0 至 65535。");
  const server = startServer({ port });
  server.on("listening", () => console.log(`商品搜索实验台 http://127.0.0.1:${server.address().port}/`));
}
