import { products, categories, benchmark } from "../catalog.mjs";
import { search, evaluate } from "../engine.mjs";

const app = document.querySelector("#app");
const dialog = document.querySelector("#product-dialog");
const catalog = new Map(products.map(product => [product.id, product]));
const categoryNames = new Map(categories.map(category => [category.id, category.label]));
const formatMoney = new Intl.NumberFormat("zh-CN", { maximumFractionDigits: 2 });
const sortOptions = { relevance: "相关度", "price-asc": "价格从低到高", "price-desc": "价格从高到低" };
const priceOptions = new Map([[0, "不限价格"], [99, "¥99 以内"], [199, "¥199 以内"], [399, "¥399 以内"]]);
const grades = ["未标注", "部分相关", "相关", "高度相关"];
const outcomes = { all: "全部", improved: "提升", declined: "下降", unchanged: "持平", unjudged: "无标注", "more-unrelated": "多出未标注" };
const preferredQueries = ["屏幕挂灯", "氮化镓", "鼠标垫", "笔记本支架"];
const featured = ["felt-mat", "k75", "gan65-dual", "basic-desk-lamp"];
const reports = new Map();
const shop = { query: "", category: "", available: false, price: 0, sort: "relevance" };
const lab = { selected: "", outcome: "all", expandAliases: true };
let mode = "shop";
let dialogTrigger;

function escape(value) {
  return String(value ?? "").replace(/[&<>"']/gu, char => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[char]);
}
function cleanQuery(value) {
  return String(value || "").trim().slice(0, 100);
}
function fixed(value) {
  return Number.isFinite(value) ? value.toFixed(3) : "—";
}
function signed(value) {
  return Number.isFinite(value) && Math.abs(value) >= 0.0005 ? `${value > 0 ? "+" : "−"}${Math.abs(value).toFixed(3)}` : "";
}
function price(value) {
  return `<span class="currency">¥</span>${formatMoney.format(value)}`;
}
function photo(product) {
  return /^[a-z-]+$/u.test(product.photo || "")
    ? `<img src="./media/${product.photo}.webp" alt="" width="600" height="450" decoding="async">`
    : `<span class="photo-placeholder" aria-hidden="true">${escape(categoryNames.get(product.category))}</span>`;
}
function report() {
  if (!reports.has(lab.expandAliases)) reports.set(lab.expandAliases, evaluate(products, benchmark, { k: 5, expandAliases: lab.expandAliases }));
  return reports.get(lab.expandAliases);
}
function sampleCase(cases) {
  return cases.find(entry => entry.query === "屏幕挂灯") || cases.find(entry => entry.outcome === "improved") || cases[0];
}
function visibleCases(cases) {
  if (lab.outcome === "more-unrelated") return cases.filter(entry => entry.moreUnrelated);
  return lab.outcome === "all" ? cases : cases.filter(entry => entry.outcome === lab.outcome);
}
function chooseCase(cases) {
  const visible = visibleCases(cases);
  lab.selected = visible.find(entry => entry.id === lab.selected)?.id ||
    (lab.outcome === "all" ? sampleCase(visible)?.id : visible[0]?.id) || "";
}
function routeLink(view) {
  const params = new URLSearchParams();
  if (view === "shop") {
    if (shop.query) params.set("q", shop.query);
    if (shop.category) params.set("category", shop.category);
    if (shop.available) params.set("stock", "1");
    if (shop.price) params.set("max", shop.price);
    if (shop.sort !== "relevance") params.set("sort", shop.sort);
  } else {
    if (lab.selected && lab.selected !== sampleCase(report().cases)?.id) params.set("q", lab.selected);
    if (lab.outcome !== "all") params.set("outcome", lab.outcome);
    if (!lab.expandAliases) params.set("aliases", "0");
  }
  return `#${view}${params.size ? `?${params}` : ""}`;
}
function syncHeader() {
  const isLab = mode === "evaluation";
  document.body.dataset.view = mode;
  document.title = `${isLab ? "搜索排序评测" : "桌面商店"} · 商品搜索实验台`;
  document.querySelector("#identity-title").textContent = isLab ? "商品搜索实验台" : "桌面商店";
  const home = routeLink("shop");
  document.querySelector(".identity").href = home;
  document.querySelector(".footer-name").href = home;
  for (const link of document.querySelectorAll(".mode-nav [data-mode]")) {
    link.href = routeLink(link.dataset.mode);
    if (link.dataset.mode === mode) link.setAttribute("aria-current", "page");
    else link.removeAttribute("aria-current");
  }
}
function rememberRoute() {
  history.replaceState(history.state, "", routeLink(mode));
  syncHeader();
}
function readRoute() {
  const [route, query] = location.hash.slice(1).split("?", 2);
  const params = new URLSearchParams(query);
  mode = route === "evaluation" ? "evaluation" : "shop";
  if (mode === "shop") {
    const category = params.get("category");
    const max = Number(params.get("max"));
    const sort = params.get("sort");
    Object.assign(shop, { query: cleanQuery(params.get("q")), category: categoryNames.has(category) ? category : "",
      available: params.get("stock") === "1", price: priceOptions.has(max) ? max : 0,
      sort: Object.hasOwn(sortOptions, sort) ? sort : "relevance" });
  } else {
    lab.expandAliases = params.get("aliases") !== "0";
    const requested = params.get("q");
    lab.outcome = Object.hasOwn(outcomes, params.get("outcome")) ? params.get("outcome") : "all";
    lab.selected = report().cases.find(entry => entry.id === requested || entry.query === requested)?.id || "";
    chooseCase(report().cases);
  }
}
function shopSearchForm() {
  return `<form class="shop-search" id="shop-search" role="search"><label class="visually-hidden" for="shop-query">商品搜索词</label>
    <span class="search-icon" aria-hidden="true"></span><input id="shop-query" name="q" type="search" maxlength="100" placeholder="品名、品牌或货号" autocomplete="off" value="${escape(shop.query)}">
    <button type="submit">搜索商品</button></form>`;
}
function quickQueries() {
  return `<div class="search-samples"><span>试搜</span>${preferredQueries.map(query =>
    `<button type="button" data-quick-query="${escape(query)}">${escape(query)}</button>`).join("")}</div>`;
}
function filterMenu(type, label, options, current) {
  const trigger = type === "price" ? "price-menu" : "sort-menu";
  return `<details class="filter-menu"><summary id="${trigger}">${escape(label)}<span class="chevron" aria-hidden="true"></span></summary>
    <div class="filter-options" role="group" aria-labelledby="${trigger}">${options.map(([value, name]) =>
      `<button type="button" data-${type}="${escape(value)}" aria-pressed="${current === value}">${escape(name)}</button>`).join("")}</div></details>`;
}
function filterControls() {
  const all = [["", "全部商品"], ...categories.map(({id, label}) => [id, label])];
  return `<div class="shop-filters"><div class="category-nav" role="group" aria-label="商品分类">${all.map(([id, label]) =>
    `<button type="button" class="category-tab" data-category="${escape(id)}" aria-pressed="${shop.category === id}">${escape(label)}</button>`).join("")}</div>
    <div class="option-nav" aria-label="筛选与排序"><button type="button" class="available-filter" data-available aria-pressed="${shop.available}"><span aria-hidden="true"></span>仅看现货</button>
    ${filterMenu("price", shop.price ? priceOptions.get(shop.price) : "价格", [...priceOptions], shop.price)}
    ${filterMenu("sort", sortOptions[shop.sort], Object.entries(sortOptions), shop.sort)}</div></div>`;
}
function productCard(product) {
  return `<article class="product-card"><button type="button" class="product-tile" aria-label="查看${escape(product.name)}" data-product="${escape(product.id)}">
    <span class="photo-frame ${escape(product.category)}">${photo(product)}<span class="stock-tag${product.inStock ? "" : " sold-out"}">${product.inStock ? "现货" : "暂缺"}</span></span>
    <span class="product-body"><span class="product-meta">${escape(product.brand)} <span aria-hidden="true">·</span> <span class="sku">${escape(product.sku)}</span></span>
    <strong>${escape(product.name)}</strong><span class="product-price">${price(product.price)}<span class="tile-arrow" aria-hidden="true">↗</span></span></span></button></article>`;
}
function productsSection(result) {
  const title = shop.query ? `「${escape(shop.query)}」的搜索结果` : shop.category ? escape(categoryNames.get(shop.category)) : "浏览商品";
  const filtered = shop.category || shop.price || shop.available;
  return `<section class="catalog" aria-labelledby="results-title"><header class="catalog-header"><h2 id="results-title">${title}</h2><span class="result-count" role="status">${result.total} 件商品</span></header>
    ${filterControls()}${result.hits.length ? `<div class="product-grid">${result.hits.map(({product}) => productCard(product)).join("")}</div>` :
      `<div class="empty-search"><span class="search-icon" aria-hidden="true"></span><h3>没有找到符合条件的商品</h3><p>${filtered ? "试试取消分类、价格或现货筛选。" : "试试更短的关键词，或直接输入品名和货号。"}</p><button type="button" data-reset-shop>${filtered ? "清除筛选" : "浏览全部商品"}</button></div>`}</section>`;
}
function featureProducts(result) {
  const primary = featured.map(id => result.hits.find(hit => hit.id === id)).filter(Boolean);
  return { ...result, hits: [...primary, ...result.hits.filter(hit => !featured.includes(hit.id))] };
}
function renderShop() {
  const result = search(products, shop.query, { strategy: "candidate", category: shop.category || undefined,
    priceMax: shop.price || undefined, inStock: shop.available || undefined, sort: shop.sort, limit: products.length });
  const compact = !!shop.query;
  const browsingHome = !compact && !shop.category && !shop.price && !shop.available && shop.sort === "relevance";
  app.innerHTML = `<section class="shop-hero${compact ? " compact" : ""}"><div class="shop-hero-copy"><h1>${compact ? "搜索商品" : "桌面好物"}</h1>
    ${compact ? "" : '<p>键鼠、照明、充电与桌面整理配件。</p>'}${shopSearchForm()}${quickQueries()}</div>
    ${compact ? "" : '<div class="hero-photo"><img src="./media/desk.webp" alt="摆放台灯、键盘、鼠标和收纳托盘的木质书桌" width="1200" height="760" fetchpriority="high"></div>'}</section>${productsSection(browsingHome ? featureProducts(result) : result)}`;
}
function metricTile(label, baseline, candidate, count = false) {
  const direction = Number.isFinite(baseline) && Number.isFinite(candidate) ? candidate - baseline : null;
  const isGain = count ? direction < 0 : direction > 0;
  const delta = count && direction ? `${direction > 0 ? "+" : "−"}${Math.abs(direction)} 条` : signed(direction);
  const value = count ? item => `${item ?? "—"}` : fixed;
  return `<article class="metric-tile"><h2>${label}</h2><div class="metric-value"><strong>${value(candidate)}</strong>
    ${delta ? `<span class="metric-delta ${isGain ? "gain" : "loss"}" aria-label="相对基线 ${escape(delta)}">${escape(delta)}</span>` : ""}</div><p>基线 ${value(baseline)}</p></article>`;
}
function caseQueryList(dataset) {
  const selectedSample = sampleCase(dataset.cases);
  const visible = [...visibleCases(dataset.cases)].sort((left, right) => Number(right === selectedSample) - Number(left === selectedSample));
  return `<section class="query-pane" aria-labelledby="queries-title"><div class="section-heading"><h2 id="queries-title">评测查询</h2><span>${visible.length} / ${dataset.cases.length}</span></div>
    <div class="outcome-filter" role="group" aria-label="按结果筛选">${Object.entries(outcomes).map(([id, name]) =>
      `<button type="button" data-outcome="${id}" aria-pressed="${lab.outcome === id}">${name}</button>`).join("")}</div>
    <div class="case-list" id="case-list">${visible.length ? visible.map(entry =>
      `<button type="button" class="case-choice" data-case="${escape(entry.id)}" aria-pressed="${entry.id === lab.selected}"><span class="case-name"><strong>${escape(entry.query)}</strong><small>${escape(entry.group)}</small></span>
        <span class="outcome ${escape(entry.outcome)}">${outcomes[entry.outcome]}${entry.moreUnrelated ? '<small class="outcome-warning">多出未标注</small>' : signed(entry.deltaNdcg) ? `<small>${signed(entry.deltaNdcg)}</small>` : ""}</span></button>`).join("") : '<p class="empty-queries">当前筛选没有查询。</p>'}</div></section>`;
}
function documentSignals(hit) {
  const expanded = (hit.expanded || []).map(item => `${item.term} → ${item.via}`);
  if (expanded.length) return `<small class="match-trace">${escape([...new Set(expanded)].slice(0, 2).join(" · "))}</small>`;
  return "";
}
function rankedResults(entry, strategy) {
  const isCandidate = strategy === "candidate";
  const result = entry[strategy];
  const diff = new Set(isCandidate ? entry.added : entry.dropped);
  const share = result.relevantShare == null ? "—" : `${Math.round(result.relevantShare * 100)}%`;
  return `<section class="rank-panel ${strategy}" aria-labelledby="rank-${strategy}"><header class="rank-heading"><div><h3 id="rank-${strategy}">${isCandidate ? "候选方案" : "原词基线"}</h3><p>nDCG@5 <span>${fixed(result.ndcg)}</span></p></div><div class="rank-quantity"><span class="rank-share" title="所展示结果中有相关性标注的比例">相关 ${share}</span><span class="rank-size">召回 ${result.total} 件</span></div></header>
    ${result.hits.length ? `<ol class="rank-list">${result.hits.map((hit, index) => {
      const grade = hit.grade || Number(entry.relevant[hit.id] || 0);
      return `<li><span class="rank-number">${index + 1}</span><div class="rank-copy"><strong>${escape(hit.product.name)}</strong><small class="sku">${escape(hit.product.sku)}</small>${documentSignals(hit)}
        <span class="grade grade-${grade}" title="相关性标注 ${grade}">${grades[grade]}</span>${diff.has(hit.id) ? `<span class="rank-change">${isCandidate ? "新进" : "移出"}</span>` : ""}</div></li>`;
    }).join("")}</ol>` : '<p class="rank-empty">没有召回商品</p>'}</section>`;
}
function expectedResults(entry) {
  const relevant = Object.entries(entry.relevant).sort(([,a], [,b]) => b - a);
  if (!relevant.length) return "";
  return `<details class="judgments"><summary>查看人工标注的商品<span class="chevron" aria-hidden="true"></span></summary><ul>${relevant.map(([id, score]) => {
    const product = catalog.get(id);
    return `<li><span>${escape(product?.name || id)}</span><span class="grade grade-${score}">${grades[score]}</span></li>`;
  }).join("")}</ul></details>`;
}
function caseDetail(dataset) {
  const entry = dataset.cases.find(item => item.id === lab.selected);
  if (!entry) return '<section class="comparison empty-comparison"><h2>没有可对照的查询</h2><p>切换筛选条件查看当前评测。</p></section>';
  return `<section class="comparison" aria-labelledby="case-title" id="comparison"><header class="case-header"><div><p>${escape(entry.group)}</p>
    <h2 id="case-title" tabindex="-1">${escape(entry.query)}</h2></div><a class="try-query" href="#shop?${new URLSearchParams({q: entry.query})}">在商店里试搜 <span aria-hidden="true">↗</span></a></header>
    ${entry.note ? `<p class="case-note">${escape(entry.note)}</p>` : ""}${entry.moreUnrelated ? `<p class="case-warning">候选前五位多出 ${entry.candidate.falsePositives - entry.baseline.falsePositives} 件未标注商品。</p>` : ""}<div class="rank-pair">${rankedResults(entry, "baseline")}${rankedResults(entry, "candidate")}</div>${expectedResults(entry)}</section>`;
}
function renderLab() {
  const dataset = report();
  const { baseline, candidate, judged, queries, improved, declined, moreUnrelated } = dataset.totals;
  app.innerHTML = `<div class="lab-shell"><header class="lab-header"><div><h1>搜索排序评测</h1><p>用同一批查询对照原词基线和候选方案，核对每个结果的相关性。</p></div>
    <button type="button" class="export" data-export>下载 CSV <span aria-hidden="true">↓</span></button></header>
    <section class="experiment-control" aria-label="候选方案设置"><div><h2>候选同义词扩展</h2><p>关闭后保留字段加权，对照同义词带来的变化。</p></div>
    <button class="experiment-switch" type="button" data-aliases role="switch" aria-checked="${lab.expandAliases}" aria-label="候选同义词扩展"><span aria-hidden="true"></span><b>${lab.expandAliases ? "已开启" : "已关闭"}</b></button></section>
    <div class="metric-grid" aria-label="评测指标">${metricTile("nDCG@5", baseline.ndcg, candidate.ndcg)}${metricTile("MRR@5", baseline.mrr, candidate.mrr)}${metricTile("无结果查询", baseline.zeroResults, candidate.zeroResults, true)}</div>
    <p class="evaluation-context">${queries} 条查询，${judged} 条计入相关性指标 <span>·</span> ${improved} 条提升，${declined} 条下降，${moreUnrelated} 条多出未标注商品</p>
    <div class="evaluation-grid">${caseQueryList(dataset)}${caseDetail(dataset)}</div>
    <details class="metric-help"><summary>指标口径<span class="chevron" aria-hidden="true"></span></summary><p>nDCG@5 衡量前五位商品的分级相关性和位置。MRR@5 计算前五位中首个有相关性标注商品的倒数排名。无相关商品标注的查询不计入这两项均值，仍检查其是否返回结果。</p></details></div>`;
}
function render() {
  if (mode === "evaluation") renderLab();
  else renderShop();
  syncHeader();
}
function restoreControl(selector, scrollTop = null) {
  if (scrollTop !== null) document.querySelector("#case-list").scrollTop = scrollTop;
  document.querySelector(selector)?.focus({preventScroll: true});
}
function updateShop(change, control) {
  change();
  rememberRoute();
  renderShop();
  if (control) restoreControl(control);
}
function shopQuery(query) {
  updateShop(() => { Object.assign(shop, {query: cleanQuery(query), category: "", available: false, price: 0, sort: "relevance"}); });
  window.scrollTo(0, 0);
  document.querySelector("#shop-query").focus({preventScroll: true});
}
function updateLab(change, control, preserveList = false) {
  const listTop = preserveList ? document.querySelector("#case-list").scrollTop : null;
  change();
  chooseCase(report().cases);
  rememberRoute();
  renderLab();
  restoreControl(control, listTop);
}
function showProduct(id, trigger) {
  const product = catalog.get(id);
  if (!product) return;
  dialogTrigger = trigger;
  dialog.innerHTML = `<div class="product-sheet"><button type="button" class="close-dialog" aria-label="关闭商品详情" data-close>×</button>
    <div class="photo-frame ${escape(product.category)}">${photo(product)}</div><div class="sheet-copy"><p class="product-meta">${escape(product.brand)} · <span class="sku">${escape(product.sku)}</span></p>
    <h2 id="product-title">${escape(product.name)}</h2><p class="sheet-price">${price(product.price)}</p><p class="sheet-summary">${escape(product.summary)}</p>
    ${(product.attributes || []).length ? `<ul class="attributes">${product.attributes.map(value => `<li>${escape(value)}</li>`).join("")}</ul>` : ""}
    <p class="sheet-stock">${product.inStock ? "现货" : "暂时无货"}</p></div></div>`;
  dialog.showModal();
  dialog.querySelector("[data-close]").focus();
}
function csvField(value) {
  let text = String(value ?? "");
  if (typeof value === "string" && /^[=+@\-\t\r]/u.test(text)) text = "'" + text;
  return `"${text.replaceAll('"', '""')}"`;
}
function downloadReport() {
  const { cases, k } = report();
  const rows = [["查询", "分类", "状态", "Top K", "候选同义词", "基线 nDCG", "候选 nDCG", "nDCG 变化", "基线倒数排名", "候选倒数排名", "基线未标注结果数", "候选未标注结果数", "候选多出未标注", "基线结果货号", "候选结果货号", "人工标注商品与分值"]];
  for (const entry of cases) rows.push([entry.query, entry.group, outcomes[entry.outcome], k, lab.expandAliases ? "开启" : "关闭",
    entry.baseline.ndcg, entry.candidate.ndcg, entry.deltaNdcg, entry.baseline.reciprocalRank, entry.candidate.reciprocalRank,
    entry.baseline.falsePositives, entry.candidate.falsePositives, entry.moreUnrelated ? "是" : "否",
    entry.baseline.hits.map(hit => hit.product.sku).join(" | "), entry.candidate.hits.map(hit => hit.product.sku).join(" | "),
    Object.entries(entry.relevant).map(([id, grade]) => `${catalog.get(id)?.sku || id}:${grade}`).join(" | ")]);
  const url = URL.createObjectURL(new Blob(["\uFEFF", rows.map(row => row.map(csvField).join(",")).join("\r\n")], {type: "text/csv;charset=utf-8"}));
  const anchor = document.createElement("a");
  anchor.href = url;
  anchor.download = `商品搜索评测-${lab.expandAliases ? "启用" : "关闭"}同义词.csv`;
  anchor.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}
app.addEventListener("submit", event => {
  if (event.target.id !== "shop-search") return;
  event.preventDefault();
  shopQuery(new FormData(event.target).get("q"));
});
app.addEventListener("click", event => {
  const button = event.target.closest("button");
  if (!button) return;
  const { quickQuery, category, price: priceChoice, sort, product, outcome, case: caseId } = button.dataset;
  if (quickQuery) shopQuery(quickQuery);
  else if (category !== undefined) updateShop(() => { shop.category = category; }, `[data-category="${CSS.escape(category)}"]`);
  else if (button.hasAttribute("data-available")) updateShop(() => { shop.available = !shop.available; }, "[data-available]");
  else if (priceChoice !== undefined) updateShop(() => { shop.price = Number(priceChoice); }, "#price-menu");
  else if (sort) updateShop(() => { shop.sort = sort; }, "#sort-menu");
  else if (product) showProduct(product, button);
  else if (button.hasAttribute("data-reset-shop")) {
    if (shop.category || shop.available || shop.price) updateShop(() => { Object.assign(shop, {category: "", available: false, price: 0}); }, '[data-category=""]');
    else shopQuery("");
  }
  else if (button.hasAttribute("data-aliases")) updateLab(() => { lab.expandAliases = !lab.expandAliases; }, "[data-aliases]");
  else if (outcome) updateLab(() => { lab.outcome = outcome; }, `[data-outcome="${CSS.escape(outcome)}"]`);
  else if (caseId) {
    updateLab(() => { lab.selected = caseId; }, `[data-case="${CSS.escape(caseId)}"]`, true);
    if (matchMedia("(max-width: 760px)").matches) document.querySelector("#case-title")?.focus();
  }
  else if (button.hasAttribute("data-export")) downloadReport();
});
document.addEventListener("click", event => {
  for (const menu of document.querySelectorAll(".filter-menu[open]")) if (!menu.contains(event.target)) menu.open = false;
});
document.addEventListener("keydown", event => {
  if (event.key !== "Escape") return;
  const menu = document.querySelector(".filter-menu[open]");
  if (menu) { menu.open = false; menu.querySelector("summary").focus(); }
});
dialog.addEventListener("click", event => {
  if (event.target === dialog || event.target.closest("[data-close]")) dialog.close();
});
dialog.addEventListener("close", () => dialogTrigger?.focus({preventScroll: true}));
window.addEventListener("hashchange", () => {
  if (dialog.open) dialog.close();
  readRoute();
  render();
  window.scrollTo(0, 0);
  app.focus({preventScroll: true});
});
document.querySelector(".skip-link").addEventListener("click", event => { event.preventDefault(); app.focus(); });
readRoute();
render();
