import {mkdir,readFile,writeFile,copyFile} from "node:fs/promises";
import {dirname,resolve} from "node:path";
import {fileURLToPath} from "node:url";

const output=resolve(process.argv[2] || "dist/index.html");
const read=file=>readFile(new URL(file,import.meta.url),"utf8");
const assets=["sw.js","manifest.webmanifest","icon-192.png","icon-512.png"];
const source=file=>fileURLToPath(new URL("../static/"+file,import.meta.url));
const asModule=code=>"data:text/javascript;base64,"+Buffer.from(code.replace(/\r\n/gu,"\n"),"utf8").toString("base64");
function replaceModule(code,path,uri){
  const quote=code.includes(`"${path}"`) ? '"' : "'";
  const pattern=quote+path+quote;
  if(!code.includes(pattern))throw new Error("Missing module "+path);
  return code.replaceAll(pattern,JSON.stringify(uri));
}
const [domain,store,transport,workflow,app,css,html]=await Promise.all([
  read("../domain.mjs"),read("../static/storage.mjs"),read("transport.mjs"),
  read("../static/offline.mjs"),read("../static/app.mjs"),read("../static/styles.css"),read("../static/index.html"),
]);
const storeModule=asModule(store);
const bridge=asModule(replaceModule(replaceModule(transport,"../domain.mjs",asModule(domain)),"./storage.mjs",storeModule));
const logic=asModule(replaceModule(replaceModule(workflow,"./transport.mjs",bridge),"./storage.mjs",storeModule));
const main=asModule(replaceModule(app,"./offline.mjs",logic));
const cssTag=/<link\b[^>]*href=["'](?:\.\/)?styles\.css(?:\?[^"']*)?["'][^>]*>/iu;
const scriptTag=/<script\b[^>]*src=["'](?:\.\/)?app\.mjs(?:\?[^"']*)?["'][^>]*>\s*<\/script>/iu;
if(!cssTag.test(html)||!scriptTag.test(html))throw new Error("Missing frontend tags.");
const policy="default-src 'none'; style-src 'unsafe-inline'; script-src data:; worker-src 'self'; manifest-src 'self'; img-src 'self' data:; connect-src 'none'; base-uri 'none'; form-action 'none'";
const portable=html.replace("<html ",'<html data-edition="public" ')
  .replace("<head>",`<head>\n  <meta http-equiv="Content-Security-Policy" content="${policy}">`)
  .replace(cssTag,()=>`<style>\n${css}\n</style>`)
  .replace(scriptTag,()=>`<script type="module" src="${main}"></script>`);
const directory=dirname(output);
await mkdir(directory,{recursive:true});
await writeFile(output,portable.replace(/\r\n/gu,"\n"),"utf8");
await Promise.all(assets.map(file=>copyFile(source(file),resolve(directory,file))));
console.log("Browser demo written to "+output);
