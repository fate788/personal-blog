"use strict";

const $ = id => document.getElementById(id);
const esc = value => String(value ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const paths = {
  library:'<path d="M3 5.5c3.5-.6 6.4.1 9 2 2.6-1.9 5.5-2.6 9-2v13c-3.5-.6-6.4.1-9 2-2.6-1.9-5.5-2.6-9-2zM12 7.5v13"/>',
  books:'<rect x="3" y="4" width="5" height="16" rx="1"/><path d="M5 7h1M10 5h4v15h-4zM16 6l3-1 3 14-3 1z"/>',
  desk:'<rect x="3" y="4" width="18" height="16" rx="2"/><path d="M3 10h18M10 10v10"/>',
  inbox:'<path d="M3 14l3-8h12l3 8v5H3zM3 14h5l2 2h4l2-2h5"/>',
  chart:'<path d="M4 4v16h16M8 16v-4M12 16V7M16 16v-6"/>',
  code:'<path d="m9 7-5 5 5 5m6-10 5 5-5 5"/>', plus:'<path d="M12 5v14M5 12h14"/>',
  search:'<circle cx="10" cy="10" r="6.2"/><path d="m15 15 5 5"/>',arrow:'<path d="M4 12h15m-5-5 5 5-5 5"/>',
  file:'<path d="M6 3h8l4 4v14H6zM14 3v5h4M9 12h6m-6 3h6"/>',
  filter:'<path d="M4 7h16M6 12h12m-9 5h6"/>', check:'<path d="m4 12 5 5L20 6"/>',upload:'<path d="M12 15V4m-4 4 4-4 4 4M4 14v6h16v-6"/>'
};
function icon(name) {
  return `<i class="icon" aria-hidden="true"><svg viewBox="0 0 24 24">${paths[name] || ""}</svg></i>`;
}
document.querySelectorAll("[data-icon]").forEach(el => { el.innerHTML = icon(el.dataset.icon); el.setAttribute("aria-hidden","true"); });
const portable = Boolean(window.manualOffline);
$("workspace-mode").textContent = portable ? "此浏览器工作区" : "本机团队工作区";
const titles = {ask:"支持工作台",read:"手册库",gaps:"待补问题",evaluation:"检索评测",publish:"发布手册"};
const demoQuestion = "门诊候补成功后，号源会保留多久？";
const demoLink = "#ask?"+new URLSearchParams({q:demoQuestion,project:"clinic",demo:"1"});
const workflowExample = window.manualWorkflowExample;
let documents=[], sections=[], gaps=[], lastAnswer=null, lastGap=null, report=null;
let revision=0, activeAsk=null, returnGap="", noticeTimer=0, gapReason="feedback", focusFilter=false;
let context={view:"ask", parts:[], params:new URLSearchParams()};
const projects = {all:"全部手册",clinic:"门诊",ledger:"双账"};
const docName = id => documents.find(d=>d.id===id)?.title || projects[id] || id;
const isTeam = d => d?.kind==="team";
const pathPart = value=>encodeURIComponent(String(value));
function readLink(project,id="",version="") {
  return "#read/"+pathPart(project)+(id?"/"+pathPart(id):"")+(version?"?revision="+pathPart(version):"");
}
function askLink(q,project="all"){return "#ask?"+new URLSearchParams({q,project});}
function gapLink(filter,id=""){return "#gaps/"+filter+(id?"/"+pathPart(id):"");}
function external(url,label){
  if(!url)return "";
  try {const u=new URL(url);if(!["http:","https:"].includes(u.protocol)||u.username||u.password)return "";}
  catch{return "";}
  return `<a class="text-link" href="${esc(url)}" target="_blank" rel="noopener">${esc(label)} ↗</a>`;
}
function lineRange(s){return "第 "+s.start+(s.start!==s.end?"–"+s.end:"")+" 行";}
function dateLabel(value){
  if(!value)return "";
  const d=new Date(value);
  return Number.isNaN(+d)?"": new Intl.DateTimeFormat("zh-CN",{year:"numeric",month:"2-digit",day:"2-digit"}).format(d);
}
function badge(d){return `<span class="doc-icon ${d.id==="ledger"?"ledger":isTeam(d)?"team":""}">${icon("file")}</span>`;}
function btn(href,text,kind="secondary",symbol=""){return `<a class="btn ${kind}" href="${esc(href)}">${symbol?icon(symbol):""}${esc(text)}</a>`;}
function header(title,desc="",actions=""){
  $("page-heading").closest(".page-title").hidden=false;
  $("page-heading").textContent=title;$("page-caption").textContent=desc;$("page-caption").hidden=!desc;
  $("page-actions").innerHTML=actions;
}
function statusTag(done){return `<span class="status ${done?"done":""}">${done?"已解决":"待处理"}</span>`;}
function notify(message){$("notice").textContent=message;$("notice").hidden=false;clearTimeout(noticeTimer);noticeTimer=setTimeout(()=>{$("notice").hidden=true;},3300);}
function showError(el,msg){el.textContent=msg;el.hidden=false;}
async function api(url, options) {
  const response=portable?await window.manualOffline.request(url,options):await fetch(url,options);
  const data=await response.json();
  if(!response.ok)throw new Error(data.error || "工作区请求失败，请重试。");
  return data;
}
const post=(url,payload,signal)=>api(url,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(payload),signal});
function picker(name,value,items,label){
  const selected=items.find(([v])=>String(v)===String(value)) || items[0];
  const list=items.map(([v,t])=>`<button type="button" data-pick="${esc(v)}" aria-pressed="${String(v)===String(selected[0])}"><span>${esc(t)}</span><span class="pick-mark" aria-hidden="true">✓</span></button>`).join("");
  return `<details class="picker" data-picker="${esc(name)}" data-value="${esc(selected[0])}"><summary aria-label="${esc(label+"，"+selected[1])}">${icon("filter")}<span>${esc(selected[1])}</span></summary><div class="picker-list" role="group" aria-label="${esc(label)}">${list}</div></details>`;
}
function scopes(){
  return [["all","全部手册"],...documents.map(d=>[d.id,d.title])];
}
function getPick(id){return document.querySelector('[data-picker="'+id+'"]')?.dataset.value || "all";}
function setRail(){
  const open=gaps.filter(g=>g.status==="open").length;
  $("rail-count").hidden=!open;$("rail-count").textContent=open;
}
function docRow(d){
  const type=isTeam(d)?"团队手册":"内置手册";
  return `<a class="doc-row" href="${esc(readLink(d.id))}">${badge(d)}<div class="doc-copy"><strong>${esc(d.title)}</strong><span>${type} · ${esc(d.version)} · ${esc(d.sections)} 段原文</span></div><i class="doc-arrow" aria-hidden="true">›</i></a>`;
}
function searchForm(q,scope,landing){
  const placeholder=scope==="clinic"||(landing&&scope==="all") ? "例如：号源保留多久？" : "输入你想核对的问题";
  return `<section class="hero ${landing?"start-hero":"compact"}" aria-label="查询手册"><div class="hero-inner">
    ${landing?'<h1>查手册，给有出处的答复</h1><p class="hero-caption">输入员工或客户的问题，找到现行条款，复制答复时带上原文出处。</p>':""}
    <form id="ask-form"><div class="searchbox">${icon("search")}<label for="question" class="sr-only">你的问题</label><input id="question" type="text" autocomplete="off" maxlength="500" required value="${esc(q)}" placeholder="${placeholder}"><button class="btn primary" type="submit">查询${icon("arrow")}</button></div>
    <div class="search-tools"><span>查找范围</span>${picker("scope",scope,scopes(),"查询范围")}${!landing&&scope!=="all"?`<a class="text-link" href="${esc(readLink(scope))}">打开原文 →</a>`:""}</div></form></div></section>`;
}
function quickStart() {
  return `<section class="quick-grid" aria-label="快速开始">
    <article class="quick-card"><span class="quick-icon" aria-hidden="true">${icon("search")}</span><div class="quick-copy"><h2>先看一次查询结果</h2><p>${demoQuestion}</p></div><a class="btn primary" href="${esc(demoLink)}">查看演示答案${icon("arrow")}</a></article>
    <article class="quick-card"><span class="quick-icon" aria-hidden="true">${icon("upload")}</span><div class="quick-copy"><h2>导入自己的手册</h2><p>上传 Markdown、TXT，或直接粘贴正文。</p></div>${btn("#publish","导入手册","secondary","arrow")}</article>
  </section>`;
}
function gapRow(g,href,selected=false){
  return `<a class="gap-row" href="${esc(href)}" ${selected?'aria-current="true"':""}><div class="doc-copy"><strong>${esc(g.question)}</strong><span>${esc(docName(g.project))} · ${esc(dateLabel(g.createdAt))}</span></div><i class="doc-arrow" aria-hidden="true">›</i></a>`;
}
function workflowHref(){
  const existing=documents.find(d=>isTeam(d)&&d.title===workflowExample.title);
  return existing?readLink(existing.id):"#publish?example=1";
}
function home(){
  const open=gaps.filter(g=>g.status==="open");
  const team=documents.filter(isTeam);
  const sorted=[...team].reverse().concat(documents.filter(d=>!isTeam(d))).slice(0,4);
  return `<div class="dashboard-grid"><section class="panel"><header class="section-head"><h2>现行手册 <span class="count">${documents.length}</span></h2><a class="text-link" href="#read">查看手册库 →</a></header>${sorted.map(docRow).join("") || '<p class="feedback">导入第一份手册后即可查证。</p>'}</section><section class="panel"><header class="section-head"><h2>待补问题 <span class="count">${open.length}</span></h2><a class="text-link" href="#gaps">查看队列 →</a></header>${open.length?open.slice(0,3).map(g=>gapRow(g,gapLink("open",g.id))).join(""):'<div class="empty-brief"><span class="empty-icon">'+icon("inbox")+'</span><div><strong>暂无待处理问题</strong><p>手册缺少某条规定时，可以登记问题并跟进补写。</p><button type="button" class="action-link empty-action" data-register="manual">登记待补问题 →</button></div></div>'}</section></div>
    <div class="workflow-link"><span>${icon("books")} 手册里没写到的规定怎么补？</span><a class="text-link" href="${esc(workflowHref())}">体验补齐手册 →</a></div>`;
}
function highlighted(section, answer=""){
  const t=section.text;
  const matches=[section.snippet,...answer.split(/(?<=[。！？])|\n/u)].map(s=>String(s||"").trim()).filter(s=>s&&t.includes(s)&&s!==t);
  const ranges=matches.map(s=>[t.indexOf(s),t.indexOf(s)+s.length]).sort((a,b)=>a[0]-b[0]||b[1]-a[1]);
  if(!ranges.length)return "<mark>"+esc(t)+"</mark>";
  let pos=0,html="";
  for(const [start,end] of ranges){if(start<pos)continue;html+=esc(t.slice(pos,start))+"<mark>"+esc(t.slice(start,end))+"</mark>";pos=end;}
  return html+esc(t.slice(pos));
}
function sourceCard(s,index,answer) {
  return `<details class="source-box" id="evidence-${index}" ${index===0?"open":""}><summary><span>${esc(s.title)}<span>${esc(s.document)} · ${esc(s.version)} · ${esc(lineRange(s))}</span></span></summary><div class="source-body" tabindex="-1"><blockquote>${highlighted(s,answer)}</blockquote><div class="source-links"><a href="${esc(readLink(s.project,s.id,s.revision))}">在手册中定位 →</a>${external(s.sourceUrl||s.url,"外部原文")}</div></div></details>`;
}
function drawAnswer(q,scope,r,demo){
  const ok=r.status==="answered";
  const cited=new Set(r.citations.map(s=>s.id)),other=r.results.filter(s=>!cited.has(s.id));
  const mode=ok?(r.mode==="model"?"本地模型整理":"原文摘录"):"资料不足";
  const evidence=ok?r.citations.map((s,i)=>sourceCard(s,i,r.answer)).join(""):documents.filter(d=>scope==="all"||d.id===scope).map(docRow).join("");
  const related=other.length?`<details class="drop more"><summary>其他匹配段落 · ${other.length}</summary><ul class="result-list">${other.map(s=>`<li><a href="${esc(readLink(s.project,s.id,s.revision))}">${esc(s.title)}</a><span class="meta">${esc(lineRange(s))}</span></li>`).join("")}</ul></details>`:"";
  const afterDemo=demo?`<div class="workflow-link"><span>${icon("books")} 试试从登记问题到补齐手册的流程。</span><a class="text-link" href="${esc(workflowHref())}">体验补齐手册 →</a></div>`:"";
  return `<div class="answer-grid"><article class="panel answer-main"><div class="mode">${icon(ok?"file":"inbox")} ${demo?"演示手册 · ":""}${mode}</div><h2 id="answer-title" tabindex="-1">${esc(q)}</h2><p class="answer-text">${esc(r.answer)}</p>${r.modeNote && r.resolutionId ? '<p class="hint resolution-hint">已由维护人员核对依据</p>' : ''}<div class="answer-actions">${ok?'<button type="button" class="btn secondary" data-copy-answer>复制答复与出处</button>':""}<button class="${ok?"action-link":"btn primary"}" type="button" data-register="${ok?"feedback":"insufficient"}">${ok?"依据不全，登记待补":"登记待补问题"}</button><a class="text-link" href="#ask">新查询</a></div><div id="reply-copy"></div></article><aside class="panel answer-side"><h2>${ok?"引用原文":"已查范围"}</h2>${evidence}${related}</aside></div>${afterDemo}`;
}
async function drawDesk(params,n){
  const q=(params.get("q")||"").trim();
  const selected=params.get("project"),scope=selected || documents.find(isTeam)?.id || "all";
  const demo=params.get("demo")==="1" && scope==="clinic" && q===demoQuestion;
  const landing=!q && !selected;
  const ready=!q && isTeam(documents.find(d=>d.id===scope)) && params.get("ready")==="1";
  header(demo?"演示答复":q?"手册查证":ready?"手册已就绪":"查询手册",
    ready?`已将查询限定在「${docName(scope)}」。输入一条问题，试着找到刚导入的原文。`:
    demo?"来自门诊预约演示手册，可打开条款核对结果。":"",
    btn("#publish","导入手册","secondary","plus"));
  $("page-heading").closest(".page-title").hidden=landing;
  $("view").innerHTML=searchForm(q,scope,landing)+'<div id="ask-output"></div>';
  if(!q){
    if(landing)$("ask-output").innerHTML=quickStart()+home();
    if(ready)$("question").focus();
    return;
  }
  const key=scope+"\n"+q;
  if(lastAnswer?.key===key){
    lastAnswer.hash=location.hash;
    $("ask-output").innerHTML=drawAnswer(q,scope,lastAnswer.result,demo);
    return;
  }
  $("ask-output").innerHTML='<p class="feedback busy" role="status">正在查找相关段落…</p>';
  activeAsk=new AbortController();
  const result=await post("/api/ask",{question:q,project:scope},activeAsk.signal);
  if(n!==revision)return;
  lastAnswer={key,question:q,project:scope,result,hash:location.hash};
  $("ask-output").innerHTML=drawAnswer(q,scope,result,demo);
  const title=$("answer-title");
  title.focus({preventScroll:true});
  const bounds=title.getBoundingClientRect();
  if(bounds.top<0 || bounds.bottom>innerHeight-100)title.scrollIntoView({block:"center"});
}


function catalogRows(query=""){
  const found=documents.filter(d=>d.title.toLocaleLowerCase().includes(query.trim().toLocaleLowerCase()));
  return found.map(d=>{
    const type=isTeam(d)?"团队维护":"固定来源",published=d.versions?.find(v=>v.revision===d.revision)?.publishedAt;
    return `<a class="library-item" href="${esc(readLink(d.id))}"><div class="lib-ident">${badge(d)}<div><b>${esc(d.title)}</b><small>${type} · ${d.sections} 段原文</small></div></div><span>${esc(d.version)}</span><span class="doc-date meta">${esc(dateLabel(published)||"内置快照")}</span><span class="doc-arrow">›</span></a>`;
  }).join("") || '<p class="feedback">没有匹配的手册。</p>';
}
function catalog(){
  header("手册库","维护当前使用的手册，按版本追溯引用。",btn("#publish","导入手册","primary","plus"));
  $("view").innerHTML=`<section class="panel"><div class="catalog-toolbar"><h2>全部手册 <span class="count">${documents.length}</span></h2><label class="filter-input">${icon("search")}<span class="sr-only">按名称筛选手册</span><input id="library-filter" type="search" placeholder="按名称筛选手册"></label></div><div class="library-item table-labels" aria-hidden="true"><span>手册名称</span><span>现行版本</span><span class="doc-date">发布</span><span></span></div><div id="catalog-rows">${catalogRows()}</div></section>`;
}
async function reader(project,sectionId,params,n){
  const doc=documents.find(d=>d.id===project);
  if(!doc)throw new Error("没有找到这份手册。");
  let ver=Number(params.get("revision"))||doc.revision||1;
  if(sectionId && !params.has("revision") && !sections.some(s=>s.id===sectionId)){
    const data=await api("/api/sections/"+pathPart(sectionId));
    if(data.section.project!==project)throw new Error("段落不属于所选手册。");
    ver=data.section.revision;
  }
  const data=await api("/api/documents/"+pathPart(project)+"?revision="+ver);
  if(n!==revision)return;
  const snapshot=data.document, rows=data.sections, archived=ver!==(doc.revision||1);
  const chosen=sectionId && rows.find(s=>s.id===sectionId);
  const groups=new Map();
  rows.forEach(s=>{if(!groups.has(s.title))groups.set(s.title,[]);groups.get(s.title).push(s);});
  const versions=(doc.versions||[{revision:1,version:doc.version}]).slice().sort((a,b)=>b.revision-a.revision).map(v=>[v.revision,v.version+(v.revision===doc.revision?" · 现行":" · 历史")]);
  header(doc.title,(archived?"历史版本":"现行版本")+" · "+snapshot.version+" · "+rows.length+" 段原文",
    isTeam(doc)?btn("#publish/"+pathPart(project),"发布新版","primary","upload"):btn("#read","返回手册库"));
  const isWorkflow=doc.title===workflowExample.title;
  const queryLink = isWorkflow
    ? '<a class="action-link" href="'+esc(askLink(workflowExample.question,project))+'">试问续借期限 →</a>'
    : '<a class="action-link" href="#ask?project='+pathPart(project)+'">在本册中查证 →</a>';
  const returnLink=lastAnswer?`<a class="action-link" href="${esc(lastAnswer.hash)}">← 返回上次查询</a>`:"";
  const body=[...groups].map(([title,items])=>`<section class="manual-chapter"><h3>${esc(title)}</h3>${items.map(s=>{
    const selected=s.id===sectionId;
    const saved=lastAnswer?.result.citations.find(c=>c.id===s.id);
    const html=selected&&saved?highlighted(saved,lastAnswer.result.answer):esc(s.text);
    const href=readLink(project,s.id,ver);
    return `<article class="section-item ${selected?"is-linked":""}" id="passage-${esc(s.id)}" tabindex="-1"><a class="section-id" href="${esc(href)}">${esc(lineRange(s))}</a><p>${html}</p><div class="source-links"><button type="button" data-copy-link="${esc(href)}">复制段落链接</button>${selected?returnLink:""}</div></article>`;
  }).join("")}</section>`).join("");
  const practice=isWorkflow&&!sectionId&&!archived?`<section class="reader-practice panel"><div><h2>试问这份手册</h2><p>可先问有明确条款的问题，再查手册初版里缺失的续借期限。</p></div><div class="practice-links">${workflowExample.starterQuestions.map(item=>btn(askLink(item.question,project),item.label)).join("")}${btn(askLink(workflowExample.question,project),"续借期限","primary","search")}</div></section>`:"";
  $("view").innerHTML=practice+`<div class="reader-layout"><aside class="panel reader-index"><h2>章节目录</h2><nav aria-label="章节">${[...groups].map(([title,items])=>`<a href="${esc(readLink(project,items[0].id,ver))}">${esc(title)}</a>`).join("")}</nav></aside><article class="panel reader-paper"><div class="reader-meta">${picker("version",ver,versions,"当前阅读版本")}${external(snapshot.sourceUrl||snapshot.url,"查看来源")}${queryLink}${returnLink}</div>${sectionId&&!chosen?'<p class="feedback">这个版本未收录所指定的段落。</p>':""}${body}</article></div>`;
  if(chosen){const el=$("passage-"+chosen.id);el.focus({preventScroll:true});el.scrollIntoView({block:"start"});}
}
function exampleContent(project){
  const e=workflowExample;
  $("doc-title").value=e.title;$("doc-content").value=project?e.updated:e.initial;
  $("file-label").textContent=project?"已填入含续借条款的示例":"已填入设备借用示例";
  if(!project)$("publish-submit").textContent="发布示例手册";
}
function updatePublishButton() {
  const form=$("publish-form");
  if(!form.dataset.project)$("publish-submit").textContent=$("doc-title").value.trim()===workflowExample.title?"发布示例手册":"发布并查询";
}
async function publisher(project,params,n){
  let data;
  if(project){
    if(!isTeam(documents.find(d=>d.id===project)))throw new Error("只有团队维护的手册可发布新版。");
    data=await api("/api/documents/"+pathPart(project));
    if(n!==revision)return;
  }
  const doc=data?.document;
  const exampleRoute=params.get("example")==="1";
  const existing=!project && exampleRoute && documents.find(d=>isTeam(d)&&d.title===workflowExample.title);
  if(existing){go(readLink(existing.id));return;}
  header(project?"发布手册新版":exampleRoute?"体验补齐手册":"导入自己的手册",
    project?"新版发布后会用于后续查询。已有引用仍能打开当时的版本。":
    exampleRoute?"先发布设备借用手册，再试问初版里缺失的续借规定。":"选一份 Markdown 或 TXT 文件，也可以直接粘贴正文。发布后即可在这份手册里查询。",
    btn(project?readLink(project):"#read","返回手册库"));
  const allowedExample=!project || doc.title===workflowExample.title;
  $("view").innerHTML=`<div class="publish-layout"><form class="panel form-panel" id="publish-form" data-project="${esc(project||"")}" data-revision="${esc(doc?.revision||"")}" novalidate><h2>${project?"修订内容":"手册内容"}</h2><div class="upload">${icon("upload")}<span id="file-label">Markdown / TXT · UTF-8 · 最大 256 KiB</span><label class="btn secondary">选择文件<input id="doc-file" type="file" accept=".md,.markdown,.txt,text/markdown,text/plain" aria-label="选择手册文件"></label></div>
    <label class="field">手册名称<input id="doc-title" required maxlength="96" value="${esc(doc?.title||"")}" placeholder="例如：IT 服务台设备借用手册"></label>
    <label class="field">正文<textarea id="doc-content" required rows="8" placeholder="粘贴条款正文。使用 Markdown 标题，可以按章节查阅原文。">${esc(data?.content||"")}</textarea></label>
    <details class="drop import-source" ${doc?.sourceUrl||doc?.url?"open":""}><summary>来源网址（选填）</summary><input class="copy-url" id="doc-url" type="url" aria-label="来源网址" value="${esc(doc?.sourceUrl||doc?.url||"")}" placeholder="https://"></details>
    <p class="form-error" role="alert" id="publish-error" hidden></p><div class="import-foot"><span class="hint">${project?"当前版本 "+esc(doc.version):"发布后保留正文和版本"}</span><button id="publish-submit" type="submit" class="btn primary">${project?"发布新版":"发布并查询"}</button></div></form>
    <aside class="panel import-side"><h2>${project?allowedExample?"补写续借规定":"版本留档":exampleRoute?"这次体验怎么走":"适合导入什么？"}</h2>
    <p>${project?allowedExample?"用示例新版补上续借期限，发布后回到待补问题，选择这段新条款。":"先核对修订内容。发布新版后，可以用新版条款处理待补问题。":exampleRoute?"发布初版后，查一次申请材料或归还流程。试问续借期限，就会遇到手册需要补充的条款。":"内部制度、工单处理流程、设备借还说明都可以。先选一份同事常查的文档，发布后用一个常见问题验证引用。"}</p>
    ${allowedExample?'<button type="button" class="btn secondary" data-fill-example>填入设备借用示例</button>':""}</aside></div>`;
  if(exampleRoute&&allowedExample)exampleContent(project);
}
function eligible(g){
  return sections.filter(s=>g.project==="all"||s.project===g.project||(!isTeam(documents.find(d=>d.id===g.project))&&isTeam(documents.find(d=>d.id===s.project))));
}
function gapPanel(g){
  if(!g)return '<article class="panel"><div class="empty-brief"><span class="empty-icon">'+icon("check")+'</span><div><strong>这个队列暂时为空</strong><p>在工作台登记资料缺口后，可在这里选择原文并完成复核。</p></div></div></article>';
  const done=g.status==="resolved";
  const currentDoc=documents.find(d=>d.id===g.project);
  const editLink=isTeam(currentDoc)?"#publish/"+pathPart(currentDoc.id):"#publish";
  const evidence=done?`<div class="evidence-panel"><h3>结案依据</h3>${g.evidence?sourceCard(g.evidence,0,""):""}${g.note?'<div class="resolved-note"><b>处理说明</b><p>'+esc(g.note)+'</p></div>':""}<p class="hint">结案于 ${esc(dateLabel(g.resolvedAt))}</p><a class="action-link" href="${esc(askLink(g.question,g.project))}">重新查证这个问题 →</a></div>`:
    `<form class="evidence-panel" id="resolve-form" data-gap="${esc(g.id)}"><div class="heading-row"><h3>关联原文并结案</h3><a href="${editLink}" class="text-link">${isTeam(currentDoc)?"发布新版":"补充手册"} ↗</a></div><div class="evidence-tools"><label class="filter-input">${icon("search")}<span class="sr-only">筛选证据段落</span><input id="evidence-search" type="search" placeholder="输入条款关键词，筛选现行段落"></label></div><div id="evidence-options" class="evidence-options" role="radiogroup" aria-label="选择结案依据"></div><div id="selected-evidence"></div><label class="field">处理说明 <em>选填</em><textarea id="resolution-note" rows="2" maxlength="1000" placeholder="记录适用条件或给支持人员的说明"></textarea></label><p class="form-error" role="alert" id="resolve-error" hidden></p><div class="form-end"><button type="submit" class="btn primary" disabled>确认结案</button></div></form>`;
  return `<article class="panel case-panel">${statusTag(done)}<h2>${esc(g.question)}</h2><p class="meta">${esc(docName(g.project))} · ${esc(g.reason==="insufficient"?"未找到充分依据":"人工反馈")} · ${esc(dateLabel(g.createdAt))}</p>${evidence}</article>`;
}
function drawOptions(g,filter,keep=""){
  const all=eligible(g);
  const words=filter.trim().toLocaleLowerCase().split(/\s+/).filter(Boolean);
  const shown=all.filter(s=>{const t=(s.document+" "+s.title+" "+s.text).toLocaleLowerCase();return words.every(w=>t.includes(w));});
  const host=$("evidence-options");
  host.innerHTML=shown.map(s=>`<label class="evidence-option"><input name="evidence" type="radio" value="${esc(s.id)}" ${s.id===keep?"checked":""}><span>${esc(s.title)} · ${esc(lineRange(s))}</span><small>${esc(s.document)} · ${esc(s.text.slice(0,68))}</small></label>`).join("")||'<p class="feedback">没有匹配的原文。可以更换关键词，或先发布手册。</p>';
  const selected=shown.find(s=>s.id===keep);
  $("selected-evidence").innerHTML=selected?`<blockquote>${esc(selected.text)}</blockquote>`:"";
  $("resolve-form").querySelector('[type=submit]').disabled=!selected;
}
function queue(filter,id){
  if(!["open","resolved","all"].includes(filter))filter="open";
  const requested=id && gaps.find(g=>String(g.id)===String(id));
  if(requested && filter!=="all" && requested.status!==filter){
    history.replaceState(null,"",gapLink(requested.status,requested.id));filter=requested.status;
  }
  const list=gaps.filter(g=>filter==="all"||g.status===filter);
  lastGap=id?requested:list[0];
  header("待补问题","把知识缺口交给维护人员，为每个已解决的问题保留原文依据。",'<button class="btn secondary" type="button" data-register="manual">'+icon("plus")+'登记问题</button>');
  const labels=[["open","待处理"],["resolved","已解决"],["all","全部"]];
  const filters=labels.map(([v,l])=>`<a href="${gapLink(v)}" class="chip" ${filter===v?'aria-current="true"':""}>${l}</a>`).join("");
  $("view").innerHTML=`<div class="queue-layout"><section class="panel"><div class="queue-tools"><div class="chips">${filters}</div><button type="button" class="action-link" data-export-gaps="${filter}" ${list.length?"":"disabled"}>导出清单</button></div><div class="queue-list">${list.map(g=>gapRow(g,gapLink(filter,g.id),g===lastGap)).join("")||'<p class="feedback">当前有 0 个问题。</p>'}</div></section>${gapPanel(lastGap)}</div>`;
  if(lastGap?.status==="open")drawOptions(lastGap,"");
}


function failed(test) {
  if (test.answerable) return !test.hybridHit || test.citationSupport === false || test.evidenceHit === false ||
    !["pending","complete"].includes(test.answerQuality) || test.status === "insufficient";
  return test.status !== "insufficient";
}
function testStatus(test) {
  if (!test.answerable) return test.status === "insufficient" ? "恰当拒答" : "误答";
  if (!test.hybridHit) return "漏检";
  if (test.status === "insufficient") return "未作答";
  if (failed(test)) return "待复核";
  return "命中";
}
function caseRow(test) {
  const method = hit => hit == null ? "不适用" : hit ? "前 3 命中" : "前 3 漏检";
  const row = (label, value) => value ? '<p><b>'+label+'</b>'+esc(value)+'</p>' : "";
  const sources = (test.citations || []).map(s => '<a href="'+esc(readLink(s.project,s.id))+'">'+
    esc(projects[s.project])+' · '+esc(lineRange(s))+' →</a>').join("");
  return '<details class="case"><summary><span class="case-status">'+testStatus(test)+'</span><span>'+esc(test.question)+'</span></summary>'+
    '<div class="case-body">'+row("关键词", method(test.baselineHit))+row("改进检索", method(test.hybridHit))+
    row("关键词返回",test.baselineRanked)+row("改进后返回",test.hybridRanked)+
    row("参考依据",test.expected)+row("返回的答案",test.answer)+
    (sources ? '<div class="source-links">'+sources+'</div>' : "")+row("复核说明",test.review)+
    '<a href="#ask?'+esc(new URLSearchParams({q:test.question,project:Object.hasOwn(projects,test.project) ? test.project : "all"}).toString())+'">在问答中重试 →</a></div></details>';
}
function drawReport(data, filter) {
  const s = data.summary;
  const metrics = [["关键词 · 前三命中",s.baseline.hits,s.baseline.answerable],["改进检索 · 前三命中",s.hybrid.hits,s.hybrid.answerable],
    ["有依据题 · 完整回答",s.fullyAnswered,s.hybrid.answerable],["无依据题 · 恰当拒答",s.abstentions,s.unanswerable]];
  const filters = {all:"全部",missed:"需复查",missing:"无依据题"};
  if (!Object.hasOwn(filters,filter)) filter = "all";
  const rows = data.cases.filter(test => filter === "missed" ? failed(test) : filter === "missing" ? !test.answerable : true);
  $("evaluation").innerHTML = '<div class="metrics">'+metrics.map(([label,x,y]) => '<div class="metric"><small>'+label+'</small><strong>'+esc(x)+' / '+esc(y)+'</strong></div>').join("")+
    '</div><p class="subtle">这组结果评测离线检索与原文摘录。有引用的回答中，'+esc(s.citationSupported)+' / '+esc(s.citationEvaluated)+
    ' 份获原文支持。独立 AI 分别复核引用和回答完整性，有依据的题目中有 '+esc(s.falseAbstentions)+' 题被误判为资料不足。</p>'+
    '<div class="eval-tools"><h2>逐题记录 <span class="meta">'+rows.length+' 题</span></h2><div class="chips" aria-label="筛选评测记录">'+
    Object.entries(filters).map(([value,label]) => '<button type="button" class="chip" data-eval="'+value+'" aria-pressed="'+(value === filter)+'">'+label+'</button>').join("")+'</div></div>'+
    (rows.length ? rows.map(caseRow).join("") : '<p class="feedback">该筛选下没有记录。</p>');
  if (focusFilter) {
    focusFilter = false;
    $("evaluation").querySelector(".chip[aria-pressed=true]")?.focus({preventScroll:true});
  }
}


function go(hash){if(location.hash===hash)navigate();else location.hash=hash;}
function currentRoute(){
  const raw=location.hash.slice(1),cut=raw.indexOf("?");
  const path=cut<0?raw:raw.slice(0,cut),params=new URLSearchParams(cut<0?"":raw.slice(cut+1));
  let parts;try{parts=path.split("/").map(decodeURIComponent);}catch{parts=[];}
  const view=Object.hasOwn(titles,parts[0])?parts[0]:"ask";return {view,parts,params};
}
async function navigate(){
  const n=++revision;activeAsk?.abort();
  const next=currentRoute(), was=context;context=next;
  const {view,parts,params}=next, nav=view==="publish"?"read":view;
  document.querySelectorAll("[data-nav]").forEach(a=>{if(a.dataset.nav===nav)a.setAttribute("aria-current","page");else a.removeAttribute("aria-current");});
  $("crumb").textContent=titles[view];document.title=titles[view]+" · 手册检索室";
  if(was.view!==view || was.parts[1]!==parts[1] || (view==="ask"&&String(was.params)!==String(params)))window.scrollTo(0,0);
  if($("gap-dialog").open)$("gap-dialog").close();
  $("view").setAttribute("aria-busy","true");
  try{
    const [lib,queueData]=await Promise.all([api("/api/documents"),api("/api/gaps?status=all")]);
    if(n!==revision)return;
    documents=lib.documents;sections=lib.sections;gaps=queueData.gaps;setRail();
    if(view==="ask")await drawDesk(params,n);
    else if(view==="read"){if(parts[1])await reader(parts[1],parts[2],params,n);else catalog();}
    else if(view==="publish")await publisher(parts[1],params,n);
    else if(view==="gaps")queue(parts[1]||"open",parts[2]);
    else {
      header("检索评测","两份内置手册的固定版本服务端评测，逐题核验检索与回答。");
      if(!report)report=await api("/api/evaluation");
      if(n===revision){$("view").innerHTML='<section id="evaluation"></section>';drawReport(report,parts[1]||"all");}
    }
  }catch(error){
    if(n===revision&&error.name!=="AbortError"){
      $("view").innerHTML=`<div class="panel"><p class="feedback" role="alert">${esc(error.message)} <button type="button" class="action-link" data-retry>重试</button></p></div>`;
    }
  }finally{if(n===revision)$("view").setAttribute("aria-busy","false");}
}
function openGap(reason){
  gapReason=reason==="insufficient"?"insufficient":"feedback";
  const fromAnswer=context.view==="ask" && lastAnswer?.hash===location.hash;
  $("gap-question").value=fromAnswer?lastAnswer.question:"";
  $("gap-scope").innerHTML=picker("gap-scope",fromAnswer?lastAnswer.project:"all",scopes(),"涉及手册");
  $("gap-error").hidden=true;$("gap-dialog").showModal();$("gap-question").focus();
}
async function saveGap(form){
  const question=$("gap-question").value.trim();
  if(!question){$("gap-question").focus();return;}
  const save=form.querySelector("[type=submit]");save.disabled=true;$("gap-error").hidden=true;
  try{
    const data=await post("/api/gaps",{question,project:getPick("gap-scope"),reason:gapReason});
    $("gap-dialog").close();notify(data.created?"问题已登记":"已定位到同一项待补问题");
    go(gapLink(data.gap.status,data.gap.id));
  }catch(e){showError($("gap-error"),e.message);}
  finally{save.disabled=false;}
}
function revisionCheck(form){
  const source=$("doc-url");
  if(!source.validity.valid)source.closest("details").open=true;
  if(!form.reportValidity())return false;
  if(!$("doc-title").value.trim()||!$("doc-content").value.trim()){
    showError($("publish-error"),"请填写手册名称和正文。");return false;
  }
  if(new TextEncoder().encode($("doc-content").value).length>256*1024){
    showError($("publish-error"),"正文超过 256 KiB，请按主题拆分。");return false;
  }
  return true;
}
async function saveDocument(form){
  const err=$("publish-error");err.hidden=true;
  if(!revisionCheck(form))return;
  const project=form.dataset.project,save=form.querySelector("[type=submit]");
  const payload={title:$("doc-title").value.trim(),content:$("doc-content").value,sourceUrl:$("doc-url").value.trim()};
  if(project){payload.project=project;payload.expectedRevision=Number(form.dataset.revision);}
  save.disabled=true;
  try{
    const result=await post("/api/documents",payload);lastAnswer=null;
    notify(result.created?"手册已发布":"已打开相同内容的现行版本");
    if(returnGap){const jump=returnGap;returnGap="";go(jump);}
    else if(project || payload.title===workflowExample.title)go(readLink(result.document.id));
    else go("#ask?"+new URLSearchParams({project:result.document.id,ready:"1"}));
  }catch(e){if(err.isConnected)showError(err,e.message);}
  finally{save.disabled=false;}
}
async function readFile(input){
  const file=input.files[0],err=$("publish-error");if(!file)return;
  try{
    if(!/\.(md|markdown|txt)$/i.test(file.name)||file.size>256*1024)throw new Error("请选择 256 KiB 以内的 Markdown 或 TXT 文件。");
    const text=new TextDecoder("utf-8",{fatal:true}).decode(await file.arrayBuffer());
    if(!text.trim())throw new Error("文件中没有正文。");
    if(!input.isConnected)return;
    const currentTitle=$("doc-title").value.trim();
    if(!currentTitle||(!$("publish-form").dataset.project&&currentTitle===workflowExample.title&&$("doc-content").value===workflowExample.initial))
      $("doc-title").value=file.name.replace(/\.[^.]+$/,"").slice(0,96);
    $("doc-content").value=text;
    $("file-label").textContent=file.name;err.hidden=true;
    updatePublishButton();
  }catch(e){if(err.isConnected)showError(err,e instanceof TypeError?"文件需要使用 UTF-8 编码。":e.message);}
  input.value="";
}
async function resolveGap(form){
  const choice=form.querySelector('input[name=evidence]:checked');if(!choice)return;
  const save=form.querySelector("[type=submit]");save.disabled=true;const err=$("resolve-error");err.hidden=true;
  try{
    const data=await post("/api/gaps/"+pathPart(form.dataset.gap)+"/resolve",{sectionId:choice.value,note:$("resolution-note").value.trim()});
    lastAnswer=null;returnGap="";notify("已结案并保存引用依据");go(gapLink("resolved",data.gap.id));
  }catch(e){if(err.isConnected)showError(err,e.message);}
  finally{save.disabled=false;}
}
function copyFallback(host,text){
  const field=document.createElement("textarea");field.className="copy-url";field.readOnly=true;field.setAttribute("aria-label","可手动复制的文本");
  field.value=text;host.append(field);field.focus();field.select();
}
async function copyLink(el){
  const url=new URL(el.dataset.copyLink,location.href).href;
  try{await navigator.clipboard.writeText(url);notify("已复制段落链接");}
  catch{copyFallback(el.closest(".section-item"),url);}
}
async function copyAnswer(){
  if(!lastAnswer)return;
  const result=await window.supportActions.copyAnswer({question:lastAnswer.question,result:lastAnswer.result,url:location.href});
  if(result.copied)notify("已复制答复与出处");else{const host=$("reply-copy");host.replaceChildren();copyFallback(host,result.text);}
}
function chooseOption(control){
  const menu=control.closest(".picker"),key=menu.dataset.picker,val=control.dataset.pick;
  if(key==="version"){go(readLink(context.parts[1],"",val));return;}
  menu.querySelectorAll("[data-pick]").forEach(b=>b.setAttribute("aria-pressed",String(control===b)));
  const label=control.firstElementChild.textContent;
  menu.dataset.value=val;const summary=menu.querySelector("summary");summary.querySelector("span").textContent=label;
  summary.setAttribute("aria-label",(key==="scope"?"查询范围":"涉及手册")+"，"+label);menu.open=false;summary.focus();
}
function closePickers(except){
  document.querySelectorAll(".picker[open]").forEach(menu=>{if(!menu.contains(except))menu.open=false;});
}
document.addEventListener("submit",e=>{
  const f=e.target;
  if(!["ask-form","gap-form","publish-form","resolve-form"].includes(f.id))return;
  e.preventDefault();
  if(f.id==="ask-form"){
    const q=$("question").value.trim();if(!q){$("question").focus();return;}lastAnswer=null;go(askLink(q,getPick("scope")));
  }else if(f.id==="gap-form")saveGap(f);
  else if(f.id==="publish-form")saveDocument(f);
  else resolveGap(f);
});
document.addEventListener("input",e=>{
  if(e.target.id==="doc-title")updatePublishButton();
  if(e.target.id==="library-filter")$("catalog-rows").innerHTML=catalogRows(e.target.value);
  if(e.target.id==="evidence-search"){
    const keep=$("resolve-form").querySelector('input[name=evidence]:checked')?.value;
    drawOptions(lastGap,e.target.value,keep);
  }
});
document.addEventListener("change",e=>{
  const el=e.target;
  if(el.id==="doc-file")readFile(el);
  if(el.name==="evidence"){
    const section=sections.find(s=>s.id===el.value);if(!section)return;
    $("selected-evidence").innerHTML="<blockquote>"+esc(section.text)+"</blockquote>";
    $("resolve-form").querySelector("[type=submit]").disabled=false;
  }
});
document.addEventListener("click",e=>{
  closePickers(e.target);
  const el=e.target.closest("button,a");if(!el)return;
  if(el.matches(".skip")){e.preventDefault();$("main").focus();return;}
  if(el.hasAttribute("data-pick"))chooseOption(el);
  if(el.hasAttribute("data-register"))openGap(el.dataset.register);
  if(el.hasAttribute("data-dismiss"))$("gap-dialog").close();
  if(el.hasAttribute("data-fill-example"))exampleContent(context.parts[1]);
  if(el.hasAttribute("data-copy-link"))copyLink(el);
  if(el.hasAttribute("data-copy-answer"))copyAnswer().catch(()=>notify("复制失败，请重试。"));
  if(el.hasAttribute("data-export-gaps")){const f=el.dataset.exportGaps;window.supportActions.exportGaps(gaps.filter(g=>f==="all"||g.status===f).map(g=>({...g,projectTitle:docName(g.project)})));}
  if(el.hasAttribute("data-eval")){focusFilter=true;go(el.dataset.eval==="all"?"#evaluation":"#evaluation/"+el.dataset.eval);}
  if(el.hasAttribute("data-retry")){lastAnswer=null;navigate();}
  if(el.matches('a[href^="#publish"]'))returnGap=context.view==="gaps"&&lastGap?.status==="open"?gapLink("open",lastGap.id):"";
});
document.addEventListener("keydown",e=>{
  const menu=e.target.closest(".picker");
  if(menu && e.key==="Escape" && menu.open){e.preventDefault();e.stopPropagation();menu.open=false;menu.querySelector("summary").focus();return;}
  if(menu && ["ArrowDown","ArrowUp","Home","End"].includes(e.key)){
    e.preventDefault();menu.open=true;const buttons=[...menu.querySelectorAll("[data-pick]")],i=buttons.indexOf(document.activeElement);
    const n=e.key==="Home"?0:e.key==="End"?buttons.length-1:e.key==="ArrowDown"?Math.min(buttons.length-1,i+1):Math.max(0,i-1);
    buttons[n]?.focus();return;
  }
});
document.addEventListener("focusin",e=>closePickers(e.target));
window.addEventListener("hashchange",navigate);
navigate();
