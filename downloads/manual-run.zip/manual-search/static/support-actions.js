"use strict";

(() => {
  function citationLabel(section) {
    const name = section.document || section.title || section.project;
    const lines = section.start === section.end ? String(section.start) : section.start + "–" + section.end;
    return [name, section.version, section.start && "第 " + lines + " 行"].filter(Boolean).join(" · ");
  }

  function sourceLink(section) {
    // Imported content lives in its own workspace; an external reader still gets the cited words.
    const address = section.sourceUrl || section.url;
    try {
      const parsed = new URL(address);
      return ["https:", "http:"].includes(parsed.protocol) ? parsed.href : "";
    } catch {
      return "";
    }
  }

  function answerText(question, result) {
    const sources = result.citations.map((section, index) => {
      const quote = section.snippet || section.text;
      return ["[" + (index + 1) + "] " + citationLabel(section), quote, sourceLink(section)]
        .filter(Boolean).join("\n");
    });
    return [question, result.answer, ...sources].filter(Boolean).join("\n\n");
  }

  async function copyAnswer({ question, result }) {
    const text = answerText(question, result);
    try {
      await navigator.clipboard.writeText(text);
      return { text, copied: true };
    } catch {
      return { text, copied: false };
    }
  }

  function csvCell(value) {
    let text = String(value ?? "");
    if (/^\s*[=+@-]/.test(text) || /^[\t\r\n]/.test(text)) text = "'" + text;
    return '"' + text.replace(/"/g, '""') + '"';
  }

  function gapCsv(gaps) {
    const rows = [["编号", "问题", "查询范围", "登记原因", "状态", "登记时间", "结案时间", "引用依据", "证据原文", "处理说明"]];
    const ranges = { all: "全部手册", clinic: "门诊候补与改约工作台", ledger: "双账核对工作台" };
    for (const gap of gaps) {
      const evidence = gap.evidence;
      rows.push([gap.id, gap.question, gap.projectTitle || ranges[gap.project] || gap.project,
        gap.reason === "feedback" ? "答复待复核" : "资料不足", gap.status === "resolved" ? "已解决" : "待处理",
        gap.createdAt, gap.resolvedAt, evidence && citationLabel(evidence),
        evidence && (evidence.snippet || evidence.text), gap.note]);
    }
    return "\uFEFF" + rows.map(row => row.map(csvCell).join(",")).join("\r\n") + "\r\n";
  }

  function exportGaps(gaps, filename = "知识待补清单.csv") {
    if (!gaps.length) return;
    const blob = new Blob([gapCsv(gaps)], { type: "text/csv;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = filename;
    document.body.append(link);
    link.click();
    link.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  }

  window.supportActions = Object.freeze({ copyAnswer, exportGaps, answerText, gapCsv });
})();
