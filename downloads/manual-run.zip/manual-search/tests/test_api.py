import json
import threading
from pathlib import Path
from tempfile import TemporaryDirectory
import unittest
from http.server import ThreadingHTTPServer
from unittest.mock import patch
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

from model_answer import LocalModel
from knowledge_store import KnowledgeStore
from server import ManualHandler


class ApiTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.workspace = TemporaryDirectory()
        cls.service = ThreadingHTTPServer(("127.0.0.1", 0), ManualHandler)
        cls.service.store = KnowledgeStore(Path(cls.workspace.name)/"knowledge.sqlite3")
        cls.service.model = None
        cls.url = f"http://127.0.0.1:{cls.service.server_port}"
        cls.thread = threading.Thread(target=cls.service.serve_forever, daemon=True)
        cls.thread.start()

    @classmethod
    def tearDownClass(cls):
        cls.service.shutdown()
        cls.service.server_close()
        cls.thread.join()
        cls.workspace.cleanup()

    def ask(self, data):
        request = Request(self.url+"/api/ask", json.dumps(data).encode(),
                          headers={"Content-Type":"application/json"})
        with urlopen(request) as response:
            return json.load(response)

    def test_query_and_source_location(self):
        result = self.ask({"question":"再次运行相同样例能找回复核历史吗？", "project":"ledger"})
        self.assertEqual(result["mode"], "extractive")
        self.assertEqual(result["status"], "answered")
        citation = result["citations"][0]
        with urlopen(self.url+"/api/documents") as response:
            library = json.load(response)
        section = next(item for item in library["sections"] if item["id"] == citation["id"])
        self.assertEqual(section["text"], citation["text"])
        self.assertIn(section["commit"], section["url"])
        self.assertIn(citation["snippet"], section["text"])

    def test_invalid_questions(self):
        for data in ([], {}, {"question":"   "}, {"question":"查手册","project":[]},
                     {"question":"问"*501}):
            with self.subTest(data=data), self.assertRaises(HTTPError) as failure:
                self.ask(data)
            self.assertEqual(failure.exception.code, 400)


class ModelTest(unittest.TestCase):
    def setUp(self):
        self.model = LocalModel("http://127.0.0.1:1/v1", "test")
        passage = {"id":"doc-L2","text":"打开批次。可查复核记录。"}
        self.result = {"status":"answered","answer":"可查复核记录。","citations":[passage],"mode":"extractive"}

    def test_selected_sentence_is_in_the_cited_source(self):
        with patch.object(self.model, "select", return_value=[1]):
            result = self.model.compose("能查历史吗？", self.result)
        self.assertEqual(result["mode"], "model")
        self.assertEqual(result["answer"], "可查复核记录。")
        self.assertEqual(result["citations"][0]["snippet"], result["answer"])

    def test_downgrades_on_unavailable_or_empty_model(self):
        for options in ({"side_effect": URLError("unavailable")}, {"return_value": []}):
            with patch.object(self.model, "select", **options):
                self.assertEqual(self.model.compose("查历史", self.result), self.result)

    def test_unknown_never_calls_model(self):
        result = {**self.result, "status":"insufficient"}
        with patch.object(self.model, "select", side_effect=AssertionError):
            self.assertEqual(self.model.compose("查历史", result), result)
