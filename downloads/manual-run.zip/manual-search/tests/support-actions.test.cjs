const assert = require("node:assert/strict");
const test = require("node:test");
global.window = {};
require("../static/support-actions.js");
const {answerText, gapCsv} = global.window.supportActions;

test("copied replies retain the published version and text of local evidence", () => {
  const text = answerText("期限多长？", {answer:"三个工作日", citations:[{
    document:"借用手册", version:"v2", start:9, end:10, snippet:"续借可延长三个工作日。",
    url:"#read/device/revision2-L9"
  }]});
  assert.ok(text.includes("借用手册 · v2 · 第 9–10 行"));
  assert.ok(text.includes("续借可延长三个工作日。"));
  assert.ok(!text.includes("#read/"));
});

test("CSV preserves text and prevents cells from becoming formulas", () => {
  const csv = gapCsv([{id:"g-1",question:'=SUM(1,2)\n带"引号"',project:"all",reason:"feedback",status:"open"}]);
  assert.ok(csv.startsWith("\uFEFF"));
  assert.ok(csv.includes(`"'=SUM(1,2)\n带""引号"""`));
  assert.ok(csv.includes("答复待复核"));
});
