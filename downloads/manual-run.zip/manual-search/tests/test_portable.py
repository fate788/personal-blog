"""Tests for the buildable single-file public edition. Browser tests are optional."""
import importlib.util
from pathlib import Path
import subprocess
import sys
from tempfile import TemporaryDirectory
import unittest

ROOT = Path(__file__).resolve().parents[1]


def build(folder):
    destination = Path(folder)/"index.html"
    subprocess.run([sys.executable, "-B", str(ROOT/"portable/build.py"), "--output", str(destination)],
                   check=True, capture_output=True)
    return destination


class PortableBuildTest(unittest.TestCase):
    def test_includes_runtime_without_remote_dependencies(self):
        with TemporaryDirectory() as temp:
            markup = build(temp).read_text(encoding="utf-8")
            self.assertIn("manualOffline=Object.freeze", markup)
            self.assertIn("connect-src 'none'", markup)
            head = markup.partition("</head>")[0]
            self.assertNotRegex(head, r'<script\b[^>]*\bsrc=')
            self.assertNotRegex(head, r'<link\b[^>]*rel="stylesheet"')
            self.assertNotRegex(head, r'url\((?:["\x27])?(?!data:)[\w./-]+\.webp')


@unittest.skipUnless(importlib.util.find_spec("playwright"), "Install Python Playwright and Chromium for browser tests")
class PortableBrowserTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        from playwright.sync_api import sync_playwright
        cls.playwright = sync_playwright().start()
        try:
            if sys.platform == "win32":
                cls.browser = cls.playwright.chromium.launch(channel="msedge", headless=True)
            else:
                cls.browser = cls.playwright.chromium.launch(headless=True)
        except Exception as error:
            cls.playwright.stop()
            raise unittest.SkipTest("Chromium is unavailable: "+str(error)) from error
        cls.folder = TemporaryDirectory()
        cls.url = build(cls.folder.name).as_uri()

    @classmethod
    def tearDownClass(cls):
        cls.browser.close()
        cls.playwright.stop()
        cls.folder.cleanup()

    def setUp(self):
        self.ctx = self.browser.new_context()
        self.addCleanup(self.ctx.close)
        self.page = self.ctx.new_page()
        self.page.goto(self.url)

    def request(self, path, data=None, expected=None, page=None):
        status, body = (page or self.page).evaluate("""async ([path, data]) => {
            const reply=await window.manualOffline.request(path,data === null ? {} :
                {method:"POST",body:JSON.stringify(data)});
            return [reply.status,await reply.json()];
        }""", [path, data])
        if expected:
            self.assertEqual(status, expected, body)
        else:
            self.assertIn(status, [200,201], body)
        return body

    def test_free_question_version_history_and_resolution(self):
        cases = [("候补排到我之后，能留多久？错过了怎么办？","clinic-L22"),
                 ("再次运行同一份样例账单，还能看到原来的复核记录吗？","ledger-L19")]
        for question, source in cases:
            answer = self.request("/api/ask", {"question":question})
            self.assertEqual(answer["status"], "answered", answer)
            self.assertIn(source, [s["id"] for s in answer["citations"]])
            self.assertEqual(answer["mode"],"extractive")
        answer = self.request("/api/ask", {"question":"预约窗口周末几点下班？"})
        self.assertEqual(answer["status"], "insufficient")
        fields = {"title":"差旅手册", "content":"# 出差报销\n\n## 票据\n员工须保存纸质车票。"}
        doc = self.request("/api/documents", fields)["document"]
        old = self.request("/api/documents/"+doc["id"])["sections"][0]
        question = "高铁车票报销最多允许多少元？"
        ask = {"question":question, "project":doc["id"]}
        self.assertEqual(self.request("/api/ask",ask)["status"],"insufficient")
        gap = self.request("/api/gaps",ask)["gap"]
        self.assertFalse(self.request("/api/gaps",ask)["created"])
        update={**fields, "project":doc["id"],"expectedRevision":1,
                "content":fields["content"]+"\n\n## 高铁上限\n高铁车票每次报销最多允许 860 元。"}
        self.assertEqual(self.request("/api/documents", update)["document"]["revision"],2)
        self.assertFalse(self.request("/api/documents", update)["created"])
        self.request("/api/documents", {**update,"content":"# 过时的草稿\n新的正文。"}, 409)
        answer=self.request("/api/ask",ask)
        self.assertEqual(answer["status"],"answered",answer)
        self.assertIn("860",answer["answer"])
        current=answer["citations"][0]
        self.assertEqual(current["revision"],2)
        self.assertEqual(self.request("/api/sections/"+old["id"])["section"]["revision"],1)
        self.assertEqual(self.request("/api/documents/"+doc["id"]+"?revision=1")["content"], fields["content"])
        resolve="/api/gaps/"+gap["id"]+"/resolve"
        self.request(resolve,{"sectionId":"ledger-L19"},422)
        self.request(resolve,{"sectionId":old["id"]},422)
        done=self.request(resolve,{"sectionId":current["id"],"note":"已核对票据限额。"})["gap"]
        self.assertEqual(done["evidence"]["id"],current["id"])
        verified = self.request("/api/ask", {**ask, "question":question.rstrip("？")})
        self.assertEqual(verified["resolutionId"],gap["id"])
        self.assertEqual(verified["citations"][0]["id"],current["id"])
        self.page.reload()
        self.assertEqual(self.request("/api/gaps?status=resolved")["gaps"][0]["id"], gap["id"])
        self.request("/api/documents",{**update, "expectedRevision":2,"content":update["content"].replace("860","750")})
        changed=self.request("/api/ask",ask)
        self.assertNotIn("resolutionId",changed)
        self.assertIn("750",changed["answer"])
        self.assertIn("860",self.request("/api/gaps?status=resolved")["gaps"][0]["evidence"]["text"])
        other=self.browser.new_context()
        try:
            fresh=other.new_page(); fresh.goto(self.url)
            self.assertEqual(self.request("/api/gaps",page=fresh)["gaps"],[])
            self.assertEqual(len(self.request("/api/documents",page=fresh)["documents"]),2)
        finally:
            other.close()

    def test_optimistic_updates_across_two_tabs(self):
        page2=self.ctx.new_page()
        page2.goto(self.url)
        fields={"title":"新员工指南","content":"## 账号\n开通账号前提交姓名。"}
        doc=self.request("/api/documents",fields)["document"]
        results=self.page.evaluate("""async ([uri,payload]) => Promise.all(["甲","乙"].map(async label=>{
            const reply=await window.manualOffline.request(uri,{method:"POST",body:JSON.stringify({
                ...payload,content:payload.content+label
            })});
            return reply.status;
        }))""", ["/api/documents",{**fields,"project":doc["id"],"expectedRevision":1}])
        self.assertEqual(sorted(results),[201,409])
        self.assertEqual(self.request("/api/documents/"+doc["id"],page=page2)["document"]["revision"],2)

    def test_builtin_gap_can_be_closed_by_related_team_supplement(self):
        q={"question":"预约窗口周末几点下班？","project":"clinic"}
        gap=self.request("/api/gaps",q)["gap"]
        doc=self.request("/api/documents", {"title":"虚构窗口服务时间", "content":"## 周末营业时间\n预约窗口周末 16:30 下班。"})
        ref=doc["sections"][0]
        self.request("/api/gaps/"+gap["id"]+"/resolve",{"sectionId":ref["id"]})
        answered=self.request("/api/ask",q)
        self.assertEqual(answered["status"],"answered")
        self.assertEqual(answered["resolutionId"],gap["id"])
        self.assertIn("16:30",answered["answer"])

    def test_operate_support_desk_without_network(self):
        from playwright.sync_api import expect
        page=self.page
        external=[]
        self.ctx.on("request",lambda request: external.append(request.url) if request.url.startswith(("http://","https://")) else None)
        page.goto(self.url+"#publish")
        page.locator("[data-fill-example]").click()
        page.locator("#publish-form button[type=submit]").click()
        expect(page.locator(".reader-paper")).to_be_visible()
        project=page.url.split("#read/")[1].split("/")[0]
        page.goto(self.url+"#ask")
        question=page.evaluate("window.manualWorkflowExample.question")
        page.locator("#question").fill(question)
        scope=page.locator('[data-picker="scope"]')
        scope.locator("summary").click()
        scope.get_by_role("button",name="IT 服务台 · 备用设备借用手册",exact=True).click()
        page.locator("#ask-form button[type=submit]").click()
        page.locator("[data-register=insufficient]").click()
        page.locator("#gap-form button[type=submit]").click()
        expect(page.locator("#resolve-form")).to_be_visible()
        page.locator('#resolve-form a[href^="#publish/"]').click()
        page.locator("[data-fill-example]").click()
        page.locator("#publish-form button[type=submit]").click()
        expect(page.locator("#resolve-form")).to_be_visible()
        page.locator("#evidence-search").fill("续借期限")
        page.locator('input[name=evidence]').first.check()
        page.locator("#resolve-form button[type=submit]").click()
        expect(page.get_by_text("结案依据",exact=True)).to_be_visible()
        page.reload()
        expect(page.locator(".source-box").first).to_contain_text("三个工作日")
        self.assertEqual(self.request("/api/documents/"+project)["document"]["revision"],2)
        self.assertEqual(external,[])


if __name__ == "__main__":
    unittest.main()
