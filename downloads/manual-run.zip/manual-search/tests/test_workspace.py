from concurrent.futures import ThreadPoolExecutor
import json
from pathlib import Path
from tempfile import TemporaryDirectory
import threading
import unittest
from urllib.request import Request, urlopen

from engine import search
from knowledge_store import KnowledgeStore, WorkspaceError
from server import ManualHandler, ThreadingHTTPServer


INITIAL = "# 展厅预约\n\n## 领取钥匙\n到服务台登记展厅名称后领取钥匙。\n"
RULE = "\n## 临时延期\n展厅每次预约最多可以延长两个工作日。\n"
QUESTION = "展厅预约最多可延长几个工作日？"


class WorkspaceTest(unittest.TestCase):
    def setUp(self):
        directory = TemporaryDirectory()
        self.addCleanup(directory.cleanup)
        self.path = Path(directory.name)/"workspace.sqlite3"
        self.store = KnowledgeStore(self.path)

    def publish(self, content=INITIAL, **extra):
        return self.store.publish({"title":"展厅接待手册", "content":content, **extra})

    def test_current_only_search_and_immutable_editions(self):
        first = self.publish()
        project = first["document"]["id"]
        self.assertFalse(self.publish()["created"])
        saved = first["sections"][0]["id"]
        for scope in (project, "all"):
            self.assertEqual(search(QUESTION, scope, additions=self.store.searchable())["status"], "insufficient")
        second = self.publish(INITIAL+RULE, project=project, expectedRevision=1)
        self.assertEqual(second["document"]["revision"], 2)
        self.assertFalse(self.publish(INITIAL+RULE, project=project, expectedRevision=1)["created"])
        self.store = KnowledgeStore(self.path)
        for scope in (project, "all"):
            answer = search(QUESTION, scope, additions=self.store.searchable())
            self.assertIn("两个工作日", answer["answer"])
            self.assertEqual(answer["citations"][0]["id"], second["sections"][-1]["id"])
        self.assertEqual(self.store.edition(project, 1)["content"], INITIAL)
        self.assertEqual(self.store.section(saved)["revision"], 1)
        self.assertNotIn(saved, {s["id"] for s in self.store.library()["sections"]})
        self.assertEqual([v["revision"] for v in second["document"]["versions"]], [2,1])

    def test_conflicting_concurrent_edits_do_not_lose_an_update(self):
        first = self.publish()
        project = first["document"]["id"]
        def update(n):
            try:
                return self.publish(INITIAL+str(n), project=project, expectedRevision=1)["document"]["revision"]
            except WorkspaceError as exc:
                return exc.status
        with ThreadPoolExecutor(max_workers=4) as pool:
            results = list(pool.map(update, range(4)))
        self.assertCountEqual(results, [2,409,409,409])
        self.assertEqual(len(self.store.edition(project)["document"]["versions"]), 2)

    def test_publishing_rejects_incomplete_input_and_name_collisions(self):
        self.publish()
        for content,extra,status in (
            ("# 只有标题",{},400), ("文本",{"sourceUrl":"javascript:alert(1)"},400),
            ("文本",{"sourceUrl":"https://user@example.org/doc"},400),
            ("不同的正文",{},409), ("文本",{"project":"clinic","expectedRevision":1},409)):
            with self.subTest(extra=extra), self.assertRaises(WorkspaceError) as error:
                self.publish(content, **extra)
            self.assertEqual(error.exception.status, status)

    def test_duplicate_triage_reused_decision_and_stale_sources(self):
        p = self.publish(INITIAL+RULE)
        project = p["document"]["id"]
        with ThreadPoolExecutor(max_workers=4) as pool:
            tickets = list(pool.map(lambda _: self.store.add_gap({"question":QUESTION, "project":project}),range(4)))
        self.assertEqual(sum(g["created"] for g in tickets), 1)
        gap = tickets[0]["gap"]["id"]
        with self.assertRaises(WorkspaceError) as unrelated:
            self.store.resolve(gap, {"sectionId":p["sections"][0]["id"]})
        self.assertEqual(unrelated.exception.status,422)
        args = {"sectionId":p["sections"][-1]["id"],"note":"已由管理员核对延期条款。"}
        closed = self.store.resolve(gap, args)
        self.assertEqual(closed, self.store.resolve(gap, args))
        self.assertEqual(self.store.reviewed_answer(QUESTION.rstrip("？"), project)["resolutionId"], gap)
        self.assertEqual(len(self.store.gaps("open")), 0)
        newer = self.publish(INITIAL+RULE.replace("两个工作日","三个工作日"), project=project, expectedRevision=1)
        self.assertIsNone(self.store.reviewed_answer(QUESTION, project))
        self.assertIn("两个工作日", self.store.gaps("resolved")[0]["evidence"]["text"])
        reopened = self.store.add_gap({"question":QUESTION, "project":project})["gap"]
        self.assertNotEqual(reopened["id"], gap)
        with self.assertRaises(WorkspaceError) as stale:
            self.store.resolve(reopened["id"], args)
        self.assertEqual(stale.exception.status,422)
        self.assertEqual(self.store.resolve(reopened["id"], {"sectionId":newer["sections"][-1]["id"]})["status"],"resolved")

    def test_http_flow_with_a_team_supplement_for_a_readonly_manual(self):
        with ThreadingHTTPServer(("127.0.0.1",0), ManualHandler) as service:
            service.store = self.store
            service.model = None
            thread = threading.Thread(target=service.serve_forever,daemon=True)
            thread.start()
            def call(route, payload=None):
                base = "http://127.0.0.1:"+str(service.server_port)
                data = None if payload is None else json.dumps(payload).encode()
                with urlopen(Request(base+route,data,headers={"Content-Type":"application/json"})) as response:
                    return json.load(response)
            try:
                question = {"question":"演示窗口周末几点下班？", "project":"clinic"}
                self.assertEqual(call("/api/ask", question)["status"],"insufficient")
                self.assertEqual(call("/api/gaps")["gaps"], [])
                gap = call("/api/gaps", {**question, "reason":"feedback"})["gap"]
                manual = call("/api/documents", {"title":"窗口轮班补充规定","content":"## 周末下班时间\n演示窗口周末下午四点下班。"})
                section = manual["sections"][0]
                call("/api/gaps/"+gap["id"]+"/resolve", {"sectionId":section["id"]})
                reviewed = call("/api/ask", question)
                self.assertEqual(reviewed["resolutionId"],gap["id"])
                self.assertIn("下午四点",reviewed["answer"])
                self.assertEqual(call("/api/sections/"+section["id"])["section"]["text"], reviewed["answer"])
                self.assertEqual(call("/api/documents/"+section["project"]+"?revision=1")["sections"][0]["id"],section["id"])
                self.assertEqual(len(call("/api/gaps?status=resolved")["gaps"]),1)
                call("/api/gaps",question)
                self.assertNotIn("resolutionId",call("/api/ask",question))
            finally:
                service.shutdown()
                thread.join()
