"""Versioned workspace manuals and the evidence attached to support requests."""
from contextlib import closing, contextmanager
from datetime import datetime, timezone
from functools import lru_cache
from hashlib import sha256
import json
from pathlib import Path
import re
import sqlite3
from urllib.parse import urlsplit
from uuid import uuid4

from engine import CORPUS, SOURCES, TeamPassage, get_documents, get_sections, normalize, related_evidence


class WorkspaceError(ValueError):
    def __init__(self, message, status=400):
        super().__init__(message)
        self.status = status


def field(value, name, maximum, required=True):
    if not isinstance(value, str):
        raise WorkspaceError(f"{name}必须为文本。")
    value = value.strip()
    if (required and not value) or len(value) > maximum or any(ord(c) < 32 and c not in "\n\t" for c in value):
        raise WorkspaceError(f"请检查{name}，长度上限为 {maximum} 字。")
    try:
        value.encode("utf-8")
    except UnicodeEncodeError:
        raise WorkspaceError(f"{name}含无法读取的字符。") from None
    return value


def timestamp():
    return datetime.now(timezone.utc).isoformat(timespec="milliseconds").replace("+00:00","Z")


def question_key(question):
    return " ".join(normalize(question).split()).rstrip("!?。？！ ").strip() or normalize(question)


def source_link(value):
    value = field(value, "来源链接", 2048, required=False)
    if value:
        try:
            parsed = urlsplit(value)
            if (parsed.scheme not in {"http","https"} or not parsed.hostname or
                    parsed.username is not None or parsed.password is not None or
                    re.search(r"[\s\\]", value)):
                raise ValueError
            _ = parsed.port
        except ValueError:
            raise WorkspaceError("来源链接须为有效的 HTTP 或 HTTPS 网页地址。") from None
    return value


def split_sections(content, title):
    """Keep real source line ranges, paragraphs and independently addressable list items."""
    chapter = title
    block = []
    start = 1
    fenced = False
    for number, line in enumerate(content.split("\n"), 1):
        stripped = line.strip()
        fence = stripped.startswith(("```", "~~~"))
        heading = re.match(r"^#{1,6}\s+(.+)", stripped) if not fenced else None
        item = not fenced and re.match(r"^(?:[-*+]\s+|\d+[.)]\s+)", stripped)
        boundary = not fenced and (heading or item or not stripped or fence or
                                   sum(len(part) for part in block) >= 1000)
        if block and boundary:
            yield chapter, start, number-1, "\n".join(block)
            block = []
        if heading:
            chapter = heading.group(1).strip().rstrip("#").strip() or title
            continue
        if fence:
            fenced = not fenced
        if stripped or fenced:
            if not block:
                start = number
            block.append(line)
    if block:
        yield chapter, start, start+len(block)-1, "\n".join(block)


@lru_cache(maxsize=32)
def passages(project, revision, title, source_url, content):
    return tuple(TeamPassage(project, chapter, start, end, text, title, revision, source_url)
                 for chapter, start, end, text in split_sections(content, title))


def version_info(row):
    return {"revision":row["rev"], "version":f"v{row['rev']}", "publishedAt":row["published"], "sections":row["nsections"]}


def document_info(project, row, versions):
    return {**version_info(row), "id":project, "project":project, "document":row["title"],
            "title":row["title"], "name":row["title"], "url":row["url"], "sourceUrl":row["url"],
            "kind":"team", "versions":versions}


def builtin_library():
    documents = []
    for doc in get_documents():
        edition = {"revision":1, "version":doc["version"], "publishedAt":None, "sections":doc["sections"]}
        documents.append({**doc, "kind":"builtin", "revision":1, "versions":[edition], "sourceUrl":doc["url"]})
    sections = [{**row, "kind":"builtin", "revision":1, "sourceUrl":row["url"]} for row in get_sections()]
    return documents, sections


class KnowledgeStore:
    def __init__(self, path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with closing(sqlite3.connect(self.path, timeout=8)) as db:
            db.execute("PRAGMA journal_mode=WAL")
            db.executescript("""
                CREATE TABLE IF NOT EXISTS manuals (
                    id TEXT PRIMARY KEY, title_key TEXT NOT NULL UNIQUE, rev INTEGER NOT NULL);
                CREATE TABLE IF NOT EXISTS editions (
                    manual TEXT NOT NULL REFERENCES manuals(id), rev INTEGER NOT NULL, title TEXT NOT NULL,
                    url TEXT NOT NULL, content TEXT NOT NULL, digest TEXT NOT NULL, published TEXT NOT NULL,
                    nsections INTEGER NOT NULL, PRIMARY KEY(manual, rev));
                CREATE TABLE IF NOT EXISTS gaps (
                    id TEXT PRIMARY KEY, question TEXT NOT NULL, normalized TEXT NOT NULL, project TEXT NOT NULL,
                    reason TEXT NOT NULL, created TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'open',
                    resolved TEXT, evidence TEXT, note TEXT NOT NULL DEFAULT '');
                CREATE UNIQUE INDEX IF NOT EXISTS one_open_question ON gaps(project, normalized) WHERE status='open';
                CREATE INDEX IF NOT EXISTS previous_questions ON gaps(project, normalized);
            """)

    @contextmanager
    def connection(self, write=False):
        with closing(sqlite3.connect(self.path, timeout=8)) as db, db:
            db.row_factory = sqlite3.Row
            db.execute("PRAGMA foreign_keys=ON")
            db.execute("BEGIN IMMEDIATE" if write else "BEGIN")
            yield db

    @staticmethod
    def _history(db, project):
        return [version_info(row) for row in db.execute(
            "SELECT rev,published,nsections FROM editions WHERE manual=? ORDER BY rev DESC", (project,))]

    @staticmethod
    def _passages(row):
        return passages(row["manual"], row["rev"], row["title"], row["url"], row["content"])

    @staticmethod
    def _current(db):
        return db.execute("SELECT e.* FROM manuals m JOIN editions e ON (e.manual=m.id AND e.rev=m.rev) ORDER BY e.published DESC,m.id").fetchall()

    def searchable(self):
        with self.connection() as db:
            rows = self._current(db)
        return tuple(p for row in rows for p in self._passages(row))

    def library(self):
        documents, sections = builtin_library()
        with self.connection() as db:
            current = self._current(db)
            for row in current:
                documents.append(document_info(row["manual"], row, self._history(db, row["manual"])))
        for row in current:
            sections.extend(p.public() for p in self._passages(row))
        return {"documents":documents, "sections":sections}

    def edition(self, project, revision=None):
        if revision is not None and (type(revision) is not int or not 1 <= revision <= 2147483647):
            raise WorkspaceError("手册版本号无效。")
        if project in SOURCES:
            if revision not in (None, 1):
                raise WorkspaceError("没有这个手册版本。", 404)
            docs, sections = builtin_library()
            return {"document":next(doc for doc in docs if doc["id"] == project),
                    "sections":[s for s in sections if s["project"] == project],
                    "content":(CORPUS/f"{project}.md").read_text(encoding="utf-8")}
        with self.connection() as db:
            manual = db.execute("SELECT rev FROM manuals WHERE id=?", (project,)).fetchone()
            if manual is None:
                raise WorkspaceError("找不到这本手册。", 404)
            row = db.execute("SELECT * FROM editions WHERE manual=? AND rev=?", (project, revision or manual["rev"])).fetchone()
            if row is None:
                raise WorkspaceError("没有这个手册版本。", 404)
            doc = document_info(project, row, self._history(db, project))
        return {"document":doc, "sections":[p.public() for p in self._passages(row)], "content":row["content"]}

    def publish(self, data):
        title = field(data.get("title"), "手册标题", 96)
        body = data.get("content")
        if not isinstance(body, str):
            raise WorkspaceError("请提供 Markdown 或纯文本原文。")
        body = body.removeprefix("\ufeff").replace("\r\n","\n").replace("\r","\n")
        if len(body.encode("utf-8")) > 256*1024 or not body.strip() or "\x00" in body:
            raise WorkspaceError("正文须为非空文本，大小最多 256 KiB。")
        url = source_link(data.get("sourceUrl",""))
        key = " ".join(normalize(title).split())
        if key in {normalize(info[0]) for info in SOURCES.values()}:
            raise WorkspaceError("已有同名内置手册，请另取标题。", 409)
        digest = sha256(body.encode()).hexdigest()
        count = sum(1 for _ in split_sections(body, title))
        if not count:
            raise WorkspaceError("请在标题下填写至少一段可引用的正文。")
        project = data.get("project")
        expected = data.get("expectedRevision")
        updating = project is not None
        if updating and (not isinstance(project,str) or type(expected) is not int or expected < 1):
            raise WorkspaceError("发布修订时请提交手册和正在编辑的版本号。")
        created = False
        with self.connection(write=True) as db:
            if updating and project in SOURCES:
                raise WorkspaceError("内置手册为固定版本，可另建团队手册。", 409)
            if not updating:
                existing = db.execute("SELECT id FROM manuals WHERE title_key=?", (key,)).fetchone()
                project = existing["id"] if existing else "team-"+uuid4().hex
            current = db.execute("SELECT e.* FROM manuals m JOIN editions e ON e.manual=m.id AND e.rev=m.rev WHERE m.id=?", (project,)).fetchone()
            if updating and not current:
                raise WorkspaceError("找不到要修订的手册。", 404)
            same = current and (current["title"],current["digest"],current["url"]) == (title,digest,url)
            if same:
                revision = current["rev"]
            else:
                if current and not updating:
                    raise WorkspaceError("已有同名手册，请从资料库中发布修订。", 409)
                if current and current["rev"] != expected:
                    raise WorkspaceError("这本手册已有新版，请重新打开现行版本。", 409)
                revision = current["rev"] + 1 if current else 1
                duplicate = db.execute("SELECT 1 FROM manuals WHERE title_key=? AND id<>?", (key, project)).fetchone()
                if duplicate:
                    raise WorkspaceError("其他手册已经使用该标题。", 409)
                if current:
                    db.execute("UPDATE manuals SET rev=?,title_key=? WHERE id=?", (revision,key,project))
                else:
                    db.execute("INSERT INTO manuals VALUES (?,?,?)", (project,key,revision))
                db.execute("INSERT INTO editions VALUES (?,?,?,?,?,?,?,?)", (project,revision,title,url,body,digest,timestamp(),count))
                created = True
        return {**self.edition(project, revision), "created":created}

    def _section(self, db, section_id, current_only=False):
        match = re.fullmatch(r"(team-[a-z0-9]+)-v(\d{1,9})-L(\d{1,9})", section_id)
        if match:
            project, rev, _ = match.groups()
            row = db.execute("SELECT e.*,m.rev AS current FROM editions e JOIN manuals m ON m.id=e.manual WHERE e.manual=? AND e.rev=?",
                             (project,int(rev))).fetchone()
            if row and current_only and int(rev) != row["current"]:
                raise WorkspaceError("请选择现行版本的原文作为依据。", 422)
            rows = (p.public() for p in self._passages(row)) if row else ()
        else:
            rows = builtin_library()[1]
        section = next((s for s in rows if s["id"] == section_id), None)
        if section is None:
            raise WorkspaceError("找不到所选原文。", 404)
        return section

    def section(self, section_id):
        with self.connection() as db:
            return self._section(db, section_id)

    @staticmethod
    def _gap(row):
        evidence = json.loads(row["evidence"]) if row["evidence"] else None
        return {"id":row["id"], "question":row["question"], "project":row["project"], "reason":row["reason"],
                "status":row["status"], "createdAt":row["created"], "resolvedAt":row["resolved"],
                "sectionId":evidence["id"] if evidence else None, "evidence":evidence, "note":row["note"]}

    def gaps(self, status="all"):
        if status not in {"all","open","resolved"}:
            raise WorkspaceError("未知的待补问题状态。")
        with self.connection() as db:
            rows = db.execute("SELECT * FROM gaps WHERE ?='all' OR status=? ORDER BY created DESC,rowid DESC", (status,status))
            return [self._gap(row) for row in rows]

    def add_gap(self, data):
        question = field(data.get("question"), "问题", 500)
        project = field(data.get("project","all"), "手册范围", 64)
        reason = data.get("reason","insufficient")
        if reason not in ("insufficient","feedback"):
            raise WorkspaceError("未知的登记原因。")
        key = question_key(question)
        with self.connection(write=True) as db:
            if project not in {*SOURCES,"all"} and not db.execute("SELECT 1 FROM manuals WHERE id=?", (project,)).fetchone():
                raise WorkspaceError("找不到这本手册。", 404)
            row = db.execute("SELECT * FROM gaps WHERE project=? AND normalized=? AND status='open'", (project,key)).fetchone()
            if row:
                return {"gap":self._gap(row), "created":False}
            gap_id = "gap-"+uuid4().hex
            db.execute("INSERT INTO gaps(id,question,normalized,project,reason,created) VALUES (?,?,?,?,?,?)",
                       (gap_id,question,key,project,reason,timestamp()))
            row = db.execute("SELECT * FROM gaps WHERE id=?", (gap_id,)).fetchone()
            return {"gap":self._gap(row), "created":True}

    def reviewed_answer(self, question, project):
        with self.connection() as db:
            row = db.execute("SELECT * FROM gaps WHERE project=? AND normalized=? ORDER BY rowid DESC LIMIT 1",
                             (project,question_key(question))).fetchone()
            if not row or row["status"] != "resolved":
                return None
            gap = self._gap(row)
            evidence = gap["evidence"]
            if evidence["kind"] == "team":
                current = db.execute("SELECT rev FROM manuals WHERE id=?", (evidence["project"],)).fetchone()
                if not current or evidence["revision"] != current["rev"]:
                    return None
        return {"status":"answered", "mode":"extractive", "method":"reviewed", "answer":evidence["text"],
                "citations":[evidence], "results":[evidence], "resolutionId":gap["id"],
                "modeNote":"已由待补问题的复核记录确认。"}

    def resolve(self, gap_id, data):
        section_id = field(data.get("sectionId"), "依据段落", 140)
        note = field(data.get("note",""), "复核说明", 1000, required=False)
        with self.connection(write=True) as db:
            row = db.execute("SELECT * FROM gaps WHERE id=?", (gap_id,)).fetchone()
            if row is None:
                raise WorkspaceError("找不到这条待补问题。", 404)
            if row["status"] == "resolved":
                previous = self._gap(row)
                if previous["sectionId"] == section_id and previous["note"] == note:
                    return previous
                raise WorkspaceError("该问题已经处理，请刷新查看已有结论。", 409)
            evidence = self._section(db, section_id, current_only=True)
            in_scope = (row["project"] in ("all", evidence["project"]) or
                        row["project"] in SOURCES and evidence["kind"] == "team")
            if not in_scope or not related_evidence(row["question"], evidence):
                raise WorkspaceError("请核对原文，并选择能支持该问题的现行段落。", 422)
            db.execute("UPDATE gaps SET status='resolved',resolved=?,evidence=?,note=? WHERE id=?",
                       (timestamp(),json.dumps(evidence,ensure_ascii=False),note,gap_id))
            return self._gap(db.execute("SELECT * FROM gaps WHERE id=?", (gap_id,)).fetchone())
