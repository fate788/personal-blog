"""Serve the manual collection and search app with Python's standard library."""
import argparse
import json
import mimetypes
import os
import re
import sqlite3
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, unquote, urlsplit

from engine import search
from knowledge_store import KnowledgeStore, WorkspaceError
from model_answer import LocalModel

ROOT = Path(__file__).resolve().parent
STATIC = ROOT / "static"


class ManualHandler(BaseHTTPRequestHandler):
    def reply(self, code, body, mime):
        self.send_response(code)
        self.send_header("Content-Type", mime)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-cache")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.end_headers()
        if self.command != "HEAD":
            try:
                self.wfile.write(body)
            except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError):
                pass

    def data(self, value, code=200):
        self.reply(code, json.dumps(value, ensure_ascii=False, allow_nan=False).encode(),
                   "application/json; charset=utf-8")

    def do_HEAD(self):
        self.do_GET()

    def do_GET(self):
        address = urlsplit(self.path)
        path = unquote(address.path)
        params = parse_qs(address.query)
        try:
            if path == "/api/documents":
                self.data(self.server.store.library())
                return
            if match := re.fullmatch(r"/api/documents/([^/]+)", path):
                raw = params.get("revision", [None])[0]
                if raw is not None and not re.fullmatch(r"[0-9]{1,9}", raw):
                    raise WorkspaceError("手册版本号无效。")
                self.data(self.server.store.edition(match[1], int(raw) if raw is not None else None))
                return
            if match := re.fullmatch(r"/api/sections/([^/]+)", path):
                self.data({"section":self.server.store.section(match[1])})
                return
            if path == "/api/gaps":
                self.data({"gaps":self.server.store.gaps(params.get("status", ["all"])[0])})
                return
        except WorkspaceError as exc:
            self.data({"error":str(exc)}, exc.status)
            return
        except sqlite3.OperationalError:
            self.data({"error":"知识库暂时不可用，请稍后重试。"}, 503)
            return
        if path == "/api/evaluation":
            try:
                report = (ROOT / "evaluation" / "report.json").read_bytes()
            except FileNotFoundError:
                self.data({"error": "评测报告尚未生成。"}, 503)
            else:
                self.reply(200, report, "application/json; charset=utf-8")
        elif path == "/api/health":
            self.data({"status":"ok", "modelConfigured": bool(self.server.model)})
        else:
            if path == "/":
                path = "/index.html"
            file = (STATIC / path.lstrip("/")).resolve()
            if not file.is_relative_to(STATIC) or not file.is_file():
                self.data({"error": "未找到页面。"}, 404)
                return
            mime = mimetypes.guess_type(file.name)[0] or "application/octet-stream"
            if file.suffix == ".js":
                mime = "text/javascript"
            self.reply(200, file.read_bytes(), mime + ("; charset=utf-8" if mime.startswith("text/") else ""))

    def do_POST(self):
        path = urlsplit(self.path).path
        close_gap = re.fullmatch(r"/api/gaps/([a-z0-9-]+)/resolve", path)
        if path not in {"/api/documents", "/api/gaps", "/api/ask"} and not close_gap:
            self.data({"error": "未找到接口。"}, 404)
            return
        if self.headers.get_content_type() != "application/json":
            self.data({"error": "请求需要 JSON 格式。"}, HTTPStatus.UNSUPPORTED_MEDIA_TYPE)
            return
        try:
            size = int(self.headers.get("Content-Length", "0"))
            if not 0 < size <= (2*1024*1024 if path == "/api/documents" else 16384):
                raise WorkspaceError("请求为空或超出大小限制。", 413)
            payload = json.loads(self.rfile.read(size))
            if not isinstance(payload, dict):
                raise ValueError
            if path == "/api/documents":
                result = self.server.store.publish(payload)
                self.data(result, 201 if result["created"] else 200)
                return
            if path == "/api/gaps":
                result = self.server.store.add_gap(payload)
                self.data(result, 201 if result["created"] else 200)
                return
            if close_gap:
                self.data({"gap":self.server.store.resolve(close_gap[1], payload)})
                return
            question = payload.get("question")
            project = payload.get("project", "all")
            if not isinstance(question, str) or not 1 <= len(question.strip()) <= 500 or not isinstance(project,str):
                raise ValueError
            question = question.strip()
            question.encode("utf-8")
            reviewed = self.server.store.reviewed_answer(question, project)
            if reviewed is not None:
                self.data(reviewed)
                return
            result = dict(search(question, project=project, method="hybrid", additions=self.server.store.searchable()),
                          mode="extractive")
        except WorkspaceError as exc:
            self.data({"error":str(exc)}, exc.status)
            return
        except (UnicodeError, ValueError, OverflowError, RecursionError):
            self.data({"error": "请检查提交的文本、手册范围和 JSON 格式。"}, 400)
            return
        except sqlite3.OperationalError:
            self.data({"error":"知识库暂时不可用，请稍后重试。"}, 503)
            return
        if self.server.model:
            result = self.server.model.compose(question, result)
        self.data(result)


def serve(port, model_url="", model_name="manual-editor", host="127.0.0.1", db=None):
    store = KnowledgeStore(db or os.getenv("MANUAL_WORKSPACE_DB") or ROOT/"data"/"knowledge.sqlite3")
    with ThreadingHTTPServer((host, port), ManualHandler) as server:
        server.store = store
        server.model = LocalModel(model_url, model_name) if model_url else None
        print(f"http://{host}:{server.server_port}/", flush=True)
        server.serve_forever()


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", default=8799, type=int)
    parser.add_argument("--db", type=Path, help="Workspace SQLite file")
    parser.add_argument("--model-url", default=os.environ.get("MANUAL_MODEL_URL", ""))
    parser.add_argument("--model-name", default=os.environ.get("MANUAL_MODEL_NAME", "manual-editor"))
    args = parser.parse_args()
    serve(args.port, args.model_url, args.model_name, args.host, args.db)
