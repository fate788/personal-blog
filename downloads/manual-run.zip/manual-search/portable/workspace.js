/* The public edition is a local workspace. IndexedDB read-write transactions
   serialize editors in different tabs without sending visitor documents anywhere. */
(() => {
  "use strict";
  const seed=window.manualPortableSeed;
  delete window.manualPortableSeed;
  const search=createManualSearch(seed.retrieval);
  const dbName="manual-room-enterprise-v2";
  const fresh=()=>({manuals:[],gaps:[]});
  let connection;

  class ApiError extends Error {
    constructor(status,message) { super(message); this.status=status; }
  }
  function reject(status,message) { throw new ApiError(status,message); }
  function database() {
    if (!connection) connection=new Promise((resolve,rejectOpen)=>{
      const pending=indexedDB.open(dbName,1);
      pending.onupgradeneeded=()=>pending.result.createObjectStore("workspace");
      pending.onsuccess=()=>{
        const db=pending.result;
        db.onversionchange=()=>{ db.close(); connection=null; };
        resolve(db);
      };
      pending.onerror=()=>rejectOpen(pending.error);
    }).catch(error=>{connection=null;throw error;});
    return connection;
  }
  async function workspace(mode, operation) {
    let db;
    try { db=await database(); }
    catch {
      if (mode==="readonly") return operation(fresh());
      reject(503,"此浏览器暂时无法保存工作区。请允许本地存储后重试。");
    }
    return new Promise((resolve,rejectChange)=>{
      const transaction=db.transaction("workspace", mode), store=transaction.objectStore("workspace");
      const read=store.get("current");
      let result, ownError;
      read.onsuccess=()=>{
        try {
          const data=read.result || fresh();
          result=operation(data);
          if (mode==="readwrite") store.put(data,"current");
        } catch (error) { ownError=error; transaction.abort(); }
      };
      transaction.oncomplete=()=>resolve(result);
      transaction.onabort=()=>rejectChange(ownError || new ApiError(503,"保存失败。请检查浏览器存储空间后重试。"));
    });
  }
  const now=()=>new Date().toISOString();
  function identifier(prefix) {
    const bytes=crypto.getRandomValues(new Uint8Array(8));
    return prefix+"-"+Array.from(bytes,n=>n.toString(16).padStart(2,"0")).join("");
  }
  function getString(input,key,min,max,required=true) {
    if (input[key]===undefined && !required) return "";
    if (typeof input[key]!=="string") reject(400,"字段 "+key+" 需要使用文字。");
    const value=input[key].trim();
    if (Array.from(value).length<min || Array.from(value).length>max || /[\u0000-\u0008\u000b-\u001f]/u.test(value))
      reject(400,"字段 "+key+" 的长度或格式不正确。");
    return value;
  }
  function sourceURL(input) {
    const raw=getString(input,"sourceUrl",0,2048,false);
    if (!raw) return "";
    let parsed;
    try { parsed=new URL(raw); } catch { reject(400,"原文地址需要是完整的 HTTP 或 HTTPS 链接。"); }
    if (!/^https?:\/\//iu.test(raw) || /[\s\\]/u.test(raw) || !["https:","http:"].includes(parsed.protocol) || parsed.username || parsed.password)
      reject(400,"原文地址不支持这种格式。");
    return raw;
  }
  function parts(content,project,revision,title,url) {
    const lines=content.split("\n"), sections=[];
    let heading=title, start=0, buffer=[], code=false, size=0;
    function flush() {
      if (!buffer.length) return;
      const text=buffer.join("\n");
      if (text.trim()) sections.push({
        id:project+"-v"+revision+"-L"+start, project, kind:"team", title:heading, document:title,
        revision,version:"v"+revision,start,end:start+buffer.length-1,text,snippet:text,sourceUrl:url,url,commit:""
      });
      buffer=[];size=0;
    }
    lines.forEach((line,index)=>{
      const stripped=line.trim(), fence=/^(?:\x60{3}|~{3})/u.test(stripped);
      const sectionTitle=!code && stripped.match(/^#{1,6}\s+(.+)/u);
      if (!code && (sectionTitle || !stripped || fence || /^(?:[-*+]|\d+[.)])\s/u.test(stripped) || size>=1000)) flush();
      if (sectionTitle) {heading=sectionTitle[1].trim().replace(/#+$/u,"").trim()||title;return;}
      if (fence) code=!code;
      if (stripped || code) {
        if (!buffer.length) start=index+1;
        buffer.push(line);size+=line.length;
      }
    });
    flush();
    if (!sections.length) reject(400,"手册需要至少一段可引用的正文。");
    return sections;
  }
  function published(workspace,project) { return workspace.manuals.find(manual=>manual.id===project); }
  function baseDoc(id) { return seed.documents.find(doc=>doc.id===id); }
  function versions(manual) {
    return [...manual.versions].reverse().map(v=>({revision:v.revision,version:v.version,publishedAt:v.publishedAt,sections:v.sections.length}));
  }
  function documentInfo(manual, v=manual.versions.at(-1)) {
    return {id:manual.id,project:manual.id,kind:"team",title:v.title,name:v.title,document:v.title,
      url:v.sourceUrl,sourceUrl:v.sourceUrl,revision:v.revision,version:v.version,sections:v.sections.length,
      publishedAt:v.publishedAt,versions:versions(manual),commit:""};
  }
  function builtinInfo(doc) {
    return {...doc,kind:"builtin",revision:1,sourceUrl:doc.url,
      versions:[{revision:1,version:doc.version,publishedAt:null,sections:doc.sections}]};
  }
  const bundled=seed.sections.map(section=>({...section,kind:"builtin",revision:1,sourceUrl:section.url}));
  function library(ws) {
    const latest=ws.manuals.map(m=>documentInfo(m)).sort((a,b)=>b.publishedAt.localeCompare(a.publishedAt));
    return {documents:[...seed.documents.map(builtinInfo),...latest],
      sections:[...bundled,...ws.manuals.flatMap(m=>m.versions.at(-1).sections)]};
  }
  function knownScope(ws,project) { return project==="all" || baseDoc(project) || published(ws,project); }
  function edition(ws,id,revision) {
    const builtin=baseDoc(id);
    if (builtin && (revision===null || revision===1)) return {document:builtinInfo(builtin),
      sections:bundled.filter(s=>s.project===id),content:seed.originals[id]};
    const doc=published(ws,id);
    if (!doc) reject(404,"没有找到这份手册或版本。");
    const v=revision===null ? doc.versions.at(-1) : doc.versions.find(v=>v.revision===revision);
    if (!v) reject(404,"没有找到这个版本。");
    return {document:documentInfo(doc,v),sections:v.sections,content:v.content};
  }
  function publish(ws,input) {
    const title=getString(input,"title",1,96),url=sourceURL(input);
    if (typeof input.content!=="string" || !input.content.trim()) reject(400,"请填写或导入手册正文。");
    const content=input.content.replace(/^\ufeff/u,"").replace(/\r\n?/gu,"\n");
    if (content.includes("\0") || new TextEncoder().encode(content).length>256*1024) reject(400,"正文须为有效文本，最大 256 KiB。");
    const titleKey=title.normalize("NFKC").toLowerCase().replace(/\s+/gu," ");
    const sameTitle=value=>value.normalize("NFKC").toLowerCase().replace(/\s+/gu," ")===titleKey;
    const updating="project" in input && input.project!=="" && input.project!=null;
    let doc=updating ? published(ws,input.project) : ws.manuals.find(m=>sameTitle(m.versions.at(-1).title));
    if (updating && !doc) reject(baseDoc(input.project)?409:404,"只能更新已发布的团队手册。");
    if (seed.documents.some(d=>sameTitle(d.title)) || ws.manuals.some(m=>m!==doc && sameTitle(m.versions.at(-1).title)))
      reject(409,"已有同名手册，请打开该手册发布修订版。");
    if (doc) {
      const previous=doc.versions.at(-1);
      if (previous.content===content && previous.title===title && previous.sourceUrl===url)
        return {...edition(ws,doc.id,null),created:false};
      if (!updating) reject(409,"已有同名手册，请打开该手册发布修订版。");
      if (!Number.isInteger(input.expectedRevision) || input.expectedRevision!==previous.revision)
        reject(409,"此手册已有更新，请重新载入当前版本。");
    } else { doc={id:identifier("team"),versions:[]};ws.manuals.push(doc); }
    const revision=doc.versions.length+1;
    const sections=parts(content,doc.id,revision,title,url);
    const version={title,content,revision,version:"v"+revision,publishedAt:now(),sourceUrl:url,sections};
    doc.versions.push(version);
    return {...edition(ws,doc.id,null),created:true};
  }
  function sectionById(ws,id) {
    const builtin=bundled.find(s=>s.id===id);
    if (builtin) return builtin;
    for (const manual of ws.manuals) for (const version of manual.versions) {
      const section=version.sections.find(s=>s.id===id);
      if (section) return section;
    }
    reject(404,"引用段落不存在。");
  }
  function gapResult(ws,gap) {
    return {...gap,evidence:gap.sectionId?sectionById(ws,gap.sectionId):null};
  }
  const normalizeQuestion=value=>{
    const normal=value.normalize("NFKC").replace(/\s+/gu," ").trim().toLowerCase();
    return normal.replace(/[!?。？！ ]+$/u,"") || normal;
  };
  function openGap(ws,input) {
    const question=getString(input,"question",1,500), project=input.project||"all";
    const reason=input.reason||"insufficient";
    if (!knownScope(ws,project) || !["insufficient","feedback"].includes(reason)) reject(400,"请检查手册范围和登记原因。");
    const saved=ws.gaps.find(g=>g.status==="open" && g.project===project && normalizeQuestion(g.question)===normalizeQuestion(question));
    if (saved) return {gap:gapResult(ws,saved),created:false};
    const gap={id:identifier("gap"),question,project,reason,status:"open",sectionId:null,note:"",
      createdAt:now(),resolvedAt:null};
    ws.gaps.unshift(gap);
    return {gap:gapResult(ws,gap),created:true};
  }
  function resolveGap(ws,id,input) {
    const gap=ws.gaps.find(g=>g.id===id);
    if (!gap) reject(404,"找不到该问题。");
    const sectionId=getString(input,"sectionId",1,180), note=getString(input,"note",0,1000,false);
    if (gap.status==="resolved") {
      if (gap.sectionId===sectionId && gap.note===note) return {gap:gapResult(ws,gap)};
      reject(409,"这个问题已经复核结案。");
    }
    const section=sectionById(ws,sectionId);
    const active=section.kind==="builtin" || published(ws,section.project).versions.at(-1).revision===section.revision;
    const scopeMatch=gap.project==="all" || section.project===gap.project || (baseDoc(gap.project) && section.kind==="team");
    if (!active || !scopeMatch) reject(422,"请选择当前范围内仍生效的原文段落。");
    if (!search.relevant(normalizeQuestion(gap.question),section)) reject(422,"这段原文与登记的问题缺少相关依据。");
    Object.assign(gap,{status:"resolved",sectionId,note,resolvedAt:now()});
    return {gap:gapResult(ws,gap)};
  }
  async function route(url,method,input) {
    const path=url.pathname;
    if (method==="GET" && path==="/api/evaluation") return seed.report;
    if (method==="GET" && path==="/api/health") return {status:"ok",modelConfigured:false};
    if (method==="GET" && path==="/api/documents") return workspace("readonly",library);
    const doc=path.match(/^\/api\/documents\/([^/]+)$/u);
    if (method==="GET" && doc) return workspace("readonly",ws=>edition(ws,decodeURIComponent(doc[1]),
      url.searchParams.has("revision") ? Number(url.searchParams.get("revision")) : null));
    const ref=path.match(/^\/api\/sections\/([^/]+)$/u);
    if (method==="GET" && ref) return workspace("readonly",ws=>({section:sectionById(ws,decodeURIComponent(ref[1]))}));
    if (method==="POST" && path==="/api/documents") return workspace("readwrite",ws=>publish(ws,input));
    if (method==="POST" && path==="/api/ask") return workspace("readonly",ws=>{
      const q=getString(input,"question",1,500),project=input.project||"all";
      if (!knownScope(ws,project)) reject(400,"请选择有效的手册范围。");
      const prior=ws.gaps.find(g=>g.project===project && normalizeQuestion(g.question)===normalizeQuestion(q));
      if (prior?.status==="resolved") {
        const evidence=sectionById(ws,prior.sectionId);
        if (evidence.kind==="builtin" || published(ws,evidence.project).versions.at(-1).revision===evidence.revision)
          return {mode:"extractive",status:"answered",method:"reviewed",answer:evidence.text,citations:[evidence],results:[evidence],
            resolutionId:prior.id,modeNote:"已由待补问题的复核记录确认。"};
      }
      return search.ask(q,project,library(ws).sections);
    });
    if (method==="GET" && path==="/api/gaps") return workspace("readonly",ws=>{
      const status=url.searchParams.get("status")||"all";
      if (!["all","open","resolved"].includes(status)) reject(400,"问题状态无效。");
      return {gaps:ws.gaps.filter(g=>status==="all" || g.status===status).map(g=>gapResult(ws,g))};
    });
    if (method==="POST" && path==="/api/gaps") return workspace("readwrite",ws=>openGap(ws,input));
    const resolve=path.match(/^\/api\/gaps\/([^/]+)\/resolve$/u);
    if (method==="POST" && resolve) return workspace("readwrite",ws=>resolveGap(ws,decodeURIComponent(resolve[1]),input));
    reject(404,"找不到此操作。");
  }
  async function request(path, options={}) {
    let status=200, payload;
    try {
      const url=new URL(path,"https://manual.local");
      const input=options.body ? JSON.parse(options.body) : {};
      if (!input || typeof input!=="object" || Array.isArray(input)) reject(400,"请求格式不正确。");
      payload=await route(url,String(options.method||"GET").toUpperCase(),input);
      if (payload.created) status=201;
    } catch(error) {
      status=error.status || (error instanceof SyntaxError ? 400 : 500);
      payload={error:error.status?error.message:"无法完成此操作，请刷新后重试。"};
    }
    return new Response(JSON.stringify(payload),{status,headers:{"Content-Type":"application/json; charset=utf-8"}});
  }
  window.manualOffline=Object.freeze({isPortable:true,request});
})();
