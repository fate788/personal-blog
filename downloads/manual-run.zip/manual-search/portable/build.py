"""Build the GitHub Pages and file:// edition from the normal product frontend.

Example: python portable/build.py --output dist/manual/index.html
"""
import argparse
import base64
import html
import json
from pathlib import Path
import re
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
STATIC = ROOT / "static"
sys.path.insert(0, str(ROOT))
import engine


def build(output):
    seed = {
        "documents": engine.get_documents(),
        "sections": engine.get_sections(),
        "originals": {key: (engine.CORPUS/f"{key}.md").read_text("utf-8") for key in engine.SOURCES},
        "report": json.loads((ROOT/"evaluation/report.json").read_text("utf-8")),
        "retrieval": {
            "groups": engine.GROUPS, "noise": sorted(engine.NOISE), "filler": engine.FILLER.pattern,
            "productNames": engine.PRODUCT_NAMES.pattern,
            "cues": {k: regex.pattern for k, regex in engine.DOMAIN_CUES.items()},
            "gaps": engine.CLEAR_GAPS, "durationQuestion": engine.DURATION_QUESTION.pattern,
            "durationEvidence": engine.DURATION_EVIDENCE.pattern,
        },
    }
    embedded_json = json.dumps(seed, ensure_ascii=False, separators=(",", ":")).replace("<", "\\u003c")
    inline_scripts = ["window.manualPortableSeed="+embedded_json+";",
                      (HERE/"search.js").read_text("utf-8"), (HERE/"workspace.js").read_text("utf-8")]
    paths = {p.relative_to(STATIC).as_posix(): p for p in STATIC.rglob("*") if p.is_file()}
    mimes = {".webp": "image/webp", ".png": "image/png", ".svg": "image/svg+xml",
             ".jpg": "image/jpeg", ".jpeg":"image/jpeg", ".woff2": "font/woff2", ".ico": "image/x-icon"}
    assets = {}
    for relative, p in paths.items():
        if p.suffix in mimes:
            assets[relative] = f"data:{mimes[p.suffix]};base64," + base64.b64encode(p.read_bytes()).decode()

    def inline_assets(content):
        for name, url in assets.items():
            pattern = r"""(?<=[('"=])(?:\./|/)?""" + re.escape(name) + r"""(?:\?[\w.=&-]+)?(?=['")\s>])"""
            content = re.sub(pattern, lambda _: url, content)
        return content

    def attr(tag, name):
        match = re.search(r'\b' + name + r'\s*=\s*(["\x27])(.*?)\1', tag, re.I|re.S)
        return html.unescape(match.group(2)) if match else ""

    def file_text(link):
        key = link.split("?",1)[0].removeprefix("./").lstrip("/")
        if key not in paths:
            raise ValueError(f"Missing static dependency: {link}")
        return paths[key].read_text("utf-8")

    def collect_script(match):
        path = attr(match.group(), "src")
        if not path:
            return match.group()
        inline_scripts.append(inline_assets(file_text(path)))
        return ""

    def stylesheet(match):
        if attr(match.group(), "rel") != "stylesheet":
            return match.group()
        return "<style>\n" + inline_assets(file_text(attr(match.group(), "href"))) + "\n</style>"

    markup = (STATIC/"index.html").read_text("utf-8")
    markup = re.sub(r"[ \t]*<script\b[^>]*>.*?</script\s*>", collect_script, markup,
                    flags=re.I|re.S)
    markup = re.sub(r"<link\b[^>]*>", stylesheet, markup, flags=re.I|re.S)
    markup = inline_assets(markup)
    policy = """<meta http-equiv="Content-Security-Policy" content="default-src 'none'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; img-src data:; font-src data:; connect-src 'none'; form-action 'none'; base-uri 'none'">"""
    markup = markup.replace("<head>","<head>\n  "+policy,1)
    tags = []
    for source in inline_scripts:
        tags.append("<script>\n" + re.sub(r"</script", r"<\\/script", source, flags=re.I) + "\n</script>")
    markup = markup.replace("</body>", "\n".join(tags)+"\n</body>",1)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_bytes(markup.encode("utf-8"))
    print(f"Built {output.name} ({output.stat().st_size:,} bytes; {len(seed['sections'])} source passages)")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True, help="Destination HTML file")
    args = parser.parse_args()
    build(args.output.resolve())
