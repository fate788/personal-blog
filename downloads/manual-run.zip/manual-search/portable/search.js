/* Browser retrieval over actual document passages. Query vocabulary and gap rules
   come from the Python engine at build time; no answers are stored in this module. */
function createManualSearch(config) {
  "use strict";
  const noise = new Set(config.noise);
  const normalized = text => text.normalize("NFKC").toLowerCase();
  const escapeRegex = text => text.replace(/[.*+?^$(){}|[\]\\]/g, "\\$&");
  const vocabulary = config.groups.map(group =>
    new RegExp([...group].sort((a,b) => b.length - a.length).map(escapeRegex).join("|"), "gu"));
  const gaps = config.gaps.map(([ask, evidence]) => [new RegExp(ask, "iu"), new RegExp(evidence, "iu")]);
  const filler = new RegExp(config.filler, "gu");
  const names = new RegExp(config.productNames, "gu");
  const scopeCues = Object.entries(config.cues).map(([id, pattern]) => [id, new RegExp(pattern, "iu")]);
  const duration = new RegExp(config.durationQuestion, "iu");
  const units = new RegExp(config.durationEvidence, "iu");
  function lacksQuantity(query,text) {
    const requested=query.matchAll(/(?:几|多少)\s*个?\s*(工作日|自然日|小时|分钟|秒|天|周|月|年|次|台|份|元|人|页|字节)/gu);
    return [...requested].some(match=>!new RegExp("(?:\\d+(?:\\.\\d+)?|[零一二两三四五六七八九十百千万半]+)\\s*个?\\s*"+match[1],"u").test(text));
  }

  function terms(text) {
    const counts = new Map();
    function add(token, amount = 1) {
      if (!noise.has(token)) counts.set(token, (counts.get(token) || 0) + amount);
    }
    const value = normalized(text);
    for (const word of value.match(/[a-z0-9]+(?:[._/-][a-z0-9]+)*|[\u3400-\u9fff]+/gu) || []) {
      if (/^[a-z0-9]/u.test(word)) {
        add(word);
        if (/[._/-]/u.test(word)) word.split(/[._/-]/u).forEach(part => add(part));
      } else {
        for (const width of [2,3]) {
          for (let i=0; i <= word.length-width; i++) add(word.slice(i,i+width));
        }
      }
    }
    vocabulary.forEach((pattern, i) => {
      const matched = value.match(pattern);
      if (matched) add("@"+i, Math.min(3, matched.length));
    });
    return counts;
  }

  function buildIndex(sections) {
    const docFreq = new Map();
    const rows = sections.map(section => {
      const vector = terms(section.text);
      const heading = terms(section.title + (section.kind === "team" ? " "+section.document : ""));
      for (const term of heading.keys()) vector.set(term, (vector.get(term) || 0) + 0.22);
      for (const term of vector.keys()) docFreq.set(term, (docFreq.get(term) || 0) + 1);
      return {section, vector, length:[...vector.values()].reduce((sum,v) => sum+v, 0)};
    });
    const mean = rows.reduce((sum,row) => sum+row.length, 0) / rows.length || 1;
    const idf = new Map([...docFreq].map(([key,n]) => [key,Math.log(1+(rows.length-n+0.5)/(n+0.5))]));
    return {rows,mean,idf};
  }

  function excerpt(text, weights) {
    const sentences = text.match(/[^。！？；]*[。！？；]|[^。！？；]+$/gu) || [text];
    if (text.length <= 120 && sentences.length <= 3) return text;
    const scores = sentences.map(s => [...terms(s)].reduce((sum,[t,n]) =>
      sum+(weights.get(t)||0)*(1+0.2*Math.min(n-1,2)),0));
    const hot = scores.reduce((best,value,index) => value>scores[best] ? index : best,0);
    let start=hot, end=hot+1;
    if (hot && scores[hot-1]>=scores[hot]*0.38) start--;
    if (end<scores.length && (scores[end]>=scores[hot]*0.2 || sentences[hot].length<=12 ||
        /以下命令/u.test(sentences[hot]) || /^(把演示时钟|到期|系统没有)/u.test(sentences[end]))) end++;
    return sentences.slice(start,end).join("").trim();
  }

  function rank(query, scopedRows, index) {
    const queryTerms = terms(query.replace(names," ").replace(filler," "));
    const weights = new Map();
    let total=0, conceptCount=0;
    for (const term of queryTerms.keys()) {
      if (!index.idf.has(term)) { total+=0.7; continue; }
      const concept=term.startsWith("@");
      const weight=index.idf.get(term)*(concept ? 4.3 : /^[\x00-\x7f]+$/u.test(term) ? 1.2 : term.length>2 ? 0.7 : 1);
      if (concept) conceptCount++;
      weights.set(term,weight);
      total+=weight;
    }
    const ranking=[];
    for (const row of scopedRows) {
      const norm=0.65+0.35*row.length/index.mean;
      let covered=0, raw=0, concepts=0, count=0, distinctive=false;
      for (const [term,weight] of weights) {
        const n=row.vector.get(term);
        if (!n) continue;
        raw+=weight*2.2*n/(n+1.2*norm);
        covered+=weight;
        count++;
        if (term.startsWith("@")) concepts++;
        if (term.length>=3 || /^[\x00-\x7f]+$/u.test(term)) distinctive=true;
      }
      if (!count) continue;
      const coverage=covered/Math.max(total,1);
      let score=raw*(0.65+0.35*coverage)*(conceptCount ? 0.4+0.6*concepts/conceptCount : 1);
      if (duration.test(query)) score*=units.test(row.section.text) ? 1.35 : 0.75;
      ranking.push({section:row.section, score,coverage,count,distinctive,weights});
    }
    ranking.sort((a,b) => b.score-a.score);
    return ranking.slice(0,3);
  }

  function hasEvidence(query, hit) {
    if (!hit || hit.score<2.15 || hit.coverage<0.22 ||
        (hit.count===1 && !hit.distinctive && hit.coverage<0.68)) return false;
    const text=normalized(hit.section.text), topic=normalized(hit.section.title+" "+hit.section.document);
    if (gaps.some(([request,evidence]) => request.test(query) && !evidence.test(text))) return false;
    if (hit.section.kind === "team") {
      if (lacksQuantity(query,text)) return false;
      if (duration.test(query) && !/[0-9零一二三四五六七八九十百千万两]+\s*(?:个)?(?:工作日|秒|分钟|小时|天|周|月|年)/u.test(text)) return false;
    }
    for (const id of query.match(/[a-z]{2,}[a-z0-9_.-]*|[psr]\d{2,6}/giu) || []) {
      if (["readme","clinic","ledger","app","web","id","ai"].includes(id) || text.includes(id) || topic.includes(id)) continue;
      const concepts=[...terms(id).keys()].filter(t=>t.startsWith("@"));
      if (!concepts.some(concept=>hit.weights.has(concept) && terms(text).has(concept))) return false;
    }
    return true;
  }

  function ask(question, project, sections) {
    const index=buildIndex(sections);
    const query=normalized(question.trim());
    const cues=scopeCues.filter(([,re])=>re.test(query)).map(([id])=>id);
    const scoped=index.rows.filter(({section})=>project==="all" ?
      (!cues.length || cues.includes(section.project) || section.kind==="team") : section.project===project);
    const ranked=rank(query,scoped,index);
    const publicRow=hit=>({...hit.section,score:Number(hit.score.toFixed(3)),snippet:excerpt(hit.section.text,hit.weights)});
    const result={method:"hybrid",mode:"extractive",status:"insufficient",answer:"所查手册没有提供足以回答这个问题的原文。",
      citations:[],results:ranked.map(publicRow)};
    if (!hasEvidence(query, ranked[0])) return result;
    let cited=[publicRow(ranked[0])];
    const clauses=query.split(/[?？；;，,]|另外|以及/u).map(s=>s.trim()).filter(s=>/谁|几|多|怎么|如何|吗|会|能|是否|哪些|什么|超时|能否/u.test(s));
    if (clauses.length>=2 && clauses.length<=3) {
      const hits=clauses.map(s=>rank(s,scoped,index)[0]);
      if (hits.every((hit,i)=>hasEvidence(clauses[i],hit) && hit.coverage>=0.28)) {
        const unique=[...new Map(hits.map(hit=>[hit.section.id,publicRow(hit)])).values()];
        const covered=terms(cited[0].text), asked=new Set(clauses.flatMap(c=>[...terms(c).keys()]));
        if (unique.length>1 && unique.some(row=>[...terms(row.text).keys()].some(t=>
          t.startsWith("@") && !covered.has(t) && asked.has(t)))) cited=unique;
      }
    }
    result.status="answered";
    result.citations=cited;
    result.answer=cited.map(s=>s.snippet).join("\n");
    result.results=[...new Map([...cited,...result.results].map(s=>[s.id,s])).values()].slice(0,3);
    return result;
  }

  function relevant(question, section) {
    const target=section.title+" "+section.text;
    if (lacksQuantity(question,target)) return false;
    const questionTerms=terms(question.replace(names," ").replace(filler," ")), evidence=terms(target);
    const overlap=[...questionTerms.keys()].filter(t=>evidence.has(t));
    return overlap.some(t=>t.startsWith("@") || t.length>=3 || /^[a-z0-9]{2,}$/u.test(t)) || overlap.length>=2;
  }
  return {ask,relevant};
}
