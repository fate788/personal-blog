import csv
import io
import unittest
from pathlib import Path

import engine


def statement(*records, encoding="utf-8"):
    file = io.StringIO(newline="")
    writer = csv.writer(file)
    writer.writerow(engine.HEADER)
    writer.writerows(records)
    return file.getvalue().encode(encoding)


class ReconciliationTests(unittest.TestCase):
    def test_sample_counts_and_evidence(self):
        folder = Path(__file__).parent / "samples"
        result = engine.reconcile((folder / "left.csv").read_bytes(), (folder / "right.csv").read_bytes())
        self.assertEqual((result["left_count"], result["right_count"]), (8, 6))
        self.assertEqual(result["counts"], dict(matched=3, amount=1, only_left=1, only_right=1, duplicate=1, invalid=1))
        diff = next(r for r in result["rows"] if r["status"] == "amount")
        self.assertEqual([diff[f] for f in ("key", "kind", "left", "right", "left_lines", "right_lines")],
                         ["000127", "收款", "128.00", "118.00", "4", "4"])
        self.assertEqual(sum(result["counts"].values()), len(result["rows"]))

    def test_exact_amounts_and_no_cross_kind_or_key_netting(self):
        left = statement(("0001", "收款", "00001.2"), ("0001", "退款", "1.2"), ("1", "收款", "0.07"),
                         ("big", "收款", "123456789123456789123456789.99"), encoding="utf-8-sig")
        right = statement(("0001", "收款", "1.20"), ("1", "收款", "0.07"),
                          ("big", "收款", "123456789123456789123456789.98"), encoding="gb18030")
        out = engine.reconcile(left, right)
        self.assertEqual((out["counts"]["matched"], out["counts"]["only_left"], out["counts"]["amount"]), (2, 1, 1))
        self.assertEqual(next(r for r in out["rows"] if r["kind"] == "退款")["key"], "0001")

    def test_duplicates_are_never_summed_or_matched(self):
        out = engine.reconcile(statement(("a", "收款", "1.10"), ("a", "收款", "2.20")),
                               statement(("a", "收款", "3.30")))
        row, = out["rows"]
        self.assertEqual([row[k] for k in ("status", "left", "right", "left_lines", "right_lines")],
                         ["duplicate", "", "3.30", "2, 3", "2"])
        other = engine.reconcile(statement(("a", "收款", "3.30")),
                                 statement(("a", "收款", "3.30"), ("a", "收款", "3.30")))
        self.assertEqual(other["rows"][0]["status"], "duplicate")

    def test_invalid_rows_and_same_key_bad_amount(self):
        malformed = ["-1", "+1", "1.234", "1e2", "NaN", "１２", "", ".5", "1."]
        data = statement(*[(str(i), "收款", v) for i, v in enumerate(malformed)],
                         ("", "收款", "1.20"), ("12", "支付", "1"), ("13", "退款"), ("14", "退款", "2", "多余"))
        out = engine.reconcile(data, statement(("0", "收款", "1.00")))
        self.assertEqual(out["counts"]["invalid"], 13)
        self.assertEqual(out["counts"]["only_right"], 0)
        self.assertIn("-1", out["rows"][0]["note"])
        self.assertEqual(out["rows"][0]["right_lines"], "2")
        self.assertTrue(all("系统订单第 " in row["note"] for row in out["rows"]))

    def test_invalid_member_of_duplicate_is_diagnosed(self):
        out = engine.reconcile(statement(("a", "收款", "100"), ("a", "收款", "bad")),
                               statement(("a", "收款", "100")))
        self.assertEqual((out["counts"]["invalid"], out["counts"]["duplicate"], out["counts"]["matched"]),
                         (1, 1, 0))

    def test_quoted_fields_and_multiline_record_evidence(self):
        data = statement(('餐厅,"A"\n单', "收款", "10"), ("B", "退款", "5"))
        result = engine.reconcile(data, data)
        self.assertEqual([row["left_lines"] for row in result["rows"]], ["2", "4"])
        self.assertEqual(result["rows"][0]["key"], '餐厅,"A"\n单')
        self.assertEqual(result["counts"]["matched"], 2)

    def test_file_errors_never_return_partial_results(self):
        head = ",".join(engine.HEADER)
        for suffix in ('\n"a,收款,1', '\na"b,收款,1', '\n"a"junk,收款,1'):
            with self.subTest(suffix=suffix), self.assertRaisesRegex(ValueError, "CSV"):
                engine.reconcile((head + suffix).encode(), statement())
        for data in (b"", b"wrong,header\n", b"\xef\xbb\xbf\xff", b"a\x00b",
                     b"a" * (engine.MAX_FILE_BYTES + 1), statement() + b"\n" * (engine.MAX_RECORDS + 1)):
            with self.subTest(length=len(data)), self.assertRaises(ValueError):
                engine.reconcile(statement(), data)
        self.assertEqual(engine.reconcile(statement(), statement())["rows"], [])

    def test_export_has_bom_evidence_and_formula_safety(self):
        left = statement(("000127", "收款", "128"), ("=1+1", "收款", "1"), ("001", "@danger", "-4"))
        report = engine.export_csv(engine.reconcile(left, statement()))
        self.assertTrue(report.startswith(b"\xef\xbb\xbf"))
        rows = list(csv.DictReader(io.StringIO(report.decode("utf-8-sig"), newline="")))
        cells = {row["业务单号"]: row for row in rows}
        self.assertEqual(cells["000127"]["系统金额"], "128.00")
        self.assertIn("'=1+1", cells)
        self.assertEqual(cells["001"]["类型"], "'@danger")
        self.assertEqual(cells["000127"]["系统行号"], "2")


if __name__ == "__main__":
    unittest.main()
