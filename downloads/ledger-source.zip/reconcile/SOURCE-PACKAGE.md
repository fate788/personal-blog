# 双账核对工作台 v0.2 源码包

原始发布归档为 `双账核对工作台-v0.2.zip`。压缩包保留其中 12 份文本文件的原始路径与字节，本文件为导出说明。

使用 Python 3.10 或更新版本，在项目根目录运行 `python server.py` 或 `python -m unittest discover -v`。合成 CSV 样例位于 `samples/`。定制 WOFF2 字体随完整运行包提供，源码包保留字体许可证，浏览器可回退到系统字体。
