'use strict';

const main = document.querySelector('main');
const dialog = document.querySelector('#format-dialog');
const statusText = { queued: '排队中', running: '核对中', done: '已完成', failed: '需重新导入' };
const categories = {
  amount: '金额不符', only_left: '仅系统有', only_right: '仅渠道有',
  duplicate: '重复键', invalid: '无效记录', matched: '一致',
};
const escapeText = value => String(value ?? '').replace(/[&<>"']/g, char =>
  ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[char]);
const pageSize = 25;
let view = 0;
let poll;
let reuseNotice = null;

async function request(path, options) {
  const response = await fetch(path, { cache: 'no-store', ...options });
  const data = await response.json();
  if (!response.ok) {
    const error = new Error(data.error || '暂时无法读取任务。');
    error.status = response.status;
    throw error;
  }
  return data;
}
function dateLabel(value) {
  return new Date(value).toLocaleString('zh-CN', { hour12: false });
}
function reviewCount(counts) {
  return Object.keys(categories).reduce((n, key) => n + (key === 'matched' ? 0 : counts[key] || 0), 0);
}
function historyRows(jobs) {
  if (!jobs.length) return '<div class="empty"><strong>还没有核对记录</strong><p>运行示例或导入两份账单后，可在这里重新打开结果。</p></div>';
  return jobs.map(job => `<a class="job-row" href="#job/${Number(job.id)}"><div><strong>${escapeText(job.left_name)} × ${escapeText(job.right_name)}</strong>
    <small>批次 #${Number(job.id)}${job.counts ? ' · ' + reviewCount(job.counts) + ' 项差异' : ''}${job.reviewed_count ? ' · ' + Number(job.reviewed_count) + ' 项已复核' : ''}</small></div>
    <span class="job-time">${escapeText(dateLabel(job.created_at))}</span><span class="job-status">${escapeText(statusText[job.status])} ↗</span></a>`).join('');
}
function fileField(key, title) {
  return `<label class="file-field"><span>${title}</span><span class="file-shell">
    <i class="file-icon" aria-hidden="true"></i><b data-file-name>选择 CSV</b><small></small>
    <input type="file" name="${key}" accept=".csv,text/csv" required></span></label>`;
}
function showNew() {
  main.innerHTML = `<div class="page-intro"><div><h1 tabindex="-1">双账核对工作台</h1>
    <p>逐笔核对收款与退款，从差异查回原始行，记录复核结论。</p></div></div>
    <div class="entry-grid"><section class="card import" aria-labelledby="import-title">
      <h2 id="import-title">导入两份账单</h2><p class="sub">按业务单号和收退款类型配对，金额精确到分。</p>
      <form id="import-form"><div class="file-pair">${fileField('left', '系统订单')}${fileField('right', '渠道账单')}</div>
      <div class="import-foot"><button class="primary action" type="submit">开始核对 <span aria-hidden="true">→</span></button>
        <button type="button" class="link" data-format>查看文件格式</button></div></form>
      <p class="error" role="alert" id="upload-note"></p>
    </section><aside class="specimen"><div class="top"><h2>样例账单</h2><small>收款 · 000127</small></div>
      <div class="amount-pair"><div><span>系统订单</span><strong>¥128.00</strong></div>
        <div><span>渠道账单</span><strong>¥118.00</strong></div></div>
      <div><p>两边相差 10.00 元。打开合成样例，查看这笔差异的出处。</p>
      <button id="run-sample" class="action" style="margin-top:12px" type="button">核对样例账单 <span aria-hidden="true">↗</span></button></div>
    </aside></div><section class="recent"><div class="section-title"><h2>最近核对</h2><a class="link" href="#history">全部记录 ↗</a></div>
      <div class="ledger" id="recent-list" aria-live="polite"><p class="pending">正在读取记录…</p></div></section>`;
  const form = main.querySelector('form');
  const version = view;
  form.addEventListener('change', event => {
    const input = event.target;
    const file = input.files?.[0];
    input.parentElement.querySelector('b').textContent = file?.name || '选择 CSV';
    input.parentElement.querySelector('small').textContent = file ? Math.ceil(file.size / 1024) + ' KiB' : '';
    document.querySelector('#upload-note').textContent = '';
  });
  form.addEventListener('submit', event => { event.preventDefault(); submit(form, false, version); });
  main.querySelector('#run-sample').onclick = () => submit(form, true, version);
  main.querySelector('[data-format]').onclick = () => dialog.showModal();
  loadHistory(version, true);
}
async function encodeFile(file) {
  if (file.size > 2 * 1024 * 1024) throw new Error('每份 CSV 最大为 2 MiB。');
  if (!file.size) throw new Error('文件为空，请检查账单。');
  const data = await new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result);
    reader.onerror = () => reject(new Error('读取文件失败，请重新选择。'));
    reader.readAsDataURL(file);
  });
  return data.slice(data.indexOf(',') + 1);
}
async function sampleFile(path) {
  const response = await fetch('/samples/' + path + '.csv');
  if (!response.ok) throw new Error('样例文件未能读取。');
  return response.blob();
}
async function submit(form, sample, version) {
  const buttons = [form.querySelector('[type=submit]'), main.querySelector('#run-sample')];
  if (buttons.some(button => button.disabled)) return;
  buttons.forEach(button => { button.disabled = true; });
  const note = main.querySelector('#upload-note');
  note.textContent = '正在提交核对任务…';
  try {
    const [left, right] = sample ? await Promise.all([sampleFile('left'), sampleFile('right')])
      : [form.elements.left.files[0], form.elements.right.files[0]];
    const [a, b] = await Promise.all([encodeFile(left), encodeFile(right)]);
    const job = await request('/api/jobs', { method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ left: a, right: b, left_name: sample ? '系统订单样例.csv' : left.name,
        right_name: sample ? '渠道账单样例.csv' : right.name }) });
    if (version !== view) return;
    reuseNotice = job.reused ? String(job.id) : null;
    location.hash = 'job/' + job.id;
  } catch (error) {
    if (version === view) note.textContent = error.message;
  } finally {
    buttons.forEach(button => { button.disabled = false; });
  }
}
async function loadHistory(version, recent) {
  const box = main.querySelector('#recent-list');
  try {
    const { jobs } = await request('/api/jobs');
    if (view === version) box.innerHTML = historyRows(recent ? jobs.slice(0, 3) : jobs);
  } catch (error) {
    if (view === version) box.innerHTML = `<p class="empty">读取记录失败。<button class="link" data-retry>重新读取</button></p>`;
    box.querySelector('[data-retry]')?.addEventListener('click', () => loadHistory(version, recent));
  }
}
function showHistory() {
  main.innerHTML = `<div class="page-intro"><div><h1 tabindex="-1">任务记录</h1><p>按创建时间查看本机保存的核对批次。</p></div>
    <a class="primary action" href="#new">新建核对</a></div><div class="ledger" id="recent-list"><p class="pending">正在读取记录…</p></div>`;
  loadHistory(view, false);
}
function lineLabel(lineText) {
  if (!lineText) return '无对应行';
  const lines = lineText.split(', ');
  if (lines.length <= 3) return '第 ' + escapeText(lineText) + ' 行';
  return '第 ' + escapeText(lines.slice(0, 3).join('、')) + ' 等 ' + lines.length + ' 行';
}

function renderSources(container, sources, job, row) {
  const sides = [['left', '系统订单'], ['right', '渠道账单']];
  container.innerHTML = sides.map(([side, label]) => `<section data-side="${side}"><small>${label}</small>
    <strong>${row[side] ? '¥' + escapeText(row[side]) : row[side + '_lines'] ? '见原始行' : '无对应金额'}</strong>
    <span class="wrap">${escapeText(job[side + '_name'])}</span>
    <span class="source-location">${lineLabel(row[side + '_lines'])}</span></section>`).join('');
  for (const [side] of sides) {
    const original = sources?.[side];
    if (!original?.length) continue;
    const column = container.querySelector(`[data-side="${side}"]`);
    column.insertAdjacentHTML('beforeend', `<details class="raw-lines"><summary>查看原始行（${original.length}）</summary>
      <div class="raw-list"></div><div class="raw-pages" ${original.length <= 8 ? 'hidden' : ''}>
      <button type="button" data-step="-1" aria-label="上一组原始行">上一组</button><span></span>
      <button type="button" data-step="1" aria-label="下一组原始行">下一组</button></div></details>`);
    const details = column.querySelector('details');
    let start = 0;
    function slice() {
      const stop = Math.min(start + 8, original.length);
      details.querySelector('.raw-list').innerHTML = original.slice(start, stop).map(record => {
        const fields = record.values.map((value, index) => {
          const label = ['单号', '类型', '金额'][index] || '第 ' + (index + 1) + ' 列';
          return `<div><dt>${label}</dt><dd>${escapeText(value || '（空）')}</dd></div>`;
        }).join('');
        return `<section><b>第 ${Number(record.line)} 行</b><dl>${fields}</dl></section>`;
      }).join('');
      details.querySelector('[data-step="-1"]').disabled = start === 0;
      details.querySelector('[data-step="1"]').disabled = stop === original.length;
      details.querySelector('.raw-pages span').textContent = `${start + 1}–${stop}`;
    }
    details.ontoggle = () => { if (details.open) slice(); };
    details.querySelector('.raw-pages').onclick = event => {
      const button = event.target.closest('[data-step]');
      if (button) { start += Number(button.dataset.step) * 8; slice(); }
    };
  }
  if (sources === null) {
    container.insertAdjacentHTML('afterend', '<p class="legacy-source">旧批次保留了来源行号和核对金额。再次导入原来的两份 CSV，可以补齐原始字段并保留已有复核。</p>');
  }
}

function renderReviews(records) {
  if (!records.length) return '<p class="no-review">尚无复核记录。</p>';
  function entry(record) {
    return `<article class="review-entry"><div><strong>${escapeText(record.reviewer)}</strong>
      <small>第 ${Number(record.version)} 次 · ${escapeText(dateLabel(record.created_at))}</small></div>
      <dl><dt>差异原因</dt><dd>${escapeText(record.reason)}</dd><dt>处理结论</dt><dd>${escapeText(record.conclusion)}</dd></dl></article>`;
  }
  const previous = records.slice(0, -1).reverse();
  return entry(records[records.length - 1]) + (previous.length
    ? `<details class="older-reviews"><summary>更早的记录（${previous.length}）</summary>${previous.map(entry).join('')}</details>` : '');
}

function openReview(job, row, update, restoreFocus) {
  const panel = document.createElement('dialog');
  panel.className = 'review-panel';
  panel.setAttribute('aria-labelledby', 'review-title');
  panel.innerHTML = `<div class="review-head"><div><small>批次 #${Number(job.id)} · ${categories[row.status]}</small>
    <h2 id="review-title">差异复核</h2></div><button class="action" type="button" data-close>返回明细</button></div>
    <div class="review-content"><h3 class="review-key">${escapeText(row.key || '未填单号')}<span>${escapeText(row.kind || '未填类型')}</span></h3>
    <p class="review-note">${escapeText(row.note)}</p><div class="source-pair"></div>
    <section class="review-ledger"><div class="review-section"><h3>复核记录</h3>
      <button class="link" type="button" data-amend hidden>追加复核记录</button></div><div data-history></div></section>
    <p class="review-feedback" data-feedback role="status" tabindex="-1"></p>
    <button class="action" type="button" data-reload hidden>重新读取记录</button>
    <form class="review-form" hidden><label>复核人<input type="text" name="reviewer" maxlength="40" required autocomplete="off" aria-describedby="signature-note"></label>
      <small id="signature-note">本机手填署名，身份未经账号验证。</small>
      <div class="review-fields"><label>差异原因<textarea name="reason" maxlength="300" rows="2" required></textarea></label>
      <label>处理结论<textarea name="conclusion" maxlength="300" rows="2" required></textarea></label></div>
      <div class="review-actions"><button class="action primary" type="submit">保存复核记录</button>
      <button class="link" type="button" data-cancel hidden>取消追加</button></div></form></div>`;
  main.append(panel);
  const form = panel.querySelector('form');
  const feedback = panel.querySelector('[data-feedback]');
  const amend = panel.querySelector('[data-amend]');
  const cancel = panel.querySelector('[data-cancel]');
  const close = panel.querySelector('[data-close]');
  const reload = panel.querySelector('[data-reload]');
  const sourceBox = panel.querySelector('.source-pair');
  const recordsBox = panel.querySelector('[data-history]');
  const endpoint = `/api/jobs/${Number(job.id)}/rows/${Number(row.row_id)}/reviews`;
  let records = [];
  let saving = false;
  let isCurrent = false;
  let editing = false;
  function paint() {
    recordsBox.innerHTML = renderReviews(records);
    amend.hidden = !records.length || editing || !isCurrent;
    form.hidden = !isCurrent || Boolean(records.length && !editing);
    cancel.hidden = !records.length;
  }
  function acceptHistory(history) {
    records = history;
    isCurrent = true;
    update(records[records.length - 1] || null);
    paint();
  }
  async function load(message) {
    isCurrent = false;
    form.hidden = true;
    amend.hidden = true;
    reload.hidden = true;
    feedback.textContent = '正在读取原始行与复核记录…';
    try {
      const data = await request(endpoint);
      if (!panel.isConnected || !panel.open) return;
      panel.querySelector('.legacy-source')?.remove();
      renderSources(sourceBox, data.sources, job, row);
      acceptHistory(data.history);
      feedback.textContent = message;
    } catch (error) {
      if (!panel.isConnected || !panel.open) return;
      reload.hidden = false;
      feedback.textContent = error.message;
    }
  }
  amend.onclick = () => {
    editing = true;
    paint();
    feedback.textContent = '';
    form.elements.reviewer.focus();
  };
  cancel.onclick = () => { editing = false; form.reset(); paint(); amend.focus(); };
  close.onclick = () => panel.close();
  panel.addEventListener('cancel', event => { if (saving) event.preventDefault(); });
  panel.addEventListener('close', () => { panel.remove(); restoreFocus(); }, { once: true });
  reload.onclick = () => load(editing ? '已读取最新记录，请核对后保存。' : '');
  form.onsubmit = async event => {
    event.preventDefault();
    if (saving || !isCurrent) return;
    const fields = [form.elements.reviewer, form.elements.reason, form.elements.conclusion];
    const blank = fields.find(field => !field.value.trim());
    if (blank) { feedback.textContent = '请填全复核人、差异原因与处理结论。'; blank.focus(); return; }
    const payload = Object.fromEntries(fields.map(field => [field.name, field.value.trim()]));
    payload.expected_version = records.length ? records[records.length - 1].version : 0;
    saving = true;
    [...form.elements, close].forEach(control => { control.disabled = true; });
    feedback.textContent = '正在保存…';
    try {
      const data = await request(endpoint, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) });
      if (!panel.isConnected || !panel.open) return;
      editing = false;
      form.reset();
      acceptHistory([...records, data.review]);
      feedback.textContent = '复核记录已保存。';
      feedback.focus();
    } catch (error) {
      if (!panel.isConnected || !panel.open) return;
      if (error.status === 409) {
        editing = true;
        await load('这笔差异已有新的复核记录。已保留你的草稿，请对照最新结论后再保存。');
      } else {
        feedback.textContent = error.message;
      }
    } finally {
      saving = false;
      [...form.elements, close].forEach(control => { control.disabled = false; });
    }
  };
  panel.showModal();
  load('');
}

function renderResult(job) {
  const { counts, rows, left_count, right_count } = job.result;
  const types = ['review', 'reviewed', ...Object.keys(categories), 'all'];
  const total = reviewCount(counts);
  const labels = { ...categories, review: '待复核', reviewed: '已复核', all: '全部' };
  const totals = { ...counts, all: rows.length };
  let reviewed = rows.filter(row => row.review).length;
  let selected = total > reviewed ? 'review' : reviewed ? 'reviewed' : 'all';
  let page = 0;
  main.innerHTML = `<div class="crumb"><a href="#history">任务记录</a> / 批次 #${Number(job.id)}</div>
    <div class="page-intro"><div><h1 tabindex="-1">核对结果</h1><p class="wrap">${escapeText(job.left_name)} × ${escapeText(job.right_name)}</p></div>
    <div class="actions"><a class="action" href="#new">新建核对</a><a class="action primary" href="/api/jobs/${Number(job.id)}/export.csv?reviews=1" download>导出完整报告 ↓</a></div></div>
    ${reuseNotice === String(job.id) ? '<p class="sub" style="margin-bottom:10px" role="status">已打开相同文件的已有核对结果。</p>' : ''}
    <section class="metrics" aria-label="核对概况"><div class="metric"><small>待复核</small><strong id="pending-total"></strong><span id="review-progress"></span></div>
    <div class="metric"><small>一致</small><strong>${counts.matched}</strong><span>业务键与金额均一致</span></div>
    <div class="metric"><small>输入行数</small><strong>${left_count} / ${right_count}</strong><span>系统 / 渠道</span></div></section>
    <div class="result-tools"><h2>逐笔明细</h2><label>业务单号 <input type="search" id="search" placeholder="输入单号查找" autocomplete="off"></label></div>
    <div class="filters" role="group" aria-label="结果筛选">${types.map(key =>
      `<button class="filter" type="button" data-filter="${key}"></button>`).join('')}</div>
    <p class="scroll-hint">左右滑动可查看两侧金额和核查说明。</p>
    <div class="table-panel" role="region" aria-label="核对明细，窄屏可横向滚动" tabindex="0"><table><thead><tr>
    <th>核对与复核</th><th>业务单号 / 类型</th><th>系统金额 · 元</th><th>渠道金额 · 元</th><th>核查说明</th></tr></thead><tbody></tbody></table></div>
    <div class="pager"><span id="range" role="status"></span><div class="actions"><button id="prev">上一页</button><button id="next">下一页</button></div></div>`;
  const search = main.querySelector('#search');
  const prev = main.querySelector('#prev');
  const next = main.querySelector('#next');
  function renderRows() {
    const term = search.value.trim();
    const filtered = rows.filter(row => {
      if (!row.key.includes(term)) return false;
      if (selected === 'review') return row.status !== 'matched' && !row.review;
      if (selected === 'reviewed') return Boolean(row.review);
      return selected === 'all' || row.status === selected;
    });
    page = Math.min(page, Math.max(0, Math.ceil(filtered.length / pageSize) - 1));
    main.querySelector('#pending-total').textContent = total - reviewed;
    main.querySelector('#review-progress').textContent = `已复核 ${reviewed} / ${total} 项差异`;
    const start = page * pageSize;
    const end = Math.min(start + pageSize, filtered.length);
    main.querySelector('tbody').innerHTML = filtered.slice(start, end).map(row => {
      const money = (amount, lines) => `<td class="money">${escapeText(amount || '—')}<small>${lineLabel(lines)}</small></td>`;
      const action = row.status === 'matched' ? '' : row.row_id
        ? `<button class="row-review" type="button" data-row-id="${Number(row.row_id)}">${row.review ? '已复核 · 查看' : '复核差异'} <span aria-hidden="true">↗</span></button>`
        : '<small>需运行 v0.2 服务以复核</small>';
      return `<tr><td><span class="tag ${row.status}">${labels[row.status]}</span>${action}</td><td><b>${escapeText(row.key || '未填单号')}</b><small>${escapeText(row.kind || '未填类型')}</small></td>
        ${money(row.left, row.left_lines)}${money(row.right, row.right_lines)}<td>${escapeText(row.note || '两侧金额一致。')}</td></tr>`;
    }).join('') || '<tr><td colspan="5" class="empty">当前条件下没有记录。</td></tr>';
    main.querySelector('#range').textContent = filtered.length ? `显示 ${start + 1}–${end}，共 ${filtered.length} 项` : '共 0 项';
    prev.disabled = page === 0; next.disabled = end >= filtered.length;
    totals.review = total - reviewed;
    totals.reviewed = reviewed;
    main.querySelectorAll('[data-filter]').forEach(button => {
      const key = button.dataset.filter;
      button.textContent = labels[key] + ' ' + totals[key];
      button.setAttribute('aria-pressed', String(key === selected));
    });
  }
  main.querySelector('tbody').onclick = event => {
    const button = event.target.closest('[data-row-id]');
    if (!button) return;
    const row = rows.find(item => item.row_id === Number(button.dataset.rowId));
    if (!row) return;
    openReview(job, row, current => {
      if (!row.review && current) reviewed++;
      row.review = current;
      renderRows();
    }, () => {
      const target = main.querySelector(`[data-row-id="${row.row_id}"]`) || main.querySelector(`[data-filter="${selected}"]`);
      target?.focus({ preventScroll: true });
    });
  };
  main.querySelector('.filters').onclick = event => {
    const button = event.target.closest('[data-filter]');
    if (button) { selected = button.dataset.filter; page = 0; renderRows(); }
  };
  search.oninput = () => { page = 0; renderRows(); };
  prev.onclick = () => { if (page > 0) page--; renderRows(); };
  next.onclick = () => { page++; renderRows(); };
  renderRows();
}
async function showJob(id, version) {
  try {
    const job = await request('/api/jobs/' + id);
    if (view !== version) return;
    if (job.status === 'done') { renderResult(job); return; }
    if (job.status === 'failed') throw new Error(job.error || '核对失败，请检查文件格式。');
    main.innerHTML = `<div class="page-intro"><div><h1 tabindex="-1">正在核对</h1><p role="status">批次 #${id} · ${escapeText(statusText[job.status])}。稍后也可从任务记录打开。</p></div><a class="action" href="#history">查看记录</a></div>`;
    poll = setTimeout(() => showJob(id, version), 600);
  } catch (error) {
    if (view !== version) return;
    main.innerHTML = `<div class="page-intro"><div><h1 tabindex="-1">无法显示结果</h1><p role="alert">${escapeText(error.message)}</p></div></div>
      <div class="actions"><a class="action primary" href="#new">重新导入</a><button class="action" data-refresh>重新读取</button></div>`;
    main.querySelector('[data-refresh]').onclick = () => showJob(id, version);
  }
}
function navigate() {
  clearTimeout(poll);
  const version = ++view;
  const hash = location.hash.slice(1);
  const job = /^job\/(\d+)$/.exec(hash);
  if (hash === 'history') showHistory();
  else if (job) { main.innerHTML = '<p class="pending">正在读取核对结果…</p>'; showJob(job[1], version); }
  else { reuseNotice = null; showNew(); }
  document.querySelectorAll('[data-nav]').forEach(link => {
    if (link.dataset.nav === (hash === 'history' || job ? 'history' : 'new')) link.setAttribute('aria-current', 'page');
    else link.removeAttribute('aria-current');
  });
  window.scrollTo(0, 0);
}
document.querySelector('#guide').onclick = () => dialog.showModal();
document.querySelector('#close-dialog').onclick = () => dialog.close();
document.querySelector('.skip').onclick = event => { event.preventDefault(); main.focus(); };
window.addEventListener('hashchange', () => { navigate(); main.focus({ preventScroll: true }); });
navigate();
