import base64
import csv
import io
import json
import os
import re
import sqlite3
import subprocess
import sys
import tempfile
import time
import unittest
from concurrent.futures import ThreadPoolExecutor
from contextlib import closing, contextmanager
from pathlib import Path
from urllib.error import HTTPError
from urllib.request import Request, urlopen


ROOT = Path(__file__).resolve().parent
JOBS = "/api/jobs"
HEADER = "业务单号,类型,金额\n"

# The wrapper pauses only inside the calculation for one marked job. By this
# point the actual worker has committed 'running' and retained both inputs.
# No production hooks, timing-dependent large file, or database fixture needed.
PAUSE_MARKED_JOB = """
import threading
import server
original = server.reconcile
def pause_marked(left, right):
    if b'CRASH-PENDING' in left:
        threading.Event().wait()
    return original(left, right)
server.reconcile = pause_marked
server.main()
"""


@contextmanager
def start_server(db_path, *, pause_marked=False):
    command = [sys.executable, "-u"]
    command += ["-c", PAUSE_MARKED_JOB] if pause_marked else [str(ROOT / "server.py")]
    command += ["--port", "0", "--db", str(db_path)]
    log_path = db_path.with_suffix(".log")
    with log_path.open("wb") as log:
        process = subprocess.Popen(
            command, cwd=ROOT, stdout=log, stderr=subprocess.STDOUT,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
            env={**os.environ, "PYTHONIOENCODING": "utf-8"},
        )
        try:
            deadline = time.monotonic() + 10
            while time.monotonic() < deadline:
                output = log_path.read_text(encoding="utf-8", errors="replace")
                if process.poll() is not None:
                    raise AssertionError(f"Server exited during startup: {output}")
                address = re.search(r"^(http://127\.0\.0\.1:\d+)/", output, re.MULTILINE)
                if address:
                    break
                time.sleep(.025)
            else:
                raise AssertionError("Server did not announce its local port")
            yield address.group(1)
        finally:
            if process.poll() is None:
                process.kill()
            process.wait(timeout=10)


def files(key="PAY-01"):
    content = (HEADER + f"{key},收款,12.30\n").encode()
    encoded = base64.b64encode(content).decode("ascii")
    return {"left": encoded, "right": encoded, "left_name": "系统.csv", "right_name": "渠道.csv"}


def samples():
    return {side: base64.b64encode((ROOT / "samples" / f"{side}.csv").read_bytes()).decode("ascii")
            for side in ("left", "right")}


def review(version, reviewer="李同学"):
    return {"reviewer": reviewer, "reason": "  渠道金额需再查  ", "conclusion": "请结算核查", "expected_version": version}


def exchange(base, path=JOBS, payload=None):
    body = json.dumps(payload).encode() if payload is not None else None
    request = Request(base + path, data=body, headers={"Content-Type": "application/json"})
    try:
        response = urlopen(request, timeout=5)
    except HTTPError as error:
        response = error
    with response:
        data = response.read()
        if response.headers.get_content_type() == "application/json":
            data = json.loads(data)
        return response.status, data


class ServerTest(unittest.TestCase):
    def setUp(self):
        folder = tempfile.TemporaryDirectory()
        self.addCleanup(folder.cleanup)
        self.db = Path(folder.name) / "jobs.sqlite3"

    def submit(self, base, payload):
        status, new = exchange(base, payload=payload)
        self.assertEqual((status, new["reused"]), (202, False))
        return new["id"]

    def await_status(self, base, job_id, expected):
        deadline = time.monotonic() + 8
        while time.monotonic() < deadline:
            status, job = exchange(base, f"{JOBS}/{job_id}")
            self.assertEqual(status, 200)
            if job["status"] == expected:
                return job
            if job["status"] in ("done", "failed"):
                self.fail(f"Expected {expected}: {job}")
            time.sleep(.025)
        self.fail(f"Job {job_id} did not reach {expected}")

    def test_concurrent_identical_inputs_create_one_result_and_export(self):
        with start_server(self.db) as base, ThreadPoolExecutor(max_workers=8) as pool:
            submissions = list(pool.map(lambda _: exchange(base, payload=files()), range(16)))
            self.assertEqual(sum(status == 202 for status, _ in submissions), 1)
            self.assertEqual(sum(status == 200 and job["reused"] for status, job in submissions), 15)
            job_ids = {job["id"] for _, job in submissions}
            self.assertEqual(len(job_ids), 1)
            job_id = job_ids.pop()
            result = self.await_status(base, job_id, "done")["result"]
            self.assertEqual(result["counts"]["matched"], 1)
            self.assertEqual(result["rows"][0]["key"], "PAY-01")
            self.assertEqual(len(exchange(base)[1]["jobs"]), 1)
            self.assertEqual(exchange(base, payload={**files(), "left_name": "改名.csv"}),
                             (200, {"id": job_id, "reused": True}))
            status, csv = exchange(base, f"{JOBS}/{job_id}/export.csv")
            self.assertEqual(status, 200)
            self.assertTrue(csv.startswith(b"\xef\xbb\xbf"))
            self.assertIn("PAY-01", csv.decode("utf-8-sig"))

    def test_bad_header_is_a_failed_job_and_next_job_still_completes(self):
        with start_server(self.db) as base:
            bad = {**files(), "left": base64.b64encode(b"wrong,header\r\n").decode("ascii")}
            failed = self.submit(base, bad)
            self.assertIn("表头", self.await_status(base, failed, "failed")["error"])
            self.assertEqual(exchange(base, f"{JOBS}/{failed}/export.csv")[0], 409)
            valid = self.submit(base, files())
            self.await_status(base, valid, "done")
            self.assertEqual([job["status"] for job in exchange(base)[1]["jobs"]], ["done", "failed"])

    def test_process_loss_preserves_done_and_recovers_running_and_queued(self):
        with start_server(self.db, pause_marked=True) as base:
            done = self.submit(base, files())
            original = self.await_status(base, done, "done")
            running = self.submit(base, files("CRASH-PENDING"))
            self.await_status(base, running, "running")
            queued = self.submit(base, files("AFTER-CRASH"))
            self.await_status(base, queued, "queued")
        # The context manager killed the process without a graceful shutdown.
        # Restart the regular executable against exactly the same SQLite file.
        with start_server(self.db) as base:
            self.assertEqual(self.await_status(base, done, "done"), original)
            self.assertEqual(self.await_status(base, running, "done")["result"]["rows"][0]["key"], "CRASH-PENDING")
            self.assertEqual(self.await_status(base, queued, "done")["result"]["rows"][0]["key"], "AFTER-CRASH")
            self.assertEqual(exchange(base, payload=files("CRASH-PENDING")), (200, {"id": running, "reused": True}))
            self.assertEqual([job["id"] for job in exchange(base)[1]["jobs"]], [queued, running, done])

    def test_review_history_and_raw_duplicate_lines_survive_reimport_and_restart(self):
        with start_server(self.db) as base:
            job_id = self.submit(base, samples())
            job = self.await_status(base, job_id, "done")
            row = next(r for r in job["result"]["rows"] if r["status"] == "duplicate")
            path = f"{JOBS}/{job_id}/rows/{row['row_id']}/reviews"
            self.assertIsNone(row["review"])
            self.assertNotIn("sources", row)
            details = exchange(base, path)[1]
            self.assertEqual(details["history"], [])
            for side in ("left", "right"):
                source_csv = (ROOT / "samples" / f"{side}.csv").read_text(encoding="utf-8-sig")
                lines = list(csv.reader(io.StringIO(source_csv)))
                for item in details["sources"][side]:
                    self.assertEqual(item["values"], lines[item["line"] - 1])
            self.assertGreater(len(details["sources"]["left"]), 1)
            first = review(0)
            first["conclusion"] = "=待确认"
            status, saved = exchange(base, path, first)
            self.assertEqual(status, 201)
            self.assertEqual(saved["review"]["reason"], first["reason"].strip())
            _, report = exchange(base, f"{JOBS}/{job_id}/export.csv?reviews=1")
            report_rows = list(csv.DictReader(io.StringIO(report.decode("utf-8-sig"))))
            reviewed = next(r for r in report_rows if r["复核状态"] == "已复核")
            self.assertEqual((reviewed["复核人（手填）"], reviewed["处理结论"]), ("李同学", "'=待确认"))
            self.assertNotIn("复核状态", exchange(base, f"{JOBS}/{job_id}/export.csv")[1].decode("utf-8-sig").splitlines()[0])
        with start_server(self.db) as base:
            self.assertEqual(exchange(base, payload=samples()), (200, {"id": job_id, "reused": True}))
            status, second = exchange(base, path, {**review(1), "conclusion": "结算已明确两笔退款的流水号"})
            self.assertEqual((status, second["review"]["version"]), (201, 2))
            self.assertEqual(exchange(base, path)[1], {"history": [saved["review"], second["review"]], "sources": details["sources"]})
            job = self.await_status(base, job_id, "done")
            self.assertEqual(job["reviewed_count"], 1)
            self.assertEqual(job["result"]["rows"][row["row_id"] - 1]["review"], second["review"])
            self.assertEqual(exchange(base)[1]["jobs"][0]["reviewed_count"], 1)

    def test_review_conflicts_and_invalid_changes_do_not_overwrite(self):
        with start_server(self.db) as base, ThreadPoolExecutor(max_workers=4) as pool:
            job_id = self.submit(base, samples())
            rows = self.await_status(base, job_id, "done")["result"]["rows"]
            prefix = f"{JOBS}/{job_id}/rows"
            row = next(r for r in rows if r["status"] == "amount")
            path = f"{prefix}/{row['row_id']}/reviews"
            for change in ({"reviewer": "  "}, {"conclusion": ""}, {"reason": "x" * 301},
                           {"expected_version": None}, {"expected_version": True}, {"reviewer": "\ud800"}):
                self.assertEqual(exchange(base, path, {**review(0), **change})[0], 400)
            matched = next(r["row_id"] for r in rows if r["status"] == "matched")
            self.assertEqual(exchange(base, f"{prefix}/{matched}/reviews", review(0))[0], 400)
            self.assertEqual(exchange(base, f"{prefix}/99999/reviews", review(0))[0], 404)
            attempts = list(pool.map(lambda i: exchange(base, path, review(0, f"复核人{i}")), range(4)))
            self.assertCountEqual([status for status, _ in attempts], [201, 409, 409, 409])
            winner = next(value["review"] for status, value in attempts if status == 201)
            self.assertEqual(exchange(base, path)[1]["history"], [winner])

    def test_pre_review_database_migrates_without_original_files(self):
        # Recreate the persisted shape of a finished v0.1 job, which kept line
        # numbers but discarded the original uploads and had no reviews table.
        with start_server(self.db) as base:
            job_id = self.submit(base, samples())
            self.await_status(base, job_id, "done")
        with closing(sqlite3.connect(self.db)) as db, db:
            db.execute("DROP TABLE reviews")
            db.execute("ALTER TABLE jobs DROP COLUMN evidence_version")
            result = json.loads(db.execute("SELECT result FROM jobs WHERE id=?", (job_id,)).fetchone()[0])
            for row in result["rows"]:
                row.pop("sources", None)
            db.execute("UPDATE jobs SET result=? WHERE id=?", (json.dumps(result), job_id))
        with start_server(self.db) as base:
            job = self.await_status(base, job_id, "done")
            line = next(row for row in job["result"]["rows"] if row["status"] == "amount")
            self.assertEqual((line["left_lines"], line["right_lines"]), ("4", "4"))
            path = f"{JOBS}/{job_id}/rows/{line['row_id']}/reviews"
            self.assertEqual(exchange(base, path)[1], {"history": [], "sources": None})
            status, saved = exchange(base, path, review(0))
            self.assertEqual(status, 201)
            before = exchange(base, f"{JOBS}/{job_id}")[1]
            with ThreadPoolExecutor(max_workers=4) as pool:
                attempts = list(pool.map(lambda _: exchange(base, payload=samples()), range(4)))
            for attempt in attempts:
                self.assertEqual(attempt, (200, {"id": job_id, "reused": True}))
            restored = exchange(base, path)[1]
            self.assertEqual(restored["history"], [saved["review"]])
            self.assertEqual(restored["sources"]["left"], [{"line": 4, "values": ["000127", "收款", "128.00"]}])
            self.assertEqual(restored["sources"]["right"], [{"line": 4, "values": ["000127", "收款", "118.00"]}])
            self.assertEqual(before, exchange(base, f"{JOBS}/{job_id}")[1])
            self.assertEqual(len(exchange(base)[1]["jobs"]), 1)
            self.assertEqual(exchange(base, payload=samples()), (200, {"id": job_id, "reused": True}))
            self.assertEqual(exchange(base, path)[1], restored)

    def test_health_reports_aggregate_queue_only(self):
        path = "/api/health"
        empty = {"queued": 0, "running": 0, "oldest_pending_seconds": 0}
        with start_server(self.db, pause_marked=True) as base:
            self.assertEqual(exchange(base, path), (200, {"service": "reconcile", "status": "ok", "queue": empty}))
            running = self.submit(base, files("CRASH-PENDING"))
            self.await_status(base, running, "running")
            queued = self.submit(base, files("PRIVATE-BILLING-KEY"))
            self.await_status(base, queued, "queued")
            with closing(sqlite3.connect(self.db)) as db, db:
                db.execute("UPDATE jobs SET created_at='2020-01-01T00:00:00.000Z' WHERE id=?", (running,))
            health = exchange(base, path)[1]
            self.assertEqual(set(health), {"service", "status", "queue"})
            self.assertEqual(set(health["queue"]), set(empty))
            self.assertEqual((health["queue"]["queued"], health["queue"]["running"]), (1, 1))
            self.assertGreater(health["queue"]["oldest_pending_seconds"], 60)
            self.assertNotIn("PRIVATE", json.dumps(health))
            self.assertEqual(exchange(base, f"{JOBS}/{running}/rows/1/reviews", review(0))[0], 409)


if __name__ == "__main__":
    unittest.main()
