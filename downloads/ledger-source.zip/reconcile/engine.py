"""Match two CSV statements using exact amounts and explicit transaction identities."""

import csv
import io
import re
from collections import defaultdict
from dataclasses import dataclass
from itertools import chain


HEADER = ("业务单号", "类型", "金额")
STATUSES = {
    "matched": "一致", "amount": "金额不符", "only_left": "仅系统",
    "only_right": "仅渠道", "duplicate": "重复键", "invalid": "无效记录",
}
AMOUNT = re.compile(r"[0-9]+(?:\.[0-9]{1,2})?\Z")
KEYS = ("key", "kind", "left", "right", "left_lines", "right_lines", "note")
MAX_FILE_BYTES = 4 * 1024 * 1024
MAX_RECORDS = 20_000


@dataclass(frozen=True)
class Record:
    line: int
    key: str
    kind: str
    amount: str
    error: str
    values: list

    def source(self):
        return {"line": self.line, "values": self.values}


def _amount(raw):
    if not AMOUNT.fullmatch(raw):
        return ""
    whole, _, cents = raw.partition(".")
    return (whole.lstrip("0") or "0") + "." + cents.ljust(2, "0")


def _decode(data, source):
    if not isinstance(data, bytes):
        raise ValueError(f"{source}文件必须以字节形式提交。")
    if len(data) > MAX_FILE_BYTES:
        raise ValueError(f"{source}文件超过 4 MiB，请分批导入。")
    if b"\x00" in data:
        raise ValueError(f"{source}文件含空字符，请另存为 UTF-8 或 GB18030 的 CSV。")
    try:
        return data.decode("utf-8-sig")
    except UnicodeDecodeError:
        if not data.startswith(b"\xef\xbb\xbf"):
            try:
                return data.decode("gb18030")
            except UnicodeDecodeError:
                pass
    raise ValueError(f"{source}文件编码无效，请另存为 UTF-8 或 GB18030。")


def _records(data, source):
    text = _decode(data, source)
    reader = csv.reader(io.StringIO(text, newline=""), strict=True)
    if not text.strip():
        raise ValueError(f"{source}文件为空，缺少表头。")
    # csv.reader accepts a literal quote inside an unquoted field. Match the CSV
    # grammar as well so a broken export cannot silently change a transaction ID.
    unquoted_quote = _bad_quote_line(text)
    if unquoted_quote:
        raise ValueError(f"{source}第 {unquoted_quote} 行 CSV 引号格式错误。")
    try:
        header = next(reader)
        if tuple(part.strip() for part in header) != HEADER:
            raise ValueError(f"{source}表头必须为 业务单号,类型,金额。")
        result = []
        while True:
            line = reader.line_num + 1
            columns = next(reader, None)
            if columns is None:
                return result
            if len(result) == MAX_RECORDS:
                raise ValueError(f"{source}超过 {MAX_RECORDS} 条记录，请分批导入。")
            key, kind, raw = (columns + ["", "", ""])[:3]
            key, kind, raw = key.strip(), kind.strip(), raw.strip()
            amount = _amount(raw)
            errors = []
            if len(columns) != 3:
                errors.append(f"应有 3 列，实际 {len(columns)} 列")
            if not key:
                errors.append("业务单号为空")
            if kind not in ("收款", "退款"):
                errors.append("类型须为收款或退款")
            if not amount:
                shown = raw[:40] + ("…" if len(raw) > 40 else "")
                errors.append(f"金额「{shown}」须为非负十进制数，最多两位小数")
            result.append(Record(line, key, kind, amount, "，".join(errors), columns))
    except csv.Error as exc:
        raise ValueError(f"{source}第 {reader.line_num or 1} 行附近 CSV 无法解析，检查引号、字段长度和文件完整性。") from exc


def _bad_quote_line(text):
    # Match complete, legal fields in bulk. An unmatched suffix starts at a bad field.
    if '"' not in text:
        return None
    end = 0
    while end < len(text):
        field = _CSV_FIELD.match(text, end)
        if not field:
            break
        end = field.end()
    if end == len(text):
        return None
    return len(re.findall(r"\r\n|\r|\n", text[:end])) + 1


_CSV_FIELD = re.compile(r'(?:"(?:[^"]|"")*"|[^,"\r\n]*)(?:,|\r\n|\r|\n|\Z)')


def _row(status, key, kind, left, right, note):
    def amount(records):
        return records[0].amount if len(records) == 1 else ""

    def lines(records):
        return ", ".join(str(item.line) for item in records)

    row = dict(status=status, key=key, kind=kind, left=amount(left), right=amount(right),
               left_lines=lines(left), right_lines=lines(right), note=note)
    if status != "matched":
        row["sources"] = {"left": [record.source() for record in left],
                          "right": [record.source() for record in right]}
    return row


def reconcile(left_bytes, right_bytes):
    """Return group counts and row-level evidence, including physical CSV line numbers."""
    left = _records(left_bytes, "系统订单")
    right = _records(right_bytes, "渠道账单")
    groups = defaultdict(lambda: ([], []))
    rows = []
    for side, records in enumerate((left, right)):
        for record in records:
            if record.key and record.kind in ("收款", "退款"):
                groups[record.key, record.kind][side].append(record)
            if record.error:
                origin = ("系统订单", "渠道账单")[side]
                rows.append(_row("invalid", record.key, record.kind, [] if side else [record],
                                 [record] if side else [], f"{origin}第 {record.line} 行：{record.error}"))

    for (key, kind), (system, channel) in groups.items():
        if len(system) > 1 or len(channel) > 1:
            status = "duplicate"
            note = f"系统 {len(system)} 行、渠道 {len(channel)} 行，请按原始行号逐笔核查。"
        elif any(record.error for record in chain(system, channel)):
            # Neither a match nor a one-sided omission can be established. Attach
            # counterpart evidence to the invalid record without counting it twice.
            continue
        elif not system:
            status, note = "only_right", "系统订单中未找到此业务单号和类型。"
        elif not channel:
            status, note = "only_left", "渠道账单中未找到此业务单号和类型。"
        elif system[0].amount != channel[0].amount:
            status, note = "amount", "同一业务单号和类型的两侧金额不同。"
        else:
            status, note = "matched", ""
        rows.append(_row(status, key, kind, system, channel, note))

    for row in rows:
        if row["status"] != "invalid":
            continue
        sides = groups.get((row["key"], row["kind"]))
        if not sides or any(len(side) > 1 for side in sides):
            continue
        for side, name in zip(sides, ("left", "right")):
            if side:
                row[name] = side[0].amount
                row[name + "_lines"] = str(side[0].line)
                row["sources"][name] = [side[0].source()]
    counts = dict.fromkeys(STATUSES, 0)
    for row in rows:
        counts[row["status"]] += 1
    return dict(counts=counts, rows=rows, left_count=len(left), right_count=len(right))


def restore_sources(result, left_bytes, right_bytes):
    """Copy only the original columns referenced by a saved row, preserving its review identity."""
    missing = [row for row in result["rows"] if row["status"] != "matched" and row.get("sources") is None]
    if not missing:
        return False
    originals = {}
    for side, data, label in (("left", left_bytes, "系统订单"), ("right", right_bytes, "渠道账单")):
        originals[side] = {item.line: item.source() for item in _records(data, label)}
    for row in missing:
        sources = {}
        for side, records in originals.items():
            lines = row[side + "_lines"]
            sources[side] = [records[int(number)] for number in lines.split(",")] if lines else []
        if not (sources["left"] or sources["right"]):
            raise ValueError("旧差异记录缺少原始行号。")
        row["sources"] = sources
    return True


def _safe_cell(value):
    text = str(value)
    stripped = text.lstrip()
    if stripped.startswith(("=", "+", "-", "@", "＝", "＋", "－", "＠")) or text.startswith(("\t", "\r", "\n")):
        return "'" + text
    return text


def export_csv(result, include_reviews=False):
    """Export the full audited result, with a BOM and spreadsheet-safe text cells."""
    output = io.StringIO(newline="")
    writer = csv.writer(output)
    headers = ["比对结果", "业务单号", "类型", "系统金额", "渠道金额", "系统行号", "渠道行号", "核查说明"]
    if include_reviews:
        headers.extend(("复核状态", "复核人（手填）", "差异原因", "处理结论", "修订版本", "记录时间（UTC）"))
    writer.writerow(headers)
    for row in result["rows"]:
        cells = [_safe_cell(row[key]) for key in KEYS]
        if include_reviews:
            review = row.get("review") or {}
            state = "已复核" if review else ("无需复核" if row["status"] == "matched" else "待复核")
            cells.append(state)
            cells.extend(_safe_cell(review.get(key, "")) for key in ("reviewer", "reason", "conclusion", "version", "created_at"))
        writer.writerow((STATUSES[row["status"]], *cells))
    return output.getvalue().encode("utf-8-sig")
