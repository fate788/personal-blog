"""Local reconciliation job server. Run with Python 3.10 or newer."""
import argparse
import base64
import binascii
import hashlib
import json
import logging
import os
import re
import sqlite3
import threading
from contextlib import closing, contextmanager
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlsplit

from engine import export_csv, reconcile, restore_sources


ROOT = Path(__file__).resolve().parent
MAX_FILE = 2 * 1024 * 1024
MAX_BASE64 = 4 * ((MAX_FILE + 2) // 3)
MAX_REQUEST = 2 * MAX_BASE64 + 16_384
JOB_ROUTE = re.compile(r"/api/jobs/([1-9][0-9]{0,17})(/export\.csv)?")
REVIEW_ROUTE = re.compile(r"/api/jobs/([1-9][0-9]{0,17})/rows/([1-9][0-9]{0,8})/reviews")
PUBLIC_FIELDS = """id, status, created_at, left_name, right_name, error, counts, left_count, right_count,
    (SELECT count(*) FROM reviews WHERE job_id=jobs.id AND version=1) AS reviewed_count"""
REVIEW_FIELDS = "version, reviewer, reason, conclusion, created_at"


def timestamp():
    return datetime.now(timezone.utc).isoformat(timespec="milliseconds").replace("+00:00", "Z")


class RequestProblem(Exception):
    def __init__(self, status, message):
        super().__init__(message)
        self.status = status


@contextmanager
def exclusive_worker(db_path):
    """Only the process holding this lock may recover this database's interrupted jobs."""
    lock_path = db_path.with_name(db_path.name + ".lock")
    with lock_path.open("a+b") as lock:
        if os.name == "nt":
            import msvcrt
            if lock.tell() == 0:
                lock.write(b"0")
                lock.flush()
            lock.seek(0)
            try:
                msvcrt.locking(lock.fileno(), msvcrt.LK_NBLCK, 1)
            except OSError as error:
                raise RuntimeError("这个数据库已有对账工作台在使用。") from error
        else:
            import fcntl
            try:
                fcntl.flock(lock.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
            except BlockingIOError as error:
                raise RuntimeError("这个数据库已有对账工作台在使用。") from error
        yield


class JobStore:
    def __init__(self, path):
        self.path = path
        self.pending = threading.Event()
        self.stopping = threading.Event()
        with self.connection() as db:
            db.execute("PRAGMA journal_mode=WAL")
            db.execute("""CREATE TABLE IF NOT EXISTS jobs (
                id INTEGER PRIMARY KEY, fingerprint TEXT NOT NULL UNIQUE,
                status TEXT NOT NULL CHECK (status IN ('queued','running','done','failed')),
                created_at TEXT NOT NULL, left_name TEXT NOT NULL, right_name TEXT NOT NULL,
                left_file BLOB, right_file BLOB, result TEXT, error TEXT,
                counts TEXT, left_count INTEGER, right_count INTEGER,
                evidence_version INTEGER NOT NULL DEFAULT 0
            )""")
            if "evidence_version" not in {column["name"] for column in db.execute("PRAGMA table_info(jobs)")}:
                db.execute("ALTER TABLE jobs ADD COLUMN evidence_version INTEGER NOT NULL DEFAULT 0")
            # A row's position and business result remain stable when a matching
            # pair of files later supplies raw columns for a pre-review batch.
            db.execute("""CREATE TABLE IF NOT EXISTS reviews (
                job_id INTEGER NOT NULL REFERENCES jobs(id), row_id INTEGER NOT NULL,
                version INTEGER NOT NULL CHECK (version >= 1), reviewer TEXT NOT NULL,
                reason TEXT NOT NULL, conclusion TEXT NOT NULL, created_at TEXT NOT NULL,
                PRIMARY KEY (job_id, row_id, version)
            )""")
            db.execute("""CREATE INDEX IF NOT EXISTS jobs_pending_age ON jobs(status,created_at)
                          WHERE status IN ('queued','running')""")
            db.execute("UPDATE jobs SET status = 'queued' WHERE status = 'running'")

    @contextmanager
    def connection(self):
        with closing(sqlite3.connect(self.path, timeout=12)) as db:
            db.row_factory = sqlite3.Row
            db.execute("PRAGMA foreign_keys=ON")
            with db:
                yield db

    def submit(self, left, right, left_name, right_name):
        fingerprint = hashlib.sha256(hashlib.sha256(left).digest() + hashlib.sha256(right).digest()).hexdigest()
        stamp = timestamp()
        with self.connection() as db:
            existing = db.execute("SELECT id,status,evidence_version FROM jobs WHERE fingerprint=?", (fingerprint,)).fetchone()
            if existing is not None:
                if existing["status"] == "done" and existing["evidence_version"] == 0:
                    self.restore_legacy(db, existing["id"], left, right)
                return {"id": existing["id"], "reused": True}
            cursor = db.execute("""INSERT INTO jobs
                (fingerprint,status,created_at,left_name,right_name,left_file,right_file)
                VALUES (?, 'queued', ?, ?, ?, ?, ?) ON CONFLICT(fingerprint) DO NOTHING""",
                (fingerprint, stamp, left_name, right_name, left, right))
            reused = cursor.rowcount == 0
            job_id = db.execute("SELECT id FROM jobs WHERE fingerprint=?", (fingerprint,)).fetchone()["id"]
        self.pending.set()
        return {"id": job_id, "reused": reused}

    @staticmethod
    def restore_legacy(db, job_id, left, right):
        # The normal submit path has already matched the exact bytes from both
        # uploads. Serialize the one-time attachment against parallel submissions.
        db.execute("BEGIN IMMEDIATE")
        saved = db.execute("SELECT result FROM jobs WHERE id=? AND status='done' AND evidence_version=0",
                           (job_id,)).fetchone()
        if saved is None:
            return
        try:
            result = json.loads(saved["result"])
            changed = restore_sources(result, left, right)
        except (ValueError, TypeError, KeyError):
            logging.warning("Original line references could not be restored for batch %s", job_id)
            return
        if changed:
            db.execute("UPDATE jobs SET result=?,evidence_version=1 WHERE id=?",
                       (json.dumps(result, ensure_ascii=False, allow_nan=False), job_id))
        else:
            db.execute("UPDATE jobs SET evidence_version=1 WHERE id=?", (job_id,))

    def process(self):
        while not self.stopping.is_set():
            self.pending.clear()
            try:
                with self.connection() as db:
                    # This worker holds the exclusive process lock. A running row here can
                    # only be its own interrupted write, and is safe to recompute.
                    job = db.execute("""SELECT id, left_file, right_file FROM jobs
                        WHERE status IN ('queued','running') ORDER BY id LIMIT 1""").fetchone()
                    if job is not None:
                        db.execute("UPDATE jobs SET status='running' WHERE id=?", (job["id"],))
                if job is None:
                    self.pending.wait(5)
                    continue
                self.finish(job)
            except sqlite3.Error:
                logging.exception("Database unavailable while processing a job")
                self.stopping.wait(1)

    def finish(self, job):
        try:
            result = reconcile(job["left_file"], job["right_file"])
            encoded = json.dumps(result, ensure_ascii=False, allow_nan=False)
            counts = json.dumps(result["counts"])
            left_count, right_count = result["left_count"], result["right_count"]
        except Exception as error:
            if isinstance(error, ValueError):
                message = str(error) or "账单格式有误，请检查模板后再导入。"
            else:
                logging.exception("Unexpected reconciliation error in job %s", job["id"])
                message = "核对过程中出现错误，请检查输入的账单格式。"
            with self.connection() as db:
                db.execute("""UPDATE jobs SET status='failed', error=?, left_file=NULL, right_file=NULL
                    WHERE id=?""", (message, job["id"]))
            return
        with self.connection() as db:
            db.execute("""UPDATE jobs SET status='done', evidence_version=1, result=?, counts=?, left_count=?, right_count=?,
                left_file=NULL, right_file=NULL WHERE id=?""",
                (encoded, counts, left_count, right_count, job["id"]))

    @staticmethod
    def decode(row):
        data = {key: row[key] for key in row.keys() if row[key] is not None}
        for key in ("counts", "result"):
            if key in data:
                data[key] = json.loads(data[key])
        return data

    def list_jobs(self):
        with self.connection() as db:
            rows = db.execute(f"SELECT {PUBLIC_FIELDS} FROM jobs ORDER BY id DESC")
            return [self.decode(row) for row in rows]

    def get(self, job_id):
        with self.connection() as db:
            db.execute("BEGIN")
            row = db.execute(f"SELECT {PUBLIC_FIELDS}, result FROM jobs WHERE id=?", (job_id,)).fetchone()
            if row is None:
                raise RequestProblem(404, "找不到这个核对批次。")
            job = self.decode(row)
            if job["status"] == "done":
                rows = job["result"]["rows"]
                for row_id, item in enumerate(rows, start=1):
                    item["row_id"] = row_id
                    item["review"] = None
                    item.pop("sources", None)
                latest = db.execute(f"""SELECT r.row_id, {REVIEW_FIELDS} FROM reviews AS r
                    WHERE r.job_id=? AND NOT EXISTS (
                        SELECT 1 FROM reviews AS newer WHERE newer.job_id=r.job_id
                          AND newer.row_id=r.row_id AND newer.version>r.version)""", (job_id,))
                for entry in latest:
                    review = dict(entry)
                    rows[review.pop("row_id") - 1]["review"] = review
        return job

    @staticmethod
    def review_row(db, job_id, row_id):
        job = db.execute("""SELECT status, json_extract(result, ?) AS item FROM jobs WHERE id=?""",
                         (f"$.rows[{row_id - 1}]", job_id)).fetchone()
        if job is None:
            raise RequestProblem(404, "找不到这个核对批次。")
        if job["status"] != "done":
            raise RequestProblem(409, "核对完成后才能复核差异。")
        if job["item"] is None:
            raise RequestProblem(404, "找不到这条差异。")
        item = json.loads(job["item"])
        if item["status"] == "matched":
            raise RequestProblem(400, "这条记录金额一致，无需复核。")
        return item

    def history(self, job_id, row_id):
        with self.connection() as db:
            db.execute("BEGIN")
            item = self.review_row(db, job_id, row_id)
            records = db.execute(f"""SELECT {REVIEW_FIELDS} FROM reviews
                WHERE job_id=? AND row_id=? ORDER BY version""", (job_id, row_id))
            return {"history": [dict(r) for r in records], "sources": item.get("sources")}

    def add_review(self, job_id, row_id, data):
        expected = data.get("expected_version")
        if type(expected) is not int or not 0 <= expected < 2**63 - 1:
            raise RequestProblem(400, "缺少有效的修订版本，请刷新差异后再试。")
        fields = {}
        for key, label, limit in (("reviewer", "复核人", 40), ("reason", "差异原因", 300), ("conclusion", "处理结论", 300)):
            value = data.get(key)
            if not isinstance(value, str) or not 1 <= len(value.strip()) <= limit:
                raise RequestProblem(400, f"{label}须填写 1 至 {limit} 个字。")
            if re.search(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f\ud800-\udfff]", value):
                raise RequestProblem(400, f"{label}包含不能保存的字符。")
            fields[key] = value.strip()
        with self.connection() as db:
            db.execute("BEGIN IMMEDIATE")
            self.review_row(db, job_id, row_id)
            version, = db.execute("""SELECT COALESCE(MAX(version),0) FROM reviews
                WHERE job_id=? AND row_id=?""", (job_id, row_id)).fetchone()
            if expected != version:
                raise RequestProblem(409, "这条差异已有新的复核记录，请查看最新版本后再提交。")
            review = {**fields, "version": version + 1, "created_at": timestamp()}
            db.execute("""INSERT INTO reviews (job_id,row_id,version,reviewer,reason,conclusion,created_at)
                VALUES (:job_id,:row_id,:version,:reviewer,:reason,:conclusion,:created_at)""",
                       {**review, "job_id": job_id, "row_id": row_id})
        return {"review": review}

    def health(self):
        with self.connection() as db:
            counts = db.execute("""SELECT status, count(*) AS size, min(created_at) AS oldest
                FROM jobs WHERE status IN ('queued','running') GROUP BY status""").fetchall()
        queue = {"queued": 0, "running": 0, "oldest_pending_seconds": 0}
        now = datetime.now(timezone.utc)
        for group in counts:
            queue[group["status"]] = group["size"]
            oldest = datetime.fromisoformat(group["oldest"].replace("Z", "+00:00"))
            queue["oldest_pending_seconds"] = max(queue["oldest_pending_seconds"], int((now - oldest).total_seconds()))
        return {"service": "reconcile", "status": "ok", "queue": queue}


class Handler(BaseHTTPRequestHandler):
    server_version = "Reconcile"

    def verify_origin(self):
        hosts = self.headers.get_all("Host") or []
        port = self.server.server_port
        allowed = {f"127.0.0.1:{port}", f"localhost:{port}"}
        if port == 80:
            allowed.update(("127.0.0.1", "localhost"))
        if len(hosts) != 1 or hosts[0].lower() not in allowed:
            raise RequestProblem(403, "请从本机工作台地址打开。")
        origins = self.headers.get_all("Origin") or []
        if origins and (len(origins) != 1 or origins[0].lower() != "http://" + hosts[0].lower()):
            raise RequestProblem(403, "请在当前工作台中发起请求。")

    def respond(self, status, body, mime, attachment=None):
        self.send_response(status)
        self.send_header("Content-Type", mime)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        if attachment:
            self.send_header("Content-Disposition", f'attachment; filename="{attachment}"')
        self.end_headers()
        if self.command != "HEAD":
            self.wfile.write(body)

    def json_response(self, status, data):
        self.respond(status, json.dumps(data, ensure_ascii=False).encode(), "application/json; charset=utf-8")

    def read_json(self, limit, size_error):
        lengths = self.headers.get_all("Content-Length") or []
        if self.headers.get("Transfer-Encoding"):
            raise RequestProblem(400, "请用指定长度的 JSON 提交数据。")
        if len(lengths) != 1 or not re.fullmatch(r"[0-9]{1,10}", lengths[0]):
            raise RequestProblem(411, "请求缺少有效的内容长度。")
        length = int(lengths[0])
        if length > limit:
            raise RequestProblem(413, size_error)
        if self.headers.get_content_type() != "application/json":
            raise RequestProblem(415, "请使用 JSON 提交数据。")
        self.connection.settimeout(15)
        raw = self.rfile.read(length)
        if len(raw) != length:
            raise RequestProblem(400, "数据没有完整上传，请重试。")
        try:
            data = json.loads(raw.decode("utf-8"))
        except (ValueError, RecursionError):
            raise RequestProblem(400, "请求内容不是有效的 UTF-8 JSON。") from None
        if not isinstance(data, dict):
            raise RequestProblem(400, "请提交有效的 JSON 对象。")
        return data

    def files(self):
        data = self.read_json(MAX_REQUEST, "每份账单最大支持 2 MiB。")
        uploads, names = [], []
        for key, example in (("left", "业务账单.csv"), ("right", "渠道账单.csv")):
            value = data.get(key)
            if not isinstance(value, str) or not value:
                raise RequestProblem(400, "请同时提供两份非空的 CSV 账单。")
            if len(value) > MAX_BASE64:
                raise RequestProblem(413, "每份账单最大支持 2 MiB。")
            try:
                binary = base64.b64decode(value, validate=True)
            except (ValueError, binascii.Error):
                raise RequestProblem(400, "文件内容不是有效的 Base64 编码。") from None
            if len(binary) > MAX_FILE:
                raise RequestProblem(413, "每份账单最大支持 2 MiB。")
            name = data.get(key + "_name", example)
            if not isinstance(name, str):
                raise RequestProblem(400, "文件名应为文本。")
            name = re.sub(r"[\x00-\x1f\x7f]", "", re.split(r"[/\\]", name)[-1]).strip()
            if any(0xD800 <= ord(c) <= 0xDFFF for c in name):
                raise RequestProblem(400, "请提供有效的文件名。")
            names.append(name[:180] or example)
            uploads.append(binary)
        return uploads + names

    def dispatch(self):
        self.verify_origin()
        url = urlsplit(self.path)
        path = url.path
        store = self.server.store
        reviews = REVIEW_ROUTE.fullmatch(path)
        if reviews:
            job_id, row_id = map(int, reviews.groups())
            if self.command == "POST":
                data = self.read_json(16384, "复核内容过长，请缩短后重试。")
                return self.json_response(201, store.add_review(job_id, row_id, data))
            return self.json_response(200, store.history(job_id, row_id))
        if self.command == "POST":
            if path != "/api/jobs":
                raise RequestProblem(404, "地址不存在。")
            job = store.submit(*self.files())
            return self.json_response(200 if job["reused"] else 202, job)
        if path == "/api/health":
            return self.json_response(200, store.health())
        if path == "/api/jobs":
            return self.json_response(200, {"jobs": store.list_jobs()})
        match = JOB_ROUTE.fullmatch(path)
        if match:
            job = store.get(int(match[1]))
            if match[2]:
                if job["status"] != "done":
                    raise RequestProblem(409, "完成核对后即可导出。")
                include_reviews = parse_qs(url.query).get("reviews") == ["1"]
                return self.respond(200, export_csv(job["result"], include_reviews), "text/csv; charset=utf-8",
                                    f"reconciliation-{job['id']}.csv")
            return self.json_response(200, job)
        static = {
            "/": ("web/index.html", "text/html; charset=utf-8"),
            "/index.html": ("web/index.html", "text/html; charset=utf-8"),
            "/app.js": ("web/app.js", "application/javascript; charset=utf-8"),
            "/style.css": ("web/style.css", "text/css; charset=utf-8"),
            "/samples/left.csv": ("samples/left.csv", "text/csv; charset=utf-8"),
            "/samples/right.csv": ("samples/right.csv", "text/csv; charset=utf-8"),
        }
        if path in static:
            name, mime = static[path]
        elif re.fullmatch(r"/fonts/[a-zA-Z0-9_.-]+\.woff2", path):
            name, mime = "web" + path, "font/woff2"
        else:
            raise RequestProblem(404, "地址不存在。")
        try:
            data = (ROOT / name).read_bytes()
        except FileNotFoundError:
            raise RequestProblem(404, "文件不存在。") from None
        self.respond(200, data, mime)

    def do_GET(self):
        try:
            self.dispatch()
        except RequestProblem as error:
            self.json_response(error.status, {"error": str(error)})
        except (BrokenPipeError, ConnectionResetError):
            pass
        except TimeoutError:
            self.json_response(408, {"error": "请求超时，请重试。"})
        except Exception:
            logging.exception("Request failed")
            self.json_response(500, {"error": "工作台暂时无法处理请求，请重试。"})

    do_HEAD = do_GET
    do_POST = do_GET


def main():
    parser = argparse.ArgumentParser(description="本机双账核对工作台")
    parser.add_argument("--port", type=int, default=8792)
    parser.add_argument("--db", type=Path, default=ROOT / "data" / "jobs.sqlite3")
    options = parser.parse_args()
    path = options.db.resolve()
    path.parent.mkdir(parents=True, exist_ok=True)
    with ThreadingHTTPServer(("127.0.0.1", options.port), Handler) as server, exclusive_worker(path):
        store = JobStore(path)
        server.store = store
        worker = threading.Thread(target=store.process, name="reconciliation-worker", daemon=True)
        worker.start()
        print(f"http://127.0.0.1:{server.server_port}/", flush=True)
        try:
            server.serve_forever()
        except KeyboardInterrupt:
            pass
        finally:
            store.stopping.set()
            store.pending.set()
            worker.join()


if __name__ == "__main__":
    main()
