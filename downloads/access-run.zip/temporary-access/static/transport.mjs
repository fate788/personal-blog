export default async function request(path, options={}) {
  const method=options.method || "GET";
  const headers={Accept:"application/json"};
  const init={method,credentials:"same-origin",cache:"no-store",headers};
  if(method==="POST"){
    headers["Content-Type"]="application/json";
    headers["X-Workspace-Request"]="1";
    init.body=JSON.stringify(options.body || {});
  }
  const response=await fetch(path,init);
  const body=await response.json();
  if(!response.ok){
    const error=new Error(body.error || "工作台请求失败，请重试。");
    error.status=response.status;
    error.code=body.code;
    throw error;
  }
  return body;
}
