export const demoWorkspace = {
  users: [
    {id:"employee", name:"林予安", role:"employee", department:"商业运营"},
    {id:"approver", name:"沈知遥", role:"approver", department:"数据平台"},
    {id:"auditor", name:"陆言", role:"auditor", department:"内控审计"},
  ],
  resources: [
    {
      id:"regional-report", name:"区域经营周报", category:"经营数据", department:"数据平台",
      summary:"汇总各区域的净成交额、有效订单与环比变化，用于大促复盘及区域对账。",
      maxMinutes:30, approverIds:["approver"], requesterIds:["employee"],
      report:{
        period:"第 47 周 · 11 月 16 日至 22 日",
        summary:"演示数据。净成交额按支付减退款汇总，环比以第 46 周为基准。",
        columns:["区域","净成交额（万元）","有效订单","净成交额环比"],
        rows:[["华东",192.6,4820,"+8.1%"],["华南",143.2,3624,"+4.6%"],["华北",117.5,2840,"−1.3%"],["西南",86.4,2126,"+5.2%"]],
      },
    },
    {
      id:"fulfillment-report", name:"履约质量看板", category:"供应链", department:"数据平台",
      summary:"按区域汇总准时发货率、积压单量和异常订单数，供供应链对齐处理进度。",
      maxMinutes:60, approverIds:["approver"], requesterIds:["employee"],
      report:{
        period:"第 47 周 · 11 月 16 日至 22 日",
        summary:"演示数据。以商家确认揽收的时间计算准时发货率。",
        columns:["区域","准时发货率","积压单量","异常订单"],
        rows:[["华东","97.4%",48,32],["华南","96.8%",42,26],["华北","95.1%",64,38]],
      },
    },
    {
      id:"refund-review", name:"售后复核简报", category:"售后管理", department:"数据平台",
      summary:"按渠道列出退款申请和已复核的数量，用于抽查售后处理记录。",
      maxMinutes:15, approverIds:["approver"], requesterIds:["employee"],
      report:{
        period:"第 47 周 · 11 月 16 日至 22 日",
        summary:"演示数据。每条已处理订单只计入一次。",
        columns:["渠道","退款申请","已复核"],
        rows:[["商场",126,101],["小程序",97,84],["企业团购",31,28]],
      },
    },
  ],
};
