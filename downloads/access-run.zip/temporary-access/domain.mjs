const MINUTE = 60_000;
const APPROVAL_WINDOW = 24 * 60 * MINUTE;

export function createWorkspace({ users, resources }) {
  return {
    users: users.map(({ id, name, role, department }) => ({ id, name, role, department })),
    resources: structuredClone(resources),
    requests: [],
    grants: [],
    events: [],
    sequences: { request: 0, grant: 0, event: 0 },
  };
}

function response(body, status = 200) {
  return { status, body };
}

function reject(status, code, error) {
  return response({ code, error }, status);
}

function nextId(state, kind, prefix) {
  const number = ++state.sequences[kind];
  return prefix + "-" + String(number).padStart(4, "0");
}

function appendEvent(state, { at, actorId, action, resourceId, requestId, details }) {
  state.events.push({
    id: nextId(state, "event", "evt"),
    at, actorId, action, resourceId, requestId, details,
  });
}

function reconcile(state, now) {
  for (const request of state.requests) {
    if (request.status !== "pending" || request.deadlineAt > now) continue;
    request.status = "expired";
    request.decidedAt = request.deadlineAt;
    appendEvent(state, {
      at: request.deadlineAt, actorId: "system", action: "request_expired",
      resourceId: request.resourceId, requestId: request.id, details: { recordedAt: now },
    });
  }
  for (const grant of state.grants) {
    if (grant.status !== "active") continue;
    const expired = grant.expiresAt <= now;
    if (!expired) {
      const user = state.users.find(item => item.id === grant.userId);
      const resource = state.resources.find(item => item.id === grant.resourceId);
      if (canRequest(resource, user)) continue;
    }
    grant.status = expired ? "expired" : "revoked";
    grant.endedAt = expired ? grant.expiresAt : now;
    grant.endedBy = "system";
    appendEvent(state, {
      at: grant.endedAt, actorId: "system", action: "grant_" + grant.status,
      resourceId: grant.resourceId, requestId: grant.requestId,
      details: { grantId: grant.id, recordedAt: now, ...(expired ? {} : { reason: "policy_changed" }) },
    });
  }
}

function canRequest(resource, actor) {
  if (!resource || !actor) return false;
  return resource.requesterIds === undefined
    ? actor.role === "employee"
    : resource.requesterIds.includes(actor.id);
}

function canApprove(resource, actor) {
  return actor.role === "approver" && resource?.approverIds.includes(actor.id);
}

function canBrowse(resource, actor) {
  return actor.role === "auditor" || canApprove(resource, actor) || canRequest(resource, actor);
}

function canSeeRecord(resource, actor, userId) {
  return actor.id === userId || actor.role === "auditor" || canApprove(resource, actor);
}

function workspace(state, actor, now) {
  const owned = new Set(state.resources.filter(resource => canApprove(resource, actor)).map(resource => resource.id));
  const visible = (resourceId, userId) => actor.role === "auditor" || owned.has(resourceId) || userId === actor.id;
  const requests = state.requests.filter(request => visible(request.resourceId, request.requesterId));
  const grants = state.grants.filter(grant => visible(grant.resourceId, grant.userId));
  const requestIds = new Set(requests.map(request => request.id));
  const events = state.events.filter(event =>
    visible(event.resourceId, event.actorId) || requestIds.has(event.requestId)
  );
  // Report data can only be returned by the protected report endpoint.
  const resources = state.resources.filter(resource => canBrowse(resource, actor)).map(resource => ({
    id: resource.id,
    name: resource.name,
    category: resource.category,
    department: resource.department,
    summary: resource.summary,
    maxMinutes: resource.maxMinutes,
    approverIds: resource.approverIds,
    canRequest: canRequest(resource, actor),
    canApprove: canApprove(resource, actor),
  }));
  const peopleIds = new Set([
    actor.id,
    ...resources.flatMap(resource => resource.approverIds),
    ...requests.flatMap(request => [request.requesterId, request.decisionBy]),
    ...events.map(event => event.actorId),
  ]);
  const people = state.users.filter(user => actor.role === "auditor" || peopleIds.has(user.id));
  events.reverse().sort((left, right) => right.at - left.at);
  return response({ now, actor, people, resources, requests, grants, events });
}

function submit(state, actor, body, now) {
  const resource = state.resources.find(item => item.id === body.resourceId);
  if (!resource) return reject(404, "RESOURCE_NOT_FOUND", "没有找到这项资源。");
  if (!canRequest(resource, actor)) return reject(403, "REQUEST_FORBIDDEN", "当前账号无法申请这项资源。");
  const reason = typeof body.reason === "string" ? body.reason.trim() : "";
  if (reason.length < 4 || reason.length > 300) {
    return reject(422, "INVALID_REASON", "请填写 4 到 300 个字的申请用途。");
  }
  const { minutes } = body;
  if (!Number.isSafeInteger(minutes) || minutes < 1 || minutes > resource.maxMinutes) {
    return reject(422, "INVALID_DURATION", "请输入 1 至 " + resource.maxMinutes + " 分钟的整数时长。");
  }
  const current = state.requests.find(request =>
    request.resourceId === resource.id && request.requesterId === actor.id && request.status === "pending"
  );
  if (current) {
    if (current.reason === reason && current.minutes === minutes) return response({ request: current, created: false });
    return reject(409, "REQUEST_PENDING", "这项资源已有一条待审批申请。");
  }
  if (activeGrant(state, actor.id, resource.id, now)) {
    return reject(409, "GRANT_ACTIVE", "这项资源已有生效的授权。可结束授权后重新申请。");
  }
  const request = {
    id: nextId(state, "request", "req"),
    resourceId: resource.id,
    requesterId: actor.id,
    reason,
    minutes,
    status: "pending",
    createdAt: now,
    deadlineAt: now + APPROVAL_WINDOW,
  };
  state.requests.push(request);
  appendEvent(state, {
    at: now, actorId: actor.id, action: "request_submitted", resourceId: resource.id,
    requestId: request.id, details: { minutes, deadlineAt: request.deadlineAt },
  });
  return response({ request, created: true }, 201);
}

function readNote(value) {
  if (value === undefined) return "";
  return typeof value === "string" && value.length <= 300 ? value.trim() : null;
}

function decide(state, actor, id, action, body, now) {
  const request = state.requests.find(item => item.id === id);
  const resource = state.resources.find(item => item.id === request?.resourceId);
  if (!request || !canSeeRecord(resource, actor, request.requesterId)) {
    return reject(404, "REQUEST_NOT_FOUND", "没有找到这条申请。");
  }
  const own = request.requesterId === actor.id;
  if (action === "withdraw") {
    if (!own) return reject(403, "OWNER_REQUIRED", "申请人可以撤回自己的申请。");
  } else if (own || !canApprove(resource, actor)) {
    return reject(403, own ? "SELF_APPROVAL" : "APPROVER_REQUIRED",
      own ? "申请人需由其他资源审批人处理。" : "只有这项资源指定的审批人可以处理申请。");
  }
  const note = readNote(body.note);
  if (note === null) return reject(422, "INVALID_NOTE", "处理备注需在 300 个字以内。");
  const status = { approve: "approved", deny: "denied", withdraw: "withdrawn" }[action];
  const grant = state.grants.find(item => item.requestId === request.id);
  if (request.status === status && request.decisionBy === actor.id && request.note === note) {
    return response(grant ? { request, grant } : { request });
  }
  if (request.status !== "pending" || now < request.createdAt) {
    return reject(409, "REQUEST_CLOSED", "这条申请已结束或已处理，请刷新查看详情。");
  }
  if (action === "approve") {
    const requester = state.users.find(user => user.id === request.requesterId);
    if (!canRequest(resource, requester)) {
      return reject(409, "REQUESTER_INELIGIBLE", "申请人已不符合这项资源的申请策略。");
    }
    if (request.minutes > resource.maxMinutes) {
      return reject(409, "DURATION_POLICY_CHANGED", "申请时长已超过当前策略上限，请让申请人调整后重新提交。");
    }
    if (activeGrant(state, request.requesterId, request.resourceId, now)) {
      return reject(409, "GRANT_ACTIVE", "该申请人已有这项资源的有效授权。");
    }
  }
  Object.assign(request, { status, decidedAt: now, decisionBy: actor.id, note });
  const result = { request };
  if (action === "approve") {
    result.grant = {
      id: nextId(state, "grant", "grant"),
      requestId: request.id,
      resourceId: request.resourceId,
      userId: request.requesterId,
      status: "active",
      startsAt: now,
      expiresAt: now + request.minutes * MINUTE,
    };
    state.grants.push(result.grant);
  }
  appendEvent(state, {
    at: now, actorId: actor.id, action: "request_" + status, resourceId: request.resourceId, requestId: id,
    details: result.grant ? { note, grantId: result.grant.id, expiresAt: result.grant.expiresAt } : { note },
  });
  return response(result);
}

function closeGrant(state, actor, id, action, body, now) {
  const grant = state.grants.find(item => item.id === id);
  const resource = state.resources.find(item => item.id === grant?.resourceId);
  if (!grant || !canSeeRecord(resource, actor, grant.userId)) {
    return reject(404, "GRANT_NOT_FOUND", "没有找到这条授权。");
  }
  if (action === "return" && actor.id !== grant.userId) {
    return reject(403, "OWNER_REQUIRED", "获授权人可以提前归还自己的访问权限。");
  }
  if (action === "revoke" && !canApprove(resource, actor)) {
    return reject(403, "APPROVER_REQUIRED", "只有这项资源指定的审批人可以撤销授权。");
  }
  const note = readNote(body.note);
  if (note === null) return reject(422, "INVALID_NOTE", "处理备注需在 300 个字以内。");
  const status = action === "revoke" ? "revoked" : "returned";
  if (grant.status === status && grant.endedBy === actor.id && grant.note === note) return response({ grant });
  if (grant.status !== "active" || now < grant.startsAt) {
    return reject(409, "GRANT_CLOSED", "这条授权已结束，请刷新查看详情。");
  }
  Object.assign(grant, { status, endedAt: now, endedBy: actor.id, note });
  appendEvent(state, {
    at: now, actorId: actor.id, action: "grant_" + status, resourceId: grant.resourceId,
    requestId: grant.requestId, details: { grantId: id, note },
  });
  return response({ grant });
}

function activeGrant(state, userId, resourceId, now) {
  return state.grants.find(grant =>
    grant.resourceId === resourceId && grant.userId === userId && grant.status === "active" &&
    grant.startsAt <= now && now < grant.expiresAt
  );
}

function readReport(state, actor, resourceId, now) {
  const resource = state.resources.find(item => item.id === resourceId);
  if (!resource) return reject(404, "RESOURCE_NOT_FOUND", "没有找到这项资源。");
  const grant = activeGrant(state, actor.id, resourceId, now);
  const request = state.requests.findLast(item => item.resourceId === resourceId && item.requesterId === actor.id);
  const previousGrant = state.grants.findLast(item => item.resourceId === resourceId && item.userId === actor.id);
  const denial = !canRequest(resource, actor) ? "policy_restricted" : request?.status === "pending" ? "pending" :
    previousGrant && previousGrant.status !== "active" ? previousGrant.status : "not_granted";
  appendEvent(state, {
    at: now, actorId: actor.id, action: grant ? "report_read" : "report_denied", resourceId,
    requestId: grant?.requestId ?? request?.id,
    details: grant ? { status: 200, grantId: grant.id } : { status: 403, reason: denial },
  });
  if (!grant) return reject(403, "ACCESS_REQUIRED", "这份报表需要当前有效的临时访问授权。");
  return response({ resource: { id: resource.id, name: resource.name }, report: resource.report, grant });
}

export function handle(state, { method, path, actorId, now, body = {} }) {
  const actor = state.users.find(user => user.id === actorId);
  if (!actor) return reject(401, "SIGN_IN_REQUIRED", "请先进入工作区。");
  if (!Number.isSafeInteger(now) || now < 0) throw new TypeError("Invalid workspace time");
  if (method === "POST" && (!body || typeof body !== "object" || Array.isArray(body))) {
    return reject(400, "INVALID_BODY", "请求格式无效。");
  }
  reconcile(state, now);
  if (method === "GET" && path === "/api/workspace") return workspace(state, actor, now);
  if (method === "POST" && path === "/api/requests") return submit(state, actor, body, now);
  if (method === "POST") {
    const request = /^\/api\/requests\/([\w-]+)\/(approve|deny|withdraw)$/.exec(path);
    if (request) return decide(state, actor, request[1], request[2], body, now);
    const grant = /^\/api\/grants\/([\w-]+)\/(revoke|return)$/.exec(path);
    if (grant) return closeGrant(state, actor, grant[1], grant[2], body, now);
  }
  if (method === "GET") {
    const report = /^\/api\/resources\/([\w-]+)\/report$/.exec(path);
    if (report) return readReport(state, actor, report[1], now);
  }
  return reject(404, "ROUTE_NOT_FOUND", "没有找到这项操作。");
}
