import {readFile,writeFile,mkdir} from "node:fs/promises";
import {dirname,resolve} from "node:path";

const {argv}=process;
const output=resolve(argv[2] || "dist/index.html");
const read=path=>readFile(new URL(path,import.meta.url),"utf8");
const asModule=code=>"data:text/javascript;base64,"+Buffer.from(code,"utf8").toString("base64");

const [domain,fixtures,transport,app,css,template]=await Promise.all([
  read("../domain.mjs"),read("../fixtures.mjs"),read("transport.mjs"),read("../static/app.mjs"),
  read("../static/styles.css"),read("../static/index.html"),
]);
function substitute(code,path,replacement){
  const specifiers=[JSON.stringify(path),"'"+path+"'"];
  const from=specifiers.find(specifier=>code.includes(specifier));
  if(!from)throw new Error("Cannot resolve bundle dependency "+path);
  return code.replaceAll(from,JSON.stringify(replacement));
}
const offlineTransport=substitute(
  substitute(transport,"../domain.mjs",asModule(domain)),"../fixtures.mjs",asModule(fixtures));
const application=asModule(substitute(app,"./transport.mjs",asModule(offlineTransport)));
const policy="default-src 'none'; style-src 'unsafe-inline'; script-src data:; img-src data:; connect-src 'none'; base-uri 'none'; form-action 'none'";

const stylesheet=/<link\b[^>]*href=["'](?:\.\/)?styles\.css["'][^>]*>/iu;
const script=/<script\b[^>]*src=["'](?:\.\/)?app\.mjs["'][^>]*>\s*<\/script>/iu;
if(!stylesheet.test(template)||!script.test(template))throw new Error("Expected stylesheet and application module in index.html");
const markup=template.replace("<head>",`<head>\n  <meta http-equiv="Content-Security-Policy" content="${policy}">`)
  .replace("<html ",'<html data-edition="browser" ')
  .replace(stylesheet,()=>`<style>\n${css}\n</style>`)
  .replace(script,()=>`<script type="module" src="${application}"></script>`);
await mkdir(dirname(output),{recursive:true});
await writeFile(output,markup.replace(/\r\n/gu,"\n"),"utf8");
console.log("Browser demo written to "+output);
