import {createWorkspace,handle} from "../domain.mjs";
import {demoWorkspace} from "../fixtures.mjs";

const storeName="workspace";
const entry="current";
let memory;
const database=new Promise(resolve=>{
  try{
    const opening=indexedDB.open("temporary-access-demo",1);
    opening.onupgradeneeded=()=>opening.result.createObjectStore(storeName);
    opening.onsuccess=()=>resolve(opening.result);
    opening.onerror=()=>resolve(null);
    opening.onblocked=()=>resolve(null);
  }catch{
    resolve(null);
  }
});

function newState(){
  return {actorId:"employee",offset:0,workspace:createWorkspace(demoWorkspace)};
}

async function transact(run){
  const db=await database;
  if(!db){
    memory ||= newState();
    return run(memory);
  }
  return new Promise((resolve,reject)=>{
    const tx=db.transaction(storeName,"readwrite");
    const store=tx.objectStore(storeName);
    const reading=store.get(entry);
    let result,failure;
    reading.onsuccess=()=>{
      const state=reading.result || newState();
      try{
        result=run(state);
        store.put(state,entry);
      }catch(error){
        failure=error;
        tx.abort();
      }
    };
    tx.oncomplete=()=>resolve(result);
    tx.onabort=()=>reject(failure || tx.error || new Error("未能保存演练进度。"));
  });
}

function session(state){
  return {mode:"demo",user:demoWorkspace.users.find(user=>user.id===state.actorId),
    roles:demoWorkspace.users,now:Date.now()+state.offset};
}

function action(state, path, method, body){
  if(method==="GET" && path==="/api/session")return {status:200,body:session(state)};
  if(method==="POST" && path==="/api/session/role"){
    if(!demoWorkspace.users.some(user=>user.id===body.id))return {status:400,body:{error:"请选择一个演练角色。"}};
    state.actorId=body.id;
    return {status:200,body:session(state)};
  }
  if(method==="POST" && path==="/api/demo/clock"){
    if(!Number.isInteger(body.minutes) || body.minutes<1 || body.minutes>1440)
      return {status:400,body:{error:"请输入 1 到 1440 之间的整数分钟。"}};
    state.offset+=body.minutes*60000;
    return {status:200,body:session(state)};
  }
  return handle(state.workspace,{method,path,actorId:state.actorId,now:Date.now()+state.offset,body});
}

export default async function request(path,options={}){
  const {method="GET",body={}}=options;
  const result=await transact(state=>action(state,path,method,body));
  if(result.status>=400){
    const error=new Error(result.body.error);
    error.status=result.status;
    error.code=result.body.code;
    throw error;
  }
  return result.body;
}
