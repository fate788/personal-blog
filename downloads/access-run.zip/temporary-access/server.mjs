import { createHash, randomBytes, scrypt, scryptSync, timingSafeEqual } from "node:crypto";
import { closeSync, mkdirSync, openSync, readFileSync, statSync } from "node:fs";
import { createServer } from "node:http";
import { dirname, resolve } from "node:path";
import { DatabaseSync } from "node:sqlite";
import { fileURLToPath } from "node:url";
import { parseArgs, promisify } from "node:util";
import { createWorkspace, handle } from "./domain.mjs";
import { demoWorkspace } from "./fixtures.mjs";

const deriveKey = promisify(scrypt);
const sessionAge = 12 * 60 * 60;
const maxBodySize = 32 * 1024;
const authWindow = 60_000;
const localNames = new Set(["127.0.0.1", "localhost", "::1", "[::1]"]);
const teamRoles = new Set(["employee", "approver", "auditor"]);
const staticFiles = new Map([
  ["/", ["index.html", "text/html; charset=utf-8"]],
  ["/index.html", ["index.html", "text/html; charset=utf-8"]],
  ["/styles.css", ["styles.css", "text/css; charset=utf-8"]],
  ["/app.mjs", ["app.mjs", "text/javascript; charset=utf-8"]],
  ["/transport.mjs", ["transport.mjs", "text/javascript; charset=utf-8"]],
]);

class HTTPError extends Error {
  constructor(status, message) {
    super(message);
    this.status = status;
  }
}

function required(condition, status, message) {
  if (!condition) throw new HTTPError(status, message);
}

function publicUser(user) {
  const { id, name, role, department } = user;
  return { id, name, role, department };
}

function validLabel(value, maximum = 120) {
  return typeof value === "string" && value.trim().length > 0 && value.length <= maximum;
}

function validId(value) {
  return typeof value === "string" && /^[a-z0-9][a-z0-9_-]{0,47}$/.test(value);
}

function credentials(user) {
  const stored = user.passwordHash;
  const envName = user.passwordEnv;
  if (stored !== undefined && envName !== undefined) {
    throw new Error(`用户 ${user.id} 请配置一种密码来源。`);
  }
  if (stored !== undefined) {
    const fields = typeof stored === "string" && /^scrypt:([a-f0-9]{32}):([a-f0-9]{128})$/i.exec(stored);
    if (!fields) throw new Error(`用户 ${user.id} 的密码散列格式错误。`);
    return { salt: Buffer.from(fields[1], "hex"), key: Buffer.from(fields[2], "hex") };
  }
  const password = typeof envName === "string" && /^[A-Za-z_][A-Za-z0-9_]*$/.test(envName) && process.env[envName];
  if (typeof password !== "string" || password.length < 12 || password.length > 256) {
    throw new Error(`用户 ${user.id} 对应的密码环境变量需要含 12 至 256 个字符。`);
  }
  const salt = randomBytes(16);
  return { salt, key: scryptSync(password, salt, 64) };
}

function validReport(report) {
  return report && validLabel(report.period)
    && (report.summary === undefined || validLabel(report.summary, 1200))
    && Array.isArray(report.columns) && report.columns.length > 0 && report.columns.length <= 20
    && report.columns.every(column => validLabel(column))
    && Array.isArray(report.rows) && report.rows.length <= 500
    && report.rows.every(row => Array.isArray(row) && row.length === report.columns.length
      && row.every(cell => (typeof cell === "string" && cell.length <= 2000) || Number.isFinite(cell)));
}

function loadTeam(filename) {
  if (statSync(filename).size > 4 * 1024 * 1024) throw new Error("团队配置超过 4 MiB。");
  const config = JSON.parse(readFileSync(filename, "utf8").replace(/^\uFEFF/, ""));
  if (!Array.isArray(config?.users) || !config.users.length || !Array.isArray(config.resources)) {
    throw new Error("团队配置需要 users 和 resources 列表。");
  }
  const accounts = new Map();
  for (const entry of config.users) {
    if (!entry || !validId(entry.id) || !teamRoles.has(entry.role) || !validLabel(entry.name)
        || !validLabel(entry.department) || accounts.has(entry.id)) {
      throw new Error("团队配置包含无效或重复的用户。");
    }
    accounts.set(entry.id, { user: publicUser(entry), ...credentials(entry) });
  }
  const resourceIds = new Set();
  for (const resource of config.resources) {
    if (!resource || !validId(resource.id) || resourceIds.has(resource.id) || !validLabel(resource.name)
        || !validLabel(resource.category) || !validLabel(resource.department) || !validLabel(resource.summary, 1200)
        || !Number.isInteger(resource.maxMinutes) || resource.maxMinutes < 1 || resource.maxMinutes > 10080
        || !Array.isArray(resource.approverIds) || !resource.approverIds.length
        || !resource.approverIds.every(id => accounts.get(id)?.user.role === "approver")
        || (resource.requesterIds !== undefined
          && (!Array.isArray(resource.requesterIds) || !resource.requesterIds.every(id => accounts.has(id))))
        || !validReport(resource.report)) {
      throw new Error("团队配置包含无效或重复的资源。");
    }
    resourceIds.add(resource.id);
  }
  return { template: { users: [...accounts.values()].map(account => account.user), resources: config.resources }, accounts };
}

function parseOrigin(value) {
  if (!value) return "";
  const url = new URL(value);
  if (!["http:", "https:"].includes(url.protocol) || value !== url.origin) {
    throw new Error("--origin 应为完整 HTTP(S) 源，例如 https://access.example.com。");
  }
  return url.origin;
}

function checkHost(request, expectedOrigin, secure) {
  let host;
  try {
    host = new URL(`${secure ? "https" : "http"}://${request.headers.host || ""}`);
  } catch {
    throw new HTTPError(400, "请求主机地址无效。");
  }
  required(!host.username && !host.password && host.pathname === "/" && !host.search && !host.hash,
    400, "请求主机地址无效。");
  required(expectedOrigin ? new URL(expectedOrigin).host === host.host : localNames.has(host.hostname),
    400, "请求主机与工作台配置不匹配。");
  return expectedOrigin || host.origin;
}

function verifyMutation(request, origin) {
  required(request.headers["x-workspace-request"] === "1", 403, "请求校验失败，请刷新页面。");
  required(!request.headers.origin || request.headers.origin === origin, 403, "该操作仅允许从工作台发起。");
  required(/^application\/json(?:[ \t]*;|$)/i.test(request.headers["content-type"] || ""), 415, "请求需要 JSON 格式。");
}

async function readBody(request) {
  required(Number(request.headers["content-length"] || 0) <= maxBodySize, 413, "请求内容过长。");
  const chunks = [];
  let length = 0;
  for await (const chunk of request.iterator({ destroyOnReturn: false })) {
    length += chunk.length;
    if (length > maxBodySize) {
      request.resume();
      throw new HTTPError(413, "请求内容过长。");
    }
    chunks.push(chunk);
  }
  try {
    const value = JSON.parse(Buffer.concat(chunks).toString("utf8"));
    required(value && typeof value === "object" && !Array.isArray(value), 400, "请提交 JSON 对象。");
    return value;
  } catch (error) {
    if (error instanceof HTTPError) throw error;
    throw new HTTPError(400, "请求中的 JSON 无法读取。");
  }
}

function tokenDigest(token) {
  return createHash("sha256").update(token).digest("hex");
}

function readToken(cookieHeader, cookieName) {
  const prefix = cookieName + "=";
  for (const raw of (cookieHeader || "").split(";")) {
    const part = raw.trim();
    if (part.startsWith(prefix)) {
      const token = part.slice(prefix.length);
      if (/^[a-f0-9]{64}$/.test(token)) return tokenDigest(token);
    }
  }
  return "";
}

function createStore(path, mode, template) {
  if (path !== ":memory:") {
    mkdirSync(dirname(resolve(path)), { recursive: true, mode: 0o700 });
    closeSync(openSync(path, "a", 0o600));
  }
  const db = new DatabaseSync(path);
  db.exec(`
    PRAGMA busy_timeout = 5000;
    PRAGMA journal_mode = WAL;
    PRAGMA foreign_keys = ON;
    CREATE TABLE IF NOT EXISTS workspaces (
      id TEXT PRIMARY KEY, mode TEXT NOT NULL, state TEXT NOT NULL,
      offset_ms INTEGER NOT NULL DEFAULT 0, updated_at INTEGER NOT NULL
    ) STRICT;
    CREATE TABLE IF NOT EXISTS sessions (
      token TEXT PRIMARY KEY, workspace_id TEXT NOT NULL REFERENCES workspaces(id) ON DELETE CASCADE,
      actor_id TEXT NOT NULL, expires_at INTEGER NOT NULL
    ) STRICT;
    CREATE INDEX IF NOT EXISTS session_expiration ON sessions(expires_at);
    CREATE INDEX IF NOT EXISTS workspace_retention ON workspaces(mode, updated_at);
  `);
  const insertDesk = db.prepare("INSERT OR IGNORE INTO workspaces (id,mode,state,updated_at) VALUES (?,?,?,?)");
  const insertSession = db.prepare("INSERT INTO sessions (token,workspace_id,actor_id,expires_at) VALUES (?,?,?,?)");
  const findSession = db.prepare(`SELECT w.id,w.state,w.offset_ms,s.actor_id,s.token
    FROM sessions s JOIN workspaces w ON w.id=s.workspace_id
    WHERE s.token=? AND w.mode=? AND s.expires_at>?`);
  const revokeSession = db.prepare("DELETE FROM sessions WHERE token=?");
  const saveDesk = db.prepare("UPDATE workspaces SET state=?,updated_at=? WHERE id=?");
  const setActor = db.prepare("UPDATE sessions SET actor_id=? WHERE token=?");
  const moveClock = db.prepare("UPDATE workspaces SET offset_ms=offset_ms+?, updated_at=? WHERE id=?");
  const pruneSessions = db.prepare("DELETE FROM sessions WHERE expires_at<=?");
  const pruneDesks = db.prepare("DELETE FROM workspaces WHERE mode='demo' AND updated_at<?");
  const catalog = createWorkspace(template);
  const withoutTeamCatalog = state => mode === "team" ? { ...state, users: [], resources: [] } : state;
  const emptyState = JSON.stringify(withoutTeamCatalog(catalog));
  let lastPrune = 0;

  function transaction(action) {
    db.exec("BEGIN IMMEDIATE");
    try {
      const result = action();
      db.exec("COMMIT");
      return result;
    } catch (error) {
      db.exec("ROLLBACK");
      throw error;
    }
  }

  if (mode === "team") {
    transaction(() => {
      insertDesk.run("team", mode, emptyState, Date.now());
      db.prepare("DELETE FROM sessions WHERE workspace_id='team'").run();
    });
  }
  return {
    db,
    transaction,
    prune(now) {
      if (now - lastPrune < 60_000) return;
      pruneSessions.run(now);
      pruneDesks.run(now - 3 * 24 * 3600 * 1000);
      lastPrune = now;
    },
    open(token, now) {
      return token ? findSession.get(token, mode, now) : null;
    },
    issue(actorId, now, previousToken) {
      const workspaceId = mode === "team" ? "team" : randomBytes(24).toString("hex");
      if (mode === "demo") insertDesk.run(workspaceId, mode, emptyState, now);
      const token = randomBytes(32).toString("hex");
      if (previousToken) revokeSession.run(previousToken);
      insertSession.run(tokenDigest(token), workspaceId, actorId, now + sessionAge * 1000);
      return token;
    },
    revoke(token) { revokeSession.run(token); },
    load(workspace) {
      const state = JSON.parse(workspace.state);
      if (mode === "team") {
        state.users = catalog.users;
        state.resources = catalog.resources;
      }
      return state;
    },
    save(workspace, state, now) { saveDesk.run(JSON.stringify(withoutTeamCatalog(state)), now, workspace.id); },
    setActor(workspace, actorId) { setActor.run(actorId, workspace.token); },
    moveClock(workspace, minutes, now) { moveClock.run(minutes * 60_000, now, workspace.id); },
  };
}

export function startServer({
  host = "127.0.0.1", port = 8801, dbPath, teamFile, origin, secureCookie = false,
} = {}) {
  const expectedOrigin = parseOrigin(origin);
  const secure = secureCookie || expectedOrigin.startsWith("https:");
  const mode = teamFile ? "team" : "demo";
  if (!localNames.has(host) && !expectedOrigin) throw new Error("监听外部地址时需要配置 --origin。");
  const external = !localNames.has(host) || expectedOrigin && !localNames.has(new URL(expectedOrigin).hostname);
  if (mode === "team" && external && !secure) throw new Error("团队模式对外服务需要 HTTPS。");
  if (secure && !expectedOrigin.startsWith("https:")) throw new Error("安全 Cookie 需要 HTTPS --origin。");
  const team = teamFile ? loadTeam(teamFile) : null;
  const template = team ? team.template : demoWorkspace;
  const publicUsers = new Map(template.users.map(user => [user.id, publicUser(user)]));
  const store = createStore(dbPath || fileURLToPath(new URL(`./data/${mode}.sqlite3`, import.meta.url)), mode, template);
  const cookieName = (secure ? "__Host-" : "") + (mode === "team" ? "accessDeskTeam" : "accessDeskDemo");
  const cookie = (token, age) => `${cookieName}=${token}; Path=/; HttpOnly; SameSite=Lax; Max-Age=${age}${secure ? "; Secure" : ""}`;
  const loginAttempts = new Map();
  const fallbackCredentials = { salt: randomBytes(16), key: randomBytes(64) };

  function json(response, status, body, options = {}) {
    response.writeHead(status, { "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store", ...options });
    response.end(JSON.stringify(body));
  }

  function sessionData(actor, now) {
    return { mode, user: actor || null, roles: mode === "demo" ? [...publicUsers.values()] : [], now };
  }

  async function login(request, response, input, previousToken) {
    required(mode === "team", 404, "当前工作区使用预设演示身份。");
    const now = Date.now();
    const address = request.socket.remoteAddress;
    for (const [key, entry] of loginAttempts) {
      if (entry.reset <= now) loginAttempts.delete(key);
    }
    const attempt = loginAttempts.get(address) || { count: 0, reset: now + authWindow };
    required(attempt.count < 24, 429, "尝试次数过多，请稍后重试。");
    attempt.count += 1;
    loginAttempts.set(address, attempt);
    const account = typeof input.id === "string" && team.accounts.get(input.id);
    const password = input.password;
    required(typeof password === "string" && password.length > 0 && password.length <= 256, 400, "请输入登录账号和密码。");
    const expected = account || fallbackCredentials;
    const hash = await deriveKey(password, expected.salt, expected.key.length);
    required(timingSafeEqual(hash, expected.key) && account, 401, "账号或密码错误。");
    const signedInAt = Date.now();
    const token = store.transaction(() => store.issue(account.user.id, signedInAt, previousToken));
    json(response, 200, sessionData(account.user, signedInAt), { "Set-Cookie": cookie(token, sessionAge) });
  }

  function routeAPI(response, method, path, input, token) {
    const wall = Date.now();
    const result = store.transaction(() => {
      store.prune(wall);
      const workspace = store.open(token, wall);
      const actor = workspace && publicUsers.get(workspace.actor_id);
      const now = wall + (workspace?.offset_ms || 0);
      if (method === "GET" && path === "/api/session") {
        if (!actor && mode === "demo") {
          const initial = publicUsers.get("employee");
          const fresh = store.issue(initial.id, wall);
          return { status: 200, body: sessionData(initial, wall), signed: cookie(fresh, sessionAge) };
        }
        return { status: 200, body: sessionData(actor, now) };
      }
      if (method === "POST" && path === "/api/logout") {
        if (workspace) store.revoke(token);
        return { status: 200, body: sessionData(null, wall), signed: cookie("", 0) };
      }
      required(actor, 401, "请登录或刷新工作区。");
      if (method === "POST" && path === "/api/session/role") {
        required(mode === "demo", 403, "团队工作区的角色由登录账号确定。");
        const next = publicUsers.get(input.id);
        required(next, 400, "未找到指定的演示身份。");
        store.setActor(workspace, next.id);
        return { status: 200, body: sessionData(next, now) };
      }
      if (method === "POST" && path === "/api/demo/clock") {
        required(mode === "demo", 403, "团队工作区使用服务器时间。");
        const { minutes } = input;
        required(Number.isInteger(minutes) && minutes >= 1 && minutes <= 1440, 400, "请选择 1 至 1440 分钟。");
        store.moveClock(workspace, minutes, wall);
        return { status: 200, body: sessionData(actor, now + minutes * 60_000) };
      }
      const state = store.load(workspace);
      const outcome = handle(state, { method, path, actorId: actor.id, now, body: input });
      store.save(workspace, state, wall);
      return outcome;
    });
    json(response, result.status, result.body, result.signed ? { "Set-Cookie": result.signed } : {});
  }

  const server = createServer({ maxHeaderSize: 16 * 1024, requestTimeout: 10_000, headersTimeout: 8_000 },
    async (request, response) => {
      response.setHeader("X-Content-Type-Options", "nosniff");
      response.setHeader("Referrer-Policy", "no-referrer");
      response.setHeader("X-Frame-Options", "DENY");
      response.setHeader("Cross-Origin-Resource-Policy", "same-origin");
      response.setHeader("Content-Security-Policy",
        "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'self'; object-src 'none'; base-uri 'none'; form-action 'self'; frame-ancestors 'none'");
      try {
        const trustedOrigin = checkHost(request, expectedOrigin, secure);
        required(request.url?.startsWith("/") && !request.url.startsWith("//"), 400, "请求路径无效。");
        const path = new URL(request.url, trustedOrigin).pathname;
        const method = request.method;
        if (path.startsWith("/api/")) {
          required(["GET", "POST"].includes(method), 405, "此方法不可用于工作台接口。");
          const site = request.headers["sec-fetch-site"];
          required(!site || site === "same-origin" || site === "none", 403, "该操作仅允许从工作台发起。");
          const token = readToken(request.headers.cookie, cookieName);
          let input = {};
          if (method === "POST") {
            verifyMutation(request, trustedOrigin);
            input = await readBody(request);
          }
          if (method === "POST" && path === "/api/login") await login(request, response, input, token);
          else routeAPI(response, method, path, input, token);
          return;
        }
        const file = staticFiles.get(path);
        required(file && ["GET", "HEAD"].includes(method), 404, "未找到此页面。");
        const [name, type] = file;
        const contents = readFileSync(new URL("./static/" + name, import.meta.url));
        response.writeHead(200, { "Content-Type": type, "Content-Length": contents.length, "Cache-Control": "no-cache" });
        response.end(method === "HEAD" ? undefined : contents);
      } catch (error) {
        if (response.destroyed) return;
        if (error instanceof HTTPError) json(response, error.status, { error: error.message });
        else {
          console.error(error.code || error.name || "RequestError");
          json(response, 500, { error: "工作台暂时无法完成操作，请稍后重试。" });
        }
      }
    });
  server.on("close", () => store.db.close());
  return server.listen(port, host);
}

if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const { values } = parseArgs({ options: {
    host: { type: "string", default: "127.0.0.1" },
    port: { type: "string", default: "8801" },
    db: { type: "string" },
    origin: { type: "string" },
    "team-file": { type: "string" },
    "secure-cookie": { type: "boolean" },
  } });
  if (!/^\d{1,5}$/.test(values.port) || Number(values.port) > 65535) throw new Error("端口应为 0 至 65535。");
  const server = startServer({
    host: values.host, port: Number(values.port), dbPath: values.db,
    teamFile: values["team-file"], origin: values.origin, secureCookie: values["secure-cookie"],
  });
  server.on("listening", () => {
    const address = server.address();
    const host = address.family === "IPv6" ? `[${address.address}]` : address.address;
    console.log(`http://${host}:${address.port}/`);
  });
}
