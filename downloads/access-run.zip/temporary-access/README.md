# 企业临时权限工作台

审批人按报表批准临时访问。申请人可在到期前查看报表或提前归还访问权，负责人也可主动撤销。到期后即使保存了原地址，服务也会按本次请求的身份、资源和时间重新鉴权。审计人员可查看申请、决定、权限结束及报表访问记录。

[在线演练](https://fate788.github.io/personal-blog/demos/access/) · [博客作品页](https://fate788.github.io/personal-blog/#project/access)

![申请人工作台](docs/preview.webp)

## 运行

安装 Node.js 22.13 或以上，不需要安装项目依赖。

```sh
node server.mjs --port 8801
npm test
```

打开 [本机工作台](http://127.0.0.1:8801/)。Windows 也可以双击 `start-access.cmd`。

| 运行方式 | 身份和数据 | 时间 |
| --- | --- | --- |
| 公开演练与离线 HTML | 虚构人员及报表，保存到访客浏览器的 IndexedDB | 可推进演练时间 |
| Node.js 演练服务 | 服务端 SQLite，每个访客会话得到独立的虚构工作区 | 可推进工作区的演练时间 |
| Node.js 团队服务 | 登录后的团队账号，读取配置内的私有报表，操作记录保存在 SQLite | 服务器实际时间 |

## 演练

1. 以申请人身份打开区域经营周报，确认还没有访问权。
2. 填写复盘用途和 15 分钟访问时长。切换为资源负责人，打开待审批申请并批准。
3. 切回申请人，访问同一份报表，核对可见的数据和结束时间。
4. 推进演练时间至少 15 分钟，再次打开同一份报表。切换到审计角色，核对申请、审批、成功读取、到期和再次读取被拒绝的记录。

## 团队试用

复制 `samples/team.example.json` 为项目目录下的 `team.local.json`，将人员、允许申请的账号、负责审批的账号和报表替换为团队自己的数据。为各示例账号设置对应名称的密码环境变量，之后启动服务。不要把团队配置加入版本控制。

```powershell
Copy-Item samples/team.example.json team.local.json
$env:ACCESS_OPERATOR_PASSWORD = Read-Host "运营同事密码" -MaskInput
$env:ACCESS_OWNER_PASSWORD = Read-Host "资源负责人密码" -MaskInput
$env:ACCESS_AUDIT_PASSWORD = Read-Host "审计员密码" -MaskInput
node server.mjs --port 8801 --db data/team.sqlite --team-file team.local.json
```

`passwordEnv` 的值是环境变量名称。每个账号用各自至少 12 字符的密码。团队服务默认监听本机。在 HTTPS 反向代理后运行时，指定 `--origin https://权限台域名 --secure-cookie` 并保留外部 Host。团队配置将授权限定到报表读取，已经读取或另行复制的内容无法收回。

## 设计与验收

- 审批参考 Microsoft Entra 的发起、审批和到期状态。每项资源单独指定负责人，限时授权期间可以归还或撤销。[访问申请流程](https://learn.microsoft.com/en-us/entra/id-governance/entitlement-management-process)
- 限时访问参考 Google Cloud Privileged Access Manager 对用途、时长、审批人与审计的拆分。工作台记录应用内报表访问，并在每次读取时重新校验授权。[Google Cloud 权限管理](https://docs.cloud.google.com/iam/docs/pam-overview/)
- `domain.mjs` 处理申请、批准、拒绝、撤回、归还、撤销与到期。到期判定精确到服务器的当前毫秒。首次触及到期状态时，审计记录同时保留实际到期时间和记录时间。
- `server.mjs` 管理会话和 SQLite 事务。团队版的静态页面不包含报表正文，访问成功后才由 API 返回。
- `npm run build:demo` 生成 `dist/index.html`。可下载并离线打开，内含公开虚构样例及与服务共用的规则。
