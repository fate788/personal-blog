import assert from "node:assert/strict";
import { test } from "node:test";
import { createWorkspace, handle } from "../domain.mjs";

const MINUTE = 60_000;
const START = Date.UTC(2026, 10, 27, 8);
const USERS = [
  { id: "lin", name: "林晓", role: "employee", department: "运营" },
  { id: "xu", name: "许一", role: "employee", department: "运营" },
  { id: "cheng", name: "程宁", role: "approver", department: "运营" },
  { id: "qiao", name: "乔念", role: "approver", department: "支持" },
  { id: "gu", name: "顾文", role: "auditor", department: "审计" },
];
const OPERATIONS = {
  id: "operations",
  name: "渠道复盘报表",
  category: "报表",
  department: "运营",
  summary: "核对渠道投放转化。",
  maxMinutes: 30,
  approverIds: ["cheng"],
  report: { period: "2026-W48", columns: ["渠道", "访问量"], rows: [["直营", 4167]] },
};
const SUPPORT = {
  id: "support",
  name: "支持回访报表",
  category: "报表",
  department: "支持",
  summary: "查看各组的回访完成情况。",
  maxMinutes: 15,
  approverIds: ["qiao"],
  requesterIds: ["lin", "qiao"],
  report: { period: "2026-W48", columns: ["团队", "回访量"], rows: [["一组", 729]] },
};

function setup() {
  const state = createWorkspace({ users: USERS, resources: [OPERATIONS, SUPPORT] });
  function get(actorId, path, now = START) {
    return handle(state, { method: "GET", path, actorId, now });
  }
  function post(actorId, path, body, now = START) {
    return handle(state, { method: "POST", path, actorId, now, body });
  }
  function request(resourceId, actorId = "lin", now = START, minutes = 5) {
    const result = post(actorId, "/api/requests", { resourceId, minutes, reason: "支援项目核对本周数据" }, now);
    assert.equal(result.status, 201);
    return result.body.request;
  }
  return { state, get, post, request };
}

test("报表同一路径从拒绝到允许，在授权到期毫秒立即拒绝", () => {
  const { get, post, request } = setup();
  const path = "/api/resources/operations/report";
  assert.equal(get("lin", path).status, 403);
  const pending = request("operations");
  assert.equal(get("lin", path).status, 403);

  const approvalAt = START + 3 * MINUTE;
  const response = post("cheng", "/api/requests/" + pending.id + "/approve", { note: "限本次核对" }, approvalAt);
  assert.equal(response.status, 200);
  assert.equal(response.body.grant.startsAt, approvalAt);
  assert.equal(response.body.grant.expiresAt, approvalAt + 5 * MINUTE);

  const expires = response.body.grant.expiresAt;
  const allowed = get("lin", path, expires - 1);
  assert.equal(allowed.status, 200);
  assert.deepEqual(allowed.body.report, OPERATIONS.report);
  const expired = get("lin", path, expires);
  assert.equal(expired.status, 403);
  assert.equal(expired.body.report, undefined);
  assert.equal(get("lin", path, expires + 1).status, 403);

  const { grants, events } = get("gu", "/api/workspace", expires + 1).body;
  assert.equal(grants[0].status, "expired");
  assert.equal(grants[0].endedAt, expires);
  assert.equal(events.filter(event => event.action === "grant_expired").length, 1);
  assert.deepEqual(events.filter(event => event.action.startsWith("report_")).map(event => event.details.status),
    [403, 403, 200, 403, 403]);
});

test("授权只能用于对应的本人和资源，工作区只展示角色可见记录", () => {
  const { get, post, request } = setup();
  const pending = request("operations");
  assert.equal(post("cheng", "/api/requests/" + pending.id + "/approve", {}).status, 200);

  assert.equal(get("lin", "/api/resources/support/report").status, 403);
  assert.equal(get("xu", "/api/resources/operations/report").status, 403);
  assert.equal(get("cheng", "/api/resources/operations/report").status, 403);
  assert.equal(get("gu", "/api/resources/operations/report").status, 403);
  assert.equal(get("anonymous", "/api/resources/operations/report").status, 401);

  const anotherEmployee = get("xu", "/api/workspace").body;
  assert.deepEqual(anotherEmployee.requests, []);
  assert.deepEqual(anotherEmployee.grants, []);
  assert.deepEqual(anotherEmployee.resources.map(resource => resource.id), ["operations"]);
  assert.equal(get("qiao", "/api/workspace").body.requests.length, 0);
  assert.equal(get("cheng", "/api/workspace").body.requests[0].requesterId, "lin");

  const audit = get("gu", "/api/workspace").body;
  assert.equal(audit.grants.length, 1);
  assert.equal(audit.resources.length, 2);
  assert.ok(audit.resources.every(resource => !Object.hasOwn(resource, "report")));
  assert.ok(!JSON.stringify(audit).includes("4167"));
});

test("重复提交和批准只创建一次，审批人只能审批所负责资源的他人申请", () => {
  const { get, post, request } = setup();
  const pending = request("operations");
  const repeated = post("lin", "/api/requests", {
    resourceId: "operations", minutes: 5, reason: "支援项目核对本周数据",
  });
  assert.equal(repeated.status, 200);
  assert.equal(repeated.body.created, false);
  assert.equal(repeated.body.request.id, pending.id);
  assert.equal(post("lin", "/api/requests", {
    resourceId: "operations", minutes: 4, reason: "同一项正在等待审批",
  }).status, 409);

  const approval = "/api/requests/" + pending.id + "/approve";
  assert.equal(post("qiao", approval, {}).status, 404);
  assert.deepEqual(post("xu", approval, {}), post("xu", "/api/requests/req-does-not-exist/approve", {}));
  assert.equal(post("gu", approval, {}).status, 403);
  const first = post("cheng", approval, { note: "限本次" });
  const repeat = post("cheng", approval, { note: "限本次" });
  assert.equal(first.status, 200);
  assert.equal(repeat.status, 200);
  assert.equal(first.body.grant.id, repeat.body.grant.id);

  const own = request("support", "qiao");
  assert.equal(post("qiao", "/api/requests/" + own.id + "/approve", {}).body.code, "SELF_APPROVAL");
  const audit = get("gu", "/api/workspace").body;
  assert.equal(audit.grants.length, 1);
  assert.equal(audit.events.filter(event => event.action === "request_approved").length, 1);
});

test("资源策略变化阻止超额审批并撤销已失去资格的存量授权", () => {
  const { state, get, post, request } = setup();
  const earlier = request("operations", "lin", START, 20);
  state.resources[0].maxMinutes = 10;
  const approval = post("cheng", "/api/requests/" + earlier.id + "/approve", {});
  assert.equal(approval.status, 409);
  assert.equal(approval.body.code, "DURATION_POLICY_CHANGED");
  assert.equal(post("lin", "/api/requests/" + earlier.id + "/withdraw", {}).status, 200);

  const adjusted = request("operations");
  assert.equal(post("cheng", "/api/requests/" + adjusted.id + "/approve", {}).status, 200);
  const path = "/api/resources/operations/report";
  assert.equal(get("lin", path, START + 1).status, 200);
  state.resources[0].requesterIds = ["xu"];
  assert.equal(get("lin", path, START + 2).status, 403);
  state.resources[0].requesterIds.push("lin");
  assert.equal(get("lin", path, START + 3).status, 403);

  const { grants, events } = get("gu", "/api/workspace", START + 3).body;
  assert.equal(grants[0].status, "revoked");
  const revoked = events.find(event => event.action === "grant_revoked");
  assert.equal(revoked.actorId, "system");
  assert.equal(revoked.details.reason, "policy_changed");
});

test("撤回和拒绝不发放授权，超过审批期限无法批准", () => {
  const { get, post, request } = setup();
  const withdrawn = request("operations");
  const withdrawal = "/api/requests/" + withdrawn.id + "/withdraw";
  assert.equal(post("cheng", withdrawal, {}).status, 403);
  assert.equal(post("lin", withdrawal, {}).body.request.status, "withdrawn");
  assert.equal(post("cheng", "/api/requests/" + withdrawn.id + "/approve", {}).status, 409);

  const denied = request("operations");
  const denial = post("cheng", "/api/requests/" + denied.id + "/deny", { note: "需先与项目负责人核对" });
  assert.equal(denial.body.request.status, "denied");
  assert.equal(denial.body.request.note, "需先与项目负责人核对");

  const forgotten = request("operations");
  assert.equal(post("cheng", "/api/requests/" + forgotten.id + "/approve", {}, forgotten.deadlineAt).status, 409);
  const snapshot = get("gu", "/api/workspace", forgotten.deadlineAt + 1).body;
  assert.deepEqual(snapshot.requests.map(record => record.status), ["withdrawn", "denied", "expired"]);
  assert.equal(snapshot.grants.length, 0);
  assert.equal(snapshot.events.filter(event => event.action === "request_expired").length, 1);
  assert.equal(get("lin", "/api/resources/operations/report", forgotten.deadlineAt + 1).status, 403);
});

test("审批人撤销和申请人归还会立即阻止后续读取", () => {
  const { get, post, request } = setup();
  const path = "/api/resources/operations/report";
  const first = request("operations");
  const approved = post("cheng", "/api/requests/" + first.id + "/approve", {}).body.grant;
  const revoke = "/api/grants/" + approved.id + "/revoke";
  assert.equal(post("qiao", revoke, {}, START + 1).status, 404);
  assert.deepEqual(post("xu", revoke, {}, START + 1), post("xu", "/api/grants/grant-does-not-exist/revoke", {}, START + 1));
  assert.equal(get("lin", path, START + 1).status, 200);
  assert.equal(post("cheng", revoke, { note: "任务已提前结束" }, START + 2).body.grant.status, "revoked");
  assert.equal(get("lin", path, START + 2).status, 403);

  const second = request("operations", "lin", START + 3);
  const added = post("cheng", "/api/requests/" + second.id + "/approve", {}, START + 3).body.grant;
  const returnAccess = "/api/grants/" + added.id + "/return";
  assert.equal(post("cheng", returnAccess, {}, START + 4).status, 403);
  assert.equal(get("lin", path, START + 4).status, 200);
  assert.equal(post("lin", returnAccess, { note: "数据核对完成" }, START + 5).body.grant.status, "returned");
  assert.equal(get("lin", path, START + 5).status, 403);
});
