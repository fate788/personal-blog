import assert from "node:assert/strict";
import {once} from "node:events";
import {spawn} from "node:child_process";
import {mkdtemp,rm} from "node:fs/promises";
import {tmpdir} from "node:os";
import {join} from "node:path";
import {fileURLToPath} from "node:url";
import {test} from "node:test";

const root=fileURLToPath(new URL("../",import.meta.url));
const postHeaders={"Content-Type":"application/json","X-Workspace-Request":"1"};
const demoReport="/api/resources/regional-report/report";
const loginSecret="test-fixture-only-password";

async function serve(t,arguments_=[],env={}){
  const temp=await mkdtemp(join(tmpdir(),"temporary-access-test-"));
  const child=spawn(process.execPath,["server.mjs","--port","0","--db",join(temp,"test.sqlite"),...arguments_],
    {cwd:root,env:{...process.env,...env},stdio:["ignore","pipe","pipe"]});
  const exited=once(child,"exit");
  t.after(async()=>{
    child.kill();
    await exited.catch(()=>{});
    await rm(temp,{recursive:true,force:true});
  });
  const url=await new Promise((resolve,reject)=>{
    let output="",errors="";
    child.stderr.on("data",chunk=>{errors+=chunk;});
    child.stdout.on("data",chunk=>{
      output+=chunk;
      const match=output.match(/http:\/\/127\.0\.0\.1:\d+/u);
      if(match)resolve(match[0]);
    });
    child.on("error",reject);
    child.on("exit",code=>reject(new Error(`Server stopped (${code}) ${errors}`)));
  });
  return url;
}

function client(base){
  let cookie="";
  return {
    cookie:()=>cookie,
    async request(path,body,headers={}){
      const response=await fetch(base+path,{
        method:body===undefined?"GET":"POST",
        headers:{...(body===undefined?{}:postHeaders),...(cookie?{Cookie:cookie}:{}),...headers},
        body:body===undefined?undefined:JSON.stringify(body),
      });
      const set=response.headers.get("set-cookie");
      if(set)cookie=set.split(";")[0];
      const type=response.headers.get("content-type");
      const data=type?.includes("application/json")?await response.json():await response.text();
      return {status:response.status,data,headers:response.headers};
    },
  };
}

test("same report returns 403, 200, then 403 and records the actual decisions", {timeout:15000},async t=>{
  const base=await serve(t);
  const person=client(base);
  const initial=await person.request("/api/session");
  assert.equal(initial.data.user.id,"employee");
  assert.match(initial.headers.get("set-cookie"),/HttpOnly/i);
  assert.match(initial.headers.get("set-cookie"),/SameSite=/i);
  assert.equal((await person.request(demoReport)).status,403);
  const catalogue=await person.request("/api/workspace");
  assert.ok(!JSON.stringify(catalogue.data).includes("192.6"));

  const input={resourceId:"regional-report",reason:"参加区域经营复盘",minutes:15};
  const pending=await person.request("/api/requests",input);
  assert.equal(pending.status,201);
  const duplicate=await person.request("/api/requests",input);
  assert.equal(duplicate.data.request.id,pending.data.request.id);
  const requestPath="/api/requests/"+pending.data.request.id;
  assert.equal((await person.request(requestPath+"/approve",{})).status,403);
  assert.equal((await person.request("/api/session/role",{id:"approver"})).status,200);
  const approved=await person.request(requestPath+"/approve",{note:"用于本次复盘"});
  assert.equal(approved.data.grant.status,"active");
  assert.equal((await person.request(demoReport)).status,403);
  await person.request("/api/session/role",{id:"employee"});
  const report=await person.request(demoReport);
  assert.equal(report.status,200);
  assert.equal(report.data.report.rows[0][1],192.6);
  assert.match(report.headers.get("cache-control"),/no-store/i);
  assert.equal((await person.request("/api/resources/fulfillment-report/report")).status,403);

  assert.equal((await person.request("/api/demo/clock",{minutes:15})).status,200);
  const expired=await person.request(demoReport);
  assert.equal(expired.status,403);
  assert.equal(expired.data.report,undefined);
  await person.request("/api/session/role",{id:"auditor"});
  const audit=(await person.request("/api/workspace")).data;
  assert.ok(audit.events.some(event=>event.action==="request_approved"&&event.actorId==="approver"));
  assert.ok(audit.events.some(event=>event.action==="report_read"&&event.actorId==="employee"));
  assert.ok(audit.events.some(event=>event.action==="grant_expired"&&event.requestId===pending.data.request.id));
  assert.equal(audit.events.filter(event=>event.action==="report_denied"&&event.actorId==="employee"&&event.resourceId==="regional-report").length,2);

  const visitor=client(base);
  await visitor.request("/api/session");
  assert.equal((await visitor.request("/api/workspace")).data.requests.length,0);
  assert.equal((await person.request("/domain.mjs")).status,404);
  assert.equal((await person.request("/fixtures.mjs")).status,404);
});

test("team login binds separate real actors and private report content", {timeout:15000},async t=>{
  const config="samples/team.example.json";
  const base=await serve(t,["--team-file",config],{
    ACCESS_OPERATOR_PASSWORD:loginSecret,ACCESS_OWNER_PASSWORD:loginSecret,ACCESS_AUDIT_PASSWORD:loginSecret,
  });
  const operator=client(base),owner=client(base),auditor=client(base);
  assert.equal((await operator.request("/api/session")).data.user,null);
  assert.equal((await operator.request("/api/workspace")).status,401);
  const staticText=await operator.request("/");
  assert.equal(staticText.status,200);
  assert.ok(!JSON.stringify(staticText.data).includes("1137"));
  assert.equal((await operator.request("/samples/team.example.json")).status,404);
  assert.equal((await operator.request("/api/login",{id:"operator",password:"incorrect"})).status,401);
  for(const [actor,id] of [[operator,"operator"],[owner,"owner"],[auditor,"audit"]]){
    const result=await actor.request("/api/login",{id,password:loginSecret});
    assert.equal(result.data.user.id,id);
    assert.equal(result.data.mode,"team");
    assert.deepEqual(result.data.roles,[]);
  }
  assert.equal((await operator.request("/api/session/role",{id:"owner"})).status,403);
  assert.equal((await operator.request("/api/demo/clock",{minutes:15})).status,403);
  const path="/api/resources/capacity-report/report";
  const request=(await operator.request("/api/requests",{resourceId:"capacity-report",reason:"复核本周供应计划",minutes:10})).data.request;
  const approvalPath="/api/requests/"+request.id+"/approve";
  assert.equal((await auditor.request(approvalPath,{})).status,403);
  const grant=(await owner.request(approvalPath,{})).data.grant;
  assert.equal((await operator.request(path)).data.report.rows[0][2],1137);
  assert.equal((await auditor.request(path)).status,403);
  assert.equal((await owner.request("/api/grants/"+grant.id+"/revoke",{note:"复核已经提前完成"})).status,200);
  assert.equal((await operator.request(path)).status,403);
  const before=operator.cookie();
  assert.equal((await operator.request("/api/logout",{})).status,200);
  assert.equal((await client(base).request("/api/workspace",undefined,{Cookie:before})).status,401);
});
