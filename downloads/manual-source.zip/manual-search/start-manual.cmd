@echo off
cd /d "%~dp0"
python -B server.py
if errorlevel 1 pause
