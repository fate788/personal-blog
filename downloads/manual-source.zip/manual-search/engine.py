"""Offline Chinese passage retrieval over two version-pinned project manuals."""

from collections import Counter
from dataclasses import dataclass
from functools import lru_cache
from math import log
from pathlib import Path
import re
import unicodedata


CORPUS = Path(__file__).resolve().parent / "corpus"
SOURCES = {
    "clinic": ("门诊候补与改约工作台", "clinic-scheduling", "v0.6",
               "bf00adf19b6588e4800e48f25bd487980f0a0119"),
    "ledger": ("双账核对工作台", "ledger-reconciliation", "v0.2",
               "97649044221e9a7bde0100948efba7b617b995b3"),
}

# Domain vocabulary expands terms in both documents and queries. No entry
# points to an answer, line number or particular document.
VOCABULARY = """
候补 排候补 排队等号 轮到 排在队首 下一位 下一人 队列中的下一人 队首 递补 替补 顺延 转给 候位
递补 转给 谁接手 给谁 下一个人 下一位 轮到谁
留位 保留位 保留多久 暂留 留号 预留 保号 锁号 过号 到期 逾期 超时 有效期 截止时刻 错过时限 没及时确认 来不及确认
时长 多久 多长时间 几分钟 分钟 时间限制 留位时间 有效时长
跨日 隔天 另一天 换一天 第二天 明天 跨天
停诊 停开 停班 取消出诊
改约 改签 改期 换班次 转诊次 换个班次 换个时间
余号 号源 空位 名额 剩余号 有号 放号
查号 预约查询 查预约 查预订单 查单 查记录
就诊编号 就诊号 患者编号 病人编号
预约单号 预约编号 预约单 挂号单
已取消 取消预约 退号 取消挂号
日程 排班 周日历 班表 出诊表
键盘 按键 快捷键 键盘操作
演示时钟 模拟时间 演示时间 初始时间 时钟 初始日期
浏览器会话 工作区隔离 会话隔离 各自独立 数据隔离 不同浏览器 另一个浏览器 独立的数据
短信 手机通知 文字短信 发短信
并发 同时登记 同时抢号 抢最后 一个席位 单席 最后一席
回滚 整批撤销 撤回事务 整批失败 原子性
事务 事务性 原子写入
输入文件 样例文件 样本文件 输入路径 文件目录 文件位置
重复 再次 相同 重复导入 重新导入 重传 重跑 重导 重新上传 再传 同一份 一模一样 同样 同一批次 复用
批次 新建批次 开新批次 多一批 另开一批 原批次
复核 人工核查 审核 复审 对账记录 审查 核查
更正 修改结论 修订 追加版本 改错 修改意见 改备注 改结论
历史 之前的记录 上次记录 保留下来 之前填写 过去的 旧记录 留痕
原始行 源行 来源行 原始字段 CSV行 第几行 行号
金额不符 金额差异 差额 差了多少钱 相差 金额不一致
格式 表头 列名 字段名称 有哪些列 哪些字段 三列 模板
上传限制 上限 限额 最大 最大多少 最多 限制 多少行 文件大小 容量上限 多大 几兆
编码 字符集 乱码 BOM GB18030 UTF-8
前导零 开头的零 开头的0 前面的零 保留零 前置零 几个零 变成数字
类型 收退款 收款 退款
复合键 核对键 匹配键 关联键 配对 配对依据 按什么匹配 对账主键
重复键 同一键 多次出现 一单多笔 重复单号 单号重复
无效记录 坏行 错误行 非法数据 单行错误
币种 多币种 外币 货币 币别 跨币种
认证 登录 登陆 账号 身份校验 身份验证
署名 签名 签字 复核人 经办人
团队分派 分配给同事 分派 协作 分工 协同
导出 输出报告 下载报告 报告下载
公式 电子表格 转义 excel Excel
健康接口 健康检查 探针 探测 健康状态 服务状态 排队数 health
重启 重新启动 掉电 中断 故障恢复 重新处理 服务重启
清除 删除源文件 清理 清空 留存 移除
端口 port 监听地址 本机回环 回环地址 localhost
数据库 sqlite 持久化 落盘 存储
启动 本地运行 本机运行 本机打开 运行起来 安装 运行命令 开起来
依赖 标准库 库依赖 第三方库 Python环境 解释器
测试 自动化测试 用例 回归 验证 unittest
图片 配图 摄影 照片 插图 人物
字体 字型 字库 许可 字体许可
源码 代码 仓库 作者 开发者
""".strip()


def normalize(text):
    return unicodedata.normalize("NFKC", text).casefold()


GROUPS = [tuple(dict.fromkeys(normalize(line).split())) for line in VOCABULARY.splitlines()]
GROUP_PATTERNS = [(f"@{index}", re.compile("|".join(re.escape(alias) for alias in
                                             sorted(group, key=len, reverse=True))))
                  for index, group in enumerate(GROUPS)]
LEXEMES = re.compile(r"[a-z0-9]+(?:[._/-][a-z0-9]+)*|[\u3400-\u9fff]+")
FILLER = re.compile("请问一下|我想知道|能不能告诉我|可不可以告诉我|麻烦帮我|能不能|可不可以|"
                    "是什么|该怎么|需要怎么|怎么办|怎么样|如何|为什么|为什么会|请问|能否|是否|可以|"
                    "这个|那个|应该|我的|我们|我想|时候|的话|一下|里面|具体|怎么|什么|哪些|哪个|"
                    "我要|我能|有没有|帮我|怎样|当前|支持不支持|支持|能用|允许|会把|到底|手册|工作台|系统")
NOISE = set("一个 这个 如果 可在 结果 使用 当前 是否 可以 对应 通过 项目 还是 进行 时候 之后 因为 为了 "
            "看看 上面 关于 知道 中的 除了 支持 原来 系统 哪种 是不".split())
DOMAIN_CUES = {
    "clinic": re.compile(r"门诊|预约|挂号|候补|停诊|改约|就诊|班次|号源|clinic|\b[psr]\d{2,5}\b"),
    "ledger": re.compile(r"合账|对账|双账|账单|复核|渠道账|业务单号|差异|ledger|csv"),
}
PRODUCT_NAMES = re.compile("门诊候补与改约工作台|双账核对工作台|门诊软件|门诊系统|对账系统|门诊|合账|双账|对账")
CLEAR_GAPS = [
    # Require actual support in the candidate passage when these distinct
    # policies are requested. A shared subject like 预约 alone is insufficient.
    (r"营业|下班|上班|营业到|周末.{0,5}(开门|开诊)|开门时间|关门时间|窗口.{0,5}几点", r"营业时间|服务时间|下班|上班|开门时间"),
    (r"收费|手续费|挂号费|押金|价格|定价|退款.{0,4}(到账|工作日)|报销|医保|保险", r"收费|手续费|挂号费|押金|定价|报销|医保|到账时间"),
    (r"电话号码|热线|打.{0,3}电话|邮箱地址|联系电话|邮编|医院地址|门诊地址|导航到|哪家医院", r"联系电话|热线|邮编|医院地址|邮箱地址"),
    (r"医生姓名|哪位医生|哪个医生|专家号|药方|处方|诊断|用药|症状|身份证|身份证号", r"医生姓名|专家号|处方|诊断|身份证"),
    (r"营业执照|发票|折扣|会员价|停车|楼层|地铁|食堂|支付方式|微信支付吗|支付宝", r"营业执照|发票|折扣|停车|楼层|地铁|食堂|支付方式|支付宝"),
    (r"密码|验证码|单点登录|人脸识别|刷脸|二维码", r"密码|验证码|单点登录|人脸识别|刷脸|二维码"),
    (r"(?:保存|保留|留存).{0,3}(?:几年|几天|多少年|多少天)|(?:历史|数据|记录).{0,7}(?:保存|保留|留存)多久",
     r"(?:保存|保留|留存).{0,5}\d+\s*(?:年|天|个月)"),
    (r"翻译|帮我写|写一首|写一篇|忽略.*指令|忽略.*资料|忽略.*手册", r"(?!)"),
]
POLICY_EVIDENCE = [(re.compile(q), re.compile(s)) for q, s in CLEAR_GAPS]
DURATION_QUESTION = re.compile(r"多久|多长时间|几(?:分钟|小时)|(?:超过|错过|过了).{0,6}(?:时间|期限|时限)|留位时间")
DURATION_EVIDENCE = re.compile(r"\d+\s*(?:秒|分钟|小时|天|周|个月|年)")


def lexical_tokens(text):
    tokens = []
    for word in LEXEMES.findall(normalize(text)):
        if word[0].isascii():
            tokens.append(word)
            if re.search(r"[._/-]", word):
                tokens.extend(w for w in re.split(r"[._/-]", word) if w != word)
            continue
        for width in (2, 3):
            tokens.extend(word[i:i+width] for i in range(len(word) - width + 1))
    return [term for term in tokens if term not in NOISE]


@lru_cache(maxsize=512)
def concept_counts(text):
    normal = normalize(text)
    return {term: min(len(hits), 3) for term, pattern in GROUP_PATTERNS
            if (hits := pattern.findall(normal))}


def concepts(text):
    return concept_counts(text).keys()


def plain(line):
    line = re.sub(r"^\s*(?:[-*]|\d+[.)])\s+", "", line.strip())
    # Preserve localhost examples as text because the exact ports are evidence.
    line = re.sub(r"\[([^\]]+)\]\((https?://127\.0\.0\.1[^)]*)\)", r"\1（\2）", line)
    line = re.sub(r"\[([^\]]+)\]\([^)]+\)", r"\1", line)
    return line.replace("**", "").replace("`", "").strip()


def document_url(project):
    _, repo, _, commit = SOURCES[project]
    return f"https://github.com/fate788/{repo}/blob/{commit}/README.md"


@dataclass(frozen=True)
class Passage:
    project: str
    chapter: str
    start: int
    end: int
    text: str

    def public(self, snippet=None, score=None):
        document, _, version, commit = SOURCES[self.project]
        lines = f"L{self.start}" if self.start == self.end else f"L{self.start}-L{self.end}"
        result = dict(id=f"{self.project}-L{self.start}", project=self.project, document=document,
                      title=self.chapter, text=self.text, start=self.start, end=self.end,
                      url=f"{document_url(self.project)}?plain=1#{lines}", version=version, commit=commit,
                      snippet=snippet or self.text)
        if score is not None:
            result["score"] = round(score, 3)
        return result


@dataclass(frozen=True)
class TeamPassage(Passage):
    document: str
    revision: int
    source_url: str

    def public(self, snippet=None, score=None):
        version = f"v{self.revision}"
        row = dict(id=f"{self.project}-{version}-L{self.start}", project=self.project,
                   document=self.document, title=self.chapter, text=self.text,
                   start=self.start, end=self.end, version=version, revision=self.revision,
                   kind="team", url=self.source_url, sourceUrl=self.source_url,
                   snippet=snippet or self.text)
        if score is not None:
            row["score"] = round(score, 3)
        return row


def read_passages(project):
    lines = (CORPUS / f"{project}.md").read_text(encoding="utf-8").splitlines()
    chapter = "项目介绍"
    covered = 0
    for number, line in enumerate(lines, 1):
        if number <= covered:
            continue
        if line.startswith("## "):
            chapter = line[3:].strip()
        elif line.startswith("# ") or not line.strip() or line.startswith(("![", "```")):
            continue
        else:
            body = plain(line)
            covered = number
            # Keep a paragraph introducing a command together with its fenced
            # example so an instruction can never cite an empty lead-in.
            if number + 1 < len(lines) and not lines[number].strip() and lines[number + 1].startswith("```"):
                stop = next((i for i in range(number + 2, len(lines)) if lines[i].startswith("```")), None)
                if stop is not None:
                    body += "\n" + "\n".join(lines[number + 2:stop])
                    covered = stop + 1
            yield Passage(project, chapter, number, covered, body)


def terms_for(text, enhanced):
    counts = Counter(lexical_tokens(text))
    if enhanced:
        counts.update(concept_counts(text))
    return counts


@lru_cache(maxsize=2)
def index(enhanced):
    passages = [p for project in SOURCES for p in read_passages(project)]
    return build_index(passages, enhanced)


def build_index(passages, enhanced):
    vectors = []
    for p in passages:
        vector = terms_for(p.text, enhanced)
        if enhanced:
            for term in terms_for(p.chapter, True):
                vector[term] += 0.22
        vectors.append(vector)
    frequency = Counter(term for vector in vectors for term in vector)
    idf = {term: log(1 + (len(vectors) - n + 0.5) / (n + 0.5)) for term, n in frequency.items()}
    lengths = [sum(vector.values()) for vector in vectors]
    mean = sum(lengths) / len(lengths)
    return passages, vectors, idf, [0.65 + 0.35 * n / mean for n in lengths]


@lru_cache(maxsize=2)
def workspace_index(additions, enhanced):
    return build_index([*index(enhanced)[0], *additions], enhanced)


def get_sections():
    return [p.public() for p in index(True)[0]]


def get_documents():
    counts = Counter(p.project for p in index(True)[0])
    return [dict(id=key, project=key, document=name, name=name, title=name, version=version,
                 commit=commit, url=document_url(key), sections=counts[key])
            for key, (name, _, version, commit) in SOURCES.items()]


def term_weight(term):
    if term.startswith("@"):
        return 4.3
    return 1.2 if term.isascii() else 0.7 if len(term) > 2 else 1.


def excerpt(passage, weights):
    sentences = [s for s in re.split(r"(?<=[。！？；])", passage.text) if s.strip()]
    # Short paragraphs often put the appointment ID in one sentence and its
    # time or amount in the next one. Cite the compact, complete procedure.
    if len(sentences) <= 3 and len(passage.text) <= 120:
        return passage.text
    scores = [sum(weights[t] * (1 + 0.2 * min(n - 1, 2)) for t, n in terms_for(s, True).items()
                  if t in weights) for s in sentences]
    hot = max(range(len(scores)), key=scores.__getitem__)
    # A procedure's next sentence often states what happens after the action.
    # Keep the immediate consequence and, when useful, its preceding condition.
    left = hot - 1 if hot and scores[hot - 1] >= 0.38 * scores[hot] else hot
    right = hot + 1
    if right < len(scores) and (scores[right] >= scores[hot] * 0.2 or
                                "以下命令" in sentences[hot] or len(sentences[hot]) <= 12 or
                                sentences[right].startswith(("把演示时钟", "到期", "系统没有"))):
        right += 1
    return "".join(sentences[left:right]).strip()


def scope_for(question, project):
    if project != "all":
        return {project}
    cues = {p for p, pattern in DOMAIN_CUES.items() if pattern.search(normalize(question))}
    return cues or set(SOURCES)


QUANTITY = re.compile(r"(?:几|多少)\s*(?:个)?\s*(工作日|自然日|小时|分钟|秒|天|周|月|年|次|台|份|元|人|页|字节)")
NUMBER = r"(?:\d+(?:\.\d+)?|[零一二两三四五六七八九十百千万半]+)\s*个?\s*"


def lacks_quantity(question, text):
    return any(not re.search(NUMBER + unit, text) for unit in QUANTITY.findall(question))


def related_evidence(question, section):
    """Cheap guard against selecting a different subject; the final review is human."""
    query = normalize(question)
    text = normalize(section["text"] + " " + section["title"])
    if (lacks_quantity(query, text) or
            any(request.search(query) and not needed.search(text) for request, needed in POLICY_EVIDENCE)):
        return False
    terms = set(terms_for(FILLER.sub(" ", PRODUCT_NAMES.sub(" ", query)), True))
    common = terms & set(terms_for(text, True))
    return bool(common) and (len(common) >= 2 or any(t.isascii() or len(t) >= 3 for t in common))


def missing_evidence(question, passage):
    text = normalize(passage.chapter + " " + passage.text if isinstance(passage, TeamPassage) else passage.text)
    if isinstance(passage, TeamPassage) and lacks_quantity(question, text):
        return True
    if any(request.search(question) and not needed.search(text) for request, needed in POLICY_EVIDENCE):
        return True
    # Unknown exact record identifiers or software/format names should not be
    # replaced silently with a nearby example or an unrelated technology.
    identifiers = re.findall(r"(?<![a-z0-9])(?:[psr]\d{2,6}|[a-z]{2,}[a-z0-9]*(?:[-_.][a-z0-9]+)*)\b", question, re.ASCII)
    common = {"readme", "clinic", "ledger", "app", "web", "id", "ai"}
    if any(token not in common and token not in text and not (concepts(token) & concepts(text)) for token in identifiers):
        return True
    versions = re.findall(r"\bv\d+(?:\.\d+)+", question, re.ASCII)
    edition = f"v{passage.revision}" if isinstance(passage, TeamPassage) else SOURCES[passage.project][2]
    if any(v != edition for v in versions):
        return True
    if re.search(r"(?:今天|明天|后天|本周|下周|\d{1,2}月\d{1,2}[日号]).{0,15}(?:还有号|有无号|能挂号|剩几个号|有空位|还能挂)", question):
        return True
    return False


def rank(query, scope, enhanced, search_index):
    passages, vectors, idf, norms = search_index
    content_query = FILLER.sub(" ", PRODUCT_NAMES.sub(" ", query)) if enhanced else query
    tokens = terms_for(content_query, enhanced)
    weights = {t: term_weight(t) * idf[t] for t in tokens if t in idf}
    query_concepts = {t for t in weights if t.startswith("@")}
    # Unknown terms reduce evidence coverage rather than contributing scores.
    total = sum(weights.values()) + sum(0.7 for t in tokens if t not in idf)
    ranking = []
    for passage, vector, norm in zip(passages, vectors, norms):
        if passage.project not in scope:
            continue
        overlap = vector.keys() & weights.keys()
        if not overlap:
            continue
        raw = sum(weights[t] * (2.2 * vector[t]) / (vector[t] + 1.2 * norm) for t in overlap)
        coverage = sum(weights[t] for t in overlap) / max(total, 1)
        score = raw * (0.65 + 0.35 * coverage) if enhanced else raw
        if query_concepts:
            score *= 0.4 + 0.6 * len(query_concepts & overlap) / len(query_concepts)
        if enhanced and DURATION_QUESTION.search(query):
            # Numeric deadlines take precedence over implementation passages
            # that merely mention the same entity (e.g. a reserved slot).
            score *= 1.35 if DURATION_EVIDENCE.search(passage.text) else 0.75
        ranking.append((score, coverage, passage, overlap))
    ranking.sort(key=lambda hit: -hit[0])
    return [(p.public(excerpt(p, weights), score), coverage, p, overlap)
            for score, coverage, p, overlap in ranking[:3]]


def supported(query, hit):
    row, coverage, passage, overlap = hit
    if missing_evidence(query, passage) or row["score"] < 2.15 or coverage < 0.22:
        return False
    return (any(t.startswith("@") or t.isascii() or len(t) >= 3 for t in overlap)
            or len(overlap) > 1 or coverage >= 0.68)


def search(question, project="all", method="hybrid", additions=()):
    """Return up to three ranked references and an independently gated answer."""
    if not isinstance(question, str):
        raise ValueError("问题必须是文本")
    added_projects = {p.project for p in additions}
    if project not in {*SOURCES, *added_projects, "all"}:
        raise ValueError("未知手册")
    if method == "keyword":
        method = "baseline"
    if method not in {"baseline", "hybrid"}:
        raise ValueError("未知检索方式")
    enhanced = method == "hybrid"
    query = normalize(question.strip())
    scope = scope_for(query, project) if enhanced else (set(SOURCES) if project == "all" else {project})
    if project == "all":
        scope.update(added_projects)
    search_index = workspace_index(tuple(additions), enhanced) if additions else index(enhanced)
    top = rank(query, scope, enhanced, search_index)
    result = dict(method=method, status="insufficient", answer="所查手册没有提供足以回答这个问题的原文。",
                  citations=[], results=[row for row, _, _, _ in top])
    if not top:
        return result
    if not supported(query, top[0]) or (additions and lacks_quantity(query, top[0][2].text)):
        return result
    citations = [top[0][0]]
    if enhanced:
        # Separate questions can have separate supporting paragraphs. Keep the
        # full-query result for short qualifiers and dependent follow-ups.
        clauses = [c.strip() for c in re.split(r"[?？；;，,]|另外|以及", query)
                   if re.search("谁|几|多|怎么|如何|吗|会|能|是否|哪些|什么|超时|能否", c)]
        if 2 <= len(clauses) <= 3:
            distinct = {}
            for clause in clauses:
                hits = rank(clause, scope, enhanced, search_index)
                if (not hits or not supported(clause, hits[0]) or hits[0][1] < 0.28 or
                        additions and lacks_quantity(clause, hits[0][2].text)):
                    break
                row = hits[0][0]
                distinct[row["id"]] = row
            else:
                covered = concepts(citations[0]["text"])
                novel = any((concepts(clause) - covered) & concepts(row["text"])
                            for clause in clauses for row in distinct.values())
                if len(distinct) > 1 and novel:
                    citations = list(distinct.values())
                    items = {r["id"]: r for r in [*citations, *result["results"]]}
                    result["results"] = list(items.values())[:3]
    result.update(status="answered", answer="\n".join(row["snippet"] for row in citations), citations=citations)
    return result
