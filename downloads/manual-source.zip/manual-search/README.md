# 手册检索室

面向一线支持人员与知识库维护者的工作台。处理咨询时，查现行手册并复制带出处的答复。材料缺了一条，就登记待补问题；补写并发布手册后，把具体条款关联到原问题，再将处理清单交给下一班。

[在线体验支持工作台](https://fate788.github.io/personal-blog/demos/manual/) · [博客项目页](https://fate788.github.io/personal-blog/#project/manual)

![支持工作台](docs/preview.webp)

## 选择工作区

| 入口 | 数据保存 | 回答方式 |
| --- | --- | --- |
| 在线体验 / 下载的单文件 HTML | 当前浏览器的工作区；刷新后可继续，同事各自拥有独立数据 | 本地检索与原文摘录 |
| Python 服务 | SQLite 保存团队手册版本和问题处理记录。默认在本机使用，也可用 `--db` 指定数据文件 | 原文摘录，可接本地语言模型 |

公开体验收录门诊和双账两份固定版本的项目手册。导入表单还提供一份可编辑的虚构 IT 设备借用手册，便于走完整个支持流程。团队可以替换为自己的资料。

Python 版按服务实例共享一个工作区，权限边界是该实例的访问范围。在企业内网提供给多位同事时，可通过团队已有的身份网关控制访问。公开浏览器版的手册和问题保存在当前浏览器，下载离线 HTML 得到的是应用和内置样例；交接处理记录可用清单导出。

## 运行

需要 Python 3.10 或更新版本。在项目根目录执行以下命令；Windows 也可双击 `start-manual.cmd`。

```shell
python server.py
```

打开[本机手册检索室](http://127.0.0.1:8799/)。标准库服务直接提供前端、自由检索、原文摘录和评测报告。内置手册随包保存，查询和日常维护可离线使用。服务默认监听本机，支持 `--port` 选择其他端口。

**启用本地模型。** Windows x64 可在同一目录运行下面的命令，作为上述启动命令的替代。首次会从项目官方地址下载约 1.16 GB 文件，校验 SHA-256 后保存在项目下的 `.model-cache`。后续运行复用缓存。

```shell
python run_with_model.py
```

启动器采用 Qwen2.5-1.5B-Instruct 的 Q4_K_M 权重和 llama.cpp b12810。已在 Windows x64 的 Vulkan 环境运行。其他平台如已运行兼容的本机模型服务，可使用 `python server.py --model-url http://127.0.0.1:8819/v1 --model-name 模型名称`。模型使用聊天补全和 JSON 对象输出接口。[Qwen 官方权重](https://huggingface.co/Qwen/Qwen2.5-1.5B-Instruct-GGUF) · [llama.cpp 官方发行包](https://github.com/ggml-org/llama.cpp/releases/tag/b12810)

## 五分钟体验一次真实的知识维护流程

1. 在支持工作台进入「导入手册」，选用设备借用示例，发布初版。也可以导入自己的 Markdown、TXT 文件或粘贴正文。
2. 限定这本手册，问「备用电脑每次续借最多能延长几个工作日？」。初版只有申领和归还条款，登记待补问题。
3. 打开同一本手册发布修订，填入示例新版，核对新增的「续借期限」后发布。
4. 回到待补问题，选择新版中说明“三个工作日”的条款，复核后结案。重新提问，查到新条款后复制答复和出处。
5. 在手册库切回初版查看当时的正文；在问题清单查看已解决记录，并按当前筛选导出 CSV。

## 工作流设计

把支持请求与知识文章放在同一处理流程，是 Jira Service Management 和 Zendesk 文档中可见的做法。这一版将其落在具体的三步操作上：支持人员记录缺口，维护人员补充原文，最终的处理记录保留条款及版本。[Jira Service Management 服务台资源](https://support.atlassian.com/jira-service-management-cloud/docs/what-are-help-resources/) · [Zendesk 知识反馈](https://support.zendesk.com/hc/en-us/articles/4408826160922-Flagging-articles-for-updates-while-working-on-tickets)

## 实现

- `knowledge_store.py` 保存发布版本与待补问题。答复引用段落所属版本，修订后仍可打开原段。更新提交时核对预期版本号，避免旧页面覆盖刚发布的内容。
- `portable/` 构建单文件浏览器版，复用同一套界面。执行 `python portable/build.py --output dist/manual/index.html` 可生成一个可下载、可离线打开的工作台。

- `corpus/` 固定了两个项目的 README 快照。按小节、列表项和连贯的代码段建立 32 个可引用片段。每段使用 Git 提交、文档和行号定位。
- `engine.py` 提供中文关键词基线以及术语归一、项目范围、覆盖度和证据检查。输入时实时检索。术语扩展使用本地规则，两份手册都可离线查询。
- `model_answer.py` 把候选段落拆成原句，让模型按问题挑选和组织句子。后端校验返回的编号，再从对应段落提取原句。前端区分模型整理与原文摘录；遇到模型繁忙、服务不可用或无效输出时仍可查阅依据。
- `static/` 支持直接打开某个问题、指定版本的段落或评测案例。`GET /api/documents` 列出内置和团队手册，`POST /api/documents` 导入手册或发布新版。`POST /api/ask` 接受 `question` 和可选的 `project`，可传 `all` 或列表中的手册标识。`GET /api/gaps` 查看问题清单，`POST /api/gaps/{id}/resolve` 关联条款并结案。

## 内置手册的固定检索评测

这组结果针对两本内置手册及离线检索。先冻结 30 道题及所需原文位置，再分别运行两个检索方法。若问题需要多个段落，前三个结果须共同覆盖全部必要位置才算命中。

| 项目 | 本版本结果 |
| --- | --- |
| 22 道可答题，前三个结果找全所需依据 | 基线 20/22，改进检索 21/22 |
| 22 道可答题，离线答复覆盖全部要点 | 16/22，另有 3 道误判为资料不足 |
| 8 道资料缺失题，正确提示依据不足 | 6/8 |
| 8 题本机模型抽查 | 6 道可答中 3 道答全，2 道资料缺失中 1 道正确拒答 |

引用原句可以核验，但仍会有与问题无关或缺少条件的答复。详细记录按题列出问题、排名、答复和独立 AI 复核意见。还没有真人试用耗时数据。[评测方法](evaluation/README.md) · [逐题数据](evaluation/report.json) · [模型实际输出](evaluation/model-check.md)

```shell
python -B -m unittest discover -s tests -v
python -B evaluation/run.py --check
node --test tests/support-actions.test.cjs
```
