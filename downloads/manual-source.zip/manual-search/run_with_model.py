"""Run the Windows x64 preview with verified, project-local Qwen and llama.cpp files."""
import argparse
from hashlib import sha256
import json
from pathlib import Path
import platform
import subprocess
import sys
from tempfile import TemporaryDirectory
import time
from urllib.error import URLError
from urllib.request import Request, urlopen
from zipfile import ZipFile

from server import serve

MODEL = "Qwen2.5-1.5B-Instruct"
FILE = "qwen2.5-1.5b-instruct-q4_k_m.gguf"
REVISION = "91cad51170dc346986eccefdc2dd33a9da36ead9"
WEIGHTS = f"https://huggingface.co/Qwen/Qwen2.5-1.5B-Instruct-GGUF/resolve/{REVISION}/{FILE}?download=true"
RUNTIME = "https://github.com/ggml-org/llama.cpp/releases/download/b12810/llama-b12810-bin-win-vulkan-x64.zip"
WEIGHT_DIGEST = "6a1a2eb6d15622bf3c96857206351ba97e1af16c30d7a74ee38970e434e9407e"
RUNTIME_DIGEST = "134e518ee19a7c9d27b478a0d0817ce4e5f11b4f0d4f721dee8cbde2fc8017ee"


def file_digest(file):
    digest = sha256()
    with file.open("rb") as source:
        for block in iter(lambda: source.read(1024*1024), b""):
            digest.update(block)
    return digest.hexdigest()


def fetch(folder, name, url, checksum):
    target = folder / name
    if target.is_file() and file_digest(target) == checksum:
        return target
    print("下载并校验", name, flush=True)
    with TemporaryDirectory(dir=folder) as staging:
        partial = Path(staging) / name
        request = Request(url, headers={"User-Agent":"manual-search/1.0"})
        with urlopen(request, timeout=90) as response, partial.open("wb") as dest:
            for block in iter(lambda: response.read(1024*1024), b""):
                dest.write(block)
        if file_digest(partial) != checksum:
            raise ValueError(f"{name} 校验失败，请重新运行。")
        partial.replace(target)
    return target


def main():
    parser = argparse.ArgumentParser(description="启用本机模型。首次下载约 1.16 GB，后续可离线使用。")
    parser.add_argument("--cache", type=Path, default=Path(__file__).resolve().parent / ".model-cache")
    parser.add_argument("--port", type=int, default=8799)
    parser.add_argument("--model-port", type=int, default=8819)
    args = parser.parse_args()
    if sys.platform != "win32" or platform.machine().lower() not in {"amd64","x86_64"}:
        parser.error("自动安装适用于 Windows x64；其他系统可向 server.py 传入已有模型服务地址。")
    folder = args.cache.resolve()
    folder.mkdir(parents=True, exist_ok=True)
    binary = fetch(folder, "llama-b12810.zip", RUNTIME, RUNTIME_DIGEST)
    weights = fetch(folder, FILE, WEIGHTS, WEIGHT_DIGEST)
    # Each process owns its extracted files, even if a second preview starts concurrently.
    with TemporaryDirectory(dir=folder) as staging:
        with ZipFile(binary) as archive:
            archive.extractall(staging)
        program = next(Path(staging).rglob("llama-server.exe"))
        base = f"http://127.0.0.1:{args.model_port}"
        command = [str(program), "-m", str(weights), "--host", "127.0.0.1", "--port", str(args.model_port),
                   "-c", "4096", "-ngl", "99", "-np", "1", "-a", MODEL, "--no-ui",
                   "--cors-origins", f"http://127.0.0.1:{args.port}"]
        child = subprocess.Popen(command, cwd=program.parent)
        try:
            for _ in range(120):
                if child.poll() is not None:
                    raise RuntimeError("本机模型启动失败，请核对上方输出及端口。")
                try:
                    with urlopen(base+"/health", timeout=1) as response:
                        if json.load(response).get("status") == "ok":
                            break
                except (OSError, URLError):
                    pass
                time.sleep(.5)
            else:
                raise RuntimeError("本机模型尚未就绪，请检查运行环境。")
            serve(args.port, base+"/v1", MODEL)
        finally:
            if child.poll() is None:
                child.terminate()
                child.wait()


if __name__ == "__main__":
    main()
