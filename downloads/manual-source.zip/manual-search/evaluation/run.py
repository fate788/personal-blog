"""Re-run the frozen retrieval benchmark against the two bundled manuals."""

import argparse
import hashlib
import json
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))

from engine import search


FROZEN = "73352c796fc118c47f8fc509d056d032622a26a3ab835e72d276e4ed9934d8c2"
DEFAULT_REPORT = HERE / "report.json"


def digest(data):
    return hashlib.sha256(data).hexdigest()


def read_cases():
    data = (HERE / "cases.json").read_text(encoding="utf-8").encode("utf-8")
    if digest(data) != FROZEN:
        raise ValueError("验收题或金标准的内容已改变。请为新题集另建版本。")
    return json.loads(data)


def anchored(item, gold, versions):
    project, number = gold.split(":")
    return (
        item["project"] == project
        and versions[project] in item["url"]
        and item["start"] <= int(number) <= item["end"]
    )


def hit(groups, matches, versions):
    return all(
        any(anchored(item, anchor, versions) for item in matches for anchor in alternatives)
        for alternatives in groups
    )


def reference(item):
    return {key: item[key] for key in ("id", "project", "document", "title", "start", "end", "url", "text")}


def short_refs(items):
    return "、".join(
        f"{'门诊' if item['project'] == 'clinic' else '双账'} L{item['start']}"
        + (f"–{item['end']}" if item['end'] != item['start'] else "")
        for item in items
    )


def run_case(case, versions, reviews):
    results = {
        method: search(case["question"], project=case["project"], method=method)
        for method in ("baseline", "hybrid")
    }
    hybrid = results["hybrid"]
    groups = case["groups"]
    citations = [reference(item) for item in hybrid["citations"]]
    captured = {"status": hybrid["status"], "answer": hybrid["answer"], "citations": citations}
    # Any change in the answer, source text or source location invalidates that review.
    review_key = digest(json.dumps(captured, ensure_ascii=False, sort_keys=True).encode("utf-8"))
    review = reviews.get(case["id"], {})
    if review.get("digest") != review_key:
        review = {}
    rankings = {
        method: [reference(item) for item in result["results"][:3]]
        for method, result in results.items()
    }
    return {
        "id": case["id"],
        "question": case["question"],
        "type": case["type"],
        "project": case["project"],
        "answerable": bool(groups),
        "expected": case["expected"],
        "expectedGroups": groups,
        "baselineHit": hit(groups, rankings["baseline"], versions) if groups else None,
        "hybridHit": hit(groups, rankings["hybrid"], versions) if groups else None,
        "baselineRanked": short_refs(rankings["baseline"]),
        "hybridRanked": short_refs(rankings["hybrid"]),
        "status": captured["status"],
        "answer": captured["answer"],
        "cited": short_refs(citations),
        "citations": citations,
        "evidenceHit": hit(groups, citations, versions) if groups else None,
        "reviewDigest": review_key,
        "citationSupport": review.get("citationSupport"),
        "answerQuality": review.get("answerQuality", "pending"),
        "review": review.get("note", "该版本输出尚未逐题复核。"),
    }


def evaluate():
    dataset = read_cases()
    path = HERE / "reviews.json"
    reviews = json.loads(path.read_text(encoding="utf-8")) if path.is_file() else {}
    cases = [run_case(case, dataset["versions"], reviews) for case in dataset["cases"]]
    known = [case for case in cases if case["answerable"]]
    unknown = [case for case in cases if not case["answerable"]]
    summary = {}
    for method in ("baseline", "hybrid"):
        summary[method] = {"hits": sum(case[method + "Hit"] for case in known), "answerable": len(known)}
    summary.update({
        "unanswerable": len(unknown),
        "abstentions": sum(case["status"] == "insufficient" for case in unknown),
        "falseAbstentions": sum(case["status"] == "insufficient" for case in known),
        "citationEvaluated": sum(case["citationSupport"] is not None for case in cases),
        "citationSupported": sum(case["citationSupport"] is True for case in cases),
        "reviewed": sum(case["answerQuality"] != "pending" for case in cases),
        "fullyAnswered": sum(case["answerable"] and case["answerQuality"] == "complete" for case in cases),
        "improvements": [case["id"] for case in known if case["hybridHit"] and not case["baselineHit"]],
        "regressions": [case["id"] for case in known if case["baselineHit"] and not case["hybridHit"]],
    })
    return {
        "dataset": "手册检索室 · 固定 30 题",
        "datasetSHA256": FROZEN,
        "versions": dataset["versions"],
        "protocol": "前三项必须合在一起覆盖该题的所有必要原文位置。一个位置有等价段落时，命中任一处即可。引用支持为按回答计数的独立 AI 复核：有引用的回答中，每项事实均可由引用推出才记通过。回答完整度另计。未做真人用时测试。本报告评测离线检索与摘录。",
        "summary": summary,
        "cases": cases,
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=DEFAULT_REPORT)
    parser.add_argument("--check", action="store_true", help="Compare a fresh run with the saved report.")
    args = parser.parse_args()
    report = evaluate()
    if args.check:
        if json.loads(args.output.read_text(encoding="utf-8")) != report:
            parser.exit(1, "当前检索行为或逐题复核与已发布报告不一致。\n")
    else:
        args.output.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report["summary"], ensure_ascii=False))


if __name__ == "__main__":
    main()
