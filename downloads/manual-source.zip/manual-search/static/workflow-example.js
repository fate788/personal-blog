"use strict";

// Illustrative workplace policy, editable before an operator publishes it.
(() => {
  const title = "IT 服务台 · 备用设备借用手册";
  const initial = `# 备用设备借用

本手册用于体验内部 IT 服务台的设备借还流程，条款为虚构示例。

## 申请备用电脑
工作电脑送修期间，员工可以向 IT 服务台提交备用电脑借用申请。申请需填写设备资产编号、维修工单号和预计归还日期。

## 领取与归还
领取时由服务台登记设备序列号、充电器和接收人。归还时双方核对配件，由服务台关闭借用记录。
`;
  const updated = initial + `
## 续借期限
备用电脑每次续借最多可延长三个工作日。请在约定归还时间前提交原借用记录编号，由 IT 服务台确认新的归还日期。
`;
  window.manualWorkflowExample = Object.freeze({
    title, initial, updated, question: "备用电脑每次续借最多能延长几个工作日？"
  });
})();
