"use strict";

const $ = id => document.getElementById(id);
const projects = {all:"全部手册", clinic:"门诊", ledger:"双账"};
const samples = [
  ["clinic", "候补排到我之后，能留多久？错过了怎么办？"],
  ["ledger", "再次运行同一份样例账单，还能看到原来的复核记录吗？"],
  ["clinic", "预约窗口周末几点下班？"]
];
let library;
let report;
let askRequest;
let lastAnswer;
let revision = 0;
let previousView = "";
let focusResult = false;
let focusFilter = false;

function esc(value) {
  return String(value ?? "").replace(/[&<>"']/g, char => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[char]));
}
function githubLink(url, label, className = "source-link") {
  try {
    const link = new URL(url);
    if (link.protocol === "https:" && link.hostname === "github.com") {
      return '<a class="'+className+'" href="'+esc(link.href)+'" target="_blank" rel="noopener">'+esc(label)+' ↗</a>';
    }
  } catch { /* A local excerpt is still available when there is no external URL. */ }
  return "";
}
function readLink(project, id) {
  return "#read/"+encodeURIComponent(project)+(id ? "/"+encodeURIComponent(id) : "");
}
function lineRange(section) {
  return section.start === section.end ? "第 "+section.start+" 行" : "第 "+section.start+"–"+section.end+" 行";
}
function documentName(section) {
  return section.document || projects[section.project] || section.project;
}
function feedback(text, retry) {
  return '<p class="feedback" role="status">'+esc(text)+(retry ? ' <button type="button" class="text-action" data-retry>重试</button>' : "")+'</p>';
}
async function api(url, options) {
  const response = await fetch(url, options);
  if (!response.ok) {
    let message;
    try { message = (await response.json()).error; } catch { /* Fall back to the status code. */ }
    throw new Error(typeof message === "string" ? message : "服务暂时无法响应 ("+response.status+")");
  }
  return response.json();
}
function getLibrary() {
  if (!library) library = api("/api/documents").catch(error => { library = null; throw error; });
  return library;
}
function volume(doc, selected) {
  const revision = String(doc.version || "").slice(0,12);
  const title = esc(doc.title).replace(/工作台$/, '<span class="term">工作台</span>');
  return '<a class="volume '+(doc.id === "ledger" ? "ledger" : "")+'" href="'+esc(readLink(doc.id))+'"'+
    (selected ? ' aria-current="page"' : '')+'><span><b>'+title+'</b><small>README'+
    (revision ? ' · '+esc(revision) : '')+'</small></span></a>';
}
async function updateShelf() {
  try {
    const {documents} = await getLibrary();
    $("shelf").innerHTML = documents.map(doc => volume(doc,false)).join("");
  } catch (error) {
    $("shelf").innerHTML = feedback("目录载入失败。"+error.message, true);
  }
}
function showSamples() {
  $("ask-output").innerHTML = '<div class="block-head"><h2>从常见问题开始</h2></div><div class="sample-grid">'+
    samples.map(([project,question],index) => '<button type="button" class="sample" data-sample="'+index+'">'+
      '<span class="path">'+projects[project]+'手册</span><strong>'+esc(question)+'</strong><i class="arrow" aria-hidden="true"></i></button>').join("")+'</div>'+
    '<div id="chapter-index"></div>';
  getLibrary().then(({documents,sections}) => {
    const container = $("chapter-index");
    if (!container) return;
    const groups = documents.map(doc => {
      const chapters = new Map();
      for (const section of sections.filter(s => s.project === doc.id && s.title !== "项目介绍")) {
        if (!chapters.has(section.title)) chapters.set(section.title,section);
      }
      const items = [...chapters.values()].map(s => '<a href="'+esc(readLink(s.project,s.id))+'">'+
        esc(s.title)+'<span class="meta">L'+esc(s.start)+'</span></a>').join("");
      return '<div class="chapter-group"><h3>'+esc(doc.title)+'</h3><div>'+items+'</div></div>';
    });
    container.innerHTML = '<h2 class="block-label">按章节查阅</h2><div class="chapters">'+groups.join("")+'</div>';
  }).catch(() => { /* The catalogue retry control handles a failed request. */ });
}
function selectedScope() {
  return document.querySelector('.scopes input:checked').value;
}
function setScope(project) {
  document.querySelector('.scopes input[value="'+(Object.hasOwn(projects, project) ? project : "all")+'"]').checked = true;
}
function setQuestion(question, project) {
  $("question").value = question;
  setScope(project);
}
function submitQuestion(question, project) {
  const trimmed = question.trim();
  if (!trimmed) {
    $("question").setCustomValidity("请先输入问题。");
    $("question").reportValidity();
    return;
  }
  const params = new URLSearchParams({q:trimmed, project});
  focusResult = true;
  const hash = "#ask?"+params;
  if (location.hash === hash) { lastAnswer = null; navigate(); }
  else location.hash = hash;
}
function highlighted(section, answer) {
  const text = section.text;
  const fragments = [section.snippet, ...(answer || "").split(/(?<=[。！？])|\n/u)]
    .filter(value => value && value.trim() && value !== text && text.includes(value.trim()))
    .map(value => value.trim());
  const spans = fragments.map(fragment => [text.indexOf(fragment), text.indexOf(fragment)+fragment.length])
    .sort((a,b) => a[0]-b[0] || b[1]-a[1]);
  if (!spans.length) return '<mark>'+esc(text)+'</mark>';
  let pos = 0;
  let html = "";
  for (const [start,end] of spans) {
    if (start < pos) continue;
    html += esc(text.slice(pos,start))+'<mark>'+esc(text.slice(start,end))+'</mark>';
    pos = end;
  }
  return html+esc(text.slice(pos));
}
function sourceCard(section, index, answer) {
  return '<details class="source-box" id="evidence-'+index+'"'+(index === 0 ? " open" : "")+'><summary><span>'+
    esc(section.title)+'<span class="meta">'+esc(documentName(section))+' · '+esc(lineRange(section))+'</span></span></summary>'+
    '<div class="source-body" tabindex="-1"><blockquote>'+highlighted(section,answer)+'</blockquote><div class="source-links">'+
    '<a href="'+esc(readLink(section.project,section.id))+'">在手册中定位 →</a>'+githubLink(section.url,"GitHub 原文")+'</div></div></details>';
}
function otherMatches(sections) {
  if (!sections.length) return "";
  return '<details class="more"><summary>查看其他匹配段落（'+sections.length+'）</summary><ul class="result-list">'+
    sections.map(s => '<li><a href="'+esc(readLink(s.project,s.id))+'">'+esc(s.title)+'</a><span class="meta">'+esc(projects[s.project])+' · '+esc(lineRange(s))+'</span></li>').join("")+'</ul></details>';
}
function drawAnswer(question, result, project) {
  const answered = result.status === "answered";
  const citations = result.citations || [];
  const ids = new Set(citations.map(s => s.id));
  const matches = (result.results || []).filter(s => !ids.has(s.id));
  const links = citations.map((s,index) => '<button type="button" class="cite" data-cite="'+index+'" aria-controls="evidence-'+index+'">原文 '+(index+1)+' · '+esc(lineRange(s))+'</button>').join("");
  const mode = !answered ? "资料未收录" : result.mode === "model" ? "模型整理" : "原文摘录";
  const relevant = Object.keys(projects).filter(key => key !== "all" && (project === "all" || project === key));
  const evidence = answered ? '<h3 class="block-label">引用依据</h3>'+citations.map((s,i) => sourceCard(s,i,result.answer)).join("") :
    '<h3 class="block-label">查询范围</h3><ul class="result-list">'+relevant.map(p => '<li><a href="'+readLink(p)+'">'+projects[p]+'手册 →</a></li>').join("")+'</ul>';
  $("ask-output").innerHTML = '<div class="answer-head"><h2 id="answer-title" tabindex="-1">'+esc(question)+'</h2><a href="#ask" class="text-action">新问题</a></div>'+
    '<div class="answer-grid"><div><div class="mode">'+mode+'</div><p class="answer-text">'+esc(result.answer)+'</p>'+
    (answered && links ? '<div class="citation-links" aria-label="答案出处">'+links+'</div>' : '')+
    (result.modeNote ? '<p class="meta mode-note">'+esc(result.modeNote)+'</p>' : '')+'</div>'+
    '<aside class="evidence" aria-label="'+(answered ? '引用依据' : '查询范围')+'">'+evidence+'</aside></div>'+otherMatches(matches);
  if (focusResult) {
    focusResult = false;
    const heading = $("answer-title");
    heading.focus({preventScroll:true});
    if (heading.getBoundingClientRect().top > innerHeight * .6 || heading.getBoundingClientRect().top < 0) {
      heading.scrollIntoView({block:"start"});
    }
  }
}
async function ask(question, project, current) {
  const key = project+"\n"+question;
  if (lastAnswer?.key === key) {
    drawAnswer(question, lastAnswer.result, project);
    return;
  }
  askRequest = new AbortController();
  $("ask-output").innerHTML = feedback("正在查阅"+projects[project]+"…");
  $("ask-output").setAttribute("aria-busy","true");
  try {
    const result = await api("/api/ask", {method:"POST", headers:{"Content-Type":"application/json"},
      body:JSON.stringify({question, project}), signal:askRequest.signal});
    if (current !== revision) return;
    lastAnswer = {key, result, hash:location.hash};
    drawAnswer(question,result,project);
  } catch (error) {
    if (current === revision && error.name !== "AbortError") {
      $("ask-output").innerHTML = feedback("未能完成查询。"+error.message,true);
    }
  } finally {
    if (current === revision) $("ask-output").removeAttribute("aria-busy");
  }
}
function sectionArticle(section, selected) {
  const linked = lastAnswer?.result.citations.find(s => s.id === section.id);
  const content = selected && linked ? highlighted(linked,lastAnswer.result.answer) : esc(section.text);
  const back = selected && lastAnswer?.hash ? '<a href="'+esc(lastAnswer.hash)+'">← 返回上次提问</a>' : "";
  return '<article class="section-item'+(selected ? " is-linked" : "")+'" aria-label="'+esc(section.title)+'，'+esc(lineRange(section))+'"'+(selected ? ' id="linked-section" tabindex="-1"' : '')+'>'+
    '<a class="meta" href="'+esc(readLink(section.project,section.id))+'" aria-label="段落链接，'+esc(lineRange(section))+'">'+esc(lineRange(section))+'</a>'+
    '<p>'+content+'</p><div class="source-links">'+back+
    '<button type="button" class="copy" data-copy="'+esc(readLink(section.project,section.id))+'">复制链接</button>'+
    githubLink(section.url,"GitHub 原文")+'</div></article>';
}
async function drawReader(project, sectionId, current) {
  $("reader").innerHTML = feedback("正在读取手册…");
  $("read-caption").textContent = "";
  try {
    const {documents,sections} = await getLibrary();
    if (current !== revision) return;
    const doc = documents.find(item => item.id === project) || documents[0];
    if (!doc) { $("reader").innerHTML = feedback("尚未收录文档。"); return; }
    const rows = sections.filter(s => s.project === doc.id);
    const chapters = new Map();
    for (const row of rows) {
      if (!chapters.has(row.title)) chapters.set(row.title,[]);
      chapters.get(row.title).push(row);
    }
    const valid = !sectionId || rows.some(s => s.id === sectionId);
    $("read-caption").textContent = "已收录 "+documents.length+" 份固定版本手册，段落链接可直接保存。";
    const back = lastAnswer?.hash ? '<a href="'+esc(lastAnswer.hash)+'" class="back-answer">← 返回上次提问</a>' : "";
    const toc = '<details class="toc"><summary>本册章节</summary>'+[...chapters.entries()].map(([heading,items]) =>
      '<a href="'+esc(readLink(doc.id,items[0].id))+'">'+esc(heading)+'</a>').join("")+'</details>';
    const chaptersHtml = [...chapters.entries()].map(([heading,items]) => '<section class="manual-chapter"><h3>'+esc(heading)+'</h3>'+
      items.map(s => sectionArticle(s,s.id === sectionId)).join("")+'</section>').join("");
    $("reader").innerHTML = '<div class="lib-layout"><nav class="lib-menu" aria-label="手册导航">'+documents.map(d => volume(d,d === doc)).join("")+toc+back+'</nav>'+
      '<div class="manual"><div class="bar"><h2>'+esc(doc.title)+'</h2>'+githubLink(doc.url,"完整手册")+'</div>'+
      '<p class="doc-version">'+esc(doc.version)+' · '+esc(String(doc.commit || "").slice(0,7))+' · '+chapters.size+' 章</p>'+
      (!valid ? feedback("这条段落链接未收录在当前版本。") : '')+
      chaptersHtml+'</div></div>';
    const target = $("linked-section");
    if (target) { target.focus({preventScroll:true}); target.scrollIntoView({block:"start"}); }
  } catch (error) {
    if (current === revision) $("reader").innerHTML = feedback("手册载入失败。"+error.message,true);
  }
}
function failed(test) {
  if (test.answerable) return !test.hybridHit || test.citationSupport === false || test.evidenceHit === false ||
    !["pending","complete"].includes(test.answerQuality) || test.status === "insufficient";
  return test.status !== "insufficient";
}
function testStatus(test) {
  if (!test.answerable) return test.status === "insufficient" ? "恰当拒答" : "误答";
  if (!test.hybridHit) return "漏检";
  if (test.status === "insufficient") return "未作答";
  if (failed(test)) return "待复核";
  return "命中";
}
function caseRow(test) {
  const method = hit => hit == null ? "不适用" : hit ? "前 3 命中" : "前 3 漏检";
  const row = (label, value) => value ? '<p><b>'+label+'</b>'+esc(value)+'</p>' : "";
  const sources = (test.citations || []).map(s => '<a href="'+esc(readLink(s.project,s.id))+'">'+
    esc(projects[s.project])+' · '+esc(lineRange(s))+' →</a>').join("");
  return '<details class="case"><summary><span class="case-status">'+testStatus(test)+'</span><span>'+esc(test.question)+'</span></summary>'+
    '<div class="case-body">'+row("关键词", method(test.baselineHit))+row("改进检索", method(test.hybridHit))+
    row("关键词返回",test.baselineRanked)+row("改进后返回",test.hybridRanked)+
    row("参考依据",test.expected)+row("返回的答案",test.answer)+
    (sources ? '<div class="source-links">'+sources+'</div>' : "")+row("复核说明",test.review)+
    '<a href="#ask?'+esc(new URLSearchParams({q:test.question,project:Object.hasOwn(projects,test.project) ? test.project : "all"}).toString())+'">在问答中重试 →</a></div></details>';
}
function drawReport(data, filter) {
  const s = data.summary;
  const metrics = [["关键词 · 前三命中",s.baseline.hits,s.baseline.answerable],["改进检索 · 前三命中",s.hybrid.hits,s.hybrid.answerable],
    ["有依据题 · 完整回答",s.fullyAnswered,s.hybrid.answerable],["无依据题 · 恰当拒答",s.abstentions,s.unanswerable]];
  const filters = {all:"全部",missed:"需复查",missing:"无依据题"};
  if (!Object.hasOwn(filters,filter)) filter = "all";
  const rows = data.cases.filter(test => filter === "missed" ? failed(test) : filter === "missing" ? !test.answerable : true);
  $("evaluation").innerHTML = '<div class="metrics">'+metrics.map(([label,x,y]) => '<div class="metric"><small>'+label+'</small><strong>'+esc(x)+' / '+esc(y)+'</strong></div>').join("")+
    '</div><p class="subtle">这组结果评测离线检索与原文摘录。有引用的回答中，'+esc(s.citationSupported)+' / '+esc(s.citationEvaluated)+
    ' 份获原文支持。独立 AI 分别复核引用和回答完整性，有依据的题目中有 '+esc(s.falseAbstentions)+' 题被误判为资料不足。</p>'+
    '<div class="eval-tools"><h2>逐题记录 <span class="meta">'+rows.length+' 题</span></h2><div class="chips" aria-label="筛选评测记录">'+
    Object.entries(filters).map(([value,label]) => '<button type="button" class="chip" data-eval="'+value+'" aria-pressed="'+(value === filter)+'">'+label+'</button>').join("")+'</div></div>'+
    (rows.length ? rows.map(caseRow).join("") : '<p class="feedback">该筛选下没有记录。</p>');
  if (focusFilter) {
    focusFilter = false;
    $("evaluation").querySelector(".chip[aria-pressed=true]")?.focus({preventScroll:true});
  }
}
async function evaluation(filter,current) {
  $("evaluation").innerHTML = feedback("正在读取评测结果…");
  try {
    if (!report) report = await api("/api/evaluation");
    if (current === revision) drawReport(report,filter);
  } catch (error) {
    if (current === revision) $("evaluation").innerHTML = feedback("评测记录载入失败。"+error.message,true);
  }
}
function navigate() {
  const current = ++revision;
  askRequest?.abort();
  $("ask-output").removeAttribute("aria-busy");
  const [path,search = ""] = location.hash.slice(1).split("?");
  let segments;
  try { segments = path.split("/").map(decodeURIComponent); } catch { segments = []; }
  const view = ["ask","read","evaluation"].includes(segments[0]) ? segments[0] : "ask";
  if (view !== previousView) window.scrollTo(0,0);
  previousView = view;
  if (view !== "ask") focusResult = false;
  document.querySelectorAll("[data-nav]").forEach(link => {
    const active = link.dataset.nav === view;
    if (active) link.setAttribute("aria-current","page"); else link.removeAttribute("aria-current");
    $(link.dataset.nav+"-page").hidden = !active;
  });
  document.title = {ask:"手册问答",read:"手册目录",evaluation:"检索评测"}[view]+" · 手册检索室";
  if (view === "read") { drawReader(segments[1],segments[2],current); return; }
  if (view === "evaluation") { evaluation(segments[1] || "all",current); return; }
  const params = new URLSearchParams(search);
  const question = (params.get("q") || "").trim();
  const scope = params.get("project");
  const project = Object.hasOwn(projects,scope) ? scope : "all";
  setQuestion(question,project);
  if (question) ask(question,project,current); else showSamples();
}
$("ask-form").addEventListener("submit", event => {
  event.preventDefault();
  submitQuestion($("question").value, selectedScope());
});
$("question").addEventListener("input", () => $("question").setCustomValidity(""));
$("question").addEventListener("keydown", event => {
  if (event.key === "Enter" && !event.shiftKey && !event.isComposing && event.keyCode !== 229) {
    event.preventDefault();
    $("ask-form").requestSubmit();
  }
});
document.addEventListener("click", event => {
  const target = event.target.closest("button, a");
  if (!target) return;
  if (target.matches(".skip")) { event.preventDefault(); $("main").focus(); return; }
  if (target.hasAttribute("data-sample")) {
    const [project,question] = samples[Number(target.dataset.sample)];
    setQuestion(question,project); submitQuestion(question,project); return;
  }
  if (target.hasAttribute("data-cite")) {
    const details = $(target.getAttribute("aria-controls"));
    details.open = true;
    const excerpt = details.querySelector(".source-body");
    excerpt.focus({preventScroll:true}); excerpt.scrollIntoView({block:"nearest"}); return;
  }
  if (target.hasAttribute("data-copy")) {
    const url = new URL(target.dataset.copy,location.href).href;
    const showCopyField = () => {
      let field = target.closest(".section-item").querySelector(".copy-url");
      if (!field) {
        field = document.createElement("input"); field.type = "url"; field.readOnly = true;
        field.className = "copy-url"; field.setAttribute("aria-label","段落链接，可复制");
        target.closest(".section-item").append(field);
      }
      field.value = url; field.focus(); field.select();
    };
    if (navigator.clipboard) navigator.clipboard.writeText(url).then(() => { target.textContent = "已复制"; }).catch(showCopyField);
    else showCopyField();
    return;
  }
  if (target.hasAttribute("data-eval")) {
    const filter = target.dataset.eval;
    if (target.getAttribute("aria-pressed") === "true") return;
    focusFilter = true;
    location.hash = filter === "all" ? "#evaluation" : "#evaluation/"+filter;
    return;
  }
  if (target.matches('a[href^="#ask?"]')) focusResult = true;
  if (target.hasAttribute("data-retry")) {
    if (target.closest("#shelf")) updateShelf();
    else { lastAnswer = null; navigate(); }
  }
});
window.addEventListener("hashchange",navigate);
updateShelf();
navigate();
