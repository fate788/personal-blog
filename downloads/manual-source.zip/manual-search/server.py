"""Serve the manual collection and search app with Python's standard library."""
import argparse
import json
import mimetypes
import os
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import unquote, urlsplit

from engine import get_documents, get_sections, search
from model_answer import LocalModel

ROOT = Path(__file__).resolve().parent
STATIC = ROOT / "static"


class ManualHandler(BaseHTTPRequestHandler):
    def reply(self, code, body, mime):
        self.send_response(code)
        self.send_header("Content-Type", mime)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-cache")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.end_headers()
        if self.command != "HEAD":
            try:
                self.wfile.write(body)
            except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError):
                pass

    def data(self, value, code=200):
        self.reply(code, json.dumps(value, ensure_ascii=False, allow_nan=False).encode(),
                   "application/json; charset=utf-8")

    def do_HEAD(self):
        self.do_GET()

    def do_GET(self):
        path = unquote(urlsplit(self.path).path)
        if path == "/api/documents":
            self.data({"documents": get_documents(), "sections": get_sections()})
        elif path == "/api/evaluation":
            try:
                report = (ROOT / "evaluation" / "report.json").read_bytes()
            except FileNotFoundError:
                self.data({"error": "评测报告尚未生成。"}, 503)
            else:
                self.reply(200, report, "application/json; charset=utf-8")
        elif path == "/api/health":
            self.data({"status":"ok", "modelConfigured": bool(self.server.model)})
        else:
            if path == "/":
                path = "/index.html"
            file = (STATIC / path.lstrip("/")).resolve()
            if not file.is_relative_to(STATIC) or not file.is_file():
                self.data({"error": "未找到页面。"}, 404)
                return
            mime = mimetypes.guess_type(file.name)[0] or "application/octet-stream"
            if file.suffix == ".js":
                mime = "text/javascript"
            self.reply(200, file.read_bytes(), mime + ("; charset=utf-8" if mime.startswith("text/") else ""))

    def do_POST(self):
        if urlsplit(self.path).path != "/api/ask":
            self.data({"error": "未找到接口。"}, 404)
            return
        if self.headers.get_content_type() != "application/json":
            self.data({"error": "提问需要 JSON 格式。"}, HTTPStatus.UNSUPPORTED_MEDIA_TYPE)
            return
        try:
            size = int(self.headers.get("Content-Length", "0"))
            if not 0 < size <= 8192:
                raise ValueError
            payload = json.loads(self.rfile.read(size))
            if not isinstance(payload, dict):
                raise ValueError
            question = payload.get("question")
            project = payload.get("project", "all")
            if not isinstance(question, str) or not 1 <= len(question.strip()) <= 500 or project not in ("all", "clinic", "ledger"):
                raise ValueError
        except (UnicodeError, ValueError, OverflowError):
            self.data({"error": "请输入 1 至 500 字的问题，并选择有效的手册范围。"}, 400)
            return
        question = question.strip()
        result = dict(search(question, project=project, method="hybrid"), mode="extractive")
        if self.server.model:
            result = self.server.model.compose(question, result)
        self.data(result)


def serve(port, model_url="", model_name="manual-editor", host="127.0.0.1"):
    server = ThreadingHTTPServer((host, port), ManualHandler)
    server.model = LocalModel(model_url, model_name) if model_url else None
    print(f"http://{host}:{server.server_port}/", flush=True)
    with server:
        server.serve_forever()


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", default=8799, type=int)
    parser.add_argument("--model-url", default=os.environ.get("MANUAL_MODEL_URL", ""))
    parser.add_argument("--model-name", default=os.environ.get("MANUAL_MODEL_NAME", "manual-editor"))
    args = parser.parse_args()
    serve(args.port, args.model_url, args.model_name, args.host)
