import hashlib
import unittest

from engine import CORPUS, get_documents, get_sections, search


class PassageTests(unittest.TestCase):
    def test_snapshots_match_pinned_git_objects(self):
        expected = {"clinic": "c285353d9366821ae132c28645f81d4c655c321d064cbd548f24387326217a5d",
                    "ledger": "f0214f3803bb4b1c79ee6e3b89b68c43dc0737dadb1f55091fbd246af4898d77"}
        for key, digest in expected.items():
            content = (CORPUS / f"{key}.md").read_bytes()
            self.assertEqual(hashlib.sha256(content).hexdigest(), digest)

    def test_pinned_range_is_valid_for_every_passage(self):
        sections = get_sections()
        self.assertEqual(len(sections), len({s["id"] for s in sections}))
        for doc in get_documents():
            rows = [s for s in sections if s["project"] == doc["id"]]
            self.assertEqual(len(rows), doc["sections"])
            lines = (CORPUS / (doc["id"] + ".md")).read_text(encoding="utf-8").splitlines()
            for row in rows:
                self.assertLessEqual(1, row["start"])
                self.assertLessEqual(row["start"], row["end"])
                self.assertLessEqual(row["end"], len(lines))
                self.assertTrue(lines[row["start"] - 1].strip())
                self.assertIn(doc["commit"], row["url"])
                self.assertIn("#L" + str(row["start"]), row["url"])

    def test_question_about_encoding_finds_the_input_encodings(self):
        response = search("账单模板用什么编码？", "ledger")
        self.assertEqual(response["status"], "answered")
        self.assertIn("GB18030", response["answer"])
        self.assertEqual(response["citations"][0]["start"], 23)

    def test_repeated_upload_does_not_lose_batch_history(self):
        response = search("同一份样例账单再次核对，会生成新批次吗？")
        self.assertIn("同一批次", response["answer"])
        self.assertIn("复核历史", response["answer"])

    def test_questions_with_distinct_evidence_keep_both_references(self):
        response = search("候补到期是给谁，短信会通知吗？")
        self.assertEqual([r["start"] for r in response["citations"]], [22, 27])
        for citation in response["citations"]:
            self.assertIn(citation["snippet"], citation["text"])
            self.assertIn(citation["snippet"], response["answer"])

    def test_expiry_question_prefers_a_deadline_to_database_internals(self):
        response = search("号源轮到我，超过留位时间会怎样？")
        self.assertIn("10 分钟", response["answer"])
        self.assertEqual(response["citations"][0]["start"], 22)

    def test_available_clinic_source_does_not_imply_business_hours(self):
        for q in ("预约窗口周末几点下班？", "医保可以支付挂号费吗？", "R972 的预约要去几楼？",
                  "账单的历史记录保存多久？", "天气怎么样"):
            with self.subTest(q=q):
                response = search(q)
                self.assertEqual(response["status"], "insufficient")
                self.assertFalse(response["citations"])

    def test_source_filters_apply_to_lexical_and_enhanced_results(self):
        for method in ("baseline", "hybrid"):
            response = search("门诊和账单服务怎么启动", "ledger", method)
            self.assertEqual(response["method"], method)
            self.assertTrue(all(x["project"] == "ledger" for x in response["results"]))
            self.assertLessEqual(len(response["results"]), 3)

    def test_start_command_shares_a_source_range_with_its_intro(self):
        response = search("Python 启动命令是什么？", "clinic")
        cited = response["citations"][0]
        self.assertEqual((cited["start"], cited["end"]), (11, 15))
        self.assertIn("python server.py", response["answer"])

    def test_unknown_scope_or_method_fails_before_retrieval(self):
        for args in (("问题", "missing"), ("问题", "all", "missing"), (None,)):
            with self.subTest(args=args), self.assertRaises(ValueError):
                search(*args)
        self.assertEqual(search("  ")["status"], "insufficient")

    def test_result_mutation_does_not_change_future_queries(self):
        first = search("提前退出菜单要按哪个键盘按键？")
        first["citations"][0]["text"] = "modified"
        other = search("提前退出菜单要按哪个键盘按键？")
        self.assertIn("Esc", other["citations"][0]["text"])
