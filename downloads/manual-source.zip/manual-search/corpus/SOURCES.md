# 检索资料

两份 Markdown 快照来自作者已发布的产品仓库。复制 Git 对象中的 README.md 保留了原始行号。检索索引直接从这两份文件生成，GitHub 引用锁定提交。

| 快照 | 版本 | 源文件 |
| --- | --- | --- |
| clinic.md | v0.6 | [门诊候补与改约工作台](https://github.com/fate788/clinic-scheduling/blob/bf00adf19b6588e4800e48f25bd487980f0a0119/README.md) |
| ledger.md | v0.2 | [双账核对工作台](https://github.com/fate788/ledger-reconciliation/blob/97649044221e9a7bde0100948efba7b617b995b3/README.md) |
