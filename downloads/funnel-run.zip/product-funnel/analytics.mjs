export const steps = ["view", "start", "success"];
const devices = ["mobile", "desktop"];
const sources = ["sample", "session", "campus"];
const MAX_TIME = 8_640_000_000_000_000;

export function normalizeEvent(value, source) {
  if (!value || typeof value !== "object" || Array.isArray(value) || !sources.includes(source))
    throw new TypeError("事件格式不正确。");
  const { id, visitorId, activityId, activityTitle, step, at, device, sequence } = value;
  const idPattern = /^[a-z0-9][a-z0-9._:-]{0,95}$/iu;
  const validId = key => typeof key === "string" && idPattern.test(key);
  if (![id, visitorId, activityId].every(validId) ||
      typeof activityTitle !== "string" || !activityTitle.trim() || activityTitle.trim().length > 140 ||
      !steps.includes(step) || !devices.includes(device) || !Number.isSafeInteger(at) || at < 0 || at > MAX_TIME ||
      (sequence!==undefined && (!Number.isSafeInteger(sequence) || sequence<1)))
    throw new TypeError("请检查事件编号、匿名访客、活动、步骤、时间和设备。");
  return { id, visitorId, activityId, activityTitle:activityTitle.trim(), step, at, device, source,
    ...(sequence===undefined ? {} : {sequence}) };
}

export function analysisFilters(params) {
  const activityId = params.get("activity");
  const window = Number(params.get("window") || 30);
  const device = params.get("device") || "all";
  if (!Number.isInteger(window) || window < 1 || window > 1440)
    throw new RangeError("转化窗口需为 1 到 1440 分钟。");
  if (!["all", ...devices].includes(device)) throw new TypeError("未知的设备类型。");
  return {activityId, window, device};
}

function sameEvent(event) {
  return event.source + "\u0000" + event.id;
}

export function eventsForActivity(events, activityId) {
  const unique = new Map();
  for (const event of events) {
    if (event.activityId === activityId && !unique.has(sameEvent(event))) unique.set(sameEvent(event), event);
  }
  return [...unique.values()];
}

const ratio = (numerator, denominator) => denominator ? numerator / denominator : null;

function visitorProgress(events, minutes) {
  const duration = minutes * 60_000;
  // Only a supplied sequence can resolve equal timestamps.
  const hasSequence=events.every(event=>event.sequence);
  const compare=(left,right)=>left.at-right.at || (hasSequence ? left.sequence-right.sequence : 0);
  events.sort((left,right)=>compare(left,right) || steps.indexOf(right.step)-steps.indexOf(left.step) ||
    left.id.localeCompare(right.id));
  const device = events.find(event=>event.step==="view")?.device;
  let viewed = null, startEntry = null, started = null, max = 0;
  for (const event of events) {
    if (event.step === "view") {
      viewed = event;
      max = Math.max(1,max);
    } else if (event.step === "start" && viewed && compare(viewed,event)<0 && event.at-viewed.at<=duration) {
      startEntry = viewed;
      started = event;
      max = 2;
    } else if (event.step === "success" && startEntry && compare(started,event)<0 && event.at-startEntry.at<=duration) {
      return { device, max:3 };
    }
  }
  return { device, max };
}

export function computeFunnel(events, {activityId, window, device}) {
  const activity = eventsForActivity(events, activityId);
  const perVisitor = new Map();
  for (const event of activity) {
    const key = event.source+"\u0000"+event.visitorId;
    if (!perVisitor.has(key)) perVisitor.set(key,[]);
    perVisitor.get(key).push(event);
  }
  const progress = [...perVisitor.values()].map(items=>visitorProgress(items,window));
  const selected = device==="all" ? progress : progress.filter(item=>item.device===device);
  const counts = steps.map((_,index)=>selected.filter(item=>item.max>index).length);
  const groups = devices.map(name=>{
    const bucket = progress.filter(item=>item.device===name && item.max>0);
    const converted = bucket.filter(item=>item.max===steps.length).length;
    return {device:name,entered:bucket.length,converted,rate:ratio(converted,bucket.length)};
  });
  const listed = device==="all" ? activity : activity.filter(event=>event.device===device);
  return {
    activityId, window, device, groups, entered:counts[0], converted:counts.at(-1),
    rate:ratio(counts.at(-1),counts[0]), eventCount:listed.length,
    sampleEvents:listed.filter(event=>event.source==="sample").length,
    sessionEvents:listed.filter(event=>event.source==="session").length,
    steps:steps.map((step,index)=>({
      step,count:counts[index],loss:index ? counts[index-1]-counts[index] : 0,
      relativeRate:ratio(counts[index],counts[index-1] ?? counts[0]),
      overallRate:ratio(counts[index],counts[0]),
    })),
  };
}

export function listEvents(all, params) {
  const {activityId,device}=analysisFilters(params);
  const step=params.get("step") || "all", source=params.get("source") || "all";
  const limit=Number(params.get("limit") || 60);
  const visitorId=params.get("visitor");
  if (!["all",...steps].includes(step) || !["all",...sources].includes(source) ||
      !Number.isInteger(limit) || limit<1 || limit>500) throw new TypeError("未知的事件筛选条件。");
  const matched=eventsForActivity(all,activityId).filter(event=>
    (device==="all" || event.device===device) && (step==="all" || event.step===step) &&
    (source==="all" || event.source===source) && (!visitorId || event.visitorId===visitorId));
  matched.sort((left,right)=>right.at-left.at || left.id.localeCompare(right.id));
  return {events:matched.slice(0,limit),total:matched.length};
}
