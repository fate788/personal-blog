import {createServer} from "node:http";
import {randomUUID} from "node:crypto";
import {DatabaseSync} from "node:sqlite";
import {mkdir,readFile} from "node:fs/promises";
import {dirname,resolve} from "node:path";
import {fileURLToPath} from "node:url";
import {parseArgs} from "node:util";
import {analysisFilters,computeFunnel,listEvents,normalizeEvent} from "./analytics.mjs";
import {createDemo,handleDemo} from "./public-api.mjs";

const {values:options}=parseArgs({options:{
  port:{type:"string",default:"8805"}, db:{type:"string",default:"data/funnel.sqlite"},
}});
const port=Number(options.port);
if (!/^\d+$/u.test(options.port) || port > 65535) throw new RangeError("端口无效。");
const campusKey=process.env.FUNNEL_CAMPUS_KEY || "";
const configuredUrl=process.env.FUNNEL_CAMPUS_URL || "";
const campus=configuredUrl ? new URL(configuredUrl) : null;
if (Boolean(campus)!==Boolean(campusKey) || campus && (
    !["http:","https:"].includes(campus.protocol) || campus.username || campus.password ||
    campus.pathname!=="/" || campus.search || campus.hash ||
    (campus.protocol==="http:" && !["localhost","127.0.0.1","[::1]"].includes(campus.hostname)))) {
  throw new TypeError("请同时设置 FUNNEL_CAMPUS_URL 和 FUNNEL_CAMPUS_KEY。地址使用 HTTPS，或本机的 HTTP 源地址。");
}
const root=fileURLToPath(new URL("./static/",import.meta.url));
const dbPath=options.db===":memory:" ? ":memory:" : resolve(options.db);
if (dbPath!==":memory:")await mkdir(dirname(dbPath),{recursive:true});
const db=new DatabaseSync(dbPath);
db.exec(`
  PRAGMA journal_mode=WAL;
  PRAGMA busy_timeout=4000;
  CREATE TABLE IF NOT EXISTS campus_events (
    id TEXT PRIMARY KEY, visitor_id TEXT NOT NULL, activity_id TEXT NOT NULL,
    activity_title TEXT NOT NULL, step TEXT NOT NULL, at INTEGER NOT NULL,
    device TEXT NOT NULL, sequence INTEGER
  );
  CREATE INDEX IF NOT EXISTS campus_events_activity ON campus_events(activity_id, at DESC);
  CREATE TABLE IF NOT EXISTS campus_feed (
    origin TEXT PRIMARY KEY, cursor INTEGER NOT NULL, synced_at INTEGER
  );
  CREATE TABLE IF NOT EXISTS demo_sessions (
    id TEXT PRIMARY KEY, state TEXT NOT NULL, touched_at INTEGER NOT NULL
  );
`);
const statements={
  list:db.prepare(`SELECT id, visitor_id AS visitorId, activity_id AS activityId, activity_title AS activityTitle,
    step, at, device, sequence, 'campus' AS source FROM campus_events WHERE activity_id=? ORDER BY at,id`),
  activity:db.prepare("SELECT activity_id AS id,activity_title AS title FROM campus_events GROUP BY activity_id ORDER BY MAX(at) DESC"),
  insert:db.prepare("INSERT INTO campus_events(id,visitor_id,activity_id,activity_title,step,at,device,sequence) VALUES(?,?,?,?,?,?,?,?) ON CONFLICT(id) DO NOTHING"),
  feed:db.prepare("SELECT * FROM campus_feed WHERE origin=?"),
  bound:db.prepare("SELECT origin FROM campus_feed LIMIT 1"),
  saveFeed:db.prepare(`INSERT INTO campus_feed(origin,cursor,synced_at) VALUES(?,?,?)
    ON CONFLICT(origin) DO UPDATE SET cursor=excluded.cursor,synced_at=excluded.synced_at`),
  getDemo:db.prepare("SELECT state FROM demo_sessions WHERE id=?"),
  saveDemo:db.prepare(`INSERT INTO demo_sessions(id,state,touched_at) VALUES(?,?,?)
    ON CONFLICT(id) DO UPDATE SET state=excluded.state,touched_at=excluded.touched_at`),
  cleanDemo:db.prepare("DELETE FROM demo_sessions WHERE touched_at<?"),
};
const existingOrigin=statements.bound.get()?.origin;
if (campus && existingOrigin && campus.origin!==existingOrigin)
  throw new Error("该数据库已绑定另一校园实例，请为新数据源指定不同的数据库文件。");

const campusOrigin=campus?.origin || existingOrigin;
const liveMode=Boolean(campusOrigin);
const demoHeader="funnel_preview";
const staticFiles=new Map([
  ["/",["index.html","text/html; charset=utf-8"]],
  ["/index.html",["index.html","text/html; charset=utf-8"]],
  ["/styles.css",["styles.css","text/css; charset=utf-8"]],
  ["/app.mjs",["app.mjs","text/javascript; charset=utf-8"]],
  ["/transport.mjs",["transport.mjs","text/javascript; charset=utf-8"]],
]);
function activities(){
  const latest=new Map();
  for(const {id,title} of statements.activity.iterate())if(!latest.has(id))latest.set(id,{id,title});
  return [...latest.values()];
}

function transaction(run) {
  db.exec("BEGIN IMMEDIATE");
  try{
    const result=run();
    db.exec("COMMIT");
    return result;
  }catch(error){
    db.exec("ROLLBACK");
    throw error;
  }
}

async function syncCampus(){
  let imported=0,received=0;
  let cursor=statements.feed.get(campus.origin)?.cursor || 0;
  for(let pageNumber=0;pageNumber<40;pageNumber++){
    const endpoint=new URL("/api/analytics/events",campus);
    endpoint.search=new URLSearchParams({after:cursor,limit:200});
    const response=await fetch(endpoint,{headers:{Authorization:"Bearer "+campusKey,Accept:"application/json"},
      redirect:"error",signal:AbortSignal.timeout(6000)});
    if(!response.ok)throw new Error("校园端返回 HTTP "+response.status+"。请检查连接和同步密钥。");
    const data=await response.json();
    if(!Array.isArray(data.events) || data.events.length>200 || typeof data.hasMore!=="boolean" ||
      !Number.isSafeInteger(data.nextCursor) || data.nextCursor<cursor ||
      (Boolean(data.events.length)!==(data.nextCursor>cursor)) || data.hasMore&&!data.events.length)
      throw new Error("校园端事件页或游标无效。");
    const events=data.events.map(event=>normalizeEvent(event,"campus"));
    received+=events.length;
    const syncedAt=Date.now();
    imported+=transaction(()=>{
      const liveCursor=statements.feed.get(campus.origin)?.cursor ?? 0;
      if(liveCursor!==cursor)throw new Error("同步进度已被更新，请重试。");
      let written=0;
      for(const e of events)
        written+=statements.insert.run(e.id,e.visitorId,e.activityId,e.activityTitle,e.step,e.at,e.device,e.sequence ?? null).changes;
      statements.saveFeed.run(campus.origin,data.nextCursor,syncedAt);
      return written;
    });
    cursor=data.nextCursor;
    if(!data.hasMore)return {imported,received,lastSyncAt:syncedAt,hasMore:false};
  }
  return {imported,received,lastSyncAt:statements.feed.get(campus.origin).synced_at,hasMore:true};
}

let syncPromise=null;
function runSync(){
  if(!syncPromise)syncPromise=syncCampus().finally(()=>{syncPromise=null;});
  return syncPromise;
}

function write(res,status,type,payload,headers={}){
  res.writeHead(status,{"Content-Type":type,"Cache-Control":"no-store","X-Content-Type-Options":"nosniff",...headers});
  res.end(payload);
}
function json(res,status,payload,headers={}){
  write(res,status,"application/json; charset=utf-8",JSON.stringify(payload),headers);
}
function originAllowed(req) {
  const host=req.headers.host || "";
  if (!/^(?:localhost|127\.0\.0\.1)(?::\d{1,5})?$/iu.test(host)) return false;
  if(req.headers["sec-fetch-site"]==="cross-site")return false;
  return !req.headers.origin || req.headers.origin==="http://"+host;
}

async function readBody(req){
  if(req.headers["x-workspace-request"]!=="1" ||
     req.headers["content-type"]?.split(";")[0]!=="application/json")throw new TypeError("请求格式不支持。");
  const chunks=[];
  let size=0;
  for await(const chunk of req){
    size+=chunk.length;
    if(size>4096)throw new RangeError("请求内容过大。");
    chunks.push(chunk);
  }
  const content=JSON.parse(Buffer.concat(chunks).toString("utf8"));
  if(!content || typeof content!=="object" || Array.isArray(content))throw new TypeError("请求格式不支持。");
  return content;
}

function demo(req,res,url,method,body){
  const now=Date.now();
  const cookieId=(req.headers.cookie || "").match(/(?:^|;\s*)funnel_preview=([a-f0-9-]{36})(?:;|$)/u)?.[1];
  const cached=cookieId && statements.getDemo.get(cookieId);
  const visitorId=cached ? cookieId : randomUUID();
  const state=cached ? JSON.parse(cached.state) : createDemo(visitorId,now);
  const result=handleDemo(state,{url,method,body,now});
  statements.saveDemo.run(visitorId,JSON.stringify(state),now);
  if(!cached)statements.cleanDemo.run(now-30*86_400_000);
  json(res,result.status,result.body,cached?{}:{
    "Set-Cookie":`${demoHeader}=${visitorId}; Path=/; HttpOnly; SameSite=Strict; Max-Age=2592000`,
  });
}

async function live(res,url,method){
  const now=Date.now();
  const items=activities();
  const lastSyncAt=statements.feed.get(campusOrigin)?.synced_at || null;
  if(method==="GET" && url.pathname==="/api/meta"){
    json(res,200,{mode:"live",activities:items,now,campusUrl:campusOrigin+"/",syncConfigured:Boolean(campus),lastSyncAt});
    return;
  }
  if(method==="POST" && url.pathname==="/api/sync" && campus){
    try { json(res,200,await runSync()); }
    catch(error) {
      const hint=error?.message?.startsWith("校园端")?error.message:"未能同步校园事件，请检查校园服务状态。";
      json(res,502,{error:hint});
    }
    return;
  }
  if(method==="GET" && ["/api/funnel","/api/events"].includes(url.pathname)){
    const activityId=url.searchParams.get("activity") || items[0]?.id || "";
    if(activityId && !items.some(item=>item.id===activityId)){json(res,404,{error:"没有找到该活动。"});return;}
    if(!url.searchParams.has("activity"))url.searchParams.set("activity",activityId);
    const events=activityId ? statements.list.all(activityId) : [];
    const result=url.pathname==="/api/funnel" ? computeFunnel(events,analysisFilters(url.searchParams)) : listEvents(events,url.searchParams);
    json(res,200,result);return;
  }
  json(res,404,{error:"没有找到该操作。"});
}

const server=createServer({headersTimeout:8000,requestTimeout:12000},async (req,res)=>{
  if(!originAllowed(req)){json(res,403,{error:"只接受当前工作台发出的同源请求。"});return;}
  try{
    const url=new URL(req.url,"http://localhost");
    const method=req.method;
    if(url.pathname.startsWith("/api/")){
      if(method!=="GET" && method!=="POST"){json(res,405,{error:"不支持的请求方法。"});return;}
      const body=method==="POST"?await readBody(req):{};
      if(liveMode)await live(res,url,method);
      else demo(req,res,url,method,body);
      return;
    }
    const item=staticFiles.get(url.pathname);
    if(method!=="GET" || !item){json(res,404,{error:"页面不存在。"});return;}
    write(res,200,item[1],await readFile(resolve(root,item[0])),{
      "Content-Security-Policy":"default-src 'self'; img-src 'self' data:; style-src 'self' 'unsafe-inline'; object-src 'none'; frame-ancestors 'none'; base-uri 'none'",
    });
  }catch(error){
    if(error instanceof TypeError || error instanceof RangeError || error instanceof SyntaxError)
      json(res,400,{error:error instanceof SyntaxError?"JSON 格式无效。":error.message});
    else {
      console.error(error);
      json(res,500,{error:"工作台暂时不可用。"});
    }
  }
});
server.listen(port,"127.0.0.1",()=>console.log(`http://127.0.0.1:${server.address().port}/`));
