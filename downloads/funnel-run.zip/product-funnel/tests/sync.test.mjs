import assert from "node:assert/strict";
import {once} from "node:events";
import {spawn} from "node:child_process";
import {createServer} from "node:http";
import {test} from "node:test";

const now=Date.UTC(2026,10,27);
const rows=["view","start","success"].map((step,index)=>({
  id:"campus-"+index,visitorId:"visitor-example",activityId:"182",activityTitle:"校园试验活动",
  step,at:now+index,device:"desktop",sequence:index+1,
}));
const headers={"Content-Type":"application/json","X-Workspace-Request":"1"};

test("local server imports campus pages by cursor and stores only validated unique events", {timeout:12000},async t=>{
  const cursors=[];
  let corrupt=true;
  const upstream=createServer((req,res)=>{
    const url=new URL(req.url,"http://127.0.0.1");
    assert.equal(url.pathname,"/api/analytics/events");
    assert.equal(req.headers.authorization,"Bearer for-integration-test-only");
    const after=Number(url.searchParams.get("after"));
    cursors.push(after);
    const events=after===0 ? rows.slice(0,2) :
      after===2 ? (corrupt ? [{...rows[2],device:"invalid"}] : [rows[1],rows[2]]) : [];
    const nextCursor=after===0?2:after===2?3:3;
    res.writeHead(200,{"Content-Type":"application/json"});
    res.end(JSON.stringify({events,nextCursor,hasMore:after===0}));
  });
  upstream.listen(0,"127.0.0.1");
  await once(upstream,"listening");
  t.after(()=>upstream.close());
  const child=spawn(process.execPath,["server.mjs","--port","0","--db",":memory:"],{
    cwd:new URL("../",import.meta.url),env:{...process.env,
      FUNNEL_CAMPUS_URL:`http://127.0.0.1:${upstream.address().port}/`,FUNNEL_CAMPUS_KEY:"for-integration-test-only",
    },stdio:["ignore","pipe","pipe"],
  });
  const stopped=once(child,"exit");
  t.after(async()=>{child.kill();await stopped.catch(()=>{});});
  const base=await new Promise((resolve,reject)=>{
    let info="",failure="";
    child.stdout.on("data",text=>{
      info+=text;
      const address=info.match(/http:\/\/127\.0\.0\.1:\d+/u);
      if(address)resolve(address[0]);
    });
    child.stderr.on("data",text=>{failure+=text;});
    child.on("error",reject);
    child.on("exit",()=>reject(new Error(failure || "Test server stopped.")));
  });
  const sync=()=>fetch(base+"/api/sync",{method:"POST",headers,body:"{}"});
  assert.equal((await sync()).status,502);
  const path=base+"/api/funnel?activity=182";
  const partial=await (await fetch(path)).json();
  assert.deepEqual(partial.steps.map(step=>step.count),[1,1,0]);
  const list=base+"/api/cohort?activity=182&step=success&device=desktop";
  const beforeCohort=await (await fetch(list+"&outcome=lost")).json();
  assert.equal(beforeCohort.total,1);
  assert.equal(beforeCohort.visitors[0].reached,"start");
  assert.equal(beforeCohort.visitors[0].source,"campus");
  corrupt=false;
  const first=await (await sync()).json();
  assert.equal(first.imported,1);
  assert.equal(first.received,2);
  const complete=await (await fetch(path)).json();
  assert.deepEqual(complete.steps.map(step=>step.count),[1,1,1]);
  assert.equal(complete.eventCount,3);
  const afterCohort=await (await fetch(list+"&outcome=reached")).json();
  assert.equal(afterCohort.total,1);
  assert.equal(afterCohort.visitors[0].reached,"success");
  assert.equal((await (await fetch(list+"&outcome=lost")).json()).total,0);
  assert.equal((await fetch(list+"&outcome=unknown")).status,400);
  assert.equal((await (await sync()).json()).imported,0);
  assert.deepEqual(cursors,[0,2,2,3]);
  const events=await (await fetch(base+"/api/events?activity=182&step=success")).json();
  assert.equal(events.total,1);
  assert.equal(events.events[0].source,"campus");
});
