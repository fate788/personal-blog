import assert from "node:assert/strict";
import {test} from "node:test";
import {computeFunnel,normalizeEvent,listEvents} from "../analytics.mjs";
import {demoEvents} from "../fixtures.mjs";
import {createDemo,handleDemo} from "../public-api.mjs";

const anchor=Date.UTC(2026,10,27,10);
const activityId="design-open-day";
const range={activityId,window:30,device:"all"};
const numbers=result=>result.steps.map(step=>step.count);
function row(visitorId,step,minutes=0,{source="campus",device="mobile",activity=activityId,sequence,id}={}){
  return normalizeEvent({
    id:id || [visitorId,step,minutes].join("-"),visitorId,activityId:activity,activityTitle:"活动",
    step,device,at:anchor+minutes*60_000,sequence,
  },source);
}

test("ordered time window ignores reversed steps, merges retried views and allows a later valid path",()=>{
  const data=[
    row("early","success",1),row("early","view",2),row("early","start",3),
    row("late","view",0),row("late","start",1),row("late","success",31),
    row("exact","view",0),row("exact","view",0),row("exact","start",1),row("exact","success",30),
    row("retry","view",0),row("retry","start",4),row("retry","view",40),row("retry","start",44),row("retry","success",45),
    row("isolated","view",0),row("isolated","start",1),row("isolated","success",2,{activity:"different"}),
  ].reverse();
  const result=computeFunnel(data,range);
  assert.deepEqual(numbers(result),[5,5,2]);
  assert.equal(result.eventCount,16);
  assert.deepEqual(result.steps.map(step=>step.loss),[0,0,3]);
  assert.equal(result.rate,.4);
});

test("same timestamp uses the campus sequence when available, preserving the all-window duration",()=>{
  const valid=[row("same","view",0,{sequence:1}),row("same","start",0,{sequence:2}),row("same","success",0,{sequence:3})];
  const ambiguous=[row("other","view"),row("other","start"),row("other","success")];
  assert.deepEqual(numbers(computeFunnel([...valid.reverse(),...ambiguous],range)),[2,1,1]);
});

test("sample dataset totals are reproducible and device denominators differ",()=>{
  const result=computeFunnel(demoEvents(anchor),range);
  assert.deepEqual(numbers(result),[160,99,67]);
  assert.deepEqual(result.groups.map(({entered,converted})=>[entered,converted]),[[96,31],[64,36]]);
  assert.ok(computeFunnel(demoEvents(anchor),{...range,window:10}).converted<67);
  assert.deepEqual(numbers(computeFunnel([],{...range,device:"desktop"})),[0,0,0]);
  assert.equal(computeFunnel([],range).rate,null);
});

test("interactive registration is isolated, ordered and idempotent, with rows traceable by visitor",()=>{
  const state=createDemo("local-visitor",anchor);
  const other=createDemo("another-visitor",anchor);
  const access=(workspace,path,step,now=anchor)=>handleDemo(workspace,{
    url:new URL(path,"https://local.demo"),method:step?"POST":"GET",body:{activityId,step,device:"mobile"},now,
  });
  assert.equal(access(state,"/api/demo/events","success").status,409);
  for(const step of ["view","start","success"]){
    assert.equal(access(state,"/api/demo/events",step).status,201);
    assert.equal(access(state,"/api/demo/events",step).status,200);
  }
  assert.deepEqual(numbers(access(state,"/api/funnel").body),[161,100,68]);
  assert.deepEqual(numbers(access(other,"/api/funnel").body),[160,99,67]);
  const trace=access(state,"/api/events?source=session&visitor=local-visitor").body;
  assert.deepEqual(trace.events.map(event=>event.step),["success","start","view"]);
  assert.ok(trace.events.every(event=>event.source==="session"));
  assert.equal(listEvents(demoEvents(anchor),new URLSearchParams({activity:activityId,source:"session"})).total,0);
});
