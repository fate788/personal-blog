import assert from "node:assert/strict";
import {test} from "node:test";
import {computeFunnel,listCohort,normalizeEvent,listEvents} from "../analytics.mjs";
import {demoEvents} from "../fixtures.mjs";
import {createDemo,handleDemo} from "../public-api.mjs";

const anchor=Date.UTC(2026,10,27,10);
const activityId="design-open-day";
const range={activityId,window:30,device:"all"};
const numbers=result=>result.steps.map(step=>step.count);
function row(visitorId,step,minutes=0,{source="campus",device="mobile",activity=activityId,sequence,id}={}){
  return normalizeEvent({
    id:id || [visitorId,step,minutes].join("-"),visitorId,activityId:activity,activityTitle:"活动",
    step,device,at:anchor+minutes*60_000,sequence,
  },source);
}

test("ordered time window ignores reversed steps, merges retried views and allows a later valid path",()=>{
  const data=[
    row("early","success",1),row("early","view",2),row("early","start",3),
    row("late","view",0),row("late","start",1),row("late","success",31),
    row("exact","view",0),row("exact","view",0),row("exact","start",1),row("exact","success",30),
    row("retry","view",0),row("retry","start",4),row("retry","view",40),row("retry","start",44),row("retry","success",45),
    row("isolated","view",0),row("isolated","start",1),row("isolated","success",2,{activity:"different"}),
  ].reverse();
  const result=computeFunnel(data,range);
  assert.deepEqual(numbers(result),[5,5,2]);
  assert.equal(result.eventCount,16);
  assert.deepEqual(result.steps.map(step=>step.loss),[0,0,3]);
  assert.equal(result.rate,.4);
});

test("same timestamp uses the campus sequence when available, preserving the all-window duration",()=>{
  const valid=[row("same","view",0,{sequence:1}),row("same","start",0,{sequence:2}),row("same","success",0,{sequence:3})];
  const ambiguous=[row("other","view"),row("other","start"),row("other","success")];
  assert.deepEqual(numbers(computeFunnel([...valid.reverse(),...ambiguous],range)),[2,1,1]);
});

test("sample dataset totals are reproducible and device denominators differ",()=>{
  const result=computeFunnel(demoEvents(anchor),range);
  assert.deepEqual(numbers(result),[160,99,67]);
  assert.deepEqual(result.groups.map(({entered,converted})=>[entered,converted]),[[96,31],[64,36]]);
  assert.ok(computeFunnel(demoEvents(anchor),{...range,window:10}).converted<67);
  assert.deepEqual(numbers(computeFunnel([],{...range,device:"desktop"})),[0,0,0]);
  assert.equal(computeFunnel([],range).rate,null);
});

test("cohort totals match each funnel count and loss under the same device and window filters",()=>{
  const data=demoEvents(anchor);
  for (const device of ["all","mobile","desktop"]) {
    for (const window of [10,30,60]) {
      const filters={activity:activityId,window,device};
      const chart=computeFunnel(data,{...filters,activityId});
      for (const {step,count,loss} of chart.steps) {
        const reached=listCohort(data,new URLSearchParams({...filters,step,outcome:"reached",limit:8}));
        const lost=listCohort(data,new URLSearchParams({...filters,step,outcome:"lost",limit:8}));
        assert.equal(reached.total,count);
        assert.equal(lost.total,loss);
        assert.equal(reached.visitors.length,Math.min(8,count));
        assert.equal(lost.visitors.length,Math.min(8,loss));
      }
    }
  }
  const base={activity:activityId,device:"all",window:30,outcome:"lost"};
  assert.equal(listCohort(data,new URLSearchParams({...base,step:"start"})).total,61);
  assert.equal(listCohort(data,new URLSearchParams({...base,step:"success"})).total,32);
  assert.throws(()=>listCohort(data,new URLSearchParams({...base,step:"all"})),TypeError);
  assert.throws(()=>listCohort(data,new URLSearchParams({...base,step:"start",limit:501})),TypeError);
});

test("the cohort returns source-scoped visitors, retains first-view device, and excludes a late success",()=>{
  const data=[
    row("one","view",0),row("one","view",0),
    row("one","start",1,{device:"desktop"}),row("one","success",31,{device:"desktop"}),
    row("one","view",2,{source:"session"}),row("one","start",3,{source:"session"}),
    row("one","success",4,{source:"session"}),
    row("other","success",5),
  ].reverse();
  const filters={activity:activityId,window:30,device:"mobile",step:"success"};
  const lost=listCohort(data,new URLSearchParams({...filters,outcome:"lost"}));
  assert.equal(lost.total,1);
  assert.deepEqual(lost.visitors,[{
    visitorId:"one",source:"campus",device:"mobile",enteredAt:anchor,lastAt:anchor+31*60_000,reached:"start",
  }]);
  const reached=listCohort(data,new URLSearchParams({...filters,outcome:"reached"}));
  assert.equal(reached.total,1);
  assert.equal(reached.visitors[0].source,"session");
  assert.equal(reached.visitors[0].reached,"success");
  assert.equal(listCohort(data,new URLSearchParams({...filters,device:"desktop",outcome:"lost"})).total,0);
});

test("interactive registration is isolated, ordered and idempotent, with rows traceable by visitor",()=>{
  const state=createDemo("local-visitor",anchor);
  const other=createDemo("another-visitor",anchor);
  const access=(workspace,path,step,now=anchor)=>handleDemo(workspace,{
    url:new URL(path,"https://local.demo"),method:step?"POST":"GET",body:{activityId,step,device:"mobile"},now,
  });
  assert.equal(access(state,"/api/demo/events","success").status,409);
  const reached="/api/cohort?step=success&outcome=reached";
  const stopped="/api/cohort?step=start&outcome=lost";
  for(const step of ["view","start","success"]){
    assert.equal(access(state,"/api/demo/events",step).status,201);
    assert.equal(access(state,"/api/demo/events",step).status,200);
  }
  assert.deepEqual(numbers(access(state,"/api/funnel").body),[161,100,68]);
  assert.deepEqual(numbers(access(other,"/api/funnel").body),[160,99,67]);
  assert.equal(access(state,reached).body.total,68);
  assert.equal(access(other,reached).body.total,67);
  assert.equal(access(state,reached).body.visitors[0].visitorId,"local-visitor");
  assert.equal(access(state,stopped).body.total,61);
  const trace=access(state,"/api/events?source=session&visitor=local-visitor").body;
  assert.deepEqual(trace.events.map(event=>event.step),["success","start","view"]);
  assert.ok(trace.events.every(event=>event.source==="session"));
  assert.equal(listEvents(demoEvents(anchor),new URLSearchParams({activity:activityId,source:"session"})).total,0);
});
