import {mkdir,readFile,writeFile} from "node:fs/promises";
import {dirname,resolve} from "node:path";

const output=resolve(process.argv[2] || "dist/index.html");
const read=path=>readFile(new URL(path,import.meta.url),"utf8");
const asModule=code=>"data:text/javascript;base64,"+Buffer.from(code,"utf8").toString("base64");
function replaceModule(code,path,module){
  const pattern=code.includes(`"${path}"`) ? `"${path}"` : `'${path}'`;
  if(!code.includes(pattern))throw new Error("Missing module "+path);
  return code.replaceAll(pattern,JSON.stringify(module));
}
const [analytics,fixtures,api,transport,app,css,html]=await Promise.all([
  read("../analytics.mjs"),read("../fixtures.mjs"),read("../public-api.mjs"),read("transport.mjs"),
  read("../static/app.mjs"),read("../static/styles.css"),read("../static/index.html"),
]);
const analyticsModule=asModule(analytics);
const fixturesModule=asModule(replaceModule(fixtures,"./analytics.mjs",analyticsModule));
const apiModule=asModule(replaceModule(replaceModule(api,"./analytics.mjs",analyticsModule),"./fixtures.mjs",fixturesModule));
const offline=asModule(replaceModule(transport,"../public-api.mjs",apiModule));
const module=asModule(replaceModule(app,"./transport.mjs",offline));
const cssTag=/<link\b[^>]*href=["'](?:\.\/)?styles\.css(?:\?[^"']*)?["'][^>]*>/iu;
const appTag=/<script\b[^>]*src=["'](?:\.\/)?app\.mjs(?:\?[^"']*)?["'][^>]*>\s*<\/script>/iu;
if(!cssTag.test(html)||!appTag.test(html))throw new Error("Missing frontend tags.");
const policy="default-src 'none'; style-src 'unsafe-inline'; script-src data:; img-src data:; connect-src 'none'; base-uri 'none'; form-action 'none'";
const portable=html.replace("<head>",`<head>\n  <meta http-equiv="Content-Security-Policy" content="${policy}">`)
  .replace(cssTag,()=>`<style>\n${css}\n</style>`)
  .replace(appTag,()=>`<script type="module" src="${module}"></script>`);
await mkdir(dirname(output),{recursive:true});
await writeFile(output,portable.replace(/\r\n/gu,"\n"),"utf8");
console.log("Browser demo written to "+output);
