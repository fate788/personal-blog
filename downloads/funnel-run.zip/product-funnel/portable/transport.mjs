import {createDemo,handleDemo} from "../public-api.mjs";

const database=new Promise(resolve=>{
  try{
    const opening=indexedDB.open("product-funnel-demo",1);
    opening.onupgradeneeded=()=>opening.result.createObjectStore("data");
    opening.onsuccess=()=>resolve(opening.result);
    opening.onerror=()=>resolve(null);
    opening.onblocked=()=>resolve(null);
  }catch{resolve(null);}
});
const key="visit";
let memory;

function newDemo() {
  const bytes=crypto.getRandomValues(new Uint8Array(12));
  const visitorId="visitor-"+[...bytes].map(byte=>byte.toString(16).padStart(2,"0")).join("");
  return createDemo(visitorId,Date.now());
}
async function transact(operation){
  const db=await database;
  if(!db){
    memory ||= newDemo();
    return operation(memory);
  }
  return new Promise((resolve,reject)=>{
    const tx=db.transaction("data","readwrite");
    const store=tx.objectStore("data");
    const reading=store.get(key);
    let result,failure;
    reading.onsuccess=()=>{
      const state=reading.result || newDemo();
      try{result=operation(state);store.put(state,key);}
      catch(error){failure=error;tx.abort();}
    };
    tx.oncomplete=()=>resolve(result);
    tx.onabort=()=>reject(failure || tx.error || new Error("演练记录保存失败。"));
  });
}

export default async function request(path,{method="GET",body={}}={}){
  const url=new URL(path,"https://demo.local");
  let result;
  try{result=await transact(state=>handleDemo(state,{url,method,body,now:Date.now()}));}
  catch(error){
    if(error instanceof TypeError || error instanceof RangeError)
      throw Object.assign(new Error(error.message),{status:400});
    throw error;
  }
  if(result.status>=400)throw Object.assign(new Error(result.body.error),{status:result.status});
  return result.body;
}
