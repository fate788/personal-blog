# 产品转化分析台

回答「活动有人看，报名却少，到底在哪一步离开」的问题。数据来自校园场务的活动详情和真实报名事务。组织者可比较手机和桌面，并打开事件明细核对图表。

[在线体验](https://fate788.github.io/personal-blog/demos/funnel/) · [博客作品页](https://fate788.github.io/personal-blog/#project/funnel)

![产品转化分析台](docs/preview.webp)

## 快速体验

打开首页会看到「创意设计开放日」的合成数据。30 分钟窗口下，160 位访客查看、99 位开始报名、67 位报名成功。点「查看流失访客」，可以核对尚未开始报名的 61 位访客。再点匿名访客，打开该活动的原始事件，查看相邻步骤有没有上报。

图表可以切换「相对首步」和「相对上一步」两种口径。前者看每一步占所有查看访客的比例，后者看上一阶段有多少人继续。顶部总转化率始终以所有查看访客为分母。点手机端或桌面端，重新计算当前分组的漏斗和访客列表。

到「体验报名」可亲手模拟一次报名。这次操作的三条事件标为本次操作，与样例可分开查询。刷新后可继续，公开体验数据保存在当前浏览器。

## 本地运行

需要 Node.js 22.13 或以上，无需安装额外依赖。

```sh
node server.mjs
npm test
npm run build:demo
```

打开 [本机工作台](http://127.0.0.1:8805/)。未配置校园数据源时，服务提供独立的样例工作区。构建命令会生成单文件演练，可直接打开 `dist/index.html`。

## 接入校园场务

1. 使用 [校园场务最新源码](https://github.com/fate788/campus-events)，执行 `mvn package` 构建。启动时设置 `CAMPUS_ANALYTICS_KEY`，让详情、报名表和报名成功事件可被分析台读取。使用单独生成且足够长的随机密钥。
2. 在分析台启动进程中设置相同的 `FUNNEL_CAMPUS_KEY`，把 `FUNNEL_CAMPUS_URL` 设为校园场务的根地址，例如 `http://127.0.0.1:8768/`。校园场务与分析台各自监听本机。
3. 在校园场务完成一次查看、开始和报名，然后在分析台点「同步校园场务」。读取分页游标和事件 ID 都会保存在 SQLite，相同事件重新同步时不会重复计数。

校园场务端的启动示例（PowerShell）

```powershell
$env:CAMPUS_ANALYTICS_KEY = Read-Host "校园同步密钥" -MaskInput
$env:CAMPUS_SEED_SAMPLE = "true"
java -jar target/campus-events-0.12.0.jar
```

分析台端的启动示例（PowerShell）

```powershell
$env:FUNNEL_CAMPUS_URL = "http://127.0.0.1:8768/"
$env:FUNNEL_CAMPUS_KEY = Read-Host "输入相同密钥" -MaskInput
node server.mjs --db data/campus-funnel.sqlite
```

SQLite 按数据源绑定。连接另一校园实例时使用单独的 SQLite 文件。真实分析台监听回环接口，建议在同一主机使用，公开博客仅提供虚构演练。分析事件保留活动、步骤、时间、设备类型和随机匿名访客号，不传账号资料。

## 指标口径

- 每个活动按匿名浏览器访客去重。设备分组归于该访客第一次查看该活动时的设备。事件表按每条事件原始设备检索。
- 只计符合「查看活动 → 开始报名 → 报名成功」顺序的路径。窗口从该次路径的查看到完成计时，到达窗口上限仍计入。有多条可能路径时，保留该访客达到的最远步骤。
- 单步转化率的分母是上一步人数，总体转化率的分母是查看访客数。没有访客时显示「—」。
- 原始事件以事件 ID 去重。出现在窗口外的成功或乱序事件仍能在明细里查看。相同毫秒的校园事件可以用采集序号核对先后。

顺序、访客去重和转化窗口参考了成熟分析产品的做法。[PostHog 漏斗文档](https://posthog.com/docs/product-analytics/funnels) · [Amplitude 漏斗计算](https://amplitude.com/docs/analytics/charts/funnel-analysis/funnel-analysis-how-amplitude-computes)

## 排查与复核

- 报名路径用实色显示走到该步的访客，用斜线显示上一步已到达、当前还未到达的访客。两种口径和图例放在同一张图里，便于核对比例。[Amplitude 图表解读](https://amplitude.com/docs/analytics/charts/funnel-analysis/funnel-analysis-interpret)
- 「已到达」和「未到达」使用与图表相同的计算结果，点匿名访客可查原始事件。尚在转化窗口内的人后续仍可能完成。[PostHog 漏斗下钻](https://posthog.com/docs/product-analytics/funnels#identify-unsuccessful-users)
