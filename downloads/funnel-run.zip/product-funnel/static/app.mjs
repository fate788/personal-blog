import request from "./transport.mjs";

const main = document.querySelector("#main");
const nav = document.querySelector("#navigation");
const sampleActivity = "design-open-day";
const pages = {
  funnel: ["转化分析", "chart"],
  events: ["事件明细", "list"],
  try: ["体验报名", "ticket"],
};
const stages = {
  view: "查看活动",
  start: "开始报名",
  success: "报名成功",
};
const explanations = {
  view:["已查看活动的访客","打开过当前活动详情"],
  start:["已开始报名的访客","从活动详情进入报名流程"],
  success:["已完成报名的访客","在当前窗口内完成报名"],
};
const preceding = {start:"查看活动",success:"开始报名"};
const deviceNames = {all:"全部设备",mobile:"手机端",desktop:"桌面端"};
const sourceNames = {all:"全部来源",sample:"合成样例",session:"本次操作",campus:"校园场务"};
const windowOptions = [["10","10 分钟"],["30","30 分钟"],["60","1 小时"],["1440","24 小时"]];
const icons = {
  chart:"M3 20h18M5 17V9m5 8V5m5 12v-5m5 5V3",
  list:"M9 6h11M9 12h11M9 18h11M4 6h.01M4 12h.01M4 18h.01",
  ticket:"M4 6h16v4a2 2 0 0 0 0 4v4H4v-4a2 2 0 0 0 0-4zM14 6v12",
  arrow:"M4 12h15m-6-6l6 6-6 6",
  out:"M13 4h7v7m0-7l-9 9m7-1v7H5V6h7",
  mobile:"M8 3h8a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2zm3 15h2",
  desktop:"M4 4h16v12H4zm4 17h8m-4-5v5",
  clock:"M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0zm-9-5v5l3 2",
  check:"M4 12l5 5L20 6",
  pulse:"M3 12h4l3-6 4 12 3-6h4",
  sync:"M20 10a8 8 0 0 0-14-5l-2 2m0-4v4h4m-4 7a8 8 0 0 0 14 5l2-2m0 4v-4h-4",
  close:"M6 6l12 12M18 6L6 18",
};
let version = 0;
let meta = null;
let refreshing = false;
let filterFocus = "";
let focusMain = false;
let cohortSequence = 0;
const drawer = document.querySelector("#cohort-dialog");
const number = new Intl.NumberFormat("zh-CN");
const percentage = new Intl.NumberFormat("zh-CN",{style:"percent", maximumFractionDigits:1});
const time = new Intl.DateTimeFormat("zh-CN",{
  month:"2-digit",day:"2-digit",hour:"2-digit",minute:"2-digit",second:"2-digit",hourCycle:"h23",
});

function esc(value) {
  return String(value??"").replace(/[&<>'"]/g,char=>({"&":"&amp;","<":"&lt;",">":"&gt;","'":"&#39;",'"':"&quot;"})[char]);
}
function icon(name) {
  return '<span class="icon" aria-hidden="true"><svg viewBox="0 0 24 24"><path d="'+icons[name]+'"/></svg></span>';
}
function count(value) {
  return Number.isFinite(value)?number.format(value):"—";
}
function rate(value) {
  return Number.isFinite(value)?percentage.format(value):"—";
}
function width(value) {
  return `${Math.min(100,Math.max(0,(value||0)*100)).toFixed(2)}%`;
}
function displayTime(value) {
  const stamp = new Date(value);
  return value&&Number.isFinite(stamp.getTime())?time.format(stamp):"—";
}
function link(label,href,kind="text",symbol="arrow") {
  return `<a class="btn ${kind}" href="${esc(href)}">${esc(label)}${symbol?icon(symbol):""}</a>`;
}
function href(page,filters,changes={}) {
  const current = {activity:filters.activity,window:filters.window,device:filters.device,
    ...(filters.chart==="relative"?{chart:"relative"}:{}),
    ...(page==="events"?{step:"all",source:"all"}:{}),...changes};
  if(page==="events" && filters.returnDevice && current.returnDevice===undefined)current.returnDevice=filters.returnDevice;
  const params = new URLSearchParams(Object.entries(current).filter(([,value])=>value));
  return `#${page}${params.size?"?"+params:""}`;
}
function getRoute() {
  const [page,query] = location.hash.slice(1).split("?",2);
  const params = new URLSearchParams(query);
  const choose = (name,options,backup)=>options.includes(params.get(name))?params.get(name):backup;
  const data = meta?.activities||[];
  return {
    page: Object.hasOwn(pages,page)?page:"funnel",
    activity: choose("activity",data.map(item=>item.id),data.some(item=>item.id===sampleActivity)?sampleActivity:data[0]?.id),
    window:choose("window",windowOptions.map(([value])=>value),"30"),
    device:choose("device",Object.keys(deviceNames),"all"),
    step:choose("step",["all",...Object.keys(stages)],"all"),
    source:choose("source",Object.keys(sourceNames),"all"),
    chart:choose("chart",["overall","relative"],"overall"),
    returnDevice:choose("returnDevice",Object.keys(deviceNames),""),
    visitor:(params.get("visitor")||"").slice(0,128),
  };
}
function navigate(target) {
  if(location.hash===target)void render();
  else location.hash=target;
}
function apiQuery(route, extras={}) {
  return new URLSearchParams({activity:route.activity,device:route.device,...extras}).toString();
}
function header(title, subtitle, actions="",top="") {
  return `<header class="page-heading"><div>${top?`<p class="eyebrow">${esc(top)}</p>`:""}<h1>${esc(title)}</h1><p>${esc(subtitle)}</p></div>
    <div class="actions">${actions}</div></header>`;
}
function setFrame(route) {
  nav.innerHTML = Object.entries(pages).filter(([id])=>id!=="try"||meta.mode==="demo")
    .map(([id,[label,symbol]])=>`<a class="nav-link" href="${esc(href(id,route))}" ${id===route.page?'aria-current="page"':""}>${icon(symbol)}${label}</a>`).join("");
  document.querySelector("#breadcrumb").textContent=pages[route.page][0];
  document.querySelector("#side-mode").textContent=meta.mode==="demo"?"浏览器演示":"校园场务数据";
  document.querySelector("#top-status").textContent=meta.mode==="demo"?"演示工作区":"校园场务连接";
}
function actionLinks(route) {
  if(meta.mode==="demo")return link("亲自试一次报名",href("try",route),"primary","ticket");
  const campus = safeExternal(meta.campusUrl);
  return `${meta.syncConfigured?`<button class="btn" type="button" data-sync>${icon("sync")}同步校园场务</button>`:""}
    ${campus?`<a class="btn primary" href="${esc(campus)}" target="_blank" rel="noopener">打开校园场务${icon("out")}</a>`:""}`;
}
function safeExternal(value) {
  try {
    const url = new URL(value);
    return /^(https?:)$/u.test(url.protocol) && !url.username && !url.password ? url.href : "";
  } catch {
    return "";
  }
}
function picker(name,label,current,choices,wide=false) {
  const chosen = choices.find(([value])=>value===current)?.[1] || "—";
  const items = choices.map(([value,title])=>
    `<button type="button" data-choice="${esc(value)}" aria-current="${value===current}">${esc(title)}<span class="pick-mark" aria-hidden="true">✓</span></button>`).join("");
  return `<div class="filter-field ${wide?"filter-wide":""}"><span>${esc(label)}</span>
    <details class="picker" data-filter="${name}"><summary aria-label="${esc(label+" "+chosen)}"><span>${esc(chosen)}</span></summary>
      <div class="picker-list" role="group" aria-label="${esc(label)}选项">${items}</div></details></div>`;
}
function filters(route) {
  const common = picker("activity","活动",route.activity,meta.activities.map(item=>[item.id,item.title]),true);
  const device = picker("device","设备",route.device,Object.entries(deviceNames));
  const fresh = meta.mode==="live"&&meta.lastSyncAt?`最近同步 ${displayTime(meta.lastSyncAt)}`:"";
  const controls = route.page==="events"?
    `${picker("step","事件",route.step,[["all","全部事件"],...Object.entries(stages)])}
     ${device}${picker("source","来源",route.source,Object.entries(sourceNames).filter(([s])=>s==="all"||(meta.mode==="demo"?s!=="campus":s==="campus")))}
     ${route.visitor?`<span class="filter-meta">访客 ${esc(route.visitor)}　${link("清除",href("events",route,{step:route.step,source:route.source}),"text","")}</span>`:""}`:
    `${picker("window","转化窗口",route.window,windowOptions)}${device}${fresh?`<span class="filter-meta">${esc(fresh)}</span>`:""}`;
  return `<section class="panel filters" aria-label="数据筛选">${common}${controls}</section>`;
}
function statusLine(message, action="") {
  return `<div class="inspection-row"><span>${icon("pulse")}${esc(message)}</span>${action}</div>`;
}
function kpis(data) {
  return `<section class="metric-strip" aria-label="报名关键指标">
    <div class="metric-tile is-primary"><span class="metric-label">总转化率</span><strong class="metric-value" data-overall-rate>${rate(data.rate)}</strong><small class="metric-detail">完成报名 ÷ 查看活动</small></div>
    <div class="metric-tile"><span class="metric-label">查看访客</span><strong class="metric-value">${count(data.entered)}</strong><small class="metric-detail">按匿名访客去重</small></div>
    <div class="metric-tile"><span class="metric-label">完成报名</span><strong class="metric-value">${count(data.converted)}</strong><small class="metric-detail">${esc(windowOptions.find(([value])=>Number(value)===data.window)?.[1]||data.window+" 分钟")}内完成</small></div>
  </section>`;
}
function cohortButton(step,outcome,caption,cls="cohort-trigger") {
  const label=cls==="cohort-trigger"?` aria-label="${esc(stages[step]+" "+caption)}"`:"";
  return `<button type="button" class="${cls}" data-cohort-step="${step}" data-cohort-outcome="${outcome}"${label}>${esc(caption)}</button>`;
}
function funnelCard(data,route) {
  const dropped = data.steps.slice(1).reduce((most,step)=>step.loss>(most?.loss||0)?step:most,null);
  const isRelative=route.chart==="relative";
  const toggle=[["overall","相对首步"],["relative","相对上一步"]].map(([value,label])=>
    `<button type="button" aria-pressed="${route.chart===value}" data-chart-mode="${value}">${label}</button>`).join("");
  const steps = data.steps.map((entry,index)=>{
    const label = stages[entry.step] || entry.step;
    const base=isRelative?entry.relativeRate:entry.overallRate;
    const previous=index===0?base:isRelative?(data.steps[index-1].count?1:0):data.steps[index-1].overallRate;
    const details=index===0?"进入漏斗":`${rate(base)} <span>· ${count(entry.loss)} 人未达</span>`;
    return `<div class="chart-step">
      <a class="bar-step" data-step="${esc(entry.step)}" aria-label="${esc(label+" "+count(entry.count)+" 人，查看原始事件")}" aria-describedby="step-rate-${entry.step}" href="${esc(href("events",route,{step:entry.step}))}">
        <span class="bar-index">0${index+1} <span>${esc(label)}</span></span>
        <span class="bar-well" aria-hidden="true"><i class="bar-fill" data-pct="${width(base)}"></i>
          <i class="bar-loss" data-pct="${width((previous||0)-(base||0))}" data-base="${width(base)}"></i></span>
        <span class="step-title"><strong>${count(entry.count)}<span>人</span></strong></span>
        <span class="step-foot" id="step-rate-${entry.step}">${details}</span>
      </a>
      <div class="step-actions">${cohortButton(entry.step,"reached","已到达")}${index?cohortButton(entry.step,"lost","未到达"):""}</div></div>`;
  }).join("");
  const insight=dropped?`<div class="analysis-note"><p><strong>${count(dropped.loss)} 人</strong>在「${preceding[dropped.step]}」后尚未「${stages[dropped.step]}」，是当前人数差最大的环节。</p>${cohortButton(dropped.step,"lost","查看流失访客","btn text insight-action")}</div>`:"";
  return `<section class="panel funnel-card"><div class="card-head"><div><h2>报名路径</h2>
    <p>从查看到报名成功，按访客去重。</p></div>
    <div class="chart-controls"><div class="axis-toggle" role="group" aria-label="转化率基准">${toggle}</div></div></div>
    <div class="chart-body"><div class="chart-wrap"><div class="chart-axis" aria-hidden="true">${[100,75,50,25,0].map(n=>`<span>${n}%</span>`).join("")}</div>
    <div class="funnel-grid" aria-label="报名转化步骤">${steps}</div></div>
    <div class="chart-legend"><span><i class="legend-swatch"></i>到达当前步骤</span><span><i class="legend-swatch lost"></i>上一步到达、当前未到达</span></div></div>${insight}</section>`;
}
function deviceCard(data,route) {
  const [mobile,desktop] = ["mobile","desktop"].map(device=>data.groups.find(item=>item.device===device));
  const groups = [mobile,desktop].filter(Boolean).map(group=>{
    const {device} = group;
    const active = route.device===device;
    return `<a class="device-tile${active?" is-selected":""}" ${active?'aria-current="true"':""} href="${esc(href("funnel",route,{device:active?"all":device}))}"><div class="device-line"><span>${icon(device)}${deviceNames[device]}</span><strong>${rate(group?.rate)}</strong></div>
      <span class="meter" aria-hidden="true"><i data-pct="${width(group?.rate)}"></i></span>
      <p>${count(group?.converted)} 人报名成功 / ${count(group?.entered)} 人进入</p></a>`;
  }).join("");
  let finding = "两种设备都有访客进入后，才可比较转化率。";
  if (Number.isFinite(mobile?.rate) && Number.isFinite(desktop?.rate)) {
    const difference = (desktop.rate-mobile.rate)*100;
    const display = new Intl.NumberFormat("zh-CN",{maximumFractionDigits:1}).format(Math.abs(difference));
    finding = display==="0" ? "两种设备的当前报名转化率接近。" :
      `${difference>0?"桌面端":"手机端"}转化率较高，相差 ${display} 个百分点。`;
  }
  return `<section class="panel device-panel"><div class="card-head"><div><h2>设备对比</h2><p>按首次查看活动的设备分组。</p></div></div>
    <div class="device-body">${groups}<p class="finding">${finding}</p></div></section>`;
}
function eventTable(events,route,{withId=false}={}) {
  if (!events.length)return '<p class="state-text">没有匹配的事件。可切换活动、步骤或设备后再看。</p>';
  return `<div class="table-scroll" tabindex="0" aria-label="事件记录表格"><table>
    <thead><tr><th scope="col">发生时间</th><th scope="col">事件</th><th scope="col">设备</th><th scope="col">匿名访客</th><th scope="col">来源</th>${withId?'<th scope="col">事件编号</th>':""}</tr></thead>
    <tbody>${events.map(event=>`<tr data-event-source="${esc(event.source)}"><td><time>${displayTime(event.at)}</time></td><td>${esc(stages[event.step]||event.step)}</td>
       <td>${esc(deviceNames[event.device]||"未知设备")}</td><td class="mono">${route.visitor?esc(event.visitorId):`<a class="visitor-link" href="${esc(href("events",route,{source:event.source,device:"all",visitor:event.visitorId,returnDevice:route.returnDevice||route.device}))}">${esc(event.visitorId)}</a>`}</td>
       <td><span class="chip ${event.source==="session"?"live":""}">${esc(sourceNames[event.source]||event.source)}</span></td>
       ${withId?`<td class="mono">${esc(event.id)}</td>`:""}</tr>`).join("")}</tbody>
  </table></div>`;
}
function visitorTrace(events,route) {
  if(!route.visitor || route.device!=="all" || route.step!=="all" || !events.length)return "";
  const ordered = [...events].reverse();
  return `<section class="panel visitor-trace"><div class="card-head"><div><h2>这位访客的已记录步骤</h2><p>同一步出现多次时，这里显示最早一条。</p></div></div>
    <ol>${Object.entries(stages).map(([step,title])=>{
      const event = ordered.find(item=>item.step===step);
      return `<li class="${event?"observed":""}"><span>${event?icon("check"):icon("clock")}</span><div><strong>${title}</strong><small>${event?displayTime(event.at):"未记录"}</small></div></li>`;
    }).join("")}</ol></section>`;
}
async function funnelView(route,id) {
  const summary = request("/api/funnel?"+apiQuery(route,{window:route.window}));
  const recent = request("/api/events?"+apiQuery(route,{step:"all",source:"all",limit:"4"}));
  const [data,{events}] = await Promise.all([summary,recent]);
  if (version!==id)return;
  const line = meta.mode==="demo"?statusLine(
    data.sessionEvents>0?`已记录 ${count(data.sessionEvents)} 条本次操作，与 ${count(data.sampleEvents)} 条合成样例一起计算。`:
      "当前展示合成样例。走完一次报名流程，再回来查看你的三条事件。",
    data.sessionEvents>0?link("只看本次操作",href("events",route,{source:"session"})):""):
    statusLine(`当前活动共采集 ${count(data.eventCount)} 条相关事件。`);
  const activity=meta.activities.find(item=>item.id===route.activity)?.title || "";
  const contextLabel=meta.mode==="demo"?activity+" · 合成样例":activity;
  main.innerHTML = header("报名转化总览",contextLabel,actionLinks(route))+
    filters(route)+kpis(data)+`<div class="study-grid">${funnelCard(data,route)}${deviceCard(data,route)}</div>`+line+`
    <section class="panel recent"><div class="card-head"><div><h2>最近的事件</h2><p>可以按步骤、设备和来源核对原始记录。</p></div>
    ${link("查看全部事件",href("events",route))}</div>${eventTable(events,route)}</section>`;
}
async function eventsView(route,id) {
  const options = {step:route.step,source:route.source,limit:"60"};
  if(route.visitor)options.visitor=route.visitor;
  const data = await request("/api/events?"+apiQuery(route,options));
  if(version!==id)return;
  const back=link("返回转化看板",href("funnel",route,{device:route.returnDevice || route.device}),"secondary");
  const action = meta.mode==="demo"&&route.source!=="session"&&!route.visitor
    ?back+link("只看本次操作",href("events",route,{source:"session",step:route.step}),"primary"):back;
  const note = data.total>data.events.length?`匹配 ${count(data.total)} 条，显示最近 ${count(data.events.length)} 条。`:`匹配 ${count(data.total)} 条事件。`;
  main.innerHTML=header("事件明细","查看每一次操作、发生的设备与来源。",action)+filters(route)+
    visitorTrace(data.total===data.events.length?data.events:[],route)+
    `<section class="panel event-rows"><div class="card-head"><div><h2>原始事件</h2><p>${note}${route.visitor?"":" 同一访客的重复操作也会列出。"}</p></div></div>${eventTable(data.events,route,{withId:true})}</section>`;
}
function timeline(session) {
  const done = Object.keys(stages).indexOf(session.step);
  const descriptions = ["打开演示活动", "进入报名确认", "保存这次报名"];
  return `<ol class="timeline">${Object.entries(stages).map(([stage,title],i)=>
    `<li class="${done>=i?"done":""}" data-try-step="${stage}" ${done>=i?'data-complete="true"':""}>
      <span class="dot">${done>=i?icon("check"):i+1}</span>
      <div><strong>${title}</strong><small>${descriptions[i]}</small></div>
    </li>`).join("")}</ol>`;
}
function renderTry(session,route) {
  const item = meta.activities.find(candidate=>candidate.id===route.activity);
  const byVisitor = href("events",route,{source:"session",device:"all",visitor:session.visitorId});
  const action = session.step==="success"?link("查看我的三条事件",byVisitor,"primary"):
    session.step==="start"?'<button type="button" class="btn primary" data-confirm>确认报名'+icon("arrow")+'</button>':
      '<button type="button" class="btn primary" data-submit-step="start">开始报名'+icon("arrow")+'</button>';
  const body = session.step==="success"?"本次演示报名已完成。可以打开事件明细，核对自己刚刚走过的三步。":
    session.step==="start"?"确认后会记录「报名成功」，再把当前匿名访客纳入漏斗的最后一步。":
      "你已触发「查看活动」。点击开始报名，然后确认，就能看到三条真实操作记录。";
  main.innerHTML=header("体验活动报名","这是一场虚构活动。你的点击会写入当前浏览器的分析记录。",link("返回转化看板",href("funnel",route,{device:"all"}),"secondary"),"校园场务演示")+
    `<div class="try-grid"><section class="panel">
      <div class="event-canvas"><div><p class="eyebrow">演示活动</p><h2>${esc(item?.title)}</h2>
      <p>${esc(item?.description||"校园活动报名演练")}</p></div></div>
      <div class="card-body"><h2>${session.step==="success"?"报名已确认":"活动报名"}</h2><p>${body}</p>
      <div class="confirm-group">${action}${session.step==="success"?link("查看更新后的看板",href("funnel",route,{device:"all"}),"secondary"):""}</div>
      <p class="live-notice" role="status" data-notice></p></div>
    </section><section class="panel card-body try-side"><h2>我的操作记录</h2>
      <p>匿名访客 <span class="mono">${esc(session.visitorId)}</span></p>${timeline(session)}</section></div>
    <dialog class="dialog" id="confirm-dialog" aria-labelledby="confirm-title"><h2 id="confirm-title">确认演示报名？</h2><p>确认后，可回到看板查看这次操作带来的漏斗变化。</p>
      <div class="confirm-group"><button class="btn" type="button" data-dismiss>返回</button><button class="btn primary" type="button" data-submit-step="success">确认并报名</button></div>
      <p class="live-notice" role="status" data-notice></p></dialog>`;
}
function report(step,route) {
  const device = matchMedia("(max-width: 680px)").matches?"mobile":"desktop";
  return request("/api/demo/events",{method:"POST",body:{activityId:route.activity,step,device}});
}
async function tryView(route,id) {
  let session = await request("/api/demo/session?"+new URLSearchParams({activity:route.activity}));
  if(version!==id)return;
  if(!session.step)session=await report("view",route);
  if(version===id)renderTry(session,route);
}
function emptyWorkspace(route) {
  const help=meta.syncConfigured?"同步后会列出已捕获的活动及真实事件。请先从校园场务打开一项活动并开始报名。":
    "当前没有可分析的活动。本机服务连到校园场务后可读取报名事件。";
  main.innerHTML = header("报名转化总览","活动数据同步后就能查看真实报名漏斗。",actionLinks(route))+
    `<section class="panel card-body"><h2>还没有活动数据</h2><p>${help}</p></section>`;
}
function styleBars() {
  main.querySelectorAll("[data-pct]").forEach(bar=>bar.style.setProperty("--pct",bar.dataset.pct));
  main.querySelectorAll("[data-base]").forEach(bar=>bar.style.setProperty("--base",bar.dataset.base));
}
async function render({refresh=false}={}) {
  const id=++version;
  main.setAttribute("aria-busy","true");
  try {
    if(!meta||refresh) {
      const nextMeta = await request("/api/meta");
      if(version!==id)return;
      meta = nextMeta;
    }
    const route = getRoute();
    setFrame(route);
    if(!route.activity)emptyWorkspace(route);
    else if(route.page==="events")await eventsView(route,id);
    else if(route.page==="try"&&meta.mode==="demo")await tryView(route,id);
    else await funnelView(route,id);
    if(version!==id)return;
    styleBars();
    if(filterFocus) {
      const filter=filterFocus.startsWith("chart:")
        ?main.querySelector(`[data-chart-mode="${filterFocus.slice(6)}"]`)
        :main.querySelector(`[data-filter="${filterFocus}"] summary`);
      if(filter)filter.focus({preventScroll:true});
    } else if(focusMain) {
      window.scrollTo(0,0);
      main.focus({preventScroll:true});
    }
  } catch(error) {
    if(version===id)main.innerHTML=`<section class="panel card-body"><h1>无法加载数据</h1><p class="error" role="alert">${esc(error.message)}</p>
      <button type="button" class="btn" data-retry>重试</button></section>`;
  } finally {
    if(version===id) {
      main.setAttribute("aria-busy","false");
      filterFocus="";
      focusMain=false;
    }
  }
}
async function submitStep(step,button) {
  if(refreshing)return;
  const route=getRoute();
  const id=version;
  refreshing=true;
  button.disabled=true;
  try {
    const session=await report(step,route);
    if(version===id) {
      renderTry(session,route);
      main.querySelector(step==="success"?'[data-try-step="success"]':"[data-confirm]")?.scrollIntoView({block:"nearest"});
      main.querySelector(step==="success"?'.confirm-group a':"[data-confirm]")?.focus({preventScroll:true});
    }
  } catch(error) {
    if(version===id){
      const note = button.closest("dialog,section")?.querySelector("[data-notice]");
      if(note)note.textContent=error.message;
    }
  } finally {
    refreshing=false;
    button.disabled=false;
  }
}
async function sync(button) {
  if(refreshing)return;
  refreshing=true;
  button.disabled=true;
  button.textContent="正在同步…";
  try {
    const result=await request("/api/sync",{method:"POST",body:{}});
    await render({refresh:true});
    main.querySelector(".page-heading")?.insertAdjacentHTML("afterend",statusLine(`本次同步新增 ${count(result.imported)} 条事件。`));
  } catch(error) {
    button.textContent="重试同步";
    main.querySelector(".page-heading")?.insertAdjacentHTML("afterend",`<p class="error" role="alert">${esc(error.message)}</p>`);
  } finally {
    refreshing=false;
    button.disabled=false;
  }
}
function closePickers(target) {
  main.querySelectorAll(".picker[open]").forEach(picker=>{if(!picker.contains(target))picker.open=false;});
}
async function showCohort(step,outcome){
  const route=getRoute();
  if(route.page!=="funnel" || !Object.hasOwn(explanations,step) || !["lost","reached"].includes(outcome))return;
  const current=++cohortSequence;
  const [reachedTitle,reachedDescription]=explanations[step];
  const title=outcome==="reached"?reachedTitle:step==="start"?"未开始报名的访客":"未完成报名的访客";
  const activity=meta.activities.find(item=>item.id===route.activity)?.title || "";
  const windowLabel=windowOptions.find(([value])=>value===route.window)?.[1];
  drawer.innerHTML=`<header class="drawer-head"><div><p>${esc(activity)} · ${esc(windowLabel)} · ${esc(deviceNames[route.device])}</p><h2 id="cohort-title">${title}</h2></div>
    <button type="button" class="drawer-close" data-close-cohort aria-label="关闭访客名单" autofocus>${icon("close")}</button></header>
    <div class="drawer-body"><p class="state-text" role="status">正在查询访客名单…</p></div>`;
  if(!drawer.open)drawer.showModal();
  drawer.querySelector("[data-close-cohort]").focus();
  const body=drawer.querySelector(".drawer-body");
  try{
    const data=await request("/api/cohort?"+apiQuery(route,{window:route.window,step,outcome,limit:"100"}));
    if(current!==cohortSequence || !drawer.open)return;
    const description=outcome==="reached"?reachedDescription:`已「${preceding[step]}」，当前记录尚未到达「${stages[step]}」。仍在窗口内的人之后可能完成。`;
    const caption=data.total>data.visitors.length?` · 显示最近 ${count(data.visitors.length)} 位`:"";
    const rows=data.visitors.map(item=>{
      const target=href("events",route,{device:"all",source:item.source,visitor:item.visitorId,returnDevice:route.device});
      return `<tr><td><a class="visitor-link" href="${esc(target)}" title="${esc(item.visitorId)}">${esc(item.visitorId)}</a></td>
        <td>${esc(deviceNames[item.device])}</td><td><time>${displayTime(item.enteredAt)}</time></td></tr>`;
    }).join("");
    body.innerHTML=`<div class="drawer-summary"><strong data-cohort-total>${count(data.total)} 位访客</strong><p>${description}${caption}</p></div>
      ${rows?`<table class="drawer-table"><thead><tr><th scope="col">匿名访客</th><th scope="col">进入设备</th><th scope="col">首次查看</th></tr></thead><tbody>${rows}</tbody></table>`:
      '<p class="state-text">这个筛选条件下没有匹配的访客。</p>'}`;
  }catch(error){
    if(current===cohortSequence&&drawer.open)body.innerHTML=`<p class="error" role="alert">${esc(error.message)}</p>${cohortButton(step,outcome,"重试","btn")}`;
  }
}
drawer.addEventListener("close",()=>{cohortSequence++;});
drawer.addEventListener("click",event=>{
  if(event.target===drawer || event.target.closest("[data-close-cohort],a[href]"))drawer.close();
});
document.addEventListener("click",event=>{
  closePickers(event.target);
  if(event.target.closest(".skip-link")) {
    event.preventDefault();
    main.focus();
    return;
  }
  const button=event.target.closest("button");
  if(!button)return;
  if(button.hasAttribute("data-cohort-step"))void showCohort(button.dataset.cohortStep,button.dataset.cohortOutcome);
  if(button.hasAttribute("data-chart-mode")){
    const route=getRoute();
    if(route.chart!==button.dataset.chartMode){
      filterFocus=`chart:${button.dataset.chartMode}`;
      navigate(href("funnel",route,{chart:button.dataset.chartMode}));
    }
  }
  if(button.hasAttribute("data-choice")){
    const route=getRoute();
    filterFocus=button.closest(".picker").dataset.filter;
    const changes=route.page==="events"?{step:route.step,source:route.source,visitor:filterFocus==="activity"?"":route.visitor}:{};
    navigate(href(route.page,route,{...changes,[filterFocus]:button.dataset.choice}));
  }
  if(button.hasAttribute("data-confirm"))document.querySelector("#confirm-dialog").showModal();
  if(button.hasAttribute("data-dismiss"))button.closest("dialog").close();
  if(button.hasAttribute("data-submit-step"))void submitStep(button.dataset.submitStep,button);
  if(button.hasAttribute("data-sync"))void sync(button);
  if(button.hasAttribute("data-retry"))void render({refresh:true});
});
document.addEventListener("keydown",event=>{
  const picker=event.target.closest(".picker");
  if(!picker)return;
  if(event.key==="Escape") {
    picker.open=false;
    picker.querySelector("summary").focus();
  }
  if(!["ArrowDown","ArrowUp","Home","End"].includes(event.key))return;
  event.preventDefault();
  picker.open=true;
  const entries=[...picker.querySelectorAll("button")];
  const index=entries.indexOf(document.activeElement);
  const next=event.key==="Home"?0:event.key==="End"?entries.length-1:event.key==="ArrowUp"?Math.max(0,index-1):Math.min(entries.length-1,index+1);
  entries[next]?.focus();
});
window.addEventListener("hashchange",()=>{
  if(drawer.open)drawer.close();
  focusMain=true;
  void render();
});
void render();
