export default async function request(path,{method="GET",body}={}) {
  const headers={Accept:"application/json"};
  const options={method,headers,cache:"no-store"};
  if(method==="POST"){
    headers["Content-Type"]="application/json";
    headers["X-Workspace-Request"]="1";
    options.body=JSON.stringify(body || {});
  }
  const response=await fetch(path,options);
  const data=await response.json();
  if(!response.ok)throw Object.assign(new Error(data.error || "请求失败。"),{status:response.status});
  return data;
}
