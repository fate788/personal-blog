import {analysisFilters,computeFunnel,listCohort,listEvents,normalizeEvent,steps} from "./analytics.mjs";
import {demoActivities,demoEvents} from "./fixtures.mjs";

const respond=(body,status=200)=>({status,body});
const error=(status,message)=>respond({error:message},status);
export const createDemo = (visitorId,now)=>({visitorId,anchor:now,events:[]});

export function handleDemo(state, {url,method,body,now}) {
  const {pathname:path,searchParams:params}=url;
  const isView = method==="GET";
  const id = isView ? params.get("activity") || demoActivities[0].id : body.activityId;
  const activity = demoActivities.find(item=>item.id===id);
  if (isView && path==="/api/meta")return respond({mode:"demo",activities:demoActivities,now});
  if (!activity)return error(404,"没有找到该活动。");
  const visit=state.events.filter(event=>event.activityId===id);
  const current=visit.at(-1);
  const session={visitorId:state.visitorId,step:current?.step || null};
  if (isView && path==="/api/demo/session")return respond(session);
  if (method==="POST" && path==="/api/demo/events") {
    const next=steps.indexOf(body.step);
    if (next<0 || !["desktop","mobile"].includes(body.device))return error(422,"请检查步骤和设备类型。");
    if (next<visit.length)return respond(session);
    if (next!==visit.length)return error(409,"请先完成上一步。");
    const event=normalizeEvent({
      id:`${state.visitorId}:${id}:${body.step}`,visitorId:state.visitorId,activityId:id,
      activityTitle:activity.title,step:body.step,at:Math.max(now,(current?.at ?? -1)+1),
      device:visit[0]?.device || body.device,
    },"session");
    state.events.push(event);
    return respond({visitorId:state.visitorId,step:event.step},201);
  }
  if (isView && ["/api/funnel","/api/events","/api/cohort"].includes(path)){
    const all=[...demoEvents(state.anchor),...state.events];
    params.set("activity",id);
    if (path==="/api/funnel") return respond(computeFunnel(all,analysisFilters(params)));
    if (path==="/api/cohort") return respond(listCohort(all,params));
    return respond(listEvents(all,params));
  }
  return error(404,"没有找到该操作。");
}
