import {normalizeEvent} from "./analytics.mjs";

export const demoActivities = [
  {id:"design-open-day",title:"创意设计开放日",description:"参观设计工作室，参加一次快题工作坊，与校园创作小组交流。",date:"12 月 12 日 · 周六"},
  {id:"community-lab",title:"社团创作工作坊",description:"带一份未完成的点子，在两小时内和其他同学一起做出原型。",date:"12 月 16 日 · 周三"},
];

const layouts = [
  {mobile:[96,54,31], desktop:[64,45,36]},
  {mobile:[52,41,30], desktop:[36,28,19]},
];

export function demoEvents(now) {
  const baseline = Math.floor(now / 86_400_000) * 86_400_000 - 2 * 86_400_000;
  return demoActivities.flatMap((activity, index)=>Object.entries(layouts[index]).flatMap(([device,counts])=>{
    const [viewers,starts,completed] = counts;
    return Array.from({length:viewers},(_,i)=>{
      const visitorId = `sample-${activity.id}-${device}-${i+1}`;
      const viewed = baseline + i * 210_000 + (i % 3) * 80_000;
      const flow = [["view",viewed]];
      if (i < starts) flow.push(["start",viewed + (2+i%8) * 60_000]);
      if (i < completed) flow.push(["success",viewed + (3 + i%8 + i%15) * 60_000]);
      if (i % 8 === 0) flow.push(["view", viewed + 10_000]);
      return flow.map(([step,at],ordinal)=>normalizeEvent({
        id:visitorId+"-"+ordinal,visitorId,activityId:activity.id,activityTitle:activity.title,device,step,at,
      },"sample"));
    }).flat();
  }));
}
