from concurrent.futures import ThreadPoolExecutor
from contextlib import contextmanager
import csv
from http.server import ThreadingHTTPServer
import io
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import threading
import unittest
from urllib.error import HTTPError
from urllib.request import Request, urlopen

from monitor import BACKLOG_SECONDS, SLOW_MS, Store, observe
from server import LocalHandler


ROOT = Path(__file__).resolve().parent
GOOD_QUEUE = dict(queued=0, running=0, oldest_pending_seconds=0)


class LedgerEndpoint(LocalHandler):
    def do_GET(self):
        self.server.calls.append((self.command, self.path))
        payload, status = self.server.reply
        self.send_json(payload, status)


@contextmanager
def ledger():
    with ThreadingHTTPServer(("127.0.0.1", 0), LedgerEndpoint) as app:
        app.reply = ({"service": "reconcile", "status": "ok", "queue": GOOD_QUEUE}, 200)
        app.calls = []
        worker = threading.Thread(target=app.serve_forever)
        worker.start()
        try:
            yield app
        finally:
            app.shutdown()
            worker.join()


@contextmanager
def desk(db, port):
    process = subprocess.Popen([sys.executable, "-B", "-u", str(ROOT / "server.py"), "--port", "0", "--db",
                                str(db), "--ledger-port", str(port)], stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                               encoding="utf-8", creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
    try:
        base = process.stdout.readline().strip().rstrip("/")
        if not base.startswith("http://127.0.0.1:"):
            raise RuntimeError(process.stderr.read())
        yield base
    finally:
        process.terminate()
        process.communicate(timeout=10)


def api(base, path, payload=None, headers=None):
    data = None if payload is None else json.dumps(payload).encode()
    request = Request(base + path, data=data, headers={"Content-Type": "application/json", **(headers or {})})
    with urlopen(request, timeout=10) as response:
        return json.load(response)


def sample(ok, reason="backlog"):
    return dict(at="2026-01-01T00:00:00.000Z", ok=ok, reason="ok" if ok else reason,
                message="采样结果", http_status=200, latency_ms=1, **GOOD_QUEUE)


class MonitoringTests(unittest.TestCase):
    def test_incident_reopens_only_after_stable_recovery(self):
        store = Store(":memory:")
        try:
            with ThreadPoolExecutor(max_workers=6) as pool:
                list(pool.map(lambda _: store.record("drill", sample(False)), range(12)))
            store.acknowledge(1)
            store.acknowledge(1)
            store.record("drill", sample(True))
            store.record("drill", sample(False, "slow"))
            store.record("drill", sample(False, "errors"))
            store.record("drill", sample(True))
            store.record("drill", sample(True))
            incident = store.incident(1)
            self.assertEqual(incident["failed_samples"], 14)
            self.assertEqual(incident["status"], "resolved")
            self.assertEqual([event["kind"] for event in incident["timeline"]],
                             ["detected", "acknowledged", "healthy_probe", "relapsed", "symptom", "healthy_probe", "resolved"])
            store.record("drill", sample(False))
            self.assertEqual(store.incident(2)["status"], "open")
        finally:
            store.close()

    def test_history_retention_preserves_full_incident(self):
        store = Store(":memory:")
        try:
            store.record("ledger", sample(False))
            for _ in range(26):
                store.record("ledger", sample(True))
            data = store.state({"ledger": "http://127.0.0.1"})
            self.assertEqual(len(data["targets"][0]["samples"]), 20)
            self.assertTrue(all(s["ok"] for s in data["targets"][0]["samples"]))
            self.assertEqual(data["incidents"][0]["origin"], "live")
            self.assertEqual(data["incidents"][0]["status"], "resolved")
        finally:
            store.close()

    def test_monitor_requires_valid_queue_and_detects_stuck_work_on_http_200(self):
        with ledger() as app:
            url = f"http://127.0.0.1:{app.server_port}/api/health"
            def read(queue):
                app.reply = (dict(service="reconcile", status="ok", queue=queue), 200)
                return observe(url, "ledger")
            self.assertTrue(read(GOOD_QUEUE)["ok"])
            self.assertEqual(read(dict(queued=0, running=1, oldest_pending_seconds=BACKLOG_SECONDS))["reason"], "backlog")
            self.assertEqual(read(dict(queued=-1, running=0, oldest_pending_seconds=0))["reason"], "invalid")
            self.assertEqual(read(dict(queued=True, running=0, oldest_pending_seconds=0))["reason"], "invalid")
            app.reply = (dict(service="other", status="ok", queue=GOOD_QUEUE), 200)
            self.assertEqual(observe(url, "ledger")["reason"], "invalid")
            app.reply = ({"status": "fail"}, 503)
            self.assertEqual(observe(url, "ledger")["http_status"], 503)

    def test_full_fixture_workflow_csv_and_restart(self):
        with tempfile.TemporaryDirectory() as temp, ledger() as app:
            db = Path(temp) / "desk.sqlite3"
            with desk(db, app.server_port) as base:
                self.assertTrue(api(base, "/api/probe", {"target": "ledger"})["targets"][0]["last"]["ok"])
                for scenario in ("backlog", "errors", "slow"):
                    state = api(base, "/api/drill", {"scenario": scenario})
                    incident = state["incidents"][0]
                    self.assertEqual(incident["origin"], "drill")
                    self.assertEqual(incident["reason"], scenario)
                    target = next(t for t in state["targets"] if t["id"] == "drill")
                    if scenario == "slow":
                        self.assertGreaterEqual(target["last"]["latency_ms"], SLOW_MS)
                    if scenario == "errors":
                        self.assertEqual(target["last"]["http_status"], 503)
                    incident_path = f"/api/incidents/{incident['id']}"
                    with self.assertRaises(HTTPError) as problem:
                        api(base, "/api/drill", {"scenario": "slow" if scenario == "backlog" else "backlog"})
                    self.assertEqual(problem.exception.code, 409)
                    self.assertEqual(api(base, "/api/probe", {"target": "drill"})["incidents"][0]["id"], incident["id"])
                    state = api(base, incident_path + "/ack", {})
                    self.assertEqual(state["incidents"][0]["status"], "acknowledged")
                    api(base, "/api/drill", {"scenario": "idle"})
                    api(base, "/api/probe", {"target": "drill"})
                    recovered = api(base, incident_path)
                    self.assertEqual(recovered["status"], "resolved")
                    self.assertEqual(recovered["timeline"][-1]["kind"], "resolved")
                    with urlopen(base + incident_path + "/timeline.csv") as download:
                        self.assertIn("attachment", download.headers["Content-Disposition"])
                        rows = list(csv.reader(io.StringIO(download.read().decode("utf-8-sig"))))
                        self.assertEqual(len(rows), 1 + len(recovered["timeline"]))
                self.assertTrue(app.calls)
                self.assertEqual(set(app.calls), {("GET", "/api/health")})
            with desk(db, app.server_port) as restarted:
                self.assertEqual(api(restarted, "/api/incidents/3")["status"], "resolved")
                self.assertEqual(api(restarted, "/api/state")["drill"]["scenario"], "idle")

    def test_active_fixture_survives_restart_and_cross_origin_controls_are_rejected(self):
        with tempfile.TemporaryDirectory() as temp, ledger() as app:
            db = Path(temp) / "desk.sqlite3"
            with desk(db, app.server_port) as base:
                with self.assertRaises(HTTPError) as problem:
                    api(base, "/api/drill", {"scenario": "errors"}, {"Origin": "https://example.com"})
                self.assertEqual(problem.exception.code, 403)
                with self.assertRaises(HTTPError) as problem:
                    api(base, "/api/probe", {"target": {"url": "invalid"}})
                self.assertEqual(problem.exception.code, 400)
                row = api(base, "/api/drill", {"scenario": "backlog"})["incidents"][0]
            with desk(db, app.server_port) as restarted:
                after = api(restarted, "/api/probe", {"target": "drill"})
                self.assertEqual(after["drill"]["scenario"], "backlog")
                self.assertEqual(after["incidents"][0]["id"], row["id"])
                self.assertEqual(len(after["incidents"]), 1)


if __name__ == "__main__":
    unittest.main()
