"""Local incident desk. Run with Python 3.10 or later."""
import argparse
from contextlib import contextmanager
import csv
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import io
import json
import logging
import mimetypes
import os
from pathlib import Path
import re
import threading
import time
from urllib.parse import unquote, urlsplit

from monitor import INTERVAL_SECONDS, SCENARIOS, Problem, Store, observe


ROOT = Path(__file__).resolve().parent
INCIDENT_ROUTE = re.compile(r"/api/incidents/([1-9][0-9]{0,17})(/timeline\.csv|/ack)?")


@contextmanager
def own_database(path):
    """One periodic sampler owns each incident database, including across processes."""
    with path.with_name(path.name + ".lock").open("a+b") as handle:
        if os.name == "nt":
            import msvcrt
            if not handle.tell():
                handle.write(b"0")
                handle.flush()
            handle.seek(0)
            try:
                msvcrt.locking(handle.fileno(), msvcrt.LK_NBLCK, 1)
            except OSError as error:
                raise RuntimeError("另一个工作台正在探测并写入此数据库。") from error
        else:
            import fcntl
            try:
                fcntl.flock(handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
            except BlockingIOError as error:
                raise RuntimeError("另一个工作台正在探测并写入此数据库。") from error
        yield


class LocalHandler(BaseHTTPRequestHandler):
    def log_message(self, *args):
        pass

    def send_bytes(self, body, content_type, status=200, attachment=None):
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        if attachment:
            self.send_header("Content-Disposition", f'attachment; filename="{attachment}"')
        self.end_headers()
        self.wfile.write(body)

    def send_json(self, data, status=200):
        self.send_bytes(json.dumps(data, ensure_ascii=False).encode(), "application/json; charset=utf-8", status)


class Fixture(LocalHandler):
    """An independent loopback endpoint; modes only affect this fixture."""
    def do_GET(self):
        if self.path != "/api/health":
            return self.send_json({"error": "路径不存在。"}, 404)
        scenario = self.server.store.drill()["scenario"]
        if scenario == "errors":
            return self.send_json({"service": "incident-fixture", "status": "unavailable"}, 503)
        if scenario == "slow":
            time.sleep(0.65)
        queue = {"queued": 4, "running": 1, "oldest_pending_seconds": 95} if scenario == "backlog" else {
            "queued": 0, "running": 0, "oldest_pending_seconds": 0}
        self.send_json({"service": "incident-fixture", "status": "ok", "queue": queue})


class Controller:
    def __init__(self, store, ledger_port, fixture_port):
        self.store = store
        self.urls = {"ledger": f"http://127.0.0.1:{ledger_port}/api/health",
                     "drill": f"http://127.0.0.1:{fixture_port}/api/health"}
        self.locks = {key: threading.RLock() for key in self.urls}
        self.stopping = threading.Event()
        self.workers = []

    def probe(self, target):
        if not isinstance(target, str) or target not in self.urls:
            raise Problem(400, "请选择已有的探针目标。")
        with self.locks[target]:
            self.store.record(target, observe(self.urls[target], target))

    def switch(self, scenario):
        if not isinstance(scenario, str) or scenario not in SCENARIOS:
            raise Problem(400, "未知的演练场景。")
        with self.locks["drill"]:
            if self.store.set_mode(scenario):
                self.probe("drill")

    def run(self, target):
        while not self.stopping.is_set():
            try:
                self.probe(target)
            except Exception:
                logging.exception("Cannot save probe for %s", target)
            self.stopping.wait(INTERVAL_SECONDS)

    def start(self):
        self.workers = [threading.Thread(target=self.run, args=(key,), daemon=True) for key in self.urls]
        for worker in self.workers:
            worker.start()

    def stop(self):
        self.stopping.set()
        for worker in self.workers:
            worker.join()

    def state(self):
        return self.store.state(self.urls)


class Desk(LocalHandler):
    def handle_api(self, method):
        try:
            port = self.server.server_port
            hosts = {f"localhost:{port}", f"127.0.0.1:{port}"}
            if self.headers.get("Host", "").lower() not in hosts:
                raise Problem(403, "请通过本机地址打开工作台。")
            self.route(method)
        except Problem as error:
            self.send_json({"error": str(error)}, error.status)
        except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError):
            pass
        except Exception:
            logging.exception("Incident desk request failed")
            self.send_json({"error": "工作台未能完成本次操作。"}, 500)

    def do_GET(self):
        self.handle_api("GET")

    def do_POST(self):
        self.handle_api("POST")

    def body(self):
        try:
            size = int(self.headers.get("Content-Length", "0"))
        except ValueError as error:
            raise Problem(400, "请求长度无效。") from error
        if not 0 < size <= 2048:
            raise Problem(400, "请提供一个简短的 JSON 对象。")
        if self.headers.get_content_type() != "application/json":
            raise Problem(415, "请求需要 JSON 内容类型。")
        origin = self.headers.get("Origin")
        if origin and origin != "http://" + self.headers["Host"]:
            raise Problem(403, "请从本机工作台发起操作。")
        try:
            payload = json.loads(self.rfile.read(size))
        except (ValueError, UnicodeError, RecursionError) as error:
            raise Problem(400, "无法读取操作参数。") from error
        if not isinstance(payload, dict):
            raise Problem(400, "操作参数必须是对象。")
        return payload

    def route(self, method):
        path = urlsplit(self.path).path
        controller = self.server.controller
        store = controller.store
        item = INCIDENT_ROUTE.fullmatch(path)
        if method == "POST":
            payload = self.body()
            if path == "/api/drill":
                controller.switch(payload.get("scenario"))
            elif path == "/api/probe":
                controller.probe(payload.get("target"))
            elif item and item[2] == "/ack":
                store.acknowledge(int(item[1]))
            else:
                raise Problem(404, "操作路径不存在。")
            return self.send_json(controller.state())
        if path == "/api/state":
            return self.send_json(controller.state())
        if item and item[2] in (None, "/timeline.csv"):
            incident = store.incident(int(item[1]))
            if item[2] is None:
                return self.send_json(incident)
            stream = io.StringIO(newline="")
            writer = csv.writer(stream)
            writer.writerow(["事件编号", "探针来源", "时间（UTC）", "记录类型", "观察或处置"])
            for event in incident["timeline"]:
                writer.writerow([incident["id"], incident["origin"], event["at"], event["kind"], event["message"]])
            return self.send_bytes(stream.getvalue().encode("utf-8-sig"), "text/csv; charset=utf-8",
                                   attachment=f"incident-{incident['id']}-timeline.csv")
        if path.startswith("/api/"):
            raise Problem(404, "未找到接口。")
        static = ROOT / "static"
        candidate = (static / (unquote(path).lstrip("/") or "index.html")).resolve()
        if static not in candidate.parents or not candidate.is_file():
            raise Problem(404, "未找到页面。")
        content_type = {".css": "text/css", ".html": "text/html", ".js": "text/javascript"}.get(candidate.suffix)
        if content_type:
            content_type += "; charset=utf-8"
        else:
            content_type = mimetypes.guess_type(str(candidate))[0] or "application/octet-stream"
        self.send_bytes(candidate.read_bytes(), content_type)


def main():
    parser = argparse.ArgumentParser(description="本机故障响应工作台")
    parser.add_argument("--db", type=Path, default=ROOT / "data" / "incident.sqlite3")
    parser.add_argument("--port", type=int, default=8793)
    parser.add_argument("--ledger-port", type=int, default=8792, help="本机对账服务端口，默认 8792")
    args = parser.parse_args()
    if not 1 <= args.ledger_port <= 65535 or not 0 <= args.port <= 65535:
        parser.error("端口无效。")
    args.db.parent.mkdir(parents=True, exist_ok=True)
    with own_database(args.db), ThreadingHTTPServer(("127.0.0.1", args.port), Desk) as app, \
            ThreadingHTTPServer(("127.0.0.1", 0), Fixture) as fixture:
        store = Store(args.db)
        fixture.store = store
        controller = Controller(store, args.ledger_port, fixture.server_port)
        app.controller = controller
        fixture_thread = threading.Thread(target=fixture.serve_forever, daemon=True)
        fixture_thread.start()
        controller.start()
        try:
            print(f"http://127.0.0.1:{app.server_port}/", flush=True)
            app.serve_forever()
        except KeyboardInterrupt:
            pass
        finally:
            controller.stop()
            fixture.shutdown()
            fixture_thread.join()
            store.close()


if __name__ == "__main__":
    main()
