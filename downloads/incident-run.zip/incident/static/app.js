"use strict";

const targets = {ledger:"双账核对服务", drill:"隔离演练服务"};
const reasons = {ok:"探测正常", backlog:"任务积压", errors:"服务错误", slow:"响应缓慢", unreachable:"连接失败", invalid:"健康数据无效"};
const scenarios = {
  backlog:["任务积压","健康接口仍能访问，但最早待处理任务已超时。"],
  errors:["服务错误","演练服务返回错误状态，查看首次异常与后续恢复。"],
  slow:["响应缓慢","演练服务延迟返回，观察耗时触发的告警。"]
};
const targetStates = {unknown:["待探测","none"],healthy:["正常",""],unhealthy:["异常","bad"],recovering:["恢复验证中","warn"]};
const incidentStates = {open:["待签收","bad"],acknowledged:["已签收","warn"],resolved:["已恢复",""]};
const el = id => document.getElementById(id);
const escape = value => String(value ?? "").replace(/[&<>"']/g, char => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[char]));
const dates = new Intl.DateTimeFormat("zh-CN",{month:"2-digit",day:"2-digit",hour:"2-digit",minute:"2-digit",second:"2-digit",hour12:false});
const clocks = new Intl.DateTimeFormat("zh-CN",{hour:"2-digit",minute:"2-digit",second:"2-digit",hour12:false});
let state = null;
let currentView = "";
let working = false;
let pollInFlight = false;
let sequence = 0;
let latest = 0;
let lastReceived = null;
let chosenScenario = "backlog";
let archiveId = 0;
let archiveRecord = null;
let archiveMessage = "";

async function loadArchived(id) {
  archiveId=id;
  archiveRecord=null;
  archiveMessage="正在读取这条事件…";
  try {
    const response=await fetch("/api/incidents/"+id,{cache:"no-store"});
    const data=await response.json();
    if(archiveId!==id) return;
    if(response.ok) archiveRecord=data;
    else archiveMessage=data.error || "事件读取失败。";
  } catch {
    if(archiveId===id) archiveMessage="读取失败，请重新打开该事件。";
  }
  if(route().id===id) render();
}

function stamp(value, compact=false) {
  const date = new Date(value || NaN);
  return Number.isNaN(date.getTime()) ? "—" : (compact ? clocks : dates).format(date);
}
function chip([label,kind]) {
  return '<span class="chip '+kind+'">'+escape(label)+'</span>';
}
function setMarkup(id, html) {
  const node = el(id);
  if (!node || node.savedMarkup === html) return;
  const priorFocus = node.contains(document.activeElement) ? document.activeElement.id : "";
  node.innerHTML = html;
  node.savedMarkup = html;
  if (priorFocus) el(priorFocus)?.focus({preventScroll:true});
}
function action(label,command,id,primary=false) {
  return '<button type="button" id="'+id+'" class="button'+(primary?' primary':'')+'" data-command="'+command+'">'+escape(label)+'</button>';
}
function eventStatus(item) {
  return chip(incidentStates[item.status] || ["未知","none"]);
}
function eventTitle(item) {
  return targets[item.target]+" · "+(reasons[item.reason] || item.summary || "服务异常");
}
function serviceCard(target) {
  const last = target.last || {};
  const count = (value,unit) => Number.isFinite(value) ? escape(value)+'<small>'+unit+'</small>' : "—";
  const samples = target.samples || [];
  const failed = samples.filter(sample=>!sample.ok).length;
  const strip = samples.map(sample=>'<i class="bar'+(sample.ok?'':' fail')+'" title="'+escape(stamp(sample.at)+' '+(sample.ok?'成功':'异常'))+'"></i>').join("");
  return '<article class="service '+escape(target.id)+'">'+
    '<div class="service-head"><div><h3 class="service-name">'+escape(targets[target.id] || target.label)+'</h3>'+
    '<p class="scope">'+(target.id==="ledger"?'真实探针 · 双账健康接口':'独立模拟服务 · 本机演练')+'</p></div>'+chip(targetStates[target.status] || targetStates.unknown)+'</div>'+
    '<dl class="metrics"><div><dt>响应耗时</dt><dd>'+count(last.latency_ms,"ms")+'</dd></div>'+
    '<div><dt>排队任务</dt><dd>'+count(last.queued,"项")+'</dd></div><div><dt>最早待处理</dt><dd>'+count(last.oldest_pending_seconds,"秒")+'</dd></div></dl>'+
    '<div class="strip"><span class="bars-caption">近 '+samples.length+' 次探测 · '+failed+' 次异常</span><span class="bars" aria-hidden="true">'+strip+'</span></div>'+
    (last.ok===false?'<p class="service-note">'+escape(last.message || reasons[last.reason])+'</p>':'')+
    '<div class="service-bottom"><time>上次 '+stamp(last.at,true)+'</time>'+
    '<button type="button" class="text-link" id="probe-'+escape(target.id)+'" data-command="probe-'+escape(target.id)+'">立即探测</button></div></article>';
}
function eventList(items,empty) {
  if (!items.length) return '<p class="empty">'+escape(empty)+'</p>';
  return '<ul class="event-list">'+items.map(item=>'<li class="event-item"><a id="item-'+Number(item.id)+'" href="#incident/'+Number(item.id)+'"><span><strong>'+escape(eventTitle(item))+'</strong>'+
    '<small>#'+Number(item.id)+'　'+stamp(item.opened_at)+'　'+(item.target==="drill"?"隔离演练":"真实服务")+'</small></span>'+eventStatus(item)+'</a></li>').join("")+'</ul>';
}
function route() {
  const hash=location.hash.slice(1);
  if (hash==="drill") return {page:"drill"};
  if (/^history(?:\/(?:drill|ledger))?$/.test(hash)) return {page:"history",filter:hash.split("/")[1] || "all"};
  if (/^incident\/[1-9]\d*$/.test(hash)) return {page:"incident",id:Number(hash.split("/")[1])};
  return {page:"overview"};
}
function pageShell(view) {
  const pages = {
    overview:["监控总览","查看真实服务和演练环境的探测结果。",""],
    drill:["故障演练","在隔离服务触发故障，跟踪告警、签收与恢复。",'<a class="button" href="#history/drill">演练记录</a>'],
    history:["事件记录","查看所有未结束事件与最近 60 起已恢复事件。",""],
    incident:["事件详情","核对探测证据和每一次状态变更。",'<a class="button" href="#history">返回事件记录</a>']
  };
  const [title,subtitle,headAction]=pages[view.page];
  el("title").textContent=title;
  el("subtitle").textContent=subtitle;
  setMarkup("head-action",headAction);
  for(const a of document.querySelectorAll("[data-nav]")){
    if(a.dataset.nav===(view.page==="incident"?"history":view.page)) a.setAttribute("aria-current","page");
    else a.removeAttribute("aria-current");
  }
  const body={
    overview:'<section><div class="section-title"><h2>服务探针</h2><small id="frequency"></small></div><div id="services" class="services"></div></section>'+
      '<div class="lower"><section class="panel"><div class="section-title"><h2>最近事件</h2><a class="text-link" href="#history">全部记录</a></div><div id="recent"></div></section>'+
      '<section class="panel aside-panel"><h2>演练一次任务积压</h2><p>模拟后台任务停止处理，查看健康接口仍能响应时，值班台如何发现问题。</p><a class="button primary" href="#drill">进入故障演练 <span aria-hidden="true">→</span></a></section></div>',
    drill:'<div class="drill-layout"><section class="panel"><div class="section-title"><h2>演练控制</h2><span id="drill-badge"></span></div>'+
      '<fieldset class="scenarios" id="scenario-fields"><legend>选择故障场景</legend>'+
      Object.entries(scenarios).map(([key,[name,desc]])=>'<label class="scenario"><input id="choice-'+key+'" type="radio" name="scenario" value="'+key+'" '+(key===chosenScenario?'checked':'')+'><span><strong>'+name+'</strong><small>'+desc+'</small></span></label>').join("")+
      '</fieldset><div id="drill-actions"></div><p class="state-note" id="thresholds"></p></section><div id="drill-service"></div></div>'+
      '<section class="panel stacked" style="margin-top:16px"><div class="section-title"><h2>本环境事件</h2><a class="text-link" href="#history/drill">全部演练记录</a></div><div id="drill-events"></div></section>',
    history:'<section class="panel"><div class="section-title"><h2>事件列表</h2><small id="event-count"></small></div><nav id="filters" class="list-filter" aria-label="筛选事件来源"></nav><div id="events"></div></section>',
    incident:'<div id="event-detail"></div>'
  };
  setMarkup("workspace",body[view.page]);
}
function renderDetails(item) {
  if(!item) return '<section class="panel"><h2>事件记录</h2><p class="body-copy">'+escape(archiveMessage)+'</p></section>';
  let timeline=(item.timeline || []).map(step=>'<li><div><time>'+stamp(step.at)+'</time><p>'+escape(step.message)+'</p></div></li>').join("");
  const fact=(key,val)=>'<div><dt>'+key+'</dt><dd>'+escape(val)+'</dd></div>';
  return '<div class="detail-layout"><section class="panel"><div class="section-title"><h2>'+escape(eventTitle(item))+'</h2>'+eventStatus(item)+'</div>'+
    '<p class="body-copy">'+escape(item.summary)+'</p><h3 style="margin-top:16px">处置时间线</h3><ol class="timeline">'+timeline+'</ol></section>'+
    '<section class="panel"><h2>事件凭据</h2><dl class="facts">'+fact("事件编号","#"+item.id)+fact("来源",item.target==="drill"?"隔离演练":"双账核对服务")+fact("首次异常",stamp(item.opened_at))+fact("异常采样",item.failed_samples+" 次")+fact("签收时间",stamp(item.acknowledged_at))+fact("恢复时间",stamp(item.resolved_at))+
    '</dl><div class="actions">'+(item.status==="open"?action("签收事件","ack-"+item.id,"ack-event",true):'')+
    '<a class="button" href="/api/incidents/'+Number(item.id)+'/timeline.csv" download>导出时间线 CSV</a></div>'+
    (item.target==="drill" && item.status!=="resolved"?'<p class="state-note"><a class="text-link" href="#drill">返回演练控制</a></p>':'')+'</section></div>';
}
function render() {
  const view=route();
  if(currentView!==view.page){
    pageShell(view);
    currentView=view.page;
  }
  if(!state) return;
  const events=state.incidents || [];
  if(view.page==="overview"){
    el("frequency").textContent="采样间隔约 "+state.interval_seconds+" 秒";
    setMarkup("services",state.targets.map(serviceCard).join(""));
    setMarkup("recent",eventList(events.slice(0,4),"尚无事件。发生异常后的首次探测会自动建立记录。"));
  } else if(view.page==="drill"){
    const current=state.drill.scenario;
    const active=current!=="idle";
    const drill=state.targets.find(target=>target.id==="drill");
    const limits=state.thresholds;
    el("thresholds").textContent="未完成任务最久满 "+limits.oldest_pending_seconds+" 秒，或响应耗时达到 "+limits.latency_ms+" ms 即告警。切换演练会立即采样，解除后需连续 "+limits.healthy_samples+" 次正常才会关闭事件。";
    setMarkup("drill-badge",chip(active?[scenarios[current]?.[0] || "演练中","warn"]:["待命","none"]));
    el("scenario-fields").disabled=active || drill.status==="recovering" || working;
    setMarkup("drill-actions",active?action("解除故障","stop","drill-stop",true):drill.status==="recovering"?'<p class="body-copy">正在验证恢复，可在演练服务上立即探测。</p>':action("启动演练","start","drill-start",true));
    setMarkup("drill-service",serviceCard(drill));
    setMarkup("drill-events",eventList(events.filter(item=>item.target==="drill").slice(0,3),"还没有演练事件。选择一个故障场景即可开始。"));
  } else if(view.page==="history"){
    const filtered=events.filter(item=>view.filter==="all" || item.target===view.filter);
    el("event-count").textContent=filtered.length+" 起";
    setMarkup("filters",[["all","全部"],["ledger","真实服务"],["drill","隔离演练"]].map(([key,name])=>'<a href="#history'+(key==="all"?'':'/'+key)+'" aria-current="'+(key===view.filter)+'">'+name+'</a>').join(""));
    setMarkup("events",eventList(filtered,"该来源暂无事件。"));
  } else {
    let record=events.find(item=>item.id===view.id);
    if(!record) {
      if(archiveId!==view.id) loadArchived(view.id);
      record=archiveRecord;
    }
    setMarkup("event-detail",renderDetails(record));
  }
  document.querySelectorAll("[data-command]").forEach(btn=>{btn.disabled=working;});
  el("workspace").setAttribute("aria-busy","false");
  el("last-update").textContent="更新于 "+stamp(lastReceived,true);
}
function errorMessage(message) {
  el("notice").hidden=!message;
  el("notice").textContent=message;
}
async function exchange(url,body) {
  const seq=++sequence;
  const options=body===undefined?{cache:"no-store"}:{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(body)};
  const response=await fetch(url,options);
  const data=await response.json();
  if(!response.ok) throw new Error(data.error || "请求未完成。");
  if(seq>=latest){
    latest=seq;
    state=data;
    lastReceived=new Date();
    render();
  }
}
let connectionIssue=false;
async function poll() {
  if(working || pollInFlight || document.hidden) return;
  pollInFlight=true;
  try{
    await exchange("/api/state");
    if(connectionIssue) {errorMessage("");connectionIssue=false;}
  } catch {
    if(!working){connectionIssue=true;errorMessage("状态更新中断，将自动重试。请确认本机故障响应服务已启动。");}
  } finally {pollInFlight=false;}
}
document.addEventListener("change",event=>{
  if(event.target.name==="scenario") chosenScenario=event.target.value;
});
document.addEventListener("click",async event=>{
  const button=event.target.closest("[data-command]");
  if(!button || working) return;
  const command=button.dataset.command;
  let url,body;
  if(command==="start" || command==="stop"){url="/api/drill";body={scenario:command==="stop"?"idle":chosenScenario};}
  else if(command.startsWith("probe-")){url="/api/probe";body={target:command.slice(6)};}
  else if(command.startsWith("ack-")){url="/api/incidents/"+Number(command.slice(4))+"/ack";body={};}
  else return;
  working=true;
  errorMessage("");
  render();
  try{await exchange(url,body);}
  catch(error){errorMessage(error.message || "操作未完成，请重试。");}
  finally{working=false;render();}
});
window.addEventListener("hashchange",()=>{render();window.scrollTo(0,0);});
document.addEventListener("visibilitychange",()=>{if(!document.hidden) poll();});
render();
poll();
window.setInterval(poll,2100);
