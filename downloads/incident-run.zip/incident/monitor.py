"""Read-only local HTTP probe and durable incident state."""
from contextlib import closing
import http.client
import json
import sqlite3
import threading
import time
from datetime import datetime, timezone
from urllib.parse import urlsplit


SLOW_MS = 400
BACKLOG_SECONDS = 45
INTERVAL_SECONDS = 3
SCENARIOS = {"idle": "正常", "backlog": "任务积压", "errors": "接口错误", "slow": "响应延迟"}
TARGET_NAMES = {"ledger": "双账核对工作台", "drill": "隔离演练服务"}


class Problem(Exception):
    def __init__(self, status, message):
        super().__init__(message)
        self.status = status


def now():
    return datetime.now(timezone.utc).isoformat(timespec="milliseconds").replace("+00:00", "Z")


def observe(url, origin):
    """A single HTTP request with no proxy, redirects, or credentials."""
    endpoint = urlsplit(url)
    started = time.monotonic()
    result = dict(ok=False, reason="unreachable", message="连接失败",
                  http_status=None, latency_ms=None, queued=None, running=None, oldest_pending_seconds=None)

    def outcome(reason, message):
        result.update(at=now(), ok=reason == "ok", reason=reason, message=message)
        return result

    try:
        with closing(http.client.HTTPConnection(endpoint.hostname, endpoint.port, timeout=2)) as conn:
            conn.request("GET", endpoint.path, headers={"Accept": "application/json"})
            response = conn.getresponse()
            result["http_status"] = response.status
            raw = response.read(16385)
        result["latency_ms"] = round((time.monotonic() - started) * 1000)
        if response.status != 200:
            return outcome("errors", f"健康接口返回 HTTP {response.status}。")
        if len(raw) > 16384:
            return outcome("invalid", "健康响应超过约定大小，无法核验。")
        data = json.loads(raw)
        required = ("queued", "running", "oldest_pending_seconds")
        expected_service = "reconcile" if origin == "ledger" else "incident-fixture"
        if (not isinstance(data, dict) or data.get("service") != expected_service or
                not isinstance(data.get("status"), str) or not isinstance(data.get("queue"), dict)):
            return outcome("invalid", "健康响应缺少约定的服务标识、状态或队列。")
        queue = data["queue"]
        if any(type(queue.get(key)) is not int or queue[key] < 0 for key in required):
            return outcome("invalid", "队列指标缺失或取值无效。")
        result.update({key: queue[key] for key in required})
        if data["status"] != "ok":
            return outcome("errors", "健康接口报告服务状态异常。")
        if queue["queued"] + queue["running"] and queue["oldest_pending_seconds"] >= BACKLOG_SECONDS:
            return outcome("backlog", f"HTTP 200，排队 {queue['queued']} 项、运行 {queue['running']} 项，最早未完成任务已等 {queue['oldest_pending_seconds']} 秒。")
        if result["latency_ms"] >= SLOW_MS:
            return outcome("slow", f"HTTP 200，健康请求耗时 {result['latency_ms']} 毫秒，阈值为 {SLOW_MS} 毫秒。")
        return outcome("ok", f"HTTP 200，耗时 {result['latency_ms']} 毫秒，排队 {queue['queued']} 项、运行 {queue['running']} 项。")
    except (OSError, http.client.HTTPException):
        result["latency_ms"] = round((time.monotonic() - started) * 1000)
        return outcome("unreachable", "健康请求未完成，请核对本机服务是否启动或应答超时。")
    except (ValueError, UnicodeError, RecursionError):
        return outcome("invalid", "健康接口返回了无法解析的 JSON。")


class Store:
    def __init__(self, path):
        self.lock = threading.RLock()
        self.db = sqlite3.connect(path, check_same_thread=False)
        self.db.row_factory = sqlite3.Row
        self.db.executescript("""
            PRAGMA journal_mode=WAL;
            PRAGMA foreign_keys=ON;
            CREATE TABLE IF NOT EXISTS samples (
                id INTEGER PRIMARY KEY, target TEXT NOT NULL, data TEXT NOT NULL
            );
            CREATE INDEX IF NOT EXISTS sample_target ON samples(target,id);
            CREATE TABLE IF NOT EXISTS incidents (
                id INTEGER PRIMARY KEY, target TEXT NOT NULL, reason TEXT NOT NULL,
                status TEXT NOT NULL, opened_at TEXT NOT NULL, acknowledged_at TEXT,
                resolved_at TEXT, failed_samples INTEGER NOT NULL, healthy_streak INTEGER NOT NULL,
                summary TEXT NOT NULL
            );
            CREATE UNIQUE INDEX IF NOT EXISTS one_active ON incidents(target) WHERE status <> 'resolved';
            CREATE TABLE IF NOT EXISTS events (
                seq INTEGER PRIMARY KEY, incident_id INTEGER NOT NULL REFERENCES incidents(id),
                at TEXT NOT NULL, kind TEXT NOT NULL, message TEXT NOT NULL
            );
            CREATE INDEX IF NOT EXISTS event_parent ON events(incident_id,seq);
            CREATE TABLE IF NOT EXISTS drill_mode (
                id INTEGER PRIMARY KEY CHECK (id=1), scenario TEXT NOT NULL, changed_at TEXT NOT NULL
            );
        """)
        with self.db:
            self.db.execute("INSERT OR IGNORE INTO drill_mode VALUES (1,'idle',?)", (now(),))

    def close(self):
        with self.lock:
            self.db.close()

    def event(self, incident_id, at, kind, message):
        self.db.execute("INSERT INTO events(incident_id,at,kind,message) VALUES (?,?,?,?)",
                        (incident_id, at, kind, message))

    def active(self, target):
        return self.db.execute("SELECT * FROM incidents WHERE target=? AND status <> 'resolved'", (target,)).fetchone()

    def record(self, target, sample):
        with self.lock, self.db:
            self.db.execute("INSERT INTO samples(target,data) VALUES (?,?)", (target, json.dumps(sample, ensure_ascii=False)))
            self.db.execute("""DELETE FROM samples WHERE target=? AND id NOT IN
                (SELECT id FROM samples WHERE target=? ORDER BY id DESC LIMIT 20)""", (target, target))
            incident = self.active(target)
            stamp, message = sample["at"], sample["message"]
            if not sample["ok"]:
                if incident is None:
                    key = self.db.execute("""INSERT INTO incidents
                        (target,reason,status,opened_at,failed_samples,healthy_streak,summary)
                        VALUES (?,?,'open',?,1,0,?)""", (target, sample["reason"], stamp, message)).lastrowid
                    self.event(key, stamp, "detected", message)
                    return
                key = incident["id"]
                if incident["healthy_streak"]:
                    self.event(key, stamp, "relapsed", "恢复确认中再次出现异常。" + message)
                elif incident["reason"] != sample["reason"]:
                    self.event(key, stamp, "symptom", "探针异常类型发生变化。" + message)
                self.db.execute("""UPDATE incidents SET reason=?, failed_samples=failed_samples+1,
                    healthy_streak=0, summary=? WHERE id=?""", (sample["reason"], message, key))
            elif incident is not None:
                key = incident["id"]
                if incident["healthy_streak"] == 0:
                    self.db.execute("UPDATE incidents SET healthy_streak=1 WHERE id=?", (key,))
                    self.event(key, stamp, "healthy_probe", "第一次健康采样。" + message)
                else:
                    self.db.execute("UPDATE incidents SET status='resolved', resolved_at=?, healthy_streak=2 WHERE id=?",
                                    (stamp, key))
                    self.event(key, stamp, "resolved", "连续两次健康采样，事件已恢复。" + message)

    def acknowledge(self, key):
        with self.lock, self.db:
            row = self.db.execute("SELECT status FROM incidents WHERE id=?", (key,)).fetchone()
            if row is None:
                raise Problem(404, "未找到这条事件。")
            if row["status"] == "resolved":
                raise Problem(409, "事件已经恢复。")
            if row["status"] == "open":
                stamp = now()
                self.db.execute("UPDATE incidents SET status='acknowledged',acknowledged_at=? WHERE id=?", (stamp, key))
                self.event(key, stamp, "acknowledged", "值班人已确认收到告警。")

    def drill(self):
        with self.lock:
            return dict(self.db.execute("SELECT scenario, changed_at FROM drill_mode").fetchone())

    def set_mode(self, scenario):
        with self.lock, self.db:
            before = self.drill()["scenario"]
            if before == scenario:
                return False
            active = self.active("drill")
            if scenario != "idle" and (before != "idle" or active is not None):
                raise Problem(409, "请先解除当前演练，并等待连续两次健康采样确认恢复。")
            stamp = now()
            self.db.execute("UPDATE drill_mode SET scenario=?,changed_at=?", (scenario, stamp))
            if active is not None and scenario == "idle":
                self.event(active["id"], stamp, "action", "已解除演练条件，等待探针验证恢复。")
            return True

    def _details(self, row):
        item = dict(row)
        item["origin"] = "live" if item["target"] == "ledger" else "drill"
        item["timeline"] = [dict(event) for event in self.db.execute(
            "SELECT at,kind,message FROM events WHERE incident_id=? ORDER BY seq", (item["id"],))]
        return item

    def incident(self, key):
        with self.lock:
            row = self.db.execute("SELECT * FROM incidents WHERE id=?", (key,)).fetchone()
            if row is None:
                raise Problem(404, "未找到这条事件。")
            return self._details(row)

    def state(self, urls):
        with self.lock:
            targets = []
            for key, url in urls.items():
                samples = [json.loads(row[0]) for row in self.db.execute(
                    "SELECT data FROM samples WHERE target=? ORDER BY id", (key,))]
                last = samples[-1] if samples else None
                active = self.active(key)
                status = "unknown" if last is None else ("healthy" if last["ok"] else "unhealthy")
                if active is not None and active["healthy_streak"]:
                    status = "recovering"
                targets.append(dict(id=key, label=TARGET_NAMES[key], url=url, status=status, last=last, samples=samples))
            rows = self.db.execute("""SELECT * FROM incidents WHERE status <> 'resolved' OR id IN
                (SELECT id FROM incidents WHERE status='resolved' ORDER BY id DESC LIMIT 60) ORDER BY id DESC""").fetchall()
            return dict(targets=targets, incidents=[self._details(row) for row in rows], drill=self.drill(),
                        interval_seconds=INTERVAL_SECONDS,
                        thresholds={"latency_ms": SLOW_MS, "oldest_pending_seconds": BACKLOG_SECONDS, "healthy_samples": 2})
