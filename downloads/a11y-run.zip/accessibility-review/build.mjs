import { copyFile, mkdir, readFile, writeFile } from 'node:fs/promises';
import { dirname, resolve } from 'node:path';

const output = resolve(process.argv[2] || 'dist/index.html');
const read = async path => (await readFile(new URL(path, import.meta.url), 'utf8')).replaceAll('\r\n', '\n');
const moduleUrl = source => `data:text/javascript;base64,${Buffer.from(source).toString('base64')}`;
const [html, css, app, engine, sample] = await Promise.all([
  read('./static/index.html'), read('./static/styles.css'), read('./static/app.mjs'),
  read('./engine.mjs'), read('./sample.mjs'),
]);

function inlineModule(source, path, script) {
  const url = moduleUrl(script);
  return source.replaceAll(`'${path}'`, `'${url}'`).replaceAll(`"${path}"`, `"${url}"`);
}

const application = inlineModule(inlineModule(app, '../engine.mjs', engine), '../sample.mjs', sample);
const cssEntry = /<link\b[^>]*href=["'](?:\.\/)?styles\.css["'][^>]*>/iu;
const jsEntry = /<script\b[^>]*src=["'](?:\.\/)?app\.mjs["'][^>]*>\s*<\/script>/iu;
if (!cssEntry.test(html) || !jsEntry.test(html)) throw new Error('找不到走查台的样式或脚本入口。');

const policy = "default-src 'none'; style-src 'unsafe-inline'; script-src data:; img-src 'self' data:; connect-src 'none'; base-uri 'none'; form-action 'none'";
const standalone = html.replace('<head>', `<head>\n  <meta http-equiv="Content-Security-Policy" content="${policy}">`)
  .replace(cssEntry, () => `<style>\n${css}\n</style>`)
  .replace(jsEntry, () => `<script type="module" src="${moduleUrl(application)}"></script>`);

const media = resolve(dirname(output), 'media');
await mkdir(media, { recursive: true });
await copyFile(new URL('./static/media/reading-room.webp', import.meta.url), resolve(media, 'reading-room.webp'));
await writeFile(output, standalone, 'utf8');
console.log(`已生成无障碍走查工作台 ${output}`);
