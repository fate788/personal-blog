# 无障碍走查工作台

用一套可操作的图书馆预约页面复核常见无障碍问题。切换修复前后，重新检查预览，在右侧定位问题，并记录用键盘走完预约的结果。

[打开原始版本](https://fate788.github.io/personal-blog/demos/a11y/index.html?v=1.0) · [看修复后](https://fate788.github.io/personal-blog/demos/a11y/index.html?v=1.0&view=fixed) · [博客作品页](https://fate788.github.io/personal-blog/projects/a11y/index.html)

![图书馆预约走查](docs/preview.webp)

## 三步走查

1. 在原始版本运行自动检查。选中一条问题，核对控件在页面上的实际位置与判定依据。
2. 切换修复版，重新运行相同检查，再用 Tab 和 Enter 完成预约，检查焦点与确认提示，记录人工复核结果。
3. 下载 JSON。报告保存两个版本的自动结果和人工结论。预约输入在当前页面内使用。

## 本机运行

需要 Node.js 22 或更新版本，无额外依赖。

```sh
npm test
npm run build
```

构建后打开 `dist/index.html`，页面和 `dist/media` 保留在一起即可离线使用。

## 检查范围

自动检查读取内置预览的实际 DOM 与计算样式，覆盖预约输入标签、指定图片替代文本、帮助按钮名称、指定文本的颜色对比，以及演示段落的标题层级。颜色按 WCAG 的 sRGB 相对亮度计算。样例的说明文字从 2.20:1 提高到 8.65:1。人工核对键盘操作、可见焦点和确认信息。标题层级提示按此示例的信息结构判断。报告只记录约定的检查点，完整的无障碍评估需要覆盖更多页面、交互及辅助技术。

设计依据 [WCAG 2.2](https://www.w3.org/TR/WCAG22/) 和 [WAI 无障碍检查方法](https://www.w3.org/WAI/test-evaluate/preliminary/)。
