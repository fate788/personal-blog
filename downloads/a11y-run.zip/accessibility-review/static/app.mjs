import { auditPreview } from '../engine.mjs';
import { renderSample } from '../sample.mjs';

const byId = id => document.getElementById(id);
const versionLabels = { baseline: '修复前', fixed: '修复后' };
const versionOrder = ['baseline', 'fixed'];
const checks = [
  { id: 'tab-order', title: '键盘动线', guidance: '用 Tab 和 Shift+Tab 移动。选时段时，按空格打开，再用方向键和回车选择。', criterion: '2.4.3' },
  { id: 'focus', title: '焦点可见', guidance: '逐个停在可操作控件上，确认能看清当前焦点的位置。', criterion: '2.4.7' },
  { id: 'submit-feedback', title: '提交反馈', guidance: '先提交空表单，再填写预约信息。确认可以找到错误和成功反馈。', criterion: '3.3.1' },
];
const choices = { pending: '待复核', pass: '通过', fail: '未通过' };
const checksByRule = {
  'form-label': '表单标签',
  'image-alt': '图片替代文本',
  'button-name': '按钮名称',
  'text-contrast': '文字对比度',
  'heading-order': '标题层级',
};

const state = {
  mode: new URLSearchParams(location.search).get('view') === 'fixed' ? 'fixed' : 'baseline',
  audits: { baseline: null, fixed: null },
  manual: Object.fromEntries(versionOrder.map(version => [version, Object.fromEntries(checks.map(check => [check.id, 'pending']))])),
  selected: null,
  sampleRoot: null,
};

function node(tag, text, classes) {
  const result = document.createElement(tag);
  if (text !== undefined) result.textContent = text;
  if (classes) result.className = classes;
  return result;
}

function announce(text) {
  byId('announcement').textContent = text;
}

function currentFinding() {
  return state.audits[state.mode]?.findings.find(item => item.id === state.selected);
}

function targetFor(finding) {
  return finding && state.sampleRoot?.querySelector(finding.selector);
}

function positionMarker() {
  const marker = byId('focus-mark');
  const target = targetFor(currentFinding());
  if (!target) {
    marker.hidden = true;
    return;
  }
  const targetRect = target.getBoundingClientRect();
  const previewRect = byId('preview-wrap').getBoundingClientRect();
  if (!targetRect.width || !targetRect.height) {
    marker.hidden = true;
    return;
  }
  const padding = targetRect.width + 8 < previewRect.width ? 4 : 0;
  marker.style.left = `${targetRect.left - previewRect.left - padding}px`;
  marker.style.top = `${targetRect.top - previewRect.top - padding}px`;
  marker.style.width = `${targetRect.width + 2 * padding}px`;
  marker.style.height = `${targetRect.height + 2 * padding}px`;
  marker.hidden = false;
}

function renderDetail(finding) {
  const panel = byId('finding-detail');
  panel.hidden = !finding;
  panel.replaceChildren();
  if (finding) {
    panel.append(
      node('h3', '检测证据'),
      node('p', finding.evidence),
      node('code', finding.selector),
    );
  }
  positionMarker();
}

function runAudit({ speak = false } = {}) {
  const audit = auditPreview(state.sampleRoot);
  state.audits[state.mode] = audit;
  const { checked, passed, failed } = audit.totals;
  byId('checked-total').textContent = checked;
  byId('failed-total').textContent = failed;
  byId('passed-total').textContent = passed;
  byId('metric-version').textContent = versionLabels[state.mode];
  const badge = byId('findings-count');
  badge.hidden = failed === 0;
  badge.textContent = `${failed} 项待复核`;

  const noFindings = byId('empty-findings');
  noFindings.hidden = failed > 0;
  noFindings.textContent = '当前版本的五项自动规则均通过。仍可在下方复核键盘操作和提交反馈。';
  if (!audit.findings.some(finding => finding.id === state.selected)) {
    state.selected = audit.findings[0]?.id ?? null;
  }

  const list = byId('finding-list');
  list.classList.toggle('fixed-checks', failed === 0);
  if (failed === 0) {
    list.replaceChildren(...Object.values(checksByRule).map(label => {
      const item = node('div', undefined, 'fixed-check');
      item.append(node('span', label), node('span', '通过'));
      return item;
    }));
  } else {
    list.replaceChildren(...audit.findings.map(finding => {
      const button = node('button', undefined, 'finding-button');
      button.type = 'button';
      button.dataset.findingId = finding.id;
      button.setAttribute('aria-pressed', String(state.selected === finding.id));
      button.setAttribute('aria-controls', 'finding-detail');
      button.append(node('span', finding.title, 'finding-name'), node('span', finding.criterion, 'finding-rule'));
      return button;
    }));
  }

  renderDetail(currentFinding());
  if (speak) announce(`${versionLabels[state.mode]}检查完成。检查 ${checked} 项，${failed} 项待复核。`);
}

function updateManual() {
  const outcomes = state.manual[state.mode];
  const controls = byId('manual-list');
  for (const element of controls.querySelectorAll('[data-outcome]')) {
    element.setAttribute('aria-pressed', String(outcomes[element.closest('[data-manual-id]').dataset.manualId] === element.dataset.outcome));
  }
  const recorded = Object.values(outcomes).filter(outcome => outcome !== 'pending').length;
  byId('manual-count').textContent = `${recorded} / ${checks.length} 已记录`;
}

function setupManual() {
  const list = byId('manual-list');
  list.replaceChildren(...checks.map(check => {
    const item = node('section', undefined, 'manual-item');
    item.dataset.manualId = check.id;
    const title = node('h3', check.title);
    title.id = `manual-${check.id}`;
    const options = node('div', undefined, 'manual-choice');
    options.setAttribute('role', 'group');
    options.setAttribute('aria-labelledby', title.id);
    for (const [key, name] of Object.entries(choices)) {
      const button = node('button', name);
      button.type = 'button';
      button.dataset.outcome = key;
      options.append(button);
    }
    item.append(title, node('p', check.guidance), options);
    return item;
  }));
}

function showVersion(mode, speak = false) {
  state.mode = mode;
  state.selected = null;
  byId('mode-baseline').setAttribute('aria-pressed', String(mode === 'baseline'));
  byId('mode-fixed').setAttribute('aria-pressed', String(mode === 'fixed'));
  state.sampleRoot = renderSample(byId('preview-sample'), mode);
  runAudit({ speak });
  updateManual();
}

function saveReport() {
  const report = {
    schemaVersion: 1,
    sample: '图书馆阅览室预约',
    scope: '仅覆盖已检查的预约样例规则。键盘与提交反馈为人工复核。',
    versions: Object.fromEntries(versionOrder.map(version => [version, {
      name: versionLabels[version],
      audit: state.audits[version],
      manual: checks.map(check => ({ id: check.id, title: check.title, criterion: check.criterion, outcome: state.manual[version][check.id] })),
    }])),
  };
  const url = URL.createObjectURL(new Blob([`${JSON.stringify(report, null, 2)}\n`], { type: 'application/json;charset=utf-8' }));
  const anchor = node('a');
  anchor.href = url;
  anchor.download = '图书馆预约无障碍走查.json';
  document.body.append(anchor);
  anchor.click();
  anchor.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1_000);
  announce('已导出走查报告。');
}

byId('mode-baseline').addEventListener('click', () => { if (state.mode !== 'baseline') showVersion('baseline', true); });
byId('mode-fixed').addEventListener('click', () => { if (state.mode !== 'fixed') showVersion('fixed', true); });
byId('run-audit').addEventListener('click', () => runAudit({ speak: true }));
byId('export-report').addEventListener('click', saveReport);
byId('finding-list').addEventListener('click', event => {
  const button = event.target.closest('[data-finding-id]');
  if (!button) return;
  state.selected = button.dataset.findingId;
  for (const control of byId('finding-list').querySelectorAll('[data-finding-id]')) {
    control.setAttribute('aria-pressed', String(control === button));
  }
  const finding = currentFinding();
  renderDetail(finding);
  targetFor(finding)?.scrollIntoView({ block: 'nearest' });
  announce(finding.evidence);
});
byId('manual-list').addEventListener('click', event => {
  const button = event.target.closest('[data-outcome]');
  if (!button) return;
  const item = button.closest('[data-manual-id]');
  state.manual[state.mode][item.dataset.manualId] = button.dataset.outcome;
  updateManual();
  announce(`${item.querySelector('h3').textContent}已记为${choices[button.dataset.outcome]}。`);
});
new ResizeObserver(positionMarker).observe(byId('preview-sample'));
byId('preview-sample').addEventListener('click', () => requestAnimationFrame(positionMarker));
byId('preview-sample').addEventListener('submit', () => requestAnimationFrame(positionMarker));

setupManual();
const inactiveVersion = state.mode === 'baseline' ? 'fixed' : 'baseline';
state.audits[inactiveVersion] = auditPreview(renderSample(byId('preview-sample'), inactiveVersion));
showVersion(state.mode);
byId('run-audit').disabled = false;
byId('export-report').disabled = false;
