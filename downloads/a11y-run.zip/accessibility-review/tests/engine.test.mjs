import assert from 'node:assert/strict';
import test from 'node:test';
import { auditPreview, contrastRatio } from '../engine.mjs';

const plain = Object.freeze({
  color: 'rgb(0, 0, 0)', backgroundColor: 'rgba(0, 0, 0, 0)', backgroundImage: 'none',
  opacity: '1', display: 'block', visibility: 'visible',
});

function node(localName, attributes = {}, children = [], computed = {}) {
  return {
    nodeType: 1,
    localName,
    style: { ...plain, ...computed },
    childNodes: children.map(child => typeof child === 'string' ? { nodeType: 3, textContent: child } : child),
    hidden: Object.hasOwn(attributes, 'hidden'),
    getAttribute(name) { return attributes[name] ?? null; },
    get textContent() { return this.childNodes.map(child => child.textContent).join(''); },
  };
}

function documentTree(...nodes) {
  const root = node('section', {}, nodes, { backgroundColor: 'rgb(244, 245, 239)' });
  const descendants = [];
  const rootDocument = {
    defaultView: { getComputedStyle: element => element.style },
    getElementById: id => descendants.find(element => element.getAttribute('id') === id),
  };
  function mount(parent) {
    for (const child of parent.childNodes) {
      if (child.nodeType !== 1) continue;
      child.parentElement = parent;
      descendants.push(child);
      mount(child);
    }
  }
  mount(root);
  return Object.assign(root, {
    isConnected: true,
    ownerDocument: rootDocument,
    contains: element => descendants.includes(element),
    querySelectorAll(selector) {
      const attribute = selector.match(/^\[(.+)\]$/u);
      if (attribute) return descendants.filter(element => element.getAttribute(attribute[1]) !== null);
      const names = selector.split(',');
      return descendants.filter(element => names.includes(element.localName));
    },
  });
}

function preview(fixed) {
  const input = node('input', { id: 'form-name', 'data-audit-id': 'booking-name', 'data-audit-label': '' });
  const label = fixed ? node('label', { for: 'form-name' }, ['称呼']) : node('span', {}, ['称呼']);
  input.labels = fixed ? [label] : [];
  const image = node('img', {
    'data-audit-id': 'room-image', 'data-audit-informative': '', ...(fixed && { alt: '阅览室入口旁的预约屏' }),
  });
  const help = node('button', {
    'data-audit-id': 'help-button', 'data-audit-name': '', ...(fixed && { 'aria-label': '预约帮助' }),
  }, [node('span', { 'aria-hidden': 'true' }, ['?'])]);
  const note = node('p', { 'data-audit-id': 'booking-note', 'data-audit-contrast': '' }, ['每人每天可预约一次。'],
    { color: fixed ? 'rgb(53, 74, 68)' : 'rgb(159, 169, 166)' });
  const title = node(fixed ? 'h3' : 'h4', { 'data-audit-id': 'booking-form-heading', 'data-audit-heading': '' }, ['预约']);
  return documentTree(node('h2', {}, ['阅览室']), image, help, title, label, input, note);
}

test('reports all five baseline targets with stable selectors and localized evidence', () => {
  const { totals, findings } = auditPreview(preview(false));
  assert.deepEqual(totals, { checked: 5, passed: 0, failed: 5 });
  assert.deepEqual(findings.map(item => [item.id, item.rule]), [
    ['booking-name', 'form-label'], ['room-image', 'image-alt'], ['help-button', 'button-name'],
    ['booking-note', 'text-contrast'], ['booking-form-heading', 'heading-order'],
  ]);
  for (const finding of findings) {
    assert.equal(finding.selector, `[data-audit-id="${finding.id}"]`);
    assert.ok(finding.title && finding.criterion && finding.evidence);
  }
  assert.match(findings[3].evidence, /2\.2\d:1/u);
  assert.match(findings[4].evidence, /h2.+h4/u);
});

test('keeps the same evaluation denominator when all five sample targets are repaired', () => {
  assert.deepEqual(auditPreview(preview(true)), { findings: [], totals: { checked: 5, passed: 5, failed: 0 } });
});

test('recognizes a referenced name and ignores marked targets inside hidden panels', () => {
  const name = node('span', { id: 'help-name' }, ['预约说明']);
  const help = node('button', { 'aria-labelledby': 'missing help-name', 'data-audit-name': '', 'data-audit-id': 'help' });
  const decorative = node('img', { alt: '' });
  const hidden = node('section', {}, [node('img', { 'data-audit-informative': '', 'data-audit-id': 'missing-hidden-alt' })], { display: 'none' });
  assert.deepEqual(auditPreview(documentTree(name, help, decorative, hidden)).totals, { checked: 1, passed: 1, failed: 0 });
});

test('calculates sRGB contrast with unrounded thresholds and transparent foreground', () => {
  assert.equal(contrastRatio('#000', '#fff'), 21);
  assert.equal(contrastRatio('#abc', '#abc'), 1);
  assert.equal(contrastRatio('transparent', '#fff'), 1);
  assert.ok(contrastRatio('rgba(0,0,0,0.5)', '#fff') > 3.9);
  assert.ok(contrastRatio('#767676', '#fff') > 4.5);
  assert.ok(contrastRatio('#777777', '#fff') < 4.5);
  assert.throws(() => contrastRatio('blue', '#fff'), TypeError);
  assert.throws(() => contrastRatio('#000', '#fff8'), TypeError);
});

test('evaluates translucent color layers but flags gradients for manual review', () => {
  const note = node('p', { 'data-audit-contrast': '', 'data-audit-id': 'note' }, ['说明'],
    { color: 'rgb(0, 0, 0)', backgroundColor: 'rgba(255, 255, 255, 0.2)' });
  const surface = node('article', {}, [note], { backgroundColor: 'rgb(255, 255, 255)' });
  const root = documentTree(surface);
  assert.equal(auditPreview(root).totals.passed, 1);
  surface.style.backgroundImage = 'linear-gradient(white, black)';
  assert.match(auditPreview(root).findings[0].evidence, /人工复核/u);
  note.style.backgroundColor = 'rgb(255, 255, 255)';
  assert.equal(auditPreview(root).totals.passed, 1);
  surface.style.opacity = '0.5';
  assert.match(auditPreview(root).findings[0].evidence, /人工复核/u);
});

test('refuses detached roots and duplicate or malformed evidence IDs', () => {
  assert.throws(() => auditPreview({}), /接入浏览器/u);
  const makeTarget = id => node('img', { 'data-audit-informative': '', 'data-audit-id': id });
  assert.throws(() => auditPreview(documentTree(makeTarget('quote"'))), /唯一/u);
  assert.throws(() => auditPreview(documentTree(makeTarget('duplicate'), makeTarget('duplicate'))), /唯一/u);
});
