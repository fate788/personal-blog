const HEADING = 'h1,h2,h3,h4,h5,h6';
const STANDARD_TEXT_CONTRAST = 4.5;
const TARGET_ID = /^[a-z][a-z0-9-]*$/u;

function colorChannels(value) {
  if (value === 'transparent') return [0, 0, 0, 0];
  if (/^#[\da-f]{3}(?:[\da-f])?$|^#[\da-f]{6}(?:[\da-f]{2})?$/iu.test(value)) {
    const hex = value.slice(1);
    const pairs = hex.length <= 4 ? [...hex].map(digit => digit.repeat(2)) : hex.match(/.{2}/gu);
    const [red, green, blue, alpha = 255] = pairs.map(pair => Number.parseInt(pair, 16));
    return [red, green, blue, alpha / 255];
  }
  const match = /^rgba?\(\s*(\d+(?:\.\d+)?)\s*,\s*(\d+(?:\.\d+)?)\s*,\s*(\d+(?:\.\d+)?)(?:\s*,\s*(\d*\.?\d+))?\s*\)$/u.exec(value);
  if (!match) return null;
  const channels = match.slice(1, 4).map(Number);
  const alpha = match[4] === undefined ? 1 : Number(match[4]);
  return channels.every(channel => channel <= 255) && alpha <= 1 ? [...channels, alpha] : null;
}

function blend(foreground, background) {
  const [red, green, blue, alpha] = foreground;
  return [red, green, blue].map((channel, index) => channel * alpha + background[index] * (1 - alpha));
}

function luminance(rgb) {
  const [red, green, blue] = rgb.map(channel => {
    const srgb = channel / 255;
    return srgb <= 0.04045 ? srgb / 12.92 : ((srgb + 0.055) / 1.055) ** 2.4;
  });
  return 0.2126 * red + 0.7152 * green + 0.0722 * blue;
}

/** Ratio for normal text on a resolved opaque sRGB surface. */
export function contrastRatio(foreground, background) {
  const ink = colorChannels(foreground);
  const paper = colorChannels(background);
  if (!ink || !paper || paper[3] !== 1) throw new TypeError('需要有效的 sRGB 文字颜色和不透明背景色。');
  return ratioForChannels(ink, paper);
}

function ratioForChannels(ink, paper) {
  const text = luminance(blend(ink, paper));
  const background = luminance(paper.slice(0, 3));
  return (Math.max(text, background) + 0.05) / (Math.min(text, background) + 0.05);
}

function present(element, getStyle) {
  if (element.hidden || element.getAttribute('aria-hidden') === 'true') return false;
  const style = getStyle(element);
  return style.display !== 'none' && style.visibility !== 'hidden' && style.visibility !== 'collapse';
}

function presentInPreview(element, root, getStyle) {
  for (let current = element; current; current = current.parentElement) {
    if (!present(current, getStyle)) return false;
    if (current === root) return true;
  }
  return false;
}

function contents(element, getStyle) {
  const words = [];
  for (const child of element.childNodes) {
    if (child.nodeType === 3) words.push(child.textContent);
    if (child.nodeType !== 1 || !present(child, getStyle)) continue;
    words.push(child.localName === 'img' ? child.getAttribute('alt') ?? '' : contents(child, getStyle));
  }
  return words.join(' ').trim();
}

// Resolve the label patterns used in the exercise. This does not emulate the accessible-name algorithm.
function authoredName(element, root) {
  const relationships = element.getAttribute('aria-labelledby')?.trim().split(/\s+/u) ?? [];
  const referencedText = relationships.map(id => {
    const target = root.ownerDocument.getElementById(id);
    return target && root.contains(target) ? target.textContent.trim() : '';
  }).filter(Boolean).join(' ');
  return referencedText || element.getAttribute('aria-label')?.trim() || '';
}

function computationForContrast(element, root, getStyle) {
  const foreground = colorChannels(getStyle(element).color);
  if (!foreground) return null;
  const layers = [];
  let paper = null;
  for (let current = element; current; current = current.parentElement) {
    const style = getStyle(current);
    if (Number(style.opacity) !== 1) return null;
    if (!paper) {
      if (style.backgroundImage !== 'none') return null;
      const color = colorChannels(style.backgroundColor);
      if (!color) return null;
      if (color[3] === 1) paper = layers.reverse().reduce((opaque, layer) => blend(layer, opaque), color);
      else if (color[3] > 0) layers.push(color);
    }
    if (current === root) break;
  }
  return paper ? ratioForChannels(foreground, paper) : null;
}

function headingLevels(root, getStyle) {
  let previous = null;
  const observation = new Map();
  for (const element of root.querySelectorAll(HEADING)) {
    if (!presentInPreview(element, root, getStyle)) continue;
    const level = Number(element.localName.slice(1));
    observation.set(element, { previous, level });
    previous = level;
  }
  return observation;
}

const CHECKS = [
  {
    marker: '[data-audit-label]', rule: 'form-label', title: '预约控件缺少关联标签', criterion: '1.3.1 / 4.1.2',
    assess(element, root, getStyle) {
      const named = authoredName(element, root) || [...(element.labels ?? [])]
        .some(label => root.contains(label) && presentInPreview(label, root, getStyle) && contents(label, getStyle));
      return named ? '' : '找不到关联的文字标签。相邻的提示文字没有通过 label 或 ARIA 与控件关联。';
    },
  },
  {
    marker: '[data-audit-informative]', rule: 'image-alt', title: '说明图片缺少替代文字', criterion: '1.1.1',
    assess(element) {
      return element.getAttribute('alt')?.trim() ? '' : '标为提供信息的图片缺少非空 alt，图片信息无法从此属性获得。';
    },
  },
  {
    marker: '[data-audit-name]', rule: 'button-name', title: '帮助按钮缺少可读名称', criterion: '4.1.2',
    assess(element, root, getStyle) {
      const name = authoredName(element, root) || contents(element, getStyle) || element.getAttribute('title')?.trim();
      return name ? '' : '帮助按钮只有隐藏于辅助技术的图标，找不到按钮文字或明确的名称。';
    },
  },
  {
    marker: '[data-audit-contrast]', rule: 'text-contrast', title: '说明文字对比度不足或待复核', criterion: '1.4.3',
    assess(element, root, getStyle) {
      const ratio = computationForContrast(element, root, getStyle);
      if (ratio === null) return '无法取得可计算的纯色背景，需人工复核这段文字。';
      if (ratio >= STANDARD_TEXT_CONTRAST) return '';
      const displayed = (Math.floor(ratio * 100) / 100).toFixed(2);
      return `文字对比度为 ${displayed}:1，低于普通文字的 4.5:1 参考阈值。`;
    },
  },
  {
    marker: '[data-audit-heading]', rule: 'heading-order', title: '预约区域标题跳级', criterion: '1.3.1（层级复核提示）',
    assess(element, _root, _getStyle, headings) {
      const detail = headings.get(element);
      if (!detail) return '未在走查区域内找到原生标题元素。';
      const { previous, level } = detail;
      return previous && level > previous + 1 ? `从 h${previous} 跳到 h${level}，请核对预约区块的标题层级。` : '';
    },
  },
];

/** Evaluate the annotated targets in a mounted sample and return portable evidence. */
export function auditPreview(root) {
  const view = root?.ownerDocument?.defaultView;
  if (!view || !root.isConnected) throw new TypeError('请先将样例接入浏览器文档。');
  const getStyle = element => view.getComputedStyle(element);
  const headings = headingLevels(root, getStyle);
  const findings = [];
  const ids = new Set();
  let checked = 0;
  for (const { marker, rule, title, criterion, assess } of CHECKS) {
    for (const element of root.querySelectorAll(marker)) {
      if (!presentInPreview(element, root, getStyle)) continue;
      const id = element.getAttribute('data-audit-id');
      if (!id || !TARGET_ID.test(id) || ids.has(id)) throw new TypeError('走查目标需要唯一的 data-audit-id。');
      ids.add(id);
      checked += 1;
      const evidence = assess(element, root, getStyle, headings);
      if (evidence) findings.push({ id, rule, selector: `[data-audit-id="${id}"]`, title, criterion, evidence });
    }
  }
  const failed = findings.length;
  return { findings, totals: { checked, passed: checked - failed, failed } };
}
