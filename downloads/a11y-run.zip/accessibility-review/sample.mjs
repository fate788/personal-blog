const SLOTS = Object.freeze([
  ['morning', '09:00–10:30'],
  ['midday', '11:00–12:30'],
  ['afternoon', '14:00–15:30'],
]);

function node(tag, className, text) {
  const element = document.createElement(tag);
  if (className) element.className = className;
  if (text) element.textContent = text;
  return element;
}

function hero(fixed) {
  const section = node('header', 'sample-hero');
  const photo = node('img', 'sample-photo');
  photo.src = './media/reading-room.webp';
  photo.dataset.auditInformative = '';
  photo.dataset.auditId = 'room-image';
  if (fixed) photo.alt = '图书馆二层静读室，长桌沿窗排列，桌间留有通道。';

  const copy = node('div', 'sample-hero-copy');
  copy.append(
    node('p', 'sample-kicker', '砚池图书馆 · 二层'),
    node('h2', 'sample-title', '静读室预约'),
    node('p', 'sample-subtitle', '挑一个时段，留出一段安静阅读的时间。'),
  );

  const button = node('button', 'sample-help-button');
  button.type = 'button';
  button.dataset.auditName = '';
  button.dataset.auditId = 'help-button';
  button.setAttribute('aria-expanded', 'false');
  button.setAttribute('aria-controls', 'sample-booking-help');
  if (fixed) button.setAttribute('aria-label', '预约说明');
  const icon = node('span', 'sample-help-icon', '?');
  icon.setAttribute('aria-hidden', 'true');
  button.append(icon);
  section.append(photo, copy, button);

  const help = node('p', 'sample-help', '请提前 10 分钟到二层服务台，出示预约时填写的姓名。每个时段限预约一个座位。');
  help.id = 'sample-booking-help';
  help.hidden = true;
  button.addEventListener('click', () => {
    help.hidden = !help.hidden;
    button.setAttribute('aria-expanded', String(!help.hidden));
  });

  return [section, help];
}

function form(fixed) {
  const section = node('form', 'sample-form');
  section.noValidate = true;
  const heading = node(fixed ? 'h3' : 'h4', 'sample-section-title', '选择预约信息');
  heading.dataset.auditHeading = '';
  heading.dataset.auditId = 'booking-form-heading';
  const date = node('time', 'sample-date', '12 月 2 日 · 周三');
  date.dateTime = '2026-12-02';
  const titleRow = node('div', 'sample-section-heading');
  titleRow.append(heading, date);

  const grid = node('div', 'sample-form-grid');
  const nameField = node('div', 'sample-field');
  const name = node('input', 'sample-input');
  name.type = 'text';
  name.id = 'sample-name';
  name.maxLength = 24;
  name.required = true;
  name.autocomplete = 'off';
  name.dataset.auditLabel = '';
  name.dataset.auditId = 'booking-name';
  const nameLabel = node(fixed ? 'label' : 'span', 'sample-label', '预约姓名');
  if (fixed) nameLabel.htmlFor = name.id;
  nameField.append(nameLabel, name);

  const slotField = node('div', 'sample-field');
  const slot = node('select', 'sample-input sample-select');
  slot.id = 'sample-slot';
  const timeLabel = node('label', 'sample-label', '入场时段');
  timeLabel.htmlFor = slot.id;
  for (const [value, label] of SLOTS) {
    const option = node('option', '', label);
    option.value = value;
    slot.append(option);
  }
  slotField.append(timeLabel, slot);
  grid.append(nameField, slotField);

  const note = node('p', 'sample-note', '每次预约 90 分钟。离场时请带走随身物品。');
  note.dataset.auditContrast = '';
  note.dataset.auditId = 'booking-note';

  const error = node('p', 'sample-error');
  error.id = 'sample-error';
  error.hidden = true;
  const errorRegion = node('div');
  if (fixed) errorRegion.setAttribute('role', 'alert');
  errorRegion.append(error);

  const actions = node('div', 'sample-actions');
  const book = node('button', 'sample-submit', '确认预约');
  book.type = 'submit';
  actions.append(book);

  const result = node('p', 'sample-result');
  result.hidden = true;
  const resultRegion = node('div');
  if (fixed) resultRegion.setAttribute('role', 'status');
  resultRegion.append(result);

  function clearError() {
    error.hidden = true;
    error.textContent = '';
    name.removeAttribute('aria-invalid');
    name.removeAttribute('aria-describedby');
  }

  function clearResult() {
    result.hidden = true;
    result.textContent = '';
  }

  name.addEventListener('input', () => {
    if (name.value.trim()) clearError();
    clearResult();
  });
  slot.addEventListener('change', clearResult);
  section.addEventListener('submit', event => {
    event.preventDefault();
    const reader = name.value.trim();
    if (!reader) {
      clearResult();
      if (fixed) {
        name.setAttribute('aria-invalid', 'true');
        name.setAttribute('aria-describedby', error.id);
      }
      error.hidden = false;
      error.textContent = '请输入预约姓名。';
      name.focus();
      return;
    }
    clearError();
    const time = slot.selectedOptions[0].textContent;
    result.hidden = false;
    result.textContent = `${reader}，预约已确认。12 月 2 日 ${time}，砚池图书馆二层静读室。`;
  });
  section.append(titleRow, grid, note, errorRegion, actions, resultRegion);
  return section;
}

export function renderSample(host, version) {
  if (version !== 'baseline' && version !== 'fixed') throw new RangeError('预约样例版本无效。');
  const fixed = version === 'fixed';
  const preview = node('div', `sample-booking sample-${version}`);
  preview.append(...hero(fixed), form(fixed));
  host.replaceChildren(preview);
  return preview;
}
