export const MAX_INPUT_BYTES = 256 * 1024;

const WINDOW_MINUTES = 5;
const MAX_WINDOWS = 288;
const MAX_WINDOW_REQUESTS = 1_000_000_000;
const DECIMAL_SCALE = 1_000;

export const DEFAULT_POLICY = Object.freeze({
  minRequests: 200,
  maxErrorDeltaPp: 1,
  maxLatencyRatio: 1.3,
  healthyWindows: 3,
  badWindows: 2,
});

function object(value, label) {
  if (!value || typeof value !== 'object' || Array.isArray(value)) throw new TypeError(`${label}应为对象。`);
  return value;
}

function label(value, name) {
  if (typeof value !== 'string' || /[\x00-\x1f\x7f]/u.test(value) || !value.trim() || value.trim().length > 80) {
    throw new TypeError(`${name}应为 1 到 80 字的单行文字。`);
  }
  return value.trim();
}

function integer(value, min, max, name) {
  if (!Number.isInteger(value) || value < min || value > max) throw new TypeError(`${name}应为 ${min} 到 ${max} 的整数。`);
  return value;
}

function decimal(value, min, max, name) {
  if (!Number.isFinite(value) || value < min || value > max || Math.round(value * DECIMAL_SCALE) / DECIMAL_SCALE !== value) {
    throw new TypeError(`${name}应在 ${min} 到 ${max} 之间，最多保留三位小数。`);
  }
  return value;
}

function cohort(value, name) {
  if (value === null) return null;
  object(value, name);
  const requests = integer(value.requests, 0, MAX_WINDOW_REQUESTS, `${name}请求数`);
  const errors = integer(value.errors, 0, requests, `${name}错误数`);
  const p95Ms = value.p95Ms === null ? null : decimal(value.p95Ms, 1, 120_000, `${name} P95 毫秒数`);
  if (requests === 0 && p95Ms !== null) throw new TypeError(`${name}零请求时，P95 应填写 null。`);
  return { requests, errors, p95Ms };
}

function normalizedRelease(input) {
  const release = object(input, '发布记录');
  const name = label(release.name, '发布名称');
  const service = label(release.service, '服务名称');
  const stableVersion = label(release.stableVersion, '稳定版');
  const canaryVersion = label(release.canaryVersion, '候选版');
  if (stableVersion === canaryVersion) throw new TypeError('稳定版和候选版应使用不同版本。');
  if (!Array.isArray(release.windows) || release.windows.length < 1 || release.windows.length > MAX_WINDOWS) {
    throw new TypeError(`发布应包含 1 到 ${MAX_WINDOWS} 个观察窗口。`);
  }
  const windows = release.windows.map((inputWindow, index) => {
    const name = `第 ${index + 1} 个窗口`;
    const window = object(inputWindow, name);
    const minute = index * WINDOW_MINUTES;
    if (window.minute !== minute) {
      throw new TypeError(`${name}应位于第 ${minute} 分钟。时间从 0 开始，每五分钟一条，缺测版本填写 null。`);
    }
    return {
      minute,
      traffic: integer(window.traffic, 1, 100, `${name}的候选版流量百分比`),
      stable: cohort(window.stable, `${name}稳定版`),
      canary: cohort(window.canary, `${name}候选版`),
    };
  });
  return { name, service, stableVersion, canaryVersion, windows };
}

function normalizedPolicy(input) {
  const policy = object(input, '灰度规则');
  return {
    minRequests: integer(policy.minRequests, 1, 1_000_000, '每版最小请求数'),
    maxErrorDeltaPp: decimal(policy.maxErrorDeltaPp, 0, 100, '错误率差上限'),
    maxLatencyRatio: decimal(policy.maxLatencyRatio, 1, 20, 'P95 倍率上限'),
    healthyWindows: integer(policy.healthyWindows, 1, 60, '连续健康窗口数'),
    badWindows: integer(policy.badWindows, 1, 60, '连续越限窗口数'),
  };
}

export function parseRelease(text) {
  if (typeof text !== 'string') throw new TypeError('请输入 JSON 发布记录。');
  if (text.length > MAX_INPUT_BYTES || new TextEncoder().encode(text).length > MAX_INPUT_BYTES) {
    throw new TypeError('发布记录不能超过 256 KiB。');
  }
  let input;
  try {
    input = JSON.parse(text.replace(/^\uFEFF/u, ''));
  } catch {
    throw new TypeError('请输入有效的 JSON 发布记录。');
  }
  return normalizedRelease(input);
}

const scale = value => BigInt(Math.round(value * DECIMAL_SCALE));
const exactScale = BigInt(DECIMAL_SCALE);

function comparisons(stable, canary, thresholds) {
  let errorDeltaPp = null;
  let latencyRatio = null;
  let errorBreach = false;
  let latencyBreach = false;
  if (stable?.requests > 0 && canary?.requests > 0) {
    // Compare the rational difference before rounding it for presentation.
    const denominator = BigInt(stable.requests) * BigInt(canary.requests);
    const numerator = 100n * (BigInt(canary.errors) * BigInt(stable.requests) - BigInt(stable.errors) * BigInt(canary.requests));
    errorDeltaPp = Number(numerator) / Number(denominator);
    errorBreach = numerator * exactScale > denominator * thresholds.error;
  }
  if (stable?.p95Ms > 0 && canary?.p95Ms > 0) {
    latencyRatio = canary.p95Ms / stable.p95Ms;
    latencyBreach = scale(canary.p95Ms) * exactScale > scale(stable.p95Ms) * thresholds.latency;
  }
  return { errorDeltaPp, latencyRatio, errorBreach, latencyBreach };
}

function breachReason(name, value, limit, unit) {
  const measurement = value.toFixed(3);
  if (Number(measurement) <= limit) return `${name}按未舍入值比较，略高于 ${limit} ${unit}。`;
  return `${name} ${measurement} ${unit}，超过 ${limit} ${unit}。`;
}

function assess(window, policy, thresholds) {
  const { stable, canary } = window;
  const { errorDeltaPp, latencyRatio, errorBreach, latencyBreach } = comparisons(stable, canary, thresholds);
  const reasons = [];
  for (const [label, observed] of [['稳定版', stable], ['候选版', canary]]) {
    if (!observed) {
      reasons.push(`${label}缺少本窗口观测。`);
      continue;
    }
    if (observed.requests < policy.minRequests) reasons.push(`${label}只有 ${observed.requests} 次请求，少于 ${policy.minRequests} 次。`);
    if (observed.p95Ms === null) reasons.push(`${label}缺少本窗口 P95 延迟。`);
  }
  if (reasons.length) return { errorDeltaPp, latencyRatio, state: 'insufficient', reasons };
  if (errorBreach) reasons.push(breachReason('错误率差', errorDeltaPp, policy.maxErrorDeltaPp, '个百分点'));
  if (latencyBreach) reasons.push(breachReason('候选与稳定版的 P95 延迟之比', latencyRatio, policy.maxLatencyRatio, '倍'));
  if (reasons.length) return { errorDeltaPp, latencyRatio, state: 'breach', reasons };
  return { errorDeltaPp, latencyRatio, state: 'healthy', reasons: ['两组请求量充足，错误率差和 P95 延迟倍率均在规则范围内。'] };
}

export function evaluateRelease(release, inputPolicy = DEFAULT_POLICY) {
  const policy = normalizedPolicy(inputPolicy);
  const { windows } = normalizedRelease(release);
  const thresholds = { error: scale(policy.maxErrorDeltaPp), latency: scale(policy.maxLatencyRatio) };
  let previousTraffic = null;
  let healthyStreak = 0;
  let badStreak = 0;
  let rollbackAt = null;

  const evaluated = windows.map(window => {
    const assessment = assess(window, policy, thresholds);
    if (window.traffic !== previousTraffic) {
      healthyStreak = 0;
      badStreak = 0;
    }
    previousTraffic = window.traffic;
    healthyStreak = assessment.state === 'healthy' ? healthyStreak + 1 : 0;
    badStreak = assessment.state === 'breach' ? badStreak + 1 : 0;
    if (rollbackAt === null && badStreak >= policy.badWindows) rollbackAt = window.minute;

    let decision = 'hold';
    if (rollbackAt !== null) {
      decision = 'rollback';
      if (rollbackAt === window.minute) assessment.reasons.push(`连续 ${badStreak} 个窗口越限，建议回滚。`);
      else assessment.reasons.push(`第 ${rollbackAt} 分钟已触发回滚建议，本次回放保留该结论。`);
    } else if (healthyStreak >= policy.healthyWindows) {
      if (window.traffic < 100) {
        decision = 'expand';
        assessment.reasons.push(`当前流量阶段已连续 ${healthyStreak} 个窗口健康，可以评估扩大流量。`);
      } else assessment.reasons.push('候选版流量已达到 100%，没有可扩大的流量。');
    } else if (assessment.state === 'healthy') {
      assessment.reasons.push(`连续健康窗口 ${healthyStreak}/${policy.healthyWindows}，继续观察。`);
    } else if (assessment.state === 'breach') {
      assessment.reasons.push(`连续越限窗口 ${badStreak}/${policy.badWindows}，继续观察。`);
    }

    return { ...window, ...assessment, healthyStreak, badStreak, decision };
  });
  const lastWindow = evaluated.at(-1);
  return { policy, windows: evaluated, decision: lastWindow.decision, lastWindow, rollbackAt };
}
