import { DEFAULT_POLICY, MAX_INPUT_BYTES, evaluateRelease, parseRelease } from '../engine.mjs';
import { DEMO_REGRESSION, DEMO_HEALTHY, DEMO_SPARSE } from '../fixtures.mjs';

const CASES = { regression: DEMO_REGRESSION, healthy: DEMO_HEALTHY, sparse: DEMO_SPARSE };
const RULE_INPUTS = {
  minRequests: 'min-requests', maxErrorDeltaPp: 'max-error-delta', maxLatencyRatio: 'max-latency-ratio',
  healthyWindows: 'healthy-windows', badWindows: 'bad-windows',
};
const STATES = { healthy: '窗口健康', breach: '指标越线', insufficient: '观测不足' };
const DECISIONS = { hold: '继续观察', expand: '建议扩大流量', rollback: '建议回滚' };
const $ = id => document.getElementById(id);
const number = new Intl.NumberFormat('zh-CN', { maximumFractionDigits: 3 });
const state = { example: null, release: null, result: null, index: 0, timer: null, frame: null, importSequence: 0 };

function element(tag, className, text) {
  const result = document.createElement(tag);
  if (className) result.className = className;
  if (text != null) result.textContent = text;
  return result;
}

function announce(message = '', tone = 'info') {
  const target = $('notice');
  target.textContent = message;
  target.dataset.tone = tone;
  target.hidden = !message;
}

function showPolicyError(message = '') {
  const target = $('policy-error');
  target.textContent = message;
  target.hidden = !message;
}

function showInputs(policy) {
  for (const [key, id] of Object.entries(RULE_INPUTS)) $(id).value = policy[key];
}

function readInputs() {
  const policy = {};
  for (const [key, id] of Object.entries(RULE_INPUTS)) {
    const input = $(id);
    if (!input.checkValidity() || !Number.isFinite(input.valueAsNumber)) {
      input.focus();
      throw new Error(`请检查「${input.labels[0].textContent.trim()}」的范围及精度。`);
    }
    policy[key] = input.valueAsNumber;
  }
  return policy;
}

const elapsed = value => `T+${value} 分钟`;
const selected = () => state.result.windows[state.index];
const rate = cohort => cohort?.requests ? cohort.errors / cohort.requests * 100 : null;
const rateText = value => value === null ? '—' : `${value.toFixed(2)}%`;
const msText = value => value == null ? '—' : `${number.format(value)} ms`;

function initialIndex(result, example) {
  if (result.decision === 'rollback') return result.windows.findIndex(window => window.minute === result.rollbackAt);
  if (result.decision === 'expand') return result.windows.findIndex(window => window.decision === 'expand' && window.traffic === result.lastWindow.traffic);
  if (example === 'sparse') {
    const missing = result.windows.findIndex(window => window.canary === null || window.stable === null);
    if (missing >= 0) return missing;
  }
  return result.windows.length - 1;
}

function showRelease(release, example, policy) {
  const result = evaluateRelease(release, policy);
  stopReplay();
  state.release = release;
  state.result = result;
  state.example = example;
  state.index = Math.max(0, initialIndex(result, example));
  for (const control of document.querySelectorAll('[data-case]')) {
    control.setAttribute('aria-pressed', String(control.dataset.case === example));
  }
  $('release-title').textContent = release.name;
  $('release-service').textContent = release.service;
  $('control-version').textContent = release.stableVersion;
  $('candidate-version').textContent = release.canaryVersion;
  $('dataset-source').textContent = `${example ? '合成发布样例' : '本地导入'} · ${result.windows.length} 个观测窗口`;
  $('download-report').disabled = false;
  $('download-workspace').disabled = false;
  showInputs(result.policy);
  renderTimeline();
  renderCurrent();
}

function story(window) {
  if (window.decision === 'rollback') return `${elapsed(state.result.rollbackAt)}触发，本次回放保留该建议`;
  if (window.decision === 'expand') return `当前 ${window.traffic}% 阶段达到连续健康条件`;
  if (window.state === 'insufficient') return '待请求量或指标齐备后再评估';
  if (window.state === 'breach') return '回滚所需连续越线窗尚未达到';
  if (window.traffic === 100) return '候选已承接全部流量';
  return `当前 ${window.traffic}% 阶段继续收集健康窗口`;
}

function renderTimeline() {
  const nodes = state.result.windows.map((window, index, windows) => {
    const button = element('button', 'window-button');
    const stage = index === 0 || windows[index - 1].traffic !== window.traffic;
    button.type = 'button';
    button.dataset.windowIndex = index;
    button.dataset.state = window.state;
    button.dataset.decision = window.decision;
    button.dataset.stage = stage;
    button.setAttribute('aria-pressed', 'false');
    button.setAttribute('aria-label', `${elapsed(window.minute)}，候选流量 ${window.traffic}% ，${STATES[window.state]}，${DECISIONS[window.decision]}`);
    const dot = element('span', 'window-dot');
    dot.setAttribute('aria-hidden', 'true');
    button.append(element('span', 'window-clock', `+${window.minute}`), dot,
      element('span', 'window-step', `${window.traffic}%${stage ? ' 起' : ''}`));
    return button;
  });
  $('window-track').replaceChildren(...nodes);
}

function fitSelectedWindow() {
  const track = $('window-track');
  const item = track.children[state.index];
  const { left, right } = item.getBoundingClientRect();
  const bounds = track.getBoundingClientRect();
  if (left < bounds.left || right > bounds.right) {
    track.scrollLeft += (left + right - bounds.left - bounds.right) / 2;
  }
}

function renderCurrent() {
  const window = selected();
  const { policy, windows } = state.result;
  const { stable, canary } = window;
  $('decision').dataset.decision = window.decision;
  $('decision-label').textContent = DECISIONS[window.decision];
  $('decision-context').textContent = story(window);
  $('window-minute').textContent = elapsed(window.minute);
  $('window-minute').dateTime = `PT${window.minute}M`;
  $('window-traffic').textContent = `${window.traffic}% 候选流量`;
  $('window-state').textContent = STATES[window.state];
  $('window-state').dataset.state = window.state;
  $('error-delta').textContent = window.errorDeltaPp == null ? '差值未知' : `${window.errorDeltaPp > 0 ? '+' : ''}${window.errorDeltaPp.toFixed(2)} pp`;
  $('latency-ratio').textContent = window.latencyRatio == null ? '倍率未知' : `${window.latencyRatio.toFixed(2)}×`;
  $('healthy-streak').textContent = `${window.healthyStreak} / ${policy.healthyWindows}`;
  $('bad-streak').textContent = `${window.badStreak} / ${policy.badWindows}`;
  $('policy-summary').textContent = `最少 ${number.format(policy.minRequests)} 次 / 组`;
  $('error-summary').textContent = `${elapsed(window.minute)}，稳定版错误率 ${rateText(rate(stable))}，候选版 ${rateText(rate(canary))}。`;
  $('latency-summary').textContent = `${elapsed(window.minute)}，稳定版 P95 ${msText(stable?.p95Ms)}，候选版 ${msText(canary?.p95Ms)}。`;
  $('previous-window').disabled = state.index === 0;
  $('next-window').disabled = state.index === windows.length - 1;
  $('play-toggle').disabled = windows.length < 2;
  for (const [index, control] of [...$('window-track').children].entries()) {
    control.setAttribute('aria-pressed', String(state.index === index));
    control.tabIndex = state.index === index ? 0 : -1;
  }
  fitSelectedWindow();

  const format = value => value == null ? '—' : number.format(value);
  const table = [
    ['总请求', format(stable?.requests), format(canary?.requests)],
    ['5xx 错误', format(stable?.errors), format(canary?.errors)],
    ['错误率', rateText(rate(stable)), rateText(rate(canary))],
    ['P95 延迟', msText(stable?.p95Ms), msText(canary?.p95Ms)],
  ];
  $('cohort-metrics').replaceChildren(...table.map(row => {
    const tr = element('tr');
    tr.append(...row.map(cell => element('td', '', cell)));
    return tr;
  }));
  $('evidence-list').replaceChildren(...window.reasons.map(reason => element('li', '', reason)));
  queueDraw();
}

const SERIES = [{ key: 'stable', label: '稳定版', color: '#71d6e1' }, { key: 'canary', label: '候选版', color: '#b9a3fb' }];

function topScale(values, minimum) {
  const target = Math.max(minimum, ...values.filter(value => value != null));
  const unit = 10 ** Math.floor(Math.log10(target / 4));
  const step = [1, 2, 2.5, 5, 10].find(size => 4 * size * unit >= target);
  return 4 * step * unit;
}

function trace(context, data, x, y, color, current) {
  context.strokeStyle = color;
  context.lineWidth = 2;
  for (const [index, value] of data.entries()) {
    if (value == null) continue;
    context.globalAlpha = index <= state.index ? .95 : .49;
    const previous = data[index - 1];
    if (previous != null) {
      context.beginPath();
      context.moveTo(x(index - 1), y(previous));
      context.lineTo(x(index), y(value));
      context.stroke();
    }
    context.fillStyle = color;
    context.beginPath();
    context.arc(x(index), y(value), index === current ? 4 : 2.2, 0, Math.PI * 2);
    context.fill();
  }
  context.globalAlpha = 1;
}

function drawChart(canvas, sample, labels, minimum) {
  const { width, height } = canvas.getBoundingClientRect();
  if (!width || !height) return;
  const ratio = Math.min(window.devicePixelRatio || 1, 2);
  canvas.width = Math.round(width * ratio);
  canvas.height = Math.round(height * ratio);
  const context = canvas.getContext('2d');
  context.setTransform(ratio, 0, 0, ratio, 0, 0);
  const windows = state.result.windows;
  const points = SERIES.map(({ key }) => windows.map(window => sample(window[key])));
  const upper = topScale(points.flat(), minimum);
  const left = width <= 330 ? 37 : 46;
  const right = width - 12;
  const top = 39;
  const bottom = height - 23;
  const x = index => windows.length === 1 ? (left + right) / 2 : left + index / (windows.length - 1) * (right - left);
  const y = value => bottom - value / upper * (bottom - top);

  context.font = '10px Consolas, monospace';
  context.fillStyle = '#a7bed1';
  context.textBaseline = 'middle';
  for (let row = 0; row <= 4; row += 1) {
    const value = row * upper / 4;
    context.textAlign = 'right';
    context.fillText(labels(value), left - 6, y(value));
    context.strokeStyle = '#293b4e';
    context.beginPath();
    context.moveTo(left, y(value) + .5);
    context.lineTo(right, y(value) + .5);
    context.stroke();
  }

  const cursorX = x(state.index);
  context.fillStyle = '#93aee222';
  context.fillRect(Math.max(left, cursorX - 7), top, Math.min(14, right - Math.max(left, cursorX - 7)), bottom - top);
  context.strokeStyle = '#80a4bf';
  context.setLineDash([2, 3]);
  context.beginPath();
  context.moveTo(cursorX, top);
  context.lineTo(cursorX, bottom);
  context.stroke();

  context.font = '10px "Microsoft YaHei UI", sans-serif';
  const interval = Math.max(1, Math.ceil(windows.length / (width < 450 ? 5 : 9)));
  for (const [index, window] of windows.entries()) {
    if (index > 0 && window.traffic !== windows[index - 1].traffic) {
      context.strokeStyle = '#7c6fa4';
      context.setLineDash([3, 4]);
      context.beginPath();
      context.moveTo(x(index), top);
      context.lineTo(x(index), bottom);
      context.stroke();
      if (windows.length <= 15) {
        context.textAlign = x(index) > right - 55 ? 'right' : 'left';
        context.fillStyle = '#d7c7fa';
        context.fillText(`${window.traffic}% 阶段`, x(index) + (x(index) > right - 55 ? -4 : 4), top - 5);
      }
    }
    const isLast = index === windows.length - 1;
    if ((!isLast && index % interval === 0 && windows.length - 1 - index >= interval * .66) || isLast) {
      context.textAlign = index === 0 ? 'left' : isLast ? 'right' : 'center';
      context.fillStyle = '#a7bed1';
      context.fillText(`+${window.minute}`, x(index), bottom + 13);
    }
  }
  context.setLineDash([]);
  SERIES.forEach(({ label, color }, index) => {
    const start = left + index * 74;
    context.lineWidth = 2;
    context.strokeStyle = color;
    context.beginPath();
    context.moveTo(start, 14);
    context.lineTo(start + 12, 14);
    context.stroke();
    context.textAlign = 'left';
    context.fillStyle = '#c7d6e5';
    context.fillText(label, start + 16, 14);
    trace(context, points[index], x, y, color, state.index);
  });
}

function queueDraw() {
  if (state.frame != null || !state.result) return;
  state.frame = requestAnimationFrame(() => {
    state.frame = null;
    drawChart($('error-chart'), rate, value => `${number.format(value)}%`, 0.04);
    drawChart($('latency-chart'), cohort => cohort?.p95Ms ?? null, value => number.format(value), 100);
  });
}

function selectIndex(index) {
  if (!Number.isInteger(index) || index < 0 || index >= state.result.windows.length || state.index === index) return;
  state.index = index;
  renderCurrent();
}

function stopReplay() {
  if (state.timer != null) clearInterval(state.timer);
  state.timer = null;
  $('play-toggle').textContent = '回放';
  $('play-toggle').setAttribute('aria-pressed', 'false');
}

function toggleReplay() {
  if (state.timer != null) {
    stopReplay();
    return;
  }
  if (state.index === state.result.windows.length - 1) selectIndex(0);
  $('play-toggle').textContent = '暂停';
  $('play-toggle').setAttribute('aria-pressed', 'true');
  state.timer = setInterval(() => {
    selectIndex(state.index + 1);
    if (state.index === state.result.windows.length - 1) stopReplay();
  }, 750);
}

function changePolicy(policy) {
  const result = evaluateRelease(state.release, policy);
  stopReplay();
  state.result = result;
  showInputs(result.policy);
  renderTimeline();
  renderCurrent();
}

function download(data, filename) {
  const payload = new Blob([`${JSON.stringify(data, null, 2)}\n`], { type: 'application/json;charset=utf-8' });
  const url = URL.createObjectURL(payload);
  const anchor = element('a');
  anchor.href = url;
  anchor.download = filename;
  document.body.append(anchor);
  anchor.click();
  anchor.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1_000);
}

function exportReport() {
  const { name, service, stableVersion, canaryVersion } = state.release;
  download({ release: { name, service, stableVersion, canaryVersion }, selectedMinute: selected().minute,
    ...state.result }, '灰度发布决策报告.json');
}

async function importRelease(event) {
  const input = event.currentTarget;
  const file = input.files[0];
  input.value = '';
  if (!file) return;
  const sequence = ++state.importSequence;
  try {
    if (file.size > MAX_INPUT_BYTES) throw new Error('请选择不超过 256 KiB 的 JSON 文件。');
    const buffer = await file.arrayBuffer();
    if (state.importSequence !== sequence) return;
    let text;
    try { text = new TextDecoder('utf-8', { fatal: true }).decode(buffer); }
    catch { throw new Error('文件需要使用 UTF-8 编码。'); }
    let raw;
    try { raw = JSON.parse(text); }
    catch { throw new Error('文件需要包含有效的 JSON。'); }
    const wrapped = raw && typeof raw === 'object' && Object.hasOwn(raw, 'release');
    const release = parseRelease(wrapped ? JSON.stringify(raw.release) : text);
    showRelease(release, null, wrapped && Object.hasOwn(raw, 'policy') ? raw.policy : state.result.policy);
    showPolicyError();
    announce(`已导入 ${file.name}。`);
  } catch (error) {
    if (state.importSequence === sequence) announce(error.message || '读取工作区失败。', 'error');
  }
}

function manualWindow(index) {
  stopReplay();
  selectIndex(index);
}

$('window-track').addEventListener('click', event => {
  const item = event.target.closest('[data-window-index]');
  if (item) manualWindow(Number(item.dataset.windowIndex));
});
$('window-track').addEventListener('keydown', event => {
  if (!event.target.matches('[data-window-index]')) return;
  const offsets = { ArrowLeft: state.index - 1, ArrowRight: state.index + 1, Home: 0, End: state.result.windows.length - 1 };
  if (!Object.hasOwn(offsets, event.key)) return;
  event.preventDefault();
  manualWindow(offsets[event.key]);
  $('window-track').children[state.index].focus();
});
$('previous-window').addEventListener('click', () => manualWindow(state.index - 1));
$('next-window').addEventListener('click', () => manualWindow(state.index + 1));
$('play-toggle').addEventListener('click', toggleReplay);
document.querySelector('.scenario-switch').addEventListener('click', event => {
  const example = event.target.closest('[data-case]')?.dataset.case;
  if (!example || example === state.example) return;
  state.importSequence += 1;
  showRelease(CASES[example], example, state.result.policy);
  showPolicyError();
  announce();
});
$('policy-form').addEventListener('submit', event => {
  event.preventDefault();
  try {
    changePolicy(readInputs());
    showPolicyError();
    announce('已使用当前规则重算发布窗口。');
  } catch (error) {
    showPolicyError(error.message);
  }
});
$('reset-policy').addEventListener('click', () => {
  changePolicy(DEFAULT_POLICY);
  showPolicyError();
  announce('已恢复默认规则并重算。');
});
$('pick-release').addEventListener('click', () => $('import-release').click());
$('import-release').addEventListener('change', importRelease);
$('download-report').addEventListener('click', exportReport);
$('download-workspace').addEventListener('click', () => download({ release: state.release, policy: state.result.policy }, '灰度发布工作区.json'));

const observer = new ResizeObserver(queueDraw);
for (const canvas of document.querySelectorAll('canvas')) observer.observe(canvas);
const query = new URLSearchParams(location.search).get('case');
const example = Object.hasOwn(CASES, query) ? query : 'regression';
showRelease(CASES[example], example, DEFAULT_POLICY);
