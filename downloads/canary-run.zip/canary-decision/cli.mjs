import { constants } from 'node:fs';
import { open, stat, unlink } from 'node:fs/promises';
import { DEFAULT_POLICY, MAX_INPUT_BYTES, evaluateRelease, parseRelease } from './engine.mjs';
import { DEMO_HEALTHY, DEMO_REGRESSION, DEMO_SPARSE } from './fixtures.mjs';

const DEMOS = new Map([
  ['regression', DEMO_REGRESSION], ['healthy', DEMO_HEALTHY], ['sparse', DEMO_SPARSE],
]);
const EXIT_CODES = new Map([['expand', 0], ['rollback', 2], ['hold', 3]]);
const OPTIONS = new Set(['--demo', '--case', '--input', '--out', '--min-requests']);
const INPUT_LIMIT_KIB = MAX_INPUT_BYTES / 1024;
const HELP = `灰度发布决策台 · 离线命令行

node cli.mjs --demo [--case regression|healthy|sparse] [--min-requests <整数>] [--out <报告.json>]
node cli.mjs --input <发布窗口.json> [--min-requests <整数>] [--out <报告.json>]

  --case <场景>    regression 指标回归（默认），healthy 稳定扩量，sparse 样本不足
  --input <文件>   读取本地发布记录或网页导出的工作区，使用 UTF-8，最大 ${INPUT_LIMIT_KIB} KiB
  --min-requests   覆盖每个版本每窗口的最少请求数，常规默认 ${DEFAULT_POLICY.minRequests}
  --out <新文件>   将同一份 JSON 报告保存到新文件
  --help, -h       查看帮助

退出码：0 建议扩大流量，2 建议回滚，3 继续观察，1 参数、输入或文件错误。
报告记录窗口证据与建议。所有计算在本机完成。`;

class CliError extends Error {}

function parseArguments(args) {
  const options = new Map();
  for (let index = 0; index < args.length; index += 1) {
    const key = args[index];
    if (!OPTIONS.has(key) || options.has(key)) {
      throw new CliError('未知或重复的选项。使用 --help 查看用法。');
    }
    if (key === '--demo') {
      options.set(key, true);
      continue;
    }
    const value = args[index + 1];
    if (!value || value.startsWith('--')) throw new CliError(`${key} 缺少参数值。`);
    options.set(key, value);
    index += 1;
  }
  if (options.has('--demo') === options.has('--input')) throw new CliError('请选择 --demo 或 --input。');
  if (options.has('--case') && !options.has('--demo')) throw new CliError('--case 只能配合 --demo 使用。');
  if (options.has('--case') && !DEMOS.has(options.get('--case'))) {
    throw new CliError('样例场景请选择 regression、healthy 或 sparse。');
  }
  if (options.has('--min-requests') && !/^\d+$/u.test(options.get('--min-requests'))) {
    throw new CliError('--min-requests 需要一个正整数。');
  }
  return options;
}

function checkFile(details) {
  if (!details.isFile() || details.size > MAX_INPUT_BYTES) {
    throw new CliError(`请提供不超过 ${INPUT_LIMIT_KIB} KiB 的本地 JSON 文件。`);
  }
}

async function readInput(path) {
  try {
    checkFile(await stat(path));
    const file = await open(path, constants.O_RDONLY | (constants.O_NONBLOCK ?? 0));
    try {
      checkFile(await file.stat());
      const buffer = Buffer.allocUnsafe(MAX_INPUT_BYTES + 1);
      let size = 0;
      while (size < buffer.length) {
        const { bytesRead } = await file.read(buffer, size, buffer.length - size, null);
        if (bytesRead === 0) break;
        size += bytesRead;
      }
      if (size > MAX_INPUT_BYTES) throw new CliError(`发布窗口文件超过 ${INPUT_LIMIT_KIB} KiB。`);
      try {
        return new TextDecoder('utf-8', { fatal: true }).decode(buffer.subarray(0, size));
      } catch {
        throw new CliError('发布窗口文件需要使用 UTF-8 编码。');
      }
    } finally {
      await file.close();
    }
  } catch (error) {
    if (error instanceof CliError) throw error;
    throw new CliError('无法读取指定的发布窗口文件。');
  }
}

async function writeReport(path, content) {
  let target;
  try {
    target = await open(path, 'wx', 0o600);
  } catch (error) {
    if (error.code === 'EEXIST') throw new CliError('报告文件已存在，请指定一个新文件。');
    throw new CliError('无法创建指定的报告文件。');
  }
  try {
    try {
      await target.writeFile(content, 'utf8');
    } finally {
      await target.close();
    }
  } catch {
    await unlink(path).catch(() => {});
    throw new CliError('写入报告失败。');
  }
}

function readWorkspace(text) {
  const value = JSON.parse(text);
  if (value && typeof value === 'object' && Object.hasOwn(value, 'release')) {
    const policy = Object.hasOwn(value, 'policy') ? value.policy : DEFAULT_POLICY;
    return { release: parseRelease(JSON.stringify(value.release)), policy };
  }
  return { release: parseRelease(text), policy: DEFAULT_POLICY };
}

async function main(args) {
  if (args.length === 1 && ['--help', '-h'].includes(args[0])) {
    console.log(HELP);
    return 0;
  }
  const options = parseArguments(args);
  let release, result;
  try {
    const workspace = options.has('--demo')
      ? { release: DEMOS.get(options.get('--case') ?? 'regression'), policy: DEFAULT_POLICY }
      : readWorkspace(await readInput(options.get('--input')));
    ({ release } = workspace);
    const policy = options.has('--min-requests')
      ? { ...workspace.policy, minRequests: Number(options.get('--min-requests')) }
      : workspace.policy;
    result = evaluateRelease(release, policy);
  } catch (error) {
    if (error instanceof CliError) throw error;
    if (error instanceof SyntaxError) throw new CliError('发布窗口文件不是有效的 JSON。');
    throw new CliError(error.message || '无法计算灰度建议。');
  }
  const exitCode = EXIT_CODES.get(result.decision);
  if (exitCode === undefined) throw new CliError('未能识别灰度决策。');
  const { name, service, stableVersion, canaryVersion } = release;
  const report = JSON.stringify({ ...result, release: { name, service, stableVersion, canaryVersion } }, null, 2) + '\n';
  if (options.has('--out')) await writeReport(options.get('--out'), report);
  process.stdout.write(report);
  return exitCode;
}

try {
  process.exitCode = await main(process.argv.slice(2));
} catch (error) {
  console.error(error instanceof CliError ? error.message : '运行失败，请检查参数与文件路径。');
  process.exitCode = 1;
}
