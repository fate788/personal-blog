const observed = (requests, errors, p95Ms) => ({ requests, errors, p95Ms });

function release(name, samples) {
  return {
    name,
    service: 'checkout-api',
    stableVersion: 'v2.18.3',
    canaryVersion: 'v2.19.0',
    windows: samples.map(([traffic, stable, canary], index) => ({ minute: index * 5, traffic, stable, canary })),
  };
}

const start = [
  [5, observed(1_140, 4, 195), observed(60, 0, 202)],
  [5, observed(4_180, 17, 198), observed(220, 1, 218)],
  [5, observed(4_560, 18, 204), observed(240, 1, 222)],
  [20, observed(1_000, 4, 200), observed(250, 1, 219)],
];

export const DEMO_REGRESSION = release('结算服务 · 差错回归', [
  ...start,
  [20, observed(2_000, 8, 202), observed(500, 15, 325)],
  [20, observed(2_000, 8, 200), observed(500, 18, 340)],
  [20, observed(1_920, 7, 200), observed(480, 2, 218)],
  [20, observed(2_080, 8, 195), observed(520, 2, 214)],
  [20, observed(2_160, 9, 203), observed(540, 2, 217)],
]);

export const DEMO_HEALTHY = release('结算服务 · 指标稳定', [
  ...start,
  [20, observed(2_000, 8, 202), observed(500, 2, 226)],
  [20, observed(2_000, 8, 200), observed(500, 3, 218)],
  [20, observed(1_920, 7, 200), observed(480, 2, 217)],
  [20, observed(2_080, 8, 195), observed(520, 2, 216)],
  [20, observed(2_160, 9, 203), observed(540, 2, 218)],
]);

export const DEMO_SPARSE = release('结算服务 · 样本不足', [
  [5, observed(1_140, 4, 195), observed(60, 0, 202)],
  [5, observed(1_520, 6, 198), observed(80, 0, 200)],
  [5, observed(1_805, 7, 204), null],
  [5, observed(4_180, 17, 201), observed(220, 1, null)],
  [5, observed(1_900, 8, 202), observed(100, 0, 225)],
  [5, observed(4_180, 17, 202), observed(220, 1, 215)],
  [5, observed(1_995, 8, 203), observed(105, 1, 220)],
  [5, observed(1_805, 7, 199), observed(95, 0, 221)],
  [5, observed(1_900, 8, 198), observed(100, 0, 213)],
]);
