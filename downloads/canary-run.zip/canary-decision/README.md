# 灰度发布决策台

发布负责人可以在时间轴回看稳定版和候选版的请求、错误率、P95 延迟及样本量。逐个窗口核对放量、观察或回滚建议，查看哪段指标触发了结论。

[回放回归案例](https://fate788.github.io/personal-blog/demos/canary/index.html?v=1.0) · [看样本不足](https://fate788.github.io/personal-blog/demos/canary/index.html?v=1.0&case=sparse) · [博客作品页](https://fate788.github.io/personal-blog/projects/canary/index.html)

![灰度决策台实屏](docs/preview.webp)

## 三种样例

- **错误率回归**。流量切到 20% 后，候选版在相邻两个窗口越限。回放到第 25 分钟，候选版 5xx 为 3.60%，稳定版是 0.40%，P95 分别为 340 和 200 毫秒。建议回滚，后面正常的数据保留为证据。
- **稳定放量**。在 20% 流量阶段连续三个窗口均通过阈值。第 25 分钟得到继续放量建议。
- **样本不足**。低请求量、缺少候选采样和缺少延迟分位数都保留未知，建议继续观察。

## 本机运行

需要 Node.js 22 或更新版本，无额外依赖。

```sh
npm test
npm run build
node cli.mjs --demo --case regression
node cli.mjs --demo --case healthy
node cli.mjs --demo --case sparse
node cli.mjs --input ./release.json --out ./decision-report.json
```

构建产物为 `dist/index.html`，可直接离线打开。页面可导出 JSON 样例和逐窗报告，导入的发布数据在当前浏览器处理。CLI 退出码 `0` 表示建议放量，`2` 表示建议回滚，`3` 表示继续观察，`1` 表示输入或文件错误。报告输出路径须是新文件。

## 规则口径

数据使用连续五分钟窗口，稳定版和候选版分别记录请求、5xx 和窗口内 P95。默认每组至少 200 请求，候选错误率最多高 1 个百分点，P95 最多是稳定版的 1.30 倍。连续 3 个合格窗口才建议放量，连续 2 个越限窗口才触发回滚建议。切到新的流量阶段、样本不足或缺测会清空连续计数。已经触发回滚的案例保留该建议和首个触发点。P95 使用窗口原始分位数。

可在体验页导出工作区作为模板。浏览器与命令行均支持导入带 `release` 和 `policy` 的工作区。发布数据需要 `name`、`service`、`stableVersion`、`canaryVersion` 和 `windows`。每窗包含 `minute`、`traffic` 以及 `stable`、`canary` 两组观测。每组记录 `requests`、`errors`、`p95Ms`。缺测组或缺测 P95 使用 `null`。支持从第 0 分钟开始的 288 个连续窗口，JSON 文件上限 256 KiB。

内置数据为演练样例。规则用于解释决策，页面和 CLI 只生成建议与报告。设计参考 [Google SRE 灰度发布](https://sre.google/workbook/canarying-releases/) 和 [Argo Rollouts 分析结论](https://argoproj.github.io/argo-rollouts/features/analysis/)。
