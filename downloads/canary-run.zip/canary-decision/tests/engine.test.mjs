import assert from 'node:assert/strict';
import test from 'node:test';
import { DEFAULT_POLICY, MAX_INPUT_BYTES, evaluateRelease, parseRelease } from '../engine.mjs';
import { DEMO_HEALTHY, DEMO_REGRESSION, DEMO_SPARSE } from '../fixtures.mjs';

const reading = (requests, errors, p95Ms) => ({ requests, errors, p95Ms });
const healthy = { traffic: 5, stable: reading(1_000, 4, 200), canary: reading(500, 2, 220) };
const breach = { traffic: 5, stable: reading(1_000, 4, 200), canary: reading(500, 15, 340) };

function release(...windows) {
  return { ...DEMO_REGRESSION, windows: windows.map((window, index) => ({ ...window, minute: index * 5 })) };
}

test('regression recommends rollback at the second degraded window and latches through recovery', () => {
  const result = evaluateRelease(DEMO_REGRESSION);
  assert.equal(result.rollbackAt, 25);
  assert.equal(result.decision, 'rollback');
  assert.deepEqual(result.windows.map(window => window.decision), [
    'hold', 'hold', 'hold', 'hold', 'hold', 'rollback', 'rollback', 'rollback', 'rollback',
  ]);
  const trigger = result.windows.find(window => window.minute === result.rollbackAt);
  assert.equal(trigger.errorDeltaPp, 3.2);
  assert.equal(trigger.latencyRatio, 1.7);
  assert.equal(trigger.badStreak, 2);
  assert.match(trigger.reasons.join(' '), /3\.200 个百分点.+1\.700 倍.+连续 2 个窗口越限/u);
  assert.equal(result.lastWindow.state, 'healthy');
  assert.match(result.lastWindow.reasons.join(' '), /第 25 分钟/u);
});

test('healthy samples expand only on the third consecutive complete window of the current traffic stage', () => {
  const result = evaluateRelease(DEMO_HEALTHY);
  assert.equal(result.decision, 'expand');
  assert.equal(result.rollbackAt, null);
  assert.equal(result.windows.find(window => window.decision === 'expand').minute, 25);
  assert.deepEqual(result.windows.slice(0, 6).map(window => window.healthyStreak), [0, 1, 2, 1, 2, 3]);
});

test('missing cohort or P95 prevents a decision and keeps the unavailable metric null', () => {
  const result = evaluateRelease(DEMO_SPARSE);
  assert.equal(result.decision, 'hold');
  assert.ok(result.windows.every(window => window.decision === 'hold'));
  const [noCanary, noLatency] = result.windows.slice(2, 4);
  assert.equal(noCanary.state, 'insufficient');
  assert.equal(noCanary.errorDeltaPp, null);
  assert.equal(noCanary.latencyRatio, null);
  assert.match(noCanary.reasons[0], /候选版缺少/u);
  assert.equal(noLatency.state, 'insufficient');
  assert.equal(typeof noLatency.errorDeltaPp, 'number');
  assert.equal(noLatency.latencyRatio, null);
  assert.match(noLatency.reasons[0], /P95/u);
  assert.equal(result.windows[5].healthyStreak, 1);
  assert.equal(result.windows[6].healthyStreak, 0);
});

test('insufficient stable or canary observations actively reset a breach streak', () => {
  const sample = release(breach, { ...breach, stable: reading(199, 1, 200) }, breach, { ...breach, canary: null }, breach);
  const result = evaluateRelease(sample);
  assert.deepEqual(result.windows.map(window => window.badStreak), [1, 0, 1, 0, 1]);
  assert.equal(result.decision, 'hold');
  assert.equal(result.rollbackAt, null);
});

test('breaches from different traffic stages cannot combine and full traffic cannot expand', () => {
  const changingStages = evaluateRelease(release(breach, { ...breach, traffic: 20 }, { ...breach, traffic: 5 }));
  assert.deepEqual(changingStages.windows.map(window => window.badStreak), [1, 1, 1]);
  const full = evaluateRelease(release({ ...healthy, traffic: 100 }), { ...DEFAULT_POLICY, healthyWindows: 1 });
  assert.equal(full.lastWindow.state, 'healthy');
  assert.equal(full.decision, 'hold');
  assert.match(full.lastWindow.reasons.at(-1), /100%/u);
});

test('compares exact percentage points and P95 ratios before display rounding', () => {
  const thresholds = { ...DEFAULT_POLICY, maxErrorDeltaPp: 0.3, maxLatencyRatio: 1.1 };
  const atLimit = { ...healthy, stable: reading(1_000, 1, 20.1), canary: reading(1_000, 4, 22.11) };
  assert.equal(evaluateRelease(release(atLimit), thresholds).lastWindow.state, 'healthy');
  const errorOnly = { ...atLimit, canary: reading(1_000, 5, 22.11) };
  const p95Only = { ...atLimit, canary: reading(1_000, 4, 22.111) };
  const result = evaluateRelease(release(errorOnly, p95Only), thresholds);
  assert.equal(result.decision, 'rollback');
  assert.match(result.windows[0].reasons[0], /错误率差/u);
  assert.match(result.windows[1].reasons[0], /P95.*未舍入.*略高于/u);
  assert.equal(result.windows[0].reasons.length, 2);
});

test('handles very large counts without precision loss at the decision boundary', () => {
  const nearlyEqual = { ...healthy, stable: reading(1_000_000_000, 40_000_000, 200), canary: reading(999_999_997, 39_999_999, 200) };
  const above = { ...nearlyEqual, canary: reading(999_999_997, 40_000_000, 200) };
  const result = evaluateRelease(release(nearlyEqual, above), { ...DEFAULT_POLICY, maxErrorDeltaPp: 0 });
  assert.deepEqual(result.windows.map(window => window.state), ['healthy', 'breach']);
  assert.ok(result.windows[0].errorDeltaPp < 0 && result.windows[1].errorDeltaPp > 0);
});

test('normalizes valid JSON and rejects empty, malformed, oversized and discontinuous inputs', () => {
  const original = structuredClone(DEMO_HEALTHY);
  original.service = '  checkout-api  ';
  original.unknown = 'ignored';
  assert.deepEqual(parseRelease(`\uFEFF${JSON.stringify(original)}`), DEMO_HEALTHY);
  assert.equal(original.service, '  checkout-api  ');
  assert.throws(() => parseRelease(''), /有效的 JSON/u);
  assert.throws(() => parseRelease('字'.repeat(MAX_INPUT_BYTES / 2)), /256 KiB/u);
  assert.throws(() => parseRelease(JSON.stringify({ ...original, windows: [] })), /观察窗口/u);
  original.windows[1].minute = 9;
  assert.throws(() => parseRelease(JSON.stringify(original)), /每五分钟/u);
});

test('validates cohort, stage and policy constraints without mutating the provided data', () => {
  const failures = [
    [release({ ...healthy, traffic: 0 }), /百分比/u],
    [release({ ...healthy, traffic: 101 }), /百分比/u],
    [release({ ...healthy, canary: reading(500, 501, 200) }), /错误数/u],
    [release({ ...healthy, canary: reading(0, 0, 200) }), /零请求/u],
    [release({ ...healthy, canary: reading(500, 0, 0) }), /P95/u],
    [release({ ...healthy, canary: reading(500, 0, 5.1234) }), /三位小数/u],
    [{ ...DEMO_HEALTHY, canaryVersion: DEMO_HEALTHY.stableVersion }, /不同版本/u],
  ];
  for (const [input, message] of failures) assert.throws(() => evaluateRelease(input), message);
  for (const override of [{ minRequests: 0 }, { maxErrorDeltaPp: -1 }, { maxLatencyRatio: 0.9 }, { badWindows: 0 }]) {
    assert.throws(() => evaluateRelease(DEMO_HEALTHY, { ...DEFAULT_POLICY, ...override }), TypeError);
  }
  const baseline = release(healthy);
  const observed = JSON.stringify(baseline);
  const result = evaluateRelease(baseline);
  assert.notStrictEqual(result.windows[0].stable, baseline.windows[0].stable);
  assert.equal(JSON.stringify(baseline), observed);
});
