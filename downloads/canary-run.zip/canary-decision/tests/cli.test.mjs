import assert from 'node:assert/strict';
import { spawnSync } from 'node:child_process';
import { mkdtemp, readFile, rm, stat, writeFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { dirname, join, resolve } from 'node:path';
import test from 'node:test';
import { fileURLToPath } from 'node:url';
import { DEFAULT_POLICY, MAX_INPUT_BYTES } from '../engine.mjs';
import { DEMO_HEALTHY, DEMO_SPARSE } from '../fixtures.mjs';

const cli = fileURLToPath(new URL('../cli.mjs', import.meta.url));

function run(...args) {
  const result = spawnSync(process.execPath, [cli, ...args], {
    encoding: 'utf8', timeout: 5_000,
  });
  assert.ifError(result.error);
  assert.equal(result.signal, null);
  return result;
}

async function temporary(t) {
  const path = await mkdtemp(join(tmpdir(), 'canary-decision-cli-'));
  assert.equal(dirname(path), resolve(tmpdir()));
  t.after(() => rm(path, { recursive: true, force: true }));
  return path;
}

test('demo replay returns exact outcomes and trigger evidence', () => {
  const result = run('--demo');
  assert.equal(result.status, 2, result.stderr);
  assert.equal(result.stdout, run('--demo', '--case', 'regression').stdout);
  const regression = JSON.parse(result.stdout);
  assert.equal(regression.decision, 'rollback');
  assert.equal(regression.rollbackAt, 25);
  assert.equal(regression.windows.find(item => item.minute === 25).badStreak, 2);
  assert.equal(regression.windows.at(-1).decision, 'rollback');
  assert.ok(regression.release.canaryVersion);

  const healthy = run('--demo', '--case', 'healthy');
  assert.equal(healthy.status, 0, healthy.stderr);
  const healthyReport = JSON.parse(healthy.stdout);
  assert.equal(healthyReport.decision, 'expand');
  assert.equal(healthyReport.rollbackAt, null);
  assert.ok(healthyReport.windows.at(-1).healthyStreak >= healthyReport.policy.healthyWindows);

  const sparse = run('--demo', '--case', 'sparse');
  assert.equal(sparse.status, 3, sparse.stderr);
  assert.equal(JSON.parse(sparse.stdout).decision, 'hold');
  assert.ok(JSON.parse(sparse.stdout).windows.some(item => item.state === 'insufficient'));
});

test('a report can be saved on hold or rollback and never differs from standard output', async t => {
  const dir = await temporary(t);
  for (const [scenario, status, decision] of [['regression', 2, 'rollback'], ['sparse', 3, 'hold']]) {
    const path = join(dir, `${scenario}.json`);
    const result = run('--demo', '--case', scenario, '--out', path);
    assert.equal(result.status, status, result.stderr);
    assert.equal(JSON.parse(result.stdout).decision, decision);
    assert.equal(await readFile(path, 'utf8'), result.stdout);
  }
});

test('reads a local UTF-8 BOM file and uses the same validation for a policy override', async t => {
  const dir = await temporary(t);
  const path = join(dir, '灰度样本.json');
  const name = '灰度演练';
  const content = '\ufeff' + JSON.stringify({ ...DEMO_HEALTHY, name });
  await writeFile(path, content, 'utf8');
  const result = run('--input', path, '--min-requests', '1000000');
  assert.equal(result.status, 3, result.stderr);
  const report = JSON.parse(result.stdout);
  assert.equal(report.release.name, name);
  assert.equal(report.decision, 'hold');
  assert.equal(report.policy.minRequests, 1_000_000);
  assert.equal(await readFile(path, 'utf8'), content);
  for (const invalid of ['0', '1000001', '200.5']) {
    const rejected = run('--input', path, '--min-requests', invalid);
    assert.equal(rejected.status, 1);
    assert.equal(rejected.stdout, '');
    assert.notEqual(rejected.stderr, '');
  }
});

test('reuses the browser workspace policy and rejects invalid saved policies', async t => {
  const dir = await temporary(t);
  const path = join(dir, 'workspace.json');
  const workspace = {
    release: DEMO_HEALTHY,
    policy: { ...DEFAULT_POLICY, minRequests: 1_000_000, maxLatencyRatio: 1.25 },
  };
  await writeFile(path, JSON.stringify(workspace));
  const held = run('--input', path);
  assert.equal(held.status, 3, held.stderr);
  assert.deepEqual(JSON.parse(held.stdout).policy, workspace.policy);
  const expanded = run('--input', path, '--min-requests', '200');
  assert.equal(expanded.status, 0, expanded.stderr);
  assert.deepEqual(JSON.parse(expanded.stdout).policy, { ...workspace.policy, minRequests: 200 });

  workspace.policy.badWindows = 0;
  await writeFile(path, JSON.stringify(workspace));
  const invalid = run('--input', path);
  assert.equal(invalid.status, 1);
  assert.equal(invalid.stdout, '');
  assert.match(invalid.stderr, /连续越限窗口/);

  await writeFile(path, JSON.stringify({ ...workspace, policy: null }));
  const missing = run('--input', path);
  assert.equal(missing.status, 1);
  assert.match(missing.stderr, /灰度规则/);
});

test('preserves an existing report and an input used as the report destination', async t => {
  const dir = await temporary(t);
  const input = join(dir, 'samples.json');
  const output = join(dir, 'report.json');
  const original = JSON.stringify(DEMO_SPARSE);
  await writeFile(input, original);
  await writeFile(output, 'old report');
  for (const [file, expected] of [[input, original], [output, 'old report']]) {
    const result = run('--input', input, '--out', file);
    assert.equal(result.status, 1);
    assert.equal(result.stdout, '');
    assert.match(result.stderr, /已存在/);
    assert.equal(await readFile(file, 'utf8'), expected);
  }
});

test('invalid metrics, encoding, syntax or file size fail without producing a report', async t => {
  const dir = await temporary(t);
  const input = join(dir, 'invalid.json');
  const report = join(dir, 'report.json');
  const invalidMetric = structuredClone(DEMO_HEALTHY);
  const entry = invalidMetric.windows.find(item => item.canary);
  entry.canary.errors = entry.canary.requests + 1;
  for (const [payload, expected] of [
    [JSON.stringify(invalidMetric), /错误|请求/],
    ['{"name": invalid JSON}', /JSON/],
    [Buffer.from([0x22, 0xff, 0x22]), /UTF-8/],
    [Buffer.alloc(MAX_INPUT_BYTES + 1, 0x20), /256 KiB/],
  ]) {
    await writeFile(input, payload);
    const result = run('--input', input, '--out', report);
    assert.equal(result.status, 1);
    assert.equal(result.stdout, '');
    assert.match(result.stderr, expected);
    await assert.rejects(stat(report), { code: 'ENOENT' });
  }
  const directory = run('--input', dir);
  assert.equal(directory.status, 1);
  assert.match(directory.stderr, /本地 JSON 文件/);
});

test('help explains decision codes and invalid option combinations are rejected', () => {
  const help = run('--help');
  assert.equal(help.status, 0);
  assert.match(help.stdout, /0 建议扩大流量，2 建议回滚，3 继续观察/);
  assert.match(help.stdout, /regression\|healthy\|sparse/);
  for (const args of [[], ['--demo', '--wat'], ['--demo', '--demo'], ['--demo', '--input', 'data.json'],
    ['--input', 'data.json', '--case', 'sparse'], ['--demo', '--case', 'other'], ['--demo', '--out']]) {
    const result = run(...args);
    assert.equal(result.status, 1, args.join(' '));
    assert.equal(result.stdout, '');
    assert.notEqual(result.stderr, '');
  }
});
