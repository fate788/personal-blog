# 校园场务 v0.12 源码包

原始发布归档为 `校园场务-v0.12.zip`。压缩包保留其中 48 份文本文件的原始路径与字节，本文件为导出说明。

服务端使用 Java 17 和 Maven。可运行 `mvn test` 复跑集成测试，运行 `mvn package` 构建 JAR。若使用随发布版本提供的 `start-review.cmd`，需将所构建的应用 JAR 放在 `release/campus-events.jar`。原版界面的 WebP、PNG 和 WOFF2 素材见完整运行包。项目内的第三方 QR 源码和相应许可证随源码提供。
