const MINUTE = 60_000;

export const HANDOFF_ACTIONS = Object.freeze([
  { id: 'hold-for-review', label: '暂扣复核' },
  { id: 'inspect-on-arrival', label: '到货核验' },
  { id: 'recover-telemetry', label: '补录设备数据' },
]);

function iso(time) {
  return new Date(time).toISOString();
}

function minutesBetween(start, end) {
  return Math.round((end - start) / MINUTE * 10) / 10;
}

function compareText(a, b) {
  return a === b ? 0 : a < b ? -1 : 1;
}

function compareReadings(a, b) {
  return compareText(a.at, b.at) || compareText(a.id, b.id) || a.tempC - b.tempC
    || compareText(a.zone, b.zone) || (a.doorOpen ?? -1) - (b.doorOpen ?? -1);
}

export function normalizeSamples(samples, { startAt, endAt }) {
  const start = Date.parse(startAt);
  const end = Date.parse(endAt);
  const ordered = samples.flatMap(sample => {
    if (!sample || typeof sample.id !== 'string' || !sample.id || !Number.isFinite(sample.tempC)) return [];
    const time = Date.parse(sample.at);
    if (!Number.isFinite(time) || time < start || time > end) return [];
    return [{
      id: sample.id,
      at: iso(time),
      tempC: sample.tempC,
      zone: typeof sample.zone === 'string' ? sample.zone : '',
      doorOpen: typeof sample.doorOpen === 'boolean' ? sample.doorOpen : null,
    }];
  }).sort(compareReadings);

  // Repeated IDs or timestamps represent one reading. A stable ordering also resolves conflicting copies.
  const seenIds = new Set();
  const seenTimes = new Set();
  return ordered.filter(sample => {
    if (seenIds.has(sample.id)) return false;
    seenIds.add(sample.id);
    if (seenTimes.has(sample.at)) return false;
    seenTimes.add(sample.at);
    return true;
  });
}

function gapFor(trip, landmarks, firstMissing, until, interval, previous, recovery) {
  const startAt = iso(firstMissing);
  const endAt = iso(until);
  const durationMinutes = minutesBetween(firstMissing, until);
  const missingCount = recovery
    ? Math.ceil((until - firstMissing) / interval)
    : Math.floor((until - firstMissing) / interval) + 1;
  const zone = landmarks.findLast(landmark => landmark.at <= startAt)?.zone ?? previous?.zone ?? '';
  const evidence = [{ at: startAt, label: '该采样时刻起无遥测记录' }];
  if (previous) evidence.unshift({ at: previous.at, label: `缺口前最后读数 ${previous.tempC} ℃` });
  if (recovery) evidence.push({ at: recovery.at, label: `恢复上报，观测 ${recovery.tempC} ℃` });
  return {
    id: `${trip.id}:gap:${startAt}`,
    type: 'gap',
    title: '遥测数据中断',
    startAt, endAt, durationMinutes, missingCount, zone, evidence,
    status: recovery ? 'closed' : 'active',
    resolvedAt: recovery?.at ?? null,
    minC: null,
    maxC: null,
    limit: null,
    lastKnownAt: previous?.at ?? null,
    cause: '设备遥测缺失，缺口内温度未知',
  };
}

function findGaps(trip, landmarks, samples, cursor, interval) {
  const gaps = [];
  let previous;
  let expectedAt = Date.parse(trip.startAt);
  for (const sample of samples) {
    const time = Date.parse(sample.at);
    if (time > expectedAt) gaps.push(gapFor(trip, landmarks, expectedAt, time, interval, previous, sample));
    previous = sample;
    expectedAt = time + interval;
  }
  if (cursor >= expectedAt) gaps.push(gapFor(trip, landmarks, expectedAt, cursor, interval, previous));
  return gaps;
}

function readingExtremes(samples) {
  let min;
  let max;
  for (const sample of samples) {
    if (!min || sample.tempC < min.tempC) min = sample;
    if (!max || sample.tempC > max.tempC) max = sample;
  }
  return { min, max };
}

function excursionFor(trip, run, direction, gap, nextReading) {
  const first = run[0];
  const last = run.at(-1);
  const durationMinutes = minutesBetween(Date.parse(first.at), Date.parse(last.at));
  if (Date.parse(last.at) - Date.parse(first.at) < trip.policy.minExcursionMinutes * MINUTE) return null;
  const { min, max } = readingExtremes(run);
  const isHigh = direction === 'high';
  const extreme = isHigh ? max : min;
  const limit = isHigh ? trip.policy.maxC : trip.policy.minC;
  const evidence = [{ at: first.at, label: `首次${isHigh ? '超过上限' : '低于下限'}，观测 ${first.tempC} ℃` }];
  if (extreme !== first && extreme !== last) evidence.push({ at: extreme.at, label: `此段观测${isHigh ? '最高' : '最低'} ${extreme.tempC} ℃` });
  if (last !== first) evidence.push({ at: last.at, label: `此段末次超限读数 ${last.tempC} ℃` });
  if (gap) evidence.push({ at: gap.startAt, label: '随后出现采样缺口，超限时长计算截至末次读数' });
  if (!gap && nextReading) evidence.push({ at: nextReading.at, label: `收到后续读数 ${nextReading.tempC} ℃，结束此段超限记录` });
  const resolvedAt = gap?.startAt ?? nextReading?.at ?? null;
  return {
    id: `${trip.id}:excursion:${first.at}`,
    type: 'excursion',
    title: isHigh ? '温度超过上限' : '温度低于下限',
    direction,
    startAt: first.at,
    endAt: last.at,
    durationMinutes,
    minC: min.tempC,
    maxC: max.tempC,
    limit,
    status: resolvedAt ? 'closed' : 'active',
    resolvedAt,
    zone: first.zone,
    evidence,
    cause: `连续采样的读数${isHigh ? '高于' : '低于'} ${limit} ℃，首末观测跨度达到 ${trip.policy.minExcursionMinutes} 分钟`,
  };
}

function findExcursions(trip, samples, gaps, interval) {
  const gapsAfter = new Map(gaps.map(gap => [gap.lastKnownAt, gap]));
  const incidents = [];
  let run = [];
  let direction;

  function finishRun(gap, nextReading) {
    if (run.length === 0) return;
    const incident = excursionFor(trip, run, direction, gap, nextReading);
    if (incident) incidents.push(incident);
    run = [];
  }

  for (const sample of samples) {
    const previous = run.at(-1);
    const nextDirection = sample.tempC > trip.policy.maxC ? 'high'
      : sample.tempC < trip.policy.minC ? 'low' : null;
    if (previous && Date.parse(sample.at) - Date.parse(previous.at) > interval) {
      finishRun(gapsAfter.get(previous.at));
    } else if (nextDirection !== direction) {
      finishRun(null, sample);
    }
    if (nextDirection) run.push(sample);
    direction = nextDirection;
  }
  finishRun(gapsAfter.get(run.at(-1)?.at));
  return incidents;
}

function findEvents(landmarks, samples, interval) {
  const events = landmarks.map((landmark, index) => ({ ...landmark, id: `landmark-${index}`, type: 'landmark' }));
  let previous;
  for (const sample of samples) {
    const contiguous = previous && Date.parse(sample.at) - Date.parse(previous.at) <= interval;
    const priorDoor = contiguous ? previous.doorOpen : null;
    const doorOpened = sample.doorOpen === true && priorDoor !== true;
    const doorClosed = sample.doorOpen === false && priorDoor === true;
    if (doorOpened || doorClosed) {
      events.push({
        id: `door-${sample.id}`,
        type: doorOpened ? 'door-open' : 'door-closed',
        at: sample.at,
        label: doorOpened ? '检测到车厢门打开' : '检测到车厢门关闭',
        zone: sample.zone,
      });
    }
    previous = sample;
  }
  return events.sort((a, b) => compareText(a.at, b.at));
}

export function projectTrip(trip, { cursorAt, handoffs = {} } = {}) {
  const start = Date.parse(trip.startAt);
  const end = Date.parse(trip.endAt);
  const interval = trip.intervalMinutes * MINUTE;
  const { minC, maxC, minExcursionMinutes } = trip.policy;
  if (!Number.isFinite(start) || !Number.isFinite(end) || end < start || !Number.isFinite(interval) || interval <= 0
    || ![minC, maxC, minExcursionMinutes].every(Number.isFinite) || minC > maxC || minExcursionMinutes <= 0) {
    throw new Error('行程起止时间或监测规则无效');
  }

  const requested = typeof cursorAt === 'number' ? cursorAt : Date.parse(cursorAt);
  const cursor = Number.isFinite(requested) ? Math.min(end, Math.max(start, requested)) : end;
  const timestamp = iso(cursor);
  const samples = normalizeSamples(trip.samples, trip).filter(sample => sample.at <= timestamp);
  const landmarks = trip.landmarks.map(landmark => ({ ...landmark, at: iso(Date.parse(landmark.at)) }))
    .filter(landmark => landmark.at <= timestamp).sort((a, b) => compareText(a.at, b.at));
  const gaps = findGaps(trip, landmarks, samples, cursor, interval);
  const incidents = [...findExcursions(trip, samples, gaps, interval), ...gaps]
    .sort((a, b) => compareText(a.startAt, b.startAt)).map(incident => ({
      ...incident,
      handoff: Object.hasOwn(handoffs, incident.id) ? handoffs[incident.id] : null,
    }));
  const events = findEvents(landmarks, samples, interval);
  const { min, max } = readingExtremes(samples);
  const lastSample = samples.at(-1) ?? null;
  const expectedReadings = Math.floor((cursor - start) / interval) + 1;
  const doorEvents = events.filter(event => event.type === 'door-open');
  const activeGap = gaps.at(-1)?.status === 'active';
  return {
    trip,
    cursorAt: timestamp,
    samples,
    gaps,
    incidents,
    events,
    currentLandmark: landmarks.at(-1) ?? null,
    progress: end === start ? 1 : (cursor - start) / (end - start),
    stats: {
      readingCount: samples.length,
      expectedReadings,
      gapCount: gaps.length,
      incidentCount: incidents.length,
      minC: min?.tempC ?? null,
      maxC: max?.tempC ?? null,
      lastTempC: lastSample?.tempC ?? null,
      currentTempC: activeGap ? null : lastSample?.tempC ?? null,
      lastAt: lastSample?.at ?? null,
      lastSample,
      coveragePercent: Math.min(100, Math.round(samples.length / expectedReadings * 1_000) / 10),
      doorOpenCount: doorEvents.length,
      lastDoorOpen: doorEvents.at(-1) ?? null,
    },
  };
}

export function createHandoff(incident, { action, note, at } = {}) {
  if (!incident?.id) throw new Error('请选择一条异常记录');
  if (!HANDOFF_ACTIONS.some(option => option.id === action)) throw new Error('请选择有效的处置方式');
  const cleanNote = typeof note === 'string' ? note.trim() : '';
  if (!cleanNote || Array.from(cleanNote).length > 240) throw new Error('交接说明需填写 1–240 个字');
  const time = typeof at === 'number' ? at : Date.parse(at);
  if (!Number.isFinite(time)) throw new Error('交接时间无效');
  return { incidentId: incident.id, action, note: cleanNote, at: iso(time) };
}
