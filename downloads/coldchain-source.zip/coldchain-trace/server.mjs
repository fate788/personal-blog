import { mkdirSync } from "node:fs";
import { readFile } from "node:fs/promises";
import { createServer as createHTTPServer } from "node:http";
import { dirname, resolve } from "node:path";
import { DatabaseSync } from "node:sqlite";
import { fileURLToPath } from "node:url";
import { parseArgs } from "node:util";
import { TRIPS } from "./fixtures.mjs";
import { prepareHandoff, replayHandoff } from "./portable/transport.mjs";

const database = fileURLToPath(new URL("./data/handoffs.sqlite", import.meta.url));
const maxBodyBytes = 4096;
const policy = "default-src 'self'; script-src 'self'; connect-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; object-src 'none'; base-uri 'none'; frame-ancestors 'none'; form-action 'none'";
const mimeTypes = {
  html: "text/html; charset=utf-8",
  mjs: "text/javascript; charset=utf-8",
  css: "text/css; charset=utf-8",
  webp: "image/webp"
};
const siteFiles = new Map([
  ["/", "static/index.html"],
  ["/domain.mjs", "domain.mjs"],
  ["/fixtures.mjs", "fixtures.mjs"]
]);
for (const name of ["index.html", "styles.css", "app.mjs", "transport.mjs", "media/cold-dock.webp"]) {
  siteFiles.set(`/${name}`, `static/${name}`);
  siteFiles.set(`/static/${name}`, `static/${name}`);
}

function requestError(status, code, message) {
  return Object.assign(new Error(message), { status, code });
}

function openStore(path) {
  if (path !== ":memory:") mkdirSync(dirname(resolve(path)), { recursive: true });
  const db = new DatabaseSync(path);
  db.exec(`
    PRAGMA busy_timeout = 4000;
    PRAGMA journal_mode = WAL;
    CREATE TABLE IF NOT EXISTS handoffs (
      operation_id TEXT PRIMARY KEY,
      trip_id TEXT NOT NULL,
      incident_id TEXT NOT NULL UNIQUE,
      action TEXT NOT NULL,
      note TEXT NOT NULL,
      captured_at TEXT NOT NULL
    ) STRICT;
  `);
  const columns = 'trip_id AS tripId, incident_id AS incidentId, action, note, captured_at AS at, operation_id AS operationId';
  const select = db.prepare(`SELECT ${columns} FROM handoffs ORDER BY captured_at, operation_id`);
  const findOperation = db.prepare(`SELECT ${columns} FROM handoffs WHERE operation_id = ?`);
  const insert = db.prepare(`
    INSERT INTO handoffs(operation_id, trip_id, incident_id, action, note, captured_at)
    VALUES (?, ?, ?, ?, ?, ?)
    ON CONFLICT DO NOTHING
  `);
  return {
    list() {
      return Object.fromEntries(select.all().map(record => [record.incidentId, record]));
    },
    record(handoff) {
      const { operationId, tripId, incidentId, action, note, at } = handoff;
      if (insert.run(operationId, tripId, incidentId, action, note, at).changes) {
        return { handoff, replayed: false };
      }
      return replayHandoff(handoff, findOperation.get(operationId));
    },
    close() {
      db.close();
    }
  };
}

function reply(response, status, body, type, head) {
  response.writeHead(status, {
    "Content-Type": type,
    "Content-Length": Buffer.byteLength(body),
    "Cache-Control": "no-store",
    "Content-Security-Policy": policy,
    "X-Content-Type-Options": "nosniff",
    "Referrer-Policy": "no-referrer"
  });
  response.end(head ? undefined : body);
}

function json(response, status, payload, head = false) {
  reply(response, status, JSON.stringify(payload), "application/json; charset=utf-8", head);
}

function checkRequest(request, port) {
  const host = request.headers.host?.toLowerCase();
  if (host !== `127.0.0.1:${port}` && host !== `localhost:${port}`) {
    throw requestError(403, "local_only", "此服务仅供本机演练。");
  }
  const origin = `http://${host}`;
  if (!request.url?.startsWith("/") || request.url.startsWith("//") || request.url.includes("\\")) {
    throw requestError(400, "invalid_path", "请求地址无效。");
  }
  const url = new URL(request.url, origin);
  if (url.origin !== origin || url.hash) {
    throw requestError(400, "invalid_path", "请求地址无效。");
  }
  if (url.pathname.startsWith("/api/")) {
    const site = request.headers["sec-fetch-site"];
    if ((request.headers.origin && request.headers.origin !== origin) || (site && !["same-origin", "none"].includes(site))) {
      throw requestError(403, "origin_mismatch", "请从本机工作台发起请求。");
    }
  }
  return url.pathname;
}

async function readJSON(request) {
  if (!/^application\/json(?:\s*;|$)/iu.test(request.headers["content-type"] || "")) {
    throw requestError(415, "invalid_content_type", "请提交 JSON 交接内容。");
  }
  if (Number(request.headers["content-length"] || 0) > maxBodyBytes) {
    throw requestError(413, "body_too_large", "交接内容过长。");
  }
  const chunks = [];
  let bytes = 0;
  for await (const chunk of request.iterator({ destroyOnReturn: false })) {
    bytes += chunk.length;
    if (bytes > maxBodyBytes) {
      request.resume();
      throw requestError(413, "body_too_large", "交接内容过长。");
    }
    chunks.push(chunk);
  }
  try {
    return JSON.parse(Buffer.concat(chunks).toString("utf8"));
  } catch {
    throw requestError(400, "invalid_json", "无法读取请求中的 JSON。");
  }
}

function requireMethod(request, response, ...allowed) {
  if (allowed.includes(request.method)) return;
  response.setHeader("Allow", allowed.join(", "));
  throw requestError(405, "method_not_allowed", "此请求方法不可用。");
}

export function createServer({ dbPath = database, clock = () => new Date().toISOString() } = {}) {
  const store = openStore(dbPath);
  const server = createHTTPServer(async (request, response) => {
    const head = request.method === "HEAD";
    try {
      const path = checkRequest(request, server.address()?.port);
      if (path === "/api/workspace") {
        requireMethod(request, response, "GET", "HEAD");
        json(response, 200, { trips: TRIPS, handoffs: store.list() }, head);
      } else if (path === "/api/handoffs") {
        requireMethod(request, response, "POST");
        const input = await readJSON(request);
        const record = store.record(prepareHandoff(input, clock()));
        json(response, record.replayed ? 200 : 201, record);
      } else {
        const file = siteFiles.get(path);
        if (!file) throw requestError(404, "not_found", "未找到此页面。");
        requireMethod(request, response, "GET", "HEAD");
        reply(response, 200, await readFile(new URL(file, import.meta.url)), mimeTypes[file.split(".").at(-1)], head);
      }
    } catch (error) {
      if (error.status) json(response, error.status, { code: error.code, message: error.message }, head);
      else if (error.code === "ENOENT") json(response, 404, { code: "not_found", message: "未找到此页面。" }, head);
      else {
        console.error(error);
        json(response, 500, { code: "service_unavailable", message: "样例服务暂时不可用。" }, head);
      }
    }
  });
  let closed = false;
  const closeStore = () => {
    if (closed) return;
    closed = true;
    store.close();
  };
  server.once("close", closeStore);
  server.once("error", closeStore);
  return server;
}

export function startServer({ port = 8830, ...options } = {}) {
  return createServer(options).listen(port, "127.0.0.1");
}

if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const { values } = parseArgs({ options: { port: { type: "string", default: "8830" }, db: { type: "string" } } });
  const port = Number(values.port);
  if (!/^\d{1,5}$/u.test(values.port) || port > 65535) throw new Error("端口应为 0 至 65535。");
  const server = startServer({ port, dbPath: values.db });
  server.once("listening", () => console.log(`冷链运输追溯台 http://127.0.0.1:${server.address().port}/`));
  server.once("error", (error) => {
    console.error(error.message);
    process.exitCode = 1;
  });
}
