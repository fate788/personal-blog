const policy = Object.freeze({ minC: 2, maxC: 8, minExcursionMinutes: 15 });

function at(date, hours, minutes) {
  return new Date(`${date}T${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}:00+08:00`).toISOString();
}

function makeTrip({ id, name, scenario, date, hour, origin, destination, shipment, vehicle, subtitle, estimate, temperatures, landmarks, doors = [] }) {
  const intervalMinutes = 5;
  const finalMinute = (temperatures.length - 1) * intervalMinutes;
  const timeAt = minute => at(date, hour + Math.floor(minute / 60), minute % 60);
  const waypoints = landmarks.map(([minute, label, zone]) => ({ at: timeAt(minute), label, zone }));
  const samples = temperatures.flatMap((tempC, index) => {
    if (tempC === null) return [];
    const minute = index * intervalMinutes;
    const timestamp = timeAt(minute);
    return [{
      id: `${id}-reading-${String(index).padStart(3, '0')}`,
      at: timestamp,
      tempC,
      zone: waypoints.findLast(waypoint => waypoint.at <= timestamp).zone,
      doorOpen: doors.some(([openAt, closeAt]) => minute >= openAt && minute < closeAt),
    }];
  });
  return {
    id, name, scenario, shipment, vehicle, origin, destination, subtitle, estimate,
    startAt: timeAt(0),
    endAt: timeAt(finalMinute),
    intervalMinutes,
    policy,
    landmarks: waypoints,
    samples,
  };
}

export const TRIPS = [
  makeTrip({
    id: 'cc-1028',
    name: '滨江门店补货',
    scenario: 'excursion',
    date: '2026-11-27',
    hour: 8,
    origin: '东湖中央冷库',
    destination: '滨江门店集配点',
    shipment: '低温酸奶 · 36 箱',
    vehicle: '冷藏车 C-17',
    subtitle: '冷藏乳品 · 同城配送',
    estimate: { distanceKm: 42, carrier: '东湖冷链车队' },
    temperatures: [4.2, 4.1, 4.3, 4.2, 4.4, 4.7, 5.5, 6.8, 8.4, 9.5, 10.3, 10.8, 10.1, 8.7, 7.6, 6.5, 5.8, 5.2, 4.9, 4.8, 4.7, 4.8],
    landmarks: [
      [0, '东湖中央冷库', '装车月台'],
      [20, '驶离冷库', '第一段运输'],
      [40, '北湾中转站', '临时中转月台'],
      [55, '离开中转站', '第二段运输'],
      [90, '滨江门店集配点', '到货交接区'],
    ],
    doors: [[0, 5], [40, 50], [90, 95]],
  }),
  makeTrip({
    id: 'cc-1027',
    name: '南桥商超早餐配送',
    scenario: 'normal',
    date: '2026-11-27',
    hour: 6,
    origin: '西桥分拨库',
    destination: '南桥商超配送口',
    shipment: '盒装鲜奶 · 24 箱',
    vehicle: '冷藏车 C-08',
    subtitle: '冷藏乳品 · 早班配送',
    estimate: { distanceKm: 28, carrier: '西桥冷链车队' },
    temperatures: [4.4, 4.6, 4.7, 4.9, 4.5, 4.3, 4.2, 4.6, 4.8, 5.1, 5.7, 5.4, 5.0, 4.8, 4.8, 4.9, 5.2],
    landmarks: [
      [0, '西桥分拨库', '装车月台'],
      [15, '驶离分拨库', '市区运输'],
      [45, '南桥物流园', '园区西门'],
      [70, '南桥商超配送口', '到货交接区'],
    ],
    doors: [[0, 5], [70, 75]],
  }),
  makeTrip({
    id: 'cc-1026',
    name: '江北分拨仓调拨',
    scenario: 'gap',
    date: '2026-11-26',
    hour: 13,
    origin: '临港集配仓',
    destination: '江北分拨仓',
    shipment: '冷藏果汁 · 48 箱',
    vehicle: '冷藏车 C-12',
    subtitle: '冷藏饮品 · 跨区调拨',
    estimate: { distanceKm: 61, carrier: '临港冷链车队' },
    temperatures: [5.1, 5.3, 5.1, 5.4, 5.6, 5.8, null, null, null, null, null, 6.3, 6.2, 6.0, 5.6, 5.8, 5.4, 5.5, 5.6, 5.5],
    landmarks: [
      [0, '临港集配仓', '装车月台'],
      [20, '驶离集配仓', '跨区运输'],
      [60, '江北分拨园区', '园区入口'],
      [85, '江北分拨仓', '到货交接区'],
    ],
    doors: [[0, 5], [85, 90]],
  }),
];
