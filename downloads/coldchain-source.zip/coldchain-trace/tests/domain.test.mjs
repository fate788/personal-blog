import test from 'node:test';
import assert from 'node:assert/strict';
import { createHandoff, normalizeSamples, projectTrip } from '../domain.mjs';
import { TRIPS } from '../fixtures.mjs';

const [excursionTrip, normalTrip, gapTrip] = TRIPS;
const localAt = (date, time) => new Date(`${date}T${time}:00+08:00`).toISOString();
const on27 = time => localAt('2026-11-27', time);
const on26 = time => localAt('2026-11-26', time);

test('an excursion appears after the configured observed span and retains its ID through recovery', () => {
  assert.equal(projectTrip(excursionTrip, { cursorAt: on27('08:54') }).incidents.length, 0);
  const active = projectTrip(excursionTrip, { cursorAt: on27('08:55') }).incidents[0];
  assert.equal(active.status, 'active');
  assert.equal(active.durationMinutes, 15);
  assert.equal(active.endAt, on27('08:55'));

  const final = projectTrip(excursionTrip);
  const [incident] = final.incidents;
  assert.equal(final.incidents.length, 1);
  assert.equal(final.stats.readingCount, 22);
  assert.equal(final.stats.coveragePercent, 100);
  assert.equal(incident.id, active.id);
  assert.equal(incident.direction, 'high');
  assert.equal(incident.status, 'closed');
  assert.equal(incident.durationMinutes, 25);
  assert.equal(incident.startAt, on27('08:40'));
  assert.equal(incident.endAt, on27('09:05'));
  assert.equal(incident.resolvedAt, on27('09:10'));
  assert.equal(incident.maxC, 10.8);
  assert.ok(final.events.some(event => event.type === 'door-open' && event.at === on27('08:40')));
});

test('a clean route projects every reading and reports no incident', () => {
  const clean = projectTrip(normalTrip);
  assert.equal(clean.progress, 1);
  assert.equal(clean.currentLandmark.label, normalTrip.destination);
  assert.deepEqual(clean.incidents, []);
  assert.equal(clean.stats.readingCount, 17);
  assert.equal(clean.stats.lastTempC, 5.2);
});

test('gaps open when a reading is due, hide current temperature and close with an actual observation', () => {
  assert.equal(projectTrip(gapTrip, { cursorAt: on26('13:29') }).gaps.length, 0);
  const missing = projectTrip(gapTrip, { cursorAt: on26('13:30') });
  assert.equal(missing.gaps[0].durationMinutes, 0);
  assert.equal(missing.gaps[0].missingCount, 1);
  assert.equal(missing.gaps[0].status, 'active');
  assert.equal(missing.stats.currentTempC, null);
  assert.equal(missing.stats.lastTempC, 5.8);
  assert.equal(missing.stats.lastAt, on26('13:25'));

  const recovered = projectTrip(gapTrip, { cursorAt: on26('13:55') });
  const [gap] = recovered.incidents;
  assert.equal(gap.id, missing.incidents[0].id);
  assert.equal(gap.type, 'gap');
  assert.equal(gap.status, 'closed');
  assert.equal(gap.durationMinutes, 25);
  assert.equal(gap.missingCount, 5);
  assert.equal(gap.maxC, null);
  assert.equal(gap.minC, null);
  assert.equal(gap.resolvedAt, on26('13:55'));
  assert.equal(recovered.stats.currentTempC, 6.3);
  assert.equal(projectTrip(gapTrip).stats.coveragePercent, 75);
});

test('the control range includes both edges and a gap separates repeated high runs', () => {
  const rangeEdge = { ...normalTrip, samples: normalTrip.samples.map((sample, index) => ({ ...sample, tempC: index % 2 ? 2 : 8 })) };
  assert.equal(projectTrip(rangeEdge).incidents.length, 0);

  const highWithGap = {
    ...gapTrip,
    samples: gapTrip.samples.map((sample, index) => ({ ...sample, tempC: index <= 8 ? 10 : sample.tempC })),
  };
  const [high, gap] = projectTrip(highWithGap).incidents;
  assert.equal(projectTrip(highWithGap).incidents.length, 2);
  assert.equal(high.type, 'excursion');
  assert.equal(high.endAt, on26('13:25'));
  assert.equal(high.resolvedAt, gap.startAt);
  assert.equal(high.durationMinutes, 25);
  assert.equal(gap.type, 'gap');
});

test('a low-temperature run follows the lower policy edge and keeps its own extreme', () => {
  const lowTrip = {
    ...normalTrip,
    samples: normalTrip.samples.map((sample, index) => ({ ...sample, tempC: [1.9, 1.4, 1.1, 1.8][index] ?? sample.tempC })),
  };
  const [low] = projectTrip(lowTrip).incidents;
  assert.equal(low.direction, 'low');
  assert.equal(low.limit, 2);
  assert.equal(low.minC, 1.1);
  assert.equal(low.durationMinutes, 15);
});

test('normalization supports out-of-order retries and reconciles conflicting duplicate records deterministically', () => {
  const [a, b, c] = normalTrip.samples;
  const noisy = [c, { ...a, at: b.at }, { ...a, doorOpen: null }, b, a, c, { ...b, id: 'zz-conflict', tempC: 100 }, { ...c, id: 'bad', tempC: null }];
  const expected = [a, b, c].map(reading => reading.id === a.id ? { ...reading, doorOpen: null } : reading);
  assert.deepEqual(normalizeSamples(noisy, normalTrip), expected);
  assert.deepEqual(normalizeSamples(noisy.toReversed(), normalTrip), expected);
  assert.equal(projectTrip({ ...normalTrip, samples: noisy }).stats.readingCount, 3);
});

test('handoff requires a supported decision and note and projects back onto its incident', () => {
  const [incident] = projectTrip(excursionTrip).incidents;
  const action = 'hold-for-review';
  const at = on27('09:55');
  assert.throws(() => createHandoff(incident, { action, note: ' ', at }), /交接说明/);
  assert.throws(() => createHandoff(incident, { action, note: '多'.repeat(241), at }), /交接说明/);
  assert.throws(() => createHandoff(incident, { action: 'other', note: '复核', at }), /处置方式/);
  assert.throws(() => createHandoff(incident, { action, note: '复核' }), /交接时间/);
  const handoff = createHandoff(incident, { action, note: '  到货复测后确认。 ', at });
  assert.deepEqual(handoff, { incidentId: incident.id, action, note: '到货复测后确认。', at });
  assert.deepEqual(projectTrip(excursionTrip, { handoffs: { [incident.id]: handoff } }).incidents[0].handoff, handoff);
});
