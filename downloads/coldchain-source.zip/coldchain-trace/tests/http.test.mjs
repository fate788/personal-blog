import assert from "node:assert/strict";
import { once } from "node:events";
import { mkdtemp, rm } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { test } from "node:test";
import { projectTrip } from "../domain.mjs";
import { TRIPS } from "../fixtures.mjs";
import { createEmbeddedTransport } from "../portable/transport.mjs";
import { startServer } from "../server.mjs";
import { loadWorkspace, saveHandoff } from "../static/transport.mjs";

const firstTime = "2026-11-28T04:00:00.000Z";
const laterTime = "2026-11-28T05:00:00.000Z";
const sample = TRIPS.find(trip => trip.scenario === "excursion");
const incident = projectTrip(sample).incidents[0];
const input = {
  tripId: sample.id,
  incidentId: incident.id,
  action: "inspect-on-arrival",
  note: "  收货时核对温度与中转记录。  ",
  operationId: "operation-001"
};

async function start(options) {
  const server = startServer({ port: 0, dbPath: ":memory:", clock: () => firstTime, ...options });
  await once(server, "listening");
  return {
    origin: `http://127.0.0.1:${server.address().port}`,
    stop: () => new Promise((resolve, reject) => server.close(error => error ? reject(error) : resolve()))
  };
}

function post(origin, value, headers = {}) {
  return fetch(`${origin}/api/handoffs`, {
    method: "POST",
    headers: { "Content-Type": "application/json", ...headers },
    body: JSON.stringify(value)
  });
}

test("workspace serves fixture telemetry read-only and creates one handoff across simultaneous retries", async t => {
  const { origin, stop } = await start();
  t.after(stop);
  const workspace = await loadWorkspace({ origin });
  assert.deepEqual(workspace, { trips: TRIPS, handoffs: {} });
  const cannotRewrite = await fetch(`${origin}/api/workspace`, { method: "POST", body: "{}" });
  assert.equal(cannotRewrite.status, 405);
  assert.equal(cannotRewrite.headers.get("Allow"), "GET, HEAD");

  const writes = await Promise.all([post(origin, input), post(origin, input)]);
  assert.deepEqual(writes.map(response => response.status).sort(), [200, 201]);
  const [created, replay] = await Promise.all(writes.toSorted((a, b) => b.status - a.status)
    .map(response => response.json()));
  assert.deepEqual(created, { handoff: { ...input, note: input.note.trim(), at: firstTime }, replayed: false });
  assert.deepEqual(replay, { handoff: created.handoff, replayed: true });
  assert.deepEqual(await loadWorkspace({ origin }), {
    trips: workspace.trips,
    handoffs: { [incident.id]: created.handoff }
  });

  await assert.rejects(saveHandoff({ ...input, note: "其他处置" }, { origin }), { code: "operation_conflict" });
  await assert.rejects(saveHandoff({ ...input, operationId: "operation-002" }, { origin }), { code: "incident_already_recorded" });
});

test("sample-only handoff API rejects invalid JSON, unknown evidence and cross-origin writes", async t => {
  const { origin, stop } = await start();
  t.after(stop);
  const invalidCases = [
    [input, { Origin: "https://foreign.example" }, 403, "origin_mismatch"],
    [input, { "Sec-Fetch-Site": "cross-site" }, 403, "origin_mismatch"],
    [input, { "Content-Type": "text/plain" }, 415, "invalid_content_type"],
    [{ ...input, note: "长".repeat(2000) }, {}, 413, "body_too_large"],
    [{ ...input, tripId: "unknown" }, {}, 404, "unknown_trip"],
    [{ ...input, incidentId: "unknown" }, {}, 404, "unknown_incident"],
    [{ ...input, action: "unknown" }, {}, 422, "invalid_handoff"],
    [{ ...input, operationId: "x" }, {}, 400, "invalid_operation_id"],
    [{ ...input, note: " " }, {}, 422, "invalid_handoff"]
  ];
  for (const [value, headers, status, code] of invalidCases) {
    const response = await post(origin, value, headers);
    assert.equal(response.status, status);
    assert.equal((await response.json()).code, code);
  }
  const malformed = await fetch(`${origin}/api/handoffs`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: "{"
  });
  assert.equal(malformed.status, 400);
  assert.equal((await malformed.json()).code, "invalid_json");
  assert.deepEqual((await loadWorkspace({ origin })).handoffs, {});
});

test("SQLite retains the original disposition and operation across restarts", async () => {
  const directory = await mkdtemp(join(tmpdir(), "coldchain-trace-"));
  const dbPath = join(directory, "handoffs.sqlite");
  try {
    const first = await start({ dbPath });
    let saved;
    try {
      saved = await saveHandoff({ ...input, at: laterTime }, { origin: first.origin });
      assert.equal(saved.handoff.at, firstTime);
    } finally {
      await first.stop();
    }
    const next = await start({ dbPath, clock: () => laterTime });
    try {
      assert.deepEqual((await loadWorkspace({ origin: next.origin })).handoffs[incident.id], saved.handoff);
      const retry = await saveHandoff({ ...input, note: input.note.trim() }, { origin: next.origin });
      assert.deepEqual(retry, { handoff: saved.handoff, replayed: true });
    } finally {
      await next.stop();
    }
  } finally {
    await rm(directory, { recursive: true, force: true });
  }
});

test("embedded edition validates and reloads handoffs from browser storage without mutating fixtures", async () => {
  const values = new Map();
  const storage = {
    getItem: key => values.get(key) ?? null,
    setItem: (key, value) => values.set(key, value)
  };
  const first = createEmbeddedTransport({ storage, clock: () => firstTime });
  const original = await first.loadWorkspace();
  original.trips[0].samples[0].tempC = -100;
  assert.deepEqual((await first.loadWorkspace()).trips, TRIPS);

  const saved = await first.saveHandoff(input);
  const later = createEmbeddedTransport({ storage, clock: () => laterTime });
  assert.deepEqual((await later.loadWorkspace()).handoffs[incident.id], saved.handoff);
  assert.deepEqual(await later.saveHandoff(input), { handoff: saved.handoff, replayed: true });
  await assert.rejects(later.saveHandoff({ ...input, note: "其他处置" }), { code: "operation_conflict" });
  await assert.rejects(later.saveHandoff({ ...input, operationId: "operation-002" }), { code: "incident_already_recorded" });
  await assert.rejects(later.saveHandoff({ ...input, note: "" }), { code: "invalid_handoff" });
});
