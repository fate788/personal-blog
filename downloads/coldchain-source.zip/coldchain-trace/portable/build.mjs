import { copyFile, mkdir, readFile, writeFile } from "node:fs/promises";
import { dirname, resolve } from "node:path";

const output = resolve(process.argv[2] || "dist/index.html");
const read = (path) => readFile(new URL(path, import.meta.url), "utf8");
const moduleUrl = (source) => "data:text/javascript;base64," + Buffer.from(source.replaceAll("\r\n", "\n")).toString("base64");
const [domain, fixtures, transport, app, css, html] = await Promise.all([
  read("../domain.mjs"), read("../fixtures.mjs"), read("transport.mjs"), read("../static/app.mjs"),
  read("../static/styles.css"), read("../static/index.html")
]);

function replaceImport(source, filepath, url) {
  return source.replaceAll(`"${filepath}"`, `"${url}"`).replaceAll(`'${filepath}'`, `'${url}'`);
}

const domainUrl = moduleUrl(domain);
const fixturesUrl = moduleUrl(replaceImport(fixtures, "./domain.mjs", domainUrl));
const inlineShared = source => replaceImport(replaceImport(source, "../domain.mjs", domainUrl), "../fixtures.mjs", fixturesUrl);
const transportUrl = moduleUrl(inlineShared(transport));
const appUrl = moduleUrl(replaceImport(inlineShared(app), "./transport.mjs", transportUrl));
const stylesheet = /<link\b[^>]*href=["'](?:\.\/)?styles\.css["'][^>]*>/iu;
const script = /<script\b[^>]*src=["'](?:\.\/)?app\.mjs["'][^>]*>\s*<\/script>/iu;
const policy = "default-src 'none'; style-src 'unsafe-inline'; script-src data:; img-src 'self' data:; connect-src 'none'; base-uri 'none'; form-action 'none'";
if (!stylesheet.test(html) || !script.test(html)) throw new Error("缺少工作台的 HTML 入口。");

const portable = html.replace("<head>", `<head>\n  <meta http-equiv="Content-Security-Policy" content="${policy}">`)
  .replace(stylesheet, () => `<style>\n${css}\n</style>`)
  .replace(script, () => `<script type="module" src="${appUrl}"></script>`);
const media = resolve(dirname(output), "media");
await mkdir(media, { recursive: true });
await copyFile(new URL("../static/media/cold-dock.webp", import.meta.url), resolve(media, "cold-dock.webp"));
await writeFile(output, portable.replaceAll("\r\n", "\n"), "utf8");
console.log(`已生成便携式冷链运输追溯台 ${output}`);
