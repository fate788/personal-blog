import { createHandoff, projectTrip } from "../domain.mjs";
import { TRIPS } from "../fixtures.mjs";

export const executionMode = "embedded";
const storageKey = "coldchain-trace:handoffs:v1";

function handoffError(status, code, message) {
  return Object.assign(new Error(message), { status, code });
}

export function prepareHandoff(input, at) {
  if (!input || typeof input !== "object" || Array.isArray(input)) {
    throw handoffError(400, "invalid_input", "请提交一个交接记录对象。");
  }
  const { tripId, incidentId, action, note, operationId } = input;
  if (typeof operationId !== "string" || !/^[A-Za-z0-9][A-Za-z0-9_-]{7,127}$/u.test(operationId)) {
    throw handoffError(400, "invalid_operation_id", "交接操作编号无效。");
  }
  const trip = TRIPS.find(candidate => candidate.id === tripId);
  if (!trip) throw handoffError(404, "unknown_trip", "找不到这条样例运单。");
  const incident = projectTrip(trip).incidents.find(candidate => candidate.id === incidentId);
  if (!incident) throw handoffError(404, "unknown_incident", "这条样例运单中找不到该事件。");
  try {
    return { tripId, ...createHandoff(incident, { action, note, at }), operationId };
  } catch (error) {
    throw handoffError(422, "invalid_handoff", error.message);
  }
}

export function replayHandoff(handoff, previous) {
  if (!previous) throw handoffError(409, "incident_already_recorded", "这一事件已留下交接记录。");
  if (["tripId", "incidentId", "action", "note"].some(field => previous[field] !== handoff[field])) {
    throw handoffError(409, "operation_conflict", "操作编号已用于其他交接内容。");
  }
  return { handoff: previous, replayed: true };
}

function browserStorage() {
  try {
    const storage = globalThis.localStorage;
    storage?.getItem(storageKey);
    return storage;
  } catch {
    return undefined;
  }
}

export function createEmbeddedTransport({
  storage = browserStorage(),
  locks = globalThis.navigator?.locks,
  clock = () => new Date().toISOString()
} = {}) {
  let memory = {};

  function readHandoffs() {
    if (!storage) return memory;
    try {
      const saved = storage.getItem(storageKey);
      if (saved === null) return {};
      const handoffs = JSON.parse(saved);
      if (!handoffs || typeof handoffs !== "object" || Array.isArray(handoffs)) throw new TypeError();
      return handoffs;
    } catch {
      throw handoffError(500, "storage_read_failed", "读取此浏览器保存的交接记录失败。");
    }
  }

  async function loadWorkspace({ signal } = {}) {
    signal?.throwIfAborted();
    return { trips: structuredClone(TRIPS), handoffs: structuredClone(readHandoffs()) };
  }

  async function saveHandoff(input, { signal } = {}) {
    signal?.throwIfAborted();
    const handoff = prepareHandoff(input, clock());
    function write() {
      const handoffs = readHandoffs();
      const previous = Object.values(handoffs).find(record => record?.operationId === handoff.operationId);
      if (previous || Object.hasOwn(handoffs, handoff.incidentId)) {
        return structuredClone(replayHandoff(handoff, previous));
      }
      const next = { ...handoffs, [handoff.incidentId]: handoff };
      if (storage) {
        try {
          storage.setItem(storageKey, JSON.stringify(next));
        } catch {
          throw handoffError(500, "storage_write_failed", "保存到此浏览器失败，请检查站点存储设置。");
        }
      } else {
        memory = next;
      }
      return { handoff: structuredClone(handoff), replayed: false };
    }
    if (storage && locks) {
      let acquired = false;
      try {
        return await locks.request(storageKey, signal ? { signal } : {}, () => {
          acquired = true;
          return write();
        });
      } catch (error) {
        if (acquired || error.name !== "SecurityError") throw error;
      }
    }
    return write();
  }

  return { loadWorkspace, saveHandoff };
}

let embedded;

export function loadWorkspace(options) {
  embedded ??= createEmbeddedTransport();
  return embedded.loadWorkspace(options);
}

export function saveHandoff(input, options) {
  embedded ??= createEmbeddedTransport();
  return embedded.saveHandoff(input, options);
}
