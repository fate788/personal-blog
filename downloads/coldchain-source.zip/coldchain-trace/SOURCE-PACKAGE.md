# 冷链运输追溯台 v1.0 源码包

原始发布归档为 `冷链运输追溯台-v1.0.zip`。压缩包保留其中 16 份文本文件的原始路径与字节，本文件为导出说明。

需要 Node.js 22.13 或以上。运行 node server.mjs 或双击 start-coldchain.cmd；npm test 复跑验收。
