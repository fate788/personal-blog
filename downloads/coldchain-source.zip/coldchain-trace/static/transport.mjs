export const executionMode = "http";

async function request(path, { origin = "", signal, method = "GET", input } = {}) {
  if (origin && !/^http:\/\/(?:127\.0\.0\.1|localhost):\d{1,5}$/u.test(origin)) {
    throw new Error("本机样例服务地址无效。");
  }
  const body = input === undefined ? undefined : JSON.stringify(input);
  const response = await fetch(`${origin}/api/${path}`, {
    method,
    body,
    headers: body === undefined ? undefined : { "Content-Type": "application/json" },
    cache: "no-store",
    redirect: "error",
    signal: signal ?? AbortSignal.timeout(12000)
  });
  const payload = await response.json();
  if (!response.ok) {
    throw Object.assign(new Error(payload.message || "样例服务暂时不可用。"), { code: payload.code });
  }
  return payload;
}

export function loadWorkspace(options) {
  return request("workspace", options);
}

export function saveHandoff(input, options) {
  return request("handoffs", { ...options, method: "POST", input });
}
