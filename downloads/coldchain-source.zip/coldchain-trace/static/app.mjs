import { HANDOFF_ACTIONS, projectTrip } from '../domain.mjs';
import { executionMode, loadWorkspace, saveHandoff } from './transport.mjs';

const $ = id => document.getElementById(id);
const enc = value => String(value ?? '').replace(/[&<>"']/g, char => ({
  '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;',
})[char]);

const clockFormat = new Intl.DateTimeFormat('zh-CN', {
  timeZone: 'Asia/Shanghai', hour: '2-digit', minute: '2-digit', hourCycle: 'h23',
});
const dateFormat = new Intl.DateTimeFormat('zh-CN', {
  timeZone: 'Asia/Shanghai', year: 'numeric', month: '2-digit', day: '2-digit',
});

const clock = at => at ? clockFormat.format(new Date(at)) : '—';
const date = at => at ? dateFormat.format(new Date(at)) : '—';
const temperature = value => value === null ? '—' : `${value.toFixed(1)} ℃`;

const scenarios = {
  all: { label: '全部运单' },
  excursion: { label: '温度超限', color: 'warning' },
  normal: { label: '全程正常', color: '' },
  gap: { label: '采样缺失', color: 'gap' },
};

let workspace = { trips: [], handoffs: {} };
let trip;
let fullProjection;
let projection;
let slot = 0;
let totalSlots = 0;
let filter = 'all';
let incidentId;
let formRecordId;
let replayTimer;
const drafts = new Map();

function setMarkup(id, html) {
  const element = $(id);
  if (element.sourceMarkup === html) return;
  element.innerHTML = html;
  element.sourceMarkup = html;
}

function badge(scenario) {
  const { color, label } = scenarios[scenario] ?? scenarios.normal;
  return `<span class="badge ${color}">${label}</span>`;
}

function renderShipments() {
  const filtered = workspace.trips.filter(item => filter === 'all' || item.scenario === filter);
  $('filter-label').textContent = scenarios[filter].label;
  for (const button of $('filter-menu').querySelectorAll('[data-filter]')) {
    button.setAttribute('aria-pressed', String(button.dataset.filter === filter));
  }
  setMarkup('shipment-list', filtered.map(item => `
    <button class="shipment" data-trip="${enc(item.id)}" type="button" aria-pressed="${item.id === trip?.id}">
      <span class="shipment-line"><span class="shipment-ref">${enc(item.id.toUpperCase())}</span>${badge(item.scenario)}</span>
      <span class="shipment-route">${enc(item.name)}</span>
      <span class="shipment-foot"><span>${enc(item.shipment)}</span><time datetime="${enc(item.startAt)}">${clock(item.startAt)}</time></span>
    </button>`).join(''));
}

function rememberTrip(id) {
  const address = new URL(location.href);
  address.searchParams.set('trip', id);
  try {
    history.replaceState(null, '', address);
  } catch {
    // Some browsers restrict address changes for a local static file.
  }
}

function selectTrip(item, updateAddress = true) {
  if (!item) return;
  pauseReplay();
  trip = item;
  fullProjection = projectTrip(trip, { handoffs: workspace.handoffs });
  totalSlots = Math.ceil((Date.parse(trip.endAt) - Date.parse(trip.startAt)) / (trip.intervalMinutes * 60_000));
  incidentId = undefined;
  if (updateAddress) rememberTrip(trip.id);
  $('trip-workspace').hidden = false;
  $('trip-reference').textContent = trip.id.toUpperCase();
  setMarkup('trip-status', badge(trip.scenario));
  $('trip-name').textContent = trip.name;
  $('trip-journey').textContent = `${trip.origin} → ${trip.destination}`;
  $('trip-meta').textContent = [trip.shipment, trip.vehicle, trip.estimate?.carrier, trip.estimate?.distanceKm && `${trip.estimate.distanceKm} 公里`].filter(Boolean).join('  /  ');
  $('trip-start').textContent = `${date(trip.startAt)} ${clock(trip.startAt)}`;
  $('trip-end').textContent = clock(trip.endAt);
  const { minC, maxC, minExcursionMinutes } = trip.policy;
  $('chart-note').textContent = `${minC}–${maxC} ℃ · 每 ${trip.intervalMinutes} 分钟采样 · 持续 ${minExcursionMinutes} 分钟触发超限`;
  $('cursor-input').max = String(totalSlots);
  $('raw-data').open = false;
  seek(totalSlots);
  renderShipments();
}

function seek(index) {
  if (!trip) return;
  slot = Math.min(totalSlots, Math.max(0, index));
  const at = Math.min(Date.parse(trip.endAt), Date.parse(trip.startAt) + slot * trip.intervalMinutes * 60_000);
  projection = projectTrip(trip, { cursorAt: at, handoffs: workspace.handoffs });
  renderReplay();
}

function seekAt(at) {
  const index = Math.ceil((Date.parse(at) - Date.parse(trip.startAt)) / (trip.intervalMinutes * 60_000));
  seek(index);
}

function renderReplay() {
  const { cursorAt, stats } = projection;
  $('cursor-input').value = String(slot);
  $('cursor-input').setAttribute('aria-valuetext', `${date(cursorAt)} ${clock(cursorAt)}`);
  $('cursor-time').value = clock(cursorAt);
  $('seek-start').disabled = $('seek-prev').disabled = slot === 0;
  $('seek-end').disabled = $('seek-next').disabled = slot === totalSlots;
  $('seek-incident').disabled = fullProjection.incidents.length === 0;
  const unknown = stats.currentTempC === null;
  const nowWarning = !unknown && (stats.currentTempC < trip.policy.minC || stats.currentTempC > trip.policy.maxC);
  setMarkup('telemetry-stats', `
    <dl class="stat"><dt>回放温度</dt><dd class="${unknown ? 'gap' : nowWarning ? 'warning' : ''}">${unknown ? '未知' : temperature(stats.currentTempC)}</dd><p>${
      stats.lastAt ? `${unknown ? '末次采样' : '实测于'} ${clock(stats.lastAt)}` : '尚无采样'}</p></dl>
    <dl class="stat"><dt>已观测最高</dt><dd>${temperature(stats.maxC)}</dd><p>当前回放区间</p></dl>
    <dl class="stat"><dt>采样覆盖率</dt><dd>${stats.coveragePercent}%</dd><p>${stats.readingCount} / ${stats.expectedReadings} 条采样</p></dl>`);
  renderChart();
  renderRoute();
  renderIncidents();
  renderReadings();
}

function renderChart() {
  if (!projection) return;
  const chart = $('telemetry-chart');
  const width = chart.clientWidth;
  const height = chart.clientHeight;
  if (width <= 0 || height <= 0) return;

  const left = 33;
  const right = width - 12;
  const top = 19;
  const bottom = height - 25;
  const start = Date.parse(trip.startAt);
  const end = Date.parse(trip.endAt);
  const range = Math.max(1, end - start);
  const lows = projection.stats.minC ?? trip.policy.minC;
  const highs = projection.stats.maxC ?? trip.policy.maxC;
  const low = Math.min(0, Math.floor(lows / 2) * 2);
  const high = Math.max(12, Math.ceil(highs / 2) * 2);
  const x = at => left + (Date.parse(at) - start) / range * (right - left);
  const y = value => bottom - (value - low) / (high - low) * (bottom - top);
  const isOut = value => value > trip.policy.maxC || value < trip.policy.minC;
  const slices = width < 400 ? 3 : 5;
  const cursor = x(projection.cursorAt);

  const ticksY = Array.from({ length: 5 }, (_, n) => Math.round(low + n / 4 * (high - low)));
  for (const threshold of [trip.policy.minC, trip.policy.maxC]) {
    if (!ticksY.includes(threshold) && ticksY.every(tick => Math.abs(tick - threshold) >= 2)) ticksY.push(threshold);
  }
  const ticksX = Array.from({ length: slices + 1 }, (_, n) => {
    const tickSlot = Math.round(n / slices * totalSlots);
    return new Date(Math.min(end, start + tickSlot * trip.intervalMinutes * 60_000)).toISOString();
  });

  const gaps = projection.gaps.map(gap => {
    const from = x(gap.startAt);
    const to = Math.max(from + 1, x(gap.endAt));
    const available = to - from;
    const center = (from + to) / 2;
    return `<g>
      <rect x="${from}" y="${top}" width="${available}" height="${bottom - top}" fill="url(#gap-pattern)" stroke="#8b98b0" stroke-dasharray="3 3" class="telemetry-gap">
        <title>${clock(gap.startAt)}起缺少 ${gap.missingCount} 条采样</title>
      </rect>
      ${available >= 47 ? `<text x="${center}" y="${top + 13}" class="gap-caption" text-anchor="middle">无读数</text>` : ''}
    </g>`;
  }).join('');
  const excursions = projection.incidents.filter(item => item.type === 'excursion').map(item => {
    const from = x(item.startAt);
    const to = x(item.endAt);
    return `<g>
      <rect x="${from}" y="${top}" width="${Math.max(1, to - from)}" height="${bottom - top}" fill="#fbe4ce" fill-opacity=".7" />
      ${to - from >= 47 ? `<text x="${(from + to) / 2}" y="${top - 4}" class="warning-caption" text-anchor="middle">持续超限</text>` : ''}
    </g>`;
  }).join('');

  const lines = projection.samples.map((sample, index) => {
    const previous = projection.samples[index - 1];
    if (!previous || Date.parse(sample.at) - Date.parse(previous.at) > trip.intervalMinutes * 60_000) return '';
    const warning = isOut(sample.tempC) && isOut(previous.tempC);
    return `<path d="M${x(previous.at)} ${y(previous.tempC)} L${x(sample.at)} ${y(sample.tempC)}" fill="none" stroke="${warning ? '#b85c23' : '#197a6e'}" stroke-width="2.3" stroke-linecap="round" />`;
  }).join('');
  const readingMarkers = projection.samples.map((sample, index) => {
    const color = isOut(sample.tempC) ? '#a9511d' : '#197a6e';
    const isLatest = index === projection.samples.length - 1 && projection.stats.currentTempC !== null;
    return `<circle cx="${x(sample.at)}" cy="${y(sample.tempC)}" r="${isLatest ? 4.4 : 2.5}" fill="#fff" stroke="${color}" stroke-width="${isLatest ? 2.2 : 1.5}"><title>${clock(sample.at)} · ${temperature(sample.tempC)}</title></circle>`;
  }).join('');

  chart.setAttribute('viewBox', `0 0 ${width} ${height}`);
  chart.setAttribute('aria-label', `运输温度曲线，回放至 ${clock(projection.cursorAt)}，${projection.stats.readingCount} 条实测，${projection.gaps.length} 段缺失`);
  setMarkup('telemetry-chart', `
    <defs><pattern id="gap-pattern" width="7" height="7" patternUnits="userSpaceOnUse" patternTransform="rotate(45)">
      <rect width="7" height="7" fill="#edf0f7" fill-opacity=".95" /><line x1="0" y1="0" x2="0" y2="7" stroke="#d4dce9" stroke-width="2" />
    </pattern></defs>
    <rect x="${left}" y="${y(trip.policy.maxC)}" width="${right - left}" height="${y(trip.policy.minC) - y(trip.policy.maxC)}" fill="#e3f1ed" />
    ${ticksY.map(tick => `<line x1="${left}" x2="${right}" y1="${y(tick)}" y2="${y(tick)}" stroke="#d7e4e5" /><text x="${left - 6}" y="${y(tick) + 3}" text-anchor="end">${tick}</text>`).join('')}
    <text x="${left - 6}" y="${top - 5}" text-anchor="end">℃</text>
    ${excursions}${gaps}
    <line x1="${cursor}" x2="${cursor}" y1="${top}" y2="${bottom}" stroke="#346a65" stroke-width="1.1" stroke-dasharray="3 3" />
    ${lines}${readingMarkers}
    ${ticksX.map((at, index) => `<text x="${x(at)}" y="${bottom + 17}" text-anchor="${index === 0 ? 'start' : index === ticksX.length - 1 ? 'end' : 'middle'}">${clock(at)}</text>`).join('')}`);
}

function renderRoute() {
  const { cursorAt, currentLandmark, events, gaps } = projection;
  $('route-position').textContent = currentLandmark ? `回放所在 · ${currentLandmark.zone}` : '等待首个节点';
  const milestones = [
    ...trip.landmarks.map((event, index) => ({ ...event, id: `landmark-${index}`, type: 'landmark' })),
    ...gaps.map(gap => ({ at: gap.startAt, id: gap.id, type: 'missing', label: '采样缺失', zone: `缺少 ${gap.missingCount} 条采样` })),
  ].sort((first, second) => first.at.localeCompare(second.at));
  const doorObservations = new Map();
  for (const event of events) {
    if (event.type !== 'door-open' && event.type !== 'door-closed') continue;
    const landmark = trip.landmarks.findLast(candidate => candidate.at <= event.at);
    if (!landmark) continue;
    const associated = doorObservations.get(landmark.at) ?? [];
    associated.push(event);
    doorObservations.set(landmark.at, associated);
  }
  setMarkup('route-list', milestones.map(event => {
    const style = event.at > cursorAt ? 'future' : event.type === 'missing' ? 'missing'
      : currentLandmark?.at === event.at ? 'current' : '';
    const observations = event.type === 'landmark' ? doorObservations.get(event.at) ?? [] : [];
    return `<li class="route-item ${style}">
      <i class="route-mark" aria-hidden="true"></i>
      <div class="route-content">
        <button class="route-link" type="button" data-route-key="${enc(event.id)}" data-seek-at="${enc(event.at)}" ${style === 'current' ? 'aria-current="step"' : ''}>
          <span>${enc(event.label)} <time datetime="${enc(event.at)}">${clock(event.at)}</time></span><small>${enc(event.zone)}</small>
        </button>
        ${observations.length ? `<div class="route-observations">${observations.map(door => `
          <button class="door-reading" type="button" data-route-key="${enc(door.id)}" data-seek-at="${enc(door.at)}" aria-label="${enc(door.label)} · ${clock(door.at)}">
            ${door.type === 'door-open' ? '开门' : '关门'} <time datetime="${enc(door.at)}">${clock(door.at)}</time>
          </button>`).join('')}</div>` : ''}
      </div></li>`;
  }).join(''));
}

function incidentStatus(incident) {
  const active = incident.status === 'active';
  const state = incident.handoff ? '已登记' : active ? '进行中' : '待处置';
  return `<span class="badge ${incident.handoff ? 'neutral' : incident.type === 'gap' ? 'gap' : 'warning'}">${state}</span>`;
}

function renderIncidents() {
  const { incidents } = projection;
  $('incident-count').textContent = `${incidents.length} 条`;
  const current = incidents.find(item => item.id === incidentId) ?? incidents[0];
  if (current) incidentId = current.id;
  $('incident-empty').hidden = Boolean(current);
  $('incident-detail').hidden = !current;
  setMarkup('incident-list', incidents.map(item => `
    <button class="incident-choice" data-incident="${enc(item.id)}" type="button" aria-pressed="${item === current}">
      <strong>${enc(item.title)}</strong><time datetime="${enc(item.startAt)}">${clock(item.startAt)}</time>${incidentStatus(item)}
    </button>`).join(''));
  if (!current) {
    $('incident-empty').textContent = slot === totalSlots ? '本单在已记录的运输过程内未触发异常。' : '当前回放时刻未触发异常。可拖动时间轴查看后续记录。';
    return;
  }
  const endsAt = current.status === 'closed' && current.type === 'gap' ? current.resolvedAt : current.endAt;
  const rangeLabel = current.type === 'gap' ? '数据缺失区间' : '首末超限观测';
  setMarkup('evidence-summary', `
    <div><dt>${rangeLabel}</dt><dd>${clock(current.startAt)} – ${clock(endsAt)} · ${current.durationMinutes} 分钟</dd></div>
    <div><dt>${current.type === 'gap' ? '缺少采样' : '超限极值'}</dt><dd>${
      current.type === 'gap' ? `${current.missingCount} 条 · 温度未知` : temperature(current.direction === 'low' ? current.minC : current.maxC)}</dd></div>
    <div class="evidence-wide"><dt>判断依据</dt><dd>${enc(current.cause)}</dd></div>
  `);
  setMarkup('evidence-list', current.evidence.map(event => `<li><time datetime="${enc(event.at)}">${clock(event.at)}</time><span>${enc(event.label)}</span></li>`).join(''));
  renderHandoff(current);
}

function renderHandoff(incident) {
  const saved = incident.handoff;
  $('handoff-record').hidden = !saved;
  $('handoff-form').hidden = Boolean(saved);
  if (saved) {
    const decision = HANDOFF_ACTIONS.find(item => item.id === saved.action)?.label ?? saved.action;
    setMarkup('handoff-record', `<div class="handoff-saved"><strong>${enc(decision)}</strong><p>${enc(saved.note)}</p><time datetime="${enc(saved.at)}">${date(saved.at)} ${clock(saved.at)} 已保存</time></div>`);
  }
  if (formRecordId === incident.id) return;
  formRecordId = incident.id;
  const draft = drafts.get(incident.id);
  $('handoff-form').reset();
  $('handoff-note').value = draft?.note ?? '';
  const action = [...$('action-options').querySelectorAll('input')].find(input => input.value === draft?.action);
  if (action) action.checked = true;
  updateHandoffMessage(draft?.message ?? '', draft?.error);
  $('handoff-save').disabled = Boolean(draft?.saving);
}

function renderReadings() {
  $('raw-count').textContent = `${projection.samples.length} 条`;
  $('download-readings').disabled = projection.samples.length === 0;
  if (!$('raw-data').open) return;
  const records = projection.samples.toReversed().map(sample => `<tr>
    <td>${clock(sample.at)}</td><td>${temperature(sample.tempC)}</td><td>${enc(sample.zone)}</td><td>${sample.doorOpen == null ? '未知' : sample.doorOpen ? '打开' : '关闭'}</td>
  </tr>`).join('');
  setMarkup('raw-table', records || '<tr><td colspan="4" class="table-empty">当前时刻无记录</td></tr>');
}

function downloadReadings() {
  const quote = value => `"${String(value ?? '').replaceAll('"', '""')}"`;
  const records = [['运单号', '采样记录 ID', '采样时间 UTC', '温度 ℃', '采样位置', '厢门']];
  for (const sample of projection.samples) {
    records.push([trip.id, sample.id, sample.at, sample.tempC, sample.zone,
      sample.doorOpen == null ? '未知' : sample.doorOpen ? '打开' : '关闭']);
  }
  const blob = new Blob(['\uFEFF', records.map(row => row.map(quote).join(',')).join('\r\n'), '\r\n'],
    { type: 'text/csv;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement('a');
  anchor.href = url;
  anchor.download = `${trip.id}-${clock(projection.cursorAt).replace(':', '')}-readings.csv`;
  document.body.append(anchor);
  anchor.click();
  anchor.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1_000);
}

function pauseReplay() {
  if (replayTimer) clearInterval(replayTimer);
  replayTimer = undefined;
  $('play-toggle').textContent = '回放';
}

function toggleReplay() {
  if (replayTimer) {
    pauseReplay();
    return;
  }
  if (slot === totalSlots) seek(0);
  $('play-toggle').textContent = '暂停';
  replayTimer = setInterval(() => {
    seek(slot + 1);
    if (slot === totalSlots) pauseReplay();
  }, 360);
}

function setSavePending(saving) {
  $('handoff-save').disabled = saving;
  $('handoff-actions').disabled = saving;
  $('handoff-note').readOnly = saving;
}

function updateHandoffMessage(message, error = false) {
  $('handoff-message').textContent = message;
  $('handoff-message').classList.toggle('error', Boolean(error));
}

function readDraft() {
  if (!formRecordId) return;
  const note = $('handoff-note').value;
  const action = $('action-options').querySelector('input:checked')?.value ?? '';
  const previous = drafts.get(formRecordId);
  if (previous?.saving) return;
  if (!previous || previous.note !== note || previous.action !== action) {
    drafts.set(formRecordId, { note, action });
    updateHandoffMessage('');
  }
}

async function submitHandoff(event) {
  event.preventDefault();
  pauseReplay();
  const tripId = trip.id;
  const id = formRecordId;
  readDraft();
  const draft = drafts.get(id);
  if (!draft || draft.saving) return;
  const { note, action } = draft;
  if (!action || !note.trim()) {
    updateHandoffMessage('请选择处置决定并填写交接备注。', true);
    return;
  }
  draft.operationId ??= globalThis.crypto.randomUUID?.() ?? `op-${Date.now()}-${Array.from(crypto.getRandomValues(new Uint32Array(3))).join('-')}`;
  draft.saving = true;
  $('handoff-save').disabled = true;
  updateHandoffMessage('正在保存…');
  try {
    const { handoff } = await saveHandoff({ tripId, incidentId: id, action, note, operationId: draft.operationId });
    workspace.handoffs[id] = handoff;
    drafts.delete(id);
    if (trip.id === tripId) seek(slot);
  } catch (error) {
    draft.message = error.message || '保存失败，请重试。';
    draft.error = true;
    if (error.code === 'incident_already_recorded') {
      try {
        const updated = await loadWorkspace();
        workspace.handoffs = updated.handoffs;
        if (trip.id === tripId) seek(slot);
      } catch {
        // Keep the original conflict reason if refreshing the record fails.
      }
    }
  } finally {
    draft.saving = false;
    if (id === formRecordId) {
      $('handoff-save').disabled = false;
      updateHandoffMessage(draft.message ?? '', draft.error);
    }
  }
}

$('shipment-list').addEventListener('click', event => {
  const id = event.target.closest('[data-trip]')?.dataset.trip;
  if (id && id !== trip?.id) {
    selectTrip(workspace.trips.find(item => item.id === id));
    [...$('shipment-list').querySelectorAll('[data-trip]')].find(button => button.dataset.trip === id)?.focus({ preventScroll: true });
  }
});

$('filter-menu').addEventListener('click', event => {
  const menu = $('filter-menu');
  const choice = event.target.closest('[data-filter]')?.dataset.filter;
  if (!choice) return;
  filter = choice;
  const matching = workspace.trips.filter(item => filter === 'all' || item.scenario === filter);
  if (matching.length && !matching.some(item => item.id === trip?.id)) selectTrip(matching[0]);
  renderShipments();
  menu.open = false;
  menu.querySelector('summary').focus();
});

document.addEventListener('click', event => {
  const menu = $('filter-menu');
  if (!menu.contains(event.target)) menu.open = false;
});

document.addEventListener('keydown', event => {
  const menu = $('filter-menu');
  if (event.key === 'Escape' && menu.open) {
    menu.open = false;
    menu.querySelector('summary').focus();
  }
});

$('cursor-input').addEventListener('input', event => {
  pauseReplay();
  seek(Number(event.target.value));
});

for (const [id, position] of [
  ['seek-start', () => 0], ['seek-prev', () => slot - 1],
  ['seek-next', () => slot + 1], ['seek-end', () => totalSlots],
]) {
  $(id).addEventListener('click', () => {
    pauseReplay();
    seek(position());
  });
}

$('play-toggle').addEventListener('click', toggleReplay);
$('seek-incident').addEventListener('click', () => {
  const first = fullProjection.incidents[0];
  if (!first) return;
  pauseReplay();
  incidentId = first.id;
  const offset = first.type === 'excursion' ? trip.policy.minExcursionMinutes * 60_000 : 0;
  seekAt(new Date(Date.parse(first.startAt) + offset).toISOString());
});

$('route-list').addEventListener('click', event => {
  const target = event.target.closest('[data-seek-at]');
  const at = target?.dataset.seekAt;
  if (!at) return;
  pauseReplay();
  seekAt(at);
  [...$('route-list').querySelectorAll('[data-seek-at]')].find(button => button.dataset.routeKey === target.dataset.routeKey)?.focus({ preventScroll: true });
});

$('incident-list').addEventListener('click', event => {
  const id = event.target.closest('[data-incident]')?.dataset.incident;
  if (!id) return;
  pauseReplay();
  incidentId = id;
  renderIncidents();
  [...$('incident-list').querySelectorAll('[data-incident]')].find(button => button.dataset.incident === id)?.focus({ preventScroll: true });
});

$('handoff-form').addEventListener('focusin', pauseReplay);
$('handoff-form').addEventListener('input', readDraft);
$('handoff-form').addEventListener('submit', submitHandoff);
$('raw-data').addEventListener('toggle', () => {
  if (projection) renderReadings();
});
$('download-readings').addEventListener('click', downloadReadings);
new ResizeObserver(renderChart).observe($('telemetry-chart'));

setMarkup('action-options', HANDOFF_ACTIONS.map(option => `<label class="action-option">
  <input type="radio" name="handoff-action" value="${enc(option.id)}"><span>${enc(option.label)}</span>
</label>`).join(''));

$('environment-label').textContent = executionMode === 'embedded' ? '离线样例' : '样例工作区';
$('load-notice').hidden = false;
$('load-notice').textContent = '正在加载样例运单…';

try {
  workspace = await loadWorkspace();
  const requested = new URLSearchParams(location.search).get('trip');
  selectTrip(workspace.trips.find(item => item.id === requested) ?? workspace.trips[0], false);
  $('load-notice').hidden = workspace.trips.length > 0;
  if (!$('load-notice').hidden) $('load-notice').textContent = '暂无样例运单。';
} catch (error) {
  $('load-notice').textContent = `无法加载样例运单。${error.message}`;
}
