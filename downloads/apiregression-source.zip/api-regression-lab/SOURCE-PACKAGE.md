# 接口回归验收台 v1.1 源码包

原始发布归档为 `接口回归验收台-v1.1.zip`。压缩包保留其中 18 份文本文件的原始路径与字节，本文件为导出说明。

需要 Node.js 20 或以上。运行 node server.mjs 或双击 start-regression.cmd。命令行和 CI 可执行 node scripts/gate.mjs --candidate candidate-b。
