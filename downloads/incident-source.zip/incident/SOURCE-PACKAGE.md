# 故障响应工作台 v0.1 源码包

原始发布归档为 `故障响应工作台-v0.1.zip`。压缩包保留其中 8 份文本文件的原始路径与字节，本文件为导出说明。

使用 Python 3.10 或更新版本，在项目根目录运行 `python server.py` 或 `python -m unittest discover -v`。演练服务会随工作台启动。README 中列出了真实对账服务的探针连接方式。
