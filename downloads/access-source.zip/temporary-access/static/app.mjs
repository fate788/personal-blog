import request from "./transport.mjs";

const $ = id => document.getElementById(id);
const escaped = value => String(value ?? "").replace(/[&<>"']/g, ch => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[ch]);
const component = value => encodeURIComponent(value);
const symbols = {
  shield: '<path d="M12 3 20 6v5c0 4.5-3.1 7.8-8 10-4.9-2.2-8-5.5-8-10V6z"/><path d="m9 12 2 2 4-4"/>',
  home: '<path d="m3 10 9-7 9 7M5 9v11h14V9M10 20v-5h4v5"/>',
  grid: '<rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/>',
  file: '<path d="M6 3h8l4 4v14H6zM14 3v5h4M9 12h6m-6 4h6"/>',
  report: '<rect x="4" y="3" width="16" height="18" rx="2"/><path d="M8 16v-3m4 3V9m4 7V7"/>',
  check: '<rect x="4" y="4" width="16" height="16" rx="2"/><path d="m8 12 3 3 5-6"/>',
  key: '<circle cx="8.5" cy="10" r="4.5"/><path d="m12 13 7 7m-3-3 2-2m0 4 2-2"/>',
  clock: '<circle cx="12" cy="12" r="8.5"/><path d="M12 7.5V12l3 2"/>',
  history: '<path d="M4 9a8 8 0 1 1 1.5 8.8M4 5v4h4m4-2v5l3 2"/>',
  lock: '<rect x="5" y="10" width="14" height="10" rx="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3m-4 4v2"/>',
  arrow: '<path d="M4 12h15m-5-5 5 5-5 5"/>',
  back: '<path d="M20 12H5m5-5-5 5 5 5"/>',
  user: '<circle cx="12" cy="8" r="3"/><path d="M5 20v-2a5 5 0 0 1 5-5h4a5 5 0 0 1 5 5v2"/>',
  switch: '<path d="M4 8h15m-4-4 4 4-4 4m5 4H5m4-4-4 4 4 4"/>',
  plus: '<path d="M6 12h12m-6-6v12"/>',
  info: '<circle cx="12" cy="12" r="8.5"/><path d="M12 11v5m0-8v.2"/>'
};
const icon = name => `<i class="ico" aria-hidden="true"><svg viewBox="0 0 24 24">${symbols[name] || symbols.file}</svg></i>`;
const navs = {
  home:["工作台","home"], resources:["资源目录","grid"], requests:["我的申请","file"],
  approvals:["审批队列","check"], grants:["临时授权","key"], audit:["审计记录","history"]
};
const roles = {employee:"申请人",requester:"申请人",approver:"审批人",auditor:"审计员",admin:"管理员"};
const labels = {
  pending:"待审批",approved:"已批准",denied:"已拒绝",withdrawn:"已撤回",active:"有效",
  expired:"已到期",revoked:"已撤销",returned:"已归还",allowed:"验证通过"
};
const events = {
  request_submitted:"提交申请",request_approved:"批准申请",request_denied:"拒绝申请",
  request_withdrawn:"撤回申请",request_expired:"申请等待超时",grant_expired:"授权到期",
  grant_revoked:"撤销授权",grant_returned:"归还权限",report_read:"读取报表",report_denied:"拒绝读取报表"
};
const state = { session:null, workspace:null, report:null, auditFilter:"all", filters:{approvals:"pending",grants:"all"} };
const mainResource = "regional-report";
let renderVersion = 0;
let noticeTimer;
let expiryTimer;
let modalHref = "";
let mutationPending = false;
const devRoutes = {
  report:id=>"#resources/"+component(id),
  detail:(view,id)=>"#"+view+"/"+component(id)
};

function formatTime(value, short = false) {
  if (!value) return "—";
  const date = new Date(value);
  if (Number.isNaN(+date)) return "—";
  return new Intl.DateTimeFormat("zh-CN", {
    year:short?undefined:"numeric",month:"2-digit",day:"2-digit",hour:"2-digit",minute:"2-digit",
    second:short?undefined:"2-digit",hourCycle:"h23"
  }).format(date);
}
function route() {
  try {
    const [view,id] = location.hash.slice(1).split("/").map(decodeURIComponent);
    return {view:Object.hasOwn(navs,view)?view:"home",id:id||""};
  } catch { return {view:"home",id:""}; }
}
const actor = () => state.workspace?.actor || state.session?.user;
const demo = () => state.session?.mode === "demo";
const now = () => state.workspace?.now ?? state.session?.now;
const resource = id => state.workspace.resources.find(item => item.id === id);
const person = id => state.workspace?.people?.find(item => item.id === id) || state.session?.roles?.find(item => item.id === id);
const personName = id => id === "system" ? "系统" : id ? person(id)?.name || id : "—";
const resourceName = id => resource(id)?.name || id;
const isApprover = user => user?.role==="approver" || user?.role==="admin";
const isAuditor = user => user?.role==="auditor" || user?.role==="admin";
const ownRequest = req => req.requesterId === actor().id;
const ownGrant = grant => grant.userId === actor().id;
const viewGrant = (grants,id) => grants.find(grant=>grant.resourceId===id&&grant.status==="active"&&ownGrant(grant));
const canApprove = item => Boolean(item && (item.canApprove ?? item.approverIds?.includes(actor().id)));
const canRequest = item => Boolean(item && (item.canRequest ?? !isAuditor(actor())));
const demoApprover = item => state.session.roles?.find(user=>item?.approverIds?.includes(user.id)) || state.session.roles?.find(isApprover);
function anchor(href, label, kind="secondary", symbol="") {
  return `<a class="btn ${kind}" href="${escaped(href)}">${escaped(label)}${symbol?icon(symbol):""}</a>`;
}
function button(label,attrs="",kind="secondary",symbol="") {
  return `<button class="btn ${kind}" type="button" ${attrs}>${escaped(label)}${symbol?icon(symbol):""}</button>`;
}
function status(value, text) {
  return `<span class="status ${escaped(value)}">${escaped(text || labels[value] || "状态待核对")}</span>`;
}
function heading(title,detail="",actions="") {
  return `<div class="page-head"><div><h1>${escaped(title)}</h1>${detail?`<p>${escaped(detail)}</p>`:""}</div><div class="heading-actions">${actions}</div></div>`;
}
function panelHead(title,help="",actions="") {
  return `<div class="panel-head"><div><h2>${escaped(title)}</h2>${help?`<small>${escaped(help)}</small>`:""}</div>${actions}</div>`;
}
function empty(title,detail,action="",symbol="info") {
  return `<div class="empty">${icon(symbol)}<div><b>${escaped(title)}</b><p>${escaped(detail)}</p>${action}</div></div>`;
}
function callout(text,symbol="info") {
  return `<p class="callout">${icon(symbol)}<span>${escaped(text)}</span></p>`;
}
function setNotice(message) {
  clearTimeout(noticeTimer);
  $("message").textContent = message;
  $("message").hidden = false;
  noticeTimer=setTimeout(()=>{$("message").hidden=true;},4200);
}
function post(path, body={}) { return request(path,{method:"POST",body}); }
function go(href) {
  if (location.hash===href) return loadWorkspace();
  location.hash=href;
}
function showEntry(error) {
  $("shell").hidden = true;
  $("entry").hidden = false;
  const login = state.session?.mode==="team" && !state.session.user;
  if (login) {
    $("entry").innerHTML = `<section class="panel entry-card">
      <span class="category-icon">${icon("shield")}</span><h1>登录临时权限工作台</h1><p>使用团队账号申请资源，或处理分配给你的审批。</p>
      <form id="login-form" method="post"><label class="form-field">团队账号<input name="id" required maxlength="120" autocomplete="username"></label>
        <label class="form-field">密码<input type="password" name="password" required maxlength="256" autocomplete="current-password"></label>
        <p class="form-error" role="alert" hidden></p><button type="submit" class="btn primary">登录${icon("arrow")}</button>
      </form></section>`;
  } else {
    $("entry").innerHTML = `<section class="panel entry-card"><span class="category-icon">${icon("shield")}</span>
      <h1>工作台暂时无法打开</h1><p role="alert">${escaped(error?.message || "请重试。")}</p>${button("重新加载","data-retry","primary")}</section>`;
  }
}
function picker(name, choices, value, label, end=false) {
  const current = choices.find(choice=>choice.value===value) || choices[0];
  if (!current) return "";
  return `<details class="picker ${end?"end":""}" data-picker="${escaped(name)}" data-value="${escaped(current.value)}">
    <summary aria-label="${escaped(label+"，"+current.label)}">${name==="role"?icon("switch"):""}<span class="picker-label">${escaped(current.label)}</span></summary>
    <div class="picker-list" role="group" aria-label="${escaped(label)}">${choices.map(choice=>`<button class="picker-item" type="button" data-pick="${escaped(choice.value)}" aria-pressed="${choice.value===current.value}">${escaped(choice.label)}</button>`).join("")}</div>
  </details>`;
}
function renderFrame(view) {
  $("entry").hidden = true;
  $("shell").hidden = false;
  $("breadcrumb").textContent = navs[view][0];
  document.title = navs[view][0]+" · 临时权限工作台";
  const user = actor();
  const items = ["home","resources","requests",...(isApprover(user)?["approvals"]:[]),"grants",...((isAuditor(user)||isApprover(user))?["audit"]:[])];
  const pending = state.workspace.requests.filter(req=>req.status==="pending"&&canApprove(resource(req.resourceId))&&!ownRequest(req)).length;
  $("navigation").innerHTML = items.map(key=>`<a class="nav-link" href="#${key}" ${view===key?'aria-current="page"':""}>${icon(navs[key][1])}<span>${navs[key][0]}</span>${key==="approvals"&&pending?`<b class="nav-badge">${pending}</b>`:""}</a>`).join("");
  $("actor").innerHTML = `<span class="avatar" aria-hidden="true">${escaped(user.name.slice(0,1))}</span>
    <span><b>${escaped(user.name)}</b><small>${escaped(roles[user.role]||user.role)}${user.department?` · ${escaped(user.department)}`:""}</small></span>`;
  $("logout").hidden = demo();
  $("top-actions").innerHTML = demo()
    ? `<span class="demo-flag">演示工作区</span>${picker("role",state.session.roles.map(user=>({value:user.id,label:roles[user.role]||user.name})),user.id,"切换演示身份",true)}`
    : `<span class="meta">${escaped(user.name)}</span><button class="action-link mobile-logout" type="button" data-logout>退出登录</button>`;
}
function renderResourceRow(item) {
  const authorized = viewGrant(state.workspace.grants,item.id);
  return `<a class="resource-row" href="${escaped(devRoutes.report(item.id))}"><span class="row-icon">${icon("report")}</span>
    <span><b>${escaped(item.name)}</b><small>${escaped(item.department)} · ${escaped(item.category)} · 最长 ${escaped(item.maxMinutes)} 分钟</small></span>
    ${authorized?status("active"):""}<span class="row-arrow">${icon("arrow")}</span></a>`;
}
function renderHome() {
  const {resources,requests,grants} = state.workspace;
  const item = resource(mainResource) || resources[0];
  const quick = item && demo() && actor().id==="employee"
    ? `<a class="btn light" href="${escaped(devRoutes.report(item.id))}" data-start-demo>开始体验${icon("arrow")}</a>` :
    anchor("#resources","查看可用资源","light","arrow");
  const mine = requests.filter(ownRequest).slice(-3).reverse();
  const active = grants.filter(grant=>ownGrant(grant)&&grant.status==="active");
  $("main").innerHTML = `<section class="hero" aria-labelledby="hero-title">
    <div class="hero-copy"><h1 id="hero-title">申请临时权限，按时收回</h1>
      <p>${demo()&&item?`试着申请「${escaped(item.name)}」。审批通过即可查看，权限到期后用同一入口再验一次。 `:"向资源负责人申请访问，跟进审批结果，按授权时段使用内部报表。"} </p>
      <div class="button-row">${quick}${item&&demo()&&actor().id==="employee"?anchor("#resources","浏览资源","dark-outline","grid"):""}</div>
    </div>
    <div class="hero-art" aria-hidden="true"><div class="hero-dot first"></div><div class="vault">${icon("lock")}</div><div class="hero-dot last"></div></div>
  </section>
  <section class="guide" aria-label="访问流程">
    <div class="guide-step">${icon("file")}<div><b>申请所需资源</b><small>填写使用原因和所需时长</small></div></div>
    <div class="guide-step">${icon("check")}<div><b>由负责人审批</b><small>通过后临时授权生效</small></div></div>
    <div class="guide-step">${icon("clock")}<div><b>到期停止访问</b><small>也可以在任务完成后归还</small></div></div>
  </section>
  <div class="home-grid">
    <section class="panel">${panelHead("资源目录","查看资源用途和最长授权时长",`<a class="action-link" href="#resources">全部资源 →</a>`)}
      ${resources.slice(0,4).map(renderResourceRow).join("")||empty("暂无可见资源","请联系团队管理员。","","grid")}</section>
    <section class="panel">${panelHead("我的进度",active.length?`当前有 ${active.length} 项授权有效`:"查看自己提交的申请",`<a class="action-link" href="#requests">申请记录 →</a>`)}
      ${mine.length?mine.map(req=>`<a class="resource-row" href="${escaped(devRoutes.detail("requests",req.id))}"><span class="row-icon">${icon("file")}</span><span><b>${escaped(resourceName(req.resourceId))}</b><small>${escaped(formatTime(req.createdAt,true))}</small></span>${status(req.status)}</a>`).join(""):
      empty("暂无申请记录","提交申请后，可以在这里查看进度。",' <a class="action-link" href="#resources">找一份资源 →</a>',"file")}</section>
  </div>`;
}
function renderResourceDirectory() {
  const {resources,grants}=state.workspace;
  $("main").innerHTML = heading("资源目录","根据业务需要申请指定资源。每份资源单独授权。")+
    `<div class="resource-grid">${resources.map(item=>{
      const authorized = viewGrant(grants,item.id);
      const pending = state.workspace.requests.find(req=>req.resourceId===item.id&&req.status==="pending"&&ownRequest(req));
      const action = authorized?anchor(devRoutes.report(item.id),"打开报表","primary","arrow"):
        pending?anchor(devRoutes.detail("requests",pending.id),"查看申请","primary","arrow"):
        canRequest(item)?button("申请访问",`data-request-resource="${escaped(item.id)}"`,"primary","plus"):"";
      return `<article class="panel resource-card"><div class="resource-ident"><span class="category-icon">${icon("report")}</span>
        <div><h2>${escaped(item.name)}</h2><p>${escaped(item.department)} · ${escaped(item.category)}</p></div></div>
        <p>${escaped(item.summary)}</p><dl><div><dt>最长授权时长</dt><dd>${escaped(item.maxMinutes)} 分钟</dd></div>
        <div><dt>当前访问</dt><dd>${authorized?status("active"):pending?status("pending"):status("locked","待授权")}</dd></div></dl>
        <div class="button-row">${action}${authorized?"":anchor(devRoutes.report(item.id),"查看报表入口","secondary","arrow")}</div></article>`;
    }).join("")||`<section class="panel">${empty("暂无可见资源","请联系团队管理员。","","grid")}</section>`}</div>`;
}

function roleButton(user,href,label,kind="secondary") {
  if (!demo() || !user || user.id===actor().id) return "";
  return button(label,`data-switch-role="${escaped(user.id)}" data-switch-target="${escaped(href)}"`,kind,"switch");
}
function renderRequestRecord(req,adminView) {
  const item = resource(req.resourceId);
  const grant = state.workspace.grants.find(grant=>grant.requestId===req.id);
  const isPending = req.status==="pending";
  const isMine = ownRequest(req);
  const employee = person(req.requesterId);
  const actions = [];
  if (isPending && isMine) {
    actions.push(roleButton(demoApprover(item), devRoutes.detail("approvals",req.id), "切换审批人","primary"));
    actions.push(button("撤回申请",`data-decision="withdraw" data-request-id="${escaped(req.id)}"`));
  }
  if (isPending && adminView && canApprove(item) && !isMine) {
    actions.push(button("批准申请",`data-decision="approve" data-request-id="${escaped(req.id)}"`,"primary","check"));
    actions.push(button("拒绝申请",`data-decision="deny" data-request-id="${escaped(req.id)}"`));
  }
  if (req.status==="approved" && isMine) {
    actions.push(anchor(devRoutes.report(req.resourceId),grant?.status==="active"?"打开报表":"重新验证报表访问","primary","arrow"));
  }
  if (grant?.status==="active" && !isMine && adminView) {
    actions.push(roleButton(employee,devRoutes.report(req.resourceId),"切回申请人查看报表","primary"));
    actions.push(button("撤销授权",`data-decision="revoke" data-grant-id="${escaped(grant.id)}"`));
  }
  const fields = [
    ["申请人",personName(req.requesterId)],["申请时长",req.minutes+" 分钟"],
    ["提交时间",formatTime(req.createdAt)],["最晚处理",formatTime(req.deadlineAt)]
  ];
  if (req.decidedAt) fields.push(["处理时间",formatTime(req.decidedAt)]);
  if (req.decisionBy) fields.push(["处理人",personName(req.decisionBy)]);
  if (grant) fields.push(["授权状态",labels[grant.status]],["授权到期",formatTime(grant.expiresAt)]);
  return `<article class="panel panel-body request-detail">
    <div class="split-head"><div><div class="meta mono">${escaped(req.id)}</div><h2>${escaped(item?.name||req.resourceId)}</h2></div>${status(req.status)}</div>
    <dl class="detail-list">${fields.map(([key,value])=>`<div><dt>${escaped(key)}</dt><dd>${escaped(value)}</dd></div>`).join("")}</dl>
    <p class="meta">使用原因</p><p class="request-reason">${escaped(req.reason)}</p>
    ${req.note?`<p class="meta">处理说明</p><p class="request-reason">${escaped(req.note)}</p>`:""}
    ${actions.some(Boolean)?`<div class="request-footer">${actions.join("")}</div>`:""}
  </article>`;
}
function filterGroup(group,choices,selected) {
  return `<div class="filters" aria-label="筛选">${choices.map(([value,label])=>`<button class="filter-button" type="button"
    data-filter-group="${escaped(group)}" data-filter="${escaped(value)}" aria-pressed="${selected===value}">${escaped(label)}</button>`).join("")}</div>`;
}
function renderRequests(id,adminView=false) {
  const view = adminView?"approvals":"requests";
  if (adminView && !isApprover(actor())) {
    $("main").innerHTML = heading("审批队列")+`<div class="panel">${empty("当前身份无法进入审批队列","只有被指定的资源审批人可以做出审批决定。","","lock")}</div>`;
    return;
  }
  const eligible = state.workspace.requests.filter(req=>adminView?canApprove(resource(req.resourceId))&&!ownRequest(req):ownRequest(req)).reverse();
  const requested = eligible.find(req=>req.id===id);
  const filter = adminView?state.filters.approvals:"all";
  const filtered = eligible.filter(req=>filter==="all" || req.status===filter);
  const selected = requested || filtered[0];
  const caption = adminView?"核对申请原因和访问时长，处理你负责的资源。":"查看自己的申请进度，访问已授权的资源。";
  $("main").innerHTML = heading(navs[view][0],caption,adminView?"":anchor("#resources","申请所需资源","primary","plus"))+
    `${adminView?`<div class="page-filters">${filterGroup("approvals",[["pending","待审批"],["all","全部"]],filter)}</div>`:""}
    <div class="detail-grid"><section class="list-stack" aria-label="申请列表">${filtered.map(req=>`<a class="list-choice"
        href="${escaped(devRoutes.detail(view,req.id))}" ${selected?.id===req.id?'aria-current="true"':""}>
      <span><strong>${escaped(resourceName(req.resourceId))}</strong><small>${escaped(adminView?personName(req.requesterId):formatTime(req.createdAt,true))} · ${escaped(req.minutes)} 分钟</small></span>${status(req.status)}</a>`).join("")||
      `<div class="panel">${empty(adminView?"暂无相关申请":"暂无申请记录",adminView?"待审批的申请将出现在这里。":"可在资源目录中申请需要的报表。","","file")}</div>`}</section>
    ${selected?renderRequestRecord(selected,adminView):""}</div>`;
}
function renderGrants() {
  const filter = state.filters.grants;
  const grants = state.workspace.grants.filter(grant=>filter==="all"||grant.status===filter).reverse();
  const cards = grants.map(grant => {
    const isMine = ownGrant(grant);
    const active = grant.status==="active";
    const options = [];
    if (isMine) options.push(anchor(devRoutes.report(grant.resourceId),active?"打开报表":"重新验证报表访问",active?"primary":"secondary","arrow"));
    if (isMine && active) options.push(button("归还权限",`data-decision="return" data-grant-id="${escaped(grant.id)}"`));
    if (!isMine && active && canApprove(resource(grant.resourceId))) options.push(button("撤销授权",`data-decision="revoke" data-grant-id="${escaped(grant.id)}"`));
    return `<article class="panel resource-card"><div class="split-head"><div class="resource-ident"><span class="category-icon">${icon("key")}</span>
      <div><h2>${escaped(resourceName(grant.resourceId))}</h2><p>${escaped(personName(grant.userId))} · ${escaped(grant.id)}</p></div></div>${status(grant.status)}</div>
      <dl><div><dt>起始时间</dt><dd>${escaped(formatTime(grant.startsAt))}</dd></div><div><dt>${grant.endedAt?"实际结束":"授权到期"}</dt>
      <dd>${escaped(formatTime(grant.endedAt||grant.expiresAt))}</dd></div></dl>
      ${options.length?`<div class="button-row">${options.join("")}</div>`:""}</article>`;
  });
  $("main").innerHTML = heading("临时授权","查看授权期限和历史，也可以主动结束仍有效的授权。")+`<div class="page-filters">
    ${filterGroup("grants",[["all","全部"],["active","有效"],["expired","已到期"],["revoked","已撤销"],["returned","已归还"]],filter)}</div>
    <div class="resource-grid">${cards.join("")||`<section class="panel">${empty("暂无相关授权","审批通过后，授权会出现在这里。","","key")}</section>`}</div>`;
}
function eventGroup(action) {
  if (action.startsWith("report_")) return "report";
  if (action.startsWith("grant_")) return "grant";
  return "request";
}
function renderAudit() {
  const user = actor();
  if (!isAuditor(user) && !isApprover(user)) {
    $("main").innerHTML = heading("审计记录")+`<section class="panel">${empty("当前身份无权查阅审计","请使用具有审计权限的团队身份。","","lock")}</section>`;
    return;
  }
  const filter = state.auditFilter;
  const rows = state.workspace.events.filter(event=>filter==="all" || eventGroup(event.action)===filter).map(event=>{
    const eventLabel = events[event.action] || event.action;
    const actorLabel = personName(event.actorId);
    const resourceLabel = event.resourceId?resourceName(event.resourceId):"";
    const reason = typeof event.details==="string"?event.details:event.details?.note;
    const sameChain = event.requestId?` · ${escaped(event.requestId)}`:"";
    return `<li class="audit-row"><time>${escaped(formatTime(event.at))}</time><div class="event-text"><b>${escaped(eventLabel)}</b>
      <small>${escaped(actorLabel)}${resourceLabel?` · ${escaped(resourceLabel)}`:""}${sameChain}</small>
      ${reason?`<small>${escaped(reason)}</small>`:""}</div>
      ${status(event.action==="report_read"?"allowed":event.action==="report_denied"?"denied":"active",
        eventGroup(event.action)==="report"?(event.action==="report_read"?"通过":"拒绝"):eventGroup(event.action)==="grant"?"授权":"申请")}</li>`;
  });
  $("main").innerHTML = heading("审计记录",isAuditor(user)?"查看申请、审批、授权和实际报表访问的时间线。":"查看自己负责资源上的申请和访问事件。")+
    `<section class="panel">${panelHead("操作时间线","",filterGroup("audit",[["all","全部"],["request","申请与审批"],["grant","授权变更"],["report","报表访问"]],filter))}
    ${rows.length?`<ol class="audit-list">${rows.join("")}</ol>`:empty("暂无相关操作记录","发生申请、授权或访问时，系统会写入对应记录。","","history")}</section>`;
}
function clockPanel(grant) {
  if (!demo()) return "";
  return `<section class="panel clock-panel" aria-label="演示时钟"><div><b>${icon("clock")}演示时钟</b>
    <small>当前时间 ${escaped(formatTime(now()))}。仅推进当前演示工作区。</small></div>
    ${button(grant?"快进至授权到期":"推进 30 分钟",`data-advance-clock="${grant?escaped(grant.expiresAt):""}"`,"secondary","clock")}</section>`;
}
function renderReport(id) {
  const item = resource(id);
  const outcome = state.report;
  const back = anchor("#resources","回到资源目录","secondary","back");
  const headingText = item?.summary||"报表接口会根据当前身份和授权期限重新校验。";
  if (!outcome || outcome.id!==id) {
    $("main").innerHTML = heading(item?.name||"受保护报表",headingText,back)+`<section class="panel">${empty("正在校验访问权限","请稍等。","","lock")}</section>`;
    return;
  }
  if (outcome.error) {
    const denied = outcome.error.status===403;
    const pending = state.workspace.requests.find(req=>req.resourceId===id&&ownRequest(req)&&req.status==="pending");
    const related = state.workspace.grants.findLast(grant=>grant.resourceId===id&&ownGrant(grant));
    const reason = pending?"该资源的申请正在等待审批。获得授权后才可以读取内容。":
      related&&related.status!=="active"?"这项临时授权"+labels[related.status]+"。当前接口拒绝发送报表内容。":
      "当前身份没有这份报表的有效授权。";
    const action = pending?anchor(devRoutes.detail("requests",pending.id),"查看申请进度","primary","arrow"):
      canRequest(item)?button(related?"重新申请访问":"申请访问",`data-request-resource="${escaped(id)}"`,"primary","plus"):"";
    const audit = roleButton(state.session.roles?.find(isAuditor),"#audit","切换审计员查看记录");
    $("main").innerHTML = heading(item?.name||"受保护报表",headingText,back)+`<section class="panel panel-body access-result" data-report-status="${denied?403:escaped(outcome.error.status||500)}">
      <div class="report-hero">${status(denied?"denied":"locked",denied?"访问被拒绝":"校验未完成")}
        <h2>${denied?"报表暂不可读":"无法打开报表"}</h2>
        <p class="report-description">${escaped(denied?reason:outcome.error.message)}</p></div>
      <div class="button-row">${denied?action:""}${button("重新校验访问","data-check-report")}${denied&&related?audit:""}</div>
    </section>${denied&&item?clockPanel(): ""}`;
    return;
  }
  const {report,grant} = outcome.result;
  const columns = Array.isArray(report.columns)?report.columns:[];
  const column = entry => typeof entry==="string"?{key:entry,label:entry}:entry;
  const cells = row => columns.map((entry,index)=>Array.isArray(row)?row[index]:row[column(entry).key]);
  const table = `<div class="report-scroll" tabindex="0" aria-label="报表数据"><table class="report-table">
    <thead><tr>${columns.map(entry=>`<th scope="col">${escaped(column(entry).label)}</th>`).join("")}</tr></thead>
    <tbody>${report.rows.map(row=>`<tr>${cells(row).map(value=>`<td>${escaped(value)}</td>`).join("")}</tr>`).join("")}</tbody></table></div>`;
  $("main").innerHTML = heading(outcome.result.resource.name,headingText,back)+
    `<section class="panel panel-body access-result" data-report-status="200"><div class="report-hero">${status("allowed","访问已授权")}
      <h2>${escaped(report.period||"报表明细")}</h2><p class="report-description">授权截止 ${escaped(formatTime(grant.expiresAt))}
      ${report.summary?" · "+escaped(report.summary):""}</p></div>${table}<div class="request-footer">
      ${button("重新校验访问","data-check-report")}${button("归还权限",`data-decision="return" data-grant-id="${escaped(grant.id)}"`)}</div></section>
      ${clockPanel(grant)}`;
  if (!demo()) {
    const ms = Number(new Date(grant.expiresAt))-Date.now();
    expiryTimer=setTimeout(()=>{if(route().view==="resources"&&route().id===id)loadWorkspace();},Math.min(2147483000,Math.max(250,ms+100)));
  }
}

function renderPage(current) {
  renderFrame(current.view);
  const {view,id} = current;
  if (view==="home") renderHome();
  else if (view==="resources") id?renderReport(id):renderResourceDirectory();
  else if (view==="requests" || view==="approvals") renderRequests(id,view==="approvals");
  else if (view==="grants") renderGrants();
  else renderAudit();
}
async function loadWorkspace() {
  if (!state.session?.user) return;
  const current = route();
  const version = ++renderVersion;
  clearTimeout(expiryTimer);
  $("main").setAttribute("aria-busy","true");
  const isReport = current.view==="resources" && current.id;
  if (isReport) {
    state.report = null;
    if (state.workspace) renderPage(current);
  }
  try {
    const workspace = await request("/api/workspace");
    if (version!==renderVersion) return;
    state.workspace = workspace;
    renderPage(current);
    if (isReport) {
      const endpoint = "/api/resources/"+component(current.id)+"/report";
      const result = await request(endpoint).then(result=>({result}),error=>({error}));
      if (version!==renderVersion) return;
      state.report = {id:current.id,...result};
      renderReport(current.id);
    }
  } catch (error) {
    if (version!==renderVersion) return;
    if (error.status===401 && !demo()) {
      state.session = {...state.session,user:null};
      showEntry(error);
    } else if (!state.workspace) showEntry(error);
    else {
      $("main").innerHTML = heading(navs[current.view][0])+`<section class="panel panel-body"><p role="alert">${escaped(error.message)}</p>
        ${button("重新加载","data-retry","secondary")}</section>`;
    }
  } finally { if (version===renderVersion) $("main").setAttribute("aria-busy","false"); }
}
async function start() {
  try {
    state.session = await request("/api/session");
    if (state.session.user) await loadWorkspace();
    else showEntry();
  } catch (error) { showEntry(error); }
}
function modalTitle(title,summary) {
  return `<div class="dialog-head"><div><h2 id="modal-title">${escaped(title)}</h2>
    <p>${escaped(summary)}</p></div><button type="button" class="close" data-close aria-label="关闭">×</button></div>`;
}
function modalForm(title,summary,contents,action,formAttrs) {
  if ($("modal").open) $("modal").close();
  $("modal-content").innerHTML = `<div class="dialog-inner">${modalTitle(title,summary)}<form ${formAttrs}>
    ${contents}<p class="form-error" role="alert" hidden></p><div class="form-end">${button("取消","data-close")}
    <button type="submit" class="btn primary">${escaped(action)}${icon("arrow")}</button></div></form></div>`;
  modalHref=location.hash;
  $("modal").showModal();
}
function openRequest(id) {
  const item = resource(id);
  if (!canRequest(item)) return;
  const max = item.maxMinutes;
  const choices = [...new Set([5,15,30,60].filter(minutes=>minutes<max).concat(max))].sort((a,b)=>a-b)
    .map(minutes=>({value:String(minutes),label:`${minutes} 分钟`}));
  const selected=choices.find(choice=>Number(choice.value)>=Math.min(15,max));
  if (max>1) choices.push({value:"custom",label:"自定义时长"});
  const prefilled = demo() && id===mainResource?"本周临时支援区域运营复盘，需要核对区域经营周报。":"";
  modalForm("申请访问",item.name,`<label class="form-field">使用原因<textarea name="reason" minlength="4" maxlength="300" required placeholder="说明工作内容和为什么需要这份报表">${escaped(prefilled)}</textarea></label>
    <div class="form-field"><span>授权时长</span>${picker("minutes",choices,selected.value,"授权时长")}
    <label class="custom-duration" hidden>分钟数<input name="customMinutes" type="number" inputmode="numeric" min="1" max="${escaped(max)}" step="1" disabled></label>
    <small>从审批通过起计时。最长 ${escaped(max)} 分钟。</small></div>`, "提交申请",`id="request-form" data-resource="${escaped(id)}"`);
  $("request-form").elements.reason.focus();
}
const decisions = {
  approve:{title:"批准申请",help:"授权从本次批准起生效，按申请时长到期。"},
  deny:{title:"拒绝申请",help:"申请人可以在进度中查看拒绝原因。",required:true},
  withdraw:{title:"撤回申请",help:"撤回后，审批人将无法再处理这条申请。"},
  revoke:{title:"撤销授权",help:"确认后立即结束这项授权，下一次读取将被拒绝。",required:true},
  return:{title:"归还权限",help:"任务结束后，可立即结束自己的授权。"}
};
function openDecision(kind,id,type) {
  const decision = decisions[kind];
  if (!decision||!id) return;
  modalForm(decision.title,decision.help,`<label class="form-field">${decision.required?"处理原因":"处理说明（选填）"}
    <textarea name="note" maxlength="300" ${decision.required?"required":""} placeholder="记录本次处理的依据"></textarea></label>`,
    decision.title,`id="decision-form" data-action="${escaped(kind)}" data-id="${escaped(id)}" data-type="${escaped(type)}"`);
  $("decision-form").elements.note.focus();
}
function formError(form,message) {
  const error = form.querySelector(".form-error");
  error.textContent = message;
  error.hidden = false;
}
async function submitForm(form) {
  if (mutationPending) return;
  mutationPending = true;
  const submit = form.querySelector('[type="submit"]');
  submit.disabled = true;
  form.querySelector(".form-error").hidden = true;
  const formId=form.getAttribute("id");
  try {
    if (formId==="login-form") {
      const data = new FormData(form);
      state.session=await post("/api/login",{id:data.get("id").trim(),password:data.get("password")});
      state.workspace=null;
      await loadWorkspace();
    } else if (formId==="request-form") {
      const reason=form.elements.reason.value.trim();
      if (reason.length<4) throw new Error("请填写至少 4 个字的使用原因。");
      const value=form.querySelector('[data-picker="minutes"]').dataset.value;
      const minutes=Number(value==="custom"?form.elements.customMinutes.value:value);
      const result = await post("/api/requests",{resourceId:form.dataset.resource,reason,minutes});
      $("modal").close();
      setNotice(result.created===false?"已打开同一份申请。":"申请已提交，等待资源负责人审批。");
      go(devRoutes.detail("requests",result.request.id));
    } else {
      const {action,id,type} = form.dataset;
      const note = form.elements.note.value.trim();
      if (decisions[action].required&&!note) throw new Error("请填写处理原因。");
      await post("/api/"+type+"/"+component(id)+"/"+action,{note});
      $("modal").close();
      setNotice(decisions[action].title+"成功。");
      if (type==="requests"&&route().view==="approvals"&&["approve","deny"].includes(action)) {
        state.filters.approvals="all";
        go(devRoutes.detail("approvals",id));
      } else await loadWorkspace();
    }
  } catch (error) { if (form.isConnected) formError(form,error.message); }
  finally { mutationPending=false; submit.disabled=false; }
}
function suggestedRoleRoute(nextRole) {
  const current = route();
  if (nextRole.role==="auditor") return "#audit";
  if (current.view==="resources") return location.hash;
  return nextRole.role==="approver"?"#approvals":"#home";
}
async function changeRole(id,target) {
  if (id===actor().id || mutationPending) return;
  mutationPending=true;
  try {
    state.session=await post("/api/session/role",{id});
    renderVersion++;
    clearTimeout(expiryTimer);
    state.workspace=null;
    state.report=null;
    // Clear the previous identity’s view before awaiting any new workspace data.
    $("main").replaceChildren();
    $("main").setAttribute("aria-busy","true");
    go(target || suggestedRoleRoute(state.session.user));
  } catch (error) { setNotice(error.message); }
  finally { mutationPending=false; }
}
async function advanceClock(expiresAt) {
  if (mutationPending || !demo()) return;
  mutationPending=true;
  try {
    const delta=expiresAt?Math.ceil((Number(new Date(Number(expiresAt))) - Number(new Date(now())))/60000):30;
    const minutes=Number.isFinite(delta)?Math.min(1440,Math.max(1,delta)):30;
    state.session=await post("/api/demo/clock",{minutes});
    setNotice(`演示时钟已推进 ${minutes} 分钟，正在重新检查报表。`);
    await loadWorkspace();
  } catch (error) { setNotice(error.message); }
  finally { mutationPending=false; }
}
async function signOut() {
  if (mutationPending) return;
  mutationPending = true;
  try {
    state.session=await post("/api/logout");
    state.workspace=null;
    state.report=null;
    clearTimeout(expiryTimer);
    renderVersion++;
    $("main").replaceChildren();
    showEntry();
  } catch (error) { setNotice(error.message); }
  finally { mutationPending=false; }
}
function closePickers(target) {
  document.querySelectorAll(".picker[open]").forEach(menu=>{if (!menu.contains(target)) menu.open=false;});
}
function chooseOption(target) {
  const menu=target.closest(".picker"), value=target.dataset.pick;
  const summary=menu.querySelector("summary");
  menu.open=false;
  summary.focus();
  if (menu.dataset.picker==="role") {changeRole(value);return;}
  menu.dataset.value=value;
  summary.querySelector(".picker-label").textContent=target.textContent;
  summary.setAttribute("aria-label","授权时长，"+target.textContent);
  menu.querySelectorAll("[data-pick]").forEach(option=>{
    option.setAttribute("aria-pressed",String(option===target));
  });
  const input=menu.closest("form").elements.customMinutes;
  input.closest("label").hidden=value!=="custom";
  input.disabled=value!=="custom";
  input.required=value==="custom";
  if (value==="custom") input.focus();
}
function changeFilter(group,value,focusSelector) {
  if (group==="audit") {
    state.auditFilter=value;
    renderAudit();
  } else {
    state.filters[group]=value;
    if(group==="approvals") {
      if(route().id) {go("#approvals");return;}
      renderRequests("",true);
    } else renderGrants();
  }
  document.querySelector(focusSelector)?.focus({preventScroll:true});
}
document.querySelectorAll("[data-icon]").forEach(element=>{
  element.innerHTML=icon(element.dataset.icon);
  element.setAttribute("aria-hidden","true");
});
document.addEventListener("submit",event=>{
  if (["login-form","request-form","decision-form"].includes(event.target.getAttribute("id"))) {
    event.preventDefault();
    submitForm(event.target);
  }
});
document.addEventListener("click",event=>{
  closePickers(event.target);
  const control=event.target.closest("button,a");
  if (!control) return;
  const data=control.dataset;
  if (control.matches(".skip-link")) {event.preventDefault();($("shell").hidden?$("entry"):$("main")).focus();return;}
  if (control.id==="logout" || "logout" in data) signOut();
  else if ("retry" in data) start();
  else if ("pick" in data) chooseOption(control);
  else if ("switchRole" in data) changeRole(data.switchRole,data.switchTarget);
  else if ("close" in data) $("modal").close();
  else if ("requestResource" in data) openRequest(data.requestResource);
  else if ("decision" in data) openDecision(data.decision,data.requestId||data.grantId,data.requestId?"requests":"grants");
  else if ("advanceClock" in data) advanceClock(data.advanceClock);
  else if ("checkReport" in data) loadWorkspace();
  else if ("filter" in data) {
    const selector=`[data-filter-group="${data.filterGroup}"][data-filter="${data.filter}"]`;
    changeFilter(data.filterGroup,data.filter,selector);
  }
});
document.addEventListener("focusin",event=>closePickers(event.target));
document.addEventListener("keydown",event=>{
  const menu=event.target.closest(".picker");
  if (!menu) return;
  if (event.key==="Escape" && menu.open) {
    event.preventDefault();
    event.stopPropagation();
    menu.open=false;
    menu.querySelector("summary").focus();
  } else if (["ArrowDown","ArrowUp","Home","End"].includes(event.key)) {
    event.preventDefault();
    menu.open=true;
    const choices=[...menu.querySelectorAll("[data-pick]")];
    const current=choices.indexOf(document.activeElement);
    const next=event.key==="Home"?0:event.key==="End"?choices.length-1:
      event.key==="ArrowDown"?Math.min(choices.length-1,current+1):current<0?choices.length-1:Math.max(0,current-1);
    choices[next]?.focus();
  }
});
window.addEventListener("hashchange",()=>{
  if ($("modal").open && modalHref!==location.hash) $("modal").close();
  window.scrollTo(0,0);
  loadWorkspace();
});
start();
